/* =====================================================================================
   হোম v2 — নতুন কাজগুলো (ধাপ ২)
   ১) হেডার: স্ক্রল করলে গ্লাস + সরু রেখা
   ২) "আজকের নামাজ": ওয়াক্তে চাপ দিলে শিট → জামাতে/একা/কাজা → সরাসরি আমলের রিপোর্টে (amol_report_state.days[YYYY-MM-DD][fajr|midday|asr|maghrib|isha])
      আমল পেজ খোলা/লোড থাকলে তার নিজের setDayRecord() দিয়েই লেখা হয়, তাই দুই জায়গার হিসাব কখনো আলাদা হয় না।
   ৩) "পড়া চালিয়ে যান": কুরআন/হাদিসে শেষ যেখানে ছিলেন (quran-last-read / hadith-last-read) — চাপ দিলে পেজ খুলে ঠিক সেই জায়গায়
   ৪) সময়ের উৎস: অফলাইনে হিসাব হলে হিরোর মাথায় সালামের ওপরে শুধু আইকন + শহর ("ঢাকা") — চাপ দিলে নামাজ পেজ (লোকেশন ঠিক করতে)
   ৫) পাথেয় শেয়ার (সেটিংস ও হোমের শেয়ার-কার্ড)
   ===================================================================================== */
(function () {
  'use strict';
  var D = document, BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function $(id) { return D.getElementById(id); }
  function tiles() { return D.querySelectorAll('.module-grid .module-tile'); }
  function openTile(i) { var t = tiles()[i]; if (t) t.click(); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dkey(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }

  /* ---------- ১) হেডার ---------- */
  var hdr = $('home-header');
  if (hdr && window.PT && PT.header) PT.header(hdr);

  /* "সময়সূচি →" = নামাজের সময় পেজ */
  var wqOpen = $('wq-open'); if (wqOpen) wqOpen.addEventListener('click', function () { openTile(0); });

  /* ---------- ২) আদায় করেছি ---------- */
  var IDS = ['fajr', 'midday', 'asr', 'maghrib', 'isha'];
  var pills = [].slice.call(D.querySelectorAll('.waqt-pill[data-waqt]'));
  var sheet = $('wq-sheet'), curIdx = -1, curKey = '';

  function amolWin() {
    try { var f = D.querySelector('#amol-overlay iframe.qr-frame'), w = f && f.contentWindow; if (w && typeof w.setDayRecord === 'function') return w; } catch (e) {}
    return null;
  }
  function amolState() {
    var w = amolWin();
    if (w) { try { var st = w.eval('STATE'); if (st && st.days) return st; } catch (e) {} }
    try { var o = JSON.parse(ls('amol_report_state') || 'null'); if (o && typeof o === 'object') { o.days = o.days || {}; return o; } } catch (e) {}
    return { days: {} };
  }
  function getVal(key, id) { var r = amolState().days[key]; return r ? r[id] || '' : ''; }
  function setVal(key, id, v) {
    var w = amolWin();
    if (w) {
      try {
        if (v) w.setDayRecord(key, id, v);
        else w.eval('(function(k,i){if(STATE.days[k]){delete STATE.days[k][i];}persist();})(' + JSON.stringify(key) + ',' + JSON.stringify(id) + ')');
        try { if (typeof w.renderHome === 'function') w.renderHome(); } catch (e2) {}
        return;
      } catch (e) {}
    }
    var st = amolState();                                  /* আমল পেজ এখনো লোড হয়নি: সরাসরি একই জায়গায় লেখা (পেজ খুললে এটাই পড়বে) */
    if (!st.days[key]) st.days[key] = {};
    if (v) st.days[key][id] = v; else delete st.days[key][id];
    if (typeof st.soundOn !== 'boolean') st.soundOn = true;
    ls('amol_report_state', JSON.stringify(st));
  }
  /* রাতে ফজরের আগে "এশা" মানে গতকালের এশা */
  function keyFor(idx) {
    var d = new Date(), W = window.WAQT;
    if (idx === 4 && W && W.ready) { var st = W.at(W.nowSec()); if (st.night) d = new Date(d.getTime() - 86400000); }
    return dkey(d);
  }
  function paintDone() {
    var n = 0, started = 0;
    pills.forEach(function (p, i) {
      var v = getVal(keyFor(i), IDS[i]);
      if (v) p.setAttribute('data-done', v); else p.removeAttribute('data-done');
      if (v === 'jamaat' || v === 'alone') n++;
      if (!p.classList.contains('is-future')) started++;
      var nm = (p.querySelector('.waqt-pill-name') || {}).textContent || '';
      p.setAttribute('aria-label', nm + (v === 'jamaat' ? ', জামাতে আদায় হয়েছে' : v === 'alone' ? ', আদায় হয়েছে' : v === 'qaza' ? ', কাজা' : ''));
    });
    var c = $('wq-count');
    if (c) { c.hidden = !n; c.textContent = bn(n) + '/৫ আদায়'; }
  }
  window.__homePillsUpdated = paintDone;

  /* ---------- ধাপ ৩: রমজান মোড (সেহরি শেষ / ইফতারের কাউন্টডাউন) ---------- */
  var hr = $('home-ramadan');
  function hrT(sec) { var m = Math.round(((sec % 86400) + 86400) % 86400 / 60) % 1440, h = Math.floor(m / 60); return bn(pad(h % 12 || 12) + ':' + pad(m % 60)) + ' <small>' + (h >= 12 ? 'PM' : 'AM') + '</small>'; }
  function hrTick() {
    var W = window.WAQT, hc = D.querySelector('.chip .chip-value');
    var on = !!(W && W.ready && W.starts.length === 5 && hc && /রমজান/.test(hc.textContent || ''));
    if (hr.hidden === on) hr.hidden = !on;
    if (!on) return;
    var now = W.nowSec(), fj = W.starts[0], mg = W.starts[3], tgt, lbl;
    if (now < fj) { tgt = fj; lbl = 'সেহরি শেষ হতে বাকি'; } else if (now < mg) { tgt = mg; lbl = 'ইফতারের বাকি'; } else { tgt = fj + 86400; lbl = 'সেহরি শেষ হতে বাকি'; }
    var d = Math.max(0, tgt - now), t = bn(pad(Math.floor(d / 3600)) + ':' + pad(Math.floor(d % 3600 / 60)) + ':' + pad(d % 60));
    if ($('hr-label').textContent !== lbl) $('hr-label').textContent = lbl;
    $('hr-cd').textContent = t;
    var a = hrT(fj), b = hrT(mg);
    if ($('hr-sehri').innerHTML !== a) $('hr-sehri').innerHTML = a;
    if ($('hr-iftar').innerHTML !== b) $('hr-iftar').innerHTML = b;
  }
  if (hr) { hr.addEventListener('click', function () { openTile(0); }); hrTick(); setInterval(function () { if (!D.hidden) hrTick(); }, 1000); }
  /* ধাপ ৩: নামাজ পেজও একই জায়গায় আদায়-চিহ্ন লেখে/পড়ে (আমল পেজ খোলা থাকলে তার নিজের setDayRecord দিয়ে) */
  window.__ptPrayed = { get: getVal, set: function (key, id, v) { setVal(key, id, v); paintDone(); }, dkey: dkey };

  function openSheet(i) {
    var p = pills[i]; if (!p || !sheet || !window.PT) return;
    if (p.classList.contains('is-future')) { PT.toast(((p.querySelector('.waqt-pill-name') || {}).textContent || 'এই ওয়াক্ত') + '-এর সময় এখনো শুরু হয়নি', { icon: 'clock' }); return; }
    curIdx = i; curKey = keyFor(i);
    var v = getVal(curKey, IDS[i]), nm = (p.querySelector('.waqt-pill-name') || {}).textContent || '';
    $('wq-sheet-title').textContent = nm;
    $('wq-sheet-sub').textContent = (curKey === dkey(new Date()) ? 'আজকের ' : 'গতকালের ') + nm + ' কীভাবে আদায় করেছেন?';
    [].forEach.call(sheet.querySelectorAll('.pt-option'), function (o) { o.setAttribute('aria-checked', o.getAttribute('data-v') === v ? 'true' : 'false'); });
    sheet.querySelector('.wq-clear').hidden = !v;
    PT.sheet.open(sheet);
  }
  pills.forEach(function (p, i) { p.addEventListener('click', function () { openSheet(i); }); });
  if (sheet) sheet.addEventListener('click', function (e) {
    if (e.target.closest('[data-wq-close]')) { PT.sheet.close(sheet); return; }
    var b = e.target.closest('[data-v]'); if (!b || curIdx < 0) return;
    var v = b.getAttribute('data-v'), p = pills[curIdx];
    setVal(curKey, IDS[curIdx], v);
    [].forEach.call(sheet.querySelectorAll('.pt-option'), function (o) { o.setAttribute('aria-checked', o === b ? 'true' : 'false'); });
    paintDone();
    if (p) { p.classList.remove('is-pop'); void p.offsetWidth; p.classList.add('is-pop'); }
    setTimeout(function () { PT.sheet.close(sheet); }, 160);
    if (v === 'jamaat' || v === 'alone') PT.toast('আলহামদুলিল্লাহ — আমলের রিপোর্টে যুক্ত হয়েছে', { type: 'success' });
    else if (v === 'qaza') PT.toast('কাজা হিসেবে রাখা হলো — আমলের রিপোর্টে কাজার হিসাব দেখুন', { icon: 'info' });
    else PT.toast('চিহ্ন মুছে ফেলা হয়েছে', { icon: 'undo' });
  });
  window.addEventListener('storage', function (e) { if (e.key === 'amol_report_state') paintDone(); });
  D.addEventListener('visibilitychange', function () { if (!D.hidden) { paintDone(); paintResume(); } });
  /* আমল পেজ থেকে ফিরলে (পেজ বন্ধ হলে) হোমের চিহ্নও মিলিয়ে নেওয়া */
  var amolOv = $('amol-overlay');
  if (amolOv && window.MutationObserver) new MutationObserver(function () { if (!amolOv.classList.contains('is-open')) paintDone(); }).observe(amolOv, { attributes: true, attributeFilter: ['class'] });

  /* ---------- ৩) পড়া চালিয়ে যান ---------- */
  function readLast(k) { try { var o = JSON.parse(ls(k) || 'null'); return o && (o.label || o.idx) ? o : null; } catch (e) { return null; } }
  function resumeIn(frameSel, appName, tileIdx) {
    openTile(tileIdx);
    var t0 = Date.now();
    (function tryClick() {
      try {
        var f = D.querySelector(frameSel), w = f && f.contentWindow, A = w && w[appName];
        var card = A && A.els && A.els.continueCard;
        if (card && !card.classList.contains('hidden')) { card.click(); return; }
        if (A && A.showContinueCard) { try { A.showContinueCard(); } catch (e) {} }
      } catch (e) {}
      if (Date.now() - t0 < 6000) setTimeout(tryClick, 250);
    })();
  }
  /* ধাপ ৪: কুরআনের খতম-পরিকল্পনা (quran-khatm, features/quran/js/51-khatm.js-এর একই হিসাব) */
  function khatmLine() {
    try {
      var o = JSON.parse(ls('quran-khatm') || 'null'); if (!o || !o.days) return '';
      var T = 610, a = String(o.start).split('-'), st = new Date(+a[0], +a[1] - 1, +a[2]), t = new Date(); t = new Date(t.getFullYear(), t.getMonth(), t.getDate());
      var day = Math.max(0, Math.floor((t - st) / 86400000)), target = Math.min(T, Math.ceil(T / o.days * (day + 1))), best = Math.min(T, o.best || 0);
      if (best >= T) return 'খতম সম্পন্ন — আলহামদুলিল্লাহ';
      return target > best ? 'খতম: আজ বাকি ' + bn(target - best) + ' পৃষ্ঠা · ' + bn(Math.round(best / T * 100)) + '%' : 'খতম: আজকের অংশ শেষ ✓ · ' + bn(Math.round(best / T * 100)) + '%';
    } catch (e) { return ''; }
  }
  function card(kind, data) {
    var q = kind === 'quran';
    var b = D.createElement('button'); b.type = 'button'; b.className = 'resume-card' + (q ? ' is-main' : '');
    b.innerHTML = '<span class="resume-ic">' + (window.PT ? PT.icon(q ? 'quran' : 'hadith') : '') + '</span>' +
      '<span class="resume-tx"><span class="resume-k">' + (q ? 'কুরআন · পড়া চালিয়ে যান' : 'হাদিস · পড়া চালিয়ে যান') + '</span><span class="resume-l"></span></span>' +
      (window.PT ? PT.icon('forward', 'resume-go pt-ic--sm') : '');
    b.querySelector('.resume-l').textContent = String(data.label || '').replace(/\s*—\s*/, ' · ');
    var kl = q ? khatmLine() : '';
    if (kl) { var k = D.createElement('span'); k.className = 'resume-kh'; k.textContent = kl; b.querySelector('.resume-tx').appendChild(k); }
    b.addEventListener('click', function () { q ? resumeIn('#quran-overlay iframe.qr-frame', 'QuranApp', 1) : resumeIn('#hadith-overlay iframe.qr-frame', 'HadithApp', 2); });
    return b;
  }
  var lastSig = '';
  function paintResume() {
    var sec = $('resume-section'), row = $('resume-row'); if (!sec || !row) return;
    var q = readLast('quran-last-read'), h = readLast('hadith-last-read');
    var sig = JSON.stringify([q && q.label, h && h.label, khatmLine()]); if (sig === lastSig) return; lastSig = sig;
    row.textContent = '';
    if (q) row.appendChild(card('quran', q));
    if (h) row.appendChild(card('hadith', h));
    sec.hidden = !(q || h);
    row.style.gridTemplateColumns = (q && h) ? '1fr' : '';
  }
  paintResume();
  ['quran-overlay', 'hadith-overlay'].forEach(function (id) {
    var o = $(id); if (o && window.MutationObserver) new MutationObserver(function () { if (!o.classList.contains('is-open')) paintResume(); }).observe(o, { attributes: true, attributeFilter: ['class'] });
  });

  /* ---------- ৪) সময়ের উৎস ---------- */
  var srcBtn = $('hero-src');
  window.__homeSrcChanged = function () {
    var W = window.WAQT; if (!srcBtn || !W) return;
    if (W.src === 'offline') {
      var pl = W.place || {};
      $('hero-src-t').textContent = pl.known ? (pl.name || 'লোকেশন') : 'ঢাকা · লোকেশন দিন';   /* v174: শুধু শহরের নাম */
      srcBtn.setAttribute('aria-label', (pl.known ? 'অফলাইন হিসাব · ' + (pl.name || '') : 'ঢাকার সময় · লোকেশন দিন') + ' — লোকেশন ঠিক করুন');
      srcBtn.hidden = false;
    } else srcBtn.hidden = true;
  };
  if (srcBtn) srcBtn.addEventListener('click', function () { openTile(0); });
  window.__homeSrcChanged();

  /* ---------- ৫) পাথেয় শেয়ার ---------- */
  var SHARE_TEXT = 'পাথেয় — নামাজের সঠিক সময় ও আজান, কুরআন, হাদিস, দোয়া, আমলের হিসাব — সব এক অ্যাপে, ইন্টারনেট ছাড়াও।\nডাউনলোড: https://patheyobygunjoron.github.io/';
  window.ptShareApp = function () {
    try { if (window.PatheyoShare && PatheyoShare.shareText && PatheyoShare.shareText(SHARE_TEXT) !== false) return; } catch (e) {}
    try { if (navigator.share) { navigator.share({ title: 'পাথেয়', text: SHARE_TEXT }).catch(function () {}); return; } } catch (e) {}
    try { navigator.clipboard.writeText(SHARE_TEXT).then(function () { window.PT && PT.toast('লিংক কপি হয়েছে — যেখানে খুশি পেস্ট করুন', { type: 'success' }); }); } catch (e) {}
  };
  var stShare = $('st-share'); if (stShare) stShare.addEventListener('click', window.ptShareApp);
  D.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-share-app]'); if (b) window.ptShareApp(); });

  /* ---------- ৬) প্রোফাইল: ছবি ও নাম (এখন ফোনেই — 'pt_profile'; ধাপ ৯-এ অ্যাকাউন্টের ছবি/নাম এখানেই বসবে) ---------- */
  var PK = 'pt_profile', pfSheet = $('pf-sheet'), pending = null;
  function prof() { try { var o = JSON.parse(ls(PK) || 'null'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
  function paintProfile() {
    var o = prof(), img = $('hdr-avatar'), btn = $('btn-profile');
    if (img && btn) {
      if (o.photo) { img.src = o.photo; img.hidden = false; btn.classList.add('has-photo'); }
      else { img.hidden = true; img.removeAttribute('src'); btn.classList.remove('has-photo'); }
      btn.setAttribute('aria-label', o.name ? 'প্রোফাইল — ' + o.name : 'প্রোফাইল');
    }
    var hn = $('hero-name'); if (hn) hn.textContent = o.name ? ', ' + String(o.name).split(/\s+/)[0] : '';
  }
  function paintSheet(photo) {
    var pi = $('pf-img'), ph = pfSheet.querySelector('.pf-ph');
    if (photo) { pi.src = photo; pi.hidden = false; ph.style.display = 'none'; } else { pi.hidden = true; pi.removeAttribute('src'); ph.style.display = ''; }
    $('pf-remove').hidden = !photo;
  }
  function openProfile() {
    if (!pfSheet || !window.PT) return;
    var o = prof(); pending = o.photo || '';
    $('pf-name').value = o.name || ''; paintSheet(pending);
    PT.sheet.open(pfSheet);
  }
  /* ছবি: মাঝখান থেকে বর্গাকার কেটে JPEG — ছবি যত বড়ই হোক, ধাপে ধাপে ছোট করে ১০০KB-এর নিচে (লক্ষ্য ≤৯৫KB) আনা হয়।
     আগে ৫১২px-এ কোয়ালিটি কমিয়ে দেখে; তবুও বড় থাকলে মাপ ২০% করে কমিয়ে আবার। (এই ছবিই ফোনে থাকে ও Supabase-এ যায়) */
  var AV_MAX = 95 * 1024;
  function dataBytes(u) { var i = u.indexOf(',') + 1, n = u.length - i, pad = u.slice(-2) === '==' ? 2 : (u.slice(-1) === '=' ? 1 : 0); return Math.floor(n * 3 / 4) - pad; }
  /* EXIF দিক: নতুন WebView ছবি নিজেই সোজা করে (image-orientation: from-image)। পুরোনো WebView-তে হাতে সোজা করা হয়, না হলে ছবি কাত হয়ে যায়। */
  function exifOri(buf) {
    try {
      var v = new DataView(buf); if (v.getUint16(0) !== 0xFFD8) return 1;
      var p = 2, n = v.byteLength;
      while (p + 4 < n) {
        var m = v.getUint16(p); if (m === 0xFFE1) {
          if (v.getUint32(p + 4) !== 0x45786966) return 1;
          var t = p + 10, le = v.getUint16(t) === 0x4949, g = function (o) { return v.getUint16(o, le); };
          var d = t + v.getUint32(t + 4, le), c = g(d);
          for (var i = 0; i < c; i++) { var e = d + 2 + i * 12; if (g(e) === 0x0112) return g(e + 8) || 1; }
          return 1;
        }
        if ((m & 0xFF00) !== 0xFF00) return 1;
        p += 2 + v.getUint16(p + 2);
      }
    } catch (e) {}
    return 1;
  }
  var NATIVE_ORI = false; try { NATIVE_ORI = !!(window.CSS && CSS.supports && CSS.supports('image-orientation', 'from-image')); } catch (e) {}
  /* v203: ছবি নিতে দুই ধাপ — (১) orient: EXIF দিক সোজা করে পূর্ণ ছবি canvas-এ (বড় ছবি হলে ছোট দিক ≤১৬০০px, মেমরি বাঁচাতে),
     (২) ইউজার চাইলে সরিয়ে/ছোট-বড় করে বর্গ বেছে নেয় (openCropper), (৩) exportSquare সেই বর্গ ≤৯৫KB JPEG করে — এটাই ফোনে ও সুপাবেজে যায় */
  var FULL_MAX = 1600;
  function orient(file, cb) {
    var hdr = new FileReader();
    hdr.onloadend = function () {
      var ori = NATIVE_ORI ? 1 : exifOri(hdr.result instanceof ArrayBuffer ? hdr.result : new ArrayBuffer(0));
      var r = new FileReader();
      r.onload = function () {
        var im = new Image();
        im.onload = function () {
          var sw = im.naturalWidth || im.width, sh = im.naturalHeight || im.height, swap = ori >= 5 && ori <= 8;
          var W0 = swap ? sh : sw, H0 = swap ? sw : sh, f = Math.min(1, FULL_MAX / Math.min(W0, H0));
          var out = null;
          try {
            var full = D.createElement('canvas'); full.width = Math.max(1, Math.round(W0 * f)); full.height = Math.max(1, Math.round(H0 * f));
            var fx = full.getContext('2d');
            var T = { 1: [1, 0, 0, 1, 0, 0], 2: [-1, 0, 0, 1, W0, 0], 3: [-1, 0, 0, -1, W0, H0], 4: [1, 0, 0, -1, 0, H0], 5: [0, 1, 1, 0, 0, 0], 6: [0, 1, -1, 0, W0, 0], 7: [0, -1, -1, 0, W0, H0], 8: [0, -1, 1, 0, 0, H0] }[ori] || [1, 0, 0, 1, 0, 0];
            fx.setTransform(T[0] * f, T[1] * f, T[2] * f, T[3] * f, T[4] * f, T[5] * f);
            fx.drawImage(im, 0, 0);
            out = full;
          } catch (e) { out = null; }
          cb(out);
        };
        im.onerror = function () { cb(null); };
        im.src = r.result;
      };
      r.onerror = function () { cb(null); };
      r.readAsDataURL(file);
    };
    hdr.onerror = function () { cb(null); };
    hdr.readAsArrayBuffer(file.slice(0, 131072));
  }
  /* v217: ছবি-কাটা পর্দা নতুন করে — (ক) মসৃণ জুম/সরানো, (খ) "যা দেখছেন তাই পাবেন", (গ) মাথা কাটা বন্ধ।
     • পুরোনো সমস্যা: প্রতি টাচে ১৬০০px ছবি এক ধাপে ৫× ছোট করে আঁকা (ভারী, দানাদার), স্লাইডার ১০০ ধাপ (প্রতি ধাপে ~১.৬% লাফ),
       জুম সবসময় ছবির মাঝখান ঘিরে, কিনারায় clamp ছবিকে হঠাৎ টানত, আর পুরো-পর্দার backdrop-blur ক্যানভাস বদলালে ভারী।
     • এখন: ছবির ছোট সংস্করণ (mip) আগে থেকে বানানো → আঁকা সস্তা ও মসৃণ; requestAnimationFrame-এ ফ্রেম-প্রতি একবার আঁকা; ওভারলে একবারই বানানো;
       স্লাইডার ১০০০ ধাপ + নরম গতি; জুম আঙুলের মাঝবিন্দু/মাউস ঘিরে; দুই আঙুলে একসাথে সরানো+জুম।
     • মাথা কাটা: (১) ডিফল্ট ক্রপ আর ছবির ঠিক মাঝখান নয় — লম্বা (পোর্ট্রেট) ছবিতে ওপরের দিকে (মাথা সাধারণত সেখানে); FaceDetector থাকলে মুখ ধরে।
       (২) প্রিমিয়ামে ছবি দেখায় ঢেউ-আকারে (বৃত্তের চেয়ে ছোট), অথচ পর্দায় পুরো বৃত্ত দেখাত — তাই যা বৃত্তের ভেতরে মনে হতো তাও কেটে যেত।
       এখন পর্দায় ঠিক সেই আকারই (প্রিমিয়ামে ঢেউ, নইলে বৃত্ত) দেখায় যেটা সেভের পর প্রোফাইলে দেখা যাবে। */
  /* প্রিমিয়ামের ঢেউ-আকার: shell/css/10-shell.css-এর --pt-wave-এর সাথে একই সূত্র (১০০×১০০ বাক্স) — একটা বদলালে অন্যটাও বদলাবেন */
  var WV = { n: 16, rc: 45.5, a: 0.052, w: 3.8, gap: 1.4, pts: 480 };
  function wavePts(S) {
    var N = WV.pts, X = [], Y = [], out = [], d = WV.w / 2 + WV.gap, i, th, r;
    for (i = 0; i < N; i++) {
      th = -Math.PI / 2 + i * 2 * Math.PI / N; r = WV.rc * (1 + WV.a * Math.cos(WV.n * (th + Math.PI / 2)));
      X.push(50 + r * Math.cos(th)); Y.push(50 + r * Math.sin(th));
    }
    for (i = 0; i < N; i++) {                                   /* ভেতরের দিকে লম্ব ধরে সমান সরানো = ছবির মাস্ক */
      var p = (i + N - 1) % N, q = (i + 1) % N, dx = X[q] - X[p], dy = Y[q] - Y[p], l = Math.hypot(dx, dy) || 1;
      out.push([(X[i] - dy / l * d) * S / 100, (Y[i] + dx / l * d) * S / 100]);
    }
    return out;
  }
  /* ছবির আধা-আধা ছোট সংস্করণ (mip): আঁকার সময় সবসময় ≤২× ছোট করতে হয় → দ্রুত ও মসৃণ, দানা পড়ে না */
  function mips(full, dst) {
    var L = [{ c: full, fx: 1, fy: 1 }], c = full;
    try {
      while (Math.min(c.width, c.height) >= dst * 2 && L.length < 4) {
        var h = D.createElement('canvas'); h.width = Math.max(1, c.width >> 1); h.height = Math.max(1, c.height >> 1);
        var x = h.getContext('2d'); x.imageSmoothingEnabled = true; try { x.imageSmoothingQuality = 'high'; } catch (e) {}
        x.drawImage(c, 0, 0, h.width, h.height); c = h;
        L.push({ c: h, fx: h.width / full.width, fy: h.height / full.height });
      }
    } catch (e) {}
    return L;
  }
  function pickLevel(L, srcW, dst) { for (var i = L.length - 1; i > 0; i--) if (srcW * L[i].fx >= dst) return L[i]; return L[0]; }
  /* full-এর (sx, sy) থেকে s×s বর্গ → JPEG ≤ AV_MAX (মাপ ৫১২px পর্যন্ত, দরকারে ধাপে ধাপে ছোট); lv = mip-তালিকা (না দিলে শুধু full) */
  function exportSquare(full, sx, sy, s, lv) {
    var out = '', side = Math.min(Math.floor(s), 512), L = lv || [{ c: full, fx: 1, fy: 1 }];
    try {
      while (side >= 96 && !out) {
        var c = D.createElement('canvas'); c.width = c.height = side;
        var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, side, side);
        x.imageSmoothingEnabled = true; try { x.imageSmoothingQuality = 'high'; } catch (e) {}
        var l = pickLevel(L, s, side);
        x.drawImage(l.c, sx * l.fx, sy * l.fy, s * l.fx, s * l.fy, 0, 0, side, side);
        for (var q = 0.86; q >= 0.4 && !out; q -= 0.08) { var d = c.toDataURL('image/jpeg', q); if (dataBytes(d) <= AV_MAX) out = d; }
        side = Math.floor(side * 0.8);
      }
    } catch (e) { out = ''; }
    return out;
  }
  /* ---------- ছবি কাটা/রিসাইজের পর্দা: আঙুলে সরান, দুই আঙুলে/স্লাইডারে ছোট-বড় ---------- */
  function openCropper(full, done) {
    var Wf = full.width, Hf = full.height;
    var root = D.createElement('div'); root.className = 'pcrop'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-label', 'ছবি ঠিক করুন');
    root.innerHTML = '<div class="pcrop__box"><h3 class="pcrop__t">ছবি ঠিক করুন</h3>' +
      '<p class="pcrop__h">আঙুল দিয়ে সরান; দুই আঙুলে বা নিচের স্লাইডারে ছোট-বড় করুন</p>' +
      '<div class="pcrop__stage"><canvas></canvas></div>' +
      '<input class="pcrop__z" type="range" min="0" max="1000" step="1" value="0" aria-label="ছোট-বড়">' +
      '<div class="pcrop__acts"><button class="pt-btn pt-btn--ghost" type="button" data-c="no">বাতিল</button><button class="pt-btn" type="button" data-c="ok">ঠিক আছে</button></div></div>';
    D.body.appendChild(root);
    var stage = root.querySelector('.pcrop__stage'), cv = root.querySelector('canvas'), zr = root.querySelector('.pcrop__z');
    var S = Math.max(200, Math.round(Math.min(320, (window.innerWidth || 360) - 64))), dpr = Math.min(2, window.devicePixelRatio || 1), PX = Math.round(S * dpr);
    stage.style.width = stage.style.height = S + 'px'; cv.width = cv.height = PX;
    var ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = true;
    var LV = mips(full, PX);
    /* গাইড: সেভের পর প্রোফাইলে যে আকারে দেখাবে ঠিক সেটাই (প্রিমিয়াম = ঢেউ, নইলে বৃত্ত); বাইরেটা অন্ধকার। একবারই আঁকা */
    var shape = D.documentElement.classList.contains('is-premium') ? wavePts(S) : null;
    var ov = D.createElement('canvas'); ov.width = ov.height = PX;
    (function () {
      var c = ov.getContext('2d'); c.scale(PX / S, PX / S);
      function trace() {
        if (shape) { for (var i = 0; i < shape.length; i++) { if (i) c.lineTo(shape[i][0], shape[i][1]); else c.moveTo(shape[i][0], shape[i][1]); } c.closePath(); }
        else { c.moveTo(S - 1, S / 2); c.arc(S / 2, S / 2, S / 2 - 1, 0, Math.PI * 2); c.closePath(); }
      }
      c.fillStyle = 'rgba(8,12,24,.66)'; c.beginPath(); c.rect(0, 0, S, S); trace(); c.fill('evenodd');
      c.lineWidth = 1.5; c.lineJoin = 'round'; c.strokeStyle = 'rgba(217,169,63,.95)'; c.beginPath(); trace(); c.stroke();
    })();
    var minK = S / Math.min(Wf, Hf), maxK = minK * 5, k = minK;
    /* শুরুর ফ্রেম: লম্বা ছবিতে মাথা সাধারণত ওপরের দিকে থাকে, তাই ঠিক মাঝখান নয় — ওপরের দিক ঘেঁষে (৩৮% উচ্চতায় কেন্দ্র) */
    var cx = Wf / 2, cy = Hf > Wf ? Hf * 0.38 : Hf / 2;
    var tk = null, tfx = 0, tfy = 0, raf = 0, lastT = 0, touched = false, closed = false;
    function clampPos() { var h = S / (2 * k); cx = Math.min(Math.max(cx, h), Wf - h); cy = Math.min(Math.max(cy, h), Hf - h); }
    clampPos();
    /* জুম: (fx, fy) = ক্যানভাসের কেন্দ্র থেকে px-দূরত্ব; ওই বিন্দুর নিচের ছবি-অংশ জায়গায় থাকে */
    function zoomAt(nk, fx, fy) {
      nk = Math.min(maxK, Math.max(minK, nk));
      var ix = cx + fx / k, iy = cy + fy / k; k = nk; cx = ix - fx / k; cy = iy - fy / k; clampPos();
    }
    function sliderVal(v) { return String(Math.round(1000 * Math.log(v / minK) / Math.log(maxK / minK))); }
    function render() {
      clampPos(); var w = S / k, l = pickLevel(LV, w, PX);
      ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, PX, PX);
      ctx.drawImage(l.c, (cx - w / 2) * l.fx, (cy - w / 2) * l.fy, w * l.fx, w * l.fy, 0, 0, PX, PX);
      ctx.drawImage(ov, 0, 0);
    }
    function tick(t) {
      raf = 0; if (closed) return;
      if (tk !== null) {                                          /* স্লাইডার/হুইলের লক্ষ্যের দিকে নরম গতি (গাণিতিক, ফ্রেম-রেট-নিরপেক্ষ) */
        var dt = lastT ? Math.min(48, t - lastT) : 16; lastT = t;
        var nk = k * Math.pow(tk / k, 1 - Math.exp(-dt / 100));
        if (Math.abs(Math.log(tk / nk)) < 0.0006) { nk = tk; tk = null; lastT = 0; }
        zoomAt(nk, tfx, tfy);
      }
      render();
      if (tk !== null) kick();
    }
    function kick() { if (!raf && !closed) raf = requestAnimationFrame(tick); }
    function target(nk, fx, fy) { tk = Math.min(maxK, Math.max(minK, nk)); tfx = fx; tfy = fy; kick(); }
    zr.addEventListener('input', function () { touched = true; target(minK * Math.pow(maxK / minK, (+zr.value) / 1000), 0, 0); });
    var ptr = {}, g = null;
    function plist() { return Object.keys(ptr).map(function (i) { return ptr[i]; }); }
    function gest() { var a = plist(); if (a.length < 2) return null; return { d: Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) || 1, mx: (a[0].x + a[1].x) / 2, my: (a[0].y + a[1].y) / 2 }; }
    stage.addEventListener('pointerdown', function (e) {
      try { stage.setPointerCapture(e.pointerId); } catch (x) {}
      ptr[e.pointerId] = { x: e.clientX, y: e.clientY }; touched = true; tk = null; g = gest(); e.preventDefault();
    });
    stage.addEventListener('pointermove', function (e) {
      var p = ptr[e.pointerId]; if (!p) return;
      var nx = e.clientX, ny = e.clientY;
      if (plist().length >= 2) {
        ptr[e.pointerId] = { x: nx, y: ny }; var n = gest();
        if (g && n) {
          var r = stage.getBoundingClientRect();
          cx -= (n.mx - g.mx) / k; cy -= (n.my - g.my) / k;      /* দুই আঙুলের মাঝবিন্দু সরলে ছবিও সরে */
          zoomAt(k * n.d / g.d, n.mx - r.left - S / 2, n.my - r.top - S / 2);   /* ফাঁক বাড়া/কমা = মাঝবিন্দু ঘিরে জুম */
          zr.value = sliderVal(k);
        }
        g = n;
      } else { cx -= (nx - p.x) / k; cy -= (ny - p.y) / k; ptr[e.pointerId] = { x: nx, y: ny }; clampPos(); }
      kick(); e.preventDefault();
    });
    function up(e) { delete ptr[e.pointerId]; try { stage.releasePointerCapture(e.pointerId); } catch (x) {} g = gest(); }
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
    stage.addEventListener('wheel', function (e) {
      e.preventDefault(); touched = true;
      var r = stage.getBoundingClientRect(), dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY, base = tk !== null ? tk : k;
      var nk = Math.min(maxK, Math.max(minK, base * Math.exp(-dy * 0.002)));
      zr.value = sliderVal(nk); target(nk, e.clientX - r.left - S / 2, e.clientY - r.top - S / 2);
    }, { passive: false });
    function close(res) {
      closed = true; if (raf) cancelAnimationFrame(raf);
      for (var i = 1; i < LV.length; i++) { LV[i].c.width = LV[i].c.height = 0; }   /* ছোট সংস্করণগুলোর মেমরি ছাড়া (full কলারের) */
      if (root.parentNode) root.parentNode.removeChild(root); done(res);
    }
    root.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-c]'); if (!b) return;
      if (b.getAttribute('data-c') === 'no') { close(null); return; }
      if (tk !== null) { zoomAt(tk, tfx, tfy); tk = null; }      /* নরম গতি শেষ হওয়ার আগে চাপলে লক্ষ্যমাপেই কাটা */
      var w = S / k, out = exportSquare(full, cx - w / 2, cy - w / 2, w, LV);
      close(out || '');
    });
    /* মুখ শনাক্তকারী থাকলে (সব WebView-তে নেই) শুরুর ফ্রেম মুখ ধরে — ইউজার হাত দেওয়ার আগেই শুধু */
    try {
      if (window.FaceDetector) {
        var lo = LV[LV.length - 1];
        new window.FaceDetector({ fastMode: true, maxDetectedFaces: 1 }).detect(lo.c).then(function (r) {
          if (closed || touched || !r || !r[0]) return;
          var b = r[0].boundingBox, fw = b.width / lo.fx;
          cx = (b.x + b.width / 2) / lo.fx; cy = (b.y + b.height / 2) / lo.fy - fw * 0.18;   /* চুলের জন্য একটু ওপরে */
          target(S / Math.min(Math.min(Wf, Hf), Math.max(fw * 2.7, 1)), 0, 0);
        }).catch(function () {});
      }
    } catch (e) {}
    render();
  }
  window.__ptPaintProfile = paintProfile;        /* ধাপ ৯: অ্যাকাউন্ট থেকে নাম/ছবি বসলে হেডার নতুন করে */
  /* ধাপ ৯: প্রোফাইল বোতাম এখন অ্যাকাউন্ট কেন্দ্র খোলে (shell/js/10-account.js); না থাকলে আগের মতো */
  var pbtn = $('btn-profile'); if (pbtn) pbtn.addEventListener('click', function () { if (window.__ptAccountOpen) window.__ptAccountOpen(); else openProfile(); });
  window.__ptProfileFill = function () { var o = prof(); pending = o.photo || ''; $('pf-name').value = o.name || ''; paintSheet(pending); };
  window.__ptProfilePending = function (v) { if (v !== undefined) { pending = v; paintSheet(v); } return pending; };
  if (pfSheet) {
    $('pf-photo').addEventListener('click', function () { $('pf-file').click(); });
    $('pf-file').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
      orient(f, function (full) {
        if (!full) { PT.toast('ছবিটা খোলা গেল না — অন্য ছবি দিন', { type: 'danger' }); return; }
        openCropper(full, function (d) {
          if (d === null) return;                                       /* বাতিল — আগের ছবিই থাকে */
          if (d) { pending = d; paintSheet(d); var nm = $('pf-name'); if (nm) nm.dispatchEvent(new Event('input')); }   /* input → "সেভ করুন" চালু */
          else PT.toast('ছবিটা ছোট করা গেল না — অন্য ছবি দিন', { type: 'danger' });
        });
      });
    });
    $('pf-remove').addEventListener('click', function () { pending = ''; paintSheet(''); });
    $('pf-save').addEventListener('click', function () {
      var o = prof(); o.name = $('pf-name').value.trim().slice(0, 40); o.photo = pending || '';
      ls(PK, JSON.stringify(o)); paintProfile(); PT.sheet.close(pfSheet); PT.toast('প্রোফাইল সেভ হয়েছে', { type: 'success' });
    });
    pfSheet.addEventListener('click', function (e) { if (e.target.closest('[data-pf-close]')) PT.sheet.close(pfSheet); });
  }
  paintProfile();

  paintDone();
})();
