/* দোয়া — নিজের পছন্দের দোয়া যোগ/সম্পাদনা/মোছার পপআপ (বটম-শিট; লেখার-সাইজ পপআপের একই .veil + .sheet কাঠামো)।
   যোগ/সম্পাদনা শুধু প্রিমিয়াম সদস্যের জন্য; অন্যদের জন্য একটা বার্তা — "প্রিমিয়াম সদস্যদের সুবিধা" + সাইন-ইনের কথা।
   (আগে যোগ করা দোয়া প্রিমিয়াম শেষ হলেও দেখা যায় ও মোছা যায়; ধর্মীয় বিষয়বস্তু প্রিমিয়ামের পেছনে নয় — এটা শুধু নিজের সংগ্রহ বানানোর সুবিধা।)
   আরবি লেখা দেখানো/টাইপ — কুরআনের Uthmanic Hafs ফন্টে (css/06-custom.css); বাংলা অ্যাপের ফন্টে। */
(function () {
  'use strict';
  var NOTE_ICON_KEYS = ['morning', 'sleep', 'food', 'home', 'salah', 'travel', 'istigfar', 'trouble', 'family', 'quran', 'heart', 'shield', 'book', 'kaaba', 'drop', 'lamp'];
  var CROWN = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 8.5l4.6 4 3.9-6.3 3.9 6.3 4.6-4-1.7 10H5.2z"/></svg>';
  var X = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  function $(id) { return document.getElementById(id); }
  function toast(m) { if (window.DuaToast) window.DuaToast(m); }

  /* ---------- প্রিমিয়াম / সাইন-ইন (হোম শেলের কাজ ব্যবহার করি; ফিচার-পেজ iframe-এ চলে) ---------- */
  function par() { try { return window.parent && window.parent !== window ? window.parent : null; } catch (e) { return null; } }
  function isPremium() {
    try { var p = par(); if (p && typeof p.ptIsPremium === 'function') return !!p.ptIsPremium(); } catch (e) {}
    return document.documentElement.classList.contains('is-premium');
  }
  function signedIn() {
    try { var p = par(), a = p && p.PatheyoAuth; if (a && typeof a.state === 'function') return !!JSON.parse(a.state()).signedIn; } catch (e) {}
    return false;
  }
  function openSignIn() {
    try { var p = par(); if (p && typeof p.__ptAccountOpen === 'function') { p.__ptAccountOpen(); return; } var b = p && p.document.getElementById('btn-profile'); if (b) { b.click(); return; } } catch (e) {}
    toast('উপরের প্রোফাইল বোতাম থেকে সাইন-ইন করুন');
  }
  function openPremium() {
    try { var p = par(); if (p && typeof p.ptOpenPremium === 'function') { p.ptOpenPremium('dua'); return; } } catch (e) {}
    toast('সেটিংসের "প্রিমিয়াম" থেকে প্রিমিয়াম দেখুন');
  }
  /* প্রিমিয়াম বদলালে ("+" এর মুকুট-চিহ্ন) টাইল আবার আঁকি */
  function repaint() { if (window.DuaMain && window.DuaMain.rerail) window.DuaMain.rerail(); }
  try { var pw = par(); if (pw) pw.addEventListener('pt:premium', repaint); } catch (e) {}
  document.addEventListener('visibilitychange', function () { if (!document.hidden) repaint(); });

  /* ---------- বটম-শিট ---------- */
  var veil, sheet, opened = false, after = null, built = false;
  function build() {
    built = true;
    veil = document.createElement('div'); veil.className = 'veil'; veil.id = 'dcveil';
    sheet = document.createElement('div'); sheet.className = 'sheet dcsheet'; sheet.id = 'dcsheet'; sheet.setAttribute('role', 'dialog');
    document.body.appendChild(veil); document.body.appendChild(sheet);
    veil.addEventListener('click', function () { requestClose(); });
  }
  function show(html, label) {
    if (!built) build();
    sheet.setAttribute('aria-label', label || '');
    sheet.innerHTML = '<div class="grab"></div>' + html;
    if (!opened) {
      opened = true;
      try { history.pushState({ dcs: 1 }, ''); } catch (e) {}
      document.documentElement.classList.add('hs-lock', 'dsz-open');
      void sheet.offsetWidth;
      veil.classList.add('on'); sheet.classList.add('on');
    }
    sheet.scrollTop = 0;
  }
  function hide() {
    if (!opened) return;
    opened = false;
    veil.classList.remove('on'); sheet.classList.remove('on');
    document.documentElement.classList.remove('hs-lock', 'dsz-open');
    var f = after; after = null; if (f) { try { f(); } catch (e) {} }
  }
  function requestClose(cb) {
    if (!opened) { if (typeof cb === 'function') cb(); return; }
    after = typeof cb === 'function' ? cb : null;
    if (history.state && history.state.dcs) history.back(); else hide();
  }
  window.addEventListener('popstate', function () { if (opened) hide(); });

  /* ---------- প্রিমিয়াম লাগবে — বার্তা ---------- */
  function gate() {
    var si = signedIn();
    show('<div class="dcg"><div class="dcg-ic">' + CROWN + '</div>' +
      '<div class="szhd-t">প্রিমিয়াম সদস্যদের সুবিধা</div>' +
      '<p class="dcg-p">নিজের পছন্দের দোয়া যোগ করার সুবিধা শুধু <b>প্রিমিয়াম সদস্যরা</b> পান — নাম ও আইকনসহ যত ইচ্ছা দোয়া যোগ করে নিজের সংগ্রহ বানানো যায়।</p>' +
      '<p class="dcg-p dcg-s">' + (si ? 'আপনি সাইন-ইন করা আছেন। প্রিমিয়াম চালু করলেই এই সুবিধা পাবেন।'
                                   : 'আগে <b>সাইন-ইন</b> করুন, তারপর প্রিমিয়াম চালু করুন। প্রিমিয়াম আপনার অ্যাকাউন্টে থাকে, তাই ফোন বদলালেও সব ফিরে আসে।') + '</p>' +
      '<p class="dcg-n">আগে থেকে থাকা সব দোয়া আগের মতোই সবার জন্য ফ্রি।</p>' +
      '<div class="szbtn"><button type="button" id="dcno">পরে</button><button type="button" class="szok" id="dcgo">' + (si ? 'প্রিমিয়াম দেখুন' : 'সাইন-ইন করুন') + '</button></div></div>', 'প্রিমিয়াম সুবিধা');
    $('dcno').onclick = function () { requestClose(); };
    $('dcgo').onclick = function () { requestClose(function () { if (si) openPremium(); else openSignIn(); }); };
  }

  /* ---------- যোগ / সম্পাদনা ফর্ম ---------- */
  function form(rec) {
    var edit = !!rec, ic = (rec && rec.ic) || 'heart';
    var icons = NOTE_ICON_KEYS.filter(function (k) { return DUA_ICON[k]; }).map(function (k) {
      return '<button type="button" data-ic="' + k + '" class="' + (k === ic ? 'on' : '') + '" aria-label="আইকন">' + DUA_ICON[k] + '</button>';
    }).join('');
    show('<div class="szhd"><div class="szhd-t">' + (edit ? 'দোয়া সম্পাদনা' : 'নিজের দোয়া যোগ করুন') + '</div><button type="button" class="szx" id="dcx" aria-label="বন্ধ করুন">' + X + '</button></div>' +
      '<label class="dcl" for="dcn">দোয়ার নাম</label><input id="dcn" class="dci" type="text" maxlength="40" autocomplete="off" placeholder="যেমন: বাবা-মায়ের জন্য দোয়া">' +
      '<div class="dcl">আইকন বেছে নিন</div><div class="dcicons" id="dcic">' + icons + '</div>' +
      '<label class="dcl" for="dca">আরবি</label><textarea id="dca" class="dci dca" rows="2" lang="ar" dir="rtl" placeholder="আরবি দোয়াটি এখানে লিখুন বা পেস্ট করুন"></textarea>' +
      '<label class="dcl" for="dct">উচ্চারণ <span class="dcopt">(ঐচ্ছিক)</span></label><textarea id="dct" class="dci" rows="2" placeholder="বাংলায় উচ্চারণ"></textarea>' +
      '<label class="dcl" for="dcb">অর্থ <span class="dcopt">(ঐচ্ছিক)</span></label><textarea id="dcb" class="dci" rows="3" placeholder="বাংলা অর্থ"></textarea>' +
      '<p class="dcnote">আরবি লেখা কুরআনের ফন্টে, বাংলা লেখা অ্যাপের নিজের ফন্টে নিজে থেকেই দেখাবে।</p>' +
      '<div class="dcerr" id="dcerr" role="alert"></div>' +
      '<div class="szbtn"><button type="button" id="dcno">বাতিল</button><button type="button" class="szok" id="dcok">' + (edit ? 'সংরক্ষণ করুন' : 'যোগ করুন') + '</button></div>',
      edit ? 'দোয়া সম্পাদনা' : 'নিজের দোয়া যোগ');
    if (rec) { $('dcn').value = rec.n || ''; $('dca').value = rec.ar || ''; $('dct').value = rec.tr || ''; $('dcb').value = rec.bn || ''; }
    ['dca', 'dct', 'dcb'].forEach(function (id) {          /* লেখা বাড়লে ঘরও বাড়ে */
      var t = $(id), grow = function () { t.style.height = 'auto'; t.style.height = (t.scrollHeight + 2) + 'px'; };
      t.addEventListener('input', grow); setTimeout(grow, 60);
    });
    $('dcic').addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[data-ic]') : null; if (!b) return;
      ic = b.getAttribute('data-ic');
      Array.prototype.forEach.call($('dcic').children, function (x) { x.classList.toggle('on', x === b); });
    });
    $('dcx').onclick = $('dcno').onclick = function () { requestClose(); };
    $('dcok').onclick = function () {
      var o = { n: $('dcn').value, ic: ic, ar: $('dca').value, tr: $('dct').value, bn: $('dcb').value }, err = $('dcerr');
      if (!o.n.trim()) { err.textContent = 'দোয়ার একটা নাম দিন'; $('dcn').focus(); return; }
      if (!o.ar.trim() && !o.tr.trim() && !o.bn.trim()) { err.textContent = 'আরবি, উচ্চারণ বা অর্থ — অন্তত একটা লিখুন'; $('dca').focus(); return; }
      var r = edit ? DuaCustom.update(rec.id, o) : DuaCustom.add(o);
      if (!r) { err.textContent = 'সংরক্ষণ করা গেল না — ফোনে জায়গা আছে কি না দেখুন'; return; }
      requestClose(function () {
        if (window.DuaMain) window.DuaMain.select('u_' + r.id);
        toast(edit ? 'দোয়াটি সংরক্ষিত হয়েছে' : 'দোয়াটি যোগ হয়েছে');
      });
    };
  }

  /* ---------- মোছার নিশ্চিতকরণ ---------- */
  function confirmDelete(rec) {
    show('<div class="dcg"><div class="szhd-t">দোয়াটি মুছে ফেলবেন?</div>' +
      '<p class="dcg-p"><b id="dcdn"></b> আপনার সংগ্রহ থেকে মুছে যাবে। এটা আর ফেরানো যাবে না।</p>' +
      '<div class="szbtn"><button type="button" id="dcno">থাক</button><button type="button" class="szok dcdel" id="dcyes">মুছে ফেলুন</button></div></div>', 'মোছার নিশ্চিতকরণ');
    $('dcdn').textContent = rec.n;
    $('dcno').onclick = function () { requestClose(); };
    $('dcyes').onclick = function () { requestClose(function () { DuaCustom.remove(rec.id); toast('দোয়াটি মুছে ফেলা হয়েছে'); }); };
  }

  window.DuaCustomUI = {
    canAdd: isPremium,
    openAdd: function () { if (!isPremium()) { gate(); return; } form(null); },
    openEdit: function (id) { var r = DuaCustom.get(id); if (!r) return; if (!isPremium()) { gate(); return; } form(r); },
    askDelete: function (id) { var r = DuaCustom.get(id); if (r) confirmDelete(r); }
  };
  repaint();
})();
