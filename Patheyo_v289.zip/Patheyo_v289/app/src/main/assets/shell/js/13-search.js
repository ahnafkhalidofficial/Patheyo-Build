/* =============================================================================
   ধাপ ১১: গ্লোবাল সার্চ — হোমের উপর থেকে একবারে কুরআন + হাদিস + দোয়া + আল্লাহর নাম + অ্যাপের ফিচার
   পেজ: index.html-এর #search-overlay (কন্ট্রোলারে 'search' নামে নিবন্ধিত)। খোলে হেডারের 🔍 বোতাম (#btn-search) থেকে।

   কোথা থেকে কী খোঁজা হয় (সব অফলাইন):
     • অ্যাপে       — নিচের FEATURES তালিকা (নাম + সমার্থক শব্দ)
     • সূরা         — কুরআন ফ্রেমের App.SURAH_BN / SURAH_EN (+ "আয়াতুল কুরসি"-র মতো প্রচলিত নাম)
     • আয়াত        — কুরআন ফ্রেমের নিজস্ব সার্চ ইঞ্জিন (QuranApp.FsUi.query) — আরবি সবসময়, তরজমা ডাউনলোড থাকলে বাংলাও
     • দোয়া        — DuaEngine (features/dua/js/02-engine.js — শেলেও লোড হয়)
     • আল্লাহর নাম  — shared/asma.js
     • হাদিস        — ডাউনলোড করা কিতাবগুলোর নিজস্ব সার্চ: সারিতে চাপলে সেই কিতাব খুলে লেখাসহ সার্চ চালু হয়
   ফলাফলে চাপলে window.__ptGo / window.__ptIn দিয়ে ঠিক জায়গায় যায়। সাম্প্রতিক খোঁজ: localStorage 'pt_gs_recent'।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, $ = function (id) { return D.getElementById(id); };
  var ov = $('search-overlay'), q = $('gs-q'), res = $('gs-res'), idle = $('gs-idle'), clr = $('gs-clear'), scopeEl = $('gs-scope');
  if (!ov || !q) return;
  var P = function () { return window.__ptPages; };
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function ic(n, c) { return window.PT ? PT.icon(n, c || '') : ''; }

  /* ঢিলেঢালা মিল: বানানের ছোটখাটো ভিন্নতা (ী/ি, শ/ষ/স, য/জ, ছ/স, ক্ব/ক, হসন্ত, ফাঁকা, হাইফেন) সমান */
  function fold(s) {
    s = String(s == null ? '' : s);
    try { s = s.normalize('NFC'); } catch (e) {}
    return s.toLowerCase()
      .replace(/্ব/g, '').replace(/[‌‍্ঁঃ়ـ'’‘`"\-–—_.,:;()।!?\s]/g, '')
      .replace(/[ী]/g, 'ি').replace(/[ূ]/g, 'ু').replace(/ঈ/g, 'ই').replace(/ঊ/g, 'উ').replace(/ণ/g, 'ন')
      .replace(/[শষছ]/g, 'স').replace(/[যয়]/g, 'জ').replace(/ঝ/g, 'জ').replace(/ৎ/g, 'ত').replace(/ঢ়/g, 'ড়')
      .replace(/[০-৯]/g, function (d) { return String(BN.indexOf(d)); })
      .replace(/[ً-ٰٟۖ-ۭ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');
  }
  function terms(s) { return String(s || '').trim().split(/\s+/).map(fold).filter(Boolean); }
  function hit(hay, tm) { for (var i = 0; i < tm.length; i++) if (hay.indexOf(tm[i]) < 0) return false; return true; }

  /* ---------------- অ্যাপের ফিচার (নাম + মানুষ যেভাবে খোঁজে) ---------------- */
  var FEATURES = [
    ['নামাজের সময়', 'আজকের ওয়াক্ত, নফল, নিষিদ্ধ সময়', 'নামাজ নামায সময় ওয়াক্ত আজান ফজর যোহর জোহর আসর মাগরিব এশা ইশা সেহরি ইফতার নফল তাহাজ্জুদ ইশরাক চাশত', 'mosque', 'f0'],
    ['কুরআন শরিফ', 'তিলাওয়াত, তরজমা, খতম পরিকল্পনা', 'কুরআন কোরআন তিলাওয়াত তরজমা অনুবাদ পারা সূরা খতম অডিও ক্বারি', 'quran', 'f1'],
    ['হাদিস শরিফ', 'বুখারি, মুসলিমসহ ৬ কিতাব', 'হাদিস হাদীস বুখারি মুসলিম তিরমিযি আবু দাউদ নাসাঈ ইবনে মাজাহ', 'hadith', 'f2'],
    ['আমলের রিপোর্ট', 'প্রতিদিনের আমল, ধারা, কাজা', 'আমল রিপোর্ট ধারা স্ট্রিক কাজা জামাত হিসাব অভ্যাস', 'amol', 'f3'],
    ['দোয়া', 'দৈনন্দিন মাসনুন দোয়া', 'দোয়া দুআ মাসনুন জিকির', 'dua', 'f4'],
    ['কিবলা কম্পাস', 'কাবার দিক ও দূরত্ব', 'কিবলা কেবলা দিক কাবা কম্পাস', 'qibla', 'f5'],
    ['ডিজিটাল তাসবিহ', 'জিকির গুনুন, লক্ষ্য রাখুন', 'তাসবিহ তসবি জিকির গণনা সুবহানাল্লাহ আলহামদুলিল্লাহ আল্লাহু আকবার', 'tasbih', 'f6'],
    ['উইজেট হাব', 'হোম-স্ক্রিনে নামাজের সময়', 'উইজেট হোম স্ক্রিন', 'widget', 'f7'],
    ['ক্যালেন্ডার', 'হিজরি ক্যালেন্ডার, বিশেষ দিন ও প্রতিদিনের তারিখ-কার্ড', 'ক্যালেন্ডার তারিখ-কার্ড তারিখ কার্ড হিজরি বাংলা ইংরেজি শেয়ার হিজরি ক্যালেন্ডার বিশেষ দিন আইয়ামে বিয শবে বরাত শবে কদর রমজান ঈদ', 'datecard', 'tile:8'],
    ['যাকাত ক্যালকুলেটর', 'নিসাব ও যাকাতের হিসাব', 'যাকাত জাকাত নিসাব সোনা স্বর্ণ রুপা রূপা ব্যবসা সম্পদ হিসাব ক্যালকুলেটর', 'zakat', 'zakat'],
    ['আসমাউল হুসনা', 'আল্লাহর ৯৯টি নাম', 'আসমাউল হুসনা আল্লাহর নাম ৯৯ নাম আসমা', 'names', 'dua:asma'],
    ['স্মার্ট রিমাইন্ডার', 'কাহফ, রোজা, ঘুমের দোয়া', 'রিমাইন্ডার নোটিফিকেশন মনে করিয়ে কাহফ জুমা রোজা আইয়ামে বীয সোমবার বৃহস্পতিবার ঘুম', 'alarm', 'reminders'],
    ['থিম — লাইট / ডার্ক', 'সেটিংস · চেহারা', 'থিম ডার্ক লাইট রাত মোড রং', 'palette', 'set:st-look'],
    ['পড়ার লেখার সাইজ', 'সেটিংস · কুরআন, হাদিস ও দোয়ার লেখা', 'লেখা সাইজ ফন্ট বড় ছোট', 'text-size', 'set:rs-section'],
    ['ব্যাকআপ ও রিস্টোর', 'সেটিংস · হিসাব নিরাপদ রাখুন', 'ব্যাকআপ রিস্টোর সেভ ফেরত', 'cloud', 'set:bk-section'],
    ['অনুমতি (আজান ঠিকমতো বাজাতে)', 'সেটিংস · অ্যালার্ম, ব্যাটারি, নোটিফিকেশন', 'অনুমতি পারমিশন অ্যালার্ম ব্যাটারি আজান বাজে না', 'shield', 'set:perm-section'],
    ['অ্যাকাউন্ট ও ক্লাউড সিঙ্ক', 'Google বা ইমেইল দিয়ে সাইন-ইন', 'অ্যাকাউন্ট সাইন ইন লগইন গুগল ইমেইল সিঙ্ক ক্লাউড', 'user-circle', 'acc'],
    ['পাথেয় প্রিমিয়াম', 'বিজ্ঞাপন ছাড়া', 'প্রিমিয়াম বিজ্ঞাপন সাবস্ক্রিপশন', 'crown', 'prem']
  ].map(function (f) { return { t: f[0], s: f[1], hay: fold(f[0] + ' ' + f[2]), ic: f[3], go: f[4] }; });

  /* প্রচলিত নাম → আয়াত/সূরা */
  var ALIAS = [
    ['আয়াতুল কুরসি আয়াতুল কুরসী', 2, 255, 'আয়াতুল কুরসি'],
    ['আমানার রাসূল বাকারার শেষ দুই আয়াত', 2, 285, 'সূরা বাকারার শেষ দুই আয়াত'],
    ['তিন কুল চার কুল', 112, 0, 'সূরা ইখলাস (তিন কুল)'],
    ['সূরা ইয়াসিন কুরআনের হৃদয়', 36, 0, 'সূরা ইয়াসীন'],
    ['সূরা মুলক রাতে', 67, 0, 'সূরা মুলক'],
    ['জুমার দিন সূরা কাহফ', 18, 0, 'সূরা কাহফ']
  ].map(function (a) { return { hay: fold(a[0]), s: a[1], a: a[2], t: a[3] }; });

  var SUGGEST = ['আয়াতুল কুরসি', 'সূরা কাহফ', 'ঘুমের দোয়া', 'রিযিক', 'যাকাত', '২:২৫৫', 'ক্ষমা', 'কিবলা'];
  var scope = 'all';

  /* ---------------- ফ্রেমের ডেটা ---------------- */
  function qWin() { var w = P() && P().frameWin('f1'); return w && w.QuranApp && w.QuranApp.SURAH_BN ? w : null; }
  function hWin() { var w = P() && P().frameWin('f2'); return w && w.HadithApp && w.HadithApp.BOOKS && w.HadithApp.bookDl ? w : null; }
  var surahHay = null;
  function surahs() {
    if (surahHay) return surahHay;
    var w = qWin(); if (!w) return null;
    var A = w.QuranApp;
    surahHay = A.SURAH_BN.map(function (n, i) { return { n: i + 1, bn: n, en: A.SURAH_EN[i] || '', hay: fold(n + ' ' + (A.SURAH_EN[i] || '')) }; });
    return surahHay;
  }

  /* ---------------- খোঁজা ---------------- */
  function findFeatures(tm, lim) { return FEATURES.filter(function (f) { return hit(f.hay, tm); }).slice(0, lim); }
  function findSurahs(raw, tm, lim) {
    var list = surahs(); if (!list) return null;
    var out = [], num = /^\d{1,3}$/.test(fold(raw)) ? +fold(raw) : 0;
    if (num >= 1 && num <= 114) out.push({ n: num, bn: list[num - 1].bn, en: list[num - 1].en, sc: 99 });
    var qq = tm.join('').replace(/^(সুরা|সুরাহ|surah|sura)/, '');
    if (qq.length >= 2) list.forEach(function (s) {
      var h = s.hay.replace(/^আল/, ''), sc = 0;
      if (h === qq || s.hay === qq) sc = 9; else if (h.indexOf(qq) === 0) sc = 6; else if (s.hay.indexOf(qq) > -1) sc = 3;
      if (sc && s.n !== num) out.push({ n: s.n, bn: s.bn, en: s.en, sc: sc });
    });
    out.sort(function (a, b) { return b.sc - a.sc || a.n - b.n; });
    return out.slice(0, lim);
  }
  function findAlias(tm) { var j = tm.join(''); if (j.length < 3) return []; return ALIAS.filter(function (a) { return a.hay.indexOf(j) > -1; }).slice(0, 2); }
  function findDuas(raw, lim) {
    if (!window.DuaEngine) return [];
    var r = DuaEngine.search(raw); return r.mode === 'empty' ? [] : r.items.slice(0, lim).map(function (x) { return x.d; });
  }
  var asmaHay = null;
  function findAsma(raw, tm, lim) {
    var A = window.PT_ASMA; if (!A) return [];
    if (!asmaHay) asmaHay = A.map(function (a) { return fold(a[1] + ' ' + a[2] + ' ' + a[0]); });
    var out = [];
    for (var i = 0; i < A.length && out.length < lim; i++) if (hit(asmaHay[i], tm)) out.push(i);
    return out;
  }
  function findAyahs(raw, lim) {
    var w = qWin(); if (!w || !w.QuranApp.FsUi || !w.QuranApp.FsUi.query) return null;
    try { return w.QuranApp.FsUi.query(raw, lim); } catch (e) { return null; }
  }

  /* আয়াতের লেখায় মেলা অংশ হাইলাইট (কুরআন ফ্রেমের নিজের spans) */
  function mark(text, r, mode, max) {
    text = String(text || '');
    var w = qWin(), FS = w && w.QuranApp.FastSearch, sp = [];
    try { if (FS && r.terms && r.terms.length) sp = FS.spans(text, r.terms, mode) || []; } catch (e) { sp = []; }
    var start = 0;
    if (sp.length && sp[0][0] > max * 0.4) start = Math.max(0, sp[0][0] - Math.round(max * 0.3));
    var end = Math.min(text.length, start + max), h = start > 0 ? '…' : '', pos = start;
    sp.forEach(function (s) {
      var a = Math.max(s[0], pos), b = Math.min(s[1], end); if (b <= a) return;
      h += esc(text.slice(pos, a)) + '<mark>' + esc(text.slice(a, b)) + '</mark>'; pos = b;
    });
    return h + esc(text.slice(pos, end)) + (end < text.length ? '…' : '');
  }

  /* ---------------- আঁকা ---------------- */
  function head(t, n, more) {
    return '<div class="gs-h"><span>' + esc(t) + '</span>' + (n ? '<em>' + n + '</em>' : '') + '<i></i>' +
      (more ? '<button type="button" class="gs-more" data-more="' + more + '">সব দেখুন</button>' : '') + '</div>';
  }
  function row(icon, t, s, data, extra) {
    return '<button type="button" class="gs-row" ' + data + '><span class="gs-ic">' + icon + '</span>' +
      '<span class="gs-tx"><span class="gs-t">' + t + '</span>' + (s ? '<span class="gs-s">' + s + '</span>' : '') + '</span>' + (extra || ic('forward', 'gs-chev')) + '</button>';
  }

  var pollT = 0;
  function render() {
    clearTimeout(pollT);
    var raw = q.value, tm = terms(raw);
    clr.hidden = !raw;
    if (!tm.length) { res.innerHTML = ''; res.hidden = true; idle.hidden = false; paintRecent(); return; }
    idle.hidden = true; res.hidden = false;
    var all = scope === 'all', L = all ? 4 : 30, h = '', any = false, waiting = false;

    var tail = '';
    if (all) {                                           /* নামে মিললে ফিচার উপরে; শুধু সমার্থক শব্দে মিললে সবার শেষে */
      var fs = findFeatures(tm, 3), tj = tm.join('');
      if (fs.length) {
        any = true;
        var fh = '<section class="gs-sec">' + head('অ্যাপে') + fs.map(function (f) { return row(ic(f.ic), esc(f.t), esc(f.s), 'data-go="' + f.go + '"'); }).join('') + '</section>';
        if (fs.some(function (f) { return fold(f.t).indexOf(tj) > -1; })) h += fh; else tail = fh;
      }
    }

    if (all || scope === 'quran') {
      var qh = '', al = findAlias(tm), ss = findSurahs(raw, tm, all ? 3 : 12), ay = findAyahs(raw, all ? 4 : 20);
      al.forEach(function (a) { qh += row('<b class="gs-num">' + bn(a.s) + '</b>', esc(a.t), a.a ? 'সূরা ' + bn(a.s) + ' · আয়াত ' + bn(a.a) : 'সূরা ' + bn(a.s), 'data-go="quran:' + a.s + ':' + a.a + '"'); });
      if (ss) ss.forEach(function (s) { if (al.some(function (a) { return a.s === s.n && !a.a; })) return; qh += row('<b class="gs-num">' + bn(s.n) + '</b>', 'সূরা ' + esc(s.bn), esc(s.en), 'data-go="quran:' + s.n + '"'); });
      if (ss === null) waiting = true;
      var ayh = '';
      if (ay && ay.items.length) {
        ay.items.forEach(function (it) {
          var bnTxt = it.bn ? '<span class="gs-s gs-tr">' + mark(it.bn, ay, 'bn', 120) + '</span>' : '';
          ayh += '<button type="button" class="gs-row gs-ayah" data-go="quran:' + it.s + ':' + it.a + '"><span class="gs-ic"><b class="gs-num">' + bn(it.s) + ':' + bn(it.a) + '</b></span>' +
            '<span class="gs-tx"><span class="gs-ref">সূরা ' + esc(it.name) + ' · আয়াত ' + bn(it.a) + '</span>' +
            '<span class="gs-ar" lang="ar" dir="rtl">' + mark(it.ar, ay, 'ar', 90) + '</span>' + bnTxt + '</span></button>';
        });
      }
      if (ay === null || (ay && !ay.ready && !ay.items.length)) waiting = true;
      var note = '';
      if (ay && !ay.trReady && /[ঀ-৿]/.test(raw) && !(ay.items && ay.items.length))
        note = '<p class="gs-note">' + ic('info', 'pt-ic--sm') + '<span>বাংলা অর্থে খুঁজতে কুরআন পেজ থেকে তরজমা একবার ডাউনলোড করে নিন — তারপর অফলাইনেই খোঁজা যাবে।</span></p>';
      if (qh || ayh || note) {
        any = any || !!(qh || ayh);
        h += '<section class="gs-sec">' + head('কুরআন', ay && ay.total > (ay.items || []).length ? bn(ay.total) + 'টি আয়াত' : '', ay && ay.total > (ay.items || []).length ? 'quran' : '') + qh + ayh + note + '</section>';
      }
    }

    if (all || scope === 'dua') {
      var du = findDuas(raw, L), as = findAsma(raw, tm, all ? 3 : 20), dh = '';
      du.forEach(function (d) { dh += row(ic('dua'), esc(d.t), esc(String(d.bn || '').slice(0, 90)) + (String(d.bn || '').length > 90 ? '…' : ''), 'data-go="dua:id:' + esc(d.id) + '"'); });
      as.forEach(function (i) { var a = window.PT_ASMA[i]; dh += row('<b class="gs-num">' + bn(i + 1) + '</b>', esc(a[1]) + ' <span class="gs-arn" lang="ar">' + esc(a[0]) + '</span>', 'আল্লাহর নাম · ' + esc(a[2]), 'data-go="dua:asma:' + (i + 1) + '"'); });
      if (dh) { any = true; h += '<section class="gs-sec">' + head('দোয়া ও আল্লাহর নাম') + dh + '</section>'; }
    }

    if (all || scope === 'hadith') {
      var hw = hWin(), hh = '';
      if (hw) {
        var books = hw.HadithApp.BOOKS.filter(function (b) { try { return hw.HadithApp.bookDl.isReady(b.id); } catch (e) { return false; } });
        books.forEach(function (b) { hh += row(ic('hadith'), esc(b.nameBn) + '-এ খুঁজুন', '“' + esc(raw.trim()) + '” · ' + bn(b.count) + 'টি হাদিসের ভেতরে', 'data-hb="' + esc(b.id) + '"'); });
        if (!books.length) hh = row(ic('download'), 'হাদিসে খুঁজতে কিতাব ডাউনলোড করুন', 'একবার নামালে পুরো কিতাবে অফলাইনেই খোঁজা যাবে', 'data-go="hadith"');
      } else { waiting = true; hh = row(ic('hadith'), 'হাদিসে খুঁজুন', 'হাদিসের পেজ প্রস্তুত হচ্ছে…', 'data-go="hadith"'); }
      h += '<section class="gs-sec">' + head('হাদিস') + hh + '</section>';
    }

    h += tail;
    if (!any && !waiting) h = '<div class="gs-empty pt-empty"><span class="pt-medal">' + ic('search') + '</span><div class="pt-empty__title">কিছু পাওয়া যায়নি</div><div class="pt-empty__text">অন্য শব্দে, আরবিতে বা আয়াত নম্বর (যেমন ২:২৫৫) লিখে দেখুন।</div></div>' + h;
    if (waiting) h += '<p class="gs-wait"><span class="pt-spinner"></span>কুরআন ও হাদিসের পেজ প্রস্তুত হচ্ছে…</p>';
    res.innerHTML = h;
    if (waiting) pollT = setTimeout(function () { if (ov.classList.contains('is-open')) render(); }, 700);
  }

  /* ---------------- সাম্প্রতিক ---------------- */
  var RK = 'pt_gs_recent';
  function recent() { try { var a = JSON.parse(localStorage.getItem(RK) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function remember(s) {
    s = String(s || '').trim(); if (!s) return;
    var a = recent().filter(function (x) { return x !== s; }); a.unshift(s);
    try { localStorage.setItem(RK, JSON.stringify(a.slice(0, 6))); } catch (e) {}
  }
  function chips(list, cls) { return list.map(function (s) { return '<button type="button" class="pt-chip ' + cls + '" data-q="' + esc(s) + '">' + esc(s) + '</button>'; }).join(''); }
  function paintRecent() {
    var r = recent(), box = $('gs-recent');
    $('gs-recent-wrap').hidden = !r.length;
    box.innerHTML = chips(r, 'gs-rc');
    $('gs-sugg').innerHTML = chips(SUGGEST, 'gs-sg');
  }

  /* ---------------- চাপ ---------------- */
  function openHadithBook(id, text) {
    window.__ptIn('f2', function (w) { return w.HadithApp && w.HadithApp.openBook && w.HadithApp.FsUi; }, function (w) {
      var A = w.HadithApp;
      if (A.curBookId !== id || !(A.state && A.state.view === 'book')) A.openBook(id);
      var t0 = Date.now();
      (function wait() {
        if (A.loadedBook && A.loadedBook.id === id) { A.FsUi.open(text); return; }
        if (Date.now() - t0 < 12000) setTimeout(wait, 200);
      })();
    });
  }
  function goSettings(id) {
    if (!P()) return;
    P().open('settings', $('btn-search'));
    setTimeout(function () { var el = $(id); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 480);
  }
  res.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    var raw = q.value.trim();
    if (b.hasAttribute('data-more')) {
      remember(raw);
      window.__ptIn('f1', function (w) { return w.QuranApp && w.QuranApp.FsUi; }, function (w) { w.QuranApp.FsUi.open(raw); });
      return;
    }
    if (b.hasAttribute('data-hb')) { remember(raw); openHadithBook(b.getAttribute('data-hb'), raw); return; }
    var g = b.getAttribute('data-go'); if (!g) return;
    e.stopPropagation();                                 /* 12-go.js-এর সাধারণ data-go হ্যান্ডলার যেন দুবার না চলে */
    remember(raw);
    try { q.blur(); } catch (er) {}
    if (g.indexOf('set:') === 0) return goSettings(g.slice(4));
    if (g === 'acc') { P() && P().home(); setTimeout(function () { window.__ptAccountOpen && window.__ptAccountOpen(); }, 360); return; }
    if (g === 'prem') { P() && P().home(); setTimeout(function () { window.ptOpenPremium && window.ptOpenPremium('search'); }, 360); return; }
    if (g === 'tile:8') { P() && P().home(); setTimeout(function () { var t = D.querySelectorAll('.module-grid .module-tile')[8]; if (t) t.click(); }, 360); return; }
    if (g === 'reminders') { P() && P().home(); setTimeout(function () { window.ptOpenReminders && window.ptOpenReminders(); }, 360); return; }
    window.__ptGo(g);
  });
  ov.addEventListener('click', function (e) {
    var c = e.target.closest ? e.target.closest('[data-q]') : null;
    if (c) { q.value = c.getAttribute('data-q'); render(); return; }
    if (e.target.closest && e.target.closest('#gs-recent-clear')) {
      /* v283: সাম্প্রতিক খোঁজ মোছার আগে নিশ্চিতকরণ */
      var doClear = function () { try { localStorage.removeItem(RK); } catch (er) {} paintRecent(); };
      if (window.PT && PT.dialog) PT.dialog({ icon: 'trash', title: 'সাম্প্রতিক খোঁজ মুছবেন?', body: 'আগের সব খোঁজের তালিকা মুছে যাবে।', ok: 'মুছে ফেলুন', cancel: 'থাক', danger: true }).then(function (y) { if (y) doClear(); }); else doClear();
    }
  });
  var raf = 0;
  q.addEventListener('input', function () { if (raf) return; raf = requestAnimationFrame(function () { raf = 0; render(); }); });
  q.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); remember(q.value); q.blur(); } });
  clr.addEventListener('click', function () { q.value = ''; render(); q.focus(); });
  if (scopeEl) {
    scopeEl.addEventListener('pt:change', function (e) { scope = ['all', 'quran', 'hadith', 'dua'][e.detail.index] || 'all'; render(); });
    scopeEl.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.pt-seg__btn') : null; if (!b) return;
      var i = Array.prototype.indexOf.call(scopeEl.querySelectorAll('.pt-seg__btn'), b);
      scope = ['all', 'quran', 'hadith', 'dua'][i] || 'all'; render();
    });
  }

  /* খোলা: হেডারের 🔍 বোতাম / __ptGo('search:লেখা') */
  window.ptOpenSearch = function (text) {
    if (!P()) return;
    surahHay = null;
    P().load('f1'); P().load('f2');                       /* সূরার নাম ও আয়াতের ইঞ্জিন কুরআন ফ্রেমে; কিতাবের তালিকা হাদিস ফ্রেমে */
    P().open('search', $('btn-search'));
    if (typeof text === 'string' && text) q.value = text;
    render();
    setTimeout(function () { try { q.focus(); if (q.value) q.select(); } catch (e) {} }, 380);
  };
  var btn = $('btn-search');
  if (btn) btn.addEventListener('click', function () { window.ptOpenSearch(); });
  paintRecent();
})();
