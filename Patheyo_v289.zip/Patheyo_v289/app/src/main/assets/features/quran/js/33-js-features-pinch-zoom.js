
/*!
 * js/features/pinch-zoom.js -- Pinch / double-tap zoom and pan for Mushaf pages
 *
 * Provides : App.bindZoom, App.pzBlocksSwipe, App.pzReset
 * Needs    : core/dom, features/mushaf-fullscreen, services/pdf-service
 */
(function (App) {
  "use strict";

  // ---- Pinch / double-tap zoom (fullscreen page viewer only) ----
  // Only the CURRENT page's canvas gets a CSS transform, so the swipe track, the three slots,
  // the buttons and the page-turn logic are untouched. Rules:
  //  * Double tap / double click: a simple toggle. At 1x it zooms to 2x; at ANY other zoom level
  //    (2x from a previous double-tap, or any level reached by pinching) it snaps back to 1x.
  //  * Two-finger pinch: any level between 1x and 8x, hard-capped at 8x (no zoom beyond it).
  //  * While zoomed in, one finger pans the page and page-swiping pauses; at 1x swiping is unchanged.
  //  * Once a zoom settles, the current page is re-rendered sharper OFFSCREEN and swapped in
  //    (no flash), within a memory budget; it goes back to normal size at 1x / on close.
  var PZ_MIN = 1, PZ_MAX = 8, PZ_DOUBLE_TAP_ZOOM = 2;

  var PZ_MAX_PIXELS = 6000000;   // v289: ৯M→৬M পিক্সেল — কম RAM-এর ফোনেও মসৃণ

 // canvas area budget for the sharpened render (memory safety)
  var pz = { scale:1, tx:0, ty:0, ptrs:{}, mode:null, g:null, pinch:null, pan:null,
             lastTap:null, raf:0, applyRaf:0, animTo:null, token:0, sharpTimer:0, sharpTask:null, retries:0 };

  function pzCount(){ var n = 0; for (var k in pz.ptrs){ if (pz.ptrs.hasOwnProperty(k)) n++; } return n; }

  function pzBlocksSwipe(){ return pz.scale > 1.001 || pzCount() >= 2; }
  App.pzBlocksSwipe = pzBlocksSwipe;

  function pzClamp(v, lo, hi){ return v < lo ? lo : (v > hi ? hi : v); }

  function pzBaseW(){ return Math.min((window.innerWidth || 400) * (window.devicePixelRatio || 1), 2000); }

  function pzCanvas(){ return App.getPfSlots().current; }

  function pzRel(x, y){ // client coords -> relative to the stage centre (the canvas is centred there)
    var r = App.els.pageStage.getBoundingClientRect();
    return { x: x - (r.left + r.width / 2), y: y - (r.top + r.height / 2) };
  }

  function pzBounds(s){
    var c = pzCanvas();
    var W = App.els.pageStage.clientWidth, H = App.els.pageStage.clientHeight;
    return { x: Math.max(0, (s * c.offsetWidth - W) / 2), y: Math.max(0, (s * c.offsetHeight - H) / 2) };
  }

  // v289: will-change সবসময় CSS-এ থাকে (লেয়ার বারবার তৈরি/ভাঙা হয় না) আর পিঞ্চ/প্যান-এর আপডেট ফ্রেম-প্রতি একবার আঁকা হয়
  function pzApplyNow(){
    if (pz.applyRaf){ cancelAnimationFrame(pz.applyRaf); pz.applyRaf = 0; }
    var c = pzCanvas();
    if (pz.scale <= 1.0005){
      pz.scale = 1; pz.tx = 0; pz.ty = 0;
      c.style.transform = '';
    } else {
      var b = pzBounds(pz.scale);
      pz.tx = pzClamp(pz.tx, -b.x, b.x);
      pz.ty = pzClamp(pz.ty, -b.y, b.y);
      c.style.transform = 'translate3d(' + pz.tx + 'px,' + pz.ty + 'px,0) scale(' + pz.scale + ')';
    }
  }
  function pzApply(){
    if (pz.applyRaf) return;
    pz.applyRaf = requestAnimationFrame(pzApplyNow);
  }

  function pzCancelAnim(){
    if (pz.raf){ cancelAnimationFrame(pz.raf); pz.raf = 0; }
    pz.animTo = null;
  }

  function pzAnimateZoom(s2, fx, fy){
    pzCancelAnim();
    var s1 = pz.scale, x1 = pz.tx, y1 = pz.ty, t0 = null, D = 240;
    pz.animTo = { s: s2 };
    function step(now){
      if (t0 === null) t0 = now;
      var p = Math.min(1, (now - t0) / D);
      var e = 1 - Math.pow(1 - p, 3);
      var s = s1 + (s2 - s1) * e;
      var k = s / s1;
      pz.scale = s;
      pz.tx = fx - k * (fx - x1); // keeps the point under the finger fixed while zooming
      pz.ty = fy - k * (fy - y1);
      pzApplyNow();
      if (p < 1){ pz.raf = requestAnimationFrame(step); }
      else { pz.raf = 0; pz.animTo = null; pzScheduleSharpen(); }
    }
    pz.raf = requestAnimationFrame(step);
  }

  function pzDoubleTap(cx, cy){
    var f = pzRel(cx, cy);
    var from = pz.animTo ? pz.animTo.s : pz.scale;
    var next = (from > 1.02) ? 1 : PZ_DOUBLE_TAP_ZOOM; // any non-1x level (double-tap OR pinch) -> back to original
    pzAnimateZoom(next, f.x, f.y);
  }

  function pzScheduleSharpen(){
    clearTimeout(pz.sharpTimer);
    pz.sharpTimer = setTimeout(pzSharpen, 300);
  }

  function pzSharpen(){
    pz.sharpTimer = 0;
    if (App.els.pageFullscreen.classList.contains('hidden')) return;
    var token = ++pz.token; // any newer request invalidates an older in-flight one
    if (pz.sharpTask){ try{ pz.sharpTask.cancel(); }catch(e){} pz.sharpTask = null; }
    var c = pzCanvas();
    if (!c.width || !c.offsetWidth) return;
    var base = pzBaseW();
    var want;
    if (pz.scale <= 1.001){
      want = base;
    } else {
      var aspect = (c.height / c.width) || 1.5;
      var cap = Math.min(4096, Math.floor(Math.sqrt(PZ_MAX_PIXELS / aspect)));
      want = c.offsetWidth * pz.scale * (window.devicePixelRatio || 1);
      want = Math.max(base, Math.min(cap, Math.ceil(want / 256) * 256));
    }
    var cur = c.width;
    if (pz.scale > 1.001 ? want <= cur * 1.2 : cur <= want * 1.1) return; // already good enough
    var n = App.pf.current;
    App.ensurePdfLoaded().then(function(doc){
      return doc.getPage(n);
    }).then(function(page){
      if (token !== pz.token) return;
      var native = page.getViewport({ scale: 1 });
      var vp = page.getViewport({ scale: want / native.width });
      var off = document.createElement('canvas');
      off.width = Math.floor(vp.width);
      off.height = Math.floor(vp.height);
      var offCtx = off.getContext('2d');
      var task = page.render({ canvasContext: offCtx, viewport: vp });
      pz.sharpTask = task;
      return task.promise.then(function(){
        if (pz.sharpTask === task) pz.sharpTask = null;
        if (App.pfBake) App.pfBake(offCtx, off.width, off.height);   // v289: থিমের রঙ বসানো
        if (token !== pz.token || App.pf.current !== n || App.els.pageFullscreen.classList.contains('hidden')) return;
        if (c.__renderTask){ // the normal render of this page is still running -> retry shortly
          if (pz.retries++ < 6){ pzScheduleSharpen(); }
          return;
        }
        c.width = off.width;
        c.height = off.height;
        c.getContext('2d').drawImage(off, 0, 0); // same task as the resize -> no blank flash
      });
    }).catch(function(){ /* sharpening is best-effort; zoom itself keeps working */ });
  }

  function pzReset(release){
    pzCancelAnim();
    clearTimeout(pz.sharpTimer); pz.sharpTimer = 0;
    pz.token++;
    if (pz.sharpTask){ try{ pz.sharpTask.cancel(); }catch(e){} pz.sharpTask = null; }
    pz.scale = 1; pz.tx = 0; pz.ty = 0;
    pz.ptrs = {}; pz.mode = null; pz.g = null; pz.pinch = null; pz.pan = null;
    pz.lastTap = null; pz.retries = 0;
    var c = pzCanvas();
    if (pz.applyRaf){ cancelAnimationFrame(pz.applyRaf); pz.applyRaf = 0; }
    c.style.transform = '';
    if (release && c.width > pzBaseW() * 1.1){ App.clearCanvas(c); } // free the big sharpened bitmap
  }
  App.pzReset = pzReset;
  App.pzRefresh = function(){ pz.retries = 0; if (pz.scale > 1.001) pzScheduleSharpen(); };

  function bindZoom(){
    var stage = App.els.pageStage;

    function twoPoints(){
      var ids = Object.keys(pz.ptrs);
      return [pz.ptrs[ids[0]], pz.ptrs[ids[1]]];
    }
    function dist(a, b){ var dx = a.x - b.x, dy = a.y - b.y; return Math.sqrt(dx * dx + dy * dy); }

    function startPinch(){
      pzCancelAnim();
      clearTimeout(pz.sharpTimer); pz.sharpTimer = 0;
      pz.retries = 0;
      var t = twoPoints(), a = t[0], b = t[1];
      pz.pinch = { d0: Math.max(dist(a, b), 10), s0: pz.scale, tx0: pz.tx, ty0: pz.ty,
                   m0: pzRel((a.x + b.x) / 2, (a.y + b.y) / 2) };
      pz.mode = 'pinch';
      pz.pan = null;
    }
    function movePinch(){
      var t = twoPoints(), a = t[0], b = t[1], k = pz.pinch;
      var m = pzRel((a.x + b.x) / 2, (a.y + b.y) / 2);
      var s = pzClamp(k.s0 * dist(a, b) / k.d0, PZ_MIN, PZ_MAX); // never above 8x
      pz.scale = s;
      pz.tx = m.x - s * (k.m0.x - k.tx0) / k.s0;
      pz.ty = m.y - s * (k.m0.y - k.ty0) / k.s0;
      pzApply();
    }

    stage.addEventListener('pointerdown', function(e){
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (App.pf.turning) return; // a page slide is in progress
      if (e.isPrimary){ // first finger down: forget any stale pointers
        pz.ptrs = {}; pz.pinch = null; pz.pan = null; pz.mode = null;
      }
      if (pzCount() >= 2) return; // ignore a third finger
      pz.ptrs[e.pointerId] = { x: e.clientX, y: e.clientY };
      try{ stage.setPointerCapture(e.pointerId); }catch(err){}
      var n = pzCount();
      if (n === 1){
        pz.g = { t0: Date.now(), x0: e.clientX, y0: e.clientY, moved: 0, multi: false };
        if (pz.scale > 1.001){
          pz.pan = { id: e.pointerId, x0: e.clientX, y0: e.clientY, tx0: pz.tx, ty0: pz.ty, started: false };
          pz.mode = 'pan';
        }
      } else if (n === 2){
        if (pz.g) pz.g.multi = true;
        if (App.pf.abortSwipe) App.pf.abortSwipe(); // cancel a half-made page swipe, then pinch
        startPinch();
      }
    });

    stage.addEventListener('pointermove', function(e){
      var p = pz.ptrs[e.pointerId];
      if (!p) return;
      p.x = e.clientX; p.y = e.clientY;
      if (pz.g){
        var ddx = e.clientX - pz.g.x0, ddy = e.clientY - pz.g.y0;
        var dd = Math.sqrt(ddx * ddx + ddy * ddy);
        if (dd > pz.g.moved) pz.g.moved = dd;
      }
      if (pz.mode === 'pinch' && pz.pinch && pzCount() === 2){
        e.preventDefault();
        movePinch();
      } else if (pz.mode === 'pan' && pz.pan && e.pointerId === pz.pan.id){
        var a = pz.pan;
        if (!a.started){
          if (Math.abs(e.clientX - a.x0) < 6 && Math.abs(e.clientY - a.y0) < 6) return; // tap slop
          a.started = true;
          pzCancelAnim();
          a.x0 = e.clientX; a.y0 = e.clientY; a.tx0 = pz.tx; a.ty0 = pz.ty;
        }
        e.preventDefault();
        pz.tx = a.tx0 + (e.clientX - a.x0);
        pz.ty = a.ty0 + (e.clientY - a.y0);
        pzApply();
      }
    });

    function onUp(e){
      if (!pz.ptrs[e.pointerId]) return;
      var cancelled = (e.type !== 'pointerup');
      delete pz.ptrs[e.pointerId];
      var left = pzCount();
      if (pz.mode === 'pinch' && left < 2){ // pinch finished
        pz.pinch = null;
        pz.mode = null;
        if (pz.scale <= 1.001){ pz.scale = 1; pzApplyNow(); }
        else if (left === 1){ // the remaining finger keeps panning
          var id = Object.keys(pz.ptrs)[0], q = pz.ptrs[id];
          pz.pan = { id: +id, x0: q.x, y0: q.y, tx0: pz.tx, ty0: pz.ty, started: true };
          pz.mode = 'pan';
        }
        pzScheduleSharpen();
      }
      if (left === 0){
        var g = pz.g;
        pz.g = null; pz.mode = null; pz.pan = null;
        var now = Date.now();
        if (!cancelled && g && !g.multi && g.moved <= 10 && (now - g.t0) < 400){
          var lt = pz.lastTap;
          if (lt && (now - lt.t) < 350 && Math.abs(e.clientX - lt.x) < 40 && Math.abs(e.clientY - lt.y) < 40){
            pz.lastTap = null;
            pzDoubleTap(e.clientX, e.clientY);
          } else {
            pz.lastTap = { t: now, x: e.clientX, y: e.clientY };
          }
        } else {
          pz.lastTap = null;
        }
      }
    }
    stage.addEventListener('pointerup', onUp);
    stage.addEventListener('pointercancel', onUp);
    stage.addEventListener('lostpointercapture', onUp);

    // iOS Safari: keep its own native pinch-zoom from fighting ours
    ['gesturestart', 'gesturechange', 'gestureend'].forEach(function(t){
      stage.addEventListener(t, function(e){ e.preventDefault(); });
    });

    window.addEventListener('resize', function(){
      if (App.els.pageFullscreen.classList.contains('hidden')) return;
      if (pz.scale > 1.001){ pzApplyNow(); pzScheduleSharpen(); }
    });
  }
  App.bindZoom = bindZoom;

})(window.QuranApp = window.QuranApp || {});

