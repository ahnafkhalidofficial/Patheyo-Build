/* দোয়া — মূল লজিক। ডেটা: 01-data.js (DUA_CATS, DUA_ITEMS)। আইকন: 01-icons.js। সার্চ: 02-engine.js। */
function ld(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
function sv(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
function $(id) { return document.getElementById(id); }

/* থিম: শেল (হোম) এই দুটো নামে থিম মেলায় — theme ভ্যারিয়েবল ও applyTheme() */
var theme = ld('dua_theme', (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light');
if (theme !== 'light' && theme !== 'dark' && theme !== 'sepia') theme = 'light';
function applyTheme() {
  document.documentElement.setAttribute('data-theme', theme);
  $('eye').classList.toggle('active', theme === 'sepia');       /* কুরআন/হাদিসের মতো: আই-কেয়ার চালু থাকলে 👁 জ্বলে */
  $('theme').classList.toggle('active', theme !== 'sepia');     /* আর লাইট/ডার্ক বাটন জ্বলে বাকি দুই মোডে */
}
$('theme').onclick = function () { theme = theme === 'light' ? 'dark' : 'light'; sv('dua_theme', theme); applyTheme(); };   /* সেপিয়া → লাইট → ডার্ক → লাইট */
$('eye').onclick = function () { theme = 'sepia'; sv('dua_theme', theme); applyTheme(); };
applyTheme();

/* লেখার সাইজ (px): শিরোনাম / আরবি / উচ্চারণ / অর্থ — প্রতিটা আলাদা। পপআপ (05-size-popup.js) এটি বদলায়। */
var DuaFS = (function () {
  var DEF = { t: 17, ar: 28, tr: 15, bn: 15 };
  var LIM = { t: [14, 28], ar: [20, 52], tr: [12, 28], bn: [12, 28] };
  var KEY = 'pt_dua_fs';
  function clamp(k, v) { v = Math.round(+v); if (isNaN(v)) v = DEF[k]; return Math.min(LIM[k][1], Math.max(LIM[k][0], v)); }
  function get() {
    var s = ld(KEY, null), o = {};
    if (!s) {                                              /* আগের সংস্করণের তিন-ধাপের সাইজ থাকলে সেটি থেকে নিই */
      var old = ld('pt_dua_size', null);
      s = old === 0 ? { ar: 24 } : old === 2 ? { ar: 34 } : {};
    }
    for (var k in DEF) o[k] = clamp(k, s[k] == null ? DEF[k] : s[k]);
    return o;
  }
  function paint(el, v) {
    el.style.setProperty('--fs-t', v.t + 'px'); el.style.setProperty('--fs-ar', v.ar + 'px');
    el.style.setProperty('--fs-tr', v.tr + 'px'); el.style.setProperty('--fs-bn', v.bn + 'px');
  }
  function save(v) { sv(KEY, v); }
  return { DEF: DEF, LIM: LIM, get: get, paint: paint, save: save, clamp: clamp };
})();
DuaFS.paint(document.documentElement, DuaFS.get());

(function () {
  var KEY_FAV = 'pt_dua_fav';
  var st = { cat: 'all', view: 'all', q: '', fav: ld(KEY_FAV, []), memo: ld('pt_asma_memo', false) };
  var ASMA = window.PT_ASMA || [];
  var catName = {}; DUA_CATS.forEach(function (c) { catName[c.id] = c.n; });

  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  var ICON_STAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.4l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.7l6-.8z"/></svg>';
  var ICON_COPY = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8.5" y="8.5" width="11" height="11" rx="2.6"/><path d="M15.5 8.5V6.6A2.1 2.1 0 0 0 13.4 4.5H6.6A2.1 2.1 0 0 0 4.5 6.6v6.8a2.1 2.1 0 0 0 2.1 2.1h1.9"/></svg>';
  var ICON_SHARE = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6.5" cy="12" r="2.3"/><circle cx="17.5" cy="6.5" r="2.3"/><circle cx="17.5" cy="17.5" r="2.3"/><path d="M8.5 10.9l7-3.3M8.5 13.1l7 3.3"/></svg>';
  var ICON_EDIT = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 19.5l1-4.2L16.4 4.4a1.9 1.9 0 0 1 2.7 0l.5.5a1.9 1.9 0 0 1 0 2.7L8.7 18.5z"/><path d="M14.5 6.4l3.1 3.1"/></svg>';
  var ICON_TRASH = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 7h15M9.5 7V5.2A1.2 1.2 0 0 1 10.7 4h2.6a1.2 1.2 0 0 1 1.2 1.2V7M6.5 7l.8 11.2A1.8 1.8 0 0 0 9.1 20h5.8a1.8 1.8 0 0 0 1.8-1.8L17.5 7M10 11v5M14 11v5"/></svg>';
  var ICON_BOOK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.2A2.2 2.2 0 0 1 7.2 3H19v15.5H7.2A2.2 2.2 0 0 0 5 20.7z"/><path d="M5 20.7A2.2 2.2 0 0 0 7.2 23H19v-4.5"/></svg>';

  function isFav(id) { return st.fav.indexOf(id) > -1; }
  function toggleFav(id) { var i = st.fav.indexOf(id); if (i > -1) st.fav.splice(i, 1); else st.fav.push(id); sv(KEY_FAV, st.fav); }

  var toastT = 0;
  function toast(m) { var t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, 1700); }
  window.DuaToast = toast;

  function visible() {
    var base = DUA_ITEMS;
    if (st.q.trim()) { var r = DuaEngine.search(st.q); base = r.mode === 'empty' ? DUA_ITEMS : r.items.map(function (x) { return x.d; }); }
    return base.filter(function (d) {
      if (st.view === 'fav' && !isFav(d.id)) return false;
      if (st.cat !== 'all' && d.cat !== st.cat) return false;
      return true;
    });
  }

  /* একটি দোয়া — বক্স নেই: শিরোনাম, আরবি, উচ্চারণ, অর্থ, তারপর রেফারেন্স ও ছোট আইকন-বাটন */
  function itemHtml(d, showLoc) {
    var f = isFav(d.id);
    return '<article class="ditem" data-id="' + esc(d.id) + '">' +
      (showLoc ? '<div class="dloc">' + DUA_ICON[d.cat] + '<span>' + esc(catName[d.cat]) + '</span></div>' : '') +
      '<div class="dhead"><div class="dt">' + esc(d.t) + '</div></div>' +
      '<div class="dar" lang="ar" dir="rtl">' + esc(d.ar) + '</div>' +
      (d.tr ? '<div class="dlb">উচ্চারণ</div><p class="dtr">' + esc(d.tr) + '</p>' : '') +
      (d.bn ? '<div class="dlb">অর্থ</div><p class="dbn">' + esc(d.bn) + '</p>' : '') +
      (d.note ? '<div class="dnote">' + esc(d.note) + '</div>' : '') +
      /* ধাপ ৬: রেফারেন্স, তারপর একই সারিতে প্রিয় · কপি · শেয়ার */
      '<div class="dfoot"><div class="dref">' + ICON_BOOK + '<span>' + esc(d.ref) + '</span></div>' +
      '<div class="dacts"><button class="dact dfav' + (f ? ' on' : '') + '" data-fav="' + esc(d.id) + '" aria-pressed="' + f + '" aria-label="' + (f ? 'প্রিয় থেকে সরান' : 'প্রিয় করুন') + '">' + ICON_STAR + '</button>' +
      '<button class="dact" data-copy="' + esc(d.id) + '" aria-label="কপি করুন">' + ICON_COPY + '</button>' +
      '<button class="dact" data-share="' + esc(d.id) + '" aria-label="শেয়ার কার্ড তৈরি করুন">' + ICON_SHARE + '</button>' +
      (d.u ? '<button class="dact" data-uedit="' + esc(d.uid) + '" aria-label="দোয়াটি সম্পাদনা করুন">' + ICON_EDIT + '</button>' +
             '<button class="dact" data-udel="' + esc(d.uid) + '" aria-label="দোয়াটি মুছুন">' + ICON_TRASH + '</button>' : '') + '</div></div>' +
      '</article>';
  }
  window.DuaItemHtml = itemHtml;          /* সাইজ-পপআপের প্রিভিউও একই কাঠামো ব্যবহার করে */

  function count(cat) { return DUA_ITEMS.filter(function (d) { return d.cat === cat; }).length; }

  function renderRail() {
    var h = '<button class="dch' + (st.cat === 'all' ? ' on' : '') + '" data-cat="all"><span class="dico">' + DUA_ICON.all + '</span><span>সব</span></button>';
    if (ASMA.length) h += '<button class="dch' + (st.cat === 'asma' ? ' on' : '') + '" data-cat="asma"><span class="dico">' + DUA_ICON.asma + '</span><span>আসমাউল হুসনা</span></button>';
    DUA_CATS.forEach(function (c) { h += '<button class="dch' + (st.cat === c.id ? ' on' : '') + '" data-cat="' + c.id + '"><span class="dico">' + DUA_ICON[c.id] + '</span><span>' + esc(c.n) + '</span></button>'; });
    /* শেষে "+" — নিজের পছন্দের দোয়া যোগ (প্রিমিয়াম); প্রিমিয়াম না থাকলে ছোট মুকুট-চিহ্ন */
    var pm = !(window.DuaCustomUI && window.DuaCustomUI.canAdd());
    h += '<button class="dch dadd' + (pm ? ' lock' : '') + '" id="dadd" type="button" aria-label="নিজের পছন্দের দোয়া যোগ করুন"><span class="dico">' + DUA_ICON.add + '</span><span>যোগ করুন</span>' +
         (pm ? '<i class="dpm" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3.5 8.5l4.6 4 3.9-6.3 3.9 6.3 4.6-4-1.7 10H5.2z"/></svg></i>' : '') + '</button>';
    $('rail').innerHTML = h;
  }
  function renderSeg() {
    var tabs = document.querySelectorAll('.dseg button'), i;
    for (i = 0; i < tabs.length; i++) tabs[i].setAttribute('aria-selected', tabs[i].getAttribute('data-v') === st.view ? 'true' : 'false');
    $('thumb').style.transform = 'translateX(' + (st.view === 'fav' ? 100 : 0) + '%)';
  }
  /* ---------- ধাপ ১১: আসমাউল হুসনা (shared/asma.js) ---------- */
  function asmaMatches(q) {
    var tm = DuaEngine.fold(q, true).t.split(/\s+/).filter(Boolean); if (!tm.length) return [];
    var num = /^\d+$/.test(tm[0]) && tm.length === 1 ? +tm[0] : 0;
    return ASMA.map(function (a, i) { return i; }).filter(function (i) {
      if (num) return i + 1 === num;
      var a = ASMA[i], hay = DuaEngine.fold(a[1] + ' ' + a[2] + ' ' + a[0], true).t;
      return tm.every(function (x) { return hay.indexOf(x) > -1; });
    });
  }
  function asmaRow(i) {
    var a = ASMA[i];
    return '<button type="button" class="asr' + (st.memo ? ' memo' : '') + '" data-asma="' + (i + 1) + '">' +
      '<span class="asr-n"><b>' + bn(i + 1) + '</b></span>' +
      '<span class="asr-ar" lang="ar" dir="rtl">' + esc(a[0]) + '</span>' +
      '<span class="asr-tx"><span class="asr-t">' + esc(a[1]) + '</span><span class="asr-m">' + esc(a[2]) + '</span></span></button>';
  }
  function asmaHtml() {
    var I = window.PT_ASMA_INTRO || {};
    return '<section class="asma" id="asma">' +
      '<div class="as-hero"><span class="as-star" aria-hidden="true">' + DUA_ICON.asma + '</span>' +
        '<div class="as-h">আসমাউল হুসনা</div><div class="as-s">আল্লাহর ৯৯টি সুন্দর নাম</div>' +
        '<p class="as-q">“' + esc(I.ayah || '') + '”<span>' + esc(I.ayahRef || '') + '</span></p>' +
        '<p class="as-q as-q2">' + esc(I.hadith || '') + '<span>' + esc(I.ref || '') + '</span></p>' +
        '<div class="as-tools"><button type="button" class="as-memo' + (st.memo ? ' on' : '') + '" id="as-memo" aria-pressed="' + st.memo + '">' +
          '<i></i><span>' + (st.memo ? 'মুখস্থ মোড চালু — নামে চাপ দিয়ে অর্থ দেখুন' : 'মুখস্থ মোড: অর্থ লুকিয়ে নিজেকে যাচাই করুন') + '</span></button>' +
          '<button type="button" class="as-copy" id="as-copy">সব কপি</button></div></div>' +
      '<div class="as-list">' + ASMA.map(function (a, i) { return asmaRow(i); }).join('') + '</div></section>';
  }
  function renderAsma(el) {
    $('cnt').textContent = bn(ASMA.length) + 'টি নাম';
    el.innerHTML = asmaHtml();
  }

  function renderList() {
    paintMode();
    var items = visible(), el = $('list');
    if (st.cat === 'asma' && st.view === 'all') {
      if (!st.q.trim()) { renderAsma(el); return; }
      var am = asmaMatches(st.q);
      $('cnt').textContent = bn(am.length) + 'টি নাম';
      el.innerHTML = am.length ? '<div class="as-list">' + am.map(asmaRow).join('') + '</div>' : '<div class="dempty"><b>কিছু পাওয়া যায়নি</b>নামের উচ্চারণ, অর্থ বা নম্বর লিখে খুঁজুন।</div>';
      return;
    }
    $('cnt').textContent = bn(items.length) + 'টি দোয়া' + (st.view === 'fav' ? ' (প্রিয়)' : '');
    if (!items.length && st.q.trim() && st.view === 'all' && st.cat === 'all' && asmaMatches(st.q).length) items = [];
    else if (!items.length) {
      el.innerHTML = st.view === 'fav' && !st.q && st.cat === 'all'
        ? '<div class="dempty"><b>এখনো কোনো প্রিয় দোয়া নেই</b>যেকোনো দোয়ার ☆ চাপলে সেটি এখানে জমা হবে।</div>'
        : '<div class="dempty"><b>কিছু পাওয়া যায়নি</b>অন্য শব্দে খুঁজুন অথবা অন্য অধ্যায় বেছে দেখুন।</div>';
      return;
    }
    var h = '';
    if (st.q.trim() || st.view === 'fav') {                /* সার্চ বা প্রিয় তালিকা: অধ্যায়ের নামসহ একটানা তালিকা */
      h = items.map(function (d) { return itemHtml(d, true); }).join('');
      var am2 = st.q.trim() && st.view === 'all' && st.cat === 'all' ? asmaMatches(st.q).slice(0, 6) : [];   /* ধাপ ১১: মেলে এমন আল্লাহর নামও */
      if (am2.length) h = '<div class="dloc as-loc">' + DUA_ICON.asma + '<span>আসমাউল হুসনা</span></div><div class="as-list as-list--q">' + am2.map(asmaRow).join('') + '</div>' + h;
    } else {                                               /* সাধারণ দেখা: অধ্যায় ধরে ধরে সাজানো */
      DUA_CATS.forEach(function (c) {
        var inCat = items.filter(function (d) { return d.cat === c.id; });
        if (!inCat.length) return;
        h += '<section class="dsecw" data-sec="' + c.id + '"><div class="dsec"><span class="dico">' + DUA_ICON[c.id] + '</span>' +
          '<div><div class="dsec-t">' + esc(c.n) + '</div><div class="dsec-n">' + bn(inCat.length) + 'টি দোয়া</div></div></div>' +
          inCat.map(function (d) { return itemHtml(d, false); }).join('') + '</section>';
      });
    }
    el.innerHTML = h;
  }
  function renderAll() { renderRail(); renderSeg(); renderList(); }
  /* ---------- অধ্যায়ের আলাদা পেজ ----------
     মূল পেজে শুধু আইকনের গ্রিড (সার্চ করলে বা প্রিয় ট্যাবে তালিকা); আইকনে চাপলে সেই অধ্যায়ের সব দোয়াসহ নতুন পেজ খোলে।
     পেজের হেডারে পেছনে-বাটন, অধ্যায়ের আইকন ও নাম; ফুটার (নিচের ট্যাব বার) হোম শেলেরই — আগের মতো থাকে।
     ইতিহাসে এক ধাপ ঢোকে ({dcat}), তাই ফোনের Back চাপলে মূল গ্রিডে ফেরে আর আগের স্ক্রোল জায়গা মনে থাকে। */
  var pageCat = null, mainY = 0, animT = 0, root = document.documentElement;
  function catMeta(cat) {
    if (cat === 'all') return { n: 'সব দোয়া', ic: DUA_ICON.all, sub: bn(DUA_ITEMS.length) + 'টি দোয়া' };
    if (cat === 'asma') return { n: 'আসমাউল হুসনা', ic: DUA_ICON.asma, sub: bn(ASMA.length) + 'টি নাম' };
    return { n: catName[cat] || '', ic: DUA_ICON[cat] || '', sub: bn(count(cat)) + 'টি দোয়া' };
  }
  function paintHead() {
    if (pageCat === null) return;
    var m = catMeta(pageCat);
    $('dcatMark').innerHTML = m.ic; $('dcatT').textContent = m.n; $('dcatS').textContent = m.sub;
  }
  function paintMode() {
    var open = pageCat !== null, idle = !open && !st.q.trim() && st.view === 'all';
    root.classList.toggle('dcat-open', open);
    root.classList.toggle('dcat-one', open && pageCat !== 'all' && pageCat !== 'asma');
    root.classList.toggle('dmain-idle', idle);
    root.classList.toggle('dmain-list', !open && !idle);
  }
  function openCat(cat) {
    if (cat !== 'all' && cat !== 'asma' && !DUA_CATS.some(function (c) { return c.id === cat; })) cat = 'all';
    var was = pageCat !== null;
    if (!was) mainY = window.pageYOffset || 0;
    st.view = 'all'; st.q = ''; qEl.value = ''; qx.classList.remove('show');
    st.cat = cat; pageCat = cat;
    try { if (was) history.replaceState({ dcat: cat }, ''); else history.pushState({ dcat: cat }, ''); } catch (e) {}
    renderAll(); paintHead(); window.scrollTo(0, 0);
    root.classList.add('dcat-anim'); clearTimeout(animT); animT = setTimeout(function () { root.classList.remove('dcat-anim'); }, 340);
  }
  function exitCat() {
    if (pageCat === null) return;
    pageCat = null; st.cat = 'all'; renderAll(); window.scrollTo(0, mainY || 0);
  }
  function closeCat() {
    if (pageCat === null) return false;
    if (history.state && history.state.dcat) history.back(); else exitCat();
    return true;
  }
  window.addEventListener('popstate', function () { if (pageCat !== null && !(history.state && history.state.dcat)) exitCat(); });
  /* v261: হেডারে আর আলাদা পেছনে-বাটন নেই — মোবাইলের ব্যাক বাটনই কাজ করে (নিচের __ptFrameBack) */
  /* Android Back: আগে খোলা পপআপ (tool-back.js), তারপর এই পেজ */
  (function () { var prev = window.__ptFrameBack; window.__ptFrameBack = function () { if (typeof prev === 'function' && prev()) return true; return closeCat(); }; })();
  window.DuaMain = { select: openCat, rerail: renderRail };
  function setSub() { $('hsub').innerHTML = bn(DUA_ITEMS.length) + 'টি দোয়া<span class="h1-long"> · ' + bn(DUA_CATS.length) + 'টি অধ্যায়</span>'; }
  window.addEventListener('duacustom', function () {      /* নিজের দোয়া যোগ/বদল/মোছা */
    catName = {}; DUA_CATS.forEach(function (c) { catName[c.id] = c.n; });
    if (pageCat !== null && pageCat !== 'all' && pageCat !== 'asma' && !DUA_CATS.some(function (c) { return c.id === pageCat; })) {
      pageCat = null; st.cat = 'all'; if (history.state && history.state.dcat) history.back(); window.scrollTo(0, mainY || 0);   /* এই অধ্যায়ের দোয়া মুছে গেছে → মূল গ্রিডে ফেরা */
    }
    setSub(); renderAll(); paintHead();
  });

  function find(id) { for (var i = 0; i < DUA_ITEMS.length; i++) if (DUA_ITEMS[i].id === id) return DUA_ITEMS[i]; return null; }
  function textOf(d) { return d.t + '\n\n' + d.ar + '\n\nউচ্চারণ: ' + d.tr + '\n\nঅর্থ: ' + d.bn + '\n\n(' + d.ref + ')'; }
  function copyText(s, done) {
    function fallback() {
      try {
        var ta = document.createElement('textarea'); ta.value = s; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
        document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, s.length);
        var ok = document.execCommand('copy'); document.body.removeChild(ta); done(ok);
      } catch (e) { done(false); }
    }
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(s).then(function () { done(true); }, fallback); return; } } catch (e) {}
    fallback();
  }

  $('list').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    var id;
    if (b.id === 'as-memo') {                                /* মুখস্থ মোড: অর্থ লুকানো, নামে চাপলে দেখা যায় */
      st.memo = !st.memo; sv('pt_asma_memo', st.memo); renderList(); toast(st.memo ? 'অর্থ লুকানো হলো — নামে চাপ দিয়ে মিলিয়ে দেখুন' : 'সব অর্থ দেখা যাচ্ছে'); return;
    }
    if (b.id === 'as-copy') {
      var all = ASMA.map(function (a, i) { return bn(i + 1) + '. ' + a[0] + ' — ' + a[1] + ' (' + a[2] + ')'; }).join('\n');
      copyText('আসমাউল হুসনা — আল্লাহর ৯৯টি নাম\n\n' + all, function (ok) { toast(ok ? '৯৯টি নাম কপি হয়েছে' : 'কপি করা যায়নি'); }); return;
    }
    if (b.hasAttribute('data-asma')) {
      if (b.classList.contains('memo')) { b.classList.toggle('show'); if (window.PT && PT.haptic) PT.haptic('light'); }
      return;
    }
    if ((id = b.getAttribute('data-uedit'))) { if (window.DuaCustomUI) window.DuaCustomUI.openEdit(id); return; }
    if ((id = b.getAttribute('data-udel'))) { if (window.DuaCustomUI) window.DuaCustomUI.askDelete(id); return; }
    if ((id = b.getAttribute('data-fav'))) {
      toggleFav(id);
      if (st.view === 'fav') { renderList(); toast('প্রিয় থেকে সরানো হয়েছে'); }
      else { var on = isFav(id); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); b.setAttribute('aria-label', on ? 'প্রিয় থেকে সরান' : 'প্রিয় করুন'); toast(on ? 'প্রিয় দোয়ায় যোগ হয়েছে' : 'প্রিয় থেকে সরানো হয়েছে'); }
    } else if ((id = b.getAttribute('data-copy'))) {
      var d = find(id); if (d) copyText(textOf(d), function (ok) { toast(ok ? 'দোয়াটি কপি হয়েছে' : 'কপি করা যায়নি'); });
    } else if ((id = b.getAttribute('data-share'))) {
      var s = find(id); if (s && window.PtShareCard) window.PtShareCard.open({ kind: 'dua', title: s.t, ar: s.ar, tr: s.tr, bn: s.bn, ref: s.ref });
    }
  });
  $('rail').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    if (b.id === 'dadd') { if (window.DuaCustomUI) window.DuaCustomUI.openAdd(); return; }
    openCat(b.getAttribute('data-cat'));
  });
  Array.prototype.forEach.call(document.querySelectorAll('.dseg button'), function (b) {
    b.addEventListener('click', function () { st.view = b.getAttribute('data-v'); if (st.view === 'fav') st.cat = 'all'; renderAll(); window.scrollTo(0, 0); });
  });
  var qEl = $('q'), qx = $('qx');
  qEl.addEventListener('input', function () { st.q = qEl.value; qx.classList.toggle('show', !!qEl.value); renderList(); });
  qx.addEventListener('click', function () { qEl.value = ''; st.q = ''; qx.classList.remove('show'); renderList(); qEl.focus(); });
  qEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); qEl.blur(); } });

  /* জুম বাটন → লেখার সাইজ পপআপ */

  /* পূর্ণ-পর্দা সার্চ থেকে একটি দোয়ায় যাওয়া: ফিল্টার মুছে সেই দোয়ায় স্ক্রোল করে একটু জ্বালিয়ে দেখায় */
  function reveal(id, cat, mark) {
    var item = id && cat !== 'asma' ? find(id) : null;
    openCat(cat === 'asma' ? 'asma' : (item ? item.cat : (cat || 'all')));
    if (cat === 'asma' && id) {                              /* ধাপ ১১: নির্দিষ্ট নাম (নম্বর) */
      var row = document.querySelector('.asr[data-asma="' + String(id).replace(/\D/g, '') + '"]');
      if (row) {
        window.scrollTo(0, Math.max(0, row.getBoundingClientRect().top + (window.pageYOffset || 0) - 120));
        row.classList.add('show'); row.classList.remove('dflash'); void row.offsetWidth; row.classList.add('dflash');
        setTimeout(function () { row.classList.remove('dflash'); }, 2000);
      }
      return;
    }
    if (!item) return;
    var el = document.querySelector('.ditem[data-id="' + id + '"]');
    if (!el) return;
    var y = el.getBoundingClientRect().top + (window.pageYOffset || 0) - 96;
    window.scrollTo(0, Math.max(0, y));
    el.classList.remove('dflash'); void el.offsetWidth; el.classList.add('dflash');
    setTimeout(function () { el.classList.remove('dflash'); }, 2000);
    /* v325: ঘুম/সকাল-সন্ধ্যার আমলে এলে এই দোয়াটি হলুদ মার্কারে থেকে যায় (পরের বার অন্য দোয়া মার্ক হলে আগেরটা যায়) */
    Array.prototype.forEach.call(document.querySelectorAll('.ditem.dmark'), function (m) { m.classList.remove('dmark'); });
    if (mark) el.classList.add('dmark');
  }
  window.DuaApp = { reveal: reveal };

  setSub();   /* ছোট ফোনে শুধু "৫০টি দোয়া" (STD_HEADER) */
  renderAll();
})();
