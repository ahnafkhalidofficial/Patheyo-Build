
/*!
 * js/features/lists.js -- Sura list and Para list rendering
 *
 * Provides : App.renderParaList, App.renderSuraList, App.renderTarjamaList
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/para-meta, data/surah-meta,
               features/para-choice, features/sura-reader, features/tarjama-reader
 */
(function (App) {
  "use strict";

  // একই সূরা-সারি (হুবহু একই ডিজাইন) তিলাওয়াত করুন ও তরজমা পড়ুন -- দুই জায়গাতেই ব্যবহার হয়
  // ৮ কোণের তারা (রুব-এল-হিজবের নকশা) -- সূরার ক্রমিক নম্বরের পেছনে
  var STAR_SVG = '<svg viewBox="0 0 48 48" focusable="false"><path class="sr-star" d="M24 2.5l5.4 5.7 7.7-1.2 1.2 7.7 5.7 5.4-4.4 6.4 4.4 6.4-5.7 5.4-1.2 7.7-7.7-1.2L24 45.5l-5.4-5.7-7.7 1.2-1.2-7.7-5.7-5.4L8.4 21 4 14.6l5.7-5.4 1.2-7.7 7.7 1.2z"/></svg>';

  function renderSuraRows(container, onOpen){
    var frag = document.createDocumentFragment();
    App.quranModel.forEach(function(sura){
      var en = App.SURAH_EN[sura.index-1] || '';
      var bnName = App.SURAH_BN[sura.index-1] || '';
      var madani = App.isMadani(sura.index), ruku = App.SURAH_RUKU[sura.index-1] || 0;
      var place = madani ? 'মাদানী' : 'মাক্কী';
      var row = document.createElement('div');
      row.className = 'list-item sura-row';
      row.setAttribute('data-name', sura.name + ' ' + en + ' ' + bnName + ' ' + place + (madani ? ' madani medinan' : ' makki meccan'));
      row.setAttribute('data-index', sura.index);
      row.innerHTML =
        '<div class="sr-no" aria-hidden="true">' + STAR_SVG + '<span>' + App.bn(sura.index) + '</span></div>' +
        '<div class="sr-main">' +
          '<div class="sr-bn">' + bnName + '</div>' +
          '<div class="sr-en">' + en + '</div>' +
          '<div class="sr-meta">' +
            '<span class="sr-place ' + (madani ? 'sr-madani' : 'sr-makki') + '">' + place + '</span>' +
            '<span class="sr-dot"></span><span class="sr-stat">' + App.bn(sura.ayahs.length) + ' আয়াত</span>' +
            '<span class="sr-dot"></span><span class="sr-stat">' + App.bn(ruku) + ' রুকু</span>' +
          '</div>' +
        '</div>' +
        '<div class="sr-ar">' + App.surahGlyph(sura.index, 'sg-list sg-row') + '</div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(idx){
        return function(){ onOpen(idx); };
      }(sura.index));
      frag.appendChild(row);
    });
    container.appendChild(frag);
  }

  function renderSuraList(){ renderSuraRows(App.els.suraList, function(idx){ App.openReader(idx); }); }
  App.renderSuraList = renderSuraList;

  function renderTarjamaList(){ renderSuraRows(App.els.trList, function(idx){ App.openTarjamaReader(idx); }); }
  App.renderTarjamaList = renderTarjamaList;

  function renderParaList(){
    var frag = document.createDocumentFragment();
    for (var p=1; p<=30; p++){
      var start = App.JUZ_START[p-1];
      var startSura = App.quranModel[start[0]-1];
      var row = document.createElement('div');
      row.className = 'list-item';
      row.setAttribute('data-name', startSura.name);
      row.setAttribute('data-index', p);
      row.innerHTML =
        '<div class="li-badge">' + App.bn(p) + '</div>' +
        '<div class="li-name-block">' +
          '<div class="li-name-en">পারা ' + App.bn(p) + '</div>' +
          '<div class="li-sub">শুরু: সূরা ' + App.bn(start[0]) + ', আয়াত ' + App.bn(start[1]) + '</div>' +
        '</div>' +
        '<div class="li-arabic">' + App.surahGlyph(startSura.index, 'sg-list') + '</div>' +
        '<div class="li-name-bn">' + (App.SURAH_BN[startSura.index-1]||'') + '</div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(idx){
        return function(){ App.openParaChoice(idx); };
      }(p));
      frag.appendChild(row);
    }
    App.els.paraList.appendChild(frag);
  }
  App.renderParaList = renderParaList;

})(window.QuranApp = window.QuranApp || {});

