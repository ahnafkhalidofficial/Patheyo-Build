/* =============================================================================
   v276 — দান (ডোনেশন)
   খোলে: হেডারের সোনালি হৃদয় (#btn-donate), হোমের কার্ড, সেটিংসের সারি — যেকোনো [data-donate] বাটন,
          অথবা  window.ptOpenDonate(from)
   নেটিভ: PatheyoPremium.donate(req, amount, method) → সার্ভার (server/payments → /donate/create) পেমেন্ট পেজ খোলে
          (বিকাশ · নগদ · রকেট · ব্যাংক/কার্ড — এখন SSLCommerz-এর মাধ্যমে; পরে আলাদা গেটওয়ে যোগ করলেও এই পপআপই থাকবে)
   ফেরত: patheyo://pay?…&kind=donate → 11-premium.js-এর __ptPayReturn → ptDonateReturn()
   গোপনীয়তা: সাইন-ইন লাগে না; নাম, নম্বর, ইমেইল কিছুই নেওয়া বা পাঠানো হয় না — শুধু অঙ্ক ও পছন্দের পদ্ধতি।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window;
  var sheet = D.getElementById('dn-sheet'); if (!sheet) return;
  var $ = function (s) { return sheet.querySelector(s); };
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(x) { return String(x).replace(/\d/g, function (d) { return BN[d]; }); }
  function toast(t, type, o) { if (W.PT) PT.toast(t, Object.assign({ type: type || '' }, o || {})); }
  var MIN = 10, MAX = 100000, amount = 100, method = 'bkash', busy = false, info = null;
  try { var last = JSON.parse(localStorage.getItem('pt_dn_last') || '{}'); if (last.m) method = last.m; if (last.a) amount = last.a; } catch (e) {}

  function P() { return W.PatheyoPremium || null; }
  /* নেটিভের উত্তর আসে __ptPremiumCb দিয়ে (11-premium.js-এর সাথে ভাগ) — নিজের id হলে এখানে ধরি, বাকিটা আগের হ্যান্ডলারে */
  var seq = 0, pend = {}, base = W.__ptPremiumCb;
  W.__ptPremiumCb = function (id, json) {
    var f = pend[id]; if (!f) return base && base(id, json);
    delete pend[id]; var r; try { r = JSON.parse(json); } catch (e) { r = { ok: false }; } f(r);
  };
  function call(fn) {
    var args = [].slice.call(arguments, 1);
    return new Promise(function (res) {
      var p = P(); if (!p || typeof p[fn] !== 'function') { res({ ok: false, code: 'na', msg: 'ডোনেশন শুধু অ্যাপের ভেতর থেকে করা যায়।' }); return; }
      var id = 'dn' + (++seq); pend[id] = res;
      try { p[fn].apply(p, [id].concat(args)); } catch (e) { delete pend[id]; res({ ok: false, msg: 'কাজটি সম্পন্ন করা যায়নি' }); }
    });
  }

  function cur() {
    if (amount !== 'other') return amount;
    var v = Math.round(Number(($('#dn-other-in') || {}).value || 0)); return v || 0;
  }
  function paint() {
    [].forEach.call(sheet.querySelectorAll('.dn-amt'), function (b) {
      var a = b.getAttribute('data-amt'); b.setAttribute('aria-checked', String(a === String(amount)));
    });
    $('#dn-other').hidden = amount !== 'other';
    [].forEach.call(sheet.querySelectorAll('.dn-m'), function (b) { b.setAttribute('aria-checked', String(b.getAttribute('data-m') === method)); });
    var v = cur(), cta = $('#dn-cta');
    cta.textContent = v >= MIN ? '৳' + bn(v.toLocaleString('en-IN')) + ' ডোনেট করুন' : 'পরিমাণ লিখুন';
    cta.disabled = !(v >= MIN && v <= MAX);
  }
  function view(v) { sheet.setAttribute('data-view', v); }

  W.ptOpenDonate = function (from) {
    if (!W.PT) return;
    view('give');
    if ([50, 100, 200, 500, 1000].indexOf(amount) < 0 && amount !== 'other') { var x = amount; amount = 'other'; setTimeout(function () { var i = $('#dn-other-in'); if (i) { i.value = x; paint(); } }, 0); }
    paint(); PT.sheet.open(sheet);
    if (!info) call('donateInfo').then(function (r) { if (r && r.ok) { info = r; MIN = r.min || MIN; MAX = r.max || MAX; $('#dn-test').hidden = !r.sandbox; paint(); } });
    try { localStorage.setItem('pt_dn_open', JSON.stringify({ from: from || '', at: Date.now() })); } catch (e) {}
  };

  sheet.addEventListener('click', function (e) {
    if (e.target.closest('[data-dn-close]')) { PT.sheet.close(sheet); return; }
    if (e.target.closest('[data-dn-again]')) { view('give'); paint(); return; }
    var a = e.target.closest('.dn-amt');
    if (a) {
      var v = a.getAttribute('data-amt'); amount = v === 'other' ? 'other' : Number(v); paint();
      if (amount === 'other') setTimeout(function () { var i = $('#dn-other-in'); i && i.focus(); }, 60);
      if (W.PT && PT.haptic) PT.haptic('light'); return;
    }
    var m = e.target.closest('.dn-m');
    if (m) { method = m.getAttribute('data-m'); paint(); if (W.PT && PT.haptic) PT.haptic('light'); }
  });
  $('#dn-other-in').addEventListener('input', paint);
  $('#dn-other-in').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('#dn-cta').click(); });

  $('#dn-cta').addEventListener('click', function () {
    var cta = this, v = cur(); if (busy || cta.disabled) return;
    if (v < MIN || v > MAX) { toast('ডোনেশনের পরিমাণ ৳১০ থেকে ৳১,০০,০০০-এর মধ্যে দিন', 'danger'); return; }
    busy = true; cta.classList.add('is-loading');
    try { localStorage.setItem('pt_dn_last', JSON.stringify({ a: v, m: method })); } catch (e) {}
    call('donate', v, method).then(function (r) {
      busy = false; cta.classList.remove('is-loading');
      if (r.ok && r.opened) toast('পেমেন্ট পেজ খোলা হয়েছে — পেমেন্ট শেষে অ্যাপে ফিরে আসুন');
      else toast(r.msg || 'পেমেন্ট পেজ খোলা যায়নি', 'danger');
    });
  });

  /* পেমেন্ট থেকে ফেরত (11-premium.js ডাকে) */
  W.ptDonateReturn = function (r) {
    if (r.status === 'success') {
      var amt = Number(r.amount) || 0;
      D.getElementById('dn-thx-p').textContent = (amt ? '৳' + bn(amt.toLocaleString('en-IN')) + ' ডোনেশন সফলভাবে পৌঁছেছে। ' : 'আপনার ডোনেশন সফলভাবে পৌঁছেছে। ') + 'আল্লাহ কবুল করুন এবং আপনাকে উত্তম প্রতিদান দিন।';
      view('thanks'); if (sheet.hidden && W.PT) PT.sheet.open(sheet);
      if (W.PT && PT.haptic) PT.haptic('success');
    } else if (r.status === 'cancelled') toast('ডোনেশন বাতিল করা হয়েছে');
    else toast('ডোনেশন সম্পন্ন হয়নি — টাকা কেটে থাকলে কিছুক্ষণের মধ্যে স্বয়ংক্রিয়ভাবে ঠিক হয়ে যাবে', 'danger', { ms: 6000 });
  };

  D.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-donate]'); if (!b || sheet.contains(b)) return;
    W.ptOpenDonate(b.getAttribute('data-donate'));
  });
})();
