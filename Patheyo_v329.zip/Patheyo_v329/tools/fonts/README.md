# বাংলা ফন্ট (Noto Serif Bengali + ব্র্যান্ডের বাংলা সংখ্যা)

অ্যাপ ও ওয়েবসাইটের সব বাংলা লেখা **Noto Serif Bengali**-এ, আর বাংলা সংখ্যা (০-৯) **Gunjoron ব্র্যান্ড ফন্টে**।
দুটো একটাই ফাইলে মেশানো — `NotoSerifBengaliPatheyo-*.ttf` — তাই সব জায়গায় (WebView, নেটিভ স্ক্রিন, উইজেট,
নোটিফিকেশন, শেয়ার-কার্ড) একই রকম দেখায় এবং কোনো ফন্ট ইন্টারনেট থেকে আনতে হয় না।

## মেলানো (harmonisation)
* Noto-র অক্ষরের আউটলাইন অপরিবর্তিত; শুধু unitsPerEm 1000 → 1170, যাতে Noto-র মাত্রা-রেখা ব্র্যান্ড ফন্টের মাত্রা-রেখার
  সাথে হুবহু মেলে — লেখা আগের মাপেই থাকে, লেআউট নড়ে না।
* লাইন-মেট্রিক (ascent 972 / descent −350) ব্র্যান্ড ফন্টের মতোই — তাই line-height, উইজেটের অবস্থান আগের মতোই।
* বাংলা সংখ্যা Noto-র বেসলাইন ও মাত্রা-রেখায় বসানো; ওজন মেলানো: Light→Thin, Regular/Medium→Normal, SemiBold/Bold/ExtraBold→Bold
  (SemiBold ফাইলটি wght 640-এ বানানো, যাতে Bold সংখ্যার সাথে স্ট্রোক মেলে)।
* ইংরেজি অক্ষর/চিহ্ন ব্র্যান্ড ফন্টেরই (হুবহু আগের মতো)।

## ফাইল
| ওজন (CSS) | ফাইল |
|---|---|
| 100–349 | NotoSerifBengaliPatheyo-Light |
| 350–449 | NotoSerifBengaliPatheyo-Regular |
| 450–549 | NotoSerifBengaliPatheyo-Medium |
| 550–649 | NotoSerifBengaliPatheyo-SemiBold |
| 650–749 | NotoSerifBengaliPatheyo-Bold |
| 750–900 | NotoSerifBengaliPatheyo-ExtraBold |

* অ্যাপ (WebView + নেটিভ): `app/src/main/assets/fonts/NotoSerifBengaliPatheyo-*.ttf`
* উইজেট/ডেট-কার্ড: `res/font/bangla_serif_regular|bold.ttf` · নোটিফিকেশন: `res/font/bangla_serif_bn.xml` (শুধু বাংলা)
* ওয়েবসাইট: `patheyo/fonts/NotoSerifBengaliPatheyo-BN-*.woff2` (শুধু বাংলা অক্ষর)
* CSS-এ পরিবারের নাম আগের মতোই (`GunjoronFont`, `GunjoronDigits`, সাইটে `Gunjoron`) — তাই কোনো পেজের CSS বদলাতে হয়নি।

## আবার বানাতে
```
pip install fonttools brotli
python3 tools/fonts/build_fonts.py tools/fonts/src/NotoSerifBengali-VF.ttf app/src/main/assets/fonts out/
```
লাইসেন্স: Noto Serif Bengali — SIL Open Font License 1.1 (`src/LICENSE-NotoSerifBengali-OFL.txt`)।
