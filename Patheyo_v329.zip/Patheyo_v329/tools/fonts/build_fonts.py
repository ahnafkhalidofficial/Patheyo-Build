#!/usr/bin/env python3
"""
Patheyo Bangla fonts builder.

Builds "Noto Serif Bengali Patheyo": Noto Serif Bengali (OFL) for every Bengali
letter/sign + the brand font (Gunjoron) for Bengali digits ০-৯ (and, in the
"full" variant, the brand font's Latin/punctuation so native Android text keeps
its brand English exactly as before).

Harmonisation:
  * Noto outlines are kept untouched; only unitsPerEm is changed (1000 -> 1170) so
    Noto's matra lands exactly on the brand font's matra (same optical size as before).  Result: Bengali text keeps the same optical size the whole UI was
    tuned for, and brand digits sit exactly on Noto's baseline and headline.
  * Brand digits are scaled 622/531 so they sit exactly on Noto's baseline and reach
    Noto's matra/headline; brand Latin is copied 1:1 (unchanged look).
  * Brand digit weight per Noto weight (matched by stem weight):
    300 -> Thin, 400/500 -> Normal, 600/700/800 -> Bold.
    The SemiBold face is instanced at wght 640 so its stems meet the brand Bold digits
    (the app has always treated 600 as 'bold').

usage: build_fonts.py <NotoSerifBengali-VF.ttf> <gunjoron-dir> <out-dir>
"""
import sys, os
from fontTools.ttLib import TTFont, newTable
from fontTools.varLib import instancer
from fontTools import subset
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.recordingPen import DecomposingRecordingPen

VF, GJ_DIR, OUT = sys.argv[1:4]
os.makedirs(OUT, exist_ok=True)

# Noto's matra/headline is 622u (of 1000); the brand font's matra is 621u (of 1170).
# Re-declaring Noto at 1170 UPM (outlines untouched) puts both matras on the same line
# and gives Bengali letters the same optical size the whole UI was designed with.
NEW_UPM = 1170
GJ_UPM = 1170
LATIN_SCALE = NEW_UPM / GJ_UPM  # = 1.0 → brand Latin unchanged
DIGIT_SCALE = 622 / 621         # brand digits sit on Noto's baseline and reach Noto's matra
# Line metrics: keep the brand font's (so every line-height / widget layout stays as tuned)
ASC, DESC = 972, -350
WIN_ASC, WIN_DESC = 1100, 470    # covers Noto's tall i-kar/reph and deep conjuncts

FAMILY = "Noto Serif Bengali Patheyo"
PS_FAMILY = "NotoSerifBengaliPatheyo"
WEIGHTS = [  # css weight, style name, brand file used for the Bengali digits
    (300, "Light", "Gunjoron-Font-Thin.ttf"),
    (400, "Regular", "Gunjoron-Font-Normal.ttf"),
    (500, "Medium", "Gunjoron-Font-Normal.ttf"),
    (600, "SemiBold", "Gunjoron-Font-Bold.ttf"),
    (700, "Bold", "Gunjoron-Font-Bold.ttf"),
    (800, "ExtraBold", "Gunjoron-Font-Bold.ttf"),
]

INSTANCE = {600: 640}
BN_DIGITS = list(range(0x09E6, 0x09F0))
# Bengali text range that must come from Noto (shaping-relevant)
NOTO_KEEP = [c for c in range(0x0980, 0x0A00) if c not in BN_DIGITS] + \
            [0x0964, 0x0965, 0x200C, 0x200D, 0x25CC]
BN_ONLY_UNICODES = list(range(0x0980, 0x0A00)) + [0x0964, 0x0965, 0x200C, 0x200D, 0x25CC, 0x20, 0xA0]


def subset_font(font, unicodes, keep_names=True):
    opts = subset.Options()
    opts.layout_features = ["*"]
    opts.name_IDs = ["*"]
    opts.name_languages = ["*"]
    opts.hinting = False
    opts.notdef_outline = True
    opts.glyph_names = False
    opts.drop_tables += ["STAT", "meta", "vhea", "vmtx", "DSIG"]
    opts.layout_scripts = ["*"]
    s = subset.Subsetter(opts)
    s.populate(unicodes=unicodes)
    s.subset(font)
    return font


def copy_glyph(src, src_name, dst, dst_name, scale):
    gs = src.getGlyphSet()
    pen = TTGlyphPen(None)
    rec = DecomposingRecordingPen(gs)
    gs[src_name].draw(rec)  # decomposes composites
    rec.replay(TransformPen(pen, (scale, 0, 0, scale, 0, 0)))
    glyph = pen.glyph()
    dst["glyf"][dst_name] = glyph
    adv = round(src["hmtx"][src_name][0] * scale)
    glyph.recalcBounds(dst["glyf"])
    lsb = glyph.xMin if glyph.numberOfContours != 0 else 0
    dst["hmtx"][dst_name] = (adv, lsb)


def build(weight, style, brand_file):
    vf = TTFont(VF)
    noto = instancer.instantiateVariableFont(vf, {"wght": INSTANCE.get(weight, weight), "wdth": 100}, updateFontNames=False)
    # keep only Bengali (+ the joiners/dotted circle) from Noto
    subset_font(noto, NOTO_KEEP + [0x20, 0xA0])
    noto["head"].unitsPerEm = NEW_UPM
    hh, o2 = noto["hhea"], noto["OS/2"]
    hh.ascent, hh.descent, hh.lineGap = ASC, DESC, 0
    o2.sTypoAscender, o2.sTypoDescender, o2.sTypoLineGap = ASC, DESC, 0
    o2.usWinAscent, o2.usWinDescent = WIN_ASC, WIN_DESC

    gj_dig = TTFont(os.path.join(GJ_DIR, brand_file))
    # Latin keeps the app's existing brand mapping: <600 Normal, >=600 Bold
    gj_lat = TTFont(os.path.join(GJ_DIR, "Gunjoron-Font-Bold.ttf" if weight >= 600 else "Gunjoron-Font-Normal.ttf"))
    gj_cmap = gj_lat.getBestCmap()
    brand_cps = [c for c in gj_cmap if c in BN_DIGITS or not (0x0980 <= c <= 0x09FF or c in (0x0964, 0x0965, 0x200C, 0x200D, 0x25CC))]
    dig_cmap = gj_dig.getBestCmap()

    order = list(noto.getGlyphOrder())
    new_map = {}
    made = {}
    for cp in sorted(brand_cps):
        sname = gj_cmap[cp] if cp not in BN_DIGITS else "DIG:" + dig_cmap[cp]
        if sname in made:
            new_map[cp] = made[sname]
            continue
        dname = "gj." + sname.replace("DIG:", "dig.")
        order.append(dname)
        made[sname] = dname
        new_map[cp] = dname
    noto.setGlyphOrder(order)
    noto["glyf"].glyphOrder = order
    for sname, dname in made.items():
        if sname.startswith("DIG:"):
            copy_glyph(gj_dig, sname[4:], noto, dname, DIGIT_SCALE)
        else:
            copy_glyph(gj_lat, sname, noto, dname, LATIN_SCALE)

    # cmap: brand glyphs win for digits/Latin
    for t in noto["cmap"].tables:
        if t.isUnicode():
            for cp, g in new_map.items():
                if t.format == 4 and cp > 0xFFFF:
                    continue
                t.cmap[cp] = g
    # make sure a format-12 table is not missing anything (and format 4 exists)
    # GDEF: mark new glyphs as base glyphs
    if "GDEF" in noto and noto["GDEF"].table.GlyphClassDef:
        cd = noto["GDEF"].table.GlyphClassDef.classDefs
        for g in made.values():
            cd[g] = 1

    # Latin kerning from the brand font is not carried over (native Latin text is short UI labels).

    # --- naming / metadata ---
    name = noto["name"]
    full = f"{FAMILY} {style}" if style != "Regular" else f"{FAMILY} Regular"
    ps = f"{PS_FAMILY}-{style}"
    legacy_family = FAMILY if style in ("Regular", "Bold") else f"{FAMILY} {style}"
    legacy_sub = "Bold" if style == "Bold" else "Regular"
    for rec in list(name.names):
        if rec.nameID in (1, 2, 3, 4, 6, 16, 17, 21, 22, 25):
            name.removeNames(nameID=rec.nameID)
    name.setName(legacy_family, 1, 3, 1, 0x409)
    name.setName(legacy_sub, 2, 3, 1, 0x409)
    name.setName(f"{ps};Patheyo", 3, 3, 1, 0x409)
    name.setName(full, 4, 3, 1, 0x409)
    name.setName(ps, 6, 3, 1, 0x409)
    name.setName(FAMILY, 16, 3, 1, 0x409)
    name.setName(style, 17, 3, 1, 0x409)
    desc = ("Noto Serif Bengali (SIL OFL 1.1, The Noto Project Authors) for Bengali text, "
            "with Patheyo/Gunjoron brand glyphs for Bengali digits and Latin. Built for the Patheyo app.")
    name.setName(desc, 10, 3, 1, 0x409)
    os2 = noto["OS/2"]
    os2.usWeightClass = weight
    os2.usWidthClass = 5
    bold = style == "Bold"
    os2.fsSelection = (os2.fsSelection & ~0b1100001) | (0b100000 if bold else 0b1000000)
    os2.fsSelection |= 1 << 7  # USE_TYPO_METRICS
    noto["head"].macStyle = 1 if bold else 0
    os2.achVendID = "PTHY"
    # unicode ranges/codepage bits
    os2.recalcUnicodeRanges(noto)
    os2.recalcCodePageRanges(noto)
    noto["post"].formatType = 3.0
    noto["post"].extraNames = []
    noto["post"].mapping = {}
    for t in ("fpgm", "prep", "cvt ", "hdmx", "LTSH", "VDMX"):
        if t in noto:
            del noto[t]
    if "gasp" in noto:
        noto["gasp"].gaspRange = {0xFFFF: 0x000F}
    noto["head"].flags &= ~(1 << 3)

    full_path = os.path.join(OUT, f"{PS_FAMILY}-{style}.ttf")
    noto.save(full_path)

    # Bengali-only variant (website / notifications)
    bn = TTFont(full_path)
    subset_font(bn, BN_ONLY_UNICODES)
    bn.save(os.path.join(OUT, f"{PS_FAMILY}-BN-{style}.ttf"))
    bn.flavor = "woff2"
    bn.save(os.path.join(OUT, f"{PS_FAMILY}-BN-{style}.woff2"))
    return full_path


for w, st, bf in WEIGHTS:
    p = build(w, st, bf)
    print("built", p)
