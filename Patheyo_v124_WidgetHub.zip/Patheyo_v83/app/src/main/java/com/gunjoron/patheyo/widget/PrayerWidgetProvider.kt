package com.gunjoron.patheyo.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle

/**
 * হোমস্ক্রিন উইজেটের প্রবেশদ্বার (ম্যানিফেস্টের একমাত্র উইজেট-রিসিভার)।
 *
 * কাজ ভাগ:
 *  • আঁকা ও টিক-অ্যালার্ম  → [WidgetUpdater] (নতুন উইজেট হাব: ৯ ডিজাইন, ক্যানভাস-বিটম্যাপ)
 *  • তথ্য (সময়, হিজরি, বার্তা) → [com.gunjoron.patheyo.widget.data.Snapshot] (অ্যাপের আগের ডেটা-সিস্টেম থেকে)
 *  • ডেটা-রিফ্রেশ অ্যালার্ম/WorkManager → [WidgetRefreshScheduler]
 *
 * এই ক্লাসের companion-এর নাম ও কী-গুলো অ্যাপের বাকি অংশ (নোটিফিকেশন, আজান, ফায়ারবেজ) ব্যবহার করে — তাই অপরিবর্তিত।
 */
class PrayerWidgetProvider : AppWidgetProvider() {

    companion object {
        /** নামাজের সময় ও হিজরি তারিখের SharedPreferences ফাইল — পুরো অ্যাপের একই উৎস */
        const val PREFS_NAME = "ibadat_widget_prefs"
        const val KEY_TIMINGS = "timings_json"

        /** সব উইজেটকে রিফ্রেশের ব্রডকাস্ট পাঠায় (সিস্টেম নিজে সাথে সাথে onUpdate চালায়) */
        fun updateAllWidgets(context: Context) {
            val appContext = context.applicationContext
            val mgr = AppWidgetManager.getInstance(appContext)
            val ids = mgr.getAppWidgetIds(ComponentName(appContext, PrayerWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                appContext.sendBroadcast(
                    Intent(appContext, PrayerWidgetProvider::class.java).apply {
                        action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                        putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    }
                )
            }
        }

        /** ব্রডকাস্ট ছাড়াই সরাসরি আঁকা (কখনো ক্র্যাশ propagate করে না) */
        fun updateWidgetDirectly(context: Context) {
            try { WidgetUpdater.updateAll(context.applicationContext) } catch (_: Throwable) { /* পরের টিকে ঠিক হবে */ }
        }
    }

    /**
     * অ্যালার্ম/ব্রডকাস্ট ফায়ার হলে। onReceive মেইন থ্রেডে ও ~১০ সেকেন্ডের মধ্যে শেষ হতে হয়, তাই
     * goAsync() + ব্যাকগ্রাউন্ড থ্রেড; কাজ শেষে finish()।
     *  • REFRESH_ACTION   → "হার্ড রিসেট" (সব অ্যালার্ম নতুন করে সেট + দরকারে ডেটা-ফেচ + আঁকা)
     *  • ACTION_TICK      → মিনিটের টিক / ওয়াক্ত-বদল: শুধু আবার আঁকা
     *  • USER_PRESENT     → ফোন আনলক: ডিজাইন ৬-এর সূর্য-অ্যানিমেশন
     */
    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)
        val ctx = context?.applicationContext ?: return
        val action = intent?.action ?: return
        val job: Runnable = when (action) {
            WidgetRefreshScheduler.REFRESH_ACTION -> Runnable {
                WidgetRefreshScheduler.hardReset(ctx)
                try {
                    // নোটিফিকেশন সিস্টেমের স্বাধীন অতিরিক্ত নিরাপত্তা-স্তর
                    com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(ctx)
                } catch (_: Throwable) { /* উইজেট চেইনের সাথে সম্পর্কহীন */ }
            }
            WidgetUpdater.ACTION_TICK -> Runnable { WidgetUpdater.updateAll(ctx) }
            Intent.ACTION_USER_PRESENT -> Runnable { WidgetUpdater.playUnlockAnim(ctx) }
            else -> return
        }
        val pending = try { goAsync() } catch (_: Throwable) { null }
        val safe = Runnable {
            try { job.run() } catch (_: Throwable) { /* কোনো অবস্থাতেই এখান থেকে ক্র্যাশ নয় */ }
            finally { try { pending?.finish() } catch (_: Throwable) {} }
        }
        if (pending != null) {
            try { Thread(safe, "patheyo-widget-work").start() } catch (_: Throwable) { safe.run() }
        } else safe.run()
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // শিডিউল সবার আগে — নিচের আঁকায় কিছু ভুল হলেও পরের রিফ্রেশ অ্যালার্ম সেট থাকে
        try { WidgetRefreshScheduler.scheduleAll(context) } catch (_: Throwable) {}
        try { WidgetUpdater.update(context, appWidgetManager, appWidgetIds) } catch (_: Throwable) {}
    }

    /** ইউজার উইজেট ছোট/বড় করলে নতুন মাপ অনুযায়ী আবার আঁকা */
    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        try { WidgetUpdater.update(context, appWidgetManager, intArrayOf(appWidgetId)) } catch (_: Throwable) {}
    }

    /** শেষ উইজেটটা সরালে অ্যালার্মও বাতিল (অকারণ ওয়েকআপ নয়) */
    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        try { WidgetRefreshScheduler.cancelAll(context) } catch (_: Throwable) {}
        try { WidgetUpdater.cancel(context) } catch (_: Throwable) {}
    }

    /** উইজেট প্রথমবার যোগ হলে সব শিডিউল সেট */
    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        try { WidgetRefreshScheduler.scheduleAll(context) } catch (_: Throwable) {}
    }
}
