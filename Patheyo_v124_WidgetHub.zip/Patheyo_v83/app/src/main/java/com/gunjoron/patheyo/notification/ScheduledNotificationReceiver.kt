package com.gunjoron.patheyo.notification

// app/src/main/java/com/gunjoron/Patheyo/notification/ScheduledNotificationReceiver.kt
//
// ScheduledNotificationScheduler থেকে স্কেজুল্ড নোটিফিকেশন রিসিভ করে দেখায়

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScheduledNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // ✅ FIX #NEW: Doze-প্রতিরোধী হার্টবিট — WorkManager throttle হলেও এটা চলতে থাকে,
        // তাই অ্যাপ না খুললেও প্রতিদিনের নোটিফিকেশন ঠিক সময়ে schedule হতেই থাকবে।
        if (intent.action == ScheduledNotificationScheduler.ACTION_HEARTBEAT) {
            ScheduledNotificationScheduler.scheduleAllNotifications(context)
            ScheduledNotificationScheduler.scheduleHeartbeat(context) // চেইন চালু রাখা
            return
        }
        if (intent.action == ScheduledNotificationScheduler.ACTION_SCHEDULED) {
            val title = intent.getStringExtra("title") ?: "নোটিফিকেশন"
            val message = intent.getStringExtra("message") ?: ""
            val type = intent.getStringExtra("type") ?: ""
            val link = intent.getStringExtra("link") ?: ""
            val image = intent.getStringExtra("image") ?: ""

            // BroadcastReceiver-এর সীমিত সময়ের (~১০ সেকেন্ড) মধ্যে ছবি ডাউনলোডের জন্য
            // goAsync() ব্যবহার করা হচ্ছে, যাতে system এই রিসিভারকে সময়ের আগে বন্ধ না করে
            val pendingResult = goAsync()
            ScheduledNotificationScheduler.showNotification(
                context = context,
                title = title,
                message = message,
                link = link,
                image = image,
                onDone = { pendingResult.finish() }
            )

            // যেকোনো নোটিফিকেশন ফায়ার হওয়ার পর পুরো তালিকা আবার যাচাই করে পরবর্তী
            // প্রাসঙ্গিক অকারেন্সের জন্য (পরের সপ্তাহ/মাস/বছর) রি-শিডিউল করা হচ্ছে
            ScheduledNotificationScheduler.scheduleAllNotifications(context)
        }
    }
}
