package com.gunjoron.patheyo.alarm

// app/src/main/java/com/gunjoron/Patheyo/alarm/AzanForegroundService.kt

import android.app.*
import android.content.*
import android.media.*
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.*
import android.view.KeyEvent
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.gunjoron.patheyo.R

// ✅ v48: (১) "আজান বন্ধ করুন"/"স্নুজ" চাপলে সাউন্ড সাথে সাথে বন্ধ (stopAudioNow + AzanActionReceiver), (২) ভলিউম বাটন চাপলে শুধু সাউন্ড বন্ধ —
//   পপআপ থাকে, রিপিট বহাল (silenceSound; ভলিউম-পোলিং + MediaSession VolumeProvider + পপআপের কী-ইভেন্ট), (৩) অ্যান্ড্রয়েড ১২+ এ সিস্টেমের ডিফল্ট
//   নোটিফিকেশন (গোল লোগো + দুই বাটন), ১১ ও নিচে কাস্টম পপআপ, (৪) নতুন চ্যানেল AzanChannel।
// ✅ v45: স্নুজ ও অটো-রিপিট (AzanRepeat) + নতুন গ্লাস ডিজাইনের নোটিফিকেশন-বার পপআপ (হেডস-আপ) — দুই বাটন: "আজান বন্ধ করুন" ও "স্নুজ"।
//  - ACTION_STOP  → আজান বন্ধ + পরের সব রিপিট বাতিল
//  - ACTION_SNOOZE → আজান বন্ধ + বাটন চাপার সময় থেকে ঠিক ১০ মিনিট পরে আবার আজান (সর্বোচ্চ ৩ বার)
//  - কোনো বাটন না চাপলে আজান শেষ হলে পপআপ সরে যায়, আর শুরুতেই বসানো রিপিট ১০ মিনিট পরে বাজে।
class AzanForegroundService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var fallbackRingtone: Ringtone? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // এই আজানের ওয়াক্ত-কী ও কত নম্বর আজান (১/২/৩)
    private var currentWaqt: String? = null
    private var currentRing: Int = 1
    private var mediaSession: MediaSession? = null
    private var wakeLock: PowerManager.WakeLock? = null

    // ভলিউম-বাটন ধরার জন্য: আজান চলাকালীন ভলিউম বদলালে (বাটন চাপলে) সাউন্ড বন্ধ
    private var silenced = false
    private var watchSince = 0L
    private val volBase = intArrayOf(-1, -1)

    companion object {
        const val CHANNEL_ID = AzanChannel.ID
        const val NOTIF_ID = 7711
        const val ACTION_STOP = "com.gunjoron.patheyo.ACTION_STOP_AZAN"
        const val ACTION_SNOOZE = "com.gunjoron.patheyo.ACTION_SNOOZE_AZAN"

        /** সাউন্ড চুপ করানোর পর পপআপ/নোটিফিকেশন সর্বোচ্চ এত সময় থাকবে (পরের রিপিট ১০ মিনিটে) */
        private const val SILENT_LINGER_MS = 5 * 60 * 1000L

        /** আজান এই মুহূর্তে চলছে কিনা — ফুল-স্ক্রীন পপআপ এটা দেখে আজান শেষ হলে নিজে বন্ধ হয় */
        @Volatile var isRunning: Boolean = false
            private set

        @Volatile private var instance: AzanForegroundService? = null

        private fun onMain(block: () -> Unit) {
            if (Looper.myLooper() == Looper.getMainLooper()) block() else Handler(Looper.getMainLooper()).post { block() }
        }

        /** "আজান বন্ধ করুন": সাউন্ড তৎক্ষণাৎ বন্ধ + রিপিট বাতিল। সার্ভিস চালু থাকলে true */
        fun requestStop(ctx: Context): Boolean {
            val s = instance
            if (s == null) { AzanRepeat.cancelAll(ctx); return false }
            onMain { s.doStop() }
            return true
        }

        /** "স্নুজ": সাউন্ড তৎক্ষণাৎ বন্ধ + ১০ মিনিট পর আবার। সার্ভিস চালু থাকলে true */
        fun requestSnooze(ctx: Context, waqt: String?, ring: Int): Boolean {
            val s = instance
            if (s == null) { AzanRepeat.scheduleNext(ctx, waqt, ring); return false }
            onMain { s.doSnooze(waqt, ring) }
            return true
        }

        /** ভলিউম বাটন: শুধু সাউন্ড বন্ধ — পপআপ ও রিপিট যেমন ছিল তেমনই থাকে */
        fun silenceNow(): Boolean {
            val s = instance ?: return false
            onMain { s.silenceSound() }
            return true
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // "আজান বন্ধ করুন": আজান থামে এবং পরের সব রিপিট বাতিল — এই ওয়াক্তে আর বাজবে না
            doStop()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SNOOZE) {
            // "স্নুজ": এখনকার বসানো রিপিট মুছে বাটন চাপার সময় থেকে ঠিক ১০ মিনিট পরের জন্য নতুন করে বসানো
            val waqt = intent.getStringExtra("waqt") ?: currentWaqt
            val ring = intent.getIntExtra(AzanRepeat.EXTRA_RING, currentRing)
            doSnooze(waqt, ring)
            return START_NOT_STICKY
        }

        val waqt = intent?.getStringExtra("waqt") ?: "নামাজ"
        val waqtName = waqtBnLabel(waqt)
        currentWaqt = waqt
        currentRing = (intent?.getIntExtra(AzanRepeat.EXTRA_RING, 1) ?: 1).coerceIn(1, AzanContent.MAX_RINGS)
        isRunning = true
        silenced = false
        mainHandler.removeCallbacks(lingerStop)

        // অটো-রিপিট: কোনো বাটন না চাপলে ১০ মিনিট পরে পরের আজান (৩য় আজানের পর আর নয়)।
        // শুরুতেই বসিয়ে রাখা হয়, যাতে আজান চলাকালীন অ্যাপ/প্রসেস মরে গেলেও রিপিট হারায় না।
        AzanRepeat.scheduleNext(this, waqt, currentRing)

        // ✅ v44: প্রতিটা ধাপ আলাদা সুরক্ষিত — আগে যেকোনো একটা ধাপে (যেমন কাস্টম নোটিফিকেশন ইনফ্লেট, MediaSession)
        // exception হলে সার্ভিস ক্র্যাশ করত আর আজান একদমই বাজত না। এখন নোটিফিকেশন/মিডিয়া-সেশন ব্যর্থ হলেও আজান বাজবেই।
        try { AzanChannel.ensure(this) } catch (_: Throwable) {}

        // সার্ভিস চালু থাকা অবস্থায় CPU যেন না ঘুমায় (সর্বোচ্চ ১০ মিনিট, তারপর নিজে ছাড়বে)
        try {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Patheyo:AzanService")
                wakeLock?.acquire(10 * 60 * 1000L)
            }
        } catch (_: Throwable) {}

        try {
            startForeground(NOTIF_ID, buildCustomNotification(waqtName))
        } catch (_: Throwable) {
            // কাস্টম ডিজাইনের নোটিফিকেশনে সমস্যা হলে সাধারণ নোটিফিকেশন দিয়ে ফোরগ্রাউন্ডে যাওয়া
            try { startForeground(NOTIF_ID, buildSimpleNotification(waqtName)) } catch (_: Throwable) {}
        }

        try { setupMediaSession() } catch (_: Throwable) {}
        playAzan()
        return START_NOT_STICKY
    }

    private fun setupMediaSession() {
        mediaSession = MediaSession(this, "AzanSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    val keyEvent = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                    if (keyEvent?.action == KeyEvent.ACTION_DOWN) {
                        when (keyEvent.keyCode) {
                            KeyEvent.KEYCODE_VOLUME_DOWN,
                            KeyEvent.KEYCODE_VOLUME_UP,
                            KeyEvent.KEYCODE_HEADSETHOOK,
                            KeyEvent.KEYCODE_MEDIA_STOP -> {
                                silenceSound()
                                return true
                            }
                        }
                    }
                    return super.onMediaButtonEvent(mediaButtonIntent)
                }
                override fun onStop() { silenceSound() }
                override fun onPause() { silenceSound() }
            })

            // ভলিউম বাটন: সক্রিয় মিডিয়া-সেশনের রিমোট ভলিউম হিসেবে নিবন্ধিত — ফোন ভলিউম-কী এখানে পাঠালে সাউন্ড বন্ধ।
            // (ভলিউম আগে থেকেই সর্বোচ্চ থাকলেও চাপ ধরা পড়ে। সব ফোন এই পথে কী পাঠায় না, তাই নিচের ভলিউম-পোলিংও আছে।)
            try {
                setPlaybackToRemote(object : android.media.VolumeProvider(android.media.VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
                    override fun onAdjustVolume(direction: Int) { if (direction != 0) mainHandler.post { silenceSound() } }
                    override fun onSetVolumeTo(volume: Int) { mainHandler.post { silenceSound() } }
                })
            } catch (_: Throwable) {}

            setPlaybackState(
                PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_STOP or PlaybackState.ACTION_PLAY_PAUSE)
                    .setState(PlaybackState.STATE_PLAYING, 0, 1f)
                    .build()
            )
            isActive = true
        }
    }


    private var audioFocusRequest: AudioFocusRequest? = null

    // ✅ FIX #2: পুরনো/দুর্বল ফোনে "আজান বাজে না" সমস্যার সবচেয়ে সম্ভাব্য কারণগুলো এখানে ঠিক করা হলো:
    //  ১) prepare() সিঙ্ক্রোনাস কল, ধীরগতির স্টোরেজ/CPU-তে ব্যর্থ/ধীর হতে পারে, তাই ব্যতিক্রম ঘটলে
    //     আগে একদম নীরবে থেমে যেত — এখন prepareAsync() + OnErrorListener দিয়ে ব্যর্থ হলে সিস্টেমের
    //     ডিফল্ট অ্যালার্ম রিংটোন দিয়ে ফলব্যাক চালানো হয়, যাতে অন্তত কোনো শব্দ বাজে।
    //  ২) অনেক ফোনে "Alarm volume" স্ট্রিম আলাদা করে মিউট করা থাকে (ব্যবহারকারী নিজেও জানেন না),
    //     ফলে USAGE_ALARM দিয়ে বাজালেও শব্দ শোনা যায় না — এখন ভলিউম ০ পেলে একটা শ্রবণযোগ্য
    //     মাত্রায় বাড়িয়ে দেওয়া হয়।
    //  ৩) AudioFocus রিকোয়েস্ট করা হচ্ছে যাতে অন্য অ্যাপের সাউন্ড/DND এর সাথে দ্বন্দ্ব কম হয়।
    private fun playAzan() {
        try {
            // আগের কোনো প্লেয়ার চালু থাকলে (দ্বিতীয়বার ট্রিগার) আগে ছেড়ে দেওয়া, যাতে দুটো আজান একসাথে না বাজে
            mediaPlayer?.let { try { it.release() } catch (_: Throwable) {} }
            mediaPlayer = null
            val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            am?.let {
                val current = it.getStreamVolume(AudioManager.STREAM_ALARM)
                if (current <= 0) {
                    val max = it.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                    val target = (max * 0.6f).toInt().coerceAtLeast(1)
                    try { it.setStreamVolume(AudioManager.STREAM_ALARM, target, 0) } catch (_: Exception) {}
                }
            }

            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

            if (am != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(attrs).build()
                try { am.requestAudioFocus(audioFocusRequest!!) } catch (_: Exception) {}
            } else {
                try { am?.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT) } catch (_: Exception) {}
            }

            val afd = assets.openFd("azan.mp3")
            mediaPlayer = MediaPlayer().apply {
                // ওয়াক লক ব্যবহার করা হলো যাতে ফোন স্লিপ মোডে গেলেও আজান না থামে
                setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                setAudioAttributes(attrs)
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = false
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ ->
                    playFallbackAlarmSound()
                    true
                }
                setOnPreparedListener { it.start() }
                prepareAsync() // ধীরগতির/পুরনো ডিভাইসে ব্লক না করার জন্য অ্যাসিঙ্ক প্রিপেয়ার
            }
            startVolumeWatch()
        } catch (e: Exception) {
            // কাস্টম azan.mp3 চালাতে না পারলেও ইউজার যেন সম্পূর্ণ নীরব না থাকেন —
            // সিস্টেমের ডিফল্ট অ্যালার্ম শব্দ দিয়ে ফলব্যাক করা হচ্ছে
            playFallbackAlarmSound()
        }
    }

    private fun playFallbackAlarmSound() {
        try {
            mediaPlayer?.let { try { it.release() } catch (_: Exception) {} }
            mediaPlayer = null
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getValidRingtoneUri(this)
            if (uri != null) {
                val ringtone = RingtoneManager.getRingtone(this, uri)
                ringtone?.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                fallbackRingtone = ringtone
                ringtone?.play()
                startVolumeWatch()
                // সিস্টেম রিংটোনের শেষ জানার কলব্যাক নেই — তাই পপআপ যেন আটকে না থাকে, ৯০ সেকেন্ড পর নিজে থামে
                mainHandler.postDelayed({ stopSelf() }, 90_000L)
            }
        } catch (_: Exception) {
            // সিস্টেম রিংটোনও না পাওয়া গেলে অন্তত ফুল-স্ক্রিন নোটিফিকেশন/ওভারলে দেখে ইউজার বুঝবেন
        }
    }

    // ───────────── বাটনের PendingIntent (BroadcastReceiver — সাথে সাথে চলে, সার্ভিস-স্টার্টের দেরি/ব্লক নেই) ─────────────
    private fun stopPi(): PendingIntent = PendingIntent.getBroadcast(this, 0,
        Intent(this, AzanActionReceiver::class.java).apply { action = ACTION_STOP },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun snoozePi(waqtName: String): PendingIntent = PendingIntent.getBroadcast(this, 1,
        Intent(this, AzanActionReceiver::class.java).apply {
            action = ACTION_SNOOZE
            putExtra("waqt", currentWaqt ?: waqtName)
            putExtra(AzanRepeat.EXTRA_RING, currentRing)
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    // ফুল-স্ক্রীন আজান পপআপ (AzanOverlayActivity) খোলার ইন্টেন্ট — লক-স্ক্রীনে সরাসরি, আর নোটিফিকেশনে ট্যাপ করলেও
    private fun overlayPi(waqtName: String): PendingIntent {
        val overlayIntent = Intent(this, AzanOverlayActivity::class.java).apply {
            putExtra("waqtName", waqtName)
            putExtra(AzanRepeat.EXTRA_RING, currentRing)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return PendingIntent.getActivity(this, 2, overlayIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /**
     * v48: নোটিফিকেশন-বারের পপআপ, অ্যান্ড্রয়েডের নিয়ম মেনে:
     *  • অ্যান্ড্রয়েড ১১ ও নিচে (API < 31): কাস্টম গ্লাস ডিজাইন (RemoteViews) — সংকুচিত + হেডস-আপ/বড়, গোল লোগো ও দুই রঙিন বাটন।
     *  • অ্যান্ড্রয়েড ১২+ (API 31+): সিস্টেম কাস্টম-ভিউ বাতিল করে নিজের টেমপ্লেটে ঢোকায় (ফলে ডিজাইন কাটা/বেমানান দেখাত) —
     *    তাই এখানে জোর না করে সিস্টেমের ডিফল্ট নোটিফিকেশন: আজানের লেখা + গোল লোগো (বড় আইকন) + অ্যাকসেন্ট রঙ + দুই নেটিভ বাটন।
     */
    private fun buildCustomNotification(waqtName: String): Notification {
        val stopPi = stopPi()
        val snoozePi = snoozePi(waqtName)
        val overlayPi = overlayPi(waqtName)
        val isLast = currentRing >= AzanContent.MAX_RINGS

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification) // FIX #7: dedicated notification icon
            .setColor(getColor(R.color.brand_notif_color))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            // অ্যান্ড্রয়েড ১২+ এ ফোরগ্রাউন্ড-সার্ভিসের নোটিফিকেশন ~১০ সেকেন্ড দেরিতে দেখানো হতে পারে — আজানে তাৎক্ষণিক দেখাতে হবে
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentTitle(AzanContent.shortTitle(waqtName)) // কাস্টম ভিউ ব্যর্থ হলেও সাধারণ লেখা থাকে
            .setContentIntent(overlayPi)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // অ্যান্ড্রয়েড ১২+: সিস্টেম ডিফল্ট স্টাইল
            builder
                .setContentText(getString(R.string.azan_popup_subtitle))
                .setSubText(appLabel())
                .addAction(0, getString(R.string.azan_popup_stop), stopPi)
            if (!isLast) builder.addAction(0, getString(R.string.azan_popup_snooze), snoozePi)
        } else {
            // অ্যান্ড্রয়েড ১১ ও নিচে: কাস্টম গ্লাস ডিজাইন
            val collapsed = azanRemoteViews(R.layout.notification_alarm, waqtName, stopPi, snoozePi, dp(42))
            val headsUp = azanRemoteViews(R.layout.notification_azan_headsup, waqtName, stopPi, snoozePi, dp(48))
            builder
                .setCustomContentView(collapsed)
                .setCustomHeadsUpContentView(headsUp)
                .setCustomBigContentView(headsUp)
        }

        // ফুল-স্ক্রীন ইন্টেন্ট শুধু ফোন লক/স্ক্রীন বন্ধ থাকলে। স্ক্রীন খোলা থাকলে এটা দিলে কিছু ফোনে (যেমন Honor/Huawei)
        // নোটিফিকেশনের বদলে সরাসরি ফুল-স্ক্রীন খুলে যায় — তাই তখন বাদ, শুধু হেডস-আপ পপআপ আসবে।
        if (AzanContent.isLockedOrScreenOff(this)) builder.setFullScreenIntent(overlayPi, true)
        return builder.build()
    }

    /** একই ডিজাইনের RemoteViews (গোল লোগো, ছোট করে ওয়াক্ত, "আজান বন্ধ করুন" ও "স্নুজ" বাটন) — শুধু অ্যান্ড্রয়েড ১১ ও নিচে */
    private fun azanRemoteViews(layoutRes: Int, waqtName: String, stopPi: PendingIntent, snoozePi: PendingIntent, logoBoxPx: Int): RemoteViews =
        RemoteViews(packageName, layoutRes).apply {
            setTextViewText(R.id.notif_title, AzanContent.shortTitle(waqtName))
            setTextViewText(R.id.notif_sub, appLabel())
            // গোল লোগো (রিং-এর ভেতরের মাপ ≈ বক্স − ২×২dp); সব জায়গায় একই গোল ভিত্তি
            AzanLogo.circle(this@AzanForegroundService, (logoBoxPx - dp(4)).coerceAtLeast(dp(24)))?.let {
                setImageViewBitmap(R.id.notifIcon, it)
            }
            setOnClickPendingIntent(R.id.btnNotifDismiss, stopPi)
            if (currentRing >= AzanContent.MAX_RINGS) {
                // শেষ (৩য়) আজানের পর আর রিপিট নেই, তাই স্নুজ বাটন লুকানো
                setViewVisibility(R.id.btnNotifSnooze, View.GONE)
            } else {
                setViewVisibility(R.id.btnNotifSnooze, View.VISIBLE)
                setOnClickPendingIntent(R.id.btnNotifSnooze, snoozePi)
            }
        }

    /** ফোনে অ্যাপের যে নাম আছে (পপআপের ছোট লাইনে দেখানো হয়) */
    private fun appLabel(): String = try {
        applicationInfo.loadLabel(packageManager).toString()
    } catch (_: Throwable) { getString(R.string.app_name) }

    // ✅ v44: কাস্টম RemoteViews ছাড়া সাধারণ নোটিফিকেশন (ব্যাকআপ — কোনো ফোনে কাস্টম ডিজাইন ব্যর্থ হলে)
    private fun buildSimpleNotification(waqtName: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(getColor(R.color.brand_notif_color))
            .setContentTitle(AzanContent.shortTitle(waqtName))
            .setContentText(getString(R.string.azan_popup_subtitle))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(overlayPi(waqtName))
            .addAction(0, getString(R.string.azan_popup_stop), stopPi())
            .apply {
                if (currentRing < AzanContent.MAX_RINGS) addAction(0, getString(R.string.azan_popup_snooze), snoozePi(waqtName))
            }
            .build()
    }

    // ───────────── সাউন্ড বন্ধ করার সব পথ (সবগুলোতে সাউন্ড আগে, তৎক্ষণাৎ) ─────────────

    /** "আজান বন্ধ করুন" */
    private fun doStop() {
        stopAudioNow()
        try { AzanRepeat.cancelAll(this) } catch (_: Throwable) {}
        isRunning = false
        stopSelf()
    }

    /** "স্নুজ" */
    private fun doSnooze(waqt: String?, ring: Int) {
        stopAudioNow()
        try { AzanRepeat.scheduleNext(this, waqt ?: currentWaqt, ring) } catch (_: Throwable) {}
        isRunning = false
        stopSelf()
    }

    /** ভলিউম বাটন (বা হেডসেট বাটন): শুধু সাউন্ড বন্ধ। পপআপ/নোটিফিকেশন থাকে, রিপিট বহাল; কয়েক মিনিট পর সার্ভিস নিজে থামে। */
    private fun silenceSound() {
        if (silenced) return
        silenced = true
        stopAudioNow()
        mainHandler.removeCallbacks(volumeWatch)
        mainHandler.removeCallbacks(lingerStop)
        mainHandler.postDelayed(lingerStop, SILENT_LINGER_MS)
    }

    private val lingerStop = Runnable { stopSelf() }

    /** প্লেয়ার/রিংটোন তৎক্ষণাৎ থামিয়ে ছেড়ে দেওয়া (বারবার ডাকলেও নিরাপদ) */
    private fun stopAudioNow() {
        mainHandler.removeCallbacks(volumeWatch)
        mediaPlayer?.let {
            try { it.setVolume(0f, 0f) } catch (_: Throwable) {}
            try { if (it.isPlaying) it.stop() } catch (_: Throwable) {}
            try { it.reset() } catch (_: Throwable) {}
            try { it.release() } catch (_: Throwable) {}
        }
        mediaPlayer = null
        try { fallbackRingtone?.stop() } catch (_: Throwable) {}
        fallbackRingtone = null
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am?.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION") am?.abandonAudioFocus(null)
            }
        } catch (_: Throwable) {}
    }

    // ───────────── ভলিউম-বাটন ধরা (পোলিং) ─────────────
    // ভলিউম-কী প্রতি ফোনে আলাদা পথে যায় (কিছুতে মিডিয়া-সেশনে, কিছুতে সরাসরি স্ট্রিমে), তাই আজান চলাকালীন
    // অ্যালার্ম/মিডিয়া ভলিউম বদলালেই বুঝে নেওয়া হয় ইউজার ভলিউম বাটন চেপেছে। কোনো লুকানো/অনিশ্চিত API নেই।
    private val volumeWatch = object : Runnable {
        override fun run() {
            if (silenced || !isRunning) return
            try {
                val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                if (am != null) {
                    val a = am.getStreamVolume(AudioManager.STREAM_ALARM)
                    val m = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    if (SystemClock.elapsedRealtime() - watchSince < 1500L || volBase[0] < 0) {
                        // শুরুর ১.৫ সেকেন্ড: আমাদের নিজের ভলিউম-সেট ধরা হয় না — শুধু ভিত্তি-মান ঠিক রাখা
                        volBase[0] = a; volBase[1] = m
                    } else if (a != volBase[0] || m != volBase[1]) {
                        silenceSound()
                        return
                    }
                }
            } catch (_: Throwable) {}
            mainHandler.postDelayed(this, 120L)
        }
    }

    private fun startVolumeWatch() {
        mainHandler.removeCallbacks(volumeWatch)
        volBase[0] = -1; volBase[1] = -1
        watchSince = SystemClock.elapsedRealtime()
        mainHandler.post(volumeWatch)
    }

    private fun waqtBnLabel(key: String) = AzanContent.label(key)

    override fun onDestroy() {
        isRunning = false
        if (instance === this) instance = null
        mainHandler.removeCallbacksAndMessages(null)
        stopAudioNow()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        wakeLock = null
        try { mediaSession?.isActive = false } catch (_: Throwable) {}
        try { mediaSession?.release() } catch (_: Throwable) {}
        mediaSession = null
        super.onDestroy()
    }
}
