package com.gunjoron.patheyo.widget.assets

import android.content.Context
import android.graphics.Typeface
import com.gunjoron.patheyo.ui.AppFonts

/**
 * উইজেট ও হাবের ফন্ট — সব ফন্ট অ্যাপের একই জায়গা (assets/fonts, AppFonts) থেকে আসে; আলাদা কপি নেই।
 * static TTF (ভেরিয়েবল ফন্ট নয়), তাই পুরনো ফোনেও উইজেট ভাঙে না।
 */
object Fonts {
    /** অ্যাপের Gunjoron-Font-এর unitsPerEm ১১৭০ (হাবের মূল কপির ১০০০) — হাবের UI লেখার মাপ এই গুণক দিয়ে মেলানো হয় */
    const val UI_SIZE_FACTOR = 1.17f

    @Volatile private var ready = false
    lateinit var regular: Typeface; private set   // গুঞ্জরণ রেগুলার
    lateinit var bold: Typeface; private set      // গুঞ্জরণ বোল্ড
    lateinit var bebas: Typeface; private set     // ডিজিটাল সংখ্যা
    lateinit var clockBold: Typeface; private set // ডিজাইন ৩-এর বড় ঘড়ি (EB Garamond Bold)
    lateinit var clockReg: Typeface; private set  // AM/PM ও সেকেন্ড (EB Garamond Regular)
    lateinit var outfit: Typeface; private set    // ডিজাইন ৪/৫-এর পাতলা আধুনিক ঘড়ি (Outfit Light)
    lateinit var ui: Typeface; private set        // হাবের UI ফন্ট — অ্যাপের Gunjoron-Font Normal
    lateinit var uiBold: Typeface; private set    // হাবের UI ফন্ট — অ্যাপের Gunjoron-Font Bold

    fun init(ctx: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            val c = ctx.applicationContext
            regular = AppFonts.load(c, AppFonts.WIDGET_BN_REGULAR)
            bold = AppFonts.load(c, AppFonts.WIDGET_BN_BOLD, Typeface.DEFAULT_BOLD)
            bebas = AppFonts.load(c, AppFonts.WIDGET_DIGITS)
            clockBold = AppFonts.load(c, AppFonts.WIDGET_CLOCK_BOLD, Typeface.DEFAULT_BOLD)
            clockReg = AppFonts.load(c, AppFonts.WIDGET_CLOCK_REGULAR)
            outfit = AppFonts.load(c, AppFonts.CLOCK_LIGHT)
            ui = AppFonts.bengali(c, false)
            uiBold = AppFonts.bengali(c, true)
            ready = true
        }
    }
}
