package com.gunjoron.patheyo.alarm

// রাখতে হবে: app/src/main/java/com/gunjoron/Patheyo/alarm/AzanAlarmReceiver.kt
//
// AlarmManager এর অ্যালার্ম বাজলে এই Receiver-টা ট্রিগার হয়, এটা ফোরগ্রাউন্ড সার্ভিস চালু করে
// আজান বাজানোর জন্য (অ্যাপ সম্পূর্ণ বন্ধ থাকা অবস্থাতেও কাজ করে), এবং একই ওয়াক্তের জন্য পরের দিনের
// অ্যালার্ম আবার শিডিউল করে দেয় (অ্যালার্ম এক-বারের জন্যই হয়)।
//
// ✅ v45: স্নুজ/অটো-রিপিটের অ্যালার্মও (AzanRepeat) এই রিসিভারেই আসে — "ring" এক্সট্রা বলে এটা কত নম্বর আজান (দৈনিক অ্যালার্মে ১)।
//  - ফুল-স্ক্রীন আজান পপআপ সরাসরি খোলা হয় শুধু ফোন লক/স্ক্রীন বন্ধ থাকলে; স্ক্রীন খোলা থাকলে নোটিফিকেশন-বারের পপআপ (সার্ভিসের হেডস-আপ) দেখায়।
//
// ✅ v44 পরিবর্তন (পুরনো/OEM ফোনে আজান না বাজার সমস্যার ফিক্স):
//  - ওয়েক-লক: রিসিভার শেষ হওয়া আর সার্ভিস চালু হওয়ার মাঝের ফাঁকে পুরনো/ধীর ফোন ঘুমিয়ে পড়ত → এখন ধরে রাখা হয়
//  - প্রতিটা ধাপ আলাদা try-catch(Throwable): একটা ধাপ ব্যর্থ হলে বাকিগুলো (বিশেষত পরের দিনের অ্যালার্ম) বাদ পড়ে না
//  - ডুপ্লিকেট-গার্ড: একই ওয়াক্তের অ্যালার্ম ৯০ সেকেন্ডের মধ্যে দুইবার এলে আজান দুইবার শুরু হবে না
//  - পরের দিনের অ্যালার্ম সবসময় finally-তে বসে, আজান শুরুতে সমস্যা হলেও

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.gunjoron.patheyo.widget.PrayerWidgetProvider

class AzanAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val waqt = intent.getStringExtra("waqt") ?: return
        val ring = intent.getIntExtra(AzanRepeat.EXTRA_RING, 1).coerceIn(1, AzanContent.MAX_RINGS)
        val app = context.applicationContext

        // ০. ওয়েক-লক (সর্বোচ্চ ৩০ সেকেন্ড, নিজে থেকেই ছেড়ে দেয়) — যাতে সার্ভিস চালু হওয়ার আগে CPU ঘুমিয়ে না পড়ে
        try {
            val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Patheyo:AzanReceiver")?.acquire(30_000L)
        } catch (_: Throwable) { }

        try {
            // ডুপ্লিকেট-গার্ড
            val prefs = app.getSharedPreferences(AlarmScheduler.PREFS_NAME, Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val last = prefs.getLong("last_fired_$waqt", 0L)
            val isDuplicate = now >= last && (now - last) < 90_000L
            if (!isDuplicate) {
                prefs.edit().putLong("last_fired_$waqt", now).apply()

                // ১. ফোরগ্রাউন্ড সার্ভিস চালু করা (আজানের অডিও ও নোটিফিকেশন বারের জন্য)
                try {
                    val serviceIntent = Intent(app, AzanForegroundService::class.java).apply {
                        putExtra("waqt", waqt)
                        putExtra(AzanRepeat.EXTRA_RING, ring)
                    }
                    ContextCompat.startForegroundService(app, serviceIntent)
                } catch (_: Throwable) { }

                // ২. ফুল-স্ক্রীন আজান পপআপ (AzanOverlayActivity) — শুধু ফোন লক বা স্ক্রীন বন্ধ থাকলে সরাসরি খোলা হয়।
                // স্ক্রীন খোলা থাকলে সার্ভিসের নোটিফিকেশন (হেডস-আপ পপআপ) দেখাবে। অ্যান্ড্রয়েড ১০+ এ ব্যাকগ্রাউন্ড থেকে
                // সরাসরি অ্যাক্টিভিটি ব্লক হতে পারে, সেক্ষেত্রে সার্ভিসের FullScreenIntent দিয়ে স্ক্রিন চালু হবে।
                if (AzanContent.isLockedOrScreenOff(app)) {
                    try {
                        val alarmPageIntent = Intent(app, AzanOverlayActivity::class.java).apply {
                            putExtra("waqtName", waqt)
                            putExtra(AzanRepeat.EXTRA_RING, ring)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                        }
                        app.startActivity(alarmPageIntent)
                    } catch (_: Throwable) { }
                }

                // আজান শুরু হওয়ার সাথে সাথে উইজেট রিফ্রেশ করা যাতে হাইলাইট আপডেট হয়
                try { PrayerWidgetProvider.updateAllWidgets(app) } catch (_: Throwable) { }
            }
        } finally {
            // এই ওয়াক্তের জন্য পরের দিনের অ্যালার্ম আবার বসিয়ে দেওয়া হলো (সবসময় চলবে)
            try { AlarmScheduler.scheduleAllAlarms(app) } catch (_: Throwable) { }
        }
    }
}
