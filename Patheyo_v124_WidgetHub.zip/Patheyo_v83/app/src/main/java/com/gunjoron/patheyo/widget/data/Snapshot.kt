package com.gunjoron.patheyo.widget.data

import android.content.Context
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import org.json.JSONObject
import java.util.Calendar

/**
 * একটি নির্দিষ্ট মুহূর্তের সব প্রদর্শনযোগ্য তথ্য। রেন্ডারার শুধু এটাই পড়ে।
 *
 * current: ০=ফজর ১=যোহর ২=আসর ৩=মাগরিব ৪=ইশা, -১ = সূর্যোদয় থেকে যোহর পর্যন্ত (কোনো ওয়াক্ত চলছে না)।
 */
class Snapshot(
    val nowMs: Long,
    val hijriMonthYear: String,      // "রবিউস সানি ১৪৪৭"
    val gregDay: String,             // "১৯"
    val gregMonth: String,           // "অক্টোবর"
    val gregYear: String,            // "২০২৬"
    val banglaDay: String,
    val banglaMonth: String,
    val banglaYear: String,
    val hijriDay: String,
    val hijriMonth: String,
    val hijriYear: String,
    val prayerNames: Array<String>,  // ফজর/যোহর(বা জুম'আ)/আসর/মাগরিব/ইশা
    val prayerTimes: Array<String>,  // ০৪:৫৫ ফরম্যাট, ফজর/যোহর/আসর/মাগরিব/ইশা
    val sunrise: String,             // ৬:৫৯
    val sehri: String,
    val iftar: String,
    val current: Int,
    val currentName: String,         // চলমান (বা পরবর্তী) ওয়াক্তের নাম
    val running: Boolean,            // true = ওয়াক্ত চলছে; false = সূর্যোদয়-যোহর বিরতি
    val periodStartMs: Long,         // চলমান ওয়াক্তের শুরু (বা বিরতির শুরু)
    val periodEndMs: Long,           // চলমান ওয়াক্তের শেষ (বা যোহরের শুরু)
    val isPm: Boolean,
    val nextChangeMs: Long,          // উইজেট কখন আবার রিফ্রেশ করতে হবে
    val sunriseMs: Long = 0L,        // আজকের সূর্যোদয়
    val sunsetMs: Long = 0L,         // আজকের সূর্যাস্ত (= মাগরিব)
    val nightStartMs: Long = 0L,     // চলমান/পরবর্তী রাতের শুরু (সূর্যাস্ত) — চাঁদের আর্কের জন্য
    val nightEndMs: Long = 0L,       // রাতের শেষ (পরবর্তী সূর্যোদয়)
    val forbid: Int = 0,             // ডিজাইন ৬: ০=স্বাভাবিক, ১=নিষিদ্ধ সময় চলছে, ২=সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত ("-")
    val forbidEndMs: Long = 0L,      // নিষিদ্ধ সময় (forbid=১) কখন শেষ
    val forbidStartMs: Long = 0L,    // নিষিদ্ধ সময় (forbid=১) কখন শুরু
    val gregFirst: Boolean = false,  // ইংরেজি তারিখ আগে (ট্রগল)
    val sunIsSet: Boolean = false,   // দিনে (সূর্যোদয়–সূর্যাস্ত) true → "সূর্যাস্ত" দেখাবে, নইলে "সূর্যোদয়"
    val sunLabel: String = "সূর্যোদয়",
    val sunTime: String = "",         // পরের সূর্য-ঘটনার সময় (দিনে সূর্যাস্ত, রাতে পরের সূর্যোদয়)
    val hasData: Boolean = true,     // false = অ্যাপ থেকে এখনও সময় লোড হয়নি ("--:--" দেখানো হবে)
    val message: String? = null      // বিশেষ বার্তা (যেমন রোজা হারামের দিন) — ডিজাইনের স্ট্যাটাস লাইনে দেখায়
) {
    val gregorianLine: String get() = "$gregDay $gregMonth $gregYear"
    val banglaLine: String get() = "$banglaDay $banglaMonth $banglaYear"
    val hijriLine: String get() = "$hijriDay $hijriMonthYear"

    companion object {
        // নিষিদ্ধ সময়ের দৈর্ঘ্য (অ্যাপের আগের উইজেটের হুবহু নিয়ম): সূর্যোদয়ের পর ১৫ মি., দুপুরে যোহরের আগে ১২ মি., সূর্যাস্তের আগে ১৫ মি.
        const val FORBID_MORNING_MS = 15 * 60_000L
        const val FORBID_NOON_MS = 12 * 60_000L
        const val FORBID_EVENING_MS = 15 * 60_000L
        private const val DAY_MS = 86_400_000L
        private const val NO_HIJRI = "-- --- ----"

        private fun clock12(ms: Long, pad: Boolean): String {
            val c = Calendar.getInstance(); c.timeInMillis = ms
            var h = c.get(Calendar.HOUR); if (h == 0) h = 12
            val m = c.get(Calendar.MINUTE)
            return Bn.digits((if (pad && h < 10) "0$h" else "$h") + ":" + Bn.pad2(m))
        }

        /** "HH:mm" (২৪ ঘণ্টা) → আজকের তারিখে মিলিসেকেন্ড; পার্স না হলে null */
        private fun todayMs(hhmm: String, dayStart: Long): Long? = try {
            val p = hhmm.trim().split(" ")[0].split(":")
            dayStart + (p[0].toInt() * 60L + p[1].toInt()) * 60_000L
        } catch (_: Exception) { null }

        /** আজকের হিজরি তারিখ-স্ট্রিং ("১৯ রবিউস সানি ১৪৪৭") — উইজেটের আগের সিস্টেমের হুবহু হিসাব (ফায়ারবেজ ওভাররাইড, দিন-এগোনো, মাগরিব-শিফট)। */
        private fun hijriString(ctx: Context, json: JSONObject, nowMs: Long, maghribMs: Long?): String {
            val prefs = ctx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            val baseHijri = json.optString("hijri", NO_HIJRI)
            val hijriFirebase = prefs.getString("hijri_date_firebase", null)
            val adjustment = prefs.getInt("last_rtdb_adjustment", 0)
            val today = FirebaseDataManager.todayDateOnlyStr()
            val override = FirebaseDataManager.overrideHijriOrNull(prefs)
            var d = when {
                override != null -> override
                !hijriFirebase.isNullOrBlank() -> {
                    val setOn = prefs.getString("hijri_date_firebase_set_on", today) ?: today
                    FirebaseDataManager.adjustHijriDate(hijriFirebase, FirebaseDataManager.daysBetweenDateStr(setOn, today))
                }
                baseHijri != NO_HIJRI -> {
                    val fetchedOn = prefs.getString("timings_fetched_on", today) ?: today
                    FirebaseDataManager.adjustHijriDate(baseHijri, adjustment + FirebaseDataManager.daysBetweenDateStr(fetchedOn, today))
                }
                else -> baseHijri
            }
            // আজকের মাগরিব পার হলে আজকের আংশিক দিনের জন্য ১ দিন এগিয়ে (ওভাররাইডে নয়)
            if (d != NO_HIJRI && override == null && maghribMs != null && nowMs >= maghribMs) {
                d = FirebaseDataManager.adjustHijriDate(d, 1)
            }
            return d
        }

        /** হাররাম রোজার দিনের বার্তা (আগের উইজেটের checkHaramRoza-র হুবহু নিয়ম) */
        private fun haramRozaMessage(hijriStr: String): String? {
            try {
                val parts = hijriStr.trim().split(" ")
                if (parts.size < 2) return null
                val day = FirebaseDataManager.convertBengaliToEnglish(parts[0]).toIntOrNull() ?: return null
                val monthName = parts[1]
                if (monthName.contains("শাওয়াল") && day == 1) return "আজ ঈদের দিন, রোজা রাখা হারাম"
                if (monthName.contains("জিলহজ") || monthName.contains("যিলহজ")) {
                    if (day == 10) return "আজ কোরবানির ঈদ, রোজা হারাম"
                    if (day in 11..13) return "আইয়ামে তাশরিক, রোজা হারাম"
                }
            } catch (_: Exception) {}
            return null
        }

        /** বাংলা (বঙ্গাব্দ) তারিখ — বাংলাদেশ সংশোধিত পঞ্জিকা, পহেলা বৈশাখ = ১৪ এপ্রিল (আগের উইজেটের হুবহু হিসাব) */
        private fun banglaDate(nowMs: Long): Triple<Int, Int, Int> {
            val now = Calendar.getInstance().apply {
                timeInMillis = nowMs
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val gYear = now.get(Calendar.YEAR)
            val isLeap = (gYear % 4 == 0 && gYear % 100 != 0) || (gYear % 400 == 0)
            val daysInMonths = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (isLeap) 30 else 29, 30)
            var bYear = gYear - 593
            var poyla = Calendar.getInstance().apply { set(gYear, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            if (now.timeInMillis < poyla.timeInMillis) {
                bYear -= 1
                poyla = Calendar.getInstance().apply { set(gYear - 1, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            }
            val diffDays = Math.round((now.timeInMillis - poyla.timeInMillis) / DAY_MS.toDouble()).toInt()
            var monthIdx = 0
            var bDay = diffDays + 1
            while (monthIdx < daysInMonths.size && bDay > daysInMonths[monthIdx]) { bDay -= daysInMonths[monthIdx]; monthIdx++ }
            if (monthIdx >= Bn.BANGLA_MONTHS.size) monthIdx = Bn.BANGLA_MONTHS.size - 1
            return Triple(bDay, monthIdx, bYear)
        }

        /**
         * অ্যাপের আগের সিস্টেমের ডেটা (SharedPreferences "ibadat_widget_prefs" → timings_json ও হিজরি কী-গুলো)
         * থেকে এই মুহূর্তের Snapshot বানায়। কোনো ডেটা না থাকলে "--:--" সহ খালি Snapshot (hasData=false)।
         */
        fun build(ctx: Context, nowMs: Long = System.currentTimeMillis()): Snapshot {
            val hub = HubPrefs.get(ctx)
            val prefs = ctx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            val json = try { prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null)?.let { JSONObject(it) } } catch (_: Exception) { null }

            val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
            val dayStart = Calendar.getInstance().apply {
                timeInMillis = nowMs
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val isPm = cal.get(Calendar.HOUR_OF_DAY) >= 12
            val bn = banglaDate(nowMs)
            val gDay = Bn.digits(cal.get(Calendar.DAY_OF_MONTH))
            val gMonth = Bn.GREG_MONTHS[cal.get(Calendar.MONTH)]
            val gYear = Bn.digits(cal.get(Calendar.YEAR))

            fun t(key: String, fallback: String? = null): Long? =
                json?.let { todayMs(it.optString(key, fallback ?: ""), dayStart) }
            val fajr = t("fajr"); val sunrise = t("sunrise"); val dhuhr = t("dhuhr")
            val asr = t("asr"); val maghrib = t("maghrib"); val isha = t("isha")
            val sunset = t("sunset") ?: maghrib

            // ডেটা নেই বা অসম্পূর্ণ: "--:--" অবস্থা
            if (json == null || fajr == null || sunrise == null || dhuhr == null || asr == null || maghrib == null || isha == null) {
                val hj = json?.let { hijriString(ctx, it, nowMs, null) }
                    ?: (prefs.getString("hijri_date_firebase", null) ?: NO_HIJRI)
                val hjBn = Bn.digits(hj).split(" ")
                val hjDay = hjBn.firstOrNull().orEmpty()
                val hjYear = if (hjBn.size > 2) hjBn.last() else ""
                val hjMonth = if (hjBn.size > 2) hjBn.subList(1, hjBn.size - 1).joinToString(" ") else hjBn.drop(1).joinToString(" ")
                return Snapshot(
                    nowMs = nowMs,
                    hijriMonthYear = "$hjMonth $hjYear".trim(),
                    gregDay = gDay, gregMonth = gMonth, gregYear = gYear,
                    banglaDay = Bn.digits(bn.first), banglaMonth = Bn.BANGLA_MONTHS[bn.second], banglaYear = Bn.digits(bn.third),
                    hijriDay = hjDay, hijriMonth = hjMonth, hijriYear = hjYear,
                    prayerNames = Bn.PRAYER_NAMES.copyOf(),
                    prayerTimes = Array(5) { "--:--" },
                    sunrise = "--:--", sehri = "--:--", iftar = "--:--",
                    current = -1, currentName = Bn.PRAYER_NAMES[1], running = false,
                    periodStartMs = nowMs, periodEndMs = nowMs + 60_000L,
                    isPm = isPm,
                    nextChangeMs = nowMs + 60_000L,
                    forbid = 2,
                    gregFirst = hub.gregFirst,
                    sunLabel = "সূর্যোদয়", sunTime = "--:--",
                    hasData = false
                )
            }
            val sunsetMs = sunset ?: maghrib

            // চলমান ওয়াক্ত (আগের সিস্টেমের মতো: আগের/পরের দিনের সময় = আজকের সময় ± ২৪ ঘণ্টা)
            val cur: Int; val start: Long; val end: Long; val running: Boolean
            when {
                nowMs < fajr -> { cur = 4; start = isha - DAY_MS; end = fajr; running = true }
                nowMs < sunrise -> { cur = 0; start = fajr; end = sunrise; running = true }
                nowMs < dhuhr -> { cur = -1; start = sunrise; end = dhuhr; running = false }
                nowMs < asr -> { cur = 1; start = dhuhr; end = asr; running = true }
                nowMs < maghrib -> { cur = 2; start = asr; end = maghrib; running = true }
                nowMs < isha -> { cur = 3; start = maghrib; end = isha; running = true }
                else -> { cur = 4; start = isha; end = fajr + DAY_MS; running = true }
            }

            // জুম'আ: আগের উইজেটের নিয়ম — ক্যালেন্ডারের শুক্রবার (মাগরিব ধরে হিজরি-দিনের শিফট নয়)
            val jumuah = cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
            val names = Bn.PRAYER_NAMES.copyOf()
            if (jumuah) names[1] = "জুম'আ"
            val name = if (cur >= 0) names[cur] else names[1]

            // হিজরি
            val hijriStr = hijriString(ctx, json, nowMs, maghrib)
            val hjParts = Bn.digits(hijriStr).split(" ")
            val hjDay = hjParts.firstOrNull().orEmpty()
            val hjYear = if (hjParts.size > 2) hjParts.last() else ""
            val hjMonth = if (hjParts.size > 2) hjParts.subList(1, hjParts.size - 1).joinToString(" ") else hjParts.drop(1).joinToString(" ")

            // পরবর্তী রিফ্রেশ: ওয়াক্তের সীমা, নিষিদ্ধ সময়ের সীমা, ১ ঘণ্টা/১০ ঘণ্টায় Chronometer-এর ফরম্যাট বদল, দুপুর ১২টা ও মধ্যরাত
            val noon = dayStart + 12 * 3600_000L
            val cands = ArrayList<Long>()
            cands += listOf(fajr, sunrise, dhuhr, asr, maghrib, isha, fajr + DAY_MS, noon, dayStart + DAY_MS)
            cands += listOf(sunrise + FORBID_MORNING_MS, dhuhr - FORBID_NOON_MS, sunsetMs - FORBID_EVENING_MS)
            for (h in longArrayOf(3600_000L, 36000_000L)) { cands += end - h; cands += start + h }
            var next = Long.MAX_VALUE
            for (c in cands) if (c > nowMs + 500 && c < next) next = c
            if (next == Long.MAX_VALUE) next = nowMs + 60_000L

            // নিষিদ্ধ সময়: সূর্যোদয়ের পর, ঠিক দুপুর, সূর্যাস্তের আগে
            val srEnd = sunrise + FORBID_MORNING_MS
            val noonStart = dhuhr - FORBID_NOON_MS
            val evStart = sunsetMs - FORBID_EVENING_MS
            var forbid = 0; var forbidEnd = 0L; var forbidStart = 0L
            when {
                nowMs >= sunrise && nowMs < srEnd -> { forbid = 1; forbidEnd = srEnd; forbidStart = sunrise }
                nowMs >= srEnd && nowMs < noonStart -> forbid = 2
                nowMs >= noonStart && nowMs < dhuhr -> { forbid = 1; forbidEnd = dhuhr; forbidStart = noonStart }
                nowMs >= evStart && nowMs < sunsetMs -> { forbid = 1; forbidEnd = sunsetMs; forbidStart = evStart }
            }

            val isDay = nowMs >= sunrise && nowMs < maghrib
            val nextSunrise = if (nowMs < sunrise) sunrise else sunrise + DAY_MS

            return Snapshot(
                nowMs = nowMs,
                hijriMonthYear = "$hjMonth $hjYear".trim(),
                gregDay = gDay, gregMonth = gMonth, gregYear = gYear,
                banglaDay = Bn.digits(bn.first), banglaMonth = Bn.BANGLA_MONTHS[bn.second], banglaYear = Bn.digits(bn.third),
                hijriDay = hjDay, hijriMonth = hjMonth, hijriYear = hjYear,
                prayerNames = names,
                prayerTimes = arrayOf(
                    clock12(fajr, true), clock12(dhuhr, true), clock12(asr, true),
                    clock12(maghrib, true), clock12(isha, true)
                ),
                sunrise = clock12(sunrise, false),
                sehri = clock12(fajr, false),
                iftar = clock12(maghrib, false),
                current = cur, currentName = name, running = running,
                periodStartMs = start, periodEndMs = end,
                isPm = isPm,
                nextChangeMs = next + 1000L,
                sunriseMs = sunrise, sunsetMs = maghrib,
                nightStartMs = if (nowMs < sunrise) maghrib - DAY_MS else maghrib,
                nightEndMs = nextSunrise,
                forbid = forbid, forbidEndMs = forbidEnd, forbidStartMs = forbidStart,
                gregFirst = hub.gregFirst,
                sunIsSet = isDay,
                sunLabel = if (isDay) "সূর্যাস্ত" else "সূর্যোদয়",
                sunTime = if (isDay) clock12(maghrib, false) else clock12(nextSunrise, false),
                message = haramRozaMessage(hijriStr)
            )
        }
    }
}
