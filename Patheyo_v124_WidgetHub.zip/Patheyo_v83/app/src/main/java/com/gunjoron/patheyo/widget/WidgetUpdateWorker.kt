package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/WidgetUpdateWorker.kt
//
// ✅ v24: দুই কাজে ব্যবহার হয় —
//   ১) ৮০-মিনিটের periodic ব্যাকআপ (AlarmManager চেইন থেমে গেলে আবার চালু করে),
//   ২) মধ্যরাতে/বাসি ডেটায় one-time fetch (শুধু CONNECTED নেটওয়ার্কে — WidgetRefreshScheduler.enqueueFetchNow)।
// নেটওয়ার্ক কল Worker-এই হয় (BroadcastReceiver/মেইন থ্রেডে নয় — Android নিয়ম)। যাই ঘটুক, Result.success()।

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class WidgetUpdateWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try {
            // v62: Firebase  (  widget    )
            com.gunjoron.patheyo.FirebaseDataManager.fetchBlocking(applicationContext)
        } catch (t: Throwable) { }
        try {
            // আজকের জন্য এখনো না আনা থাকলে Aladhan থেকে নেটিভ fetch (সফল হলে নিজেই রিরেন্ডার করে)
            NativePrayerTimesFetcher.fetchIfStale(applicationContext)
        } catch (t: Throwable) { /* পরের সাইকেলে আবার চেষ্টা */ }
        try {
            // fetch লাইনে আবার fetch ঢোকানো নয় (লুপ এড়াতে allowFetchEnqueue=false)
            WidgetRefreshScheduler.hardReset(applicationContext, allowFetchEnqueue = false)
        } catch (t: Throwable) { /* পরের সাইকেলে আবার চেষ্টা */ }
        return Result.success()
    }
}
