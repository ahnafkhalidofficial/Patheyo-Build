package com.gunjoron.patheyo.quran

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.Executors
import java.util.zip.GZIPInputStream
import javax.net.ssl.SSLException

/**
 * কুরআন পেজের (WebView) জন্য নেটিভ ডাউনলোডার — মুসহাফ PDF ও তরজমা ফাইল GitHub থেকে নামিয়ে অ্যাপের নিজস্ব স্টোরেজে রাখে।
 *
 * JS-এর সাথে চুক্তি (assets/index.html → কুরআন পেজের pdf-download / tarjama-download):
 *   window.QuranNative        (Kind.PDF)     : isPdfReady, getPdfSize, deletePdf, startDownload, cancelDownload, getStatus, readChunk
 *   window.QuranTarjamaNative (Kind.TARJAMA) : isTarjamaReady, getTarjamaSize, deleteTarjama, startDownload, cancelDownload, getStatus, readChunk
 *   প্রগ্রেস: window.__quranNativeEvent('pdf'|'tarjama', {phase, downloaded, total, error}) — phase = downloading | done | error | idle
 *   ফাইল পড়া: https://quran-local.invalid/<ফাইল> (QuranLocalServer), না হলে readChunk (base64 টুকরো)।
 *
 * ফাইল থাকে filesDir/quran/ ফোল্ডারে। ডাউনলোড `.part` ফাইলে হয়; নেটওয়ার্ক কেটে গেলে ফাইলটা রাখা হয়, আবার চাপলে
 * যেখানে থেমেছিল সেখান থেকে চলে (HTTP Range)। শেষে ফাইল যাচাই (PDF: "%PDF-", তরজমা: .gz খুলে `{"format":`) করে তবেই সেভ হয়।
 */
class QuranFileBridge(context: Context, private val webView: WebView, private val kind: Kind) {

    enum class Kind(val jsKind: String, val fileName: String) {
        PDF("pdf", "Hafezi-Quran.pdf"),
        TARJAMA("tarjama", "Quran-Tarjama.json")
    }

    private class Cancelled : Exception()

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    @Volatile private var phase = "idle"
    @Volatile private var downloaded = 0L
    @Volatile private var total = 0L
    @Volatile private var error: String? = null
    @Volatile private var cancelled = false
    @Volatile private var conn: HttpURLConnection? = null
    @Volatile private var lastPushAt = 0L

    private fun dir(): File = File(appContext.filesDir, QuranLocalServer.DIR_NAME).apply { mkdirs() }
    private fun finalFile(): File = File(dir(), kind.fileName)
    private fun partFile(): File = File(dir(), kind.fileName + ".part")

    // ------------------------------------------------------------------ JS-এ দেখানো মেথড

    @JavascriptInterface fun isPdfReady(): Boolean = kind == Kind.PDF && finalFile().let { it.exists() && it.length() > 0 }
    @JavascriptInterface fun isTarjamaReady(): Boolean = kind == Kind.TARJAMA && finalFile().let { it.exists() && it.length() > 0 }
    @JavascriptInterface fun getPdfSize(): Long = if (kind == Kind.PDF) finalFile().length() else 0L
    @JavascriptInterface fun getTarjamaSize(): Long = if (kind == Kind.TARJAMA) finalFile().length() else 0L
    @JavascriptInterface fun deletePdf() { if (kind == Kind.PDF) deleteFiles() }
    @JavascriptInterface fun deleteTarjama() { if (kind == Kind.TARJAMA) deleteFiles() }

    @JavascriptInterface fun getStatus(): String = statusJson()

    @JavascriptInterface fun startDownload(url: String) {
        if (phase == "downloading") return
        if (!url.startsWith("https://", ignoreCase = true)) { fail("bad-url"); return }
        cancelled = false
        error = null
        downloaded = 0L
        total = 0L
        phase = "downloading"
        push(true)
        worker.execute {
            try {
                runDownload(url)
            } catch (_: Cancelled) {
                onCancelled()
            } catch (e: Throwable) {
                if (cancelled) onCancelled() else fail(mapError(e))
            }
        }
    }

    @JavascriptInterface fun cancelDownload() {
        if (phase != "downloading") return
        cancelled = true
        try { conn?.disconnect() } catch (_: Throwable) {}   // আটকে থাকা read সাথে সাথে ছাড়ানো
    }

    /** offset থেকে length বাইট পড়ে base64 (NO_WRAP) হিসেবে দেয়; ব্যর্থ হলে খালি স্ট্রিং */
    @JavascriptInterface fun readChunk(offset: Long, length: Int): String {
        return try {
            RandomAccessFile(finalFile(), "r").use { raf ->
                if (offset < 0 || offset >= raf.length() || length <= 0) return ""
                val n = minOf(length.toLong(), raf.length() - offset).toInt()
                val buf = ByteArray(n)
                raf.seek(offset)
                raf.readFully(buf)
                Base64.encodeToString(buf, Base64.NO_WRAP)
            }
        } catch (_: Throwable) { "" }
    }

    // ------------------------------------------------------------------ ডাউনলোড

    private fun openConnection(url: String, from: Long): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true      // GitHub Release → objects.githubusercontent.com (https→https)
        c.requestMethod = "GET"
        c.setRequestProperty("User-Agent", "Patheyo/1.6 (Android)")
        c.setRequestProperty("Accept-Encoding", "identity")
        if (from > 0) c.setRequestProperty("Range", "bytes=$from-")
        return c
    }

    private fun runDownload(url: String) {
        val part = partFile()
        var resumeFrom = if (part.exists()) part.length() else 0L
        var c = openConnection(url, resumeFrom)
        conn = c
        var code = c.responseCode
        if (code == 416) {                    // রেঞ্জ মেলেনি (আগের .part পুরনো/নষ্ট) → গোড়া থেকে
            c.disconnect(); part.delete(); resumeFrom = 0L
            c = openConnection(url, 0L); conn = c; code = c.responseCode
        }
        if (code !in 200..299) { c.disconnect(); fail("http-$code"); return }
        val append = code == 206 && resumeFrom > 0
        if (!append) resumeFrom = 0L          // সার্ভার Range না মানলে (200) গোড়া থেকে শুরু
        val len = c.contentLengthLong
        total = if (len > 0) len + resumeFrom else 0L
        downloaded = resumeFrom
        push(true)

        c.inputStream.use { input ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (cancelled) throw Cancelled()
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    downloaded += n
                    push(false)
                }
            }
        }
        if (cancelled) throw Cancelled()
        c.disconnect()
        if (total > 0 && part.length() < total) { fail("network"); return }   // মাঝপথে কেটে গেছে — .part রাখা হলো, আবার চাপলে চলবে
        finishAndStore(part)
    }

    private fun readHead(f: File, n: Int): ByteArray {
        val buf = ByteArray(n)
        val r = f.inputStream().use { it.read(buf) }
        return if (r <= 0) ByteArray(0) else buf.copyOf(r)
    }

    /** ফাইল যাচাই করে চূড়ান্ত নামে সেভ (PDF: "%PDF-"; তরজমা: .gz হলে খুলে `{"format":`) */
    private fun finishAndStore(part: File) {
        val dst = finalFile()
        if (kind == Kind.PDF) {
            if (String(readHead(part, 5), Charsets.ISO_8859_1) != "%PDF-") { part.delete(); fail("not-pdf"); return }
            dst.delete()
            if (!part.renameTo(dst)) { fail("corrupt"); return }
        } else {
            val tmp = File(dir(), kind.fileName + ".tmp")
            val head = readHead(part, 2)
            val isGz = head.size >= 2 && head[0] == 0x1f.toByte() && head[1] == 0x8b.toByte()
            try {
                if (isGz) {
                    GZIPInputStream(part.inputStream().buffered()).use { gz -> FileOutputStream(tmp).use { gz.copyTo(it) } }
                    part.delete()
                } else if (!part.renameTo(tmp)) { fail("corrupt"); return }
            } catch (e: IOException) {
                tmp.delete(); part.delete(); fail("corrupt"); return
            }
            if (String(readHead(tmp, 10), Charsets.UTF_8) != "{\"format\":") { tmp.delete(); fail("not-tarjama"); return }
            dst.delete()
            if (!tmp.renameTo(dst)) { fail("corrupt"); return }
        }
        val size = dst.length()
        downloaded = size; total = size; error = null; phase = "done"
        push(true)                                   // JSON এখনই বানানো হয়; তারপর অবস্থা শান্ত (idle) করা হয়
        phase = "idle"; downloaded = 0L; total = 0L
    }

    private fun onCancelled() {
        try { partFile().delete() } catch (_: Throwable) {}
        error = null; phase = "idle"; downloaded = 0L; total = 0L
        push(true)
    }

    private fun fail(code: String) {
        error = code; phase = "error"
        push(true)
    }

    private fun deleteFiles() {
        if (phase == "downloading") { cancelled = true; try { conn?.disconnect() } catch (_: Throwable) {} }
        try { finalFile().delete(); partFile().delete(); File(dir(), kind.fileName + ".tmp").delete() } catch (_: Throwable) {}
        error = null; phase = "idle"; downloaded = 0L; total = 0L
    }

    private fun mapError(e: Throwable): String = when (e) {
        is UnknownHostException -> if (isOnline()) "network" else "offline"
        is SocketTimeoutException -> "timeout"
        is SSLException -> "ssl"
        is IOException -> {
            val m = e.message ?: ""
            when {
                m.contains("ENOSPC", true) || m.contains("No space", true) -> "no-space"
                !isOnline() -> "offline"
                else -> "network"
            }
        }
        else -> "network"
    }

    private fun isOnline(): Boolean = try {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Throwable) { true }

    // ------------------------------------------------------------------ JS-এ অবস্থা পাঠানো

    private fun statusJson(): String = JSONObject()
        .put("phase", phase)
        .put("downloaded", downloaded)
        .put("total", total)
        .put("error", error ?: JSONObject.NULL)
        .toString()

    private fun push(force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPushAt < 250L) return
        lastPushAt = now
        val js = "window.__quranNativeEvent&&window.__quranNativeEvent('${kind.jsKind}',${statusJson()});"
        main.post { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} }
    }
}
