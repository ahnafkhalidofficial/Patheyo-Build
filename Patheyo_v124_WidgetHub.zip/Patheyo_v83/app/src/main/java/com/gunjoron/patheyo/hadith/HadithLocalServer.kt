package com.gunjoron.patheyo.hadith

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

/**
 * ডাউনলোড করা হাদিসের কিতাব WebView-কে একটা নকল ঠিকানায় দেখায়: https://hadith-local.invalid/<id>-v<ভার্সন>.json
 * (হাদিস পেজের JS এখান থেকে XHR দিয়ে সরাসরি বাইট পড়ে; কাজ না করলে readChunk ব্রিজ ফলব্যাক)।
 */
object HadithLocalServer {
    const val HOST = "hadith-local.invalid"
    const val DIR_NAME = "hadith"
    private val NAME = Regex("^[a-z0-9_]+-v[0-9]+\\.json$")

    private val HEADERS = mapOf(
        "Access-Control-Allow-Origin" to "*",
        "Access-Control-Allow-Methods" to "GET, OPTIONS",
        "Access-Control-Allow-Headers" to "*",
        "Cache-Control" to "no-store"
    )

    fun intercept(context: Context, request: WebResourceRequest): WebResourceResponse? {
        val uri = request.url ?: return null
        if (!HOST.equals(uri.host, ignoreCase = true)) return null
        val name = uri.lastPathSegment ?: return null
        if (!NAME.matches(name)) return empty(404, "Not Found")
        if ("OPTIONS".equals(request.method, ignoreCase = true)) return empty(200, "OK")
        val f = File(File(context.filesDir, DIR_NAME), name)
        if (!f.exists() || f.length() <= 0L) return empty(404, "Not Found")
        return WebResourceResponse("application/json", "utf-8", 200, "OK", HEADERS, FileInputStream(f))
    }

    private fun empty(code: Int, reason: String) =
        WebResourceResponse("application/json", "utf-8", code, reason, HEADERS, ByteArrayInputStream(ByteArray(0)))
}
