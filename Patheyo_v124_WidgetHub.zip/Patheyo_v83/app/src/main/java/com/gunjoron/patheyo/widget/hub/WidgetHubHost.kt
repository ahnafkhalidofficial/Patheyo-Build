package com.gunjoron.patheyo.widget.hub

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.widget.data.HubPrefs

/**
 * উইজেট পেজে নেটিভ হাব বসানোর জায়গা।
 *
 * উইজেট পেজের হেডার (HTML) অপরিবর্তিত; তার নিচের অংশটা এই নেটিভ ভিউ ঢেকে দেয়। পেজের hub-host.js হেডারের নিচের
 * ফাঁকা জায়গার মাপ (স্ক্রিন-পিক্সেলে) ও থিম [show]-তে পাঠায়, পেজ বন্ধ/ঢাকা পড়লে [hide] ডাকে।
 * ডার্ক/লাইট বদলালে (পেজের থিম-বোতাম) হাব নতুন রঙে আবার তৈরি হয়; একই থিমে শুধু জায়গা/মাপ বদলায়।
 * সব মেথড মেইন থ্রেডে চলে (ব্রিজ runOnUiThread করে ডাকে)।
 */
class WidgetHubHost(private val act: Activity) {
    private val host: FrameLayout? = act.findViewById(R.id.widget_hub_host)
    private var screen: HubScreen? = null
    private var builtDark: Boolean? = null

    fun show(left: Int, top: Int, width: Int, height: Int, dark: Boolean, bgColor: Int) {
        val h = host ?: return
        if (width <= 0 || height <= 0) { hide(); return }
        if (screen == null || builtDark != dark) {
            HubPrefs.get(act).appDark = dark
            val s = HubScreen(act)
            h.removeAllViews()
            h.addView(s.build(), ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            screen = s; builtDark = dark
        }
        h.setBackgroundColor(bgColor)
        val wv = act.findViewById<View>(R.id.webview)   // JS-র মাপ WebView-র বাম-উপর থেকে
        val l = left + (wv?.left ?: 0); val t = top + (wv?.top ?: 0)
        val lp = h.layoutParams as ViewGroup.MarginLayoutParams
        if (lp.leftMargin != l || lp.topMargin != t || lp.width != width || lp.height != height) {
            lp.leftMargin = l; lp.topMargin = t; lp.width = width; lp.height = height
            h.layoutParams = lp
        }
        if (h.visibility != View.VISIBLE) {
            h.alpha = 0f
            h.visibility = View.VISIBLE
            h.animate().alpha(1f).setDuration(160L).start()
        }
    }

    fun hide() {
        val h = host ?: return
        if (h.visibility != View.VISIBLE) return
        h.animate().cancel()
        h.visibility = View.GONE
    }

    /** নামাজের সময়/হিজরি তারিখ বদলালে (অ্যাপের ডেটা এলে) প্রিভিউ নতুন তথ্যে আবার আঁকা */
    fun onDataChanged() { screen?.onDataChanged() }

    /** অ্যাপ বন্ধের সময় ভিউ ছেড়ে দেওয়া */
    fun release() { hide(); host?.removeAllViews(); screen = null; builtDark = null }
}
