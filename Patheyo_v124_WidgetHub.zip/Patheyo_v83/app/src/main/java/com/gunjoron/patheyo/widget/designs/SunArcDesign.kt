package com.gunjoron.patheyo.widget.designs

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import com.gunjoron.patheyo.widget.data.Snapshot
import com.gunjoron.patheyo.widget.WidgetRenderer.cardW
import com.gunjoron.patheyo.widget.assets.Fonts
import com.gunjoron.patheyo.widget.render.*
import com.gunjoron.patheyo.widget.theme.Look
import com.gunjoron.patheyo.widget.theme.PaletteMin
import com.gunjoron.patheyo.widget.theme.Palettes
import java.util.Calendar

/** ডিজাইন ৬ (সান-আর্ক): সূর্য/চাঁদ আর্ক + আনলক-অ্যানিমেশনের ফ্রেম আঁকা। */
internal object SunArcDesign {
    // ডিজাইন ৬-এর আকাশ-আর্ক: অর্ধ-উপবৃত্ত (চওড়া, গোল নয়)। অ্যানিমেশন ফ্রেমও একই ফাংশনে আঁকা।
    const val SKY_X0 = 30f; const val SKY_Y0 = 72f; const val SKY_W = 940f; const val SKY_H = 266f

    private const val SHC = 430f; private const val STOP = 118f; private const val SCY = 334f

    // চওড়া অগভীর বৃত্ত-চাপ: ভূমি-রেখায় cx±SHC, চূড়া y = STOP (পুরো উইজেট জুড়ে, নিচের দিকে ঢালু প্রান্ত)
    private val SH = SCY - STOP

    private val SR = (SHC * SHC + SH * SH) / (2f * SH)

    private val STH = Math.asin((SHC / SR).toDouble())

    private const val SUN_K = 0.8f; private const val MOON_R = 19f

    /** আকাশের পথ: পুরো উইজেট জুড়ে চওড়া অগভীর চাপ — দুই প্রান্ত ভূমি-রেখায়, চূড়া মাঝখানে; রেখার নিচে যায় না */
    private fun skyX(cx: Float, u: Double): Float =
        cx + SR * Math.sin(STH * (2.0 * u.coerceIn(0.0, 1.0) - 1.0)).toFloat()

    private fun skyY(cy: Float, u: Double): Float =
        (STOP + SR) - SR * Math.cos(STH * (2.0 * u.coerceIn(0.0, 1.0) - 1.0)).toFloat()

    /** fOv ≥ 0 হলে আর্কের ওপর ওই অনুপাতে (০..১) আইকন বসে (অ্যানিমেশন); নইলে এখনকার সময় অনুযায়ী। */
    private fun drawSky(c: Canvas, p: Paint, m: PaletteMin, lightText: Boolean, snap: Snapshot, nowMs: Long, fOv: Float) {
        val cx = cardW(6) / 2f; val cy = SCY
        val isDay = snap.sunsetMs > snap.sunriseMs && nowMs >= snap.sunriseMs && nowMs < snap.sunsetMs
        val a0 = if (isDay) snap.sunriseMs else snap.nightStartMs
        val a1 = if (isDay) snap.sunsetMs else snap.nightEndMs
        val f = if (fOv >= 0f) fOv.coerceIn(0f, 1f) else if (a1 > a0) ((nowMs - a0).toFloat() / (a1 - a0)).coerceIn(0f, 1f) else 0f
        val moonBody = if (lightText) 0xFFF4EEDC.toInt() else 0xFF2F4378.toInt()
        val nightGlow = if (lightText) 0xFFC9D6FF.toInt() else 0xFF3B4F8A.toInt()
        val lineCol = if (isDay) m.accent else moonBody      // আইকনের সাথে এক রঙ — দাগ আর চাঁদ একটাই টুকরো
        val u = if (isDay) f else 1f - f                     // বাঁ থেকে ডানে অবস্থান
        val n = 480
        val xs = FloatArray(n + 1); val ys = FloatArray(n + 1)
        for (i in 0..n) {
            xs[i] = skyX(cx, i.toDouble() / n); ys[i] = skyY(cy, i.toDouble() / n)
        }
        val ix = skyX(cx, u.toDouble()); val iy = skyY(cy, u.toDouble())
        val sgn = if (isDay) 1.0 else -1.0
        val tx = ((skyX(cx, u + 0.004) - skyX(cx, u - 0.004)) * sgn).toFloat()
        val ty = ((skyY(cy, u + 0.004) - skyY(cy, u - 0.004)) * sgn).toFloat()
        val gB = if (isDay) 28.5f * SUN_K + 3f else MOON_R           // পেছনের দাগ আইকনের কিনারায় থামে
        val gA = if (isDay) 28.5f * SUN_K + 6f else MOON_R + 5f  // সামনের ফিকে দাগ ফাঁক রেখে শুরু
        fun dist(i: Int) = Math.hypot((xs[i] - ix).toDouble(), (ys[i] - iy).toDouble()).toFloat()

        // পুরো আকাশ (দাগ, ট্র্যাক, আইকন) ভূমি-রেখার ওপরেই কাটা — গোল ক্যাপ বা আইকন রেখার নিচে নামে না
        c.save(); c.clipRect(-100f, -100f, cardW(6) + 100f, cy - 1f)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        // সামনের বাকি পথ: ফিকে ড্যাশ-রেখা (আইকনের দু'পাশে ফাঁক)
        p.strokeWidth = 3.5f; p.color = m.track
        var path = Path(); var open = false
        var acc = 0f
        for (i in 0..n) {
            if (i > 0) acc += Math.hypot((xs[i] - xs[i - 1]).toDouble(), (ys[i] - ys[i - 1]).toDouble()).toFloat()
            val on = dist(i) >= gA && (acc % 17f) < 7f
            if (on) { if (!open) { path.moveTo(xs[i], ys[i]); open = true } else path.lineTo(xs[i], ys[i]) }
            else if (open) { c.drawPath(path, p); path = Path(); open = false }
        }
        if (open) c.drawPath(path, p)
        // উজ্জ্বল অংশ: শুরু থেকে আইকনের কিনারা পর্যন্ত
        val ii = Math.round(u * n).coerceIn(0, n)
        path = Path(); var any = false
        if (isDay) {
            var e = ii; while (e > 0 && dist(e) < gB) e--
            if (e >= 1) { path.moveTo(xs[0], ys[0]); for (i in 1..e) path.lineTo(xs[i], ys[i]); any = true }
        } else {
            var s0 = ii; while (s0 < n && dist(s0) < gB) s0++
            if (s0 <= n - 1) { path.moveTo(xs[s0], ys[s0]); for (i in s0 + 1..n) path.lineTo(xs[i], ys[i]); any = true }
        }
        if (any) {
            // পেরিয়ে আসা পথের নিচে হালকা রঙের আভা (ভূমি-রেখা পর্যন্ত)
            val fillP = Path()
            // আভার কিনারা ঠিক সূর্য/চাঁদের কেন্দ্র বরাবর (আইকনের পেছনে) — আইকনের সাথে সাথে বাড়ে
            if (isDay) {
                fillP.moveTo(xs[0], cy)
                for (i in 0..n) { if (xs[i] >= ix) break; fillP.lineTo(xs[i], ys[i]) }
                fillP.lineTo(ix, iy); fillP.lineTo(ix, cy)
            } else {
                fillP.moveTo(ix, cy); fillP.lineTo(ix, iy)
                for (i in 0..n) { if (xs[i] > ix) fillP.lineTo(xs[i], ys[i]) }
                fillP.lineTo(xs[n], cy)
            }
            fillP.close()
            p.style = Paint.Style.FILL; p.color = (lineCol and 0xFFFFFF) or 0x16000000
            c.drawPath(fillP, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 5f; p.color = lineCol; c.drawPath(path, p)
        }
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL

        // সূর্য/চাঁদ ভূমি-রেখার নিচে দেখা যায় না — ওঠা/ডোবার সময় রেখার আড়াল থেকে ওঠে
        if (isDay) {
            c.save(); c.translate(ix, iy); c.scale(SUN_K, SUN_K)
            sun(c, p, 0f, 0f, m.accent, false)
            c.restore()
        } else {
            // কামড় চলার দিকে মুখ করে, তবে ৩০° ওপরের দিকে হেলানো — পেছনের গোল কিনারা দাগের সাথে মেলে, চাঁদ দেখতে স্বাভাবিক থাকে
            val th = Math.toDegrees(Math.atan2(ty.toDouble(), tx.toDouble()))
            var dd = (-90.0 - th) % 360.0; if (dd > 180.0) dd -= 360.0; if (dd < -180.0) dd += 360.0
            moon(c, p, ix, iy, MOON_R, nightGlow, moonBody, false, (th + (if (dd >= 0) 30.0 else -30.0)).toFloat())
        }
        c.restore()
    }

    /** অ্যানিমেশনের একটা ফ্রেম: শুধু আকাশ-অংশ (কার্ডের SKY_* এলাকা), q = বিটম্যাপের স্কেল। */
    fun drawSkyFrame(ctx: Context, c: Canvas, look: Look, snap: Snapshot, nowMs: Long, fAnim: Float, scale: Float) {
        Fonts.init(ctx)
        val m = Palettes.ofMin(look.variant)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.save(); c.scale(scale, scale); c.translate(-SKY_X0, -SKY_Y0)
        drawSky(c, p, m, lum(m.primary) > 150f, snap, nowMs, fAnim)
        c.restore()
    }

    /** আজকের আর্কে আইকনের চূড়ান্ত অনুপাত (০..১) — অ্যানিমেশন এখানে থামে। */
    fun skyFraction(snap: Snapshot, nowMs: Long): Float {
        val isDay = snap.sunsetMs > snap.sunriseMs && nowMs >= snap.sunriseMs && nowMs < snap.sunsetMs
        val a0 = if (isDay) snap.sunriseMs else snap.nightStartMs
        val a1 = if (isDay) snap.sunsetMs else snap.nightEndMs
        return if (a1 > a0) ((nowMs - a0).toFloat() / (a1 - a0)).coerceIn(0f, 1f) else 0f
    }

    /**
     * ডিজাইন ৬: চলমান ওয়াক্ত। স্বাভাবিক সময়ে "ইশা [চলমান]" + বাকি সময়; নিষিদ্ধ সময়ে "নিষিদ্ধ সময়" (লাল-কমলা) + বাকি সময়;
     * সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত নাম ও টাইমার দুটোতেই "–"।
     */
    private fun drawD6Current(c: Canvas, p: Paint, m: PaletteMin, lightText: Boolean, snap: Snapshot, nowMs: Long, live: Boolean, ov: Overlay, cx: Float) {
        val warn = if (lightText) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        when (snap.forbid) {
            2 -> {   // কোনো ওয়াক্ত নেই: নাম ও টাইমারে "–"
                text(c, p, "–", cx, 394f, 60f, m.secondary, Fonts.bold, Paint.Align.CENTER)
                text(c, p, "–", cx, 434f, 40f, m.secondary, Fonts.bold, Paint.Align.CENTER)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", cx, 394f, 52f, warn, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 520f, 434f, 34f, 32f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                val nsz = 52f
                val nw = measure(p, snap.currentName, Fonts.bold, nsz)
                val badge = "চলমান"
                val bsz = 27f
                val bw = measure(p, badge, Fonts.bold, bsz) + 34f
                val gap = 16f
                val x0 = cx - (nw + gap + bw) / 2f
                text(c, p, snap.currentName, x0, 394f, nsz, m.accent, Fonts.bold)
                val bx = x0 + nw + gap
                tile(c, p, bx, 355f, bx + bw, 397f, 21f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x80000000.toInt())
                text(c, p, badge, bx + bw / 2f, 385f, bsz, m.accent, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 520f, 434f, 34f, 32f, m.primary, m.primary)
            }
        }
    }

    fun draw(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, hideSky: Boolean) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(6)
        val L = 40f; val R = cw - 40f
        val cx = cw / 2f; val cy = SCY
        val rule = (m.primary and 0xFFFFFF) or 0x40000000
        val lightText = lum(m.primary) > 150f

        // ওপরের মাঝখানে লোগো: গোল বৃত্তের ভেতরে লোগোর পাথ
        logoRing(ctx, c, p, m, cx, 50f, 36f)

        // ওপরের কোণে তিন তারিখ: বাঁয়ে ইংরেজি + বাংলা, ডানে হিজরি (দুই লাইনে)
        text(c, p, snap.gregorianLine, L, 62f, 35f, m.secondary, Fonts.bold)
        text(c, p, snap.banglaLine, L, 106f, 35f, m.secondary, Fonts.bold)
        text(c, p, snap.hijriDay + " " + snap.hijriMonth, R, 62f, 35f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
        text(c, p, snap.hijriYear + " হিজরি", R, 106f, 35f, m.secondary, Fonts.bold, Paint.Align.RIGHT)

        // আর্ক (অর্ধ-উপবৃত্ত): দিনে সূর্যোদয় → সূর্যাস্ত (সূর্য, বাঁ থেকে ডানে); রাতে সূর্যাস্ত → পরদিন সূর্যোদয় (চাঁদ, ডান থেকে বাঁয়ে)
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(L, cy - 1f, R, cy + 1f, p)
        if (!hideSky) drawSky(c, p, m, lightText, snap, nowMs, -1f)

        // আর্কের ভেতরে ঘড়ি + AM/PM
        // ঘড়ি (ডানে-সারিবদ্ধ, আগের AM/PM-এর জায়গায় একটু নামানো) + ডানে AM/PM ও তার নিচে লাইভ সেকেন্ড
        val clockSize = 124f
        val clockEnd = cx + 139f            // "00:00"-এর মাপে গোটা গুচ্ছ মাঝখানে বসে; ডান কিনারা স্থির, তাই AM/PM-সেকেন্ড মিনিটের গা ঘেঁষে থাকে
        val hmNow = hmOf(nowMs)
        val clockW = measure(p, hmNow.substring(0, 2), Fonts.outfit, clockSize) + measure(p, ":", Fonts.outfit, clockSize) + measure(p, hmNow.substring(3), Fonts.outfit, clockSize)
        slimClock(c, p, hmNow, clockEnd - clockW, 308f, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", cx + 191f, 262f, 32f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(Calendar.getInstance().also { it.timeInMillis = nowMs }.get(Calendar.SECOND)), cx + 191f, 308f, 32f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ভূমি-রেখার নিচে: সূর্যোদয় | চলমান ওয়াক্ত + বাকি সময় (লাইভ) | সূর্যাস্ত
        text(c, p, "সূর্যোদয়", L, 382f, 31f, m.secondary, Fonts.regular, Paint.Align.LEFT)
        text(c, p, snap.sunrise, L, 432f, 50f, m.primary, Fonts.bold, Paint.Align.LEFT)
        text(c, p, "সূর্যাস্ত", R, 382f, 31f, m.secondary, Fonts.regular, Paint.Align.RIGHT)
        text(c, p, snap.iftar, R, 432f, 50f, m.primary, Fonts.bold, Paint.Align.RIGHT)
        drawD6Current(c, p, m, lightText, snap, nowMs, live, ov, cx)
    }
}
