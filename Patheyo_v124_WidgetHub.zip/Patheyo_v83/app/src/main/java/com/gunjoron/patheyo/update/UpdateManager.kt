package com.gunjoron.patheyo.update

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.withStarted
import com.gunjoron.patheyo.R
import kotlinx.coroutines.launch

/** MainActivity থেকে শুধু এই অবজেক্টের ২টি ফাংশন কল করলেই চলবে */
object UpdateManager {

    private var dialogShowing = false

    /** Activity-র onStart()-এ কল করুন */
    fun checkAndPrompt(activity: AppCompatActivity) {
        val app = activity.applicationContext
        activity.lifecycleScope.launch {
            val info = UpdateChecker.checkForUpdate(app) ?: return@launch
            if (dialogShowing || activity.isFinishing || activity.isDestroyed) return@launch
            if (!activity.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) return@launch

            // নোটিফিকেশন দেখানো হয়ে থাকলে (ইউজার সেটায় ট্যাপ করে এসেছে) → ডায়ালগ অবশ্যই দেখাবে
            val fromNotification = UpdatePrefs.consumeNotificationPending(app)
            if (fromNotification || info.mandatory || UpdatePrefs.shouldPrompt(app, info)) {
                showDialog(activity, info)
            }
        }
    }

    /**
     * v49: ওয়েবসাইটের "অ্যাপ আপডেট করুন" বাটন (patheyo://update লিংক) থেকে অ্যাপ খুললে এটা চলে।
     * সাধারণ চেকের মতো দিনে-২বারের সীমা মানে না — সাথে সাথে চেক করে ফল দেখায়:
     * নতুন ভার্সন থাকলে আপডেট পপআপ, না থাকলে "সর্বশেষ ভার্সনে আছেন" বার্তা।
     */
    fun checkNow(activity: AppCompatActivity) {
        val app = activity.applicationContext
        activity.lifecycleScope.launch {
            val latest = UpdateChecker.fetchLatest(app)
            if (activity.isFinishing || activity.isDestroyed) return@launch
            if (latest == null) {
                Toast.makeText(app, R.string.update_check_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (!UpdateChecker.isNewer(app, latest)) {
                Toast.makeText(app, R.string.update_latest_already, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (dialogShowing) return@launch
            try {
                activity.lifecycle.withStarted { }      // অ্যাপ পুরোপুরি সামনে আসা পর্যন্ত অপেক্ষা
                if (!dialogShowing && !activity.isFinishing && !activity.isDestroyed) showDialog(activity, latest)
            } catch (t: Throwable) {
                android.util.Log.e("PatheyoSafe", "checkNow failed", t)
            }
        }
    }

    /** Activity-র onResume()-এ কল করুন ("অজানা সোর্স" সেটিংস থেকে ফিরে এলে ডাউনলোড চালু করতে) */
    fun resumePending(activity: Activity) {
        val ctx = activity.applicationContext
        val (url, name) = UpdatePrefs.takePending(ctx) ?: return
        if (UpdateDownloader.canInstall(ctx)) beginDownload(activity, url, name)
    }

    private fun showDialog(activity: Activity, info: UpdateInfo) {
        UpdatePrefs.markPrompted(activity.applicationContext, info)
        dialogShowing = true
        // v47: পপআপ বানাতে সমস্যা হলে (lifecycleScope-এর ভেতরে) ক্র্যাশ না করে শুধু বন্ধ রাখা
        try {
            UpdateDialog.show(
                activity, info,
                onUpdate = { startUpdate(activity, info.apkUrl, info.versionName) },
                onDismiss = { dialogShowing = false }
            )
        } catch (t: Throwable) {
            dialogShowing = false
            android.util.Log.e("PatheyoSafe", "update popup failed", t)
        }
    }

    private fun startUpdate(activity: Activity, url: String, name: String) {
        val ctx = activity.applicationContext
        if (UpdateDownloader.canInstall(ctx)) {
            beginDownload(activity, url, name)
            return
        }
        // "অজানা অ্যাপ ইনস্টল" পারমিশন নেই → বুঝিয়ে সেটিংসে পাঠানো
        AlertDialog.Builder(activity)
            .setTitle(R.string.update_perm_title)
            .setMessage(R.string.update_perm_msg)
            .setPositiveButton(R.string.update_perm_go) { _, _ ->
                UpdatePrefs.savePending(ctx, url, name)
                activity.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                )
            }
            .setNegativeButton(R.string.update_perm_cancel, null)
            .show()
    }

    private fun beginDownload(activity: Activity, url: String, name: String) {
        val ctx = activity.applicationContext
        if (UpdateDownloader.isDownloading(ctx)) {
            Toast.makeText(ctx, R.string.update_already_downloading, Toast.LENGTH_SHORT).show()
            return
        }
        UpdateDownloader.start(ctx, url, name)
        Toast.makeText(ctx, R.string.update_downloading, Toast.LENGTH_LONG).show()
    }
}
