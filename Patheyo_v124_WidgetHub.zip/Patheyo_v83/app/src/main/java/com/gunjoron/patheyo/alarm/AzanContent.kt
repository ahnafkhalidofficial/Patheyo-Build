package com.gunjoron.patheyo.alarm

// v45: আজান পপআপ (ফুল-স্ক্রীন + নোটিফিকেশন) এর ওয়াক্ত-নাম ও লেখা এক জায়গায় — আগে একই "when" তিন জায়গায় কপি করা ছিল।
// ইনপুট যেকোনো রূপে আসতে পারে: ইংরেজি কী ("Fajr"), বাংলা নাম ("ফজর"), বা সার্ভিসের দেওয়া "জুম'আ"।

import android.app.KeyguardManager
import android.content.Context
import android.os.PowerManager
import java.util.Calendar

object AzanContent {

    /** এই আজান-সিকোয়েন্সে সর্বোচ্চ কতবার আজান বাজবে (প্রথমবার + ২ বার স্নুজ/অটো-রিপিট) */
    const val MAX_RINGS = 3

    /** স্নুজ / অটো-রিপিটের বিরতি */
    const val SNOOZE_MINUTES = 10

    /** ওয়াক্তের স্ট্যান্ডার্ড ইংরেজি কী ("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"); চেনা না গেলে null */
    fun key(raw: String?): String? = when (raw?.trim()) {
        "Fajr", "ফজর" -> "Fajr"
        "Dhuhr", "যোহর", "জোহর", "জুম'আ" -> "Dhuhr"
        "Asr", "আসর" -> "Asr"
        "Maghrib", "মাগরিব" -> "Maghrib"
        "Isha", "ইশা", "এশা" -> "Isha"
        else -> null
    }

    /** পপআপে দেখানোর বাংলা নাম — শুক্রবার যোহর = "জুম'আ" */
    fun label(raw: String?): String {
        val t = raw?.trim().orEmpty()
        return when (key(t)) {
            "Fajr" -> "ফজর"
            "Dhuhr" -> if (t == "জুম'আ" || isFriday()) "জুম'আ" else "যোহর"
            "Asr" -> "আসর"
            "Maghrib" -> "মাগরিব"
            "Isha" -> "ইশা"
            else -> if (t.isEmpty()) "নামাজ" else t
        }
    }

    /** "ফজরের", "জুম'আর", "এশার" ... (ষষ্ঠী বিভক্তি) */
    private fun possessive(label: String) = when (label) {
        "ফজর" -> "ফজরের"
        "যোহর" -> "যোহরের"
        "জুম'আ" -> "জুম'আর"
        "আসর" -> "আসরের"
        "মাগরিব" -> "মাগরিবের"
        "ইশা" -> "এশার"
        else -> "$label এর"
    }

    /** লম্বা শিরোনাম: "ফজরের নামাজের আজান হচ্ছে" */
    fun title(raw: String?): String = "${possessive(label(raw))} নামাজের আজান হচ্ছে"

    /** নোটিফিকেশনের ছোট শিরোনাম: "ফজরের আজান হচ্ছে" */
    fun shortTitle(raw: String?): String = "${possessive(label(raw))} আজান হচ্ছে"


    /**
     * v46: নামাজের প্রতি আহ্বান — প্রতি ওয়াক্তের জন্য একটা হাদিস/আয়াত (বাংলা অনুবাদ) ও তার সূত্র।
     * শুক্রবার যোহরের জায়গায় জুম'আর আয়াত।  ফেরত: (লেখা, সূত্র)
     */
    fun call(raw: String?): Pair<String, String> = when (label(raw)) {
        "ফজর" -> Pair(
            "“যে ব্যক্তি ফজরের নামাজ আদায় করে, সে আল্লাহর জিম্মায় থাকে।”",
            "— সহীহ মুসলিম ৬৫৭"
        )
        "যোহর" -> Pair(
            "নবী (সা.)-কে জিজ্ঞেস করা হলো, আল্লাহর কাছে সবচেয়ে প্রিয় আমল কোনটি? তিনি বললেন, “ওয়াক্তমতো নামাজ আদায় করা।”",
            "— সহীহ বুখারী ৫২৭"
        )
        "জুম'আ" -> Pair(
            "“হে মুমিনগণ! জুমার দিনে যখন নামাজের জন্য আহ্বান করা হয়, তখন তোমরা আল্লাহর স্মরণের দিকে ছুটে যাও এবং কেনাবেচা ছেড়ে দাও। এটাই তোমাদের জন্য উত্তম, যদি তোমরা জানতে।”",
            "— সূরা আল-জুমুআ ৬২:৯"
        )
        "আসর" -> Pair(
            "“যে ব্যক্তি দুই ঠান্ডা সময়ের নামাজ (ফজর ও আসর) আদায় করবে, সে জান্নাতে প্রবেশ করবে।”",
            "— সহীহ বুখারী ৫৭৪, সহীহ মুসলিম ৬৩৫"
        )
        "মাগরিব" -> Pair(
            "“আর তুমি নামাজ কায়েম করো দিনের দুই প্রান্তে এবং রাতের প্রথম অংশে। নিশ্চয়ই সৎকাজ অসৎকাজকে মিটিয়ে দেয়।”",
            "— সূরা হূদ ১১:১১৪"
        )
        "ইশা" -> Pair(
            "“যে ব্যক্তি জামাতের সাথে এশার নামাজ আদায় করল, সে যেন অর্ধরাত ইবাদতে কাটাল; আর যে ফজরও জামাতে আদায় করল, সে যেন পুরো রাত ইবাদতে কাটাল।”",
            "— সহীহ মুসলিম ৬৫৬"
        )
        else -> Pair(
            "“নিশ্চয়ই নামাজ মুমিনদের উপর নির্ধারিত সময়ে ফরজ করা হয়েছে।”",
            "— সূরা আন-নিসা ৪:১০৩"
        )
    }

    /**
     * v46: ফোন এখন লক / স্ক্রীন বন্ধ কিনা (কোনো কারণে জানা না গেলে true — তখন ফুল-স্ক্রীন পপআপই নিরাপদ)।
     * স্ক্রীন খোলা ও আনলক থাকলে false — তখন ফুল-স্ক্রীন নয়, শুধু নোটিফিকেশন-বারের পপআপ দেখানো হয়।
     */
    fun isLockedOrScreenOff(ctx: Context): Boolean = try {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
        (km?.isKeyguardLocked ?: true) || !(pm?.isInteractive ?: false)
    } catch (_: Throwable) { true }

    private fun isFriday() = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
}
