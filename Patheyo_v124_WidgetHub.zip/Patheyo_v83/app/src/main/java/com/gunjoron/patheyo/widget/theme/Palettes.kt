package com.gunjoron.patheyo.widget.theme

/**
 * রঙের টেবিল — আপনার উইজেট-ডিজাইন শিটের (Widget_Hub_v2.html) ১২টি কার্ড থেকে স্বয়ংক্রিয়ভাবে নেওয়া
 * (৩ ডিজাইন × গ্লাস/লাইট/ট্রান্সপারেন্ট-ডার্ক/ট্রান্সপারেন্ট-লাইট)। হাতে বদলাবেন না — রঙ বদলাতে চাইলে এখানেই
 * ঠিক করুন, রেন্ডারার সরাসরি এগুলোই পড়ে। cardFill/cardStroke = 0 মানে কার্ড নেই (ট্রান্সপারেন্ট)।
 */
enum class Variant { GLASS, LIGHT, NOBG_DARK, NOBG_LIGHT }

/** ডিজাইন ১ ও ২-এর রঙ। */
class Palette12(
    val cardFill: Int, val cardStroke: Int,
    val day: Int, val hijri: Int, val date: Int, val divider: Int,
    val name: Int, val time: Int, val hlFill: Int, val hlText: Int,
    val now: Int, val nowTime: Int, val pillLabel: Int, val pillTime: Int,
    val clock: Int, val pm: Int
)

/** ডিজাইন ৩-এর রঙ। */
class Palette3(
    val cardFill: Int, val cardStroke: Int,
    val day: Int, val month: Int, val prayer: Int, val badgeText: Int,
    val subLabel: Int, val subTime: Int, val clock: Int
)

/** ডিজাইন ৪ ও ৫ (মিনিমাল) — একই রঙ-সেট। accent = চলমান ওয়াক্ত/প্রগ্রেস, track = প্রগ্রেসের ফাঁকা অংশ। */
class PaletteMin(
    val cardFill: Int, val cardStroke: Int,
    val primary: Int, val secondary: Int, val accent: Int, val track: Int
)

object Palettes {
    val MIN_GLASS = PaletteMin(0xFF0B1220.toInt(), 0x38FFFFFF, 0xFFFFFFFF.toInt(), 0xB3FFFFFF.toInt(), 0xFFF5C26B.toInt(), 0x2EFFFFFF)
    val MIN_LIGHT = PaletteMin(0xFFE6E6E4.toInt(), 0x24000000, 0xFF1B1B1A.toInt(), 0xFF3A3A38.toInt(), 0xFF0A61A0.toInt(), 0x26000000)
    val MIN_NOBG_DARK = PaletteMin(0, 0, 0xFFFFFFFF.toInt(), 0xBFFFFFFF.toInt(), 0xFFF5C26B.toInt(), 0x38FFFFFF)
    val MIN_NOBG_LIGHT = PaletteMin(0, 0, 0xFF1B1B1A.toInt(), 0xFF2E2E2C.toInt(), 0xFF0A61A0.toInt(), 0x33000000)
    fun ofMin(v: Variant): PaletteMin = when (v) {
        Variant.GLASS -> MIN_GLASS; Variant.LIGHT -> MIN_LIGHT
        Variant.NOBG_DARK -> MIN_NOBG_DARK; Variant.NOBG_LIGHT -> MIN_NOBG_LIGHT
    }

    val D1_GLASS = Palette12(cardFill=0xFF0B1220.toInt(), cardStroke=0xFFC6C6C5.toInt(), day=0xFFFFFFFF.toInt(), hijri=0xFFFFFFFF.toInt(), date=0xFFFFFFFF.toInt(), divider=0xFFB2B2B2.toInt(), name=0xFFFFFFFF.toInt(), time=0xFFFFFFFF.toInt(), hlFill=0xFFDADADA.toInt(), hlText=0xFF0B1220.toInt(), now=0xFFFFFFFF.toInt(), nowTime=0xFFFFFFFF.toInt(), pillLabel=0xFFFFFFFF.toInt(), pillTime=0xFFFFFFFF.toInt(), clock=0xFFFFFFFF.toInt(), pm=0xFFFFFFFF.toInt())
    val D1_LIGHT = Palette12(cardFill=0xFFDADADA.toInt(), cardStroke=0xFF575756.toInt(), day=0xFF000000.toInt(), hijri=0xFF000000.toInt(), date=0xFF3C3C3B.toInt(), divider=0xFF3C3C3B.toInt(), name=0xFF3C3C3B.toInt(), time=0xFF3C3C3B.toInt(), hlFill=0xFF3C3C3B.toInt(), hlText=0xFFF6F6F6.toInt(), now=0xFF3C3C3B.toInt(), nowTime=0xFF3C3C3B.toInt(), pillLabel=0xFF3C3C3B.toInt(), pillTime=0xFF3C3C3B.toInt(), clock=0xFF1B3A5C.toInt(), pm=0xFF3C3C3B.toInt())
    val D1_NOBG_DARK = Palette12(cardFill=0, cardStroke=0, day=0xFFFFFFFF.toInt(), hijri=0xFFFFFFFF.toInt(), date=0xFFFFFFFF.toInt(), divider=0xFFB2B2B2.toInt(), name=0xFFFFFFFF.toInt(), time=0xFFFFFFFF.toInt(), hlFill=0xFFDADADA.toInt(), hlText=0xFF0B1220.toInt(), now=0xFFFFFFFF.toInt(), nowTime=0xFFFFFFFF.toInt(), pillLabel=0xFFFFFFFF.toInt(), pillTime=0xFFFFFFFF.toInt(), clock=0xFFFFFFFF.toInt(), pm=0xFFFFFFFF.toInt())
    val D1_NOBG_LIGHT = Palette12(cardFill=0, cardStroke=0, day=0xFF000000.toInt(), hijri=0xFF000000.toInt(), date=0xFF3C3C3B.toInt(), divider=0xFF3C3C3B.toInt(), name=0xFF3C3C3B.toInt(), time=0xFF3C3C3B.toInt(), hlFill=0xFF3C3C3B.toInt(), hlText=0xFFF6F6F6.toInt(), now=0xFF3C3C3B.toInt(), nowTime=0xFF3C3C3B.toInt(), pillLabel=0xFF3C3C3B.toInt(), pillTime=0xFF3C3C3B.toInt(), clock=0xFF1B3A5C.toInt(), pm=0xFF3C3C3B.toInt())
    val D2_GLASS = Palette12(cardFill=0xFF0B1220.toInt(), cardStroke=0xFFC6C6C5.toInt(), day=0xFFFFFFFF.toInt(), hijri=0xFFFFFFFF.toInt(), date=0xFFFFFFFF.toInt(), divider=0xFFB2B2B2.toInt(), name=0xFFFFFFFF.toInt(), time=0xFFFFFFFF.toInt(), hlFill=0xFFDADADA.toInt(), hlText=0xFF0B1220.toInt(), now=0xFFFFFFFF.toInt(), nowTime=0xFFFFFFFF.toInt(), pillLabel=0xFFFFFFFF.toInt(), pillTime=0xFFFFFFFF.toInt(), clock=0, pm=0)
    val D2_LIGHT = Palette12(cardFill=0xFFDADADA.toInt(), cardStroke=0xFF575756.toInt(), day=0xFF000000.toInt(), hijri=0xFF000000.toInt(), date=0xFF3C3C3B.toInt(), divider=0xFF3C3C3B.toInt(), name=0xFF3C3C3B.toInt(), time=0xFF3C3C3B.toInt(), hlFill=0xFF3C3C3B.toInt(), hlText=0xFFF6F6F6.toInt(), now=0xFF3C3C3B.toInt(), nowTime=0xFF3C3C3B.toInt(), pillLabel=0xFF3C3C3B.toInt(), pillTime=0xFF3C3C3B.toInt(), clock=0, pm=0)
    val D2_NOBG_DARK = Palette12(cardFill=0, cardStroke=0, day=0xFFFFFFFF.toInt(), hijri=0xFFFFFFFF.toInt(), date=0xFFFFFFFF.toInt(), divider=0xFFB2B2B2.toInt(), name=0xFFFFFFFF.toInt(), time=0xFFFFFFFF.toInt(), hlFill=0xFFDADADA.toInt(), hlText=0xFF0B1220.toInt(), now=0xFFFFFFFF.toInt(), nowTime=0xFFFFFFFF.toInt(), pillLabel=0xFFFFFFFF.toInt(), pillTime=0xFFFFFFFF.toInt(), clock=0, pm=0)
    val D2_NOBG_LIGHT = Palette12(cardFill=0, cardStroke=0, day=0xFF000000.toInt(), hijri=0xFF000000.toInt(), date=0xFF3C3C3B.toInt(), divider=0xFF3C3C3B.toInt(), name=0xFF3C3C3B.toInt(), time=0xFF3C3C3B.toInt(), hlFill=0xFF3C3C3B.toInt(), hlText=0xFFF6F6F6.toInt(), now=0xFF3C3C3B.toInt(), nowTime=0xFF3C3C3B.toInt(), pillLabel=0xFF3C3C3B.toInt(), pillTime=0xFF3C3C3B.toInt(), clock=0, pm=0)
    val D3_GLASS = Palette3(cardFill=0xFF0B1220.toInt(), cardStroke=0xFFC6C6C5.toInt(), day=0xFFFFED00.toInt(), month=0xFFFFFFFF.toInt(), prayer=0xFFFFED00.toInt(), badgeText=0xFF000000.toInt(), subLabel=0xFFFFFFFF.toInt(), subTime=0xFFFFFFFF.toInt(), clock=0xFFFFFFFF.toInt())
    val D3_LIGHT = Palette3(cardFill=0xFFDADADA.toInt(), cardStroke=0xFF575756.toInt(), day=0xFF0A61A0.toInt(), month=0xFF3C3C3B.toInt(), prayer=0xFF0A61A0.toInt(), badgeText=0xFF000000.toInt(), subLabel=0xFF3C3C3B.toInt(), subTime=0xFF3C3C3B.toInt(), clock=0xFF3C3C3B.toInt())
    val D3_NOBG_DARK = Palette3(cardFill=0, cardStroke=0, day=0xFFFFED00.toInt(), month=0xFFFFFFFF.toInt(), prayer=0xFFFFED00.toInt(), badgeText=0xFF000000.toInt(), subLabel=0xFFFFFFFF.toInt(), subTime=0xFFFFFFFF.toInt(), clock=0xFFFFFFFF.toInt())
    val D3_NOBG_LIGHT = Palette3(cardFill=0, cardStroke=0, day=0xFF0A61A0.toInt(), month=0xFF3C3C3B.toInt(), prayer=0xFF0A61A0.toInt(), badgeText=0xFF000000.toInt(), subLabel=0xFF3C3C3B.toInt(), subTime=0xFF3C3C3B.toInt(), clock=0xFF3C3C3B.toInt())

    fun of12(design: Int, v: Variant): Palette12 = if (design == 1) when (v) {
        Variant.GLASS -> D1_GLASS; Variant.LIGHT -> D1_LIGHT
        Variant.NOBG_DARK -> D1_NOBG_DARK; Variant.NOBG_LIGHT -> D1_NOBG_LIGHT
    } else when (v) {
        Variant.GLASS -> D2_GLASS; Variant.LIGHT -> D2_LIGHT
        Variant.NOBG_DARK -> D2_NOBG_DARK; Variant.NOBG_LIGHT -> D2_NOBG_LIGHT
    }

    fun of3(v: Variant): Palette3 = when (v) {
        Variant.GLASS -> D3_GLASS; Variant.LIGHT -> D3_LIGHT
        Variant.NOBG_DARK -> D3_NOBG_DARK; Variant.NOBG_LIGHT -> D3_NOBG_LIGHT
    }
}
