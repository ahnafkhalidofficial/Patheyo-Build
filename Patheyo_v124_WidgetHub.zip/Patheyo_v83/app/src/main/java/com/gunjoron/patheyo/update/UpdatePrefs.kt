package com.gunjoron.patheyo.update

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * পপআপ/নোটিফিকেশন কতবার দেখানো হবে তার হিসাব এখানে।
 *
 * নিয়ম:
 *  ১) নতুন ভার্সন প্রথমবার ধরা পড়লেই → সাথে সাথে দেখাবে।
 *  ২) এরপর প্রতিদিন সর্বোচ্চ MAX_PER_DAY বার, দুইবারের মাঝে কমপক্ষে MIN_GAP_MS ব্যবধান।
 *  ৩) ইউজার আপডেট করে ফেললে (versionCode বেড়ে গেলে) আর কিছুই দেখাবে না।
 */
object UpdatePrefs {

    const val MAX_PER_DAY = 2                      // ✏️ দিনে সর্বোচ্চ কতবার
    const val MIN_GAP_MS = 3L * 60 * 60 * 1000     // ✏️ দুইবারের মাঝে ন্যূনতম ব্যবধান (৩ ঘণ্টা)

    private const val FILE = "patheyo_update_prefs"
    private const val K_VERSION = "last_prompted_version"
    private const val K_DAY = "prompt_day"
    private const val K_COUNT = "prompt_count_today"
    private const val K_LAST_TIME = "last_prompt_time"
    private const val K_NOTIF_PENDING = "notification_pending"
    private const val K_DOWNLOAD_ID = "download_id"
    private const val K_PENDING_URL = "pending_url"
    private const val K_PENDING_NAME = "pending_name"
    private const val K_PUSHED = "pushed_update"

    private fun p(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun shouldPrompt(ctx: Context, info: UpdateInfo): Boolean {
        val p = p(ctx)
        if (p.getLong(K_VERSION, 0L) != info.versionCode) return true // নতুন ভার্সনের প্রথমবার
        val count = if (p.getString(K_DAY, "") == today()) p.getInt(K_COUNT, 0) else 0
        val gapOk = System.currentTimeMillis() - p.getLong(K_LAST_TIME, 0L) >= MIN_GAP_MS
        return count < MAX_PER_DAY && gapOk
    }

    fun markPrompted(ctx: Context, info: UpdateInfo) {
        val p = p(ctx)
        val sameVersion = p.getLong(K_VERSION, 0L) == info.versionCode
        val sameDay = p.getString(K_DAY, "") == today()
        val count = if (sameVersion && sameDay) p.getInt(K_COUNT, 0) else 0
        p.edit()
            .putLong(K_VERSION, info.versionCode)
            .putString(K_DAY, today())
            .putInt(K_COUNT, count + 1)
            .putLong(K_LAST_TIME, System.currentTimeMillis())
            .apply()
    }

    // ---- নোটিফিকেশন দেখানো হয়েছে, অ্যাপ খুললে ডায়ালগ দেখাতে হবে ----
    fun setNotificationPending(ctx: Context, v: Boolean) =
        p(ctx).edit().putBoolean(K_NOTIF_PENDING, v).apply()

    fun consumeNotificationPending(ctx: Context): Boolean {
        val v = p(ctx).getBoolean(K_NOTIF_PENDING, false)
        if (v) setNotificationPending(ctx, false)
        return v
    }

    // ---- DownloadManager ID ----
    fun getDownloadId(ctx: Context) = p(ctx).getLong(K_DOWNLOAD_ID, -1L)
    fun setDownloadId(ctx: Context, id: Long) = p(ctx).edit().putLong(K_DOWNLOAD_ID, id).apply()

    // ---- "অজানা সোর্স" পারমিশন দিতে সেটিংসে গেলে আপডেটের তথ্য মনে রাখা ----
    fun savePending(ctx: Context, url: String, name: String) =
        p(ctx).edit().putString(K_PENDING_URL, url).putString(K_PENDING_NAME, name).apply()

    fun takePending(ctx: Context): Pair<String, String>? {
        val p = p(ctx)
        val url = p.getString(K_PENDING_URL, null) ?: return null
        val name = p.getString(K_PENDING_NAME, "") ?: ""
        p.edit().remove(K_PENDING_URL).remove(K_PENDING_NAME).apply()
        return url to name
    }

    // ---- v49: FCM পুশে (ওয়েবসাইট/GitHub থেকে) আসা নতুন ভার্সনের তথ্য ----
    fun savePushed(ctx: Context, info: UpdateInfo) {
        try {
            val o = org.json.JSONObject()
                .put("versionCode", info.versionCode).put("versionName", info.versionName)
                .put("apkUrl", info.apkUrl).put("notes", info.releaseNotes)
                .put("sizeMb", info.sizeMb).put("mandatory", info.mandatory).put("codeKnown", info.codeKnown)
            p(ctx).edit().putString(K_PUSHED, o.toString()).apply()
        } catch (_: Throwable) {}
    }

    /** সেভ করা পুশ-তথ্য; ইউজার ততদিনে আপডেট করে ফেললে মুছে দিয়ে null */
    fun getPushed(ctx: Context): UpdateInfo? {
        val raw = p(ctx).getString(K_PUSHED, null) ?: return null
        return try {
            val o = org.json.JSONObject(raw)
            val info = UpdateInfo(
                o.getLong("versionCode"), o.getString("versionName"), o.getString("apkUrl"),
                o.optString("notes", ""), o.optInt("sizeMb", 0), o.optBoolean("mandatory", false),
                o.optBoolean("codeKnown", true)
            )
            if (UpdateChecker.isNewer(ctx, info)) info
            else { p(ctx).edit().remove(K_PUSHED).apply(); null }
        } catch (_: Throwable) { null }
    }
}
