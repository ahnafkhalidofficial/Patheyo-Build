package com.gunjoron.patheyo.widget.data

import com.gunjoron.patheyo.FirebaseDataManager

/** বাংলা সংখ্যা ও মাসের নাম (উইজেটের জন্য)। */
object Bn {
    /** ইংরেজি অঙ্ক → বাংলা অঙ্ক (অ্যাপের একই রূপান্তর-ফাংশন, আলাদা কপি নেই) */
    fun digits(s: String): String = FirebaseDataManager.convertEnglishToBengali(s)

    fun digits(n: Int): String = digits(n.toString())

    fun pad2(n: Int): String = if (n < 10) "0$n" else n.toString()

    val GREG_MONTHS = arrayOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    // বাংলাদেশ সংশোধিত পঞ্জিকা (বৈশাখ = ১৪ এপ্রিল)
    val BANGLA_MONTHS = arrayOf(
        "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
        "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
    )

    val PRAYER_NAMES = arrayOf("ফজর", "যোহর", "আসর", "মাগরিব", "ইশা")
}
