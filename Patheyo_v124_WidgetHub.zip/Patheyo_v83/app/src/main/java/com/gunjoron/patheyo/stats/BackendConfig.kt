package com.gunjoron.patheyo.stats

/**
 * v49: ওয়েবসাইটের অ্যাডমিন প্যানেলের (Supabase) সাথে অ্যাপের সংযোগ।
 *
 * এই দুটি মান ওয়েবসাইটের patheyo/config.js-এর SUPABASE_URL ও SUPABASE_ANON_KEY-এর হুবহু একই হবে।
 * (anon key পাবলিক কী — অ্যাপে রাখা নিরাপদ। service_role key কখনো এখানে দেবেন না।)
 *
 * খালি রাখলে ইউজার-গণনা বন্ধ থাকবে, কিন্তু অ্যাপের বাকি সব কিছু আগের মতোই চলবে।
 */
object BackendConfig {
    const val SUPABASE_URL = "https://zullugdawmkajmzxwrwx.supabase.co"        // যেমন: "https://abcdxyz.supabase.co"
    const val SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1bGx1Z2Rhd21rYWptenh3cnd4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTEzNjIyOTQsImV4cCI6MjEwNjkzODI5NH0.CUrhF4YHcVuxgvvXeSbY2SExI2rbiTdHiIgynPIBZmc"   // Supabase → Project Settings → API → anon public

    fun enabled(): Boolean =
        SUPABASE_URL.startsWith("https://") && SUPABASE_ANON_KEY.length > 20
}
