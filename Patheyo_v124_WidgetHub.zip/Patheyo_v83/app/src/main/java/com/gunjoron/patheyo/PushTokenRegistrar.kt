package com.gunjoron.patheyo

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.firebase.messaging.FirebaseMessaging
import com.gunjoron.patheyo.stats.AppHeartbeat
import com.gunjoron.patheyo.stats.BackendConfig
import com.gunjoron.patheyo.update.UpdateChecker
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * v65: এই ফোনের FCM token Supabase-এ জমা দেয় (register_push_token RPC).
 * ওয়েবসাইটের send-push এই token-এ সরাসরি পাঠায়, তাই topic-এর দেরি লাগে না।
 * ডুপ্লিকেট রোধে push_id দিয়ে একই নোটিফিকেশন দুইবার দেখানো বন্ধ করে।
 */
object PushTokenRegistrar {
    private const val PREFS = "patheyo_push"
    private const val KEY_SEEN = "seen_push_ids"
    private const val MAX_SEEN = 80

    /** অ্যাপ শুরুতে ও token বদলালে কল করুন। মূল থ্রেড ব্লক করে না। */
    fun register(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            try { registerBlocking(app) } catch (_: Throwable) { }
        }.start()
    }

    private fun registerBlocking(ctx: Context) {
        if (!BackendConfig.enabled()) return
        val token: String = Tasks.await(FirebaseMessaging.getInstance().token, 20, TimeUnit.SECONDS) ?: return
        if (token.isBlank()) return
        val body = JSONObject()
            .put("p_installation", AppHeartbeat.installationId(ctx))
            .put("p_token", token)
            .put("p_version", UpdateChecker.installedVersionName(ctx))
        val conn = (URL(BackendConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/rpc/register_push_token")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 15000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", BackendConfig.SUPABASE_ANON_KEY)
            setRequestProperty("Authorization", "Bearer " + BackendConfig.SUPABASE_ANON_KEY)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            android.util.Log.d("PatheyoFCM", "token registered, http=${conn.responseCode}")
        } finally {
            conn.disconnect()
        }
    }

    /** true = এই push_id আগে দেখা হয়েছে (ডুপ্লিকেট, দেখাবেন না) */
    @Synchronized
    fun seenBefore(ctx: Context, pushId: String): Boolean {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val list = sp.getString(KEY_SEEN, "").orEmpty().split(",").filter { it.isNotEmpty() }.toMutableList()
        if (list.contains(pushId)) return true
        list.add(pushId)
        while (list.size > MAX_SEEN) list.removeAt(0)
        sp.edit().putString(KEY_SEEN, list.joinToString(",")).apply()
        return false
    }
}
