package com.gunjoron.patheyo

// app/src/main/java/com/gunjoron/Patheyo/PatheyoMessagingService.kt
//
// অ্যাপ সম্পূর্ণ বন্ধ থাকলেও FCM push পেলে এই service জেগে ওঠে।
// Firebase Console → Engage → Messaging (Cloud Messaging) থেকে push পাঠালে এখানে আসবে।
// অ্যাপ সাবস্ক্রাইব করা আছে "all" ও "prayer_updates" টপিকে (MainActivity.kt দেখুন)।
//
// তিন রকম push সাপোর্ট করে (data payload-এর "update_type" key অনুযায়ী):
//   ১) update_type = hijri_config          → আরবি তারিখ/এডজাস্টমেন্ট সংশোধন
//   ২) update_type = notifications_config  → Remote Config থেকে JSON সাথে সাথে রিফ্রেশ
//   ২ক) update_type = app_update           → (v49) নতুন অ্যাপ ভার্সন এসেছে: "আপডেট করুন" নোটিফিকেশন
//                                             (GitHub Release দিলে অটো / অ্যাডমিন প্যানেল থেকে হাতে পাঠানো)
//   ৩) অন্য কিছু / খালি                    → সাধারণ ঘোষণা নোটিফিকেশন (title+message,
//                                             ঐচ্ছিক link ও image) — ফোরগ্রাউন্ডেও দেখাবে
//
// বিস্তারিত বাংলা নির্দেশিকা: FIREBASE_NOTIFICATION_NIRDESHIKA.md (প্রজেক্ট রুটে)

import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.gunjoron.patheyo.notification.NotificationRemoteConfigSync
import com.gunjoron.patheyo.notification.ScheduledNotificationScheduler
import com.gunjoron.patheyo.update.NotificationHelper
import com.gunjoron.patheyo.update.UpdateChecker
import com.gunjoron.patheyo.update.UpdatePrefs

class PatheyoMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        // v65: একই push দুই রুটে (topic + token) এলে একবারই দেখাবে
        val pushId = remoteMessage.data["push_id"]
        if (!pushId.isNullOrBlank() && PushTokenRegistrar.seenBefore(applicationContext, pushId)) return

        val updateType = remoteMessage.data["update_type"]

        when (updateType) {
            "hijri_config" -> {
                val hijriDate = remoteMessage.data["hijri_date"]
                val adjStr = remoteMessage.data["hijri_adjustment"]
                val adj = adjStr?.toIntOrNull()

                if (!hijriDate.isNullOrBlank() || adj != null) {
                    FirebaseDataManager.applyRemoteUpdate(applicationContext, adj, hijriDate)
                }

                // RTDB listener-ও চালু রাখা — পরবর্তী sync-এর জন্য
                FirebaseDataManager.startRtdbListener(applicationContext)
            }

            "notifications_config" -> {
                // Remote Config-এ notifications_config_json বদলে Publish করার পর এই
                // এক্সট্রা key সহ একটা push পাঠালে ইউজারের ফোনে ঘণ্টার অপেক্ষা ছাড়াই
                // সাথে সাথে নতুন কনফিগ প্রয়োগ হয়ে যাবে
                NotificationRemoteConfigSync.fetchAndApply(applicationContext) { updated ->
                    if (updated) {
                        ScheduledNotificationScheduler.scheduleAllNotifications(applicationContext)
                    }
                }
            }

            "app_update" -> {
                try { handleAppUpdatePush(remoteMessage.data) } catch (t: Throwable) {
                    android.util.Log.e("PatheyoFCM", "app_update push failed", t)
                }
            }

            else -> {
                // Firebase Console-এর সাধারণ "Notification message" (title/body) অথবা
                // কাস্টম data payload (title/message/link/image) — দুটোই এখানে ধরা হচ্ছে।
                // এভাবে করাতে অ্যাপ ফোরগ্রাউন্ডে খোলা থাকলেও নোটিফিকেশন দেখাবে (আগে শুধু
                // ব্যাকগ্রাউন্ডে থাকলে সিস্টেম নিজে থেকে দেখাত, ফোরগ্রাউন্ডে কিছুই হতো না)
                // ✅ ওয়েবসাইট/অ্যাডমিন প্যানেল থেকে আসা পুশ ঠিকমতো ধরতে: পাঠানোর ফরম্যাট যেমনই হোক
                // (title/message, title/body, text, url/link, image_url...) সবই চেনা হয়।
                // আগে শুধু "title" ও "message" key থাকলেই দেখাত — ওয়েবসাইট "body" বা অন্য নামে
                // পাঠালে মেসেজ নিঃশব্দে বাদ পড়ত (ওয়েবসাইটে "সফল" দেখালেও ফোনে আসত না)।
                val d = remoteMessage.data
                fun pick(vararg keys: String): String? =
                    keys.asSequence().mapNotNull { d[it]?.trim() }.firstOrNull { it.isNotEmpty() }

                val n = remoteMessage.notification
                var title = n?.title?.takeIf { it.isNotBlank() }
                    ?: pick("title", "notification_title", "heading", "subject", "headline")
                var message = n?.body?.takeIf { it.isNotBlank() }
                    ?: pick("message", "body", "text", "content", "msg", "description", "notification_body", "details")

                // শুধু একটা থাকলেও দেখাও (আগে দুটো না থাকলে বাদ যেত)
                if (title.isNullOrBlank() && !message.isNullOrBlank()) title = "পাথেয়"
                if (message.isNullOrBlank() && !title.isNullOrBlank()) { message = title; title = "পাথেয়" }

                if (!title.isNullOrBlank() && !message.isNullOrBlank()) {
                    val link = pick("link", "url", "click_action", "target_url", "open_url") ?: ""
                    val image = pick("image", "image_url", "imageUrl", "img", "picture", "photo")
                        ?: n?.imageUrl?.toString()
                        ?: ""

                    ScheduledNotificationScheduler.showNotification(
                        context = applicationContext,
                        title = title,
                        message = message,
                        link = link,
                        image = image
                    )
                } else {
                    android.util.Log.w("PatheyoFCM", "push পাওয়া গেছে কিন্তু দেখানোর মতো টেক্সট নেই; data keys=${d.keys}")
                }
            }
        }
    }

    /**
     * v49: নতুন ভার্সনের পুশ। data: version_name, apk_url, notes (ঐচ্ছিক), size_mb (ঐচ্ছিক), mandatory (ঐচ্ছিক)।
     * ইনস্টল করা ভার্সনের চেয়ে নতুন হলেই নোটিফিকেশন দেখায়; ট্যাপ করলে অ্যাপ খুলে আপডেট পপআপ আসে।
     */
    private fun handleAppUpdatePush(d: Map<String, String>) {
        val name = d["version_name"] ?: return
        val apk = d["apk_url"] ?: return
        val info = UpdateChecker.infoFromName(
            name = name,
            apkUrl = apk,
            notes = d["notes"] ?: "",
            sizeMb = d["size_mb"]?.toIntOrNull() ?: 0,
            mandatory = d["mandatory"] == "true"
        )
        val ctx = applicationContext
        if (!UpdateChecker.isNewer(ctx, info)) return          // আগেই আপডেট করা আছে
        UpdatePrefs.savePushed(ctx, info)                       // অ্যাপ খুললে এই তথ্য দিয়েই পপআপ দেখাবে
        if (NotificationHelper.showUpdateAvailable(ctx, info)) {
            UpdatePrefs.markPrompted(ctx, info)
            UpdatePrefs.setNotificationPending(ctx, true)
        }
    }

    override fun onNewToken(token: String) {
        // ✅ v30: নতুন টোকেন পেলে (নতুন ইন্সটল / ডেটা ক্লিয়ার / রিস্টোর) টপিকে আবার সাবস্ক্রাইব
        // নিশ্চিত করা হচ্ছে, যাতে Console-এর "prayer_updates" টপিক-টার্গেটে মেসেজ ঠিকই পৌঁছায়।
        subscribeAll()
        try { syncVersionTopic(applicationContext, force = true) } catch (_: Throwable) {}
        // v65: নতুন token Supabase-এ পাঠান
        PushTokenRegistrar.register(applicationContext)
    }

    companion object {
        /** সব ইউজারকে মেসেজ পাঠানোর টপিক (Console/GitHub Release অটোমেশনে "all") */
        const val TOPIC_ALL = "all"
        /** আগের টপিক — পুরনো কনফিগ/নির্দেশিকার সাথে সামঞ্জস্যের জন্য রাখা হলো */
        const val TOPIC = "prayer_updates"

        /**
         * v49: ভার্সন-ভিত্তিক টপিক ("ver_1_6_0")। অ্যাডমিন প্যানেল থেকে "শুধু নির্দিষ্ট ভার্সনের ইউজারকে"
         * নোটিফিকেশন পাঠাতে লাগে। অ্যাপ আপডেট হলে পুরোনো ভার্সনের টপিক ছেড়ে নতুনটায় ঢোকে।
         */
        fun versionTopic(versionName: String): String =
            "ver_" + versionName.replace(Regex("[^A-Za-z0-9_]"), "_")

        fun syncVersionTopic(ctx: android.content.Context, force: Boolean = false) {
            val name = UpdateChecker.installedVersionName(ctx)
            if (name.isBlank()) return
            val cur = versionTopic(name)
            val sp = ctx.getSharedPreferences("patheyo_stats", android.content.Context.MODE_PRIVATE)
            val old = sp.getString("ver_topic", null)
            if (old == cur && !force) return
            try {
                if (old != null && old != cur) FirebaseMessaging.getInstance().unsubscribeFromTopic(old)
                FirebaseMessaging.getInstance().subscribeToTopic(cur).addOnSuccessListener {
                    sp.edit().putString("ver_topic", cur).apply()
                }
            } catch (_: Throwable) {}
        }

        fun subscribeAll() {
            for (t in listOf(TOPIC_ALL, TOPIC)) {
                try {
                    FirebaseMessaging.getInstance().subscribeToTopic(t).addOnCompleteListener { r ->
                        android.util.Log.d("PatheyoFCM", if (r.isSuccessful) "subscribed: $t" else "subscribe failed: $t ${r.exception?.message}")
                    }
                } catch (_: Throwable) {}
            }
        }
    }
}
