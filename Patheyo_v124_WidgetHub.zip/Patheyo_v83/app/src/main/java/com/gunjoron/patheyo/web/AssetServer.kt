package com.gunjoron.patheyo.web

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.IOException

/**
 * ফিচার পেজগুলোর (assets/features/<নাম>/…) HTML, CSS, JS, ফন্ট ও ছবি WebView-কে একটা নকল ঠিকানায় দেয়:
 *   https://appassets.patheyo.invalid/<assets-এর ভেতরের পাথ>
 *
 * কেন: মূল পেজ file:///android_asset/index.html (লোকাল স্টোরেজ আগের মতোই থাকে), আর ফিচারগুলো একই অরিজিনের srcdoc ফ্রেমে চলে।
 * file:// থেকে file:// XHR/ফন্ট ব্লক হতে পারে, তাই এই ঠিকানা Access-Control-Allow-Origin: * দিয়ে সরাসরি assets থেকে ফেরত দেওয়া হয়
 * (কুরআনের QuranLocalServer-এর মতোই)।
 */
object AssetServer {
    const val HOST = "appassets.patheyo.invalid"

    private val HEADERS = mapOf(
        "Access-Control-Allow-Origin" to "*",
        "Access-Control-Allow-Methods" to "GET, OPTIONS",
        "Access-Control-Allow-Headers" to "*",
        // নতুন অ্যাপ ভার্সনে পুরনো ক্যাশ যেন না থাকে — লোকাল ফাইল পড়া খুবই দ্রুত, তাই প্রতিবার নতুন করে দেওয়া হয়
        "Cache-Control" to "no-cache"
    )

    private fun mimeOf(path: String): String {
        val ext = path.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html" -> "text/html"
            "css" -> "text/css"
            "js" -> "application/javascript"
            "json" -> "application/json"
            "woff2" -> "font/woff2"
            "woff" -> "font/woff"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "svg" -> "image/svg+xml"
            "mp3" -> "audio/mpeg"
            else -> "application/octet-stream"
        }
    }

    fun intercept(context: Context, request: WebResourceRequest): WebResourceResponse? {
        val uri = request.url ?: return null
        if (!HOST.equals(uri.host, ignoreCase = true)) return null
        val path = (uri.path ?: return null).trimStart('/')
        if (path.isEmpty() || path.contains("..")) return empty(404, "Not Found", "text/plain")
        val mime = mimeOf(path)
        if ("OPTIONS".equals(request.method, ignoreCase = true)) return empty(200, "OK", mime)
        return try {
            val stream = context.assets.open(path)
            val enc = if (mime.startsWith("text/") || mime == "application/javascript" || mime == "application/json") "utf-8" else null
            WebResourceResponse(mime, enc, 200, "OK", HEADERS, stream)
        } catch (_: IOException) {
            empty(404, "Not Found", mime)
        }
    }

    private fun empty(code: Int, reason: String, mime: String) =
        WebResourceResponse(mime, "utf-8", code, reason, HEADERS, ByteArrayInputStream(ByteArray(0)))
}
