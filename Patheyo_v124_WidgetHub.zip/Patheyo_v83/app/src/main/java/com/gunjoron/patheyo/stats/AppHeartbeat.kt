package com.gunjoron.patheyo.stats

import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * v49: অ্যাপ কতজন ব্যবহার করছে ও কে কোন ভার্সনে আছে — ওয়েবসাইটের অ্যাডমিন প্যানেলে দেখানোর জন্য
 * নিঃশব্দে একটি "হার্টবিট" পাঠায়।
 *
 * কী পাঠায় (কোনো ব্যক্তিগত তথ্য নয়): অ্যাপ প্রথম চালুর সময় বানানো এলোমেলো আইডি, অ্যাপের ভার্সন,
 * ফোনের মডেল ও অ্যান্ড্রয়েড ভার্সন। নাম/নম্বর/লোকেশন/ইমেইল কিছুই নয়।
 *
 * নিরাপত্তা: সব কাজ try-catch-এ; ইন্টারনেট না থাকলে বা সার্ভার সাড়া না দিলে চুপচাপ বাদ যায়,
 * অ্যাপের কোনো কাজে বাধা দেয় না। BackendConfig খালি থাকলে কিছুই করে না।
 */
object AppHeartbeat {

    private const val FILE = "patheyo_stats"
    private const val K_ID = "installation_id"
    private const val K_LAST_OPEN = "last_open_beat"
    private const val K_LAST_BG = "last_bg_beat"

    private const val OPEN_GAP_MS = 4L * 60_000L          // সামনে থাকলে ~৫ মিনিটে একবার
    private const val BG_GAP_MS = 10L * 60 * 60_000L      // ব্যাকগ্রাউন্ডে ~১২ ঘণ্টায় একবার
    private const val WORK_NAME = "patheyo_heartbeat_bg"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** এই ইনস্টলেশনের বেনামী আইডি (প্রথমবার বানিয়ে সেভ হয়) */
    fun installationId(ctx: Context): String {
        val p = prefs(ctx)
        var id = p.getString(K_ID, null)
        if (id.isNullOrBlank()) {
            id = UUID.randomUUID().toString()
            p.edit().putString(K_ID, id).apply()
        }
        return id
    }

    /** Activity-র onCreate-এ একবার কল করুন: অ্যাপ সামনে থাকা অবস্থায় প্রতি ~৫ মিনিটে হার্টবিট */
    fun startLoop(activity: AppCompatActivity) {
        if (!BackendConfig.enabled()) return
        val app = activity.applicationContext
        activity.lifecycleScope.launch {
            activity.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    send(app, "open")
                    delay(5L * 60_000L)
                }
            }
        }
    }

    /** Application.onCreate()-এ কল করুন: অ্যাপ না খুললেও ১২ ঘণ্টায় একবার ভার্সন জানাবে */
    fun scheduleBackground(ctx: Context) {
        if (!BackendConfig.enabled()) return
        val req = PeriodicWorkRequestBuilder<HeartbeatWorker>(12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** source = "open" (অ্যাপ খোলা) অথবা "bg" (ব্যাকগ্রাউন্ড)। সফল হলে true */
    suspend fun send(ctx: Context, source: String): Boolean = withContext(Dispatchers.IO) {
        if (!BackendConfig.enabled()) return@withContext false
        var conn: HttpURLConnection? = null
        try {
            val p = prefs(ctx)
            val now = System.currentTimeMillis()
            val key = if (source == "open") K_LAST_OPEN else K_LAST_BG
            val gap = if (source == "open") OPEN_GAP_MS else BG_GAP_MS
            if (now - p.getLong(key, 0L) < gap) return@withContext true   // সম্প্রতি পাঠানো হয়েছে

            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            val body = JSONObject().apply {
                put("p_installation", installationId(ctx))
                put("p_version", (pi.versionName ?: "").take(32))
                put("p_version_code", PackageInfoCompat.getLongVersionCode(pi))
                put("p_device", "${Build.MANUFACTURER} ${Build.MODEL}".trim().take(60))
                put("p_android", Build.VERSION.RELEASE.orEmpty().take(16))
                put("p_source", source)
            }.toString()

            conn = (URL(BackendConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/rpc/app_heartbeat")
                .openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 10_000
                doOutput = true
                setRequestProperty("apikey", BackendConfig.SUPABASE_ANON_KEY)
                setRequestProperty("Authorization", "Bearer " + BackendConfig.SUPABASE_ANON_KEY)
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val ok = conn.responseCode in 200..299
            if (ok) p.edit().putLong(key, now).apply()
            ok
        } catch (t: Throwable) {
            false
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }
}

/** ব্যাকগ্রাউন্ডে ১২ ঘণ্টায় একবার চলে — ইউজার অ্যাপ আপডেট করে না খুললেও নতুন ভার্সন অ্যাডমিন প্যানেলে ধরা পড়ে */
class HeartbeatWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try { AppHeartbeat.send(applicationContext, "bg") } catch (_: Throwable) {}
        return Result.success()
    }
}
