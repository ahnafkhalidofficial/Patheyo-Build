package com.gunjoron.patheyo.update

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.core.content.FileProvider
import com.gunjoron.patheyo.R
import java.io.File

/** DownloadManager দিয়ে APK ডাউনলোড + FileProvider দিয়ে ইনস্টল ইনটেন্ট তৈরি */
object UpdateDownloader {

    private const val APK_NAME = "Patheyo-update.apk"
    private const val APK_MIME = "application/vnd.android.package-archive"

    fun apkFile(ctx: Context) =
        File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), APK_NAME)

    /** "অজানা সোর্স থেকে ইনস্টল" পারমিশন আছে কি? (Android 8+) */
    fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ctx.packageManager.canRequestPackageInstalls()

    private fun dm(ctx: Context) = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun isDownloading(ctx: Context): Boolean {
        val id = UpdatePrefs.getDownloadId(ctx)
        if (id < 0) return false
        dm(ctx).query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (c.moveToFirst()) {
                val s = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                return s == DownloadManager.STATUS_RUNNING ||
                    s == DownloadManager.STATUS_PENDING ||
                    s == DownloadManager.STATUS_PAUSED
            }
        }
        return false
    }

    fun isSuccessful(ctx: Context, id: Long): Boolean {
        dm(ctx).query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (c.moveToFirst()) {
                return c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) ==
                    DownloadManager.STATUS_SUCCESSFUL
            }
        }
        return false
    }

    /** ডাউনলোড শুরু করে। DownloadManager নিজেই GitHub-এর redirect ফলো করে। */
    fun start(ctx: Context, apkUrl: String, versionName: String) {
        apkFile(ctx).delete() // আগের অসম্পূর্ণ/পুরনো ফাইল মুছে ফেলা

        val req = DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle(ctx.getString(R.string.dm_title))
            .setDescription(ctx.getString(R.string.dm_desc, versionName))
            .setMimeType(APK_MIME)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
            .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, APK_NAME)

        UpdatePrefs.setDownloadId(ctx, dm(ctx).enqueue(req))
    }

    /** Package Installer খোলার ইনটেন্ট (FileProvider ব্যবহার করে) */
    fun buildInstallIntent(ctx: Context): Intent {
        // ⚠️ authority অবশ্যই AndroidManifest-এর provider-এর সাথে মিলতে হবে
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apkFile(ctx))
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, APK_MIME)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
