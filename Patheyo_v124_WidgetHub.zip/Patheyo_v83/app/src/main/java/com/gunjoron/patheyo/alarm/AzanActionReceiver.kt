package com.gunjoron.patheyo.alarm

// v48: নোটিফিকেশনের "আজান বন্ধ করুন" / "স্নুজ" বাটনের রিসিভার।
// আগে বাটন সরাসরি সার্ভিস স্টার্ট করত (PendingIntent.getService) — অনেক ফোনে (বিশেষত OEM/ব্যাটারি-সেভারে) সার্ভিস-স্টার্টে দেরি বা ব্লক হতো।
// BroadcastReceiver সবসময় সাথে সাথে চলে, আর চলমান সার্ভিসকে সরাসরি ডেকে আজানের সাউন্ড তৎক্ষণাৎ বন্ধ করে।

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AzanActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            when (intent.action) {
                AzanForegroundService.ACTION_STOP -> AzanForegroundService.requestStop(context)
                AzanForegroundService.ACTION_SNOOZE -> AzanForegroundService.requestSnooze(
                    context,
                    intent.getStringExtra("waqt"),
                    intent.getIntExtra(AzanRepeat.EXTRA_RING, 1)
                )
            }
        } catch (_: Throwable) { }
    }
}
