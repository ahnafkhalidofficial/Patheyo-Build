package com.gunjoron.patheyo.ui

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.view.ContextThemeWrapper
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.alarm.AlarmReliability

/**
 * v44: আজান নির্ভরযোগ্যভাবে বাজার জন্য দরকারি সিস্টেম-সেটিংস (এক্সাক্ট অ্যালার্ম / ব্যাটারি / অটো-স্টার্ট / ফুলস্ক্রিন)
 * চাওয়ার আগে ইউজারকে কারণ বুঝিয়ে বলার গ্লাস পপআপ। লোকেশন ও নোটিফিকেশন পপআপের (GlassStyle ফ্রেম) হুবহু একই ডিজাইন —
 * শুধু আইকন ও লেখা ধাপ অনুযায়ী বদলায়।
 */
object AlarmPermissionDialog {

    // v48: NOTIF_POPUP = "নামাজের আজান" নোটিফিকেশন বন্ধ/কম গুরুত্বের (পপআপ আসবে না); OEM_POPUP = ফোন-কোম্পানির আলাদা
    // "লক স্ক্রিনে দেখানো / ব্যাকগ্রাউন্ড পপআপ" অনুমতি। ক্রম: এই enum-এর ক্রমেই ধাপগুলো একটার পর একটা দেখানো হয়।
    enum class Step { EXACT_ALARM, BATTERY, OEM_BACKGROUND, FULL_SCREEN, NOTIF_POPUP, OEM_POPUP }

    private const val PREFS = "patheyo_permission_prefs"
    private const val RE_ASK_AFTER_MS = 24L * 60 * 60 * 1000 // "না" চাপলে ২৪ ঘণ্টা পর আবার একবার মনে করানো

    private fun declinedKey(step: Step) = "alarm_step_declined_at_${step.name}"
    private fun doneKey(step: Step) = "alarm_step_done_${step.name}"

    /** এই ধাপটা এখন দেখানো দরকার কিনা (পারমিশন নেই + সম্প্রতি "না" বলা হয়নি) */
    fun needed(activity: Activity, step: Step): Boolean {
        val needs = when (step) {
            Step.EXACT_ALARM -> android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                !com.gunjoron.patheyo.alarm.AlarmScheduler.canScheduleExact(activity)
            Step.BATTERY -> !AlarmReliability.isIgnoringBatteryOptimizations(activity)
            // OEM সেটিং ফোন থেকে পড়ে জানার উপায় নেই — তাই আগ্রাসী ব্র্যান্ড হলে একবার (ইউজার "অনুমতি" চাপা পর্যন্ত) দেখানো হয়
            Step.OEM_BACKGROUND -> AlarmReliability.isAggressiveOem() &&
                !activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).getBoolean(doneKey(step), false)
            Step.FULL_SCREEN -> !AlarmReliability.canUseFullScreenIntent(activity)
            Step.NOTIF_POPUP -> com.gunjoron.patheyo.alarm.AzanChannel.problem(activity)
            // Xiaomi-তে অনুমতির অবস্থা পড়া যায় (চালু থাকলে দেখানো হয় না); বাকি আগ্রাসী ব্র্যান্ডে পড়া যায় না — একবার দেখানো হয়
            Step.OEM_POPUP -> AlarmReliability.isAggressiveOem() &&
                AlarmReliability.xiaomiPopupAllowed(activity) != true &&
                !activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).getBoolean(doneKey(step), false)
        }
        if (!needs) return false
        val last = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).getLong(declinedKey(step), 0L)
        return last == 0L || System.currentTimeMillis() - last > RE_ASK_AFTER_MS
    }

    /** onAllow: "অনুমতি" চাপলে সঠিক সেটিংস স্ক্রিন খোলা হয়ে গেছে।  onDone: "না" চাপলে বা ব্যাক করলে। */
    fun show(activity: Activity, step: Step, onAllow: () -> Unit, onDone: () -> Unit) {
        val themed = ContextThemeWrapper(activity, R.style.Theme_Patheyo)
        val view = LayoutInflater.from(themed).inflate(R.layout.dialog_alarm_permission, null)

        val honor = AlarmReliability.oemFamily() == AlarmReliability.Oem.HONOR_HUAWEI
        val (icon, title, subtitle, benefits, warning) = when (step) {
            Step.EXACT_ALARM -> Content(R.drawable.ic_btn_clock, R.string.alarm_perm_exact_title, R.string.alarm_perm_exact_subtitle, R.string.alarm_perm_exact_benefits, R.string.alarm_perm_exact_warning)
            Step.BATTERY -> Content(R.drawable.ic_bell, R.string.alarm_perm_battery_title, R.string.alarm_perm_battery_subtitle, R.string.alarm_perm_battery_benefits, R.string.alarm_perm_battery_warning)
            Step.OEM_BACKGROUND -> Content(R.drawable.ic_bell, R.string.alarm_perm_oem_title, R.string.alarm_perm_oem_subtitle,
                if (honor) R.string.alarm_perm_oem_benefits_honor else R.string.alarm_perm_oem_benefits, R.string.alarm_perm_oem_warning)
            Step.FULL_SCREEN -> Content(R.drawable.ic_bell, R.string.alarm_perm_full_title, R.string.alarm_perm_full_subtitle, R.string.alarm_perm_full_benefits, R.string.alarm_perm_full_warning)
            Step.NOTIF_POPUP -> Content(R.drawable.ic_bell, R.string.alarm_perm_popup_title, R.string.alarm_perm_popup_subtitle, R.string.alarm_perm_popup_benefits, R.string.alarm_perm_popup_warning)
            Step.OEM_POPUP -> Content(R.drawable.ic_bell, R.string.alarm_perm_lock_title, R.string.alarm_perm_lock_subtitle, R.string.alarm_perm_lock_benefits, R.string.alarm_perm_lock_warning)
        }

        view.findViewById<ImageView>(R.id.ivIcon).setImageResource(icon)
        view.findViewById<TextView>(R.id.tvAppName).text = DialogText.nameWithTag(
            activity, GlassStyle.appLabel(activity), activity.getString(R.string.alarm_perm_tag), latinTag = false
        )
        view.findViewById<TextView>(R.id.tvTitle).setText(title)
        view.findViewById<TextView>(R.id.tvSubtitle).setText(subtitle)
        view.findViewById<TextView>(R.id.tvWarning).setText(warning)
        view.findViewById<TextView>(R.id.tvAllowLabel).setText(R.string.alarm_perm_allow)
        view.findViewById<TextView>(R.id.tvDenyLabel).setText(R.string.alarm_perm_deny)
        view.findViewById<TextView>(R.id.tvNotes).text = DialogText.formatList(
            activity, activity.getString(benefits), activity.getColor(R.color.update_tag_text)
        )

        var chose = false
        val dialog = AlertDialog.Builder(themed).setView(view).setCancelable(true).create()
        dialog.setOnDismissListener { if (!chose) { chose = true; markDeclined(activity, step); onDone() } }
        val prepared = GlassStyle.prepare(activity, dialog)

        GlassStyle.limitHeight(view.findViewById(R.id.svNotes), maxDp = 200)

        view.findViewById<View>(R.id.btnAllow).setOnClickListener {
            chose = true
            activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(doneKey(step), true).apply()
            // "জিজ্ঞেস করা হয়েছে" সময় রাখা হয় — ইউজার সেটিংসে গিয়ে না দিয়ে ফিরলেও একই পপআপ বারবার লুপে আসবে না
            markDeclined(activity, step)
            dialog.dismiss()
            android.widget.Toast.makeText(activity, R.string.alarm_perm_toast_return, android.widget.Toast.LENGTH_LONG).show()
            openSettingsFor(activity, step)
            onAllow()
        }
        view.findViewById<View>(R.id.btnDeny).setOnClickListener {
            chose = true
            markDeclined(activity, step)
            dialog.dismiss(); onDone()
        }

        dialog.show()
        GlassStyle.present(activity, dialog, view, prepared)
    }

    private data class Content(val icon: Int, val title: Int, val subtitle: Int, val benefits: Int, val warning: Int)

    private fun markDeclined(activity: Activity, step: Step) {
        activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit()
            .putLong(declinedKey(step), System.currentTimeMillis()).apply()
    }

    private fun openSettingsFor(activity: Activity, step: Step) {
        when (step) {
            Step.EXACT_ALARM -> AlarmReliability.openExactAlarmSettings(activity)
            Step.BATTERY -> AlarmReliability.openBatteryOptimization(activity)
            Step.OEM_BACKGROUND -> if (!AlarmReliability.openOemBackgroundSettings(activity)) AlarmReliability.openAppDetails(activity)
            Step.FULL_SCREEN -> AlarmReliability.openFullScreenIntentSettings(activity)
            Step.NOTIF_POPUP -> AlarmReliability.openAzanChannelSettings(activity)
            Step.OEM_POPUP -> AlarmReliability.openPopupPermissionSettings(activity)
        }
    }
}
