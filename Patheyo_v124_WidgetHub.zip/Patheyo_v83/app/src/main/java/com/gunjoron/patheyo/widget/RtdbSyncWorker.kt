package com.gunjoron.patheyo.widget

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.gunjoron.patheyo.FirebaseDataManager

// v62: 15 minute   Firebase RTDB  (  )
class RtdbSyncWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            FirebaseDataManager.fetchBlocking(applicationContext)
            Result.success()
        } catch (t: Throwable) {
            Result.retry()
        }
    }
}
