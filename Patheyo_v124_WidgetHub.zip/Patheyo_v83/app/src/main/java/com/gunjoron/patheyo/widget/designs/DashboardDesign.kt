package com.gunjoron.patheyo.widget.designs

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import com.gunjoron.patheyo.widget.data.Snapshot
import com.gunjoron.patheyo.widget.WidgetRenderer.cardW
import com.gunjoron.patheyo.widget.assets.Fonts
import com.gunjoron.patheyo.widget.render.*
import com.gunjoron.patheyo.widget.theme.Look
import com.gunjoron.patheyo.widget.theme.Palettes
import java.util.Calendar

/** ডিজাইন ৫ (ড্যাশবোর্ড): সেকেন্ডসহ ঘড়ি, তিন তারিখ, সেহরি-ইফতার, চলমান ওয়াক্ত। */
internal object DashboardDesign {
    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৫ (ড্যাশবোর্ড): সেকেন্ডসহ ঘড়ি · তিন তারিখ (ইংরেজি/হিজরি/বাংলা) · সাহরি-ইফতার · চলমান ওয়াক্ত · পাঁচ ওয়াক্ত
    // শুধু সেকেন্ডটা লাইভ (TextClock "ss"); বাকি সব বিটম্যাপে।
    // ------------------------------------------------------------------------------------------
    private const val D5_CLOCK_W = 380f; private const val D5_BASE = 224f

    const val D5_SIDE_CX = 456f

    private const val D5_DIV = 548f; private const val D5_RX = 572f

    fun draw(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(5)
        val L = 40f; val R = cw - 40f
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x66000000

        // ১) বার (ঘড়ির ওপরে) + ঘড়ি (বাঁয়ে) + AM/PM ও সেকেন্ড (একটার নিচে আরেকটা)
        logoRing(ctx, c, p, m, L + 28f, 52f, 26f)
        text(c, p, weekday(nowMs), L + 70f, 64f, 36f, m.accent, Fonts.bold)
        val clockSize = D5_CLOCK_W / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        slimClock(c, p, hm, L - 4f, D5_BASE, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", D5_SIDE_CX, 148f, 38f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), D5_SIDE_CX, 222f, 66f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ২) ডানে তিন তারিখ — লেবেল + তারিখ
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(D5_DIV - 1f, 44f, D5_DIV + 1f, 258f, p)
        val dates = arrayOf(
            "ইংরেজি" to snap.gregorianLine,
            "হিজরি" to (snap.hijriDay + " " + snap.hijriMonthYear),
            "বাংলা" to snap.banglaLine
        )
        for ((i, dv) in dates.withIndex()) {
            val y0 = 66f + 72f * i
            text(c, p, dv.first, D5_RX, y0, 28f, m.accent, Fonts.regular)
            val sz = fit(p, dv.second, Fonts.bold, 39f, R - D5_RX)
            text(c, p, dv.second, D5_RX, y0 + 38f, sz, m.primary, Fonts.bold)
        }

        // ৩) সেহরি / ইফতার (বক্স ছাড়া: সরু অ্যাকসেন্ট দাগ + পাতলা ডিভাইডার) + চলমান ওয়াক্ত
        val ty = 282f
        val tiles = arrayOf("সেহরি" to snap.sehri, "ইফতার" to snap.iftar)
        val gx = floatArrayOf(L + 4f, L + 262f)
        for ((i, t) in tiles.withIndex()) {
            val x0 = gx[i]
            p.style = Paint.Style.FILL; p.color = rule      // তারিখের পাশের দাগের মতোই চিকন
            c.drawRect(x0 - 1f, ty + 8f, x0 + 1f, ty + 92f, p)
            text(c, p, t.first, x0 + 24f, ty + 38f, 31f, m.secondary, Fonts.regular)
            text(c, p, t.second, x0 + 24f, ty + 88f, 50f, m.primary, Fonts.bold)
        }
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(D5_DIV - 1f, ty + 8f, D5_DIV + 1f, ty + 92f, p)
        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f5 = snap.forbid     // ০ স্বাভাবিক · ১ নিষিদ্ধ সময় · ২ সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত ("–")
        text(c, p, if (f5 == 1) "নামাজ আদায় নিষেধ" else "চলমান ওয়াক্ত", D5_RX, ty + 32f, 29f, if (f5 == 1) warn else m.secondary, Fonts.regular)
        when (f5) {
            2 -> {
                text(c, p, "–", D5_RX, ty + 76f, 56f, m.secondary, Fonts.bold)
                text(c, p, "–", R, ty + 76f, 44f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", D5_RX, ty + 76f, 50f, warn, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 912f, ty + 76f, 32f, 30f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, D5_RX, ty + 76f, 52f, m.accent, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 912f, ty + 76f, 32f, 30f, m.primary, m.primary)
            }
        }
        val f5Frac = when (f5) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        bar(c, p, D5_RX, R, ty + 92f, 8f, f5Frac, m.track, if (f5 == 1) warn else m.accent)
    }
}
