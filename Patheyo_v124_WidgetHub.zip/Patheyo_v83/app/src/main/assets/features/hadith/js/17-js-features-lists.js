
/* ===== js/features/lists.js ===== */
/*!
 * js/features/lists.js -- Book list rendering (same rows as the Quran app's sura list)
 *
 * Provides : App.renderBookList
 * Needs    : core/dom, core/books, core/utils, services/book-download, features/book-view
 */
(function (App) {
  "use strict";

  // ডাউনলোড করা কিতাবের নামের পাশে সবুজ ঢেউ-কিনারার গোল টিক (ভেক্টর SVG); বাকি থাকলে লেখা
  var OK_BADGE = '<svg class="ok-badge" viewBox="0 0 24 24" role="img" aria-label="ডাউনলোড করা" focusable="false"><defs><linearGradient id="okg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3FD38A"/><stop offset="1" stop-color="#1E9E5A"/></linearGradient></defs><path d="M22.74 12.00 L22.69 12.37 L22.53 12.74 L22.27 13.08 L21.94 13.40 L21.56 13.69 L21.15 13.94 L20.75 14.18 L20.38 14.40 L20.06 14.62 L19.81 14.84 L19.63 15.08 L19.54 15.36 L19.53 15.67 L19.58 16.03 L19.67 16.43 L19.79 16.87 L19.90 17.33 L19.99 17.80 L20.03 18.27 L20.00 18.72 L19.90 19.11 L19.72 19.45 L19.45 19.72 L19.11 19.90 L18.72 20.00 L18.27 20.03 L17.80 19.99 L17.33 19.90 L16.87 19.79 L16.43 19.67 L16.03 19.58 L15.67 19.53 L15.36 19.54 L15.08 19.63 L14.84 19.81 L14.62 20.06 L14.40 20.38 L14.18 20.75 L13.94 21.15 L13.69 21.56 L13.40 21.94 L13.08 22.27 L12.74 22.53 L12.37 22.69 L12.00 22.74 L11.63 22.69 L11.26 22.53 L10.92 22.27 L10.60 21.94 L10.31 21.56 L10.06 21.15 L9.82 20.75 L9.60 20.38 L9.38 20.06 L9.16 19.81 L8.92 19.63 L8.64 19.54 L8.33 19.53 L7.97 19.58 L7.57 19.67 L7.13 19.79 L6.67 19.90 L6.20 19.99 L5.73 20.03 L5.28 20.00 L4.89 19.90 L4.55 19.72 L4.28 19.45 L4.10 19.11 L4.00 18.72 L3.97 18.27 L4.01 17.80 L4.10 17.33 L4.21 16.87 L4.33 16.43 L4.42 16.03 L4.47 15.67 L4.46 15.36 L4.37 15.08 L4.19 14.84 L3.94 14.62 L3.62 14.40 L3.25 14.18 L2.85 13.94 L2.44 13.69 L2.06 13.40 L1.73 13.08 L1.47 12.74 L1.31 12.37 L1.26 12.00 L1.31 11.63 L1.47 11.26 L1.73 10.92 L2.06 10.60 L2.44 10.31 L2.85 10.06 L3.25 9.82 L3.62 9.60 L3.94 9.38 L4.19 9.16 L4.37 8.92 L4.46 8.64 L4.47 8.33 L4.42 7.97 L4.33 7.57 L4.21 7.13 L4.10 6.67 L4.01 6.20 L3.97 5.73 L4.00 5.28 L4.10 4.89 L4.28 4.55 L4.55 4.28 L4.89 4.10 L5.28 4.00 L5.73 3.97 L6.20 4.01 L6.67 4.10 L7.13 4.21 L7.57 4.33 L7.97 4.42 L8.33 4.47 L8.64 4.46 L8.92 4.37 L9.16 4.19 L9.38 3.94 L9.60 3.62 L9.82 3.25 L10.06 2.85 L10.31 2.44 L10.60 2.06 L10.92 1.73 L11.26 1.47 L11.63 1.31 L12.00 1.26 L12.37 1.31 L12.74 1.47 L13.08 1.73 L13.40 2.06 L13.69 2.44 L13.94 2.85 L14.18 3.25 L14.40 3.62 L14.62 3.94 L14.84 4.19 L15.08 4.37 L15.36 4.46 L15.67 4.47 L16.03 4.42 L16.43 4.33 L16.87 4.21 L17.33 4.10 L17.80 4.01 L18.27 3.97 L18.72 4.00 L19.11 4.10 L19.45 4.28 L19.72 4.55 L19.90 4.89 L20.00 5.28 L20.03 5.73 L19.99 6.20 L19.90 6.67 L19.79 7.13 L19.67 7.57 L19.58 7.97 L19.53 8.33 L19.54 8.64 L19.63 8.92 L19.81 9.16 L20.06 9.38 L20.38 9.60 L20.75 9.82 L21.15 10.06 L21.56 10.31 L21.94 10.60 L22.27 10.92 L22.53 11.26 L22.69 11.63Z" fill="url(#okg)"/><path d="M7.6 12.4l3 3 5.9-6.2" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  // ৮ কোণের তারা (কুরআনের সূরা-তালিকার একই নকশা) -- ক্রমিক নম্বরের পেছনে
  var STAR_SVG = '<svg viewBox="0 0 48 48" focusable="false"><path class="sr-star" d="M24 2.5l5.4 5.7 7.7-1.2 1.2 7.7 5.7 5.4-4.4 6.4 4.4 6.4-5.7 5.4-1.2 7.7-7.7-1.2L24 45.5l-5.4-5.7-7.7 1.2-1.2-7.7-5.7-5.4L8.4 21 4 14.6l5.7-5.4 1.2-7.7 7.7 1.2z"/></svg>';
  function isReady(id){ return App.bookDl.isReady(id); }
  function statusHtml(id){
    return isReady(id) ? '' : '<span class="sr-dot"></span><span class="bk-dl">ডাউনলোড বাকি</span>';
  }

  function renderBookList(){
    var frag = document.createDocumentFragment();
    App.BOOKS.forEach(function(b, i){
      var row = document.createElement('div');
      row.className = 'list-item bk-row';
      row.setAttribute('data-name', b.nameBn + ' ' + b.nameEn + ' ' + b.nameAr);
      row.setAttribute('data-index', i + 1);
      row.setAttribute('data-book', b.id);
      row.innerHTML =
        '<div class="sr-no" aria-hidden="true">' + STAR_SVG + '<span>' + App.bn(i + 1) + '</span></div>' +
        '<div class="sr-main">' +
          '<div class="bk-title"><span class="li-nm-t">' + App.escapeHtml(b.nameBn) + '</span>' + (isReady(b.id) ? OK_BADGE : '') + '</div>' +
          '<div class="sr-meta"><span class="bk-chip">' + App.bn(b.count) + ' হাদীস</span>' + statusHtml(b.id) + '</div>' +
        '</div>' +
        '<div class="sr-ar">' + App.bookGlyph(b.id, 'sg-list') + '</div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(){ App.openBook(b.id); });
      frag.appendChild(row);
    });
    App.els.booksList.innerHTML = '';
    App.els.booksList.appendChild(frag);
  }
  App.renderBookList = renderBookList;

})(window.HadithApp = window.HadithApp || {});

