
/* ===== js/features/bookmark-fab.js ===== */
/*!
 * js/features/bookmark-fab.js -- Bookmark floating button: saved-position tracking and icon state
 *
 * Provides : App.activeBookmarkPos, App.bmTapPulse, App.updateBmFabIcon, App.updateBookmarkPosition
 * Needs    : core/dom, core/state, features/bookmark-list, features/bookmark-modal, features/chapter-reader,
 *            features/feedback, services/bookmark-store
 */
(function (App) {
  "use strict";

  // ---- "Update this bookmark" vs "add a new bookmark" (exactly the Quran app's behaviour) ----
  // While the chapter was opened FROM a saved bookmark (activeBookmarkId set), the FAB shows a "save/update"
  // icon instead of the usual "add" icon; tapping it silently moves that same bookmark to the hadith at the
  // top of the screen. The button is green while it is still AT the saved hadith ("synced") and grey once
  // the reader scrolled on ("drifted"); tapping it either way moves the bookmark here and turns it green.
  var BM_ICON_ADD = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21 12 16 5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>';

  var BM_ICON_UPDATE = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"></path><path d="M17 21v-8H7v8"></path><path d="M7 3v5h6"></path></svg>';

  App.activeBookmarkPos = null;   // the position the active bookmark is currently saved at

  function bmFabList(){ return [App.els.chapterBmFab]; }

  function isAtSavedPosition(){
    if (!App.activeBookmarkPos) return false;
    var pos = App.getCurrentVisibleHadith();
    return !!pos && App.curBookId === App.activeBookmarkPos.book && pos.seq === App.activeBookmarkPos.seq;
  }

  function updateBmFabIcon(){
    var icon = App.activeBookmarkId ? BM_ICON_UPDATE : BM_ICON_ADD;
    var label = App.activeBookmarkId ? 'বুকমার্ক আপডেট করুন' : 'বুকমার্ক';
    var synced = App.activeBookmarkId ? isAtSavedPosition() : false;
    bmFabList().forEach(function(btn){
      btn.innerHTML = icon;
      btn.setAttribute('aria-label', label);
      btn.classList.toggle('bm-synced', !!App.activeBookmarkId && synced);
      btn.classList.toggle('bm-drifted', !!App.activeBookmarkId && !synced);
    });
  }
  App.updateBmFabIcon = updateBmFabIcon;

  function bmTapPulse(btn){
    if (!btn) return;
    btn.classList.remove('bm-tap-anim');
    void btn.offsetWidth;
    btn.classList.add('bm-tap-anim');
    setTimeout(function(){ btn.classList.remove('bm-tap-anim'); }, 400);
  }
  App.bmTapPulse = bmTapPulse;

  // patch: { seq, num, ch, ct } -- moves the bookmark to another hadith
  function updateBookmarkPosition(id, patch){
    var arr = App.loadBookmarks();
    var found = null;
    for (var i=0;i<arr.length;i++){
      if (arr[i].id === id){
        for (var k in patch){ if (patch.hasOwnProperty(k)) arr[i][k] = patch[k]; }
        found = arr[i];
        break;
      }
    }
    if (!found){ App.activeBookmarkId = null; App.activeBookmarkPos = null; updateBmFabIcon(); return; }
    App.saveBookmarksArr(arr);
    App.renderBookmarksList();
    App.activeBookmarkPos = { book: found.book, seq: found.seq };
    updateBmFabIcon();
    App.refreshCardMarks();
    App.showCenterToast('বুকমার্ক আপডেট হয়েছে');
  }
  App.updateBookmarkPosition = updateBookmarkPosition;

})(window.HadithApp = window.HadithApp || {});

