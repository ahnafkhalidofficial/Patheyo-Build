
/* ===== js/features/search.js ===== */
/*!
 * js/features/search.js -- Search inside the open book: hadith number, Bengali words, Arabic words, chapter names
 *
 * Provides : App.runBookSearch, App.cancelBookSearch
 * Needs    : core/dom, core/utils, services/book-store, features/chapter-reader
 *
 * - শুধু সংখ্যা লিখলে -> হাদীস নম্বর মেলানো
 * - আরবি অক্ষর থাকলে -> আরবি টেক্সটে খোঁজা (হারাকাত ছাড়া)
 * - নইলে -> বাংলা অনুবাদে খোঁজা (একাধিক শব্দ হলে সবগুলো শব্দ থাকতে হবে) + অধ্যায়ের নাম
 * বড় কিতাবেও ফোন আটকে না যাওয়ার জন্য খোঁজা ছোট ছোট ধাপে (অ্যাসিঙ্ক) চলে; নতুন অক্ষর লিখলে আগেরটা বাতিল।
 */
(function (App) {
  "use strict";

  var LIMIT = 40;          // সর্বোচ্চ কত ফলাফল দেখাবে
  var STEP = 350;          // প্রতি ধাপে কতটি হাদীস যাচাই
  var token = 0;           // বর্তমান খোঁজার পরিচয় (নতুন খোঁজা এলে পুরনো থামে)
  var timer = null;

  function cancelBookSearch(){ token++; clearTimeout(timer); }
  App.cancelBookSearch = cancelBookSearch;

  function esc(s){ return App.escapeHtml(s); }

  function escRe(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  function snippet(text, words){
    var low = App.normBn(text), at = -1;
    for (var i = 0; i < words.length; i++){ var p = low.indexOf(words[i]); if (p >= 0 && (at < 0 || p < at)) at = p; }
    var start = Math.max(0, (at < 0 ? 0 : at) - 40);
    var s = text.slice(start, start + 200).replace(/\s+/g, ' ');
    var out = esc(s);
    words.forEach(function(w){
      if (!w) return;
      try{ out = out.replace(new RegExp('(' + escRe(esc(w)) + ')', 'gi'), '<mark>$1</mark>'); } catch(e){}
    });
    return (start > 0 ? '… ' : '') + out + (text.length > start + 200 ? ' …' : '');
  }

  function badgeHtml(num){
    var t = App.bn(num), cls = t.length >= 5 ? ' style="font-size:11px"' : (t.length === 4 ? ' style="font-size:13.5px"' : '');
    return '<div class="li-badge"' + cls + '>' + t + '</div>';
  }

  function hitRow(book, r){
    var ch = book.data.ch[r.c];
    var row = document.createElement('div');
    row.className = 'list-item';
    if (r.k === 'c'){
      row.innerHTML =
        '<div class="li-badge">' + (ch.n != null ? App.bn(ch.n) : '•') + '</div>' +
        '<div class="li-name-block"><div class="li-sub">অধ্যায়</div><div class="li-name-main">' + esc(ch.t) + '</div></div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(){ App.openChapter(r.c, { origin:'book' }); });
    } else {
      var h = r.h;
      var body = r.ar
        ? '<div class="hit-text hit-ar">' + esc(h[1].slice(0, 220)) + '</div>'
        : '<div class="hit-text">' + snippet(h[2] || h[1], r.words) + '</div>';
      row.innerHTML =
        badgeHtml(h[0]) +
        '<div class="li-name-block"><div class="li-sub" style="margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' +
        esc(ch.t) + '</div>' + body + '</div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(){ App.openChapter(r.c, { origin:'book', seq: r.seq }); });
    }
    return row;
  }

  function showList(){
    App.els.chapterList.classList.remove('hidden');
    App.els.bookResults.classList.add('hidden');
    App.els.bookResults.innerHTML = '';
    App.els.bookEmpty.classList.add('hidden');
    App.els.bookTools.classList.remove('hidden');
  }

  function runBookSearch(raw){
    cancelBookSearch();
    var my = token;
    var q = (raw || '').trim();
    App.els.searchClear.classList.toggle('show', !!q);
    var book = App.loadedBook;
    if (!q || !book || book.id !== App.curBookId){ showList(); return; }

    App.els.chapterList.classList.add('hidden');
    App.els.bookTools.classList.add('hidden');
    App.els.bookResults.classList.remove('hidden');
    App.els.bookResults.innerHTML = '';
    App.els.bookEmpty.classList.add('hidden');

    var out = App.els.bookResults, found = 0, hadithHits = 0, capped = false;
    function add(r){ out.appendChild(hitRow(book, r)); found++; }

    var digits = App.toEnglishDigits(q).replace(/\s+/g, '');
    var mode, words = [], num = 0;
    if (/^\d+$/.test(digits)){ mode = 'num'; num = parseInt(digits, 10); }
    else if (App.hasArabic(q)){
      mode = 'ar';
      words = App.normAr(q).split(/\s+/).filter(Boolean);
    } else {
      mode = 'bn';
      words = App.normBn(q).split(/\s+/).filter(Boolean);
      // অধ্যায়ের নামে মিল
      var chHits = 0;
      for (var c = 0; c < book.data.ch.length && chHits < 6; c++){
        var t = App.normBn(book.data.ch[c].t);
        var okAll = words.every(function(w){ return t.indexOf(w) !== -1; });
        if (okAll){ add({ k:'c', c: c }); chHits++; }
      }
    }

    var ch = book.data.ch, c2 = 0, s2 = 0, i2 = 0, seq = 0;

    function finish(){
      if (my !== token) return;
      if (!found){ App.els.bookEmpty.classList.remove('hidden'); }
      else if (capped){
        var note = document.createElement('div');
        note.className = 'results-note';
        note.textContent = 'প্রথম ' + App.bn(LIMIT) + 'টি ফলাফল দেখানো হচ্ছে। আরও নির্দিষ্ট করে লিখুন।';
        out.appendChild(note);
      }
    }

    function step(){
      if (my !== token) return;
      var n = 0;
      while (c2 < ch.length && n < STEP){
        var secs = ch[c2].s;
        if (s2 >= secs.length){ c2++; s2 = 0; i2 = 0; continue; }
        var hs = secs[s2].h;
        if (i2 >= hs.length){ s2++; i2 = 0; continue; }
        var h = hs[i2], match = false;
        if (mode === 'num'){ match = (h[0] === num); }
        else {
          var hay = (mode === 'ar') ? App.normAr(h[1]) : App.normBn(h[2]);
          match = words.length > 0 && words.every(function(w){ return hay.indexOf(w) !== -1; });
        }
        if (match){
          add({ k:'h', c: c2, seq: seq, h: h, words: words, ar: mode === 'ar' });
          hadithHits++;
          if (hadithHits >= LIMIT){ capped = true; finish(); return; }
        }
        i2++; seq++; n++;
      }
      if (c2 >= ch.length){ finish(); return; }
      timer = setTimeout(step, 0);
    }
    step();
  }
  App.runBookSearch = runBookSearch;

})(window.HadithApp = window.HadithApp || {});

