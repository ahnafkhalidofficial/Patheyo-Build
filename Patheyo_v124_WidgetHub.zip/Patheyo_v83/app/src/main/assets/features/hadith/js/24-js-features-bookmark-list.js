
/* ===== js/features/bookmark-list.js ===== */
/*!
 * js/features/bookmark-list.js -- Bookmarks tab list, jump-to-bookmark navigation, delete confirmation
 *
 * Provides : App.renderBookmarksList, App.removeBookmarkWithUndo
 * Needs    : core/dom, core/books, core/utils, features/bookmark-fab, features/bookmark-modal, features/book-view,
 *            features/chapter-reader, features/feedback, services/bookmark-store
 */
(function (App) {
  "use strict";

  function goToBookmark(bm){
    App.openHadith(bm.book, { seq: bm.seq, num: bm.num, ch: bm.ch, bookmarkId: bm.id });
  }

  function renderBookmarksList(){
    var arr = App.loadBookmarks().slice().sort(function(a,b){ return b.createdAt - a.createdAt; });
    App.els.bookmarksList.innerHTML = '';
    App.els.bookmarksEmpty.classList.toggle('hidden', arr.length !== 0);
    var frag = document.createDocumentFragment();
    arr.forEach(function(bm){
      var row = document.createElement('div');
      row.className = 'list-item bm-item';
      var sub = bm.label || bm.ct || '';
      row.innerHTML =
        '<div class="li-badge"><svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21 12 16 5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg></div>' +
        '<div class="li-name-block">' +
          '<div class="li-name-en">' + App.escapeHtml(App.bookmarkTitle(bm)) + '</div>' +
          (sub ? '<div class="li-sub" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + App.escapeHtml(sub) + '</div>' : '') +
        '</div>' +
        '<button class="bm-edit-btn" aria-label="সম্পাদনা"><svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg></button>' +
        '<button class="bm-del-btn" aria-label="মুছুন"><svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path></svg></button>';
      row.querySelector('.bm-edit-btn').addEventListener('click', function(e){
        e.stopPropagation();
        App.openBookmarkModal(bm, bm.id);
      });
      row.querySelector('.bm-del-btn').addEventListener('click', function(e){
        e.stopPropagation();
        openDeleteConfirm(bm);
      });
      row.addEventListener('click', function(){ goToBookmark(bm); });
      frag.appendChild(row);
    });
    App.els.bookmarksList.appendChild(frag);
  }
  App.renderBookmarksList = renderBookmarksList;

  var pendingDeleteBm = null;

  function openDeleteConfirm(bm){
    pendingDeleteBm = bm;
    var b = App.bookById(bm.book);
    var what = (b ? b.nameBn : '') + ', হাদীস-' + App.bn(bm.num);
    App.els.bmDeleteContext.innerHTML = '<strong style="color:var(--text)">' + App.escapeHtml(what) + '</strong><br>এই বুকমার্কটি কি আপনি মুছে ফেলতে চান?';
    App.els.bmDeleteOverlay.classList.remove('hidden');
  }

  function closeDeleteConfirm(){
    App.els.bmDeleteOverlay.classList.add('hidden');
    pendingDeleteBm = null;
  }

  // used by the green icon on a hadith card (no confirmation dialog -- "undo" instead)
  function removeBookmarkWithUndo(id){
    var removed = App.deleteBookmark(id);
    if (App.activeBookmarkId === id){ App.activeBookmarkId = null; App.activeBookmarkPos = null; App.updateBmFabIcon(); }
    if (App.refreshCardMarks) App.refreshCardMarks();
    App.showSnackbarUndo('বুকমার্ক মুছে ফেলা হয়েছে', function(){
      if (removed){ App.addOrUpdateBookmark(removed); if (App.refreshCardMarks) App.refreshCardMarks(); }
    });
  }
  App.removeBookmarkWithUndo = removeBookmarkWithUndo;

  App.els.bmDeleteCancelBtn.addEventListener('click', closeDeleteConfirm);

  App.els.bmDeleteOverlay.addEventListener('click', function(e){
    if (e.target === App.els.bmDeleteOverlay) closeDeleteConfirm();
  });

  App.els.bmDeleteConfirmBtn.addEventListener('click', function(){
    if (!pendingDeleteBm) return;
    var bm = pendingDeleteBm;
    var removed = App.deleteBookmark(bm.id);
    if (App.activeBookmarkId === bm.id){ App.activeBookmarkId = null; App.activeBookmarkPos = null; App.updateBmFabIcon(); }
    closeDeleteConfirm();
    App.showSnackbarUndo('বুকমার্ক মুছে ফেলা হয়েছে', function(){ if (removed) App.addOrUpdateBookmark(removed); });
  });

})(window.HadithApp = window.HadithApp || {});

