
/* ===== js/core/dom.js ===== */
/*!
 * js/core/dom.js -- Cached references to every DOM element the app touches
 *
 * Provides : App.els
 * Needs    : (nothing)
 */
(function (App) {
  "use strict";

  function $(id){ return document.getElementById(id); }

  App.els = {
    errorBox: $('error-box'),
    booksPanel: $('books-panel'),
    booksList: $('books-list'),
    booksEmpty: $('books-empty'),
    bookmarksPanel: $('bookmarks-panel'),
    bookmarksList: $('bookmarks-list'),
    bookmarksEmpty: $('bookmarks-empty'),
    searchInput: $('search-input'),
    searchClear: $('search-clear'),
    searchWrap: $('search-wrap'),
    continueCard: $('continue-card'),
    continueTitle: $('continue-title'),
    tabs: document.querySelectorAll('.tab'),
    themeBtns: document.querySelectorAll('[data-theme-btn]'),

    bookPanel: $('book-panel'),
    bookBackBtn: $('book-back-btn'),
    bookBadge: $('book-badge'),
    bookArabicName: $('book-arabic-name'),
    bookNameCaption: $('book-name-caption'),
    bookMeta: $('book-meta'),
    bookLoading: $('book-loading'),
    bookGate: $('book-gate'),
    bookBody: $('book-body'),
    chapterList: $('chapter-list'),
    bookResults: $('book-results'),
    bookEmpty: $('book-empty'),
    bookTools: $('book-tools'),
    bookRemoveBtn: $('book-remove-btn'),
    bookRemoveOverlay: $('book-remove-overlay'),
    bookRemoveContext: $('book-remove-context'),
    bookRemoveCancelBtn: $('book-remove-cancel-btn'),
    bookRemoveConfirmBtn: $('book-remove-confirm-btn'),

    dlCard: $('dl-card'),
    dlRing: $('dl-ring'),
    dlRingBar: $('dl-ring-bar'),
    dlPercent: $('dl-percent'),
    dlTitle: $('dl-title'),
    dlDesc: $('dl-desc'),
    dlStatSize: $('dl-stat-size'),
    dlStatSpeed: $('dl-stat-speed'),
    dlStatEta: $('dl-stat-eta'),
    dlStartBtn: $('dl-start-btn'),
    dlStartLabel: $('dl-start-label'),
    dlCancelBtn: $('dl-cancel-btn'),

    chapterPanel: $('chapter-panel'),
    chapterBackBtn: $('chapter-back-btn'),
    chapterBadge: $('chapter-badge'),
    chapterArabicName: $('chapter-arabic-name'),
    chapterNameCaption: $('chapter-name-caption'),
    chapterMeta: $('chapter-meta'),
    chapterItems: $('chapter-items'),
    moreSentinel: $('more-sentinel'),
    chapterBmFab: $('chapter-bm-fab'),

    bmModalOverlay: $('bm-modal-overlay'),
    bmModalTitle: $('bm-modal-title'),
    bmModalContext: $('bm-modal-context'),
    bmNoteInput: $('bm-note-input'),
    bmCancelBtn: $('bm-cancel-btn'),
    bmSaveBtn: $('bm-save-btn'),
    bmDeleteOverlay: $('bm-delete-overlay'),
    bmDeleteContext: $('bm-delete-context'),
    bmDeleteCancelBtn: $('bm-delete-cancel-btn'),
    bmDeleteConfirmBtn: $('bm-delete-confirm-btn'),
    snackbar: $('snackbar'),
    snackbarText: $('snackbar-text'),
    snackbarUndo: $('snackbar-undo'),
    centerToast: $('center-toast'),
    centerToastText: $('center-toast-text')
  };

})(window.HadithApp = window.HadithApp || {});

