
/* ===== js/services/book-store.js ===== */
/*!
 * js/services/book-store.js -- ডাউনলোড করা কিতাবের JSON পড়া ও মেমরিতে (একটি কিতাব) রাখা, অধ্যায়-অফসেট হিসাব
 *
 * Provides : App.loadBook, App.loadedBook, App.hadithAtSeq, App.findSeqByNumber, App.chapterOfSeq, App.chapterItems
 * Needs    : core/books, services/book-download
 *
 * কিতাবের গঠন (data): { v, id, name, count, ch:[ { n?, t, a?, s:[ { t, h:[ [নম্বর, আরবি, বাংলা], ... ] } ] } ] }
 * "seq" = কিতাবের শুরু থেকে হাদীসের ক্রমিক নম্বর (০ থেকে) -- বুকমার্ক/শেষ-পড়ার জন্য এটাই স্থায়ী ঠিকানা।
 */
(function (App) {
  "use strict";

  App.loadedBook = null;   // { id, data, chStart:[], total }
  var loading = null;      // { id, promise }

  function build(id, data){
    if (!data || !Array.isArray(data.ch)) throw new Error('bad-data');
    var chStart = [], n = 0;
    for (var c = 0; c < data.ch.length; c++){
      chStart.push(n);
      var secs = data.ch[c].s;
      for (var s = 0; s < secs.length; s++) n += secs[s].h.length;
    }
    return { id: id, data: data, chStart: chStart, total: n };
  }

  function loadBook(id){
    if (App.loadedBook && App.loadedBook.id === id) return Promise.resolve(App.loadedBook);
    if (loading && loading.id === id) return loading.promise;
    App.loadedBook = null; // আগের কিতাবের মেমরি ছেড়ে দিই
    var p = App.bookDl.readText(id).then(function(text){
      var data = JSON.parse(text);
      text = null;
      var b = build(id, data);
      App.loadedBook = b;
      loading = null;
      return b;
    }).catch(function(err){
      loading = null;
      throw err;
    });
    loading = { id: id, promise: p };
    return p;
  }
  App.loadBook = loadBook;

  // ---- seq -> অধ্যায় (binary search) ----
  function chapterOfSeq(book, seq){
    var lo = 0, hi = book.chStart.length - 1;
    while (lo < hi){
      var mid = (lo + hi + 1) >> 1;
      if (book.chStart[mid] <= seq) lo = mid; else hi = mid - 1;
    }
    return lo;
  }
  App.chapterOfSeq = chapterOfSeq;

  // ---- seq -> { c, h:[num, ar, bn] } ----
  function hadithAtSeq(book, seq){
    if (seq < 0 || seq >= book.total) return null;
    var c = chapterOfSeq(book, seq), k = seq - book.chStart[c];
    var secs = book.data.ch[c].s;
    for (var s = 0; s < secs.length; s++){
      if (k < secs[s].h.length) return { c: c, h: secs[s].h[k] };
      k -= secs[s].h.length;
    }
    return null;
  }
  App.hadithAtSeq = hadithAtSeq;

  // হাদীস-নম্বর থেকে (প্রথম) seq খোঁজা
  function findSeqByNumber(book, num){
    var seq = 0, ch = book.data.ch;
    for (var c = 0; c < ch.length; c++){
      for (var s = 0; s < ch[c].s.length; s++){
        var hs = ch[c].s[s].h;
        for (var i = 0; i < hs.length; i++, seq++){ if (hs[i][0] === num) return seq; }
      }
    }
    return -1;
  }
  App.findSeqByNumber = findSeqByNumber;

  // একটি অধ্যায়ের দেখানোর তালিকা: পরিচ্ছেদ-লেবেল ও হাদীস পরপর
  function chapterItems(book, c){
    var out = [], seq = book.chStart[c], secs = book.data.ch[c].s;
    for (var s = 0; s < secs.length; s++){
      if (secs[s].t) out.push({ k:'s', t: secs[s].t });
      var hs = secs[s].h;
      for (var i = 0; i < hs.length; i++) out.push({ k:'h', h: hs[i], seq: seq++ });
    }
    return out;
  }
  App.chapterItems = chapterItems;

})(window.HadithApp = window.HadithApp || {});

