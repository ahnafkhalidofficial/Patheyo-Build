
/* ===== js/core/state.js ===== */
/*!
 * js/core/state.js -- Shared runtime state: current tab / view, open book / chapter, tab to return to
 *
 * Provides : App.state, App.returnTab, App.curBookId, App.curChapter
 * Needs    : (nothing)
 */
(function (App) {
  "use strict";

  // view: 'list' (tabs) | 'book' (download card or chapter list) | 'chapter' (hadith reader)
  App.state = { tab:'books', view:'list', depth:0, chapterOrigin:'book' };

  // Remembers which top-level tab (books / bookmarks) was active right before a book or chapter was
  // opened, so the back button returns to that SAME tab -- e.g. opening a hadith from the bookmarks
  // list and going back must land on the bookmarks list again.
  App.returnTab = 'books';

  App.curBookId = null;    // the book shown in the book screen
  App.curChapter = 0;      // index of the chapter shown in the chapter reader

})(window.HadithApp = window.HadithApp || {});

