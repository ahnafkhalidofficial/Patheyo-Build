
/* ===== data/books-config.js ===== */
/*!
 * data/books-config.js -- ৬টি কিতাবের তালিকা ও ডাউনলোড-লিংক (এখানেই শুধু লিংক বসাতে হবে)
 *
 * Provides : window.__HADITH_CONFIG__
 * Needs    : (nothing)
 */
window.__HADITH_CONFIG__ = {

  // >>>>>>  নিচের লাইনে ডাবল-কোটের ভেতরে GitHub Release-এর "ফোল্ডার লিংক" বসান  <<<<<<
  // ৬টা ফাইলই একই Release-এ আপলোড করলে শুধু এই একটি লাইনই বসালে চলবে।
  // শেষে অবশ্যই "/" থাকতে হবে। উদাহরণ:
  //   "https://github.com/PatheyobyGunjoron/quran-assets-by-patheyo/releases/download/hadith-v1/"
  releaseBase: "PASTE_YOUR_RELEASE_FOLDER_LINK_HERE/",

  // ডেটা-ফাইল নতুন করে বানিয়ে আবার আপলোড করলে এই সংখ্যাটি ১ বাড়িয়ে দিন (যেমন 2) --
  // তাহলে ইউজারদের ফোনে নতুন ফাইলটি আবার ডাউনলোড হবে। না বাড়ালে পুরনো ফাইলই চলতে থাকবে।
  version: 1,

  books: [
    {
      id: "bukhari",
      nameBn: "সহীহ বুখারী",
      nameAr: "صحيح البخاري",
      nameEn: "Sahih al-Bukhari",
      file: "bukhari.json.gz",     // GitHub Release-এ এই নামেই ফাইলটি আপলোড করবেন
      url: "https://github.com/PatheyobyGunjoron/hadith-assets-by-patheyo/releases/download/Bukhari/bukhari.json.gz",                 // (ঐচ্ছিক) শুধু এই কিতাবের আলাদা লিংক; খালি রাখলে releaseBase + file ব্যবহার হবে
      count: 7053,              // হাদীস সংখ্যা
      chapters: 84,              // অধ্যায় সংখ্যা
      sizeBytes: 4003925        // ডাউনলোড ফাইলের সাইজ (bytes)
    },
    {
      id: "muslim",
      nameBn: "সহীহ মুসলিম",
      nameAr: "صحيح مسلم",
      nameEn: "Sahih Muslim",
      file: "muslim.json.gz",     // GitHub Release-এ এই নামেই ফাইলটি আপলোড করবেন
      url: "https://github.com/PatheyobyGunjoron/hadith-assets-by-patheyo/releases/download/Muslim/muslim.json.gz",                 // (ঐচ্ছিক) শুধু এই কিতাবের আলাদা লিংক; খালি রাখলে releaseBase + file ব্যবহার হবে
      count: 7279,              // হাদীস সংখ্যা
      chapters: 57,              // অধ্যায় সংখ্যা
      sizeBytes: 2660297        // ডাউনলোড ফাইলের সাইজ (bytes)
    },
    {
      id: "tirmidhi",
      nameBn: "জামে তিরমিযী",
      nameAr: "جامع الترمذي",
      nameEn: "Jami at-Tirmidhi",
      file: "tirmidhi.json.gz",     // GitHub Release-এ এই নামেই ফাইলটি আপলোড করবেন
      url: "https://github.com/PatheyobyGunjoron/hadith-assets-by-patheyo/releases/download/Tirmidhi/tirmidhi.json.gz",                 // (ঐচ্ছিক) শুধু এই কিতাবের আলাদা লিংক; খালি রাখলে releaseBase + file ব্যবহার হবে
      count: 3953,              // হাদীস সংখ্যা
      chapters: 48,              // অধ্যায় সংখ্যা
      sizeBytes: 1890241        // ডাউনলোড ফাইলের সাইজ (bytes)
    },
    {
      id: "abudawud",
      nameBn: "সুনানে আবু দাউদ",
      nameAr: "سنن أبي داود",
      nameEn: "Sunan Abi Dawud",
      file: "abudawud.json.gz",     // GitHub Release-এ এই নামেই ফাইলটি আপলোড করবেন
      url: "https://github.com/PatheyobyGunjoron/hadith-assets-by-patheyo/releases/download/Abudawud/abudawud.json.gz",                 // (ঐচ্ছিক) শুধু এই কিতাবের আলাদা লিংক; খালি রাখলে releaseBase + file ব্যবহার হবে
      count: 5179,              // হাদীস সংখ্যা
      chapters: 36,              // অধ্যায় সংখ্যা
      sizeBytes: 1976290        // ডাউনলোড ফাইলের সাইজ (bytes)
    },
    {
      id: "nasai",
      nameBn: "সুনানে নাসাঈ",
      nameAr: "سنن النسائي",
      nameEn: "Sunan an-Nasa'i",
      file: "nasai.json.gz",     // GitHub Release-এ এই নামেই ফাইলটি আপলোড করবেন
      url: "https://github.com/PatheyobyGunjoron/hadith-assets-by-patheyo/releases/download/Nasai/nasai.json.gz",                 // (ঐচ্ছিক) শুধু এই কিতাবের আলাদা লিংক; খালি রাখলে releaseBase + file ব্যবহার হবে
      count: 5754,              // হাদীস সংখ্যা
      chapters: 52,              // অধ্যায় সংখ্যা
      sizeBytes: 1737605        // ডাউনলোড ফাইলের সাইজ (bytes)
    },
    {
      id: "ibnmajah",
      nameBn: "সুনানে ইবনে মাজাহ",
      nameAr: "سنن ابن ماجه",
      nameEn: "Sunan Ibn Majah",
      file: "ibnmajah.json.gz",     // GitHub Release-এ এই নামেই ফাইলটি আপলোড করবেন
      url: "https://github.com/PatheyobyGunjoron/hadith-assets-by-patheyo/releases/download/Ibnmajah/ibnmajah.json.gz",                 // (ঐচ্ছিক) শুধু এই কিতাবের আলাদা লিংক; খালি রাখলে releaseBase + file ব্যবহার হবে
      count: 4332,              // হাদীস সংখ্যা
      chapters: 36,              // অধ্যায় সংখ্যা
      sizeBytes: 1357575        // ডাউনলোড ফাইলের সাইজ (bytes)
    }
  ]
};

