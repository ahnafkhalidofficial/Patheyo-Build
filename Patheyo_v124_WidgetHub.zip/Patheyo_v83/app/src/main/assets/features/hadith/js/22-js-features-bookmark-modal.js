
/* ===== js/features/bookmark-modal.js ===== */
/*!
 * js/features/bookmark-modal.js -- Add / edit bookmark dialog and the active-bookmark state
 *
 * Provides : App.activeBookmarkId, App.bookmarkTitle, App.closeBookmarkModal, App.openBookmarkModal,
 *            App.saveBookmarkFromModal, App.syncModalToViewport
 * Needs    : core/dom, core/books, core/utils, features/bookmark-fab, features/chapter-reader, features/feedback,
 *            services/bookmark-store
 */
(function (App) {
  "use strict";

  App.activeBookmarkId = null;

  function bookName(id){ var b = App.bookById(id); return b ? b.nameBn : ''; }

  function bookmarkTitle(bm){ return bookName(bm.book) + ' · হাদীস ' + App.bn(bm.num); }
  App.bookmarkTitle = bookmarkTitle;

  var bmDraft = null;

  // info: { book, seq, num, ch, ct }  |  existingId: edit that bookmark's note
  function openBookmarkModal(info, existingId){
    var existing = existingId ? findById(existingId) : App.findBookmark(info.book, info.seq);
    bmDraft = { book: info.book, seq: info.seq, num: info.num, ch: info.ch, ct: info.ct || '', id: existing ? existing.id : null,
                createdAt: existing ? existing.createdAt : null };
    App.els.bmModalTitle.textContent = existing ? 'বুকমার্ক সম্পাদনা' : 'বুকমার্ক যোগ করুন';
    App.els.bmModalContext.textContent = bookName(info.book) + ' — হাদীস ' + App.bn(info.num);
    App.els.bmNoteInput.value = existing ? (existing.label || '') : '';
    App.els.bmModalOverlay.classList.remove('hidden');
    syncModalToViewport();
    setTimeout(function(){ try{ App.els.bmNoteInput.focus(); }catch(e){} }, 50);
  }
  App.openBookmarkModal = openBookmarkModal;

  function findById(id){
    var arr = App.loadBookmarks();
    for (var i = 0; i < arr.length; i++){ if (arr[i].id === id) return arr[i]; }
    return null;
  }

  function syncModalToViewport(){
    if (!window.visualViewport) return;
    var vv = window.visualViewport;
    App.els.bmModalOverlay.style.top = vv.offsetTop + 'px';
    App.els.bmModalOverlay.style.height = vv.height + 'px';
  }
  App.syncModalToViewport = syncModalToViewport;

  function closeBookmarkModal(){
    App.els.bmModalOverlay.classList.add('hidden');
    App.els.bmModalOverlay.style.top = '';
    App.els.bmModalOverlay.style.height = '';
  }
  App.closeBookmarkModal = closeBookmarkModal;

  function saveBookmarkFromModal(){
    if (!bmDraft) return;
    var bm = {
      id: bmDraft.id || ('bm' + Date.now() + Math.random().toString(36).slice(2,7)),
      createdAt: bmDraft.createdAt || Date.now(),
      label: App.els.bmNoteInput.value.trim(),
      book: bmDraft.book, seq: bmDraft.seq, num: bmDraft.num, ch: bmDraft.ch, ct: bmDraft.ct
    };
    App.addOrUpdateBookmark(bm);
    closeBookmarkModal();
    App.showSnackbar('বুকমার্ক সংরক্ষণ করা হয়েছে');
    // The bookmark just saved (new or edited) becomes the active one, so the FAB turns into the live
    // green (synced) / grey (drifted) "save position" indicator right away -- same as in the Quran app.
    if (App.state.view === 'chapter' && App.curBookId === bm.book){
      App.activeBookmarkId = bm.id;
      App.activeBookmarkPos = { book: bm.book, seq: bm.seq };
      App.updateBmFabIcon();
      App.refreshCardMarks();
    }
  }
  App.saveBookmarkFromModal = saveBookmarkFromModal;

})(window.HadithApp = window.HadithApp || {});

