
/* ===== js/boot/theme-init.js ===== */
  /* Runs synchronously before any CSS is applied, so the very first paint already uses the
     user's saved theme -- this is what stops the "flash of dark then switch to the real theme"
     glitch on open. Must stay this early (before the <style> block) to work. */
  (function(){
    try{
      var t = localStorage.getItem('hadith-theme') || 'light';
      document.documentElement.setAttribute('data-theme', t);
    }catch(e){}
  })();

