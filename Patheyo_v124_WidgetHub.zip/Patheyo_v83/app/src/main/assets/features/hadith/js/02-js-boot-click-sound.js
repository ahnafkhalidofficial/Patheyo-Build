
/* ===== js/boot/click-sound.js ===== */
/* Click sounds (synthesised with WebAudio -- no audio files, works fully offline) + tap ripple. */
(function(){
  var ctx=null, master=null, noiseBuf=null, last=0, enabled=true, unlocked=false;
  enabled = false;   // ক্লিক সাউন্ড সম্পূর্ণ বন্ধ

  // Every sound is a small list of layers so the same recipe feeds both engines below.
  //  {k:'t'} tone: f0->f1 Hz, d sec, g gain, w wave, at delay   |   {k:'n'} noise burst: d, g, band f0->f1
  var RECIPES = {
    // Each control gets its own soft "click" voice (all short, no pitch sweeps, nothing drum-like).
    tap:      [ {k:'n',d:.014,g:.24,f0:2900,f1:2900}, {k:'t',f0:2400,f1:2400,d:.028,g:.16}, {k:'t',f0:1300,f1:1300,d:.022,g:.08} ],   // list rows, generic buttons
    tab:      [ {k:'n',d:.012,g:.22,f0:3500,f1:3500}, {k:'t',f0:2900,f1:2900,d:.026,g:.15}, {k:'t',f0:1500,f1:1500,d:.02,g:.07} ],    // tabs: crisper / brighter
    open:     [ {k:'n',d:.016,g:.22,f0:2600,f1:2600}, {k:'t',f0:2100,f1:2100,d:.03,g:.15},  {k:'t',f0:1050,f1:1050,d:.03,g:.10} ],    // continue card, mushaf page: warmer
    select:   [ {k:'n',d:.015,g:.24,f0:2500,f1:2500}, {k:'t',f0:2000,f1:2000,d:.03,g:.16},  {k:'t',f0:1000,f1:1000,d:.026,g:.10} ],   // choice buttons
    back:     [ {k:'n',d:.014,g:.20,f0:2000,f1:2000}, {k:'t',f0:1700,f1:1700,d:.028,g:.14}, {k:'t',f0:950,f1:950,d:.024,g:.07} ],     // lower = "going back"
    soft:     [ {k:'n',d:.012,g:.16,f0:2300,f1:2300}, {k:'t',f0:1900,f1:1900,d:.026,g:.11} ],                                          // cancel, skip, undo, clear
    close:    [ {k:'n',d:.012,g:.15,f0:2100,f1:2100}, {k:'t',f0:1600,f1:1600,d:.026,g:.10} ],                                          // tapping outside a dialog
    toggle:   [ {k:'n',d:.010,g:.18,f0:2200,f1:2200}, {k:'t',f0:2000,f1:2000,d:.022,g:.14},
                {k:'n',d:.010,g:.18,f0:3000,f1:3000,at:.05}, {k:'t',f0:2800,f1:2800,d:.022,g:.14,at:.05} ],                            // theme switch: two-step "switch"
    bookmark: [ {k:'n',d:.014,g:.22,f0:3000,f1:3000}, {k:'t',f0:2400,f1:2400,d:.028,g:.15}, {k:'t',f0:3300,f1:3300,d:.05,g:.08,at:.055} ], // pin: click + tiny blip
    success:  [ {k:'n',d:.012,g:.20,f0:2900,f1:2900}, {k:'t',f0:2400,f1:2400,d:.026,g:.14},
                {k:'n',d:.012,g:.20,f0:3700,f1:3700,at:.075}, {k:'t',f0:3100,f1:3100,d:.03,g:.14,at:.075} ],                          // saved: two rising ticks
    'delete': [ {k:'n',d:.018,g:.24,f0:1700,f1:1700}, {k:'t',f0:1250,f1:1250,d:.035,g:.15}, {k:'t',f0:850,f1:850,d:.04,g:.10,at:.05} ]  // lower, falling second tick
  };

  /* ---------- Engine 1: WebAudio ---------- */
  function ensure(){
    try{
      if (!ctx){
        var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
        ctx = new AC();
        master = ctx.createGain(); master.gain.value = 0.85;
        var comp = ctx.createDynamicsCompressor();
        comp.threshold.value = -10; comp.knee.value = 12; comp.ratio.value = 5; comp.attack.value = 0.002; comp.release.value = 0.12;
        master.connect(comp); comp.connect(ctx.destination);
        noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate*0.3), ctx.sampleRate);
        var d = noiseBuf.getChannelData(0); for (var i=0;i<d.length;i++) d[i] = Math.random()*2-1;
      }
      if (ctx.state !== 'running'){ try{ ctx.resume(); }catch(e){} }
      return ctx.state === 'running';
    }catch(e){ return false; }
  }
  function wTone(L){
    var t = ctx.currentTime + (L.at||0), dur = L.d;
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = L.w || 'sine';
    o.frequency.setValueAtTime(L.f0, t);
    if (L.f1 && L.f1 !== L.f0) o.frequency.exponentialRampToValueAtTime(L.f1, t+dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(L.g, t+Math.min(0.003, dur*0.2));
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t+dur+0.03);
  }
  function wNoise(L){
    var t = ctx.currentTime + (L.at||0), dur = L.d;
    var s = ctx.createBufferSource(); s.buffer = noiseBuf;
    var bp = ctx.createBiquadFilter(); bp.type='bandpass'; bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(L.f0, t); if (L.f1 !== L.f0) bp.frequency.exponentialRampToValueAtTime(L.f1, t+dur);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(L.g, t+Math.min(0.004, dur*0.3)); g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    s.connect(bp); bp.connect(g); g.connect(master); s.start(t); s.stop(t+dur+0.02);
  }
  function playWebAudio(type){
    var R = RECIPES[type] || RECIPES.tap;
    for (var i=0;i<R.length;i++){ if (R[i].k === 't') wTone(R[i]); else wNoise(R[i]); }
  }

  /* ---------- Engine 2 (fallback): pre-rendered WAV played through <audio> ---------- */
  var wavCache = {};
  function makeWavUrl(type){
    var R = RECIPES[type] || RECIPES.tap, SR = 22050, total = 0, i;
    for (i=0;i<R.length;i++) total = Math.max(total, (R[i].at||0) + R[i].d);
    var n = Math.ceil((total+0.03)*SR), buf = new Float32Array(n);
    R.forEach(function(L){
      var start = Math.floor((L.at||0)*SR), len = Math.floor(L.d*SR), phase = 0;
      for (var j=0;j<len && start+j<n;j++){
        var p = j/len, env = Math.pow(1-p, 2.6) * Math.min(1, j/(SR*0.002));
        var v;
        if (L.k === 't'){
          var f = L.f0 + (L.f1 - L.f0)*p; phase += 2*Math.PI*f/SR;
          v = (L.w === 'triangle') ? (2/Math.PI)*Math.asin(Math.sin(phase)) : Math.sin(phase);
        } else { var fc = L.f0 + (L.f1 - L.f0)*p; phase += 2*Math.PI*fc/SR; v = (Math.random()*2-1) * Math.sin(phase) * 1.2; }
        buf[start+j] += v * env * L.g;
      }
    });
    var pcm = new Int16Array(n);
    for (i=0;i<n;i++){ var x = Math.max(-1, Math.min(1, buf[i]*1.1)); pcm[i] = x < 0 ? x*32768 : x*32767; }
    var hdr = new ArrayBuffer(44), dv = new DataView(hdr);
    function ws(o,s){ for (var k=0;k<s.length;k++) dv.setUint8(o+k, s.charCodeAt(k)); }
    ws(0,'RIFF'); dv.setUint32(4, 36+pcm.length*2, true); ws(8,'WAVE'); ws(12,'fmt ');
    dv.setUint32(16,16,true); dv.setUint16(20,1,true); dv.setUint16(22,1,true);
    dv.setUint32(24,SR,true); dv.setUint32(28,SR*2,true); dv.setUint16(32,2,true); dv.setUint16(34,16,true);
    ws(36,'data'); dv.setUint32(40, pcm.length*2, true);
    return URL.createObjectURL(new Blob([hdr, pcm.buffer], {type:'audio/wav'}));
  }
  function playFallback(type){
    try{
      if (!wavCache[type]) wavCache[type] = makeWavUrl(type);
      var a = new Audio(wavCache[type]); a.volume = 1; var p = a.play(); if (p && p.catch) p.catch(function(){});
    }catch(e){}
  }

  function play(type){
    if (!enabled) return;
    var now = Date.now(); if (now - last < 25) return; last = now;
    var ok = false;
    try{ ok = ensure(); }catch(e){}
    if (ok){ try{ playWebAudio(type); return; }catch(e){} }
    playFallback(type);   // first tap (context still waking up) or WebAudio unavailable
  }
  window.UISound = { play: function(){}, setEnabled: function(){} };

  // Wake the audio engine on the very first touch so the first real click already has sound.
  function unlock(){
    if (unlocked) return; unlocked = true;
    // সাউন্ড বন্ধ -- অডিও ইঞ্জিন চালু করা হয় না
    ['pointerdown','touchstart','keydown'].forEach(function(n){ document.removeEventListener(n, unlock, true); });
  }
  ['pointerdown','touchstart','keydown'].forEach(function(n){ document.addEventListener(n, unlock, true); });

  var SEL = 'button, a, label, [role="button"], .list-item, .tab, .continue-card, .choice-btn, .tools button';
  document.addEventListener('click', function(e){
    var el = e.target && e.target.closest ? e.target.closest(SEL) : null;
    var t = e.target;
    var isBackdrop = t && t.classList && (t.classList.contains('bm-modal-overlay') || t.classList.contains('choice-overlay'));
    if (!el && !isBackdrop) return;
    if (el && (el.disabled || el.getAttribute('aria-disabled') === 'true')) return;
    var type = 'tap';
    if (isBackdrop) type = 'close';
    else {
      var id = el.id || '', cl = el.classList;
      if (id === 'bm-save-btn') type = 'success';
      else if (id === 'bm-delete-confirm-btn' || id === 'book-remove-confirm-btn') type = 'delete';
      else if (cl.contains('bm-fab') || cl.contains('hd-bm')) type = 'bookmark';
      else if (cl.contains('back-btn') || id === 'pf-close-btn') type = 'back';
      else if (cl.contains('tab')) type = 'tab';
      else if (el.closest && el.closest('.tools')){
        type = 'toggle';
        var root = document.documentElement; root.classList.add('fx-theme');
        clearTimeout(window.__fxTheme); window.__fxTheme = setTimeout(function(){ root.classList.remove('fx-theme'); }, 550);
      }
      else if (cl.contains('continue-card')) type = 'open';
      else if (cl.contains('choice-btn')) type = 'select';
      else if (id === 'bm-cancel-btn' || id === 'bm-delete-cancel-btn' || id === 'book-remove-cancel-btn' || id === 'choice-cancel-btn' || id === 'ob-skip' ||
               id === 'snackbar-undo' || id === 'search-clear') type = 'soft';
    }
    // play(type);  (সাউন্ড বন্ধ)
    try{ if (navigator.vibrate) navigator.vibrate(type === 'delete' ? 14 : 6); }catch(err){}
  }, true);
})();

