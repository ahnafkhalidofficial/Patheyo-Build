
/* ===== js/core/books.js ===== */
/*!
 * js/core/books.js -- The book list (from data/books-config.js) and download-link helpers
 *
 * Provides : App.BOOKS, App.DATA_VERSION, App.bookById, App.bookIndex, App.getBookUrl, App.localFileName
 * Needs    : data/books-config
 */
(function (App) {
  "use strict";

  var cfg = window.__HADITH_CONFIG__ || { books: [] };

  App.BOOKS = cfg.books || [];
  App.DATA_VERSION = parseInt(cfg.version, 10) || 1;

  App.bookById = function(id){
    for (var i = 0; i < App.BOOKS.length; i++){ if (App.BOOKS[i].id === id) return App.BOOKS[i]; }
    return null;
  };
  App.bookIndex = function(id){
    for (var i = 0; i < App.BOOKS.length; i++){ if (App.BOOKS[i].id === id) return i; }
    return -1;
  };

  // The file name the phone keeps the (unpacked) book under -- the data version is part of it,
  // so bumping `version` in books-config.js makes every phone fetch the new file.
  App.localFileName = function(id){ return id + '-v' + App.DATA_VERSION + '.json'; };

  // ---- download address: per-book `url`, otherwise `releaseBase` + `file`.
  // A GitHub "blob" page link is turned into the real (raw) file link automatically. ----
  App.getBookUrl = function(id){
    var b = App.bookById(id);
    if (!b) return '';
    var u = String(b.url || '').trim();
    if (!u){
      var base = String(cfg.releaseBase || '').trim();
      if (!base) return '';
      u = base.replace(/\/+$/, '') + '/' + b.file;
    }
    if (!/^https:\/\//i.test(u) || /PASTE_YOUR/i.test(u)) return '';
    var m = u.match(/^https:\/\/github\.com\/([^\/]+)\/([^\/]+)\/blob\/(.+)$/i);
    if (m) u = 'https://raw.githubusercontent.com/' + m[1] + '/' + m[2] + '/' + m[3].split('?')[0];
    return u;
  };

})(window.HadithApp = window.HadithApp || {});

