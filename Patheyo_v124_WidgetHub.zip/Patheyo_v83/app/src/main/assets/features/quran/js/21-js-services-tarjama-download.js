
/*!
 * js/services/tarjama-download.js -- তরজমা ফাইল অনলাইন থেকে ডাউনলোড (লাইভ প্রগ্রেস, গতি, বাকি সময়) ও লোকাল স্টোরেজ
 *
 * Provides : App.tarjamaDownload  { getUrl, hasNative, isReady, getState, getKnownTotal, subscribe, start, cancel,
 *                                   readText, discard, setError, syncFromNative, _onNative }
 * Needs    : data/tarjama-config
 *
 * দুইটি ব্যাকএন্ড (মুসহাফ PDF-এর মতোই):
 *  1) Android অ্যাপ (window.QuranTarjamaNative আছে): Kotlin ডাউনলোড করে অ্যাপের স্টোরেজে সেভ করে; এখানে শুধু প্রগ্রেস আসে।
 *  2) সাধারণ ব্রাউজার (টেস্টিং): XHR দিয়ে নামিয়ে (.gz হলে খুলে) IndexedDB-তে রাখে।
 */
(function (App) {
  "use strict";

  var cfg = window.__QURAN_TARJAMA_CONFIG__ || {};
  var native = (window.QuranTarjamaNative && typeof window.QuranTarjamaNative.isTarjamaReady === 'function') ? window.QuranTarjamaNative : null;
  var LOCAL_URL = 'https://quran-local.invalid/Quran-Tarjama.json';

  var state = { phase:'idle', downloaded:0, total:0, speed:0, eta:null, error:null };
  var listeners = [];
  var sample = null;
  var xhr = null;
  var webText = null;         // ব্রাউজার ব্যাকএন্ড: ডাউনলোড করা JSON লেখা (মেমরিতে)
  var webChecked = false;     // IndexedDB একবার দেখা হয়েছে কি

  function emit(){ listeners.slice().forEach(function(fn){ try{ fn(state); }catch(e){} }); }

  function subscribe(fn){
    listeners.push(fn);
    return function(){ listeners = listeners.filter(function(f){ return f !== fn; }); };
  }

  // GitHub-এর "blob" পেজের লিংক দিলেও আসল ফাইলের (raw) লিংকে বদলে নেয়
  function getUrl(){
    var u = String(cfg.url || '').trim();
    if (!/^https:\/\//i.test(u) || /PASTE_YOUR/i.test(u)) return '';
    var m = u.match(/^https:\/\/github\.com\/([^\/]+)\/([^\/]+)\/blob\/(.+)$/i);
    if (m) u = 'https://raw.githubusercontent.com/' + m[1] + '/' + m[2] + '/' + m[3].split('?')[0];
    return u;
  }

  function knownTotal(){ return state.total > 0 ? state.total : (cfg.sizeBytes || 0); }

  function track(bytes){
    var now = Date.now();
    if (!sample){ sample = { t:now, b:bytes }; return; }
    var dt = now - sample.t;
    if (dt < 500) return;
    var inst = Math.max(0, (bytes - sample.b) / dt * 1000);
    state.speed = state.speed ? state.speed * 0.6 + inst * 0.4 : inst;
    sample = { t:now, b:bytes };
    var t = knownTotal();
    state.eta = (t > 0 && state.speed > 1024) ? Math.max(0, (t - bytes) / state.speed) : null;
  }

  function reset(phase){ state.phase = phase; state.speed = 0; state.eta = null; sample = null; }

  // ---------------------------------------------------------------- Android (native)
  function onNative(ev){
    if (!ev) return;
    var prev = state.phase;
    state.downloaded = ev.downloaded || 0;
    state.total = ev.total > 0 ? ev.total : 0;
    state.error = ev.error || null;
    if (ev.phase === 'downloading'){
      if (prev !== 'downloading'){ reset('downloading'); }
      track(state.downloaded);
    } else if (ev.phase === 'done'){
      reset('done'); state.downloaded = state.total = (ev.total > 0 ? ev.total : state.downloaded);
    } else if (ev.phase === 'error'){
      reset('error');
    } else {
      reset('idle'); state.downloaded = 0;
    }
    emit();
  }

  function syncFromNative(){
    if (!native) return;
    try { onNative(JSON.parse(native.getStatus())); } catch(e){}
  }

  // ---------------------------------------------------------------- ব্রাউজার (টেস্ট): IndexedDB
  var DB_NAME = 'quran-tarjama', STORE = 'files', KEY = 'tarjama-json';

  function idb(mode, fn){
    return new Promise(function(resolve, reject){
      var req;
      try { req = indexedDB.open(DB_NAME, 1); } catch(e){ reject(e); return; }
      req.onupgradeneeded = function(){ req.result.createObjectStore(STORE); };
      req.onerror = function(){ reject(req.error); };
      req.onsuccess = function(){
        var db = req.result, tx = db.transaction(STORE, mode), st = tx.objectStore(STORE), r = fn(st);
        tx.oncomplete = function(){ db.close(); resolve(r && r.result); };
        tx.onerror = tx.onabort = function(){ db.close(); reject(tx.error); };
      };
    });
  }
  function idbGet(){ return idb('readonly', function(st){ return st.get(KEY); }); }
  function idbPut(v){ return idb('readwrite', function(st){ return st.put(v, KEY); }); }
  function idbDel(){ return idb('readwrite', function(st){ return st.delete(KEY); }); }

  function bytesToText(buf){
    var u8 = new Uint8Array(buf);
    if (u8.length > 2 && u8[0] === 0x1f && u8[1] === 0x8b){            // gzip
      if (typeof DecompressionStream !== 'function') return Promise.reject(new Error('no-gzip'));
      var ds = new DecompressionStream('gzip');
      var stream = new Response(new Blob([u8]).stream().pipeThrough(ds));
      return stream.text();
    }
    return Promise.resolve(new TextDecoder('utf-8').decode(u8));
  }

  function acceptBuffer(buf){
    return bytesToText(buf).then(function(text){
      if (text.slice(0, 10) !== '{"format":'){ throw new Error('not-tarjama'); }
      webText = text; webChecked = true;
      return idbPut(text).catch(function(){ /* স্টোরেজ না পেলেও এই সেশনে চলবে */ });
    });
  }
  function failWith(e){
    xhr = null;
    if (e && e.code === 'abort'){ reset('idle'); state.downloaded = 0; emit(); return; }
    var code = 'corrupt';
    if (e && typeof e.code === 'string') code = e.code;
    else if (e && e.message === 'not-tarjama') code = 'not-tarjama';
    else if (e && e.message === 'no-gzip') code = 'no-gzip';
    reset('error'); state.error = code; emit();
  }
  function startWeb(url){
    reset('downloading'); state.downloaded = 0; state.error = null; emit();
    xhr = App.netFetch(url, {
      onProgress: function(loaded, total){ state.downloaded = loaded; if (total > 0) state.total = total; track(loaded); emit(); },
      validate: function(buf){
        var u = new Uint8Array(buf, 0, Math.min(10, buf.byteLength));
        return (u[0] === 0x1f && u[1] === 0x8b) || String.fromCharCode.apply(null, u) === '{"format":';
      }
    });
    xhr.promise.then(function(buf){
      xhr = null;
      var n = buf.byteLength;
      return acceptBuffer(buf).then(function(){ state.downloaded = state.total = n || state.total; reset('done'); emit(); });
    }).catch(failWith);
  }
  // ব্যবহারকারী নিজে ফাইল বেছে নিলে
  function loadBuffer(buf){
    reset('downloading'); state.downloaded = 0; state.error = null; emit();
    var n = buf.byteLength;
    return acceptBuffer(buf).then(function(){ state.downloaded = state.total = n; reset('done'); emit(); }).catch(failWith);
  }

  // ---------------------------------------------------------------- public API
  function start(){
    if (state.phase === 'downloading') return;
    var url = getUrl();
    if (!url){ reset('error'); state.error = 'no-url'; emit(); return; }
    state.error = null;
    if (native){
      reset('downloading'); state.downloaded = state.downloaded || 0; emit();
      try { native.startDownload(url); }
      catch(e){ reset('error'); state.error = 'network'; emit(); }
    } else {
      startWeb(url);
    }
  }

  function cancel(){
    if (state.phase !== 'downloading') return;
    if (native){ try{ native.cancelDownload(); }catch(e){} }
    else if (xhr){ xhr.abort(); }
  }

  function isReady(){
    if (native){ try{ return !!native.isTarjamaReady(); }catch(e){ return false; } }
    return !!webText;
  }

  // ---- ডাউনলোড করা ফাইলের লেখা পড়া (Promise<string>); ফাইল না থাকলে code='missing' দিয়ে reject ----
  function missing(){ var e = new Error('missing'); e.code = 'missing'; return e; }

  function readViaUrl(){
    return new Promise(function(resolve, reject){
      var x = new XMLHttpRequest();
      x.open('GET', LOCAL_URL, true);
      x.responseType = 'text';
      x.onload = function(){
        if (x.status === 200 && x.responseText && x.responseText.length > 0) resolve(x.responseText);
        else reject(new Error('local-url-status-' + x.status));
      };
      x.onerror = function(){ reject(new Error('local-url-error')); };
      x.send();
    });
  }

  function readViaBridge(){
    var size = native.getTarjamaSize();
    if (!size) return Promise.reject(new Error('empty'));
    var out = new Uint8Array(size), CHUNK = 1024 * 1024, off = 0;
    return new Promise(function(resolve, reject){
      (function next(){
        if (off >= size){ resolve(new TextDecoder('utf-8').decode(out)); return; }
        try {
          var b64 = native.readChunk(off, Math.min(CHUNK, size - off));
          var bin = atob(b64);
          for (var i = 0; i < bin.length; i++) out[off + i] = bin.charCodeAt(i);
          off += bin.length;
          if (!bin.length){ reject(new Error('short-read')); return; }
        } catch(e){ reject(e); return; }
        setTimeout(next, 0);
      })();
    });
  }

  function readText(){
    if (native){
      if (!isReady()) return Promise.reject(missing());
      return readViaUrl().catch(function(){ return readViaBridge(); });
    }
    if (webText) return Promise.resolve(webText);
    if (webChecked) return Promise.reject(missing());
    return idbGet().then(function(v){
      webChecked = true;
      if (typeof v === 'string' && v.length){ webText = v; return v; }
      throw missing();
    }, function(){ webChecked = true; throw missing(); });
  }

  // ফাইল নষ্ট (corrupt) হলে মুছে দেয়, যাতে ইউজার আবার ডাউনলোড করতে পারে
  function discard(){
    if (native){ try { native.deleteTarjama(); } catch(e){} }
    else { webText = null; webChecked = true; idbDel().catch(function(){}); }
    reset('idle'); state.downloaded = 0; emit();
  }

  // বাইরে থেকে ত্রুটির অবস্থা দেখানোর জন্য (যেমন ফাইল নষ্ট ধরা পড়লে)
  function setError(code){ reset('error'); state.error = code; emit(); }

  App.tarjamaDownload = {
    getUrl: getUrl,
    hasNative: function(){ return !!native; },
    isReady: isReady,
    getState: function(){ return state; },
    getKnownTotal: knownTotal,
    subscribe: subscribe,
    start: start,
    cancel: cancel,
    readText: readText,
    discard: discard,
    setError: setError,
    loadBuffer: loadBuffer,
    syncFromNative: syncFromNative,
    _onNative: onNative
  };

  syncFromNative();

})(window.QuranApp = window.QuranApp || {});

