
/*!
 * js/features/web-reader.js -- Para "web page" reader: text pages with page numbers
 *
 * Provides : App.closeParaWebPage, App.getCurrentVisibleWebPage, App.openParaWebPage
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/mushaf-pages, data/para-meta,
               features/bookmark-fab, features/bookmark-modal, features/last-read, features/navigation,
               features/sura-reader
 */
(function (App) {
  "use strict";

  // ---- Web-page reader ("ওয়েব পেজে পড়ুন") ----
  // Builds the same {suraIndex, ayahIndex, text, bismillah, isFirstOfSura, noNumber} items used by
  // the single-sura reader, but for one Mushaf-style page (per PAGE_DATA), possibly spanning more
  // than one sura, and honouring the known mid-ayah page break (sura 6, ayah 73).
  // The marker is the last word before the break; the waqf sign(s) that follow it are included automatically
  // (see splitCutIndex), so the sign stays at the END of the first page, not at the start of the next one.
  var SPLIT_AYAHS = {
    '6-73': '\u0643\u064F\u0646\u06E1 \u0641\u064E\u064A\u064E\u0643\u064F\u0648\u06E1\u0646\u064F'
  };

  // index just after the marker word and the waqf marks that directly follow it (-1 when the marker is not found)
  function splitCutIndex(text, marker){
    var i = text.indexOf(marker);
    if (i === -1) return -1;
    var cut = i + marker.length;
    var m = /^\s*[\u0610-\u061A\u06D6-\u06ED]+/.exec(text.slice(cut));
    return m ? cut + m[0].length : cut;
  }

  function buildPageFlat(pageNum){
    var d = App.PAGE_DATA[pageNum-1];
    var ss = d[0], sa = d[1], es = d[2], ea = d[3];
    if (ss === 1 && es === 1){ return App.buildFatihaFlat(); }
    var out = [];
    for (var s = ss; s <= es; s++){
      var sura = App.quranModel[s-1];
      var aStart = (s === ss) ? sa : 1;
      var aEnd = (s === es) ? ea : sura.ayahs.length;
      for (var a = aStart; a <= aEnd; a++){
        var ayah = sura.ayahs[a-1];
        var text = ayah.text;
        var noNumber = false;
        var splitMarker = SPLIT_AYAHS[s + '-' + a];
        if (splitMarker){
          var cut = splitCutIndex(text, splitMarker);
          if (cut !== -1){
            if (a === ea && s === es && pageNum < App.PAGE_DATA.length && App.PAGE_DATA[pageNum][0] === s && App.PAGE_DATA[pageNum][1] === a){
              // this page ends mid-ayah; show only the first half, no verse-number yet
              text = text.slice(0, cut).trim();
              noNumber = true;
            } else if (a === sa && s === ss && pageNum > 1 && App.PAGE_DATA[pageNum-2][2] === s && App.PAGE_DATA[pageNum-2][3] === a){
              // this page starts with the remainder of the previous page's last (split) ayah
              text = text.slice(cut).trim();
            }
          }
        }
        out.push({
          suraIndex: s, ayahIndex: a, text: text, bismillah: ayah.bismillah,
          isFirstOfSura: (a === 1), isOpeningBismillah: false, noNumber: noNumber
        });
      }
    }
    return out;
  }

  function renderParaWebContent(paraIdx){
    App.els.webVerses.innerHTML = '';
    var range = App.PARA_PAGE_RANGE[paraIdx-1];
    var frag = document.createDocumentFragment();
    for (var p = range[0]; p <= range[1]; p++){
      var pageWrap = document.createElement('div');
      pageWrap.className = 'qp-page';
      pageWrap.setAttribute('data-page', p);
      var head = document.createElement('div');
      head.className = 'qp-page-head';
      head.innerHTML =
        '<div class="qp-page-para">পারা ' + App.bn(paraIdx) + '</div>' +
        '<div class="qp-page-num">পৃষ্ঠা ' + App.bn(p) + '</div>' +
        '<div class="qp-page-parapage">' + App.bn(App.pageIndexInPara(p)) + ' / ' + App.bn(range[1]-range[0]+1) + '</div>';
      pageWrap.appendChild(head);
      var body = document.createElement('div');
      body.className = 'qp-page-body';
      pageWrap.appendChild(body);
      App.renderFlatList(buildPageFlat(p), true, body);
      frag.appendChild(pageWrap);
      if (p < range[1]){
        var gap = document.createElement('div');
        gap.className = 'qp-page-gap';
        frag.appendChild(gap);
      }
    }
    App.els.webVerses.appendChild(frag);
  }

  var currentWebParaIdx = 1;

  function openParaWebPage(idx){
    App.returnTab = App.state.tab;
    App.activeBookmarkId = null; App.activeBookmarkPos = null; App.updateBmFabIcon();
    App.els.paraPanel.classList.add('hidden');
    App.els.continueCard.classList.add('hidden');
    App.els.webPagePanel.classList.remove('hidden');
    window.scrollTo(0,0);
    currentWebParaIdx = idx;
    var startSura = App.quranModel[App.JUZ_START[idx-1][0]-1];
    App.els.webPageBadge.textContent = 'পারা ' + App.bn(idx);
    App.els.webPageMeta.textContent = 'পৃষ্ঠা ' + App.bn(App.PARA_PAGE_RANGE[idx-1][0]) + '–' + App.bn(App.PARA_PAGE_RANGE[idx-1][1]);
    renderParaWebContent(idx);
    App.saveLastRead('para-web', idx, 'পারা ' + App.bn(idx) + ' — ওয়েব পেজ', { pageNum: App.PARA_PAGE_RANGE[idx-1][0] });
    App.pushHistory('para-web');
  }
  App.openParaWebPage = openParaWebPage;

  function closeParaWebPage(){
    App.els.webPagePanel.classList.add('hidden');
    App.switchTab(App.returnTab);
  }
  App.closeParaWebPage = closeParaWebPage;

  function getCurrentVisibleWebPage(){
    var pages = App.els.webVerses.querySelectorAll('.qp-page');
    var best = null;
    for (var i = 0; i < pages.length; i++){
      var rect = pages[i].getBoundingClientRect();
      if (rect.top <= 140){ best = pages[i]; } else { break; }
    }
    if (!best) best = pages[0];
    return best ? parseInt(best.getAttribute('data-page'), 10) : App.PARA_PAGE_RANGE[currentWebParaIdx-1][0];
  }
  App.getCurrentVisibleWebPage = getCurrentVisibleWebPage;

})(window.QuranApp = window.QuranApp || {});

