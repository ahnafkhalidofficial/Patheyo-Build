
/*!
 * js/core/quran-meta.js -- Helpers over the Quran metadata: surah-name / Bismillah SVG markup, Para <-> page lookups
 *
 * Provides : App.bismillahSvg, App.pageIndexInPara, App.paraForPage, App.surahGlyph
 * Needs    : data/para-meta, data/surah-meta
 */
(function (App) {
  "use strict";

  // Surah name calligraphy: the 114 images from muslimbangla.com (assets/features/quran/img/surah_names/s_N.png).
  // The image is used as a mask, so the name is painted in the current text colour (works in light and dark themes).
  // The hidden <img> only gives the span its natural width at whatever height the CSS class sets.
  var SURAH_IMG_BASE = 'https://appassets.patheyo.invalid/features/quran/img/surah_names/s_';
  function surahGlyph(index, cls){
    var url = SURAH_IMG_BASE + index + '.png';
    return '<span class="surah-glyph sg-img ' + cls + '" style="-webkit-mask-image:url(' + url + ');mask-image:url(' + url + ')" aria-hidden="true"><img src="' + url + '" alt="" draggable="false"></span>';
  }
  App.surahGlyph = surahGlyph;

  function bismillahSvg(){
    return '<svg class="bismillah-svg" width="936" height="180" viewBox="' + App.BISMILLAH_VB + '" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true"><use href="#bismillah-g" xlink:href="#bismillah-g"></use></svg>';
  }
  App.bismillahSvg = bismillahSvg;

  function paraForPage(n){
    for (var i=0;i<App.PARA_PAGE_RANGE.length;i++){
      if (n >= App.PARA_PAGE_RANGE[i][0] && n <= App.PARA_PAGE_RANGE[i][1]) return i+1;
    }
    return 1;
  }
  App.paraForPage = paraForPage;

  function pageIndexInPara(n){ return n - App.PARA_PAGE_RANGE[paraForPage(n)-1][0] + 1; }
  App.pageIndexInPara = pageIndexInPara;

})(window.QuranApp = window.QuranApp || {});

