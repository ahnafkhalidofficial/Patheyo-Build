
/* Theme switch: briefly adds html.fx-theme so the colours cross-fade instead of snapping (see css/motion.css).
   (The old click sounds were removed on request.) */
(function(){
  document.addEventListener('click', function(e){
    var el = e.target && e.target.closest ? e.target.closest('.tools') : null;
    if (!el) return;
    var root = document.documentElement;
    root.classList.add('fx-theme');
    clearTimeout(window.__fxTheme);
    window.__fxTheme = setTimeout(function(){ root.classList.remove('fx-theme'); }, 550);
  }, true);
})();

