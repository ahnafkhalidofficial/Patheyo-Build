
/*!
 * js/features/bookmark-fab.js -- Bookmark floating button: saved-position tracking and icon state
 *
 * Provides : App.activeBookmarkPos, App.bmTapPulse, App.getCurrentVisibleAyah, App.updateBmFabIcon,
               App.updateBookmarkPosition
 * Needs    : core/dom, core/state, features/bookmark-list, features/bookmark-modal, features/feedback,
               features/mushaf-fullscreen, features/mushaf-viewer, features/web-reader,
               services/bookmark-store
 */
(function (App) {
  "use strict";

  // ---- "Update this bookmark" vs "add a new bookmark" ----
  // While a view was opened FROM a saved bookmark (activeBookmarkId set in goToBookmark), every
  // bookmark FAB on screen shows a "save/update" icon instead of the usual "add" icon; tapping it
  // silently moves that same bookmark to the current reading position instead of creating a new one.
  // On top of that, the button is coloured to show whether it's still AT the saved spot (green,
  // "synced") or the reader has moved away from it while reading on (grey, "drifted") -- tapping it
  // in either case updates the bookmark to right here and turns it green again.
  var BM_ICON_ADD = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21 12 16 5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>';

  var BM_ICON_UPDATE = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"></path><path d="M17 21v-8H7v8"></path><path d="M7 3v5h6"></path></svg>';

  App.activeBookmarkPos = null;

 // the position the active bookmark is currently saved at, to compare against
  var BM_FABS = null;

  function bmFabList(){
    if (!BM_FABS) BM_FABS = [App.els.suraBmFab, App.els.paraBmFab, App.els.webBmFab, App.els.pfBookmarkBtn].filter(Boolean);
    return BM_FABS;
  }

  function isAtSavedPosition(){
    if (!App.activeBookmarkPos) return false;
    if (App.activeBookmarkPos.type === 'sura'){
      var pos = getCurrentVisibleAyah();
      return !!pos && pos.sura === App.activeBookmarkPos.suraIndex && pos.ayah === App.activeBookmarkPos.ayahIndex;
    }
    var pageNow;
    if (App.state.view === 'para-web') pageNow = App.getCurrentVisibleWebPage();
    else if (App.state.view === 'para-fullscreen') pageNow = App.pf.current;
    else pageNow = App.pageState.current;
    return pageNow === App.activeBookmarkPos.pageNum;
  }

  function updateBmFabIcon(){
    var icon = App.activeBookmarkId ? BM_ICON_UPDATE : BM_ICON_ADD;
    var label = App.activeBookmarkId ? 'বুকমার্ক আপডেট করুন' : 'বুকমার্ক';
    var synced = App.activeBookmarkId ? isAtSavedPosition() : false;
    bmFabList().forEach(function(btn){
      btn.innerHTML = icon;
      btn.setAttribute('aria-label', label);
      btn.classList.toggle('bm-synced', !!App.activeBookmarkId && synced);
      btn.classList.toggle('bm-drifted', !!App.activeBookmarkId && !synced);
    });
  }
  App.updateBmFabIcon = updateBmFabIcon;

  function bmTapPulse(btn){
    if (!btn) return;
    btn.classList.remove('bm-tap-anim');
    void btn.offsetWidth;
    btn.classList.add('bm-tap-anim');
    setTimeout(function(){ btn.classList.remove('bm-tap-anim'); }, 400);
  }
  App.bmTapPulse = bmTapPulse;

  function updateBookmarkPosition(id, patch){
    var arr = App.loadBookmarks();
    var found = null;
    for (var i=0;i<arr.length;i++){
      if (arr[i].id === id){
        for (var k in patch){ if (patch.hasOwnProperty(k)) arr[i][k] = patch[k]; }
        found = arr[i];
        break;
      }
    }
    if (!found){ App.activeBookmarkId = null; App.activeBookmarkPos = null; updateBmFabIcon(); return; }
    App.saveBookmarksArr(arr);
    App.renderBookmarksList();
    App.activeBookmarkPos = { type: found.type, suraIndex: found.suraIndex, ayahIndex: found.ayahIndex, pageNum: found.pageNum, mode: found.mode };
    updateBmFabIcon();
    App.showCenterToast('বুকমার্ক আপডেট হয়েছে');
  }
  App.updateBookmarkPosition = updateBookmarkPosition;

  function getCurrentVisibleAyah(){
    var nums = App.els.verses.querySelectorAll('.aya-number');
    var best = null;
    for (var i=0;i<nums.length;i++){
      var rect = nums[i].getBoundingClientRect();
      if (rect.top <= 160){ best = nums[i]; } else { break; }
    }
    if (!best && nums.length) best = nums[0];
    return best ? { sura: parseInt(best.getAttribute('data-sura'),10), ayah: parseInt(best.getAttribute('data-ayah'),10) } : null;
  }
  App.getCurrentVisibleAyah = getCurrentVisibleAyah;

})(window.QuranApp = window.QuranApp || {});

