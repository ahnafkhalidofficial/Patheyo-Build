/* Android WebView: কুরআন ডাউনলোড ব্রিজ (QuranNative / QuranTarjamaNative) এই ফ্রেমে নিশ্চিত করা */
(function(){try{var p=window.parent;if(p&&p!==window){if(!window.QuranNative&&p.QuranNative)window.QuranNative=p.QuranNative;if(!window.QuranTarjamaNative&&p.QuranTarjamaNative)window.QuranTarjamaNative=p.QuranTarjamaNative;}}catch(e){}})();
