
/*!
 * data/para-meta.js -- 30 Juz (Para) start positions and the Mushaf page range of every Para
 *
 * Provides : App.JUZ_START, App.PARA_PAGE_RANGE, App.TOTAL_PAGES
 * Needs    : (nothing)
 */
(function (App) {
  "use strict";

  // Standard 30-Juz (Para) starting points: [sura, ayah]
  App.JUZ_START = [
    [1,1],[2,142],[2,253],[3,93],[4,24],[4,148],[5,82],[6,111],[7,88],[8,41],
    [9,93],[11,6],[12,53],[15,1],[17,1],[18,75],[21,1],[23,1],[25,21],[27,56],
    [29,46],[33,31],[36,28],[39,32],[41,47],[46,1],[51,31],[58,1],[67,1],[78,1]
  ];

  // Page-image range [firstPage, lastPage] per Para, matching the user's own scanned
  // Mushaf ("Page (N).jpg" files placed alongside this HTML file), 1-indexed, 610 pages total.
  App.PARA_PAGE_RANGE = [
    [1,21],[22,41],[42,61],[62,81],[82,101],[102,121],[122,141],[142,161],[162,181],[182,201],
    [202,221],[222,241],[242,261],[262,281],[282,301],[302,321],[322,341],[342,361],[362,381],[382,401],
    [402,421],[422,441],[442,461],[462,481],[482,501],[502,521],[522,541],[542,561],[562,585],[586,610]
  ];

  App.TOTAL_PAGES = App.PARA_PAGE_RANGE[App.PARA_PAGE_RANGE.length-1][1];

})(window.QuranApp = window.QuranApp || {});

