
/*!
 * js/features/mushaf-fullscreen.js -- Fullscreen Mushaf pager: 3-slot swipe navigation, page info, Para toast
 *
 * Provides : App.bindDragNav, App.closeFullscreenPage, App.getPfSlots, App.openFullscreenPage, App.pf
 * Needs    : core/dom, core/quran-meta, core/utils, data/para-meta, features/bookmark-fab, features/last-read,
               features/mushaf-viewer, features/navigation, features/pinch-zoom, services/pdf-service
 */
(function (App) {
  "use strict";

  // ---- Fullscreen page-by-page swipeable viewer ----
  // Slot layout is fixed by position (left=-100%, center=0, right=+100%). Since this is a
  // right-to-left (Arabic) reading direction: dragging right-to-left reveals the RIGHT slot
  // and goes to the PREVIOUS page (backward, like physically turning a Mushaf page); dragging
  // left-to-right reveals the LEFT slot and goes to the NEXT page (forward).
  var pf = { current:1, dragging:false, startX:0, startY:0, dragX:0, locked:null, animating:false, turning:false };
  App.pf = pf;

  var pfSlots = null;

 // {prev, current, next} DOM elements (left/center/right), set once on first open

  function getPfSlots(){
    if (!pfSlots){
      pfSlots = {
        prev: App.els.pageTrack.querySelector('[data-slot="prev"] canvas'),
        current: App.els.pageTrack.querySelector('[data-slot="current"] canvas'),
        next: App.els.pageTrack.querySelector('[data-slot="next"] canvas')
      };
    }
    return pfSlots;
  }
  App.getPfSlots = getPfSlots;

  function renderSlots(n){
    var s = getPfSlots();
    var targetW = Math.min((window.innerWidth || 400) * (window.devicePixelRatio || 1), 2000);
    // left slot (data-slot="prev") shows the FORWARD/next page
    if (n < App.TOTAL_PAGES){ App.renderPageToCanvas(n+1, s.prev, targetW).catch(function(){}); } else { App.clearCanvas(s.prev); }
    App.renderPageToCanvas(n, s.current, targetW).catch(function(){});
    // right slot (data-slot="next") shows the BACKWARD/previous page
    if (n > 1){ App.renderPageToCanvas(n-1, s.next, targetW).catch(function(){}); } else { App.clearCanvas(s.next); }
  }

  function updatePageInfo(n){
    var paraIdx = App.paraForPage(n);
    var pageInPara = n - App.PARA_PAGE_RANGE[paraIdx-1][0] + 1;
    App.els.pfPageInfo.textContent = 'পারা-' + App.bn(paraIdx) + ' . পৃষ্ঠা-' + App.bn(pageInPara);
    App.updateLastReadMushaf(n);
  }

  function showParaToast(paraIdx){
    App.els.ptNum.textContent = App.bn(paraIdx);
    App.els.paraToast.classList.add('show');
    clearTimeout(App.els.paraToast.__t);
    App.els.paraToast.__t = setTimeout(function(){ App.els.paraToast.classList.remove('show'); }, 1600);
  }

  function openFullscreenPage(n){
    pf.current = n;
    App.updateBmFabIcon();
    pf.dragging = false;
    pf.animating = false;
    pf.turning = false;
    App.pzReset();
    App.els.pageTrack.classList.remove('dragging');
    App.els.pageTrack.style.transform = 'translateX(0)';
    renderSlots(n);
    updatePageInfo(n);
    App.els.pageFullscreen.classList.remove('hidden');
    App.pushHistory('para-fullscreen');
  }
  App.openFullscreenPage = openFullscreenPage;

  function closeFullscreenPage(){
    App.els.pageFullscreen.classList.add('hidden');
    App.pzReset(true);
    App.showPreviewPage(pf.current);
  }
  App.closeFullscreenPage = closeFullscreenPage;

  function settlePage(delta){
    var prevPara = App.paraForPage(pf.current);
    var stageW = App.els.pageStage.clientWidth;
    App.els.pageTrack.classList.remove('dragging');
    pf.animating = true;
    if (delta === 0){
      App.els.pageTrack.style.transform = 'translateX(0)';
      setTimeout(function(){ pf.animating = false; }, 300);
      return;
    }
    // delta>0 (forward) reveals the LEFT slot -> track moves right (+stageW).
    // delta<0 (backward) reveals the RIGHT slot -> track moves left (-stageW).
    App.els.pageTrack.style.transform = 'translateX(' + (delta > 0 ? stageW : -stageW) + 'px)';
    pf.turning = true;
    setTimeout(function(){
      pf.current = pf.current + delta;
      App.updateBmFabIcon();
      App.els.pageTrack.classList.add('dragging');
      void App.els.pageTrack.offsetWidth;
      App.els.pageTrack.style.transform = 'translateX(0)';
      renderSlots(pf.current);
      updatePageInfo(pf.current);
      var newPara = App.paraForPage(pf.current);
      if (newPara !== prevPara){ showParaToast(newPara); }
      requestAnimationFrame(function(){
        App.els.pageTrack.classList.remove('dragging');
        pf.animating = false;
        pf.turning = false;
      });
    }, 300);
  }

  function bindDragNav(){
    var activePointer = null;

    App.els.pageStage.addEventListener('pointerdown', function(e){
      if (activePointer !== null) return;
      if (pf.animating) return;
      if (App.pzBlocksSwipe()) return; // zoomed in (finger pans) or pinching -> no page swipe
      if (e.button !== undefined && e.button !== 0) return; // left mouse button / touch / pen only
      activePointer = e.pointerId;
      pf.startX = e.clientX;
      pf.startY = e.clientY;
      pf.dragX = 0;
      pf.dragging = true;
      pf.locked = null;
      App.els.pageTrack.classList.add('dragging');
      try{ App.els.pageStage.setPointerCapture(e.pointerId); }catch(err){}
    });

    App.els.pageStage.addEventListener('pointermove', function(e){
      if (!pf.dragging || e.pointerId !== activePointer) return;
      var dx = e.clientX - pf.startX;
      var dy = e.clientY - pf.startY;
      if (pf.locked === null){
        if (Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
        pf.locked = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
      }
      if (pf.locked !== 'x') return;
      e.preventDefault();
      // dx>0 (left-to-right, forward) resists at the last page; dx<0 (right-to-left, backward) resists at page 1.
      if ((dx > 0 && pf.current >= App.TOTAL_PAGES) || (dx < 0 && pf.current <= 1)){
        dx = dx * 0.35; // resistance at the very start/end of the Quran
      }
      pf.dragX = dx;
      App.els.pageTrack.style.transform = 'translateX(' + dx + 'px)';
    });

    function endDrag(e){
      if (!pf.dragging || e.pointerId !== activePointer) return;
      pf.dragging = false;
      activePointer = null;
      if (pf.locked !== 'x'){ App.els.pageTrack.classList.remove('dragging'); return; }
      var stageW = App.els.pageStage.clientWidth || 1;
      var ratio = pf.dragX / stageW;
      var THRESH = 0.18;
      if (ratio <= -THRESH && pf.current > 1){ settlePage(-1); }
      else if (ratio >= THRESH && pf.current < App.TOTAL_PAGES){ settlePage(1); }
      else { settlePage(0); }
    }
    App.els.pageStage.addEventListener('pointerup', endDrag);
    App.els.pageStage.addEventListener('pointercancel', endDrag);

    // Used by the zoom module when a second finger lands mid-swipe: snap the page back.
    pf.abortSwipe = function(){
      if (!pf.dragging && activePointer === null) return;
      var wasX = (pf.locked === 'x');
      pf.dragging = false;
      activePointer = null;
      pf.locked = null;
      if (wasX){ settlePage(0); } else { App.els.pageTrack.classList.remove('dragging'); }
    };
  }
  App.bindDragNav = bindDragNav;

})(window.QuranApp = window.QuranApp || {});

