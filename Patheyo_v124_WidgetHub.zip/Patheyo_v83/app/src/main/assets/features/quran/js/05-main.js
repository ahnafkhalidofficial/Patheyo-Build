
(function(){
  var done = false, files = ['pdfjs.js', 'pdfjs-worker-source.js', 'pdfjs-boot.js'];
  window.__loadPdfjs = function(){
    if (done) return; done = true;
    files.forEach(function(f){ var s = document.createElement('script'); s.async = false; s.src = 'https://appassets.patheyo.invalid/features/quran/vendor/' + f; document.head.appendChild(s); });   /* async=false: তিনটা ফাইল ঠিক এই ক্রমেই চলে */
  };
  window.addEventListener('load', function(){ setTimeout(window.__loadPdfjs, 1500); });
})();
