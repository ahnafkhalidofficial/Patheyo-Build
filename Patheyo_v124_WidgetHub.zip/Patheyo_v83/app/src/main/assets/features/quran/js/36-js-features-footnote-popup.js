
/*!
 * js/features/footnote-popup.js -- ব্যাখ্যার গ্লাস-ইফেক্ট পপআপ (একই পেজের ওপর ভেসে ওঠে, নতুন পেজে যায় না)
 *
 * Provides : App.openFootnote, App.closeFootnote, App.isFootnoteOpen, App.bindFootnotePopup
 * Needs    : core/dom, core/state, core/utils, data/surah-meta, services/tarjama-data, features/navigation, features/feedback
 *
 * ব্যাক বাটন / বাইরে ট্যাপ / ✕ / Esc -- সবই এক পথে (history.back) পপআপ বন্ধ করে, তাই সূরা-রিডার খোলাই থাকে।
 */
(function (App) {
  "use strict";

  var isOpen = false;
  var lastFocus = null;
  var hideTimer = null;

  var AR = '\\u0600-\\u06FF\\u0750-\\u077F\\u08A0-\\u08FF\\uFB50-\\uFDFF\\uFE70-\\uFEFF';
  var AR_RUN = new RegExp('[' + AR + ']+(?:[\\s\\u200c\\u200d]+[' + AR + ']+)*', 'g');

  // ব্যাখ্যার লেখার ভেতরের আরবি অংশ আলাদা ফন্টে (ডানদিক থেকে বামে) সাজানো
  function formatNote(text){
    return App.escapeHtml(text)
      .split(/\n+/)
      .filter(function(p){ return p.trim(); })
      .map(function(p){
        return '<p>' + p.replace(AR_RUN, function(m){ return '<span class="fn-ar" dir="rtl" lang="ar">' + m + '</span>'; }) + '</p>';
      }).join('');
  }

  function openFootnote(suraIdx, n, ayahIdx){
    var text = App.tarjamaData.getNote(suraIdx, n);
    if (!text){ if (App.showSnackbar) App.showSnackbar('এই ব্যাখ্যাটি পাওয়া যায়নি'); return; }
    if (isOpen) return;
    var el = App.els;
    el.fnBadge.textContent = App.bn(n);
    el.fnTitle.textContent = 'ব্যাখ্যা';
    el.fnSub.textContent = 'সূরা ' + (App.SURAH_BN[suraIdx - 1] || App.bn(suraIdx)) + (ayahIdx ? ' · আয়াত ' + App.bn(ayahIdx) : '');
    el.fnBody.innerHTML = formatNote(text);
    el.fnFoot.textContent = 'ব্যাখ্যা: ' + App.tarjamaData.getAuthor();
    el.fnBody.scrollTop = 0;

    clearTimeout(hideTimer);
    lastFocus = document.activeElement;
    isOpen = true;
    if (App.markFootnoteHintSeen) App.markFootnoteHintSeen();
    el.fnOverlay.classList.remove('hidden');
    el.fnOverlay.setAttribute('aria-hidden', 'false');
    void el.fnOverlay.offsetWidth;                         // reflow: যাতে ট্রানজিশন চলে
    el.fnOverlay.classList.add('open');
    document.documentElement.classList.add('fn-lock');
    App.pushHistory('tr-fn');
    try { el.fnCloseBtn.focus({ preventScroll: true }); } catch(e){}
  }
  App.openFootnote = openFootnote;

  // fromPop = true হলে history আগেই সরানো হয়ে গেছে
  function closeFootnote(fromPop){
    if (!isOpen) return;
    isOpen = false;
    var el = App.els;
    el.fnOverlay.classList.remove('open');
    document.documentElement.classList.remove('fn-lock');
    hideTimer = setTimeout(function(){
      if (isOpen) return;
      el.fnOverlay.classList.add('hidden');
      el.fnOverlay.setAttribute('aria-hidden', 'true');
    }, 300);
    try { if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true }); } catch(e){}
    lastFocus = null;
    if (!fromPop && history.state && history.state.qview === 'tr-fn'){ try { history.back(); } catch(e){} }
  }
  App.closeFootnote = closeFootnote;
  App.isFootnoteOpen = function(){ return isOpen; };

  function bindFootnotePopup(){
    App.els.fnCloseBtn.addEventListener('click', App.goBackOneLevel);
    App.els.fnBackdrop.addEventListener('click', App.goBackOneLevel);
    document.addEventListener('keydown', function(e){
      if (e.key === 'Escape' && isOpen) App.goBackOneLevel();
    });
  }
  App.bindFootnotePopup = bindFootnotePopup;

})(window.QuranApp = window.QuranApp || {});

