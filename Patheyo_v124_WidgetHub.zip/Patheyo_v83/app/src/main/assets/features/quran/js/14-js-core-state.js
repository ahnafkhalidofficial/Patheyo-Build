
/*!
 * js/core/state.js -- Shared runtime state: loaded Quran model, current tab / view, tab to return to
 *
 * Provides : App.quranModel, App.returnTab, App.state  (mode = 'tilawat' | 'tarjama', trMode = 'ar-bn' | 'bn' | 'ar-bn-tr')
 * Needs    : (nothing)
 */
(function (App) {
  "use strict";

  App.quranModel = [];

  // mode    : top-level section -- 'tilawat' (তিলাওয়াত করুন: সূরা / পারা / বুকমার্ক) or 'tarjama' (তরজমা পড়ুন)
  // trMode  : how the translation is read -- 'ar-bn' (আরবি ও বাংলা), 'bn' (বাংলা), 'ar-bn-tr' (আরবি, বাংলা ও উচ্চারণ)
  // view    : 'list' | 'sura-reader' | 'para-pages' | 'para-fullscreen' | 'para-web' | 'tr-reader' | 'tr-fn' (ব্যাখ্যা পপআপ)
  App.state = { tab:'sura', view:'list', mode:'tilawat', trMode:'ar-bn', trShowArabic:true };

  // Remembers which top-level tab (sura/para/bookmarks) was active right before a reader was
  // opened, so the browser/hardware back button returns to that SAME tab -- e.g. opening a
  // sura from the bookmarks list and going back must land back on the bookmarks list, not the
  // sura list, even though the reader itself is shared code.
  App.returnTab = 'sura';

})(window.QuranApp = window.QuranApp || {});

