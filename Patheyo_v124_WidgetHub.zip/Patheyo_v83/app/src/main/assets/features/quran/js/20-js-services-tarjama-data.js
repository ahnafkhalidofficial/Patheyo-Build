
/*!
 * js/services/tarjama-data.js -- ডাউনলোড করা তরজমা ফাইল (তরজমা + উচ্চারণ + ব্যাখ্যা) মেমরিতে লোড ও যাচাই
 *
 * Provides : App.tarjamaData { isLoaded, load, unload, getSura, getAyah, getNote, getAuthor }
 * Needs    : data/tarjama-config, services/tarjama-download
 *
 * ফাইলের গঠন (tools/build_data.py যা বানায়):
 *   format 2 (বর্তমান): বৈধ JSON, কিন্তু প্রতিটি সূরা আলাদা লাইনে। অ্যাপ ফাইল একবার পড়ে শুধু যে সূরা খোলা হয় সেটিই JSON-পার্স করে
 *                      (কয়েক মিলিসেকেন্ড) -- পুরো ~৭ MB স্টার্টআপে পার্স করতে হয় না।
 *   format 1 (পুরনো): পুরো ফাইল একটাই JSON অবজেক্ট -- এখনও পড়া যায়।
 *   সূরা = { n:সূরা-নম্বর, a:[ { u:উচ্চারণ, t:তরজমা (ব্যাখ্যার জায়গায় [[N]]) } ... ], f:{ "N":"ব্যাখ্যার লেখা" } }
 */
(function (App) {
  "use strict";

  var cfg = window.__QURAN_TARJAMA_CONFIG__ || {};
  var doc = null;          // { format, author, lines | suras, cache }
  var loading = null;

  function fail(code, msg){ var e = new Error(msg || code); e.code = code; return e; }

  function validSura(s, n){ return s && s.n === n && Array.isArray(s.a) && s.a.length > 0; }

  function parseText(text){
    var nl = text.indexOf('\n');
    var first = nl > 0 ? text.slice(0, nl) : '';
    if (first.indexOf('{"format":2,') === 0 && first.slice(-6) === ',"s":['){
      var head;
      try { head = JSON.parse(first.slice(0, first.length - 6) + '}'); } catch(e){ throw fail('corrupt', 'head'); }
      var lines = text.split('\n');
      if (lines.length < 116 || lines[115] !== ']}') throw fail('corrupt', 'truncated');
      return { format: 2, author: head.author, lines: lines, cache: {} };
    }
    var parsed;                                              // format 1
    try { parsed = JSON.parse(text); } catch(e){ throw fail('corrupt', 'json-parse'); }
    if (!parsed || parsed.format !== 1 || !Array.isArray(parsed.s) || parsed.s.length !== 114) throw fail('corrupt', 'bad-structure');
    for (var i = 0; i < 114; i++){ if (!validSura(parsed.s[i], i + 1)) throw fail('corrupt', 'bad-sura'); }
    return { format: 1, author: parsed.author, suras: parsed.s };
  }

  function load(){
    if (doc) return Promise.resolve(doc);
    if (loading) return loading;
    loading = App.tarjamaDownload.readText().then(function(text){
      doc = parseText(text); loading = null;
      return doc;
    }).catch(function(e){
      loading = null;
      if (!e || !e.code) e = fail('corrupt', e && e.message);
      throw e;
    });
    return loading;
  }

  function unload(){ doc = null; loading = null; }

  // সূরা n (১-১১৪) -- format 2-এ প্রথমবার চাইলে তবেই পার্স হয়, তারপর মনে রাখা হয়
  function getSura(n){
    if (!doc) return null;
    if (doc.format === 1) return doc.suras[n - 1];
    var s = doc.cache[n];
    if (!s){
      var l = doc.lines[n];
      if (!l) throw fail('corrupt', 'missing-line');
      try { s = JSON.parse(l.charCodeAt(l.length - 1) === 44 ? l.slice(0, -1) : l); } catch(e){ throw fail('corrupt', 'sura-parse'); }
      if (!validSura(s, n)) throw fail('corrupt', 'bad-sura');
      doc.cache[n] = s;
    }
    return s;
  }
  function getAyah(n, i){ var s = getSura(n); return s ? s.a[i - 1] : null; }
  function getNote(n, k){ var s = getSura(n); return (s && s.f && s.f[String(k)]) || null; }
  function getAuthor(){ return cfg.authorName || (doc && doc.author) || ''; }

  App.tarjamaData = {
    isLoaded: function(){ return !!doc; },
    load: load, unload: unload,
    getSura: getSura, getAyah: getAyah, getNote: getNote, getAuthor: getAuthor
  };

})(window.QuranApp = window.QuranApp || {});

