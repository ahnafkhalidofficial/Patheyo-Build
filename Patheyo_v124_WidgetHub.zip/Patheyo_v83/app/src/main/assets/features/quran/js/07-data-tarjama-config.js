
/*!
 * data/tarjama-config.js -- তরজমা ফাইলের অনলাইন ঠিকানা (এখানেই শুধু লিংক বসাতে হবে)
 *
 * Provides : window.__QURAN_TARJAMA_CONFIG__
 * Needs    : (nothing)
 *
 * ফাইলটি হলো release-files/Quran-Tarjama.json.gz -- এতে বাংলা তরজমা, বাংলা উচ্চারণ ও ব্যাখ্যা একসাথে আছে।
 * এটি GitHub Release-এ আপলোড করে, নিচের url-এ তার ডাউনলোড লিংক বসান।
 */
window.__QURAN_TARJAMA_CONFIG__ = {

  // >>>>>>  নিচের লাইনে ডাবল-কোটের ভেতরে আপনার GitHub Release-এর ফাইল-লিংকটি বসান  <<<<<<
  // উদাহরণ: "https://github.com/আপনার-ইউজারনেম/রেপোর-নাম/releases/download/v1/Quran-Tarjama.json.gz"
  url: "https://github.com/PatheyobyGunjoron/quran-assets-by-patheyo/releases/download/v3/Quran-Tarjama.json.gz",

  // ফাইলের সাইজ (bytes) -- ডাউনলোডের আগে "১.৩ MB" দেখাতে এবং % হিসাবে কাজে লাগে।
  // ফাইল নতুন করে বানালে (python3 tools/build_data.py) এই সংখ্যাটিও বদলে দিন (না দিলেও অ্যাপ চলবে)।
  sizeBytes: 1390618,

  // তরজমা ও ব্যাখ্যায় যে নাম দেখানো হবে
  authorName: "মুফতী তাকী উসমানী"
};

