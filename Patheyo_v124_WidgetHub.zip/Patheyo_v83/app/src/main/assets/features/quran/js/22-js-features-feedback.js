
/*!
 * js/features/feedback.js -- Snackbar and centre-toast messages
 *
 * Provides : App.showCenterToast, App.showSnackbar, App.showSnackbarUndo
 * Needs    : core/dom
 */
(function (App) {
  "use strict";

  function showSnackbar(text){
    App.els.snackbarText.textContent = text;
    App.els.snackbarUndo.classList.add('hidden');
    App.els.snackbar.classList.add('show');
    clearTimeout(App.els.snackbar.__t);
    App.els.snackbar.__t = setTimeout(function(){ App.els.snackbar.classList.remove('show'); }, 2200);
  }
  App.showSnackbar = showSnackbar;

  function showCenterToast(text){
    App.els.centerToastText.textContent = text;
    App.els.centerToast.classList.add('show');
    clearTimeout(App.els.centerToast.__t);
    App.els.centerToast.__t = setTimeout(function(){ App.els.centerToast.classList.remove('show'); }, 1500);
  }
  App.showCenterToast = showCenterToast;

  function showSnackbarUndo(text, onUndo){
    App.els.snackbarText.textContent = text;
    App.els.snackbarUndo.classList.remove('hidden');
    App.els.snackbar.classList.add('show');
    var handler = function(){
      onUndo();
      App.els.snackbar.classList.remove('show');
      App.els.snackbarUndo.removeEventListener('click', handler);
    };
    App.els.snackbarUndo.addEventListener('click', handler);
    clearTimeout(App.els.snackbar.__t);
    App.els.snackbar.__t = setTimeout(function(){
      App.els.snackbar.classList.remove('show');
      App.els.snackbarUndo.removeEventListener('click', handler);
    }, 4200);
  }
  App.showSnackbarUndo = showSnackbarUndo;

})(window.QuranApp = window.QuranApp || {});

