
/*!
 * js/features/theme.js -- Light / sepia / dark theme switching
 *
 * Provides : App.setTheme
 * Needs    : core/dom
 */
(function (App) {
  "use strict";

  function setTheme(name){
    document.documentElement.setAttribute('data-theme', name);
    App.els.themeBtns.forEach(function(btn){
      var b = btn.getAttribute('data-theme-btn');
      btn.classList.toggle('active', b === 'toggle' ? name !== 'sepia' : b === name);   /* one Light/Dark button + Eye-care button */
    });
    try{ localStorage.setItem('quran-theme', name); } catch(e){}
  }
  App.setTheme = setTheme;

})(window.QuranApp = window.QuranApp || {});

