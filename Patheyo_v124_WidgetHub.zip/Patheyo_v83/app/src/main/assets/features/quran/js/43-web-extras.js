
/*! web-extras.js -- সরাসরি ডাউনলোড লিংক + তরজমা ফাইল নিজে বেছে নেওয়ার বাটন */
(function (App) {
  "use strict";
  function $(id){ return document.getElementById(id); }
  var pdfUrl = App.pdfDownload && App.pdfDownload.getUrl();
  var trUrl = App.tarjamaDownload && App.tarjamaDownload.getUrl();
  var a1 = $('pdf-direct-link'), a2 = $('trdl-direct-link');
  if (a1 && pdfUrl) a1.href = pdfUrl; else if (a1) a1.style.display = 'none';
  if (a2 && trUrl) a2.href = trUrl; else if (a2) a2.style.display = 'none';
  var pick = $('trdl-pick-btn'), input = $('trdl-file-input');
  if (pick && input){
    pick.addEventListener('click', function(){ input.click(); });
    input.addEventListener('change', function(){
      var f = input.files && input.files[0]; if (!f) return;
      f.arrayBuffer().then(function(buf){ return App.tarjamaDownload.loadBuffer(buf); }).then(function(){ input.value = ''; });
    });
  }
})(window.QuranApp = window.QuranApp || {});
