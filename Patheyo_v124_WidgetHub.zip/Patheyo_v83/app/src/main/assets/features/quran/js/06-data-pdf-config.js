
/*!
 * data/pdf-config.js -- হাফেজি মুসহাফ PDF-এর অনলাইন ঠিকানা (এখানেই শুধু লিংক বসাতে হবে)
 *
 * Provides : window.__QURAN_PDF_CONFIG__
 * Needs    : (nothing)
 */
window.__QURAN_PDF_CONFIG__ = {

  // >>>>>>  নিচের লাইনে ডাবল-কোটের ভেতরে আপনার GitHub-এর PDF লিংকটি বসান  <<<<<<
  // উদাহরণ: "https://raw.githubusercontent.com/আপনার-ইউজারনেম/রেপোর-নাম/main/Hafezi-Quran.pdf"
  url: "https://github.com/PatheyobyGunjoron/quran-assets-by-patheyo/releases/download/v1/Hafezi-Quran.pdf",

  // PDF-এর আনুমানিক সাইজ (bytes)। ডাউনলোডের আগে "২২.৯ MB" দেখাতে এবং সার্ভার সাইজ না জানালে % হিসাব করতে কাজে লাগে।
  // ফাইল বদলালে সঠিক সাইজ বসিয়ে দিন (না দিলেও অ্যাপ চলবে)।
  sizeBytes: 24070037
};

