
/*!
 * js/features/last-read.js -- "Continue reading" card and last-read position tracking
 *
 * Provides : App.saveLastRead, App.showContinueCard, App.updateLastReadMushaf, App.updateLastReadSura,
               App.updateLastReadWeb
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/surah-meta, features/bookmark-fab,
               features/bookmark-list, features/mushaf-fullscreen, features/mushaf-viewer,
               features/sura-reader, features/web-reader
 */
(function (App) {
  "use strict";

  function saveLastRead(type, idx, label, pos){
    try{
      var data = { type:type, idx:idx, label:label };
      if (pos){ for (var k in pos){ data[k] = pos[k]; } }
      localStorage.setItem('quran-last-read', JSON.stringify(data));
    } catch(e){}
  }
  App.saveLastRead = saveLastRead;

  // Called continuously (on scroll / on page turn) so "পড়া চালিয়ে যান" always resumes at the
  // exact ayah/page the user last reached -- not just the start of the sura/para that was opened.
  function updateLastReadSura(){
    var pos = App.getCurrentVisibleAyah();
    if (!pos) return;
    var sura = App.quranModel[pos.sura-1];
    saveLastRead('sura', pos.sura,
      'সূরা ' + App.bn(pos.sura) + ' — ' + (App.SURAH_EN[sura.index-1]||'') + ' · আয়াত ' + App.bn(pos.ayah),
      { ayahIndex: pos.ayah });
  }
  App.updateLastReadSura = updateLastReadSura;

  function updateLastReadWeb(){
    var p = App.getCurrentVisibleWebPage();
    if (!p) return;
    var paraIdx = App.paraForPage(p);
    saveLastRead('para-web', paraIdx,
      'পারা ' + App.bn(paraIdx) + ' — ওয়েব পেজ · পৃষ্ঠা ' + App.bn(p),
      { pageNum: p });
  }
  App.updateLastReadWeb = updateLastReadWeb;

  function updateLastReadMushaf(n){
    var paraIdx = App.paraForPage(n);
    saveLastRead('para-page', paraIdx,
      'পারা ' + App.bn(paraIdx) + ' — মুসহাফ · পৃষ্ঠা ' + App.bn(n),
      { pageNum: n, mode:'mushaf' });
  }
  App.updateLastReadMushaf = updateLastReadMushaf;

  function showContinueCard(){
    if (App.state.view !== 'list' || App.state.mode === 'tarjama'){ App.els.continueCard.classList.add('hidden'); return; }
    try{
      var raw = localStorage.getItem('quran-last-read');
      if (!raw){ App.els.continueCard.classList.add('hidden'); return; }
      var data = JSON.parse(raw);
      App.els.continueTitle.textContent = data.label;
      App.els.continueCard.classList.remove('hidden');
      App.els.continueCard.onclick = function(){
        if (data.type === 'para-page'){
          App.openParaPages(data.idx);
          if (data.pageNum){ App.showPreviewPage(data.pageNum); App.openFullscreenPage(data.pageNum); }
        }
        else if (data.type === 'para-web'){
          App.openParaWebPage(data.idx);
          if (data.pageNum){ setTimeout(function(){ App.scrollToWebPage(data.pageNum); }, 80); }
        }
        else {
          App.openReader(data.idx);
          if (data.ayahIndex){ setTimeout(function(){ App.scrollToAyah(data.idx, data.ayahIndex); }, 80); }
        }
      };
    } catch(e){ App.els.continueCard.classList.add('hidden'); }
  }
  App.showContinueCard = showContinueCard;

})(window.QuranApp = window.QuranApp || {});

