
/*! js/services/net-fetch.js -- ব্রাউজারে ফাইল ডাউনলোড: আগে সরাসরি লিংক, না হলে CORS-প্রক্সি দিয়ে (GitHub Release সরাসরি ব্রাউজারে CORS দেয় না) */
(function (App) {
  "use strict";
  var ROUTES = [
    function (u) { return u; },
    function (u) { return 'https://corsproxy.io/?url=' + encodeURIComponent(u); },
    function (u) { return 'https://api.allorigins.win/raw?url=' + encodeURIComponent(u); },
    function (u) { return 'https://api.codetabs.com/v1/proxy/?quest=' + encodeURIComponent(u); }
  ];
  var STALL_MS = 60000;
  App.netFetch = function (url, opt) {
    opt = opt || {};
    var aborted = false, cur = null, httpErr = null, timer = null;
    var promise = new Promise(function (resolve, reject) {
      var i = 0;
      function finish(fn, v) { clearInterval(timer); fn(v); }
      function giveUp() {
        if (aborted) return finish(reject, { code: 'abort' });
        if (httpErr) return finish(reject, { code: 'http-' + httpErr });
        finish(reject, { code: (navigator.onLine === false) ? 'offline' : 'blocked' });
      }
      function next() {
        if (aborted) return finish(reject, { code: 'abort' });
        if (i >= ROUTES.length) return giveUp();
        var direct = (i === 0), target = ROUTES[i++](url), x = new XMLHttpRequest(), last = Date.now(), moved = false;
        cur = x;
        x.open('GET', target, true);
        x.responseType = 'arraybuffer';
        x.onprogress = function (e) {
          last = Date.now(); moved = true;
          if (opt.onProgress) opt.onProgress(e.loaded, e.lengthComputable ? e.total : 0);
        };
        x.onload = function () {
          var ok = x.status >= 200 && x.status < 300, buf = x.response;
          if (ok && buf && buf.byteLength > 0 && (!opt.validate || opt.validate(buf))) return finish(resolve, buf);
          if (direct && x.status >= 400) httpErr = x.status;
          next();
        };
        x.onerror = function () { next(); };
        x.ontimeout = function () { next(); };
        x.onabort = function () { if (aborted) return giveUp(); next(); };
        clearInterval(timer);
        timer = setInterval(function () { if (Date.now() - last > STALL_MS) { try { x.abort(); } catch (e) {} } }, 5000);
        x.send();
      }
      next();
    });
    return { promise: promise, abort: function () { aborted = true; try { if (cur) cur.abort(); } catch (e) {} } };
  };
})(window.QuranApp = window.QuranApp || {});
