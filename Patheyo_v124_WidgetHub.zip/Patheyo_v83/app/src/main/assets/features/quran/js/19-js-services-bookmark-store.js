
/*!
 * js/services/bookmark-store.js -- Bookmark persistence (localStorage)
 *
 * Provides : App.addOrUpdateBookmark, App.deleteBookmark, App.loadBookmarks, App.saveBookmarksArr
 * Needs    : features/bookmark-list
 */
(function (App) {
  "use strict";

  // ---- Bookmarks (localStorage) ----
  var BOOKMARKS_KEY = 'quran-bookmarks';

  function loadBookmarks(){
    try{ return JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]'); } catch(e){ return []; }
  }
  App.loadBookmarks = loadBookmarks;

  function saveBookmarksArr(arr){
    try{ localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr)); } catch(e){}
  }
  App.saveBookmarksArr = saveBookmarksArr;

  function addOrUpdateBookmark(bm){
    var arr = loadBookmarks();
    var i = -1;
    for (var k=0;k<arr.length;k++){ if (arr[k].id === bm.id){ i = k; break; } }
    if (i >= 0){ arr[i] = bm; } else { arr.unshift(bm); }
    saveBookmarksArr(arr);
    App.renderBookmarksList();
  }
  App.addOrUpdateBookmark = addOrUpdateBookmark;

  function deleteBookmark(id){
    var arr = loadBookmarks();
    var removed = null;
    var out = [];
    for (var k=0;k<arr.length;k++){
      if (arr[k].id === id){ removed = arr[k]; } else { out.push(arr[k]); }
    }
    saveBookmarksArr(out);
    App.renderBookmarksList();
    return removed;
  }
  App.deleteBookmark = deleteBookmark;

})(window.QuranApp = window.QuranApp || {});

