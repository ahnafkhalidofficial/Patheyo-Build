
/*!
 * js/features/pdf-download-ui.js -- মুসহাফ PDF ডাউনলোড কার্ড: আইকন, লাইভ % রিং, MB, গতি, বাকি সময়, ত্রুটির বার্তা
 *
 * Provides : App.bindPdfDownloadUi, App.syncPdfPanel
 * Needs    : core/dom, core/utils, features/feedback, features/mushaf-viewer, services/pdf-download, services/pdf-service
 */
(function (App) {
  "use strict";

  var RING_C = 2 * Math.PI * 52;   // ring circumference (r = 52 in index.html)
  var showDone = false;            // "সম্পন্ন" অবস্থাটি শুধু ডাউনলোড শেষ হওয়ার ঠিক পরের কয়েক মুহূর্ত দেখানো হয়
  var prevPhase = 'idle';

  // ---------------------------------------------------------------- formatting (সংখ্যা সবসময় ইংরেজি digit-এ: 0-9)
  function num(v){ return String(v); }

  function mb(bytes, digits){ return num((bytes / 1048576).toFixed(digits === undefined ? 1 : digits)); }

  function fmtSize(bytes){
    if (bytes >= 1048576) return mb(bytes) + ' MB';
    return num(Math.round(bytes / 1024)) + ' KB';
  }

  function fmtSpeed(bps){
    if (!bps) return 'মাপা হচ্ছে…';
    if (bps >= 1048576) return mb(bps) + ' MB/s';
    return num(Math.max(1, Math.round(bps / 1024))) + ' KB/s';
  }

  function fmtEta(sec){
    if (sec === null || sec === undefined) return 'হিসাব হচ্ছে…';
    sec = Math.ceil(sec);
    if (sec <= 3) return 'কয়েক সেকেন্ড';
    if (sec < 60) return num(sec) + ' সেকেন্ড';
    var m = Math.floor(sec / 60), s = sec % 60;
    if (m >= 60) return num(Math.floor(m / 60)) + ' ঘণ্টা ' + num(m % 60) + ' মিনিট';
    return num(m) + ' মিনিট' + (s ? ' ' + num(s) + ' সেকেন্ড' : '');
  }

  var ERRORS = {
    'blocked':     ['ডাউনলোড করা যায়নি', 'ইন্টারনেট ঠিক থাকলে আবার চেষ্টা করুন। না হলে নিচের লিংক থেকে ফাইলটি ব্রাউজারে নামিয়ে "নিজে বেছে নিন" দিয়ে দিন।'],
    'no-gzip':     ['এই ব্রাউজারে ফাইল খোলা যায়নি', 'ব্রাউজার আপডেট করুন, অথবা Chrome / Edge / Safari-র নতুন ভার্সনে খুলুন।'],
    'offline':   ['ইন্টারনেট সংযোগ নেই', 'ওয়াই-ফাই বা মোবাইল ডেটা চালু করে আবার চেষ্টা করুন।'],
    'timeout':   ['সংযোগ ধীর হয়ে গেছে', 'ইন্টারনেট ঠিক হলে আবার চেষ্টা করুন, যেখানে থেমেছিল সেখান থেকেই চলবে।'],
    'network':   ['ডাউনলোড বাধাপ্রাপ্ত হয়েছে', 'ইন্টারনেট বিচ্ছিন্ন হয়েছে। আবার চেষ্টা করলে যেখানে থেমেছিল সেখান থেকেই চলবে।'],
    'ssl':       ['নিরাপদ সংযোগ হয়নি', 'ফোনের তারিখ ও সময় ঠিক আছে কিনা দেখে আবার চেষ্টা করুন।'],
    'no-space':  ['ফোনে জায়গা নেই', 'কিছু জায়গা খালি করে আবার চেষ্টা করুন।'],
    'not-pdf':   ['ফাইলটি সঠিক PDF নয়', 'ডাউনলোড লিংকটি সরাসরি PDF ফাইলের কিনা যাচাই করুন।'],
    'no-url':    ['ডাউনলোড লিংক সেট করা হয়নি', 'data/pdf-config.js ফাইলে PDF-এর লিংক বসান।'],
    'bad-url':   ['ডাউনলোড লিংক সঠিক নয়', 'লিংকটি https:// দিয়ে শুরু হতে হবে (data/pdf-config.js)।']
  };

  function errorText(code){
    if (ERRORS[code]) return ERRORS[code];
    var m = /^http-(\d+)$/.exec(code || '');
    if (m){
      if (m[1] === '404') return ['ফাইলটি পাওয়া যায়নি', 'ডাউনলোড লিংকটি ঠিক নেই বা ফাইলটি সরানো হয়েছে। (কোড ' + num(404) + ')'];
      return ['সার্ভারে সমস্যা হয়েছে', 'কিছুক্ষণ পরে আবার চেষ্টা করুন। (কোড ' + num(m[1]) + ')'];
    }
    return ['ডাউনলোড সম্পন্ন হয়নি', 'আবার চেষ্টা করুন।'];
  }

  // ---------------------------------------------------------------- rendering
  function render(s){
    var el = App.els;
    if (!el.dlCard) return;
    var dl = App.pdfDownload;
    var phase = s.phase;
    if (phase === 'done' && !showDone) phase = 'idle'; // আগে থেকেই ডাউনলোড করা আছে, অথচ এখানে এসেছি -> সাধারণ অবস্থা

    var total = dl.getKnownTotal();
    var pct = (phase === 'done') ? 100 : (total > 0 ? Math.min(100, Math.floor(s.downloaded / total * 100)) : 0);
    el.dlCard.setAttribute('data-state', phase);
    el.dlCard.classList.toggle('trdl-indet', phase === 'downloading' && !(total > 0));
    el.dlRing.setAttribute('aria-valuenow', String(pct));
    el.dlRingBar.style.strokeDashoffset = String(RING_C * (1 - pct / 100));
    el.dlPercent.textContent = num(pct) + '%';

    if (phase === 'idle'){
      el.dlTitle.textContent = 'হাফেজি মুসহাফ ডাউনলোড করুন';
      el.dlDesc.textContent = 'আসল মুসহাফের পাতা পড়তে ফাইলটি একবার ডাউনলোড করতে হবে' +
        (total > 0 ? ' (' + fmtSize(total) + ')' : '') + '। এরপর ইন্টারনেট ছাড়াই পড়তে পারবেন।';
      el.dlStartLabel.textContent = 'ডাউনলোড করুন';
    } else if (phase === 'downloading'){
      el.dlTitle.textContent = 'ডাউনলোড হচ্ছে…';
      el.dlDesc.textContent = 'অনুগ্রহ করে অপেক্ষা করুন। ডাউনলোড শেষ হলেই মুসহাফ নিজে থেকে খুলে যাবে।';
      el.dlStatSize.textContent = total > 0
        ? mb(s.downloaded) + ' / ' + mb(total) + ' MB'
        : fmtSize(s.downloaded);
      el.dlStatSpeed.textContent = fmtSpeed(s.speed);
      el.dlStatEta.textContent = (total > 0) ? fmtEta(s.eta) : '–';
    } else if (phase === 'done'){
      el.dlTitle.textContent = 'ডাউনলোড সম্পন্ন!';
      el.dlDesc.textContent = 'মুসহাফ খোলা হচ্ছে…';
    } else { // error
      var t = errorText(s.error);
      el.dlTitle.textContent = t[0];
      el.dlDesc.textContent = t[1];
      el.dlStartLabel.textContent = 'আবার চেষ্টা করুন';
    }
  }

  function syncPdfPanel(){ render(App.pdfDownload.getState()); }
  App.syncPdfPanel = syncPdfPanel;

  // ---------------------------------------------------------------- when a download finishes
  function onFinished(){
    showDone = true;
    syncPdfPanel();
    App.ensurePdfLoaded().then(function(){
      setTimeout(function(){
        showDone = false;
        var viewing = !App.els.paraPagesPanel.classList.contains('hidden') && !App.els.pagePreviewMissing.classList.contains('hidden');
        if (viewing){ App.showPreviewPage(App.pageState.current); }
        else if (App.showSnackbar){ App.showSnackbar('মুসহাফ ডাউনলোড সম্পন্ন হয়েছে'); }
      }, 900);
    }).catch(function(){
      showDone = false;
      syncPdfPanel();
      if (App.showSnackbar) App.showSnackbar('ফাইলটি খোলা যায়নি, আবার ডাউনলোড করুন');
    });
  }

  // ---------------------------------------------------------------- wiring
  function bindPdfDownloadUi(){
    var dl = App.pdfDownload;
    if (!dl || !App.els.dlCard) return;

    // Android অ্যাপে ম্যানুয়াল ফাইল-পিকার নেই (ডাউনলোডই একমাত্র পথ)
    if (dl.hasNative()) App.els.pdfPickBtn.classList.add('hidden');

    App.els.dlStartBtn.addEventListener('click', function(){ dl.start(); });
    App.els.dlCancelBtn.addEventListener('click', function(){ dl.cancel(); });

    dl.subscribe(function(s){
      if (prevPhase === 'downloading' && s.phase === 'done'){ prevPhase = s.phase; onFinished(); return; }
      prevPhase = s.phase;
      render(s);
    });
    prevPhase = dl.getState().phase;
    syncPdfPanel();
  }
  App.bindPdfDownloadUi = bindPdfDownloadUi;

})(window.QuranApp = window.QuranApp || {});

