
/*!
 * js/services/pdf-download.js -- মুসহাফ PDF অনলাইন থেকে ডাউনলোড (লাইভ প্রগ্রেস, গতি, বাকি সময়) ও লোকাল স্টোরেজ
 *
 * Provides : App.pdfDownload  { getUrl, hasNative, isReady, needsDownload, getState, subscribe, start, cancel,
 *                               readNativeBytes, discardNative, _onNative }
 * Needs    : data/pdf-config, services/pdf-service (App.loadPdfFromBuffer -- শুধু ব্রাউজার/টেস্ট মোডে)
 *
 * দুইটি ব্যাকএন্ড:
 *  1) Android অ্যাপ (window.QuranNative আছে): Kotlin ডাউনলোড করে অ্যাপের স্টোরেজে সেভ করে; এখানে শুধু প্রগ্রেস আসে।
 *  2) সাধারণ ব্রাউজার (টেস্টিং): XHR দিয়ে নামিয়ে IndexedDB-তে রাখে।
 */
(function (App) {
  "use strict";

  var cfg = window.__QURAN_PDF_CONFIG__ || {};
  var native = (window.QuranNative && typeof window.QuranNative.isPdfReady === 'function') ? window.QuranNative : null;
  var LOCAL_URL = 'https://quran-local.invalid/Hafezi-Quran.pdf';

  var state = { phase:'idle', downloaded:0, total:0, speed:0, eta:null, error:null };
  var listeners = [];
  var sample = null;          // { t, b } -- গতি মাপার শেষ নমুনা
  var xhr = null;             // ব্রাউজার ব্যাকএন্ডের চলমান XHR
  var webReady = false;       // ব্রাউজার ব্যাকএন্ডে ডাউনলোড শেষ হয়েছে কি

  function emit(){ listeners.slice().forEach(function(fn){ try{ fn(state); }catch(e){} }); }

  function subscribe(fn){
    listeners.push(fn);
    return function(){ listeners = listeners.filter(function(f){ return f !== fn; }); };
  }

  // ---- ঠিকানা: GitHub-এর "blob" পেজের লিংক দিলেও আসল ফাইলের (raw) লিংকে বদলে নেয় ----
  function getUrl(){
    var u = String(cfg.url || '').trim();
    if (!/^https:\/\//i.test(u) || /PASTE_YOUR/i.test(u)) return '';
    var m = u.match(/^https:\/\/github\.com\/([^\/]+)\/([^\/]+)\/blob\/(.+)$/i);
    if (m) u = 'https://raw.githubusercontent.com/' + m[1] + '/' + m[2] + '/' + m[3].split('?')[0];
    return u;
  }

  function knownTotal(){ return state.total > 0 ? state.total : (cfg.sizeBytes || 0); }

  // ---- গতি (EMA) ও বাকি সময় ----
  function track(bytes){
    var now = Date.now();
    if (!sample){ sample = { t:now, b:bytes }; return; }
    var dt = now - sample.t;
    if (dt < 500) return; // ছোট ছোট ওঠানামা এড়াতে ০.৫ সেকেন্ড পরপর মাপা
    var inst = Math.max(0, (bytes - sample.b) / dt * 1000);
    state.speed = state.speed ? state.speed * 0.6 + inst * 0.4 : inst;
    sample = { t:now, b:bytes };
    var t = knownTotal();
    state.eta = (t > 0 && state.speed > 1024) ? Math.max(0, (t - bytes) / state.speed) : null;
  }

  function reset(phase){
    state.phase = phase; state.speed = 0; state.eta = null; sample = null;
  }

  // ---------------------------------------------------------------- Android (native)
  function onNative(ev){
    if (!ev) return;
    var prev = state.phase;
    state.downloaded = ev.downloaded || 0;
    state.total = ev.total > 0 ? ev.total : 0;
    state.error = ev.error || null;
    if (ev.phase === 'downloading'){
      if (prev !== 'downloading'){ reset('downloading'); }
      track(state.downloaded);
    } else if (ev.phase === 'done'){
      reset('done'); state.downloaded = state.total = (ev.total > 0 ? ev.total : state.downloaded);
    } else if (ev.phase === 'error'){
      reset('error');
    } else {
      reset('idle'); state.downloaded = 0;
    }
    emit();
  }

  function syncFromNative(){
    if (!native) return;
    try { onNative(JSON.parse(native.getStatus())); } catch(e){}
  }

  // ---------------------------------------------------------------- ব্রাউজার (টেস্ট)
  function startWeb(url){
    reset('downloading'); state.downloaded = 0; state.error = null; emit();
    xhr = App.netFetch(url, {
      onProgress: function(loaded, total){ state.downloaded = loaded; if (total > 0) state.total = total; track(loaded); emit(); },
      validate: function(buf){ return String.fromCharCode.apply(null, new Uint8Array(buf, 0, Math.min(5, buf.byteLength))) === '%PDF-'; }
    });
    xhr.promise.then(function(buf){
      xhr = null;
      var n = buf.byteLength;
      return App.loadPdfFromBuffer(buf).then(function(){
        webReady = true; state.downloaded = state.total = n || state.total; reset('done'); emit();
      }, function(){ throw { code: 'not-pdf' }; });
    }).catch(function(e){
      xhr = null;
      if (e && e.code === 'abort'){ reset('idle'); state.downloaded = 0; emit(); return; }
      reset('error'); state.error = (e && e.code) || 'network'; emit();
    });
  }

  // ---------------------------------------------------------------- public API
  function start(){
    if (state.phase === 'downloading') return;
    var url = getUrl();
    if (!url){ reset('error'); state.error = 'no-url'; emit(); return; }
    state.error = null;
    if (native){
      reset('downloading'); state.downloaded = state.downloaded || 0; emit();
      try { native.startDownload(url); }
      catch(e){ reset('error'); state.error = 'network'; emit(); }
    } else {
      startWeb(url);
    }
  }

  function cancel(){
    if (state.phase !== 'downloading') return;
    if (native){ try{ native.cancelDownload(); }catch(e){} }
    else if (xhr){ xhr.abort(); }
  }

  function isReady(){
    if (native){ try{ return !!native.isPdfReady(); }catch(e){ return false; } }
    return webReady;
  }

  // Android-এ PDF না থাকলে আগেই ডাউনলোড-কার্ড দেখানো যায় (রেন্ডার চেষ্টা না করেই)
  function needsDownload(){ return !!native && !isReady(); }

  // ---- ডাউনলোড করা ফাইলের বাইট পড়া: আগে লোকাল URL (XHR), না হলে ব্রিজের টুকরো-পড়া ----
  function readViaUrl(){
    return new Promise(function(resolve, reject){
      var x = new XMLHttpRequest();
      x.open('GET', LOCAL_URL, true);
      x.responseType = 'arraybuffer';
      x.onload = function(){
        if (x.status === 200 && x.response && x.response.byteLength > 0) resolve(new Uint8Array(x.response));
        else reject(new Error('local-url-status-' + x.status));
      };
      x.onerror = function(){ reject(new Error('local-url-error')); };
      x.send();
    });
  }

  function readViaBridge(){
    var size = native.getPdfSize();
    if (!size) return Promise.reject(new Error('empty'));
    var out = new Uint8Array(size), CHUNK = 1024 * 1024, off = 0;
    return new Promise(function(resolve, reject){
      (function next(){
        if (off >= size){ resolve(out); return; }
        try {
          var b64 = native.readChunk(off, Math.min(CHUNK, size - off));
          var bin = atob(b64);
          for (var i = 0; i < bin.length; i++) out[off + i] = bin.charCodeAt(i);
          off += bin.length;
          if (!bin.length){ reject(new Error('short-read')); return; }
        } catch(e){ reject(e); return; }
        setTimeout(next, 0);
      })();
    });
  }

  function readNativeBytes(){
    return readViaUrl().catch(function(){ return readViaBridge(); });
  }

  // ফাইল নষ্ট (corrupt) হলে মুছে দেয়, যাতে ইউজার আবার ডাউনলোড করতে পারে
  function discardNative(){
    if (!native) return;
    try { native.deletePdf(); } catch(e){}
    reset('idle'); state.downloaded = 0; emit();
  }

  App.pdfDownload = {
    getUrl: getUrl,
    hasNative: function(){ return !!native; },
    isReady: isReady,
    needsDownload: needsDownload,
    getState: function(){ return state; },
    getKnownTotal: knownTotal,
    subscribe: subscribe,
    start: start,
    cancel: cancel,
    readNativeBytes: readNativeBytes,
    discardNative: discardNative,
    syncFromNative: syncFromNative,
    _onNative: onNative
  };

  syncFromNative();

})(window.QuranApp = window.QuranApp || {});

