/* js/prayer/hijri-calendar.js */
/* =============================================================================
   হিজরি ক্যালেন্ডার
   অফলাইন-সহনশীল হিজরি তারিখ গণনা (Tabular Islamic Calendar) ও প্রদর্শন।
   ============================================================================= */

// ============================================================================
// অফলাইন-সহনশীল হিজরি তারিখ ব্যবস্থা
// ইন্টারনেট থাকলে API থেকে আসা হিজরি তারিখটাই বিশ্বস্ত উৎস হিসেবে ব্যবহার হয়।
// ইন্টারনেট না থাকলে (বা পুরোনো একাধিক দিনের ক্যাশ হলে) নিচের ক্যালেন্ডার সূত্র (Tabular
// Islamic Calendar) দিয়ে সরাসরি ফোনের লোকাল তারিখ থেকেই হিজরি তারিখ বের করে ফেলা হয় —
// এর জন্য কোনো নেট লাগে না, তাই প্রতিদিন এমনিতেই ঠিকভাবে এগিয়ে যাবে।
// দুই ক্ষেত্রেই: রাত ১২টার বদলে মাগরিবের সাথে সাথে পরের দিনে চলে যায়।
// ============================================================================
function gregorianToJDN(y, m, d) {
    const a = Math.floor((14 - m) / 12);
    const y2 = y + 4800 - a;
    const m2 = m + 12 * a - 3;
    return d + Math.floor((153 * m2 + 2) / 5) + 365 * y2 + Math.floor(y2 / 4) - Math.floor(y2 / 100) + Math.floor(y2 / 400) - 32045;
}
function localGregorianToHijri(date, ignoreAdjustment = false) {
    const jdn = gregorianToJDN(date.getFullYear(), date.getMonth() + 1, date.getDate());
    const ISLAMIC_EPOCH = 1948440;
    let l = jdn - ISLAMIC_EPOCH + 10632;

    // ✅ Firebase থেকে আসা অ্যাডজাস্টমেন্ট এখানে যোগ করা হলো
    if (!ignoreAdjustment) {
        const adj = (window._nativeHijriAdjustment !== undefined) ? parseInt(window._nativeHijriAdjustment) : 0;
        l += adj;
    }

    let n = Math.floor((l - 1) / 10631);
    l = l - 10631 * n + 354;
    let j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
    l = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
    const month = Math.floor((24 * l) / 709);
    const day = l - Math.floor((709 * month) / 24);
    const year = 30 * n + j - 30;
    return { day, month: month - 1, year, monthLength: null };
}
function addHijriDays(anchor, n) {
    if (n === 0) return anchor;
    let { day, month, year } = anchor;
    const len = anchor.monthLength || 30;
    day += n;
    if (day > len) {
        day -= len; month += 1; if (month > 11) { month = 0; year += 1; }
    } else if (day < 1) {
        month -= 1; if (month < 0) { month = 11; year -= 1; }
        day += 30;
    }
    return { day, month, year, monthLength: anchor.monthLength };
}
function toDateOnlyStr(d) { return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`; }

// আজকে কী হিজরি তারিখ দেখানো হবে — মাগরিব পার হয়েছে কিনা সেটা বিবেচনা করে
function getDisplayHijriDate(now, ignoreAdjustment = false, ignoreMaghrib = false) {
    const todayStr = toDateOnlyStr(now);
    const maghribTodayStr = globalTimings && globalTimings.Maghrib ? globalTimings.Maghrib : null;
    const maghribPassed = !ignoreMaghrib && !!(maghribTodayStr && now >= parseWaqtStringToDate(maghribTodayStr));

    if (hijriApiAnchor && hijriApiAnchor.fetchedForDateStr === todayStr) {
        let h = Object.assign({}, hijriApiAnchor);
        if (maghribPassed) h = addHijriDays(h, 1);
        if (!ignoreAdjustment) {
            const adj = (window._nativeHijriAdjustment !== undefined) ? parseInt(window._nativeHijriAdjustment) : 0;
            if (adj !== 0) h = addHijriDays(h, adj);
        }
        return h;
    }
    const targetDate = maghribPassed ? new Date(now.getTime() + 24 * 60 * 60000) : now;
    return localGregorianToHijri(targetDate, ignoreAdjustment);
}
function formatHijriDate(h) { return `${h.day} ${hijriMonthsBN[h.month]} ${h.year}`; }

// হিজরি তারিখের চূড়ান্ত স্ট্রিং বের করা (Firebase ডিরেক্ট ডেট থাকলে সেটিই প্রাধান্য পাবে)
function getFinalHijriDisplayString(now, ignoreAdjustment = false, ignoreMaghrib = false) {
    if (!ignoreAdjustment && (window._nativeHijriOverride || window._nativeDirectHijriDate)) {
        const ov = resolveHijriOverride(now);
        if (ov) return ov.text;
    }
    return formatHijriDate(getDisplayHijriDate(now, ignoreAdjustment, ignoreMaghrib));
}

/* =============================================================================
   হিজরি ম্যানুয়াল ওভাররাইড — Firebase: prayer_config
     hijri_override : true / false          ← সুইচ (true হলে নিচের তারিখ দেখানো হয়, false হলে অটোমেটিক হিসাব)
     bn : { day: "৩০", month: "রবিউস সানি" }   ← প্রতিটা ভাষার জন্য আলাদা ঘর (day, month; year ঐচ্ছিক)
     en : { day: "30", month: "Rabi al-Thani" }
   - দিন ও মাস আলাদা ঘরে থাকে, তাই অনুমান/ভাগ করার দরকার নেই। অ্যাপ যে ভাষায় চলে সেই ভাষার ঘর দেখায়
     (window.__hijriLang, ডিফল্ট 'bn'); সেই ভাষা না থাকলে bn → en → অন্য ভাষা।
   - বছর না দিলে অ্যাপ নিজে বসিয়ে নেয়। আগের একক hijri_date ("৩০ রবিউস সানি") এখনও চলে (hijri_override না থাকলে)।
   - ফলাফল সবসময় "দিন মাস বছর" ফরম্যাটে — হোমের তারিখ-কার্ড, উইজেট ও বাকি সব জায়গা আগের মতোই কাজ করে।
   ============================================================================= */
const hijriMonthsEN = ["Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani", "Jumada al-Ula", "Jumada al-Thani", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"];

// মাসের নাম (বাংলা/ইংরেজি, বানান-ভিন্নতাসহ) থেকে ০–১১ ইনডেক্স; চিনতে না পারলে -১
function hijriMonthIndexFromName(name) {
    const c = String(name || '').toLowerCase().replace(/[’'‘`ʼʿʾ\-_.,]/g, '').replace(/\s+/g, '');
    if (!c) return -1;
    if (/q[ai]d|kad|কদ|ক্বদ/.test(c)) return 10;
    if (/hij|haj|হজ/.test(c)) return 11;
    if (/muharr?am|moharr?am|মুহা?র+ম|মহর+ম/.test(c)) return 0;
    if (/safar|sofar|সফর|ছফর/.test(c)) return 1;
    if (/rabi|rabb?i|রবি/.test(c)) return /thani|thaani|sani|akhir|akher|আখ[িে]র|আখেরা|সানি|সানী|দ্বিতীয়|ii$|2$|২$/.test(c) ? 3 : 2;
    if (/jum?ad|jamad|জুমা|জামাদ|জমাদ/.test(c)) return /thani|thaani|sani|akhir|akher|আখ[িে]র|আখেরা|সানি|সানী|দ্বিতীয়|ii$|2$|২$/.test(c) ? 5 : 4;
    if (/rajab|রজব/.test(c)) return 6;
    if (/sha+ban|শা?বান/.test(c)) return 7;
    if (/ramad|ramz|ramaz|রমজান|রমযান|রামাদান/.test(c)) return 8;
    if (/shaw+al|শাওয়াল|শাউয়াল|শওয়াল/.test(c)) return 9;
    return -1;
}

function hijriToBnDigits(v) { return String(v).replace(/[0-9]/g, d => BN_DIGITS[d]); }
function hijriToEnDigits(v) { return String(v).replace(/[০-৯]/g, ch => String(BN_DIGITS.indexOf(ch))); }
function hijriParseFlag(v) {
    if (v === true || v === false) return v;
    if (typeof v === 'number') return v !== 0;
    if (typeof v === 'string') {
        const s = v.trim().toLowerCase();
        if (s === 'true' || s === 'on' || s === 'yes' || s === '1') return true;
        if (s === 'false' || s === 'off' || s === 'no' || s === '0') return false;
    }
    return null;
}

// বছর দেওয়া না থাকলে অ্যাপের নিজস্ব হিসাব থেকে বছর নেওয়া (বছরের সীমানা মিলিয়ে)
function hijriDeriveYear(monthIdx, now) {
    try {
        const base = getDisplayHijriDate(now || new Date(), true, true);
        let year = base.year;
        if (monthIdx === 0 && base.month === 11) year += 1;
        else if (monthIdx === 11 && base.month === 0) year -= 1;
        return year;
    } catch (e) { return null; }
}

// Firebase prayer_config → { override, directDate } (সুইচ বন্ধ হলে দুটোই null = অটোমেটিক)
function hijriOverrideFromFirebaseConfig(cfg) {
    const flag = hijriParseFlag(cfg.hijri_override);
    const legacy = (cfg.hijri_date && String(cfg.hijri_date).trim() !== '') ? String(cfg.hijri_date).trim() : null;
    if (flag === false) return { override: null, directDate: null };
    if (flag === true) {
        const o = { on: true };
        let any = false;
        Object.keys(cfg).forEach(function (k) {
            const v = cfg[k];
            if (v && typeof v === 'object' && (v.day != null || v.month != null)) {
                o[k] = { day: v.day != null ? String(v.day) : '', month: v.month != null ? String(v.month) : '', year: v.year != null ? String(v.year) : '' };
                any = true;
            }
        });
        return { override: any ? o : null, directDate: null };
    }
    return { override: null, directDate: legacy };   // hijri_override না থাকলে: আগের একক hijri_date
}

// ভাষা-ভিত্তিক ওভাররাইড ({on, bn:{day,month,year}, en:{...}}) → দিন/মাস/বছর + প্রতিটা ভাষার লেখা
function resolveStructuredHijriOverride(o, now) {
    const keys = Object.keys(o).filter(k => k !== 'on' && o[k] && typeof o[k] === 'object');
    const order = ['bn', 'en'].concat(keys.filter(k => k !== 'bn' && k !== 'en'));
    const get = (k, f) => (o[k] && o[k][f] != null) ? String(o[k][f]).trim() : '';
    let dayStr = '', idx = -1, yearStr = '';
    order.forEach(function (k) {
        if (!dayStr) dayStr = get(k, 'day');
        if (idx < 0) idx = hijriMonthIndexFromName(get(k, 'month'));
        if (!yearStr) { const y = hijriToEnDigits(get(k, 'year')); if (/^\d{3,4}$/.test(y)) yearStr = y; }
    });
    const day = parseInt(hijriToEnDigits(dayStr).replace(/\D/g, ''), 10);
    if (!(day >= 1 && day <= 30)) return null;
    const anyMonthText = order.map(k => get(k, 'month')).find(Boolean) || '';
    if (idx < 0 && !anyMonthText) return null;
    const year = yearStr ? parseInt(yearStr, 10) : (idx >= 0 ? hijriDeriveYear(idx, now) : null);
    if (year === null) return null;
    const hasBn = t => /[\u0980-\u09FF]/.test(t);
    const monthFor = function (k) {                      // bn/en-এ মাসের নাম সবসময় অ্যাপের নির্ধারিত বানানে; চেনা না গেলে অ্যাডমিনের লেখাই
        const typed = get(k, 'month');
        if (k === 'bn') return idx >= 0 ? hijriMonthsBN[idx] : typed;
        if (k === 'en') return idx >= 0 ? hijriMonthsEN[idx] : typed;
        return typed || (idx >= 0 ? hijriMonthsEN[idx] : anyMonthText);
    };
    const dayFor = k => k === 'bn' ? hijriToBnDigits(day) : (k === 'en' ? String(day) : (get(k, 'day') || String(day)));
    const yearFor = k => k === 'bn' ? hijriToBnDigits(year) : String(year);
    const texts = {};
    ['bn', 'en'].concat(keys.filter(k => k !== 'bn' && k !== 'en')).forEach(function (k) {
        texts[k] = { day: dayFor(k), month: monthFor(k), year: yearFor(k) };
        texts[k].text = texts[k].day + ' ' + texts[k].month + ' ' + texts[k].year;
    });
    const lang = (window.__hijriLang && texts[window.__hijriLang]) ? window.__hijriLang : 'bn';
    return { day: day, monthIdx: idx, monthBn: texts.bn.month, monthEn: texts.en.month, year: year,
             text: texts[lang].text, langs: texts };
}

// আগের একক লেখা: "৩০ রবিউস সানি [১৪৪৮]" / "30 Rabi al-Thani"
function resolveLegacyHijriOverride(raw, now) {
    const parts = hijriToEnDigits(raw).trim().replace(/,/g, ' ').split(/\s+/).filter(Boolean);
    if (parts.length < 2 || !/^\d{1,2}$/.test(parts[0])) return null;
    const day = parseInt(parts[0], 10);
    if (!(day >= 1 && day <= 30)) return null;
    let year = null, monthParts = parts.slice(1);
    if (/^\d{3,4}$/.test(parts[parts.length - 1])) { year = parseInt(parts[parts.length - 1], 10); monthParts = parts.slice(1, -1); }
    const monthText = monthParts.join(' ');
    if (!monthText) return null;
    const idx = hijriMonthIndexFromName(monthText);
    if (year === null) year = hijriDeriveYear(idx, now);
    if (year === null) return null;
    const monthBn = idx >= 0 ? hijriMonthsBN[idx] : monthText;
    const monthEn = idx >= 0 ? hijriMonthsEN[idx] : monthText;
    const bn = { day: hijriToBnDigits(day), month: monthBn, year: hijriToBnDigits(year) };
    const en = { day: String(day), month: monthEn, year: String(year) };
    bn.text = bn.day + ' ' + bn.month + ' ' + bn.year; en.text = en.day + ' ' + en.month + ' ' + en.year;
    return { day: day, monthIdx: idx, monthBn: monthBn, monthEn: monthEn, year: year,
             text: (window.__hijriLang === 'en') ? en.text : bn.text, langs: { bn: bn, en: en } };
}

let _hijriOverrideCache = { key: null, val: null };
function resolveHijriOverride(now) {
    const o = window._nativeHijriOverride, raw = window._nativeDirectHijriDate;
    if (!o && !raw) return null;
    const key = (o ? JSON.stringify(o) : '') + '|' + (raw || '') + '|' + (window.__hijriLang || '') + '|' + (now || new Date()).toDateString();
    if (_hijriOverrideCache.key === key) return _hijriOverrideCache.val;
    let val = o ? resolveStructuredHijriOverride(o, now) : null;
    if (!val && raw) val = resolveLegacyHijriOverride(raw, now);
    if (!val) console.warn('হিজরি ওভাররাইড বোঝা যায়নি, অটোমেটিক তারিখ দেখানো হচ্ছে:', o || raw);
    _hijriOverrideCache = { key: key, val: val };
    return val;
}

// চলতি হিজরি মাসের ইনডেক্স (০–১১): ওভাররাইড থাকলে সেটা, নইলে অ্যাপের হিসাব — রমজান-মোড ইত্যাদির জন্য
function getEffectiveHijriMonthIndex(now) {
    const ov = (window._nativeHijriOverride || window._nativeDirectHijriDate) ? resolveHijriOverride(now) : null;
    return (ov && ov.monthIdx >= 0) ? ov.monthIdx : getDisplayHijriDate(now).month;
}

// অন্য/ইংরেজি ইন্টারফেসের জন্য: ওভাররাইডের দিন, মাস, বছর আলাদাভাবে (প্রতিটা ভাষায়); ওভাররাইড না থাকলে null
//   window.getHijriOverrideParts()        → { day, monthBn, monthEn, year, langs: { bn: {day, month, year, text}, en: {...} } }
//   window.getHijriOverrideParts(now,'en') → শুধু ওই ভাষার { day, month, year, text }
window.getHijriOverrideParts = function (now, lang) {
    const ov = (window._nativeHijriOverride || window._nativeDirectHijriDate) ? resolveHijriOverride(now || new Date()) : null;
    if (!ov) return null;
    if (lang) return ov.langs[lang] || ov.langs.bn || null;
    return { day: ov.day, monthBn: ov.monthBn, monthEn: ov.monthEn, year: ov.year, langs: ov.langs };
};

