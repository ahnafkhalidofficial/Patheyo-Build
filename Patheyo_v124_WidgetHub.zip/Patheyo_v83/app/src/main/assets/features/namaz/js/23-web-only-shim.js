/* web-only shim: ব্রাউজারে প্রথম টাচে আজান অডিও আনলক */
(function(){
  if (window.AndroidWidgetBridge) return;
  var done=false;
  function unlock(){
    if(done) return; done=true;
    try{
      var a=azanAudioEngine, v=a.volume; a.volume=0;
      var p=a.play(); if(p&&p.then){p.then(function(){a.pause();a.currentTime=0;a.volume=v;}).catch(function(){a.volume=v;done=false;});}
      else{a.pause();a.currentTime=0;a.volume=v;}
    }catch(e){}
    try{ if('Notification' in window && Notification.permission==='default') Notification.requestPermission(); }catch(e){}
  }
  ['click','touchend','keydown'].forEach(function(ev){document.addEventListener(ev,unlock,{once:false,passive:true});});
})();
