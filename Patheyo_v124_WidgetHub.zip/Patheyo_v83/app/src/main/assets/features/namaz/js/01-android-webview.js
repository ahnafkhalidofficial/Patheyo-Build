/* Android WebView: নেটিভ ব্রিজ (AndroidWidgetBridge) এই ফ্রেমে নিশ্চিত করা */
(function(){try{var p=window.parent;if(p&&p!==window&&!window.AndroidWidgetBridge&&p.AndroidWidgetBridge)window.AndroidWidgetBridge=p.AndroidWidgetBridge;}catch(e){}})();
