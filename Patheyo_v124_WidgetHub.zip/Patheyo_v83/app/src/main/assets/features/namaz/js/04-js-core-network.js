/* js/core/network.js */
/* =============================================================================
   নেটওয়ার্ক হেল্পার
   অনলাইন আছে কি না তার নির্ভরযোগ্য চেক (isActuallyOnline) এবং টাইমআউটযুক্ত fetch হেল্পার।
   (নেটিভ থেকে কল হওয়া setNativeNetworkStatus আছে native-callbacks.js-এ।)
   ============================================================================= */

// Reliable network check - uses Android native status if available, falls back to navigator.onLine
function isActuallyOnline() {
    if (nativeNetworkStatus !== null) {
        return nativeNetworkStatus;
    }
    return navigator.onLine;
}

// নেট মোবাইলে থাকা সত্ত্বেও সময় লাগা কোনো রিকোয়েস্ট (ধীর সংযোগ, DNS জটিলতা, বা ISP-লেভেল সমস্যা) যেন
// অনির্দিষ্টকাল ঝুলে না থেকে যথাসময়ে ব্যর্থ হয়ে ক্যাশে ফলব্যাক করে — তার জন্য টাইমআউট যুক্ত ফেচ হেল্পার।
async function fetchWithTimeout(url, timeoutMs = 12000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        return await fetch(url, { signal: controller.signal });
    } finally {
        clearTimeout(timer);
    }
}

