/* js/prayer/nafal-forbidden.js */
/* =============================================================================
   নফল ও মাকরুহ সময়
   নফল নামাজের সময় ও নিষিদ্ধ (মাকরুহ) সময়ের গণনা ও কার্ড রেন্ডার।
   ============================================================================= */

// --- NAFAL & FORBIDDEN CALCULATIONS ---
function renderNafalAndForbiddenCards(tm, now) {
    const zawalStart = new Date(tm['Dhuhr'].getTime() - 12 * 60000);

    // 1. Ishrak
    const ishrakStart = new Date(tm['Sunrise'].getTime() + 15 * 60000);
    const ishrakEnd = new Date(zawalStart.getTime() - 5 * 60000);

    // 2. Chasht/Duha
    const duhaStart = new Date(tm['Sunrise'].getTime() + ((zawalStart.getTime() - tm['Sunrise'].getTime()) / 2));
    const duhaEnd = new Date(zawalStart.getTime() - 15 * 60000);

    // 3. Awabin
    const awabinStart = new Date(tm['Maghrib'].getTime() + 15 * 60000);
    const awabinEnd = new Date(tm['Isha'].getTime() - 5 * 60000);

    // 4. Tahajjud
    const tahajjudEnd = new Date(tm['Fajr'].getTime() - 10 * 60000);

    const nafalContainer = document.getElementById('nafal-prayer-container');
    const DAY = 86400000;
    const p2 = n => String(n).padStart(2, '0');
    const fmt = d => pcTime(p2(d.getHours()) + ':' + p2(d.getMinutes()));

    /* তাহাজ্জুদের অ্যালার্ম: রাতের শেষ তৃতীয়াংশের শুরু (ইশা → ফজর) */
    let nightStart = tm['Isha'], nightEnd = new Date(tm['Fajr'].getTime() + DAY);
    if (now < tm['Fajr']) { nightStart = new Date(tm['Isha'].getTime() - DAY); nightEnd = tm['Fajr']; }
    const lastThird = new Date(nightStart.getTime() + (nightEnd - nightStart) * 2 / 3);

    const nafalItems = [
        { id: 'ishrak',   cls: 'ishrak',   name: 'ইশরাক',    rk: '২–৪ রাকাত',  start: ishrakStart, end: ishrakEnd, alarm: ishrakStart },
        { id: 'chasht',   cls: 'chasht',   name: 'চাশত',     rk: '২–১২ রাকাত', start: duhaStart,   end: duhaEnd,   alarm: duhaStart },
        { id: 'awabin',   cls: 'awabin',   name: 'আওয়াবিন', rk: '৬–২০ রাকাত', start: awabinStart, end: awabinEnd, alarm: awabinStart },
        { id: 'tahajjud', cls: 'tahajjud', name: 'তাহাজ্জুদ', rk: '২–১২ রাকাত', start: null,        end: tahajjudEnd, alarm: lastThird }
    ];
    window.__nfLast = [tm, now];
    if (typeof nfAfterCompute === 'function') nfAfterCompute(nafalItems, now);

    let nafalHtml = '';
    nafalItems.forEach(item => {
        /* তাহাজ্জুদ: শুরুর নির্দিষ্ট সময় নেই; রাত ১২টার পর থেকে ফজরের আগ পর্যন্ত চলমান ও কাউন্টডাউন */
        const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
        const sT = item.start || midnight;
        const isActive = now >= sT && now < item.end;
        let pct = null, cdHTML = '';
        if (isActive) {
            pct = Math.max(0, Math.min(100, ((now - sT) / (item.end - sT)) * 100));
            const ph = getWaqtPhaseInfo(sT, item.end, now);
            cdHTML = `<div class="nf-cd"><span>${ph.isFirstHalf ? `${item.name}-এর সময় অতিবাহিত` : `${item.name}-এর সময় শেষ হতে বাকি`}</span><b>${pcFixed(ph.diffStr)}</b></div>`;
        }
        const en = fmt(item.end);
        const st = item.start ? fmt(item.start) : null;
        const rangeHTML = (st ? `<b>${st.n}</b><small>${st.p}</small>` : `<b>--:--</b>`) + `<i>–</i><b>${en.n}</b><small>${en.p}</small>`;
        const cfg = (window.nafalConfigs && nafalConfigs[item.id]) || { active: false };
        const al = fmt(item.alarm);
        nafalHtml += `
                <div class="nf ${item.cls}${isActive ? ' on' : ''}">
                    <div class="nf-main">
                        <div class="nf-top"><b>${item.name}</b><span class="nf-rk">${item.rk}</span>${isActive ? '<span class="nf-live"><i></i>চলমান</span>' : ''}</div>
                        <div class="nf-tr">${rangeHTML}</div>
                        ${isActive ? `<div class="nf-bar"><span style="width:${pct.toFixed(1)}%"></span></div>${cdHTML}` : ''}
                    </div>
                    <div class="nf-act">
                        <button class="nf-btn ${cfg.active ? 'on' : ''}" onclick="nfToggle('${item.id}')" aria-label="${cfg.active ? 'অ্যালার্ম অন' : 'অ্যালার্ম অফ'}">${cfg.active ? PC_ICON.bell : PC_ICON.bellOff}</button>
                        <button class="nf-btn" onclick="nfOpenSettings('${item.id}')" aria-label="সেটিংস">${PC_ICON.gear}</button>
                    </div>
                </div>`;
    });
    nafalContainer.innerHTML = nafalHtml;

    const forbiddenContainer = document.getElementById('forbidden-times-container');
    const forbiddenItems = [
        { name: 'সূর্যোদয়', svg: `<svg viewBox="0 0 24 24" class="mk-svg" aria-hidden="true"><path d="M2.5 19h19"/><path d="M7 19a5 5 0 0 1 10 0"/><path class="mk-arr-up" d="M12 4v5M9.6 6.4L12 4l2.4 2.4"/><path d="M4.6 12.2l1.5 1.5M19.4 12.2l-1.5 1.5"/></svg>`,        start: tm['Sunrise'], end: new Date(tm['Sunrise'].getTime() + 15 * 60000) },
        { name: 'দুপুর',     icon: 'fa-sun ic-sun', start: zawalStart, end: tm['Dhuhr'] },
        { name: 'সূর্যাস্ত', svg: `<svg viewBox="0 0 24 24" class="mk-svg" aria-hidden="true"><path d="M2.5 19h19"/><path d="M7 19a5 5 0 0 1 10 0"/><path class="mk-arr-dn" d="M12 4v5M9.6 6.6L12 9l2.4-2.4"/><path d="M4.6 12.2l1.5 1.5M19.4 12.2l-1.5 1.5"/></svg>`, start: new Date(tm['Sunset'].getTime() - 15 * 60000), end: tm['Sunset'] }
    ];

    let forbiddenHtml = '';
    forbiddenItems.forEach(item => {
        const st = fmt(item.start), en = fmt(item.end);
        const isActive = (now >= item.start && now < item.end);
        const mins = Math.max(1, Math.round((item.end - item.start) / 60000));
        const leftMs = Math.max(0, item.end - now);
        const cd = ((p2(Math.floor(leftMs / 3600000)) + ':' + p2(Math.floor((leftMs % 3600000) / 60000)) + ':' + p2(Math.floor((leftMs % 60000) / 1000))));
        forbiddenHtml += `
                <div class="mk${isActive ? ' on' : ''}">
                    <span class="mk-ic">${item.svg || `<i class="fa-solid ${item.icon}"></i>`}</span>
                    <div class="mk-main">
                        <div class="mk-name">${item.name}</div>
                        <div class="mk-time"><b>${st.n}</b><small>${st.p}</small><span>⟶</span><b>${en.n}</b><small>${en.p}</small></div>
                        ${isActive ? `<span class="mk-now"><i></i>নিষিদ্ধ সময় বাকি<b class="mk-cd">${cd}</b></span>` : ''}
                    </div>
                    <div class="mk-dur"><b>${pcBn(mins)}</b><small>মিনিট</small></div>
                </div>`;
    });
    forbiddenContainer.style.setProperty('--ph', '-' + (Date.now() % 24000) + 'ms');
    forbiddenContainer.innerHTML = forbiddenHtml;
}

