/* digital-tasbih থেকে: লাইট/ডার্ক */
function ld(k,d){try{var v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}}
function sv(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
var theme=ld("ns_theme",matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");
function applyTheme(){document.documentElement.setAttribute("data-theme",theme)}
document.getElementById("theme").onclick=function(){theme=theme==="dark"?"light":"dark";sv("ns_theme",theme);applyTheme()};applyTheme();
