/* js/ui/navigation.js */
/* শুধু ড্যাশবোর্ড — ট্যাব নেই */
function switchTab(tId) { /* no-op: single page */ }

