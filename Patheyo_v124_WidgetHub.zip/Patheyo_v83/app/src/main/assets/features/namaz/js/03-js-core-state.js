/* js/core/state.js */
/* =============================================================================
   গ্লোবাল স্টেট
   সব মডিউলের শেয়ার্ড ভ্যারিয়েবল: নামাজের সময়, লোকেশন, মাযহাব, উইজেট থিম,
   ওয়াক্ত কনফিগ, তাসবীহ, কিবলা ও আজান অডিও ইঞ্জিন।
   ⚠️ এটা সবার আগে লোড হতে হবে।
   ============================================================================= */

let globalTimings = null;
let isRamadanNow = false; // রমজান মাস হলে true হবে — উইজেটের সূর্যোদয়/সূর্যাস্ত পিলে সাহরি/ইফতার দেখানোর জন্য ব্যবহৃত
let userLat = 23.8103, userLng = 90.4125;
let currentMadhab = "1";
let quranViewMode = 'surah';
let cacheTemperatureStr = "--°C";
let isShowingOfflineData = false;
let nativeNetworkStatus = null; // Android native network status (true/false)

// প্রতিটা ওয়াক্তের সময় হাতে এক-দুই মিনিট কম/বেশি করে লোকাল মসজিদের সময়সূচির সাথে মিলিয়ে নেওয়ার জন্য
let waqtMinuteOffsets = { Fajr: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0 };

// আজকে অনলাইনে API থেকে সফলভাবে পাওয়া হিজরি তারিখ — মাগরিবের পরে এখান থেকেই ১ দিন বাড়ানো হয়
let hijriApiAnchor = null; // { day, month, year, monthLength, fetchedForDateStr }

let waqtConfigs = {
    Fajr: { isCustom: false, hour: "05", minute: "20", ampm: "AM", active: false },
    Dhuhr: { isCustom: false, hour: "12", minute: "30", ampm: "PM", active: false },
    Asr: { isCustom: false, hour: "04", minute: "15", ampm: "PM", active: false },
    Maghrib: { isCustom: false, hour: "06", minute: "45", ampm: "PM", active: false },
    Isha: { isCustom: false, hour: "08", minute: "15", ampm: "PM", active: false }
};

let targetedActiveWaqtKey = 'Fajr';
let firedAlarmsCacheKey = "";

// Tasbih Module State
let tasbihMode = 'farz'; // 'farz', 'nafal', 'custom'
let currentTasbihIndex = 0;
let tasbihCount = 0;
let tasbihTarget = 33;
let tasbihTitle = "সুবহানআল্লাহ";
const farzTasbihList = [
    { title: "সুবহানআল্লাহ", target: 33 },
    { title: "আলহামদুলিল্লাহ", target: 33 },
    { title: "আল্লাহু আকবার", target: 34 }
];
const nafalTasbihList = [
    { title: "সুবহানআল্লাহ", target: 100 },
    { title: "আলহামদুলিল্লাহ", target: 100 },
    { title: "আল্লাহু আকবার", target: 100 },
    { title: "লা-ইলাহা ইল্লাল্লাহ", target: 100 },
    { title: "আস্তাগফিরুল্লাহ", target: 100 },
    { title: "আল্লাহ", target: 100 }
];
let customTasbihList = JSON.parse(localStorage.getItem('customTasbihList') || '[]');

// Qibla Compass State
let compassHeading = 0;
let qiblaDirection = 0;
let isCompassRunning = false;

const azanAudioEngine = new Audio(window.__ASSET.azan);

