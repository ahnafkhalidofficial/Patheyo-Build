/* js/ui/dashboard.js */
/* =============================================================================
   মূল ড্যাশবোর্ড
   ওয়াক্তের ফেজ হিসাব, টাইমলাইন আপডেট ও ড্যাশবোর্ড কার্ড রেন্ডার।
   ============================================================================= */

// একটা ওয়াক্তের সময়সীমার মাঝে আমরা কোথায় আছি (প্রথমার্ধ না দ্বিতীয়ার্ধ) সেটা বের করে
// উপযুক্ত লেখা+সময় ফেরত দেয় — প্রথমার্ধে "চলছে, এত সময় ধরে" (এলাপসড গণনা),
// দ্বিতীয়ার্ধে "শেষ হতে বাকি, এত সময়" (রিমেইনিং গণনা) — দুটো জায়গায় (ড্যাশবোর্ড কার্ড ও উইজেট) একই নিয়মে ব্যবহার হয়।
function getWaqtPhaseInfo(start, end, now) {
    let elapsedMs = now - start;
    let remainingMs = end - now;

    // নেগেটিভ টাইম বা মাইনাস চিহ্ন রোধ করার জন্য সুরক্ষা
    if (elapsedMs < 0) elapsedMs = 0;
    if (remainingMs < 0) remainingMs = 0;

    const isFirstHalf = elapsedMs < remainingMs;
    const diffMs = isFirstHalf ? elapsedMs : remainingMs;
    const h = Math.floor(diffMs/3600000); const m = Math.floor((diffMs%3600000)/60000); const s = Math.floor((diffMs%60000)/1000);
    const diffStr = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    return { isFirstHalf, diffStr, isOver: (now >= end) };
}

function processDashboardTimelineUpdates(now) {
    if (!globalTimings) return; // ডেটা এখনো লোড না হলে (যেমন অ্যাপ চালু হওয়ার একদম শুরুতে) কিছু করার নেই, ক্র্যাশ এড়ানোর জন্য
    const tm = {
        'Fajr': parseWaqtStringToDate(globalTimings.Fajr),
        'Sunrise': parseWaqtStringToDate(globalTimings.Sunrise),
        'Dhuhr': parseWaqtStringToDate(globalTimings.Dhuhr),
        'Asr': parseWaqtStringToDate(globalTimings.Asr),
        'Maghrib': parseWaqtStringToDate(globalTimings.Maghrib),
        'Isha': parseWaqtStringToDate(globalTimings.Isha),
        'Sunset': parseWaqtStringToDate(globalTimings.Sunset || globalTimings.Maghrib)
    };

    // নামাজের ৩টা নিষিদ্ধ সময়ের প্রতিটার সঠিক শুরু ও শেষ — পরে এলাপসড/রিমেইনিং বের করার জন্য লাগবে
    const forbiddenWindows = [
        { start: tm['Sunrise'], end: new Date(tm['Sunrise'].getTime() + 15*60000) },
        { start: new Date(tm['Dhuhr'].getTime() - 12*60000), end: tm['Dhuhr'] },
        { start: new Date(tm['Sunset'].getTime() - 15*60000), end: tm['Sunset'] }
    ];
    let isForbidden = false; let activeForbiddenWindow = null;
    for (const w of forbiddenWindows) {
        if (now >= w.start && now < w.end) { isForbidden = true; activeForbiddenWindow = w; break; }
    }
    document.getElementById('forbidden-time-banner').style.display = isForbidden ? 'flex' : 'none';

    // নামাজের সঠিক ওয়াক্ত হিসাব: ফজরের ওয়াক্ত সূর্যোদয়েই শেষ হয়ে যায়, এরপর যোহর শুরু না হওয়া পর্যন্ত কোনো ফরজ ওয়াক্ত "চলমান" থাকে না (isGap)।
    let act = null; let start = null; let end = null; let isGap = false;
    if(now >= tm['Fajr'] && now < tm['Sunrise']) { act = 'Fajr'; start = tm['Fajr']; end = tm['Sunrise']; }
    else if(now >= tm['Sunrise'] && now < tm['Dhuhr']) { isGap = true; start = tm['Sunrise']; end = tm['Dhuhr']; }
    else if(now >= tm['Dhuhr'] && now < tm['Asr']) { act = 'Dhuhr'; start = tm['Dhuhr']; end = tm['Asr']; }
    else if(now >= tm['Asr'] && now < tm['Maghrib']) { act = 'Asr'; start = tm['Asr']; end = tm['Maghrib']; }
    else if(now >= tm['Maghrib'] && now < tm['Isha']) { act = 'Maghrib'; start = tm['Maghrib']; end = tm['Isha']; }
    else {
        act = 'Isha';
        if(now >= tm['Isha']) { start = tm['Isha']; end = new Date(tm['Fajr'].getTime() + 24*60*60000); }
        else { end = tm['Fajr']; start = new Date(tm['Isha'].getTime() - 24*60*60000); }
    }

    renderMainDashboardCards(tm, act, start, end, now, isGap, isForbidden, activeForbiddenWindow);
    renderNafalAndForbiddenCards(tm, now);
}

function buildForbiddenStatusHTML(activeForbiddenWindow, now, compact) {
    const phase = getWaqtPhaseInfo(activeForbiddenWindow.start, activeForbiddenWindow.end, now);
    const phaseLabel = phase.isFirstHalf ? 'চলছে' : 'বাকি আছে';
    if (compact) {
        return `⚠️ সাবধান! নিষিদ্ধ সময় ${phaseLabel}: ${phase.diffStr}`;
    }
    return `<p class="text-[13px] md:text-xs font-bold mt-1 flex items-center gap-1.5" style="color:#FACC15">
                        <span>⚠️ সাবধান! এখন নামাজ পড়া ও সিজদা আদায় করা থেকে বিরত থাকুন — নিষিদ্ধ সময় ${phaseLabel}: <span class="mono-font">${phase.diffStr}</span></span>
                    </p>`;
}

/* বাংলা ওয়াক্তের নাম — শুক্রবারে যোহরের নাম হবে "জুম’আ" */
function waqtBnName(id, d) {
    d = d || new Date();
    if (id === 'Dhuhr' && d.getDay() === 5) return 'জুম’আ';
    return ({ Fajr: 'ফজর', Dhuhr: 'যোহর', Asr: 'আসর', Maghrib: 'মাগরিব', Isha: 'ইশা' })[id] || id;
}

const PC_ICON = {
    bell:    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6.5 2 6.5H4S6 14 6 9z"/><path d="M10 19a2 2 0 0 0 4 0"/></svg>',
    bellOff: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8.6 4.6A6 6 0 0 1 18 9c0 3 .7 4.9 1.5 5.8"/><path d="M6.2 7.6C6.1 8 6 8.5 6 9c0 5-2 6.5-2 6.5h11"/><path d="M10 19a2 2 0 0 0 4 0"/><path d="M3 3l18 18"/></svg>',
    gear:    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'
};
const PC_WAQT_ICON = { Fajr: 'fa-moon', Dhuhr: 'fa-sun', Asr: 'fa-cloud-sun', Maghrib: 'fa-cloud-moon', Isha: 'fa-star-and-crescent' };
const PC_ICON_ANIM = { Fajr: 'ic-moon', Dhuhr: 'ic-sun', Asr: 'ic-cloudsun', Maghrib: 'ic-cloudmoon', Isha: 'ic-star', Jumuah: 'ic-mosque' };

const PC_BN = '০১২৩৪৫৬৭৮৯';
function pcBn(s) { return String(s).replace(/\d/g, d => PC_BN[d]); }
/* প্রতিটা ফরয ওয়াক্ত যে সময়ে শেষ হয় (ড্যাশবোর্ডের কাউন্টডাউনের হিসাবের সাথে হুবহু এক) */
const PC_END_KEY = { Fajr: 'Sunrise', Dhuhr: 'Asr', Asr: 'Maghrib', Maghrib: 'Isha', Isha: 'Fajr' };
/* প্রতিটা অঙ্ক নির্দিষ্ট প্রস্থের ঘরে বসে — ফন্ট যা-ই হোক, সেকেন্ড বদলালে লেখা নড়ে না */
function pcFixed(s) { return String(s).replace(/\d/g, d => `<span class="fd">${d}</span>`).replace(/:/g, '<span class="fc">:</span>'); }
function pcTime(s24) {
    const t = String(convert24To12(s24)).trim().split(' ');
    return { n: pcBn(t[0]), p: t[1] || '' };
}

function pcIcon(id, isJumuah, icon, icAnim) {
    if (!isJumuah) {
        if (id === 'Fajr') return `<svg viewBox="0 0 24 24" class="pc-svg" fill="currentColor" aria-hidden="true"><mask id="pcm-fajr" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24"><rect width="24" height="24" fill="#fff"/><circle cx="14.6" cy="12" r="7" fill="#000"/></mask><g transform="rotate(-25 12 12)"><circle cx="11" cy="12" r="8.2" mask="url(#pcm-fajr)"/></g><circle class="tw" style="animation-duration:2s;animation-delay:calc(var(--ph,0s) - 0s)" cx="16.2" cy="7.8" r="0.8"/><circle class="tw" style="animation-duration:3s;animation-delay:calc(var(--ph,0s) - 0.9s)" cx="19.6" cy="11.4" r="0.65"/><circle class="tw" style="animation-duration:4s;animation-delay:calc(var(--ph,0s) - 1.7s)" cx="14.6" cy="15.4" r="0.75"/><circle class="tw" style="animation-duration:2s;animation-delay:calc(var(--ph,0s) - 0.4s)" cx="18.6" cy="16.2" r="0.6"/><circle class="tw" style="animation-duration:3s;animation-delay:calc(var(--ph,0s) - 2.1s)" cx="20.6" cy="6.6" r="0.55"/><circle class="tw" style="animation-duration:4s;animation-delay:calc(var(--ph,0s) - 0.6s)" cx="12.6" cy="4.6" r="0.6"/><circle class="tw" style="animation-duration:2s;animation-delay:calc(var(--ph,0s) - 1.3s)" cx="21" cy="14" r="0.5"/></svg>`;
        if (id === 'Asr') return `<svg viewBox="0 0 24 24" class="pc-svg" fill="currentColor" aria-hidden="true"><mask id="pcm-asr" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24"><rect width="24" height="24" fill="#fff"/><g class="" fill="#000" stroke="#000" stroke-width="2.4"><rect x="6" y="16" width="13" height="4.2" rx="2.1"/><circle cx="10.2" cy="15.8" r="3"/><circle cx="14.8" cy="14.6" r="3.8"/></g></mask><g mask="url(#pcm-asr)"><g class="sun-rot"><circle cx="9.5" cy="9.5" r="3.4"/><g stroke="currentColor" stroke-width="1.8" stroke-linecap="round" fill="none"><path d="M9.5 1.6v1.6M9.5 15.8v1.6M1.6 9.5h1.6M15.8 9.5h1.6M3.9 3.9l1.1 1.1M14 14l1.1 1.1M15.1 3.9L14 5M5 14l-1.1 1.1"/></g></g></g><g><rect x="6" y="16" width="13" height="4.2" rx="2.1"/><circle cx="10.2" cy="15.8" r="3"/><circle cx="14.8" cy="14.6" r="3.8"/></g></svg>`;
        if (id === 'Maghrib') return `<svg viewBox="0 0 24 24" class="pc-svg" fill="currentColor" aria-hidden="true"><mask id="pcm-mag" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24"><rect width="24" height="24" fill="#fff"/><g class="mg-cloud" fill="#000" stroke="#000" stroke-width="2.4"><rect x="6" y="16" width="13" height="4.2" rx="2.1"/><circle cx="10.2" cy="15.8" r="3"/><circle cx="14.8" cy="14.6" r="3.8"/></g></mask><mask id="pcm-mag2" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24"><rect width="24" height="24" fill="#fff"/><circle cx="12" cy="9.5" r="5.4" fill="#000"/></mask><g mask="url(#pcm-mag)"><g class="mg-moon"><g transform="rotate(-25 9 9.5)"><circle cx="9" cy="9.5" r="6.4" mask="url(#pcm-mag2)"/></g></g></g><g class="mg-cloud"><rect x="6" y="16" width="13" height="4.2" rx="2.1"/><circle cx="10.2" cy="15.8" r="3"/><circle cx="14.8" cy="14.6" r="3.8"/></g></svg>`;
        if (id === 'Isha') return `<svg viewBox="0 0 24 24" class="pc-svg" fill="currentColor" aria-hidden="true"><mask id="pcm-isha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24"><rect width="24" height="24" fill="#fff"/><circle cx="14.6" cy="12" r="7" fill="#000"/></mask><g transform="rotate(-25 12 12)"><circle cx="11" cy="12" r="8.2" mask="url(#pcm-isha)"/></g><path class="tw-star" d="M15.60,7.20 L16.36,9.35 L18.64,9.41 L16.84,10.80 L17.48,12.99 L15.60,11.70 L13.72,12.99 L14.36,10.80 L12.56,9.41 L14.84,9.35Z"/></svg>`;
    }
    return `<i class="fa-solid ${icon} ${icAnim}"></i>`;
}

function renderMainDashboardCards(tm, act, start, end, now, isGap, isForbidden, activeForbiddenWindow) {
    const container = document.getElementById('main-prayer-cards-container');
    /* নিষিদ্ধ সময়ে কোনো ফরয ওয়াক্ত সিলেক্ট/লাল হবে না — উপরের লাল সতর্কতা ও নিচের মাকরুহ অংশেই দেখাবে */
    if (isForbidden) { act = null; isGap = false; isForbidden = false; }
    const list = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map(id => ({ id, name: waqtBnName(id, now) }));

    const firstRender = !container.firstElementChild;
    /* কার্ড প্রতি সেকেন্ডে নতুন করে আঁকা হয়; সব লুপ অ্যানিমেশন ঘড়ির সাথে একই ফেজে চালু হয় যাতে মাঝপথে ঝাঁকি না খায় */
    container.style.setProperty('--ph', '-' + (Date.now() % 24000) + 'ms');
    const popId = window.__pcPop; window.__pcPop = null;
    let html = '';
    list.forEach((item, idx) => {
        const isCurrent = item.id === act;
        const isGapForbid = (isGap && item.id === 'Dhuhr' && isForbidden);
        const bad = (isCurrent && isForbidden) || isGapForbid;
        const cnf = waqtConfigs[item.id];
        let statHTML = '';
        let badgeHTML = '';
        let barPct = null;
        let midHTML = '';

        if (isCurrent) {
            const total = end - start;
            barPct = total > 0 ? Math.max(0, Math.min(100, ((now - start) / total) * 100)) : 0;
        }
        if (isCurrent && isForbidden) {
            statHTML = buildForbiddenStatusHTML(activeForbiddenWindow, now, false);
            badgeHTML = '<span class="pc-chip bad">নিষিদ্ধ সময়</span>';
        } else if (isCurrent) {
            const phase = getWaqtPhaseInfo(start, end, now);
            if (!(phase.isOver || phase.diffStr.startsWith('-'))) {
                midHTML = `<div class="pc-mt"><span>${phase.isFirstHalf ? `${item.name}-এর সময় অতিবাহিত` : `${item.name}-এর সময় শেষ হতে বাকি`}</span><b>${pcFixed(phase.diffStr)}</b></div>`;
            }
            badgeHTML = `<span class="pc-chip live"><i style="animation-delay:-${Date.now() % 1600}ms"></i>চলমান</span>`;
        } else if (isGapForbid) {
            statHTML = buildForbiddenStatusHTML(activeForbiddenWindow, now, false);
            badgeHTML = '<span class="pc-chip bad">নিষিদ্ধ সময়</span>';
        }
        statHTML = statHTML.replace(/\d{2}:\d{2}:\d{2}/g, pcFixed);
        const customChip = cnf.isCustom ? `<span class="pc-chip custom">কাস্টম ${pcBn(cnf.hour + ':' + cnf.minute)} ${cnf.ampm}</span>` : '';

        const st = pcTime(globalTimings[item.id]);
        const en = pcTime(globalTimings[PC_END_KEY[item.id]]);
        const nextDay = item.id === 'Isha' ? '<em>পরদিন</em>' : '';
        const isJumuah = (item.id === 'Dhuhr' && now.getDay() === 5);
        const icon = isJumuah ? 'fa-mosque' : PC_WAQT_ICON[item.id];
        const icAnim = isJumuah ? PC_ICON_ANIM.Jumuah : PC_ICON_ANIM[item.id];
        const cls = 'pc' + (isCurrent ? ' cur' : '') + (bad ? ' bad' : '') + (firstRender ? ' pc-in' : '');
        const inStyle = firstRender ? ` style="animation-delay:${idx * 60}ms"` : '';
        const popCls = (popId === item.id) ? ' pop' : '';
        const lineFill = barPct !== null ? `<span style="width:${barPct.toFixed(1)}%"></span><u style="left:${barPct.toFixed(1)}%"></u>` : '';

        const actionsHTML = `
                <div class="pc-act">
                    <button class="pc-btn ${cnf.active ? 'on' : ''}${popCls}" onclick="window.__pcPop='${item.id}';toggleAlarmActiveState('${item.id}')" aria-label="${cnf.active ? 'অ্যালার্ম অন' : 'অ্যালার্ম অফ'}" title="${cnf.active ? 'অ্যালার্ম অন' : 'অ্যালার্ম অফ'}">${cnf.active ? PC_ICON.bell : PC_ICON.bellOff}</button>
                    <button class="pc-btn gear" onclick="openWaqtConfigModal('${item.id}')" aria-label="সেটিংস" title="সেটিংস">${PC_ICON.gear}</button>
                </div>`;

        if (isCurrent) {
            /* চলমান ওয়াক্ত: শুরু — শেষ সময় + প্রোগ্রেস লাইন */
            html += `
        <div class="${cls}"${inStyle}>
            <div class="pc-row">
                <div class="pc-ic">${pcIcon(item.id, isJumuah, icon, icAnim)}</div>
                <div class="pc-main">
                    <div class="pc-name-row"><span class="pc-name">${item.name}</span>${badgeHTML}${customChip}</div>
                </div>${actionsHTML}
            </div>
            <div class="pc-span">
                <div class="pc-pt"><span class="pc-pl">শুরু</span><div><b>${st.n}</b><small>${st.p}</small></div></div>
                <div class="pc-mid">${midHTML}<div class="pc-line">${lineFill}</div></div>
                <div class="pc-pt end"><span class="pc-pl">শেষ${nextDay ? ' · পরদিন' : ''}</span><div><b>${en.n}</b><small>${en.p}</small></div></div>
            </div>
            ${statHTML}
        </div>`;
        } else {
            /* অন্য ওয়াক্ত: আগের মতো শুধু শুরুর সময় */
            html += `
        <div class="${cls}"${inStyle}>
            <div class="pc-row">
                <div class="pc-ic">${pcIcon(item.id, isJumuah, icon, icAnim)}</div>
                <div class="pc-main">
                    <div class="pc-name-row"><span class="pc-name">${item.name}</span>${badgeHTML}</div>
                    <div class="pc-time"><b>${st.n}</b><small>${st.p}</small>${customChip}</div>
                </div>${actionsHTML}
            </div>
            ${statHTML}
        </div>`;
        }
    });
    container.innerHTML = html;
}

/* ---------- সেটিংস পপআপের ছোট সহায়ক ফাংশন ---------- */
function wmNorm(el) {
    const min = parseInt(el.min, 10), max = parseInt(el.max, 10);
    let v = parseInt(el.value, 10); if (isNaN(v)) v = (el.id === 'custom-minute-offset') ? 0 : min;
    v = Math.max(min, Math.min(max, v));
    el.value = (el.id === 'custom-minute-offset') ? String(v) : String(v).padStart(2, '0');
}
function wmStep(id, d, min, max, wrap) {
    const el = document.getElementById(id); let v = parseInt(el.value, 10); if (isNaN(v)) v = 0;
    v += d;
    if (v > max) v = wrap ? min : max;
    if (v < min) v = wrap ? max : min;
    el.value = (id === 'custom-minute-offset') ? String(v) : String(v).padStart(2, '0');
}
function wmSyncAmPm() {
    const v = document.getElementById('custom-ampm').value;
    const am = document.getElementById('wm-am'), pm = document.getElementById('wm-pm');
    if (!am || !pm) return;
    am.classList.toggle('on', v === 'AM'); pm.classList.toggle('on', v === 'PM');
    am.parentNode.dataset.v = v;
}
function wmSetAmPm(v) { document.getElementById('custom-ampm').value = v; wmSyncAmPm(); }
/* রিসেট বাটন: কাস্টম সময় বা মিনিট এডজাস্ট থাকলে চালু, না থাকলে নিষ্ক্রিয় */
var wmResetState = '', wmResetTimer = null;
function wmSetSub(t) {
    const sub = document.getElementById('wm-reset-sub'); if (!sub) return;
    sub.textContent = t; sub.classList.remove('swap'); void sub.offsetWidth; sub.classList.add('swap');
}
function wmUpdateResetBtn() {
    const btn = document.getElementById('wm-reset-btn'); if (!btn) return;
    if (wmResetState === 'busy') return;
    const modeBtn = document.getElementById('amode-custom');
    const isCustom = !!modeBtn && modeBtn.getAttribute('data-state') === 'true';
    const offEl = document.getElementById('custom-minute-offset');
    const off = offEl ? (parseInt(offEl.value, 10) || 0) : 0;
    const dirty = isCustom || off !== 0;
    const card = document.getElementById('wm-reset-card');
    if (dirty && wmResetState === 'done') { wmResetState = ''; if (card) card.classList.remove('done'); }
    btn.disabled = !dirty;
    const sec = document.getElementById('wm-reset-sec'); if (sec) sec.classList.toggle('is-idle', !dirty && wmResetState !== 'done');
    if (wmResetState === 'done') return;
    const sub = document.getElementById('wm-reset-sub');
    if (sub) sub.textContent = dirty ? (isCustom && off !== 0 ? 'কাস্টম সময় ও এডজাস্ট চালু আছে' : isCustom ? 'কাস্টম নির্দিষ্ট সময় চালু আছে' : 'মিনিট এডজাস্ট চালু আছে') : 'ওয়াক্তের নিজস্ব সময় ব্যবহার হচ্ছে';
}
function wmPulse(el) { if (!el) return; el.classList.remove('wm-pulse'); void el.offsetWidth; el.classList.add('wm-pulse'); }
function resetWaqtToRealTime() {
    if (wmResetState === 'busy') return;
    const btn = document.getElementById('wm-reset-btn'), card = document.getElementById('wm-reset-card');
    const lbl = document.getElementById('wm-reset-lbl');
    /* মান সঙ্গে সঙ্গে আসল অবস্থায় বসানো হয় — যাতে মাঝপথে সেভ করলেও ঠিক থাকে */
    setAlarmCustomTimeMode(false);
    const offEl = document.getElementById('custom-minute-offset'); if (offEl) { offEl.value = 0; wmPulse(offEl); }
    wmResetState = 'busy';
    if (card) { card.classList.remove('done'); card.classList.add('busy'); }
    if (btn) { btn.disabled = true; btn.classList.add('busy'); }
    if (lbl) lbl.textContent = 'অপেক্ষা করুন';
    wmSetSub('আসল সময়ে ফিরিয়ে আনা হচ্ছে…');
    try { if (navigator.vibrate) navigator.vibrate(8); } catch (e) {}
    clearTimeout(wmResetTimer);
    wmResetTimer = setTimeout(function () {
        wmResetState = 'done';
        if (card) { card.classList.remove('busy'); card.classList.add('done'); }
        if (btn) btn.classList.remove('busy');
        if (lbl) lbl.textContent = 'রিসেট';
        wmUpdateResetBtn();
        wmSetSub('আসল সময়ে ফিরে এসেছে · সেভ করলে কার্যকর হবে');
    }, 900);
}
(function () {
    const m = document.getElementById('waqt-setup-modal'); if (!m) return;
    ['click', 'input', 'change'].forEach(function (ev) {
        m.addEventListener(ev, function (e) {
            if (e.target && e.target.closest && e.target.closest('#wm-reset-btn')) return;
            setTimeout(wmUpdateResetBtn, 0);
        });
    });
})();
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { const m = document.getElementById('waqt-setup-modal'); if (m && m.style.display === 'flex') closeWaqtModal(); }
});


