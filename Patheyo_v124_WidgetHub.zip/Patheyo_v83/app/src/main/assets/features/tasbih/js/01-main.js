
(function(){
var FARZ=[{id:"f1",ar:"سُبْحَانَ ٱللّٰه",bn:"সুবহানাল্লাহ",t:33},{id:"f2",ar:"ٱلْحَمْدُ لِلّٰه",bn:"আলহামদুলিল্লাহ",t:33},{id:"f3",ar:"ٱللّٰهُ أَكْبَر",bn:"আল্লাহু আকবার",t:34}];
var NAFL=[["سُبْحَانَ ٱللّٰه","সুবহানাল্লাহ"],["ٱلْحَمْدُ لِلّٰه","আলহামদুলিল্লাহ"],["ٱللّٰهُ أَكْبَر","আল্লাহু আকবার"],["ٱللّٰه","আল্লাহ"],["لَا إِلٰهَ إِلَّا ٱللّٰه","লা ইলাহা ইল্লাল্লাহ"],["ٱللّٰهُ ٱللّٰه","আল্লাহু আল্লাহ"],["أَسْتَغْفِرُ ٱللّٰه","আসতাগফিরুল্লাহ"],["يَا غَفُور","ইয়া গাফুর"],["يَا شَافِي","ইয়া শাফি"],["يَا رَحْمٰن","ইয়া রহমান"],["يَا رَحِيم","ইয়া রহীম"],["يَا كَرِيم","ইয়া কারীম"],["لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِٱللّٰه","লা হাওলা ওয়ালা কুওয়াতা ইল্লা বিল্লাহ"],["ٱللّٰهُمَّ صَلِّ عَلَىٰ مُحَمَّد","আল্লাহুম্মা সাল্লি আলা মুহাম্মাদ"]].map(function(x,i){return{id:"n"+i,ar:x[0],bn:x[1],t:100}});
var $=function(i){return document.getElementById(i)};
function ld(k,d){try{var v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}}
function sv(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
function today(){var d=new Date();return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()}
var popId=null,wPop=null;
var counts=ld("tz3_counts",{}),mine=ld("tz3_mine",[]),tab=ld("tz3_tab","farz"),fi=ld("tz3_fi",0),sel={nafl:ld("tz3_sn","n0"),mine:ld("tz3_sm",null)};
var daily=ld("tz3_daily",{d:today(),total:0,done:0});if(daily.d!==today())daily={d:today(),total:0,done:0};
var theme=ld("tz3_theme",matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");
function bn(n){return String(n).replace(/\d/g,function(d){return "০১২৩৪৫৬৭৮৯"[d]})}
function esc(s){return s.replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function applyTheme(){document.documentElement.setAttribute("data-theme",theme)}
$("theme").onclick=function(){theme=theme==="dark"?"light":"dark";sv("tz3_theme",theme);applyTheme()};applyTheme();
function cur(){
  if(tab==="farz")return FARZ[fi];
  if(tab==="nafl")return NAFL.filter(function(x){return x.id===sel.nafl})[0]||NAFL[0];
  var m=mine.filter(function(x){return x.id===sel.mine})[0]||mine[0];return m?{id:m.id,ar:"",bn:m.bn,t:m.t}:null;
}
// tick dial
var ticks=[],tkey="";
function build(t){
  var n=Math.min(t,100),key=n+"";if(key===tkey)return;tkey=key;
  var s=$("ticks");s.innerHTML="";ticks=[];
  var w=n<=40?5:n<=70?3.6:2.8;
  for(var i=0;i<n;i++){
    var a=i/n*Math.PI*2-Math.PI/2,l=document.createElementNS("http://www.w3.org/2000/svg","line"),c=Math.cos(a),sn=Math.sin(a);
    l.setAttribute("x1",160+136*c);l.setAttribute("y1",160+136*sn);l.setAttribute("x2",160+152*c);l.setAttribute("y2",160+152*sn);
    l.setAttribute("stroke-width",w);l.setAttribute("class","tk");s.appendChild(l);ticks.push(l);
  }
}
function paint(c,t){
  var n=ticks.length,f=t<=100?c:Math.floor(c/t*n);
  ticks.forEach(function(k,i){k.classList.toggle("on",i<f);k.classList.toggle("cur",i===f&&c<t)});
}
function render(){
  var idx=["farz","nafl","mine"].indexOf(tab);$("thumb").style.transform="translateX("+(idx*100)+"%)";
  document.querySelectorAll(".seg button").forEach(function(b){b.setAttribute("aria-selected",b.dataset.t===tab)});
  rail();
  var d=cur();
  $("s1").textContent=bn(daily.total);$("s3").textContent=bn(daily.done);
  if(!d){$("ar").textContent="";$("bn").textContent="কোনো জিকির নেই";$("n").textContent="০";$("t").textContent="";$("fin").textContent="উপরের “+ নতুন” থেকে জিকির যোগ করুন";$("s2").textContent="০";build(33);paint(0,33);return}
  var c=Math.min(counts[d.id]||0,d.t);
  $("ar").textContent=d.ar;$("bn").textContent=d.bn;$("n").textContent=bn(c);$("t").textContent="লক্ষ্য "+bn(d.t);
  $("s2").textContent=bn(d.t-c);build(d.t);paint(c,d.t);
  var last=tab!=="farz"||fi===FARZ.length-1;
  $("fin").textContent=(c>=d.t&&last)?"মাশাআল্লাহ! জিকির সম্পন্ন হয়েছে 🤲":"";
}
function rail(){
  var r=$("rail"),old=r.firstChild?r.firstChild.scrollLeft:0;
  if(tab==="farz"){
    var s=r.querySelector(".stepper");
    if(!s){r.innerHTML='<div class="stepper"></div>';s=r.firstChild;
      FARZ.forEach(function(f,i){var b=document.createElement("button");b.innerHTML='<b></b><span>'+f.bn+'</span>';b.onclick=function(){fi=i;sv("tz3_fi",fi);render()};s.appendChild(b)})}
    var CK='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.6 12.9l4.1 4.1 8.7-9.1"/></svg>';
    FARZ.forEach(function(f,i){
      var b=s.children[i],c=Math.min(counts[f.id]||0,f.t),ok=c>=f.t,bb=b.firstChild;
      b.className="stp"+(ok?" ok":(i===fi?" cur":""))+(ok&&popId===f.id?" pop":"");
      b.style.setProperty("--p",(c/f.t).toFixed(4));
      var st=ok?"ok":"n"+i;if(bb.getAttribute("data-s")!==st){bb.setAttribute("data-s",st);bb.innerHTML=ok?CK:bn(i+1)}
    });
    return;
  }
  r.innerHTML='<div class="chips"></div>';var c=r.firstChild,d=cur();
  var list=tab==="nafl"?NAFL:mine;
  list.forEach(function(x){var b=document.createElement("button");b.className="chip";b.setAttribute("aria-pressed",!!d&&d.id===x.id);b.textContent=x.bn;
    b.onclick=function(){if(tab==="nafl"){sel.nafl=x.id;sv("tz3_sn",x.id)}else{sel.mine=x.id;sv("tz3_sm",x.id)}render()};c.appendChild(b)});
  if(tab==="mine"){var a=document.createElement("button");a.className="chip add";a.textContent="+ নতুন জিকির";a.onclick=openSheet;c.appendChild(a)}
  c.scrollLeft=old;
}
// sheet (my dhikr)
function openSheet(){
  var sc=$("sc");
  sc.innerHTML='<h3>নতুন জিকির যোগ করুন</h3><div class="form"><input id="fn" placeholder="জিকিরের নাম" maxlength="80"><div class="r"><input id="fc" type="number" inputmode="numeric" min="1" max="100000" placeholder="সংখ্যা"><button class="go" id="add">সেভ করুন</button></div></div><h3>সংরক্ষিত জিকির</h3><div id="L"></div>';
  var L=$("L");if(!mine.length)L.innerHTML='<div class="empty">এখনো কোনো জিকির সেভ করা হয়নি</div>';
  mine.forEach(function(x){var e=document.createElement("div");e.className="it";e.innerHTML='<span>'+esc(x.bn)+'<small>লক্ষ্য '+bn(x.t)+'</small></span><button class="x">মুছুন</button>';
    e.querySelector(".x").onclick=function(){if(confirm("এই জিকিরটি মুছে ফেলবেন?")){mine=mine.filter(function(y){return y.id!==x.id});delete counts[x.id];sv("tz3_mine",mine);sv("tz3_counts",counts);if(sel.mine===x.id)sel.mine=null;render();openSheet()}};L.appendChild(e)});
  $("add").onclick=function(){var n=$("fn").value.trim(),t=parseInt($("fc").value,10);
    if(!n){$("fn").focus();return}if(!t||t<1){$("fc").focus();return}
    var it={id:"m"+Date.now(),bn:n,t:Math.min(t,100000)};mine.push(it);sv("tz3_mine",mine);sel.mine=it.id;sv("tz3_sm",it.id);closeSheet();render()};
  $("sheet").classList.add("on");$("veil").classList.add("on");
}
function closeSheet(){$("sheet").classList.remove("on");$("veil").classList.remove("on")}
$("veil").onclick=closeSheet;


// soft sound (WebAudio, no files)
var soundOn=ld("tz3_sound",true),ac=null;
function sndIcon(){$("snd").classList.toggle("on",soundOn);$("snd").setAttribute("aria-pressed",soundOn)}
$("snd").onclick=function(){soundOn=!soundOn;sv("tz3_sound",soundOn);sndIcon();if(soundOn)snd("tick")};sndIcon();
function bell(f,t0,dur,vol){
  [[1,1],[2,.28],[3,.1]].forEach(function(h){
    var o=ac.createOscillator(),g=ac.createGain();o.type="sine";o.frequency.value=f*h[0];
    g.gain.setValueAtTime(0.0001,t0);g.gain.exponentialRampToValueAtTime(vol*h[1],t0+0.01);g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
    o.connect(g);g.connect(ac.destination);o.start(t0);o.stop(t0+dur+0.02);
  });
}
function click(t0,j){
  var o=ac.createOscillator(),g=ac.createGain();
  o.type="sine";o.frequency.setValueAtTime(1700*j,t0);o.frequency.exponentialRampToValueAtTime(1250*j,t0+0.035);
  g.gain.setValueAtTime(0.0001,t0);g.gain.exponentialRampToValueAtTime(0.045,t0+0.003);g.gain.exponentialRampToValueAtTime(0.0001,t0+0.05);
  o.connect(g);g.connect(ac.destination);o.start(t0);o.stop(t0+0.07);
  var len=Math.floor(ac.sampleRate*0.012),b=ac.createBuffer(1,len,ac.sampleRate),d=b.getChannelData(0);
  for(var i=0;i<len;i++)d[i]=(Math.random()*2-1)*(1-i/len);
  var s=ac.createBufferSource(),hp=ac.createBiquadFilter(),ng=ac.createGain();s.buffer=b;hp.type="highpass";hp.frequency.value=3500;ng.gain.value=0.02;
  s.connect(hp);hp.connect(ng);ng.connect(ac.destination);s.start(t0);
}
function snd(kind){
  if(!soundOn)return;
  try{
    ac=ac||new (window.AudioContext||window.webkitAudioContext)();
    if(ac.state==="suspended")ac.resume();
    var t0=ac.currentTime,j=1+(Math.random()-.5)*0.04;
    if(kind==="end"){
      [523.25,659.25,783.99,1046.5,1318.5].forEach(function(f,i){bell(f,t0+i*.085,.5,.032)});
      [1046.5,1318.5,1568].forEach(function(f){bell(f,t0+.5,1.1,.022)});
      [2093,2637,3136].forEach(function(f,i){bell(f,t0+.62+i*.07,.45,.008)});
    }else click(t0,j);
  }catch(e){}
}
// congratulation screen
var wTimer=null;
function closeWin(){$("win").classList.remove("on");clearTimeout(wTimer);if(wPop){popId=wPop;wPop=null;render();popId=null}}
function confetti(){
  var cf=$("cf");cf.innerHTML="";var cols=["#FFFFFF","#D9FFE9","#FFE9A8","#9BE8C2"];
  for(var i=0;i<34;i++){var s=document.createElement("span");
    s.style.left=Math.random()*100+"%";s.style.background=cols[i%4];
    s.style.setProperty("--dx",(Math.random()*120-60)+"px");
    s.style.animationDuration=(2.2+Math.random()*2.2)+"s";s.style.animationDelay=(Math.random()*.7)+"s";cf.appendChild(s)}
}
function celebrate(d){
  var lastFarz=tab==="farz"&&fi===FARZ.length-1,mid=tab==="farz"&&!lastFarz,next=mid?FARZ[fi+1]:null;
  $("wt").textContent=lastFarz?"অভিনন্দন! মাশাআল্লাহ":"মাশাআল্লাহ!";
  $("ws").textContent=mid?(d.bn+" "+bn(d.t)+" বার সম্পন্ন। এবার: "+next.bn)
    :lastFarz?"নামাজের পরের সব জিকির সম্পূর্ণ হয়েছে। আল্লাহ কবুল করুন 🤲"
    :(d.bn+" "+bn(d.t)+" বার সম্পন্ন হয়েছে। আল্লাহ কবুল করুন 🤲");
  $("wag").style.display=mid?"none":"block";
  wPop=tab==="farz"?d.id:null;confetti();$("win").classList.add("on");
  $("wok").onclick=closeWin;
  $("wag").onclick=function(){if(tab==="farz"){FARZ.forEach(function(f){counts[f.id]=0});fi=0;sv("tz3_fi",0)}else counts[d.id]=0;sv("tz3_counts",counts);closeWin();render()};
  if(mid){fi++;sv("tz3_fi",fi);render();wTimer=setTimeout(closeWin,2800)}
}
function buzz(p){try{navigator.vibrate&&navigator.vibrate(p)}catch(e){}}
function saveDaily(){sv("tz3_daily",daily)}
var disc=$("disc");
function tick(){
  var d=cur();if(!d)return;var c=counts[d.id]||0;
  if(c>=d.t){if(tab==="farz"&&fi<FARZ.length-1){fi++;sv("tz3_fi",fi);render()}return}
  c++;counts[d.id]=c;sv("tz3_counts",counts);daily.total++;
  snd(c>=d.t?"end":"tick");
  var n=$("n");n.classList.add("b");setTimeout(function(){n.classList.remove("b")},150);
  if(c>=d.t){daily.done++;buzz([40,60,90]);saveDaily();render();celebrate(d);return}else buzz(12);
  saveDaily();render();
}
disc.addEventListener("pointerdown",function(){disc.classList.add("down");tick()});
["pointerup","pointerleave","pointercancel"].forEach(function(v){disc.addEventListener(v,function(){disc.classList.remove("down")})});
disc.addEventListener("keydown",function(e){if(e.key===" "||e.key==="Enter"){e.preventDefault();tick()}});
$("undo").onclick=function(){var d=cur();if(!d)return;if(tab==="farz"&&!(counts[d.id]>0)&&fi>0){fi--;sv("tz3_fi",fi);d=cur()}
  if(counts[d.id]>0){if(counts[d.id]>=d.t&&daily.done>0)daily.done--;counts[d.id]--;if(daily.total>0)daily.total--;sv("tz3_counts",counts);saveDaily()}render()};
$("reset").onclick=function(){if(tab==="farz"){FARZ.forEach(function(f){counts[f.id]=0});fi=0;sv("tz3_fi",0)}else{var d=cur();if(d)counts[d.id]=0}sv("tz3_counts",counts);render()};
document.querySelectorAll(".seg button").forEach(function(b){b.onclick=function(){tab=b.dataset.t;sv("tz3_tab",tab);render()}});
render();
})();
