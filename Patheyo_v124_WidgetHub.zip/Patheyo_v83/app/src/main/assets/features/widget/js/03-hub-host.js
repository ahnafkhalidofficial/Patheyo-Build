/* নেটিভ উইজেট হাব বসানো।
   এই পেজের শুধু হেডার HTML; হেডারের নিচের ফাঁকা অংশ (#hub-slot) জুড়ে অ্যাপের নেটিভ উইজেট হাব (Kotlin: WidgetHubHost) বসে।
   এখানে কাজ: (১) পেজ খোলা ও ফেড শেষ হলে স্লটের জায়গা/মাপ স্ক্রিন-পিক্সেলে নেটিভকে জানানো,
   (২) পেজের থিম (ডার্ক/লাইট) জানানো, (৩) পেজ বন্ধ/ঢাকা পড়লে হাব লুকাতে বলা। */
(function () {
  'use strict';
  var slot = document.getElementById('hub-slot');
  var fe = null; try { fe = window.frameElement; } catch (e) {}
  var overlay = fe && fe.parentElement;
  var lastKey = '', shown = false;

  function bridge() {
    try { return window.AndroidWidgetBridge || (window.parent && window.parent.AndroidWidgetBridge) || null; } catch (e) { return null; }
  }
  function opaque(c) {                       /* "rgb(r,g,b)" → 0xFFRRGGBB; স্বচ্ছ হলে null */
    var m = /^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/.exec(c || '');
    if (!m || (m[4] !== undefined && parseFloat(m[4]) < 1)) return null;
    return ((255 << 24) | (+m[1] << 16) | (+m[2] << 8) | +m[3]) | 0;
  }
  function visible() {
    if (!slot || !overlay || document.hidden) return false;
    if (!overlay.classList.contains('is-open')) return false;
    var cs = getComputedStyle(overlay);
    return cs.visibility !== 'hidden' && parseFloat(cs.opacity) >= 0.99;   /* ফেড-ইন শেষ হলে; ফেড-আউট শুরু হলেই লুকানো */
  }
  function hide() {
    if (!shown) return;
    shown = false; lastKey = '';
    var b = bridge(); if (b && b.hideWidgetHub) { try { b.hideWidgetHub(); } catch (e) {} }
  }
  function sync() {
    var b = bridge();
    if (!b || !b.showWidgetHub) return;
    if (!visible()) { hide(); return; }
    var sr = slot.getBoundingClientRect(), fr = fe.getBoundingClientRect();
    var dpr = window.devicePixelRatio || 1;
    var dark = document.documentElement.getAttribute('data-theme') !== 'light';
    var bg = opaque(getComputedStyle(document.body).backgroundColor);
    if (bg === null) bg = dark ? 0xFF040C21 | 0 : 0xFFF2F5FA | 0;           /* হাবের নিজস্ব ব্যাকগ্রাউন্ড রঙ */
    var left = Math.round((fr.left + sr.left) * dpr), top = Math.round((fr.top + sr.top) * dpr);
    var w = Math.round(sr.width * dpr), h = Math.round((window.innerHeight - sr.top) * dpr);
    var key = [left, top, w, h, dark ? 1 : 0, bg].join(',');
    if (key === lastKey) return;
    lastKey = key; shown = true;
    try { b.showWidgetHub(left, top, w, h, dark, bg); } catch (e) {}
  }

  window.addEventListener('resize', sync);
  window.addEventListener('pagehide', hide);
  document.addEventListener('visibilitychange', sync);
  if (window.MutationObserver) new MutationObserver(sync).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  setInterval(sync, 150);                    /* ওভারলের খোলা/বন্ধ ও ফেড ধরার জন্য */
  sync();
})();
