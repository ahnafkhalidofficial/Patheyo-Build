

/* লাইট/ডার্ক মোড (Namajer_Somoysuci.html-এর হুবহু একই কোড; সেভ হওয়া মোড না থাকলে ডার্ক, কারণ উইজেট হাবের ডিজাইন ডার্ক) */
function ld(k,d){try{var v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}}
function sv(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
var theme=ld("ns_theme","dark");
function applyTheme(){document.documentElement.setAttribute("data-theme",theme);var m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute("content",theme==="dark"?"#040C21":"#F2F5FA")}
document.getElementById("theme").onclick=function(){theme=theme==="dark"?"light":"dark";sv("ns_theme",theme);applyTheme()};applyTheme();

