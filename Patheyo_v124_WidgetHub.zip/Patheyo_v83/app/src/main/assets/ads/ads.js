/* ===== Patheyo বিজ্ঞাপন -- হোম স্লাইডার + সব পেজের নিচের ফিক্সড বিজ্ঞাপন =====
   কনফিগ: ads/ads-config.js (window.PT_ADS)। এই ফাইলের কোড বদলানোর দরকার নেই।
   - PTAds.mountFooter(doc): ফিচার পেজের (iframe) একদম নিচে ফিক্সড বিজ্ঞাপন বসায় -- শেল প্রতিটা ফিচারে এটা নিজে ডাকে, তাই নতুন ফিচারেও আপনাআপনি আসে।
   - লিংক সবসময় target="_blank" -- অ্যান্ড্রয়েড অ্যাপ (MainActivity.shouldOverrideUrlLoading) সেটা ফোনের ব্রাউজারে খোলে। */
(function () {
  var C = window.PT_ADS; if (!C) return;
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  function url(p) { try { return new URL(p, document.baseURI).href; } catch (e) { return p; } }
  var ARROW = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>';
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

  /* ---------- হোম স্লাইডার ---------- */
  function initCarousel() {
    var host = document.getElementById('ad-carousel'); if (!host || !C.carousel || !C.carousel.length) return;
    var n = C.carousel.length, cur = 0, timer = 0, paused = false, visible = true, idleT = 0;
    host.innerHTML = '<div class="ad-viewport" id="ad-viewport"><div class="ad-track">' + C.carousel.map(function (s, i) {
      return '<div class="ad-slide' + (i === 0 ? ' is-active' : '') + '"><img src="' + esc(url(s.img)) + '" alt="' + esc(s.alt || '') + '" draggable="false" ' + (i === 0 ? '' : 'loading="lazy" ') + 'width="1200" height="350">' +
        '<a class="ad-go" href="' + esc(s.link || C.site) + '" target="_blank" rel="noopener" aria-label="ওয়েবসাইটে যান" title="ওয়েবসাইটে যান">' + ARROW + '</a></div>';
    }).join('') + '</div></div><div class="ad-dots" role="tablist" aria-label="বিজ্ঞাপন">' + C.carousel.map(function (s, i) {
      return '<button class="ad-dot' + (i === 0 ? ' is-active' : '') + '" type="button" role="tab" aria-label="ছবি ' + (i + 1) + '"></button>';
    }).join('') + '</div>';
    var vp = host.querySelector('#ad-viewport'), slides = host.querySelectorAll('.ad-slide'), dots = host.querySelectorAll('.ad-dot');
    function mark(i) {
      if (i === cur && slides[i].classList.contains('is-active')) return;
      cur = i;
      for (var k = 0; k < n; k++) { slides[k].classList.toggle('is-active', k === i); dots[k].classList.toggle('is-active', k === i); }
    }
    function go(i, smooth) { vp.scrollTo({ left: i * vp.clientWidth, behavior: (smooth && !reduce) ? 'smooth' : 'auto' }); mark(i); }
    var raf = 0;
    vp.addEventListener('scroll', function () {            /* আঙুলে টানলে ডট নিজে বদলায় */
      if (raf) return; raf = requestAnimationFrame(function () { raf = 0; var w = vp.clientWidth || 1; mark(Math.max(0, Math.min(n - 1, Math.round(vp.scrollLeft / w)))); });
    }, { passive: true });
    dots.forEach(function (d, i) { d.addEventListener('click', function () { hold(); go(i, true); }); });
    function hold() { paused = true; clearTimeout(idleT); idleT = setTimeout(function () { paused = false; }, C.intervalMs || 5000); }   /* ইউজার ছুঁলে ৫ সেকেন্ড অটো-বদল থামে */
    ['touchstart', 'pointerdown', 'wheel'].forEach(function (ev) { vp.addEventListener(ev, hold, { passive: true }); });
    function tick() { if (paused || !visible || document.hidden) return; go((cur + 1) % n, true); }
    function start() { clearInterval(timer); timer = setInterval(tick, C.intervalMs || 5000); }
    if ('IntersectionObserver' in window) new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }, { threshold: 0.4 }).observe(host);
    window.addEventListener('resize', function () { vp.scrollLeft = cur * vp.clientWidth; });
    start();
  }

  /* ---------- নিচের ফিক্সড বিজ্ঞাপন ---------- */
  var FOOT_HTML = function () {
    var f = C.footer; if (!f) return '';
    return '<a class="pt-ad-foot" href="' + esc(f.link || C.site) + '" target="_blank" rel="noopener" aria-label="' + esc(f.alt || '') + '"><img src="' + esc(url(f.img)) + '" alt="' + esc(f.alt || '') + '" width="1200" height="450"></a>';
  };
  function initHomeFooter() {
    var h = document.getElementById('ad-footer-home'); if (h) h.innerHTML = FOOT_HTML().replace('class="pt-ad-foot"', 'class="pt-ad-foot in-home"');
  }
  /* নিচের বিজ্ঞাপনের CSS এখানেই বসানো (fetch ভরসা করা যায় না -- অ্যান্ড্রয়েডে file:// fetch ব্যর্থ হলে ছবি আসল মাপে ফেটে যেত)। ads.css-এর নিচের অংশের কপি। */
  var FOOT_CSS = "/* নিচের ফিক্সড বিজ্ঞাপন -- হালকা আলোর ঝিলিক + নরম শ্বাসের মতো ছায়া */\n.pt-ad-foot { display: block; position: relative; margin: 22px 16px 14px; border-radius: 16px; overflow: hidden; text-decoration: none; line-height: 0;\n  aspect-ratio: 8 / 3; background: #E3EDFD; -webkit-tap-highlight-color: transparent;\n  box-shadow: 0 10px 24px -14px rgba(0, 32, 94, .5), 0 0 0 1px rgba(35, 95, 254, .18); animation: ptAdGlow 4.8s ease-in-out infinite; }\n.pt-ad-foot img { display: block; width: 100%; height: 100%; object-fit: cover; }\n.pt-ad-foot::after { content: \"\"; position: absolute; top: 0; bottom: 0; left: -40%; width: 28%; pointer-events: none;\n  background: linear-gradient(100deg, rgba(255,255,255,0) 0%, rgba(255,255,255,.6) 50%, rgba(255,255,255,0) 100%);\n  transform: skewX(-18deg); animation: ptAdShine 4.8s ease-in-out infinite; }\n.pt-ad-foot:active { transform: scale(.992); }\n@keyframes ptAdShine { 0%, 62% { left: -40%; } 92%, 100% { left: 120%; } }\n@keyframes ptAdGlow { 0%, 100% { box-shadow: 0 10px 24px -14px rgba(0,32,94,.5), 0 0 0 1px rgba(35,95,254,.18); } 50% { box-shadow: 0 12px 30px -12px rgba(35,95,254,.55), 0 0 0 1px rgba(35,95,254,.34); } }\n@media (prefers-reduced-motion: reduce) { .pt-ad-foot, .pt-ad-foot::after { animation: none; } .ad-slide img { transition: none; transform: none; opacity: 1; } }\n.pt-ad-foot.in-home { margin: 8px 0 0; }\n\n#pt-ad-foot-wrap{display:block;width:100%;max-width:480px;margin:0 auto;padding:0 0 4px;box-sizing:border-box}#pt-ad-foot-wrap .pt-ad-foot{margin:22px 0 14px;width:100%;box-sizing:border-box}#pt-ad-foot-wrap .pt-ad-foot img{max-width:100%!important;width:100%!important;height:100%!important}#pt-ad-foot-wrap.pt-ad-off{display:none!important}";
  /* কুরআন/হাদিসে বিজ্ঞাপন শুধু প্রথম (তালিকার) পেজে; পড়ার, তরজমার, ডাউনলোড ও অন্য সব ভিতরের পেজে লুকানো */
  function watchView(doc, w) {
    var win = doc.defaultView; if (!win) return;
    function sync() { try { var A = win.QuranApp || win.HadithApp; if (!A || !A.state) return; w.classList.toggle('pt-ad-off', A.state.view !== 'list'); } catch (e) {} }
    sync(); win.setInterval(sync, 200);
  }
  function mountFooter(doc) {
    try {
      if (!doc || !doc.body || doc.getElementById('pt-ad-foot-wrap')) return;
      var st = doc.createElement('style'); st.textContent = FOOT_CSS; doc.head.appendChild(st);
      var w = doc.createElement('div'); w.id = 'pt-ad-foot-wrap'; w.innerHTML = FOOT_HTML();
      var root = doc.querySelector('.app') || doc.body;
      var cs = doc.defaultView.getComputedStyle(root);
      if (root === doc.body || (parseFloat(cs.paddingLeft) || 0) < 8) w.style.padding = '0 16px 4px';
      root.appendChild(w);
      if (doc.querySelector('.tabs') || /quran|hadith/i.test(doc.title || '') ) watchView(doc, w);
    } catch (e) {}
  }
  window.PTAds = { mountFooter: mountFooter };
  function boot() { initCarousel(); initHomeFooter(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
