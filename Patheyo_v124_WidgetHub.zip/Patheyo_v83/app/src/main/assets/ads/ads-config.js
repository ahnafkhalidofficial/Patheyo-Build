/* ===== Patheyo বিজ্ঞাপন কনফিগ (এই ফাইল বদলালেই সব বিজ্ঞাপন বদলায়) =====
   - ছবির মাপ সবসময় ১২০০ × ২০০ px (৬:১)। ছবিগুলো এই `ads/img/` ফোল্ডারে থাকে।
   - নতুন ছবি দিতে: ছবি `ads/img/`-এ রাখুন, নিচের তালিকায় একটা লাইন যোগ করুন। ডটের সংখ্যা নিজে থেকে ছবির সংখ্যা অনুযায়ী হয়।
   - link: ছবির ডান কোণার ছোট বাটনে চাপলে যেখানে যাবে (এখন সবই আমাদের ওয়েবসাইট)। */
window.PT_ADS = {
  site: 'https://patheyobygunjoron.github.io/',
  intervalMs: 5000,                                   /* প্রতি কত মিলিসেকেন্ডে নিজে থেকে পরের ছবি */
  carousel: [
    { img: 'ads/img/carousel-1.png', alt: 'পাথেয় বাই গুঞ্জরণ — চিরস্থায়ী সফরের পরম সঙ্গী', link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-2.png', alt: 'নামাজের সময়সূচি — প্রতিটি ওয়াক্তের সঠিক সময়',       link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-3.png', alt: 'কুরআন শরিফ — ১১৪ সূরা, ৩০ পারা এক অ্যাপে',           link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-4.png', alt: 'হাদিস শরিফ — সিহাহ সিত্তার ৬ কিতাব',                  link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-5.png', alt: 'আমল, তাসবিহ, কিবলা ও উইজেট — সামনে আসছে দোয়া',         link: 'https://patheyobygunjoron.github.io/' }
  ],
  footer: { img: 'ads/img/footer.png', alt: 'পাথেয় বাই গুঞ্জরণ — আজই ডাউনলোড করুন', link: 'https://patheyobygunjoron.github.io/' }
};
