# 📖 কুরআন — মুসহাফ PDF ও তরজমা ডাউনলোড (v55)

## কীভাবে কাজ করে
- কুরআন পেজে মুসহাফ (PDF) ও তরজমা (JSON) অ্যাপের ভেতরে নেই; প্রথমবার খুললে GitHub Release থেকে নামিয়ে অ্যাপের স্টোরেজে রাখা হয়, তারপর অফলাইনেই চলে।
- ডাউনলোডার: Kotlin — `quran/QuranFileBridge.kt` (WebView-তে `QuranNative` = মুসহাফ, `QuranTarjamaNative` = তরজমা)।
- ফাইল পড়া: `quran/QuranLocalServer.kt` ফাইলগুলো `https://quran-local.invalid/…` ঠিকানায় দেখায়; কাজ না করলে ব্রিজ থেকে টুকরো টুকরো (base64) পড়ে।
- ফাইল থাকে: `filesDir/quran/Hafezi-Quran.pdf` ও `filesDir/quran/Quran-Tarjama.json`।
- ডাউনলোড মাঝপথে কেটে গেলে `.part` ফাইল থাকে; আবার চাপলে যেখানে থেমেছিল সেখান থেকে চলে।
- ডাউনলোড শেষে ফাইল যাচাই হয় (PDF: `%PDF-` দিয়ে শুরু; তরজমা: `.gz` খুলে `{"format":` দিয়ে শুরু)। ভুল ফাইল হলে সেভ হয় না, ত্রুটি দেখায়।
- প্রগ্রেস Kotlin থেকে `window.__quranNativeEvent` (index.html-এর `native-bridge` স্ক্রিপ্ট) হয়ে কুরআন ফ্রেমে যায়।

## ডাউনলোড লিংক বদলাতে চাইলে
`assets/index.html`-এর কুরআন অংশে দুটো কনফিগ আছে (টেক্সট সার্চ করে নিন):
- `window.__QURAN_PDF_CONFIG__` → `url` (মুসহাফ PDF), `sizeBytes`
- `window.__QURAN_TARJAMA_CONFIG__` → `url` (তরজমা `.json.gz`), `sizeBytes`, `authorName`

বর্তমান লিংক: `…/quran-assets-by-patheyo/releases/download/v1/Hafezi-Quran.pdf` ও `…/v3/Quran-Tarjama.json.gz`।

## ত্রুটির কোড (পেজে বাংলায় দেখায়)
`offline` (নেট নেই) · `timeout` · `network` (কেটে গেছে, আবার চাপলে চলবে) · `ssl` (ফোনের তারিখ/সময় ভুল) · `no-space` · `http-404` (লিংক ভুল) · `not-pdf` / `not-tarjama` (ভুল ফাইল) · `corrupt` (নষ্ট ফাইল)।
