# উইজেট ও উইজেট হাব (নেটিভ)

হোম-স্ক্রিন উইজেট ও অ্যাপের "উইজেট" পেজের হাব — দুটোই `app/src/main/java/com/gunjoron/patheyo/widget/`।

## গঠন
| জায়গা | কাজ |
|---|---|
| `PrayerWidgetProvider.kt` | ম্যানিফেস্টের একমাত্র উইজেট-রিসিভার। টিক/আনলক/রিফ্রেশ ধরে `WidgetUpdater`/`WidgetRefreshScheduler`-কে ডাকে। `PREFS_NAME`/`KEY_TIMINGS` অ্যাপের বাকি অংশ ব্যবহার করে — বদলাবেন না। |
| `WidgetUpdater.kt` | Snapshot + Look → বিটম্যাপ → RemoteViews (`wv15_d*` লেআউট); মিনিট-টিক অ্যালার্ম; ডিজাইন ৬-এর আনলক অ্যানিমেশন। |
| `data/Snapshot.kt` | **আগের ডেটা-সিস্টেম** থেকে এই মুহূর্তের সব তথ্য (সময়, হিজরি, বাংলা/ইংরেজি তারিখ, নিষিদ্ধ সময়, বার্তা)। |
| `data/HubPrefs.kt` | হাবের নিজস্ব সেটিং (থিম, ডিজাইন, কাস্টম রঙ, "ইংরেজি তারিখ আগে")। |
| `WidgetRefreshScheduler.kt`, `WidgetUpdateWorker`, `RtdbSyncWorker`, `NativePrayerTimesFetcher` | ডেটা আনা/অ্যালার্ম — আগের সিস্টেম, অপরিবর্তিত। |
| `designs/`, `render/`, `theme/`, `assets/` | ৯ ডিজাইন, আঁকার সরঞ্জাম, রঙ, ফন্ট/আর্ট। |
| `hub/HubScreen.kt`, `hub/ui/` | নেটিভ হাবের কনটেন্ট (হেডার ছাড়া)। |
| `hub/WidgetHubHost.kt` | হাবকে উইজেট পেজের হেডারের নিচে বসায় (`activity_main.xml`-এর `widget_hub_host`)। |

## ডেটা কোথা থেকে
`SharedPreferences "ibadat_widget_prefs"`: `timings_json`, `hijri_date_firebase`, `hijri_date_firebase_set_on`, `last_rtdb_adjustment`, `timings_fetched_on` + ফায়ারবেজ ওভাররাইড (`FirebaseDataManager.overrideHijriOrNull`)। হিজরি তারিখের সংখ্যা ও মাস সবসময় বাংলায়।

## নিয়ম (আগের উইজেটের হুবহু)
- নিষিদ্ধ সময়: সূর্যোদয়ের পর ১৫ মি., যোহরের আগে ১২ মি., সূর্যাস্তের আগে ১৫ মি.।
- জুম'আ: ক্যালেন্ডারের শুক্রবারে "যোহর"-এর জায়গায় "জুম'আ"।
- রোজা হারামের দিন (ঈদুল ফিতর, কোরবানির ঈদ, আইয়ামে তাশরিক): ডিজাইনের স্ট্যাটাস লাইনে বার্তা (`Snapshot.message`), লাইভ টাইমার সেই সময় লুকানো।
- ডেটা না থাকলে "--:--" ও "–" অবস্থা।

## পেজ ↔ হাব
`features/widget/widget.html` শুধু হেডার (আগের মতো) ও `#hub-slot`। `js/03-hub-host.js` পেজ খোলা ও ফেড শেষ হলে স্লটের স্ক্রিন-পিক্সেল মাপ ও থিম `AndroidWidgetBridge.showWidgetHub(...)`-এ পাঠায়; বন্ধ হলে `hideWidgetHub()`।

## লেআউট বদলাতে
`tools/genlayout.py` চালান (`python3 tools/genlayout.py`) — `res/layout/wv15_*`-এ লেখে। লেআউট বদলালে নামের ভার্শন (`wv15` → `wv16`) বাড়ান, নইলে লঞ্চার পুরনোটাই দেখায়।

## নতুন ডিজাইন
`designs/XxxDesign.kt` → `WidgetRenderer` (মাপ+ডিসপ্যাচ) → `tools/genlayout.py` → `WidgetUpdater.LAYOUT_W/H` → `HubPrefs` সীমা ও `HubScreen.designTitles`।
