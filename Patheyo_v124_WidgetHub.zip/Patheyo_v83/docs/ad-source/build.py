import re,sys,os,html
A='/tmp/claude-0/-home-claude/d9c2552f-5d71-5344-9783-aace0d3ed7ed/scratchpad/v83src/Patheyo_v83/app/src/main/assets'
idx=open(A+'/index.html',encoding='utf-8').read().split('\n')
defs=[l for l in idx if l.startswith('<svg width="0" height="0" style="position:absolute"') and 'gjG1_' in l][0]   # gradient defs used by tile icons
logo=re.search(r'<svg class="brand-logo-svg".*?</svg>','\n'.join(idx),re.S).group(0)
tiles=re.findall(r'<span class="module-tile-icon">(<svg.*?</svg>)</span>\s*<span class="module-tile-title[^>]*>([^<]*)</span>',open(A+'/index.html',encoding='utf-8').read(),re.S)
icon={t[1].strip():t[0] for t in tiles}
print(list(icon),file=sys.stderr)
FONT=A+'/fonts/Gunjoron-Font-Normal.ttf',A+'/fonts/Gunjoron-Font-Bold.ttf'
ICONCSS=open('icon.css',encoding='utf-8').read()

BASE = '''
@font-face{font-family:K;src:url("file://%s");font-weight:400}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:K,"Noto Sans Bengali",sans-serif;position:relative;overflow:hidden}
.abs{position:absolute}
.module-tile-icon svg{display:block;width:100%%;height:100%%;overflow:visible}
''' % FONT[0] + ICONCSS

def page(name, w, h, css, body):
    open(f'{name}.html', 'w', encoding='utf-8').write(
        f'<!doctype html><meta charset="utf-8"><style>{BASE}html,body{{width:{w}px;height:{h}px}}{css}</style><body>{defs}{body}</body>')

def ic(n, size): return f'<div class="module-tile-icon" style="width:{size}px;height:{size}px">{icon[n]}</div>'
def chev(s): return f'<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" style="width:{s}px;height:{s}px"><path d="M5 12h13M13 6l6 6-6 6"/></svg>'
def dots(c, op=.2): return f'<div class="abs" style="inset:0;opacity:{op};background-image:radial-gradient(circle at 1px 1px,{c} 1.3px,transparent 1.7px);background-size:20px 20px"></div>'

# ---- স্লাইডারের ৫টি ছবি: ১২০০×৩৫০ ----
H = 350
PILL = "border-radius:999px;"

# ১: ব্র্যান্ড নীল
page('ad1', 1200, H, """
body{background:linear-gradient(100deg,#F4F8FF,#E3EDFD 55%,#CFE0FB);color:#00205E}
.plate{left:44px;top:50px;width:250px;height:250px;border-radius:50%;background:#fff;box-shadow:0 20px 40px -16px rgba(0,32,94,.4),inset 0 0 0 3px rgba(35,95,254,.35)}
.plate svg{width:250px;height:250px;border-radius:50%}
.k{font-size:28px;font-weight:700;color:#8A5A12;background:linear-gradient(135deg,#FFF3CF,#F4DDA0);border:2px solid rgba(201,138,43,.55);border-radius:999px;padding:3px 24px 5px;align-self:flex-start}
.txt{left:340px;top:0;bottom:0;width:520px;display:flex;flex-direction:column;justify-content:center;gap:14px}
h1{font-size:70px;line-height:1.12;white-space:nowrap}h1 em{font-style:normal;color:#235FFE}
p{font-size:34px;color:#3A4A73}
.rc{right:44px;top:0;bottom:0;width:330px;display:flex;flex-wrap:wrap;align-content:center;justify-content:flex-end;gap:14px;padding-bottom:70px}
.rc span{font-size:28px;font-weight:700;background:rgba(255,255,255,.92);border:2px solid rgba(35,95,254,.4);border-radius:999px;padding:7px 26px 9px;box-shadow:0 10px 20px -12px rgba(0,32,94,.5)}
.o{right:-120px;top:-230px;width:520px;height:520px;border-radius:50%;background:radial-gradient(circle,rgba(35,95,254,.28),transparent 70%)}
""", f'''{dots("rgba(35,95,254,.5)")}<div class="abs o"></div><div class="abs plate">{logo}</div>
<div class="abs txt"><div class="k">নতুন অ্যাপ · পাথেয়</div><h1>পাথেয় <em>বাই গুঞ্জরণ</em></h1><p>চিরস্থায়ী সফরের পরম সঙ্গী</p></div>
<div class="abs rc"><span>নামাজ</span><span>কুরআন</span><span>হাদিস</span><span>কিবলা</span><span>তাসবিহ</span><span>উইজেট</span></div>''')

# ২: সোনালি-ক্রিম টাইমলাইন
nodes = ''.join(
    f'<div style="position:absolute;left:{x}px;top:0;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:10px"><i style="width:28px;height:28px;border-radius:50%;background:{c};border:5px solid #fff;box-shadow:0 0 0 3px {c}"></i><b style="font-size:32px;color:#5A3A06">{t}</b></div>'
    for x, t, c in [(50, 'ফজর', '#E0A02C'), (230, 'যোহর', '#C98516'), (410, 'আসর', '#B8740F'), (590, 'মাগরিব', '#C9602B'), (770, 'ইশা', '#7A4A9E')])
page('ad2', 1200, H, """
body{background:linear-gradient(115deg,#FFFBEF,#FDEFC6 55%,#F8DB93);color:#5A3A06}
.band{left:0;right:0;bottom:0;height:120px;background:linear-gradient(0deg,rgba(201,133,22,.18),transparent)}
.ring{left:44px;top:50px;width:240px;height:240px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff,#FFF1CC);box-shadow:0 20px 40px -16px rgba(138,90,18,.5),inset 0 0 0 4px rgba(224,160,44,.6);display:grid;place-items:center}
.kk{left:340px;top:30px;font-size:27px;font-weight:700;color:#fff;background:linear-gradient(135deg,#E0A02C,#B8740F);border-radius:999px;padding:3px 26px 5px}
h1{left:340px;top:82px;font-size:66px;line-height:1.1;font-weight:700;white-space:nowrap}h1 em{font-style:normal;color:#B8610F}
.sub{left:340px;top:170px;font-size:31px;color:#7A5A2A;white-space:nowrap}
.sun{right:40px;top:-90px;width:260px;height:260px;border-radius:50%;background:radial-gradient(circle,rgba(255,196,64,.55),transparent 70%)}
""", f'''<div class="abs band"></div><div class="abs sun"></div>{dots("rgba(201,133,22,.7)",.16)}<div class="abs kk">নামাজের সময়সূচি</div>
<h1 class="abs">প্রতিটি ওয়াক্তের <em>সঠিক সময়</em></h1><div class="abs sub">আজানের রিমাইন্ডার ও নিষিদ্ধ সময়ের সতর্কতা সহ</div>
<div class="abs" style="left:390px;top:262px;width:720px;height:0;border-top:4px dashed rgba(184,116,15,.45)"></div>
<div class="abs" style="left:340px;top:248px;width:860px;height:90px">{nodes}</div>
<div class="abs ring">{ic('নামাজের সময়', 170)}</div>''')

# ৩: সবুজ বড় সংখ্যা
page('ad3', 1200, H, """
body{background:linear-gradient(100deg,#F0FBF5,#D5F2E3 55%,#ADE3C7);color:#06402A}
.stat{top:56px;width:196px;height:238px;border-radius:40px;background:linear-gradient(150deg,#1DB877,#0A7A4C);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;box-shadow:0 22px 38px -18px rgba(6,64,42,.7),inset 0 0 0 3px rgba(255,255,255,.35)}
.stat b{font-size:104px;line-height:1}.stat span{font-size:34px;font-weight:700;margin-top:4px}
.stat.g{background:linear-gradient(150deg,#F6C95A,#C98516)}
.kk{left:490px;top:50px;font-size:26px;font-weight:700;color:#0A7A4C;background:#fff;border:2px solid rgba(10,122,76,.45);border-radius:999px;padding:3px 24px 5px}
h1{left:490px;top:100px;font-size:58px;line-height:1.12;font-weight:700;white-space:nowrap}h1 em{font-style:normal;color:#0E9F5A}
.sub{left:490px;top:182px;font-size:29px;color:#2F6B52;white-space:nowrap}
.chips{left:490px;top:250px;display:flex;gap:9px}
.chips span{font-size:22px;font-weight:700;color:#0A5A38;background:rgba(255,255,255,.85);border-radius:999px;padding:3px 15px 5px;border:1.5px solid rgba(10,122,76,.35)}
.big{right:30px;top:70px;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff,#DDF6EA);box-shadow:0 22px 40px -18px rgba(6,64,42,.55),inset 0 0 0 4px rgba(14,159,90,.5);display:grid;place-items:center}
.arc{right:-70px;bottom:-190px;width:480px;height:480px;border-radius:50%;border:44px solid rgba(14,159,90,.14)}
""", f'''{dots("rgba(10,122,76,.6)",.14)}<div class="abs arc"></div>
<div class="abs stat" style="left:40px"><b>১১৪</b><span>সূরা</span></div><div class="abs stat g" style="left:256px"><b>৩০</b><span>পারা</span></div>
<div class="abs kk">কুরআন শরিফ</div><h1 class="abs">এক অ্যাপে <em>পুরো কুরআন</em></h1><div class="abs sub">তরজমা ও মুসহাফ পেজ সহ, যখন খুশি পড়ুন</div>
<div class="abs chips"><span>সূরা</span><span>পারা</span><span>তরজমা</span><span>মুসহাফ</span><span>বুকমার্ক</span></div>
<div class="abs big">{ic('কুরআন শরিফ', 146)}</div>''')

# ৪: টিল-আকাশি বইয়ের সারি
sp = ''.join(
    f'<div style="width:62px;height:{h}px;border-radius:14px 14px 6px 6px;background:linear-gradient(170deg,{a},{b});color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:16px 0 14px;box-shadow:0 14px 24px -12px rgba(7,71,90,.7),inset 0 0 0 3px rgba(255,255,255,.28)"><i style="width:38px;height:5px;border-radius:3px;background:rgba(255,255,255,.7)"></i><b style="font-size:42px;line-height:1">{n}</b><i style="width:38px;height:5px;border-radius:3px;background:rgba(255,255,255,.7)"></i></div>'
    for n, h, a, b in [('১', 192, '#2A74E0', '#1F4FB0'), ('২', 220, '#F2BD42', '#C98516'), ('৩', 176, '#1DB877', '#0A7A4C'), ('৪', 230, '#1CBBA7', '#0E7F76'), ('৫', 186, '#5BB5F0', '#2B7FD0'), ('৬', 210, '#7A5AD6', '#4A33A8')])
page('ad4', 1200, H, """
body{background:linear-gradient(105deg,#F0FAFD,#D4EFF6 55%,#A9DCEA);color:#07475A}
.shelf{right:76px;bottom:26px;width:460px;height:20px;border-radius:10px;background:linear-gradient(#B58A3C,#8A5F1E);box-shadow:0 10px 18px -8px rgba(7,71,90,.5)}
.books{right:96px;bottom:46px;display:flex;align-items:flex-end;gap:10px}
.plate{left:40px;top:80px;width:190px;height:190px;border-radius:46px;background:linear-gradient(150deg,#fff,#DDF2F8);box-shadow:0 20px 38px -16px rgba(7,71,90,.45),inset 0 0 0 3px rgba(14,134,176,.45);display:grid;place-items:center}
.kk{left:270px;top:56px;font-size:26px;font-weight:700;color:#fff;background:linear-gradient(135deg,#1AA9CC,#0E7F9E);border-radius:999px;padding:3px 24px 5px}
h1{left:270px;top:108px;font-size:56px;line-height:1.12;font-weight:700;white-space:nowrap}h1 em{font-style:normal;color:#0E86B0}
.sub{left:270px;top:188px;font-size:28px;color:#2F6B7A;white-space:nowrap}
.names{left:270px;top:246px;font-size:22px;font-weight:700;color:#0E6B88;width:420px;line-height:1.5}
.blob{left:560px;top:-170px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(26,169,204,.3),transparent 70%)}
""", f'''{dots("rgba(14,134,176,.6)",.14)}<div class="abs blob"></div><div class="abs plate">{ic('হাদিস শরিফ', 142)}</div>
<div class="abs kk">হাদিস শরিফ</div><h1 class="abs">সিহাহ সিত্তার <em>৬ কিতাব</em></h1><div class="abs sub">কিতাব, অধ্যায় ও বুকমার্ক সহ সহজে পড়ুন</div>
<div class="abs names">বুখারী · মুসলিম · তিরমিযী<br>আবু দাউদ · নাসাঈ · ইবনে মাজাহ</div>
<div class="abs shelf"></div><div class="abs books">{sp}</div>''')

# ৫: বেগুনি — চার আইকন + দোয়া আসছে
def tile(n, x, y, r):
    return f'<div class="abs" style="left:{x}px;top:{y}px;width:124px;height:124px;border-radius:38px;background:linear-gradient(150deg,#fff,#EAEBFF);display:grid;place-items:center;transform:rotate({r}deg);box-shadow:0 18px 30px -14px rgba(52,40,140,.5),inset 0 0 0 3px rgba(98,84,220,.35)">{ic(n, 92)}</div>'
page('ad5', 1200, H, """
body{background:linear-gradient(110deg,#F6F5FF,#E4E3FC 55%,#CDCBF6);color:#2A2169}
.kk{left:360px;top:66px;font-size:26px;font-weight:700;color:#fff;background:linear-gradient(135deg,#6C5CE0,#3E2FB0);border-radius:999px;padding:3px 24px 5px}
h1{left:360px;top:118px;font-size:52px;line-height:1.12;font-weight:700;white-space:nowrap}h1 em{font-style:normal;color:#5B49D6}
.sub{left:360px;top:200px;font-size:28px;color:#51489A;white-space:nowrap}
.soon{right:40px;top:34px;width:240px;height:208px;border-radius:38px;background:linear-gradient(160deg,#FFF6D8,#F8E2A0);border:4px dashed rgba(184,116,15,.65);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:#6B4408;box-shadow:0 20px 36px -18px rgba(138,90,18,.6)}
.soon b{font-size:60px;line-height:1.1}.soon span{font-size:28px;font-weight:700;background:#fff;border-radius:999px;padding:3px 22px 5px;color:#B8610F}
.soon i{position:absolute;right:-14px;top:-18px;font-style:normal;font-size:24px;font-weight:700;color:#fff;background:linear-gradient(135deg,#E0502C,#B02A12);border-radius:999px;padding:3px 20px 5px;transform:rotate(8deg)}
.orb{left:-120px;bottom:-200px;width:480px;height:480px;border-radius:50%;background:radial-gradient(circle,rgba(108,92,224,.28),transparent 70%)}
""", f'''{dots("rgba(98,84,220,.6)",.15)}<div class="abs orb"></div>{tile('আমলের রিপোর্ট',40,44,-6)}{tile('ডিজিটাল তাসবিহ',184,44,5)}{tile('কিবলা কম্পাস',40,186,4)}{tile('হোম স্ক্রীন উইজেট',184,186,-5)}
<div class="abs kk">আরও অনেক কিছু</div><h1 class="abs">আমল, তাসবিহ, কিবলা <em>ও উইজেট</em></h1><div class="abs sub">সামনে আসছে আরও ফিচার, ইনশা আল্লাহ</div>
<div class="abs soon"><i>নতুন</i><b>দোয়া</b><span>শীঘ্রই আসছে</span></div>''')

# ---- নিচের ফিক্সড বিজ্ঞাপন ১২০০×৪৫০ ----
feat = ['নামাজের সময়', 'কুরআন শরিফ', 'হাদিস শরিফ', 'আমলের রিপোর্ট', 'ডিজিটাল তাসবিহ', 'কিবলা কম্পাস', 'হোম স্ক্রীন উইজেট']
ficons = ''.join(f'<div style="width:112px;height:112px;border-radius:32px;background:linear-gradient(150deg,#fff,#E4EEFF);display:grid;place-items:center;box-shadow:0 14px 24px -12px rgba(0,32,94,.45),inset 0 0 0 2px rgba(35,95,254,.3)">{ic(n, 82)}</div>' for n in feat)
page('ad6', 1200, 450, """
body{background:linear-gradient(120deg,#F6F9FF,#DDE9FC 50%,#BFD6F8);color:#00205E}
.plate{left:56px;top:50px;width:230px;height:230px;border-radius:50%;background:#fff;box-shadow:0 22px 44px -18px rgba(0,32,94,.5),inset 0 0 0 3px rgba(35,95,254,.4)}
.plate svg{width:230px;height:230px;border-radius:50%}
.ring{left:32px;top:26px;width:278px;height:278px;border-radius:50%;border:3px dashed rgba(201,133,22,.55)}
.kk{left:350px;top:26px;font-size:30px;font-weight:700;color:#8A5A12;background:linear-gradient(135deg,#FFF3CF,#F4DDA0);border:2px solid rgba(201,138,43,.6);border-radius:999px;padding:3px 26px 5px}
h1{left:350px;top:74px;font-size:100px;line-height:1.1;font-weight:700;white-space:nowrap}h1 em{font-style:normal;color:#235FFE}
.sub{left:350px;top:190px;font-size:32px;color:#3A4A73;white-space:nowrap}
.url{left:350px;top:246px;font-size:34px;font-weight:700;color:#235FFE}
.cta{right:58px;top:236px;display:flex;align-items:center;gap:12px;font-size:36px;font-weight:700;color:#fff;background:linear-gradient(135deg,#235FFE,#00205E);border-radius:999px;padding:12px 38px 14px;box-shadow:0 20px 36px -14px rgba(0,32,94,.7)}
.row{left:56px;right:56px;bottom:24px;display:flex;justify-content:space-between}
.orb{right:-120px;top:-200px;width:520px;height:520px;border-radius:50%;background:radial-gradient(circle,rgba(35,95,254,.3),transparent 70%)}
.sky{right:0;bottom:0;width:640px;height:150px}
""", f'''{dots("rgba(35,95,254,.5)",.18)}<div class="abs orb"></div>
<svg class="abs sky" viewBox="0 0 430 64" preserveAspectRatio="none"><g fill="#235FFE" fill-opacity=".13"><path d="M150 64V30C150 8 215 8 215 30V64z"/><rect x="80" y="14" width="9" height="50"/><path d="M80 14L84.5 0L89 14z"/><rect x="341" y="14" width="9" height="50"/><path d="M341 14L345.5 0L350 14z"/><path d="M110 64V44C110 30 134 30 134 44V64z"/><path d="M296 64V44C296 30 320 30 320 44V64z"/></g></svg>
<div class="abs ring"></div><div class="abs plate">{logo}</div>
<div class="abs kk">পাথেয় বাই গুঞ্জরণ</div><h1 class="abs">আজই <em>ডাউনলোড</em> করুন</h1>
<div class="abs sub">নামাজ · কুরআন · হাদিস · আমল · তাসবিহ · কিবলা · উইজেট</div><div class="abs url">patheyobygunjoron.github.io</div>
<div class="abs cta">অ্যাপ নিন{chev(36)}</div>
<div class="abs row">{ficons}</div>''')
