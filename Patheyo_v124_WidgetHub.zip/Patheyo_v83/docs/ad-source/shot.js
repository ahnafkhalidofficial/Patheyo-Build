const { chromium } = require('/opt/npm-tools/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox','--allow-file-access-from-files'] });
  const ctx = await b.newContext({ viewport: { width: 1200, height: 350 }, deviceScaleFactor: 1 });
  const p = await ctx.newPage();
  for (let i = 1; i <= 6; i++) {
    await p.goto('file://' + __dirname + `/ad${i}.html`); await p.waitForTimeout(600);
    await p.setViewportSize({width:1200,height:i===6?450:350}); await p.screenshot({ path: __dirname + `/ad${i}.png`, clip: { x: 0, y: 0, width: 1200, height: i===6?450:350 } });
  }
  await b.close();
})();
