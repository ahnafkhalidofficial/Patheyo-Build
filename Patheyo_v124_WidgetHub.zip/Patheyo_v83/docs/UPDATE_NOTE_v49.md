# v49 — ওয়েবসাইট ↔ অ্যাপ সংযোগ (versionCode 6 / versionName 1.6.0)

নতুন ফাইল: stats/BackendConfig.kt, stats/AppHeartbeat.kt, res/values/update_v49_strings.xml, UPDATE_JSON_TEMPLATE_v49.json
বদলানো: update/UpdateInfo, UpdateChecker, UpdatePrefs, UpdateManager, PatheyoMessagingService, PatheyoApp, MainActivity, app/build.gradle.kts
(কোনো ডিজাইন/লেআউট/ফাংশন মোছা বা বদলানো হয়নি — সব নতুন কাজ আলাদা try-catch-এ, ব্যর্থ হলে অ্যাপ আগের মতোই চলে।)

## কী যোগ হলো
1. **ওয়েবসাইটের “অ্যাপ আপডেট করুন” বাটন** → `patheyo://update` লিংকে অ্যাপ খোলে এবং সাথে সাথে আপডেট চেক করে: নতুন ভার্সন থাকলে আপডেট পপআপ, না থাকলে “সর্বশেষ ভার্সনেই আছেন” বার্তা (দিনে-২বারের সীমা এখানে খাটে না)।
2. **ইউজার/ভার্সন গণনা** → অ্যাপ সামনে থাকলে ~৫ মিনিটে, ব্যাকগ্রাউন্ডে ১২ ঘণ্টায় একবার বেনামী সংকেত (আইডি, ভার্সন, ফোনের মডেল, অ্যান্ড্রয়েড) পাঠায়। `BackendConfig.kt`-এ URL/key না বসালে কিছুই পাঠায় না।
3. **আপডেট-নোটিফিকেশন** → FCM `update_type=app_update` পুশ (GitHub Release/অ্যাডমিন প্যানেল থেকে) এলে “নতুন আপডেট” নোটিফিকেশন; ট্যাপ করলে অ্যাপ খুলে আপডেট পপআপ।
4. **আপডেটারের নতুন সূত্র** → আগের `docs/update.json`-এর পাশাপাশি `patheyo/data/update.json` (GitHub Action নিজে বানায়) — যেটা নতুন সেটাই ধরে। versionCode না থাকলে versionName (1.6.0) মিলিয়ে তুলনা।
5. **ভার্সন-টপিক** (`ver_1_6_0`) → অ্যাডমিন প্যানেল থেকে শুধু নির্দিষ্ট ভার্সনের ইউজারকে নোটিফিকেশন পাঠানোর জন্য।

## আপনাকে যা করতে হবে
- `stats/BackendConfig.kt`-এ Supabase URL ও anon key বসান (ওয়েবসাইটের config.js-এর হুবহু একই)।
- ধাপে ধাপে পুরো নির্দেশিকা: ওয়েবসাইট প্যাকের `patheyo/SETUP-BANGLA.md`।
- নতুন ভার্সনের ট্যাগ = `v` + versionName (যেমন `v1.6.0`)।
