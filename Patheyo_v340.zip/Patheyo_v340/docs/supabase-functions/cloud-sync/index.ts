// Supabase Edge Function: cloud-sync  (পাথেয় v185, v200: meta, v340: ওপরে-লেখা ঠেকানো + আগের সংস্করণ রাখা)
// কাজ: Firebase-এ সাইন-ইন করা ইউজারের ব্যাকআপ Supabase-এর user_backups টেবিলে রাখা / আনা / মোছা।
// নিরাপত্তা: অ্যাপ পাঠায় Firebase ID টোকেন (x-firebase-token হেডারে)। এখানে Google-এর পাবলিক কী দিয়ে সেটা যাচাই
// করে uid নেওয়া হয় — তাই কেউ অন্যের uid দিয়ে অন্যের ডেটা পড়তে/লিখতে পারে না।
// service_role কী Supabase নিজেই এই ফাংশনে বসিয়ে দেয় (SUPABASE_SERVICE_ROLE_KEY); অ্যাপে কখনো যায় না।
import { createClient } from "npm:@supabase/supabase-js@2";
import { createRemoteJWKSet, jwtVerify } from "npm:jose@5";

const PROJECT_ID = Deno.env.get("FIREBASE_PROJECT_ID") ?? "hijri-tarikh";
const JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"),
);
const db = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } },
);
const MAX = 4_000_000;
const DAY = 24 * 60 * 60 * 1000;
const KEEP_DAILY = 4;   // প্রতি ইউজারে সর্বশেষ ৪টি দৈনিক কপি
const KEEP_SHRINK = 2;  // + "হঠাৎ ছোট হয়ে যাওয়ার" আগের সর্বশেষ ২টি কপি
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-firebase-token",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...CORS, "Content-Type": "application/json" } });

async function uidFrom(req: Request): Promise<string | null> {
  const tok = req.headers.get("x-firebase-token");
  if (!tok) return null;
  try {
    const { payload } = await jwtVerify(tok, JWKS, {
      issuer: `https://securetoken.google.com/${PROJECT_ID}`,
      audience: PROJECT_ID,
    });
    return typeof payload.sub === "string" && payload.sub.length > 0 ? payload.sub : null;
  } catch (_) {
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ ok: false, msg: "POST দিন" }, 405);

  const uid = await uidFrom(req);
  if (!uid) return json({ ok: false, msg: "সাইন-ইন যাচাই হয়নি" }, 401);

  let body: { action?: string; data?: unknown; device?: unknown; base?: unknown; id?: unknown };
  try { body = await req.json(); } catch (_) { return json({ ok: false, msg: "ভুল অনুরোধ" }, 400); }

  if (body.action === "load") {
    const { data, error } = await db.from("user_backups")
      .select("data, device, updated_at").eq("uid", uid).maybeSingle();
    if (error) return json({ ok: false, msg: error.message }, 500);
    if (!data) return json({ ok: true, empty: true });
    return json({ ok: true, empty: false, data: data.data, device: data.device ?? "", at: Date.parse(data.updated_at) });
  }

  // v200: রিয়েল-টাইম পরীক্ষার হালকা কল — ডেটা ছাড়া শুধু শেষ বদলের সময়
  if (body.action === "meta") {
    const { data, error } = await db.from("user_backups")
      .select("device, updated_at").eq("uid", uid).maybeSingle();
    if (error) return json({ ok: false, msg: error.message }, 500);
    if (!data) return json({ ok: true, empty: true });
    return json({ ok: true, empty: false, device: data.device ?? "", at: Date.parse(data.updated_at) });
  }

  if (body.action === "save") {
    if (typeof body.data !== "string" || body.data.length === 0) return json({ ok: false, msg: "ডেটা নেই" }, 400);
    if (body.data.length > MAX) return json({ ok: false, msg: "ডেটা অনেক বড়" }, 413);
    const device = typeof body.device === "string" ? body.device.slice(0, 80) : "";
    const hasBase = typeof body.base === "number" && Number.isFinite(body.base);

    const cur = await db.from("user_backups").select("data, device, updated_at").eq("uid", uid).maybeSingle();
    if (cur.error) return json({ ok: false, msg: cur.error.message }, 500);
    const old = cur.data;

    // v340 (১) অন্য ফোন এর মধ্যে লিখে থাকলে ওপরে লেখা নয় — অ্যাপ দুই হিসাব মিলিয়ে আবার পাঠাবে
    if (old && hasBase && Date.parse(old.updated_at) > (body.base as number)) {
      return json({ ok: false, conflict: true, at: Date.parse(old.updated_at) }, 409);
    }

    // v340 (২) আগের সংস্করণ রেখে দেওয়া — যেকোনো ভুলের পরেও ফেরানো যায়।
    //   • শেষ কপির পর ২৪ ঘণ্টা পেরোলে (অর্থাৎ দিনে সর্বোচ্চ একটি), অথবা
    //   • নতুন হিসাব হঠাৎ অনেক ছোট হলে (৬০%-এর নিচে — হিসাব মুছে যাওয়ার লক্ষণ) সাথে সাথে।
    //   টেবিল (user_backup_history) না থাকলে বা কপি ব্যর্থ হলে সেভ আটকায় না।
    if (old && old.data !== body.data) {
      try {
        const last = await db.from("user_backup_history").select("created_at")
          .eq("uid", uid).order("created_at", { ascending: false }).limit(1).maybeSingle();
        if (!last.error) {
          const shrink = old.data.length > 1500 && body.data.length < old.data.length * 0.6;
          const due = !last.data || Date.now() - Date.parse(last.data.created_at) > DAY;
          if (shrink || due) {
            await db.from("user_backup_history").insert({
              uid, data: old.data, device: old.device ?? "", saved_at: old.updated_at, reason: shrink ? "shrink" : "daily",
            });
            // পুরনো কপি ছাঁটা: সাধারণ কপি সর্বশেষ KEEP_DAILY টি, "হঠাৎ ছোট" কপি সর্বশেষ KEEP_SHRINK টি
            for (const [reason, keep] of [["daily", KEEP_DAILY], ["shrink", KEEP_SHRINK]] as const) {
              const ids = await db.from("user_backup_history").select("id")
                .eq("uid", uid).eq("reason", reason).order("created_at", { ascending: false }).range(keep, keep + 50);
              if (!ids.error && ids.data && ids.data.length) {
                await db.from("user_backup_history").delete().in("id", ids.data.map((r: { id: number }) => r.id));
              }
            }
          }
        }
      } catch (_) { /* ইতিহাস রাখা না গেলেও সেভ চলবে */ }
    }

    // v340 (৩) লেখা — শর্তসহ, যাতে একই মুহূর্তে দুই ফোন লিখলে একটিই জেতে, অন্যটি conflict পায়
    const now = new Date();
    const row = { uid, data: body.data, device, updated_at: now.toISOString() };
    if (old) {
      const up = await db.from("user_backups").update(row).eq("uid", uid).eq("updated_at", old.updated_at).select("uid");
      if (up.error) return json({ ok: false, msg: up.error.message }, 500);
      if (!up.data || up.data.length === 0) {
        if (hasBase) return json({ ok: false, conflict: true, at: 0 }, 409);
        const up2 = await db.from("user_backups").upsert(row);        // পুরনো অ্যাপ (base পাঠায় না) — আগের মতোই
        if (up2.error) return json({ ok: false, msg: up2.error.message }, 500);
      }
    } else {
      const ins = await db.from("user_backups").insert(row);
      if (ins.error) {
        if (ins.error.code === "23505" && hasBase) return json({ ok: false, conflict: true, at: 0 }, 409);   // এই মুহূর্তে অন্য ফোন সারি বানিয়েছে
        const up2 = await db.from("user_backups").upsert(row);
        if (up2.error) return json({ ok: false, msg: up2.error.message }, 500);
      }
    }
    return json({ ok: true, at: now.getTime(), guard: true });
  }

  // v340: আগের সংস্করণগুলোর তালিকা (ডেটা ছাড়া)
  if (body.action === "history") {
    const { data, error } = await db.from("user_backup_history")
      .select("id, device, saved_at, created_at, reason").eq("uid", uid).order("created_at", { ascending: false }).limit(30);
    if (error) return json({ ok: false, msg: error.message }, 500);
    return json({ ok: true, list: (data ?? []).map((r) => ({ id: r.id, device: r.device ?? "", at: Date.parse(r.saved_at), kept: Date.parse(r.created_at), reason: r.reason })) });
  }

  // v340: আগের একটি সংস্করণ পড়া (শুধু নিজের)
  if (body.action === "version") {
    const id = Number(body.id);
    if (!Number.isFinite(id)) return json({ ok: false, msg: "ভুল অনুরোধ" }, 400);
    const { data, error } = await db.from("user_backup_history")
      .select("data, device, saved_at").eq("uid", uid).eq("id", id).maybeSingle();
    if (error) return json({ ok: false, msg: error.message }, 500);
    if (!data) return json({ ok: true, empty: true });
    return json({ ok: true, empty: false, data: data.data, device: data.device ?? "", at: Date.parse(data.saved_at) });
  }

  if (body.action === "delete") {
    const { error } = await db.from("user_backups").delete().eq("uid", uid);
    if (error) return json({ ok: false, msg: error.message }, 500);
    try { await db.from("user_backup_history").delete().eq("uid", uid); } catch (_) { /* টেবিল না থাকলে */ }
    return json({ ok: true });
  }

  return json({ ok: false, msg: "অজানা কাজ" }, 400);
});
