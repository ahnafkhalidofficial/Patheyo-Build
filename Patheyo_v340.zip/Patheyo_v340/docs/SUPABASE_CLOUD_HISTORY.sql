-- =====================================================================
-- পাথেয় v340 — ক্লাউড ব্যাকআপের "আগের সংস্করণ" (একবারই চালাতে হবে)
-- Supabase Dashboard → SQL Editor → New query → পুরোটা পেস্ট → Run        (দুবার চালালেও সমস্যা নেই)
--
-- cloud-sync ফাংশন (v340) প্রতিটি অ্যাকাউন্টের হিসাব বদলানোর আগে পুরনো হিসাবের একটা কপি এখানে রাখে:
--   • দিনে সর্বোচ্চ একটি ("daily") — সর্বশেষ ৪টি থাকে
--   • হিসাব হঠাৎ অনেক ছোট হয়ে গেলে সাথে সাথে ("shrink") — সর্বশেষ ২টি থাকে
-- নিরাপত্তা user_backups-এর মতোই: RLS চালু, কোনো policy নেই, anon/authenticated-এর কোনো অনুমতি নেই — শুধু Edge Function ঢুকতে পারে।
-- =====================================================================

create table if not exists public.user_backup_history (
  id          bigint generated always as identity primary key,
  uid         text not null,
  data        text not null,
  device      text,
  saved_at    timestamptz not null,               -- এই হিসাবটা ক্লাউডে কখন লেখা হয়েছিল
  reason      text not null default 'daily',      -- 'daily' | 'shrink'
  created_at  timestamptz not null default now()  -- কপিটা কখন রাখা হলো
);

create index if not exists user_backup_history_uid_idx on public.user_backup_history (uid, created_at desc);

alter table public.user_backup_history enable row level security;
revoke all on table public.user_backup_history from anon, authenticated;


-- =====================================================================
-- কাজে লাগবে এমন কোয়েরি (দরকার হলে একটা একটা করে চালান)
-- =====================================================================

-- ক) কত জায়গা লাগছে (ফ্রি সীমা: ডেটাবেস ৫০০MB)
-- select pg_size_pretty(pg_total_relation_size('public.user_backups'))        as backups,
--        pg_size_pretty(pg_total_relation_size('public.user_backup_history')) as history,
--        (select count(*) from public.user_backups)                           as users,
--        pg_size_pretty(pg_database_size(current_database()))                 as whole_database;

-- খ) একজন ইউজারের এখনকার ও আগের সংস্করণগুলো (uid = Firebase Authentication → Users → User UID)
-- select 'current' as kind, null::bigint as id, device, updated_at as saved_at, length(data) as size from public.user_backups where uid = 'UID_এখানে'
-- union all
-- select reason, id, device, saved_at, length(data) from public.user_backup_history where uid = 'UID_এখানে'
-- order by saved_at desc;

-- গ) আগের একটি সংস্করণ ফিরিয়ে আনা (id = ওপরের তালিকা থেকে)। এখনকার হিসাবটাও আগে ইতিহাসে রেখে দেওয়া হয়।
--    চালানোর পর ইউজারের ফোনে ১ মিনিটের মধ্যে (বা অ্যাপ খুললে) নিজে থেকে ফিরে আসবে।
-- with keep as (
--   insert into public.user_backup_history (uid, data, device, saved_at, reason)
--   select uid, data, device, updated_at, 'shrink' from public.user_backups where uid = 'UID_এখানে'
-- )
-- update public.user_backups b
--    set data = h.data, device = 'admin-restore', updated_at = now()
--   from public.user_backup_history h
--  where h.id = 123 and h.uid = 'UID_এখানে' and b.uid = h.uid;
