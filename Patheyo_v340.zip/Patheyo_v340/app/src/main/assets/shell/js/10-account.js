/* =============================================================================
   ধাপ ৯ — অ্যাকাউন্ট ও ক্লাউড সিঙ্ক
   নেটিভ: PatheyoAuth (app/.../auth/AuthBridge.kt) — Google (Credential Manager) + ইমেইল, Firebase Auth,
          ক্লাউড (v185 থেকে) = Supabase user_backups, Edge Function cloud-sync দিয়ে (Firebase টোকেন যাচাই করে শুধু নিজের সারি)।
   ওয়েব:  প্রোফাইল বাটন / সেটিংস → অ্যাকাউন্ট কেন্দ্র (#pf-sheet, মাঝখানের পপআপ)।
   সিঙ্ক: সেটিংসের ব্যাকআপ-ফাইলের একই লেখা (window.__ptBackup)।
          • সাইন-ইন করলেই ক্লাউডে হিসাব থাকলে নিজে থেকে ফিরে আসে (প্রশ্ন করে না; আগের অবস্থা সেটিংসের \"রিস্টোর বাতিল\"-এ থাকে)।
          • ডেটা বদলালে/মুছলে ~৬ সেকেন্ড পরে নিজে থেকে ক্লাউডে (মুছলে ক্লাউড থেকেও মুছে যায়, কারণ পুরো হিসাব একসাথে বদলায়)।
          • অ্যাপ পেছনে গেলে ও প্রতি ২ মিনিটে (বদল থাকলে) নিশ্চিন্ত করার জন্য।
          • অন্য ফোনে ক্লাউড বদলে থাকলে, এই ফোনে নিজের বদল না থাকলে অ্যাপ খুললে সেটি নিজে থেকে চলে আসে।
          এই ফোনের অল্প ডেটা দিয়ে ক্লাউডের পুরনো হিসাব নিজে থেকে কখনো মোছে না।
   সাইন-ইন ঐচ্ছিক — অতিথি হিসেবে সব কাজ চলে।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window;
  var A = function () { return W.PatheyoAuth || null; };
  var GM = 'pt_google_mode';                 /* 'web' = Google সাইন-ইন সরাসরি ব্রাউজারে (শিট কাজ না করা ফোনে) */
  var CK = 'pt_cloud';                       /* {uid, on, at, fp, hold} — এই ফোনের সিঙ্কের অবস্থা (ব্যাকআপে যায় না) */
  var $ = function (id) { return D.getElementById(id); };
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(x) { return String(x).replace(/\d/g, function (d) { return BN[d]; }); }
  function jget(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function jset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function toast(t, type) { if (W.PT) PT.toast(t, { type: type || '' }); }

  var sheet = $('pf-sheet');
  if (!sheet) return;

  /* ---------------------------------------------------------------- নেটিভ কল (Promise) */
  var seq = 0, wait = {};
  W.__ptAuthCb = function (id, json) {
    var f = wait[id]; if (!f) return; delete wait[id];
    var r; try { r = JSON.parse(json); } catch (e) { r = { ok: false, msg: 'কাজটি সম্পন্ন করা যায়নি' }; }
    if (r && r.state) S = r.state;
    f(r);
  };
  function call(fn) {
    var args = [].slice.call(arguments, 1);
    return new Promise(function (res) {
      var a = A(); if (!a || typeof a[fn] !== 'function') { res({ ok: false, code: 'na', msg: 'এই সুবিধা শুধু অ্যাপের ভেতরে কাজ করে।' }); return; }
      var id = 'a' + (++seq); wait[id] = res;
      /* v193: সাইন-ইনের উত্তর ২ মিনিটে না এলে বাটন আটকে থাকে না — বার্তা দেখিয়ে ছাড়ে */
      if (fn === 'google' || fn === 'googleWeb' || fn === 'emailIn' || fn === 'emailUp') setTimeout(function () { var f = wait[id]; if (f) { delete wait[id]; f({ ok: false, code: 'timeout', msg: 'সাড়া পাওয়া যায়নি। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।' }); } }, 120000);
      try { a[fn].apply(a, [id].concat(args)); } catch (e) { delete wait[id]; res({ ok: false, msg: 'কাজটি সম্পন্ন করা যায়নি' }); }
    });
  }
  var lastOk = 0;   /* v200: ক্লাউডের সাথে শেষ সফল মিল/সেভ (মেমরিতে) */
  var S = { signedIn: false };
  function readState() { try { var a = A(); if (a && a.state) S = JSON.parse(a.state()) || S; } catch (e) {} return S; }
  W.__ptAuthChanged = function (json) { try { S = JSON.parse(json); } catch (e) {} paintAll(); };

  /* ---------------------------------------------------------------- দেখানো */
  var view = 'guest', mode = 'in', busy = false;
  function show(v) {
    view = v; sheet.setAttribute('data-view', v);
    [].forEach.call(sheet.querySelectorAll('.ac-pane'), function (p) { p.hidden = (' ' + p.getAttribute('data-v') + ' ').indexOf(' ' + v + ' ') < 0; });
    var t = { guest: 'আপনার অ্যাকাউন্ট', email: 'ইমেইল দিয়ে', user: 'আমার অ্যাকাউন্ট', local: 'নাম ও ছবি', del: 'অ্যাকাউন্ট মোছা' }[v];
    $('pf-title').textContent = t || 'আপনার অ্যাকাউন্ট';
    sheet.querySelector('.ac-back').hidden = !(v === 'email' || v === 'local' || v === 'del');
    sheet.querySelector('.ac-back').setAttribute('data-ac-go', v === 'del' ? 'user' : 'guest');
    if (v === 'email') { var sg = sheet.querySelector('.ac-seg'); if (sg && W.PT) PT.seg(sg); setMode(mode); }
    if (v === 'user' || v === 'local') { if (W.__ptProfileFill) W.__ptProfileFill(); }
    if (v === 'del') { $('ac-del-err').hidden = true; $('ac-del-pass').value = ''; }
    errOff();
  }
  function setMode(m) {
    mode = m; sheet.setAttribute('data-mode', m);
    $('ac-submit').textContent = m === 'up' ? 'অ্যাকাউন্ট খুলুন' : 'সাইন-ইন করুন';
    $('ac-pass').setAttribute('autocomplete', m === 'up' ? 'new-password' : 'current-password');
    errOff();
  }
  function err(t, id) { var e = $(id || 'ac-err'); if (!e) return; e.textContent = t; e.hidden = !t; if (t && W.PT) PT.haptic('warn'); }
  function errOff() { err('', 'ac-err'); gerr(''); }
  /* v193: Google-এর ব্যর্থতা বাটনের নিচেই লেখা দেখায় — আগে চুপচাপ কেটে যেত */
  function gerr(t, more) { var e = $('ac-gerr'); if (!e) return; e.textContent = t || ''; e.hidden = !t; var w = $('ac-gweb'); if (w) w.hidden = !(t && more); if (t && W.PT) PT.haptic('warn'); }
  function setBusy(b, btn) {
    busy = b; sheet.classList.toggle('is-busy', b);
    if (btn) { btn.disabled = b; btn.classList.toggle('is-loading', b); }
  }

  function provLabel(s) { return s.provider === 'google' ? 'Google' : 'ইমেইল'; }
  function fmtAgo(ms) {
    if (!ms) return '';
    var d = Math.round((Date.now() - ms) / 60000);
    if (d < 1) return 'এইমাত্র'; if (d < 60) return bn(d) + ' মিনিট আগে';
    var h = Math.round(d / 60); if (h < 24) return bn(h) + ' ঘণ্টা আগে';
    var dt = new Date(ms); return bn(dt.getDate()) + ' ' + ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'][dt.getMonth()];
  }
  function paintUser() {
    if (!S.signedIn) return;
    $('ac-mail').textContent = S.email || '';
    var pv = $('ac-prov'); pv.innerHTML = (W.PT ? PT.icon(S.provider === 'google' ? 'google' : 'mail', 'pt-ic--sm') : '') + provLabel(S);
    $('ac-verify').hidden = !!S.verified;
    var c = jget(CK) || {};
    $('ac-auto').checked = c.on !== false;
    var lt = Math.max(c.uid === S.uid && c.at || 0, lastOk);
    var pend = !(c.uid === S.uid && c.at);   /* v339: ক্লাউডের সাথে প্রথম মিল এখনো হয়নি */
    if (pend && c.on !== false && !c.hold) lt = 0;
    $('ac-last').textContent = pend && c.hold ? 'ক্লাউডের হিসাব পড়া যায়নি — ক্লাউড অক্ষত আছে; সুইচ বন্ধ করে আবার চালু করলে আবার চেষ্টা হবে' : pend && c.on !== false && fsTry ? 'ক্লাউডের হিসাব আনা যায়নি — আবার চেষ্টা হচ্ছে…' : c.hold ? 'বিরতি — সুইচ আবার চালু করলে শুরু হবে' : (c.on === false ? 'বন্ধ — চালু করলে সব ফোনে নিজে থেকে মিলবে' : (lt ? 'রিয়েল-টাইম চালু · শেষ মিল: ' + fmtAgo(lt) : 'সিঙ্ক শুরু হচ্ছে…'));
    $('ac-last').setAttribute('data-st', c.hold ? 'hold' : (c.on !== false && lt ? 'ok' : 'none'));
    sheet.classList.toggle('ac-email-user', S.provider !== 'google');
    paintPrem();
  }
  /* v278: অ্যাকাউন্ট পপআপের প্রিমিয়াম লাইন — অবস্থা অনুযায়ী লেখা */
  function paintPrem() {
    var row = $('ac-prem'); if (!row) return;
    var P = {}; try { if (W.PatheyoPremium) P = JSON.parse(W.PatheyoPremium.state()) || {}; } catch (e) {}
    var t = $('ac-prem-t'), s = $('ac-prem-s'), g = $('ac-prem-go');
    row.classList.toggle('is-on', !!P.active);
    if (P.active) {
      t.textContent = 'প্রিমিয়াম সদস্য';
      if (P.plan === 'lifetime') s.textContent = 'আজীবন · জাযাকাল্লাহু খাইরান';
      else { var d = new Date(P.until || 0); s.textContent = P.until ? 'মেয়াদ ' + bn(d.getDate()) + ' ' + ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'][d.getMonth()] + ' ' + bn(d.getFullYear()) + ' পর্যন্ত' : 'বিজ্ঞাপন ছাড়া পাথেয় চালু আছে'; }
      g.textContent = 'বিস্তারিত';
    } else if (P.had) { t.textContent = 'প্রিমিয়ামের মেয়াদ শেষ'; s.textContent = 'নবায়ন করলে আবার বিজ্ঞাপন ছাড়া'; g.textContent = 'নবায়ন'; }
    else { t.textContent = 'পাথেয় প্রিমিয়ামে যান'; s.textContent = 'বিজ্ঞাপন ছাড়া, আরও সুন্দর পাথেয়'; g.textContent = 'দেখুন'; }
  }
  W.addEventListener('pt:premium', function () { paintPrem(); });
  function paintSettings() {
    var t = $('st-acc-t'), s = $('st-acc-s'), img = $('st-acc-img'); if (!t) return;
    var p = jget('pt_profile') || {};
    if (S.signedIn) {
      t.textContent = p.name || S.name || 'আমার অ্যাকাউন্ট';
      var c = jget(CK) || {};
      s.textContent = (S.email || '') + (c.on !== false && !c.hold && (c.at || lastOk) ? ' · রিয়েল-টাইম সিঙ্ক' : '');
    } else { t.textContent = 'সাইন-ইন করুন'; s.textContent = 'স্বয়ংক্রিয় ক্লাউড ব্যাকআপ — নতুন ফোনেও সব ফিরে পাবেন'; }
    if (p.photo && String(p.photo).indexOf('data:') !== 0) p.photo = '';
    if (p.photo) { img.src = p.photo; img.hidden = false; } else { img.hidden = true; img.removeAttribute('src'); }
    var av = img.closest && img.closest('.st-acc__av'); if (av) av.classList.toggle('has-photo', !!p.photo);
    var hb = $('btn-profile'); if (hb) hb.classList.toggle('is-signed', !!S.signedIn);
  }
  function paintAll() {
    paintSettings();
    if (!sheet.hidden) { if (S.signedIn && (view === 'guest' || view === 'email')) show('user'); else if (!S.signedIn && (view === 'user' || view === 'del')) show('guest'); paintUser(); }
  }

  W.__ptAccountOpen = function () {
    if (!W.PT) return;
    readState();
    show(S.signedIn ? 'user' : 'guest'); paintUser();
    PT.sheet.open(sheet);
  };
  var _open = W.__ptAccountOpen; W.__ptAccountOpen = function () { _open(); baseH = hsh(photoNow()); };
  var row = $('st-acc-row'); if (row) row.addEventListener('click', W.__ptAccountOpen);

  /* ---------------------------------------------------------------- সাইন-ইনের পরে */
  /* v202: গুগলের ছবি → ফোনের প্রোফাইলে (ইউজারের নিজের ছবি না থাকলে) */
  function putPhoto(d, gp) {
    var q = jget('pt_profile') || {}; q.photo = d; if (gp) q.gp = 1; else delete q.gp; jset('pt_profile', q); baseH = hsh(d);   /* v340: gp = Google-এর ছবি (ক্লাউডে যায় না) */
    if (W.__ptPaintProfile) W.__ptPaintProfile(); paintSettings();
    if (!sheet.hidden && W.__ptProfileFill) W.__ptProfileFill(); pfDirty();
  }
  var gpBusy = false, gpTry = 0, avNone = '';   /* v339: avNone = এই uid-এর জন্য Storage-এ ছবি নেই বলে জানা গেছে */
  function googlePhoto() {
    if (!S.signedIn || !S.photo || photoNow() || gpBusy || gpTry >= 6) return;
    if ((jget('pt_profile') || {}).nogp) return;          /* ইউজার নিজে ছবি সরিয়েছেন — Google-এর ছবি আর নিজে থেকে বসে না */
    var uid = S.uid; gpBusy = true; gpTry++;
    call('photo').then(function (r) { gpBusy = false; if (r && r.ok && r.data && S.signedIn && S.uid === uid && !photoNow()) putPhoto(r.data, true); });
  }
  /* v202: লগআউটের পর আবার লগইনে ছবি গায়েব হওয়ার সমাধান — ক্লাউডের (Supabase avatars/{uid}.jpg) নিজের ছবি ফেরত আনা।
     ফোনে ছবি থাকলে বা নিজের মোছা/বদল ক্লাউডে যাওয়া বাকি থাকলে কিছু করে না। fallback = ক্লাউডে ছবি না থাকলে গুগলের ছবি। */
  var avLoading = false;
  function loadCloudAvatar(fallback) {
    if (!S.signedIn || avLoading || photoNow()) return;
    var d = jget(AVD); if (d && d.uid === S.uid) return;
    if (avNone === S.uid) { if (fallback) googlePhoto(); return; }   /* v339: Storage-এ নেই জানা — শুধু Google-এর ছবির চেষ্টা */
    var uid = S.uid; avLoading = true;
    call('downloadAvatar').then(function (r) {
      avLoading = false;
      if (!S.signedIn || S.uid !== uid || photoNow()) return;
      /* v272: AVM আগে বসে, তারপর ছবি — যাতে ক্লাউডের রূপ (শুধু চিহ্ন) এক মুহূর্তের জন্যও বদলে না যায় */
      if (r && r.ok && r.data) { jset(AVM, { uid: uid, h: hsh(r.data) }); try { localStorage.removeItem(AVW); } catch (e) {} putPhoto(r.data); }
      else if (r && r.ok) { avNone = uid; try { localStorage.removeItem(AVW); } catch (e) {} if (fallback) googlePhoto(); }   /* Storage-এ ছবি নেই — "নামানো বাকি" চিহ্ন আর রাখার মানে নেই */
    });
  }
  function adoptProfile(isNew) {
    var p = jget('pt_profile') || {};
    var changed = false;
    if (S.name && (!p.name || isNew)) { p.name = S.name; changed = true; }
    if (changed) { jset('pt_profile', p); if (W.__ptPaintProfile) W.__ptPaintProfile(); }
    if (!p.photo) loadCloudAvatar(true);
  }
  function afterSignIn(r, how) {
    S = r.state || readState();
    /* v339: নতুন করে সাইন-ইন মানেই ক্লাউড আগে দেখা। ফোনে পুরনো সিঙ্ক-চিহ্ন (pt_cloud) থেকে গেলে — যেমন রিইনস্টলের পর
       Android-এর নিজস্ব ব্যাকআপ পুরনো ডেটা ফিরিয়ে দিলে — সেটিতে ভরসা করে পুরনো হিসাব ক্লাউডের ওপর লেখা চলবে না। */
    var c0 = jget(CK); if (c0 && c0.uid === S.uid) jset(CK, { uid: S.uid, on: c0.on !== false });
    fsTry = 0; gpTry = 0; avNone = '';
    adoptProfile(r.isNew);
    show('user'); paintUser(); paintSettings();
    toast(how === 'up' ? 'অ্যাকাউন্ট খোলা হয়েছে — ইমেইল যাচাই করে নিন' : 'আসসালামু আলাইকুম' + (S.name ? ', ' + S.name.split(/\s+/)[0] : '') + '!', 'success');
    firstSync();
  }

  /* ---------------------------------------------------------------- প্রোফাইল ছবি → Supabase Storage (v184)
     বাকেট avatars, ফাইল {uid}.jpg, সর্বোচ্চ ১০০KB (09-home.js ছোট করে; নেটিভও আবার যাচাই করে)।
     শুধু ইউজার নিজে ছবি বদলে/সরিয়ে "সেভ" চাপলে আপলোড/মোছা — গুগলের ছবি নিজে থেকে যায় না।
     ইন্টারনেট না থাকলে "বাকি" থেকে যায়, পরে নিজে থেকে আবার চেষ্টা হয়। */
  var AVM = 'pt_avatar_up', AVD = 'pt_avatar_dirty', AVW = 'pt_avatar_want', baseH = '', avBusy = false;   /* AVW (v272): ক্লাউড-রিস্টোরের পর Storage থেকে ছবি নামানো বাকি */
  function hsh(s) { s = s || ''; var h = 5381; for (var i = 0; i < s.length; i += 7) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return s.length + ':' + h; }
  function photoNow() { var ph = (jget('pt_profile') || {}).photo || ''; return String(ph).indexOf('data:') === 0 ? ph : ''; }
  function syncAvatar(loud) {
    if (!S.signedIn || avBusy) return Promise.resolve();
    var d = jget(AVD); if (!d || d.uid !== S.uid) return Promise.resolve();
    var photo = photoNow(), want = photo ? hsh(photo) : '';
    avBusy = true;
    return (photo ? call('uploadAvatar', photo) : call('deleteAvatar')).then(function (r) {
      avBusy = false;
      if (r && r.ok) { try { localStorage.removeItem(AVD); } catch (e) {} jset(AVM, { uid: S.uid, h: want }); }
      else if (loud && r && r.code !== 'na') toast('ছবি ক্লাউডে রাখা যায়নি — ইন্টারনেট এলে নিজে থেকে আবার চেষ্টা হবে');
    });
  }

  /* ---------------------------------------------------------------- ক্লাউড সিঙ্ক
     v340 — "কোনো অবস্থাতেই হিসাব না হারানো"র নিয়ম:
       ১) এই অ্যাকাউন্টের ক্লাউড এই ফোনে একবার সফলভাবে দেখা না হলে ক্লাউডে কিছু লেখা হয় না (v339)।
       ২) লেখার আগে দেখা হয় ক্লাউড এর মধ্যে অন্য ফোন থেকে বদলেছে কি না (সার্ভার নিজেই base মিলিয়ে দেখে — cloud-sync v340;
          পুরনো ফাংশন হলে অ্যাপ আগে cloudMeta দিয়ে দেখে)। বদলে থাকলে ওপরে লেখা হয় না — দুই পাশের হিসাব মিলিয়ে (merge3) নেওয়া হয়।
       ৩) মিলিয়ে নেওয়ার ভিত্তি (BASE) = এই ফোন ক্লাউডের সাথে শেষ যে হিসাবে মিলেছিল — ফোনেই থাকে, ক্লাউডে যায় না।
       ৪) সার্ভার প্রতিটি অ্যাকাউন্টের আগের কয়েকটি সংস্করণ রেখে দেয় (user_backup_history) — ভুল হলেও ফেরানো যায়। */
  var B = function () { return W.__ptBackup || null; };
  var BASE = 'pt_cloud_base';
  function cloudState() { var c = jget(CK) || {}; if (c.uid !== S.uid) c = { uid: S.uid, on: true }; return c; }
  function setBase(d) { try { localStorage.setItem(BASE, JSON.stringify({ uid: S.uid, d: d })); } catch (e) { try { localStorage.removeItem(BASE); } catch (e2) {} } }
  function getBase() { var b = jget(BASE); return b && b.uid === S.uid && b.d && typeof b.d === 'object' ? b.d : null; }
  function typing() { var ae = D.activeElement; return !!(ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)); }
  function synced(c, fp, cat) { c.fp = fp; c.at = Date.now(); if (cat) c.cat = cat; c.hold = false; lastOk = Date.now(); jset(CK, c); paintUser(); paintSettings(); }

  var inflight = false, chT = 0, fsBusy = false, guardSrv = false, recBusy = false, applying = false;   /* applying = মেলানো হিসাব বসাতে অ্যাপ নতুন করে খুলছে — এই ফাঁকে (পুরনো অবস্থা) ক্লাউডে পাঠানো চলবে না */   /* guardSrv = সার্ভার নিজেই base মিলিয়ে দেখে (cloud-sync v340) */
  /** হিসাব (data) ক্লাউডে পাঠানো; base = ক্লাউডের যে সংস্করণের ওপর ভিত্তি করে পাঠানো হচ্ছে (০ = ক্লাউড ফাঁকা বলে জানা) */
  function send(data, base, c, force) {
    var a = A(), v2 = a && typeof a.cloudSaveV2 === 'function', fp = B().fpOf(data);
    return (v2 ? call('cloudSaveV2', B().pack(data), String(base || 0)) : call('cloudSave', B().pack(data))).then(function (r) {
      inflight = false;
      if (r && r.ok) { if (r.guard) guardSrv = true; setBase(data); synced(c, fp, r.at || Date.now()); return true; }
      if (r && r.code === 'conflict') return reconcile(force);      /* এর মধ্যে অন্য ফোন লিখেছে — ওপরে লেখা হয়নি; মিলিয়ে নেওয়া */
      return false;
    });
  }
  function push(force, first) {
    if (!S.signedIn || !B() || applying) return Promise.resolve(false);
    if (!force && fsBusy) return Promise.resolve(false);
    var c = cloudState();
    /* v339: ক্লাউড একবারও সফলভাবে দেখা না হলে (c.at নেই) কিছুই লেখা হয় না — জোর করে হলেও না। ব্যতিক্রম: firstSync, যখন সে নিশ্চিত জেনেছে ক্লাউড ফাঁকা। */
    if (!first && !c.at) { if (!fsBusy && !fsT && c.on !== false && !c.hold) firstSync(); return Promise.resolve(false); }
    if (!force && (c.on === false || c.hold)) return Promise.resolve(false);
    var data = B().data(), fp = B().fpOf(data);
    if (!force && fp === c.fp) return Promise.resolve(false);
    if (inflight || recBusy) { if (!force) onChange(); return Promise.resolve(false); }   /* আগের কাজ চলছে — একটু পরে আবার */
    inflight = true;
    /* পুরনো সার্ভার-ফাংশন base মিলিয়ে দেখে না — তাই লেখার আগে অ্যাপ নিজে দেখে নেয় ক্লাউড বদলেছে কি না */
    var pre = (first || guardSrv || !metaOK) ? Promise.resolve(null) : call('cloudMeta');
    return pre.then(function (m) {
      if (m && !m.ok) { if (m.code === 'nometa') metaOK = false; else { inflight = false; return false; } }   /* দেখা যায়নি → লেখা নয়, পরে আবার */
      if (m && m.ok && !m.empty && m.at > (c.cat || 0)) { inflight = false; return reconcile(force); }
      return send(data, first ? 0 : (c.cat || 0), c, force);
    });
  }
  /** ক্লাউড অন্য ফোন থেকে বদলেছে: ক্লাউডের হিসাব এনে এই ফোনের হিসাবের সাথে মিলিয়ে নেওয়া — কারও বদল মোছে না */
  function reconcile(force) {
    if (recBusy || applying || !S.signedIn || !B()) return Promise.resolve(false);
    recBusy = true; var uid = S.uid;
    return call('cloudLoad').then(function (r) {
      recBusy = false;
      if (!r || !r.ok || !S.signedIn || S.uid !== uid) return false;
      var c = cloudState();
      if (r.empty || !r.data) { c.cat = 0; jset(CK, c); inflight = true; return send(B().data(), 0, c, force); }   /* ক্লাউডের সারি নেই — এই ফোনেরটাই যায় */
      var cd = B().parse(r.data);
      if (!cd) { c.hold = true; jset(CK, c); paintUser(); toast('ক্লাউডের হিসাব পড়া যায়নি — ক্লাউডে কিছু বদলানো হয়নি', 'danger'); return false; }
      var local = B().data(), lf = B().fpOf(local), cf = B().fpOf(cd);
      if (lf === cf) { setBase(cd); synced(c, cf, r.at); return true; }
      var base = getBase() || (lf === c.fp ? local : {});
      var merged = B().merge3(base, local, cd, true, true), mf = B().fpOf(merged);
      if (mf === lf || force) { c.cat = r.at; jset(CK, c); inflight = true; return send(merged, r.at, c, force); }   /* এই ফোনে বসানোর কিছু নেই (বা সাইন-আউট হচ্ছে) — মেলানো হিসাব সরাসরি ক্লাউডে */
      if (typing()) return false;                                        /* লিখছেন — পরের বার */
      if (!B().applyData(merged)) { toast('ফোনে জায়গা কম — ক্লাউডের হিসাব বসানো যায়নি', 'danger'); return false; }
      applying = true;
      setBase(cd); c.cat = r.at; c.fp = cf; c.at = Date.now(); c.hold = false; jset(CK, c);   /* রিলোডের পর: মেলানো হিসাব ক্লাউডের থেকে আলাদা হলে নিজে থেকে পাঠানো হবে */
      toast(mf === cf ? 'অন্য ফোনের নতুন হিসাব আসছে…' : 'দুই ফোনের হিসাব মিলিয়ে নেওয়া হচ্ছে…', 'success');
      return false;
    });
  }
  /** ডেটা বদলালে (এই পেজে বা অন্য পেজে) আড়াই সেকেন্ড থেমে থাকলে ক্লাউডে পাঠাই */
  function onChange() {
    if (!S.signedIn) return;
    clearTimeout(chT); chT = setTimeout(function () { push(false); }, 2500);
  }
  try {
    var _si = Storage.prototype.setItem, _ri = Storage.prototype.removeItem;
    var mine = function (k) { return k === CK || k === AVM || k === AVD || k === BASE; };
    Storage.prototype.setItem = function (k) { var r = _si.apply(this, arguments); try { if (this === W.localStorage && !mine(k)) onChange(); } catch (e) {} return r; };
    Storage.prototype.removeItem = function (k) { var r = _ri.apply(this, arguments); try { if (this === W.localStorage && !mine(k)) onChange(); } catch (e) {} return r; };
  } catch (e) {}
  /* v247: নেটিভ (Kotlin) পাশে নোট ইত্যাদি বদলালে নেটিভ এটি ডাকে — localStorage বদলায় না বলে নিজে থেকে ধরা পড়ত না */
  W.__ptNativeChanged = function () { onChange(); };
  W.addEventListener('storage', function (e) { if (!e.key || !mine(e.key)) onChange(); });   /* অন্য পেজ/ফ্রেম থেকে বদল */

  /** নতুন ফোন / নতুন সাইন-ইন: ক্লাউডে হিসাব থাকলে নিজে থেকেই ফিরিয়ে আনা, না থাকলে এই ফোনেরটা পাঠানো।
      v339: ক্লাউড থেকে আনা সফল না হওয়া পর্যন্ত ক্লাউডে কিছুই লেখা হয় না — বারবার আবার চেষ্টা (৪, ৮, ১২… সর্বোচ্চ ৬০ সেকেন্ড; নেট ফিরলে সাথে সাথে)।
      v340: এই ফোনে আগে থেকে (অতিথি অবস্থায়) জমা হিসাব মুছে যায় না — ক্লাউডের হিসাবের সাথে মিলে যায় (একই ঘরে দুই রকম হলে ক্লাউডেরটা)। */
  var fsT = 0, fsTry = 0, fsSeq = 0;
  function firstSync() {
    clearTimeout(fsT); fsT = 0;
    if (!S.signedIn || !B() || fsBusy) return;
    var c = cloudState();
    if (c.at) { pollCloud(true); return; }      /* এই অ্যাকাউন্ট এই ফোনে আগেই সিঙ্ক হয়েছে */
    if (c.on === false || c.hold) return;
    var uid = S.uid, my = ++fsSeq;
    fsBusy = true;
    var retry = function () {
      if (my !== fsSeq) return; fsSeq++; fsBusy = false; fsTry++;
      if (fsTry === 1) toast('ক্লাউড থেকে হিসাব আনা যায়নি — সংযোগ পেলে নিজে থেকে আনা হবে। ততক্ষণ ক্লাউডের হিসাব অক্ষত থাকবে।');
      fsT = setTimeout(firstSync, Math.min(60000, 4000 * fsTry)); paintUser();
    };
    var guard = setTimeout(retry, 75000);       /* নেটিভের সময়সীমা (১৫+৪০ সেকেন্ড) পেরিয়েও উত্তর না এলে — আবার চেষ্টা */
    call('cloudLoad').then(function (r) {
      if (my !== fsSeq) return;                 /* দেরিতে আসা পুরনো উত্তর */
      clearTimeout(guard);
      if (!S.signedIn || S.uid !== uid) { fsBusy = false; return; }
      var hold = function (msg) { fsBusy = false; c.hold = true; jset(CK, c); paintUser(); paintSettings(); toast(msg, 'danger'); };
      if (r && !r.ok && r.code === 'broken') { hold('ক্লাউডের হিসাব পড়া যায়নি — ক্লাউডে কিছু বদলানো হয়নি'); return; }
      if (!r || !r.ok) { retry(); return; }
      fsTry = 0;
      if (r.empty || !r.data) { fsBusy = false; push(true, true); return; }      /* ক্লাউড সত্যিই ফাঁকা — এই ফোনেরটাই প্রথম হিসাব */
      var cd = B().parse(r.data);
      if (!cd) { hold('ক্লাউডের হিসাব পড়া যায়নি — ক্লাউডে কিছু বদলানো হয়নি'); return; }
      var local = B().data(), cf = B().fpOf(cd);
      if (cf === B().fpOf(local)) { fsBusy = false; setBase(cd); synced(c, cf, r.at || 0); return; }
      var merged = B().merge3({}, local, cd, false, false);
      if (!B().applyData(merged, { merge: true })) { hold('ফোনে জায়গা কম — ক্লাউডের হিসাব বসানো যায়নি'); return; }   /* সফল হলে অ্যাপ নতুন করে খোলে — fsBusy রিলোডেই শেষ */
      applying = true;
      setBase(cd); c.at = Date.now(); c.cat = r.at || 0; c.fp = cf; c.hold = false; jset(CK, c);
      toast('আপনার সব হিসাব ক্লাউড থেকে ফিরে আসছে…', 'success');
    });
  }

  /* ---------------------------------------------------------------- অন্য ফোনের বদল আনা
     • এই ফোনে বদল → আড়াই সেকেন্ডে ক্লাউডে (onChange ওপরে)।
     • অন্য ফোনে বদল → অ্যাপ খুললে/সামনে এলে সাথে সাথে, আর খোলা থাকলে প্রতি ১ মিনিটে (হাত না পড়লে ৫ মিনিটে) ক্লাউডের "শেষ বদলের সময়" (হালকা cloudMeta) দেখা।
       v340: আগে ৪ সেকেন্ড পরপর দেখা হতো — প্রতি ইউজারে ঘণ্টায় ~৯০০ বার সার্ভার-ফাংশন ডাকা; Supabase-এর ফ্রি সীমা (মাসে ৫ লাখ) কয়েকশো ইউজারেই শেষ হয়ে যেত।
     • নিজের অসেভড বদল থাকলে আগে সেটি পাঠানোর চেষ্টা (push নিজেই দরকার হলে মিলিয়ে নেয়)। */
  var pollBusy = false, metaOK = true, lastTouch = Date.now(), lastPoll = 0;
  ['touchstart', 'click', 'keydown'].forEach(function (ev) { D.addEventListener(ev, function () { lastTouch = Date.now(); }, { passive: true, capture: true }); });
  function pollCloud(now) {
    if (!S.signedIn || !B() || pollBusy || inflight || recBusy || fsBusy || applying || D.visibilityState === 'hidden') return;
    var c = cloudState(); if (!c.at || c.on === false || c.hold) return;
    if (B().fingerprint() !== c.fp) { push(false); return; }
    if (!now && Date.now() - lastPoll < 15000) return;
    pollBusy = true; lastPoll = Date.now();
    var viaMeta = metaOK;
    call(viaMeta ? 'cloudMeta' : 'cloudLoad').then(function (r) {
      pollBusy = false;
      if (!r || !r.ok) { if (viaMeta && r && r.code === 'nometa') metaOK = false; return; }
      lastOk = Date.now();
      if (r.empty || !r.at || r.at <= (c.cat || 0)) return;
      reconcile(false);
    });
  }
  function pollLoop() {
    var idle = Date.now() - lastTouch > 120000;     /* ২ মিনিট হাত না পড়লে ধীর */
    pollCloud(false);                               /* পেছনে থাকলে নিজেই থেমে যায় */
    setTimeout(pollLoop, (!metaOK || idle) ? 300000 : 60000);
  }
  setTimeout(pollLoop, 60000);
  function autoPush() { push(false); syncAvatar(false); loadCloudAvatar(true); }   /* v339: ছবি না থাকলে (নেটের কারণে আগে আনা যায়নি) আবার চেষ্টা */
  D.addEventListener('visibilitychange', function () { if (D.visibilityState === 'hidden') { push(false); syncAvatar(false); } else { lastTouch = Date.now(); pollCloud(false); } });
  W.addEventListener('online', function () { var c = cloudState(); if (S.signedIn && !c.at && !fsBusy && c.on !== false && !c.hold) firstSync(); gpTry = 0; autoPush(); pollCloud(false); });
  setInterval(autoPush, 15000);
  setInterval(function () { if (S.signedIn && !sheet.hidden) paintUser(); }, 10000);

  /* ---------------------------------------------------------------- বাটন */
  sheet.addEventListener('click', function (e) {
    var go = e.target.closest('[data-ac-go]'); if (go) { show(go.getAttribute('data-ac-go')); if (go.getAttribute('data-ac-go') === 'user') paintUser(); return; }
    var m = e.target.closest('[data-ac-mode]'); if (m) { setMode(m.getAttribute('data-ac-mode')); return; }
    var b = e.target.closest('[data-ac]'); if (!b || busy) return;
    var a = b.getAttribute('data-ac');
    if (a === 'google' || a === 'google-web') {
      /* v194: শিট (Credential Manager) বাতিল/ব্যর্থ হলে "ব্রাউজার দিয়ে" পথ; একবার ব্রাউজারে সফল হলে পরের বার সরাসরি সেটিই */
      var web = a === 'google-web' || jget(GM) === 'web';
      setBusy(true, b); gerr('');
      call(web ? 'googleWeb' : 'google').then(function (r) {
        setBusy(false, b);
        if (r.ok) { if (web) jset(GM, 'web'); afterSignIn(r, 'google'); }
        else if (r.code === 'cancel') {
          if (web) { if (a !== 'google-web') jset(GM, 'sheet'); return; }   /* ব্রাউজার বন্ধ করেছেন — চুপ */
          gerr('সাইন-ইন সম্পন্ন হলো না' + (r.detail ? ' (' + r.detail + ')' : '') + '। অ্যাকাউন্ট বেছেও এমন হলে নিচের "ব্রাউজার দিয়ে" চাপুন।', true);
        } else { var m = r.msg || 'Google সাইন-ইন হলো না। ইমেইল দিয়ে সাইন-ইন করুন।'; gerr(m, true); toast(m, 'danger'); }
      });
    } else if (a === 'premium') {
      /* v278: অ্যাকাউন্ট পপআপ বন্ধ করে প্রিমিয়াম পেজ খোলে */
      if (W.PT) PT.sheet.close(sheet);
      setTimeout(function () { if (W.ptOpenPremium) W.ptOpenPremium('account'); }, 220);
    } else if (a === 'eye') {
      var pi = $('ac-pass'), shown = pi.type === 'text'; pi.type = shown ? 'password' : 'text';
      b.innerHTML = W.PT ? PT.icon(shown ? 'eye' : 'eye-off') : ''; b.setAttribute('aria-label', shown ? 'পাসওয়ার্ড দেখান' : 'পাসওয়ার্ড লুকান');
    } else if (a === 'forgot') {
      var em = $('ac-email').value.trim();
      if (!/^\S+@\S+\.\S+$/.test(em)) { err('আগে ইমেইল ঠিকানাটি লিখুন, তারপর এখানে চাপুন।'); $('ac-email').focus(); return; }
      setBusy(true, b);
      call('reset', em).then(function (r) { setBusy(false, b); if (r.ok) { errOff(); toast('পাসওয়ার্ড বদলানোর লিংক ' + em + '-এ পাঠানো হয়েছে', 'success'); } else err(r.msg); });
    } else if (a === 'resend') {
      setBusy(true, b); call('sendVerify').then(function (r) { setBusy(false, b); toast(r.ok ? 'যাচাইয়ের ইমেইল আবার পাঠানো হয়েছে' : r.msg, r.ok ? 'success' : 'danger'); });
    } else if (a === 'verified') {
      setBusy(true, b); call('reload').then(function (r) { setBusy(false, b); paintUser(); toast(S.verified ? 'ইমেইল যাচাই হয়েছে — জাযাকাল্লাহ' : 'এখনো যাচাই হয়নি — ইমেইলের লিংকে চাপুন', S.verified ? 'success' : ''); });
    } else if (a === 'signout') {
      /* v194: সাইন-আউট = এই ফোন প্রথম দিনের মতো (নাম, ছবি, সেটিংস, হিসাব মুছে)। ক্লাউডে হিসাব নিরাপদ — আগে সেটি নিশ্চিত করা হয়। */
      var sc = cloudState(), dirty = !!B() && B().fingerprint() !== sc.fp;
      var finish = function () {
        setBusy(true, b);
        call('signOut').then(function () { S = { signedIn: false }; try { B().resetLocal(); } catch (e) { setBusy(false, b); show('guest'); paintSettings(); } });
      };
      var warn = function () {
        PT.dialog({ icon: 'logout', title: 'সিঙ্ক হয়নি — তবুও সাইন-আউট?', body: 'এই ফোনের কিছু বদল ক্লাউডে পাঠানো যায়নি (ইন্টারনেট বা সিঙ্ক বন্ধ)। এখন সাইন-আউট করলে সেগুলো মুছে যাবে।', ok: 'তবুও সাইন-আউট' }).then(function (y) { if (y) finish(); });
      };
      PT.dialog({ icon: 'logout', title: 'সাইন-আউট করবেন?', body: 'এই ফোনের নাম, ছবি, ক্যালেন্ডারের নোট ও সব সেটিংস মুছে অ্যাপ প্রথম দিনের মতো হয়ে যাবে। আপনার হিসাব ক্লাউডে নিরাপদ থাকবে — আবার সাইন-ইন করলেই ফিরে আসবে।', ok: 'সাইন-আউট' }).then(function (y) {
        if (!y) return;
        if (!dirty) { finish(); return; }
        if (sc.hold || sc.on === false) { warn(); return; }
        setBusy(true, b);
        push(true).then(function (ok) { setBusy(false, b); if (ok) finish(); else warn(); });
      });
    } else if (a === 'delete') {
      var pw = $('ac-del-pass').value;
      if (S.provider !== 'google' && !pw) { err('পাসওয়ার্ড দিন।', 'ac-del-err'); return; }
      setBusy(true, b);
      call('deleteAccount', S.provider === 'google' ? '' : pw).then(function (r) {
        setBusy(false, b);
        if (r.ok) { try { localStorage.removeItem(CK); localStorage.removeItem(BASE); localStorage.removeItem(AVM); localStorage.removeItem(AVD); localStorage.removeItem(AVW); } catch (e) {} S = { signedIn: false }; show('guest'); paintSettings(); toast('অ্যাকাউন্ট ও ক্লাউডের ডেটা মুছে ফেলা হয়েছে', 'success'); try { B().resetLocal(); } catch (e) {} }
        else if (r.code !== 'cancel') err(r.msg, 'ac-del-err');
      });
    }
  });

  $('ac-form').addEventListener('submit', function (e) {
    e.preventDefault(); if (busy) return;
    var name = $('ac-name').value.trim(), em = $('ac-email').value.trim(), pw = $('ac-pass').value;
    if (mode === 'up' && name.length < 2) { err('আপনার নাম লিখুন।'); $('ac-name').focus(); return; }
    if (!/^\S+@\S+\.\S+$/.test(em)) { err('ইমেইল ঠিকানাটি সঠিক নয়।'); $('ac-email').focus(); return; }
    if (pw.length < 6) { err('পাসওয়ার্ড অন্তত ৬ অক্ষরের দিন।'); $('ac-pass').focus(); return; }
    var btn = $('ac-submit'); setBusy(true, btn);
    (mode === 'up' ? call('emailUp', name, em, pw) : call('emailIn', em, pw)).then(function (r) {
      setBusy(false, btn);
      if (r.ok) { $('ac-pass').value = ''; afterSignIn(r, mode); }
      else { err(r.msg); if (r.code === 'exists') setTimeout(function () { var sg = sheet.querySelector('.ac-seg'); if (sg && sg.ptSelect) sg.ptSelect(0); setMode('in'); err(r.msg); }, 10); }
    });
  });
  var seg = sheet.querySelector('.ac-seg');
  if (seg) seg.addEventListener('pt:change', function (e) { setMode(e.detail.index ? 'up' : 'in'); });

  $('ac-auto').addEventListener('change', function () { var c = cloudState(); c.on = this.checked; if (c.on) c.hold = false; jset(CK, c); paintUser(); if (c.on) push(false); });

  /* v182: নাম/ছবিতে বদল না থাকলে "সেভ করুন" ধূসর — বদল করলেই চালু */
  function pfDirty() {
    var sv = $('pf-save'); if (!sv) return;
    if (view !== 'user') { sv.disabled = false; return; }
    var p = jget('pt_profile') || {}, nm = $('pf-name').value.trim();
    var ph = W.__ptProfilePending ? (W.__ptProfilePending() || '') : (p.photo || '');
    sv.disabled = (nm === (p.name || '').trim()) && (ph === (p.photo || ''));
  }
  $('pf-name').addEventListener('input', pfDirty);
  ['pf-file', 'pf-remove', 'pf-photo'].forEach(function (id) { var el = $(id); if (el) el.addEventListener(id === 'pf-file' ? 'change' : 'click', function () { setTimeout(pfDirty, 60); setTimeout(pfDirty, 600); }); });
  var _show = show; show = function (v) { _show(v); pfDirty(); };

  /* সাইন-ইন অবস্থায় নাম বদলালে অ্যাকাউন্টেও (সেভ বাটনের নিজের কাজ 09-home.js করে) */
  $('pf-save').addEventListener('click', function () {
    if (!S.signedIn) return;
    var q = jget('pt_profile') || {}, hadP = baseH !== hsh(''), nowP = !!photoNow();   /* v339 */
    if (nowP && (q.nogp || (q.gp && hsh(photoNow()) !== baseH))) { delete q.nogp; if (hsh(photoNow()) !== baseH) delete q.gp; jset('pt_profile', q); }
    else if (!nowP && hadP && !q.nogp) { q.nogp = 1; delete q.gp; jset('pt_profile', q); }
    if (hsh(photoNow()) !== baseH) { try { localStorage.removeItem(AVW); } catch (e) {} jset(AVD, { uid: S.uid }); baseH = hsh(photoNow()); syncAvatar(true); }   /* নিজে ছবি বদলালে/সরালে সেটিই চূড়ান্ত */
    var n = $('pf-name').value.trim(); if (n && n !== S.name) call('setName', n);
  });

  /* ---------------------------------------------------------------- শুরু */
  readState(); paintSettings();
  if (S.signedIn) setTimeout(function () { var c = cloudState(); if (!c.at && !c.hold) firstSync(); else pollCloud(true); syncAvatar(false); loadCloudAvatar(true); }, 700);   /* v339: true = Storage-এ ছবি না থাকলে Google-এর ছবি (রিস্টোরের রিলোডের পরেও) */
})();
