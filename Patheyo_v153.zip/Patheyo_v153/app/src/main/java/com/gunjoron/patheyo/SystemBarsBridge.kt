package com.gunjoron.patheyo

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import androidx.core.view.WindowCompat

/**
 * v139: স্ট্যাটাস বার (সময়/নেটওয়ার্ক/ব্যাটারি) ও নেভিগেশন বারের আইকনের রং এখন সিস্টেমের থিম নয়,
 * অ্যাপের স্ক্রিনে এই মুহূর্তে যে থিম (লাইট/ডার্ক/সেপিয়া) দেখা যাচ্ছে সেটা অনুযায়ী ঠিক হয়।
 *  - লাইট/সেপিয়া স্ক্রিন → গাঢ় আইকন
 *  - ডার্ক স্ক্রিন      → সাদা আইকন
 * JS (shell/js/05-pages-controller.js) থেকে PatheyoSystemBars.setLightTheme(true/false) দিয়ে ডাকা হয়।
 * শেষ মানটা সেভ থাকে, তাই পরের বার অ্যাপ খুললে প্রথম ফ্রেম থেকেই সঠিক রং থাকে।
 */
class SystemBarsBridge(private val activity: Activity) {

    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun setLightTheme(light: Boolean) {
        try { activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LIGHT, light).apply() } catch (_: Throwable) { }
        main.post { apply(activity, light) }
    }

    companion object {
        private const val PREFS = "patheyo_system_bars"
        private const val KEY_LIGHT = "light_theme"

        /** অ্যাপ চালুর সময় (onCreate) শেষ জানা থিম অনুযায়ী আইকনের রং বসানো */
        fun applySaved(activity: Activity) {
            try {
                val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                if (prefs.contains(KEY_LIGHT)) apply(activity, prefs.getBoolean(KEY_LIGHT, false))
            } catch (_: Throwable) { }
        }

        /**
         * v150: সব ফোনে স্ট্যাটাস বার অ্যাপের ব্যাকগ্রাউন্ডের সাথে মিলে যাওয়া।
         * Android 15+ এ সিস্টেম নিজেই অ্যাপকে স্ট্যাটাস বারের নিচ পর্যন্ত আঁকতে দেয় (edge-to-edge), তাই সেখানে ঠিকই ছিল।
         * পুরনো Android (১৪ ও নিচে) ও কিছু কাস্টম ROM-এ (যেমন EMUI/Huawei) স্ট্যাটাস বার আলাদা ধূসর/রঙিন স্ট্রিপ হয়ে থাকত।
         * এখানে শুধু স্ট্যাটাস বারটাকে স্বচ্ছ করে অ্যাপের কনটেন্ট তার নিচ পর্যন্ত আনা হচ্ছে — নেভিগেশন বার আগের মতোই থাকে।
         * হেডারের ওপরের ফাঁক MainActivity-র setupSafeInsets()/setNativeSafeTop আগে থেকেই ঠিক করে, তাই কিছু নিচে নামে না।
         */
        @Suppress("DEPRECATION")
        fun drawBehindStatusBar(activity: Activity) {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 35) return   // Android 15+: সিস্টেম নিজেই edge-to-edge করে
                val w = activity.window
                w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                w.statusBarColor = android.graphics.Color.TRANSPARENT
                val dv = w.decorView
                dv.systemUiVisibility = dv.systemUiVisibility or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            } catch (_: Throwable) { }
        }

        private fun apply(activity: Activity, light: Boolean) {
            try {
                if (activity.isFinishing || activity.isDestroyed) return
                val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                c.isAppearanceLightStatusBars = light       // true = গাঢ় আইকন (হালকা ব্যাকগ্রাউন্ডের জন্য)
                c.isAppearanceLightNavigationBars = light
            } catch (_: Throwable) { }
        }
    }
}
