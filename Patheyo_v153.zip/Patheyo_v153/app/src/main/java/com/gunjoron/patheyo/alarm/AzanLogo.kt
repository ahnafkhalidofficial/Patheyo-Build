package com.gunjoron.patheyo.alarm

// v49: Patheyo new logo (home_logo_circle.png) used as-is for alarm / azan notification / overlay.
// The logo is already a round badge, so it is only scaled (no extra base disk or ring).

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.gunjoron.patheyo.R

object AzanLogo {

    @Volatile private var cache: Pair<Int, Bitmap>? = null
    @Volatile private var source: Bitmap? = null

    private fun logoSource(ctx: Context): Bitmap? {
        source?.let { if (!it.isRecycled) return it }
        return try {
            val o = BitmapFactory.Options().apply { inScaled = false }
            BitmapFactory.decodeResource(ctx.applicationContext.resources, R.drawable.home_logo_circle, o)?.also { source = it }
        } catch (_: Throwable) { null }
    }

    /** [sizePx] x [sizePx] logo bitmap; null if the logo cannot be loaded */
    fun circle(ctx: Context, sizePx: Int): Bitmap? {
        val size = sizePx.coerceIn(48, 768)
        cache?.let { if (it.first == size && !it.second.isRecycled) return it.second }
        return try {
            val logo = logoSource(ctx) ?: return null
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            c.drawBitmap(logo, null, RectF(0f, 0f, size.toFloat(), size.toFloat()), paint)
            cache = size to out
            out
        } catch (_: Throwable) { null }
    }
}
