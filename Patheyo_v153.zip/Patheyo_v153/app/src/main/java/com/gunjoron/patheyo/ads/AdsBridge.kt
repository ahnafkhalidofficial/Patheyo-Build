package com.gunjoron.patheyo.ads

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.pm.PackageInfoCompat
import com.gunjoron.patheyo.stats.BackendConfig
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * v143: ওয়েবসাইটের অ্যাডমিন প্যানেলের "এড" ট্যাব ↔ অ্যাপের বিজ্ঞাপন (স্লাইডার, নিচের ব্যানার, অ্যাপ-খোলা পপআপ)।
 *
 * JS-এর সাথে চুক্তি (assets/ads/ads.js) — window.PatheyoAds:
 *   getCached()          : সর্বশেষ সফলভাবে আনা এডের JSON (খালি স্ট্রিং = এখনো কিছু আসেনি)
 *   refresh()            : পেছনে Supabase `get_app_ads` ডাকে; নতুন কিছু এলে window.PTAds.onRemote() চালায়
 *   track(adId, event)   : "view" | "click" | "copy" — ওয়েবসাইটের এড-পরিসংখ্যানের জন্য (`track_ad`)
 *   copyText(text)       : প্রমো কোড ক্লিপবোর্ডে
 *
 * নিরাপত্তা: সব কাজ try-catch-এ ও আলাদা থ্রেডে; ইন্টারনেট না থাকলে বা সার্ভার সাড়া না দিলে চুপচাপ বাদ যায়,
 * অ্যাপের কিছুতে বাধা দেয় না। BackendConfig খালি থাকলে কিছুই করে না (তখন অ্যাপে বসানো ডিফল্ট এড দেখায়)।
 */
class AdsBridge(context: Context, private val webView: WebView) {

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "patheyo-ads").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var busy = false
    @Volatile private var lastTry = 0L
    @Volatile private var lastOk = 0L

    @JavascriptInterface
    fun getCached(): String = try { prefs.getString(K_JSON, "") ?: "" } catch (_: Throwable) { "" }

    @JavascriptInterface
    fun refresh() {
        try {
            if (!BackendConfig.enabled() || busy) return
            val now = SystemClock.elapsedRealtime()
            if (lastOk != 0L && now - lastOk < OK_GAP_MS) return        // সম্প্রতি সফল হয়েছে
            if (lastTry != 0L && now - lastTry < RETRY_GAP_MS) return   // ব্যর্থ হলে অন্তত ২০ সেকেন্ড পর আবার
            busy = true; lastTry = now
            io.execute {
                try {
                    val text = fetchAds()
                    if (text != null) {
                        lastOk = SystemClock.elapsedRealtime()
                        val old = prefs.getString(K_JSON, "") ?: ""
                        if (text != old) {
                            prefs.edit().putString(K_JSON, text).apply()
                            notifyJs()
                        }
                    }
                } catch (_: Throwable) {
                } finally { busy = false }
            }
        } catch (_: Throwable) { busy = false }
    }

    @JavascriptInterface
    fun track(adId: String?, event: String?) {
        try {
            if (!BackendConfig.enabled()) return
            val id = adId?.trim().orEmpty()
            val ev = event?.trim().orEmpty()
            if (id.length != 36 || ev !in EVENTS) return
            val body = JSONObject().put("p_ad", id).put("p_event", ev).toString()
            io.execute { try { post("track_ad", body) } catch (_: Throwable) {} }
        } catch (_: Throwable) { }
    }

    @JavascriptInterface
    fun copyText(text: String?): Boolean {
        val t = text?.take(80).orEmpty()
        if (t.isEmpty()) return false
        main.post {
            try {
                val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("promo", t))
            } catch (_: Throwable) { }
        }
        return true
    }

    // ---------- ভেতরের কাজ ----------

    private fun versionCode(): Long = try {
        PackageInfoCompat.getLongVersionCode(app.packageManager.getPackageInfo(app.packageName, 0))
    } catch (_: Throwable) { 0L }

    /** সফল হলে যাচাই করা JSON স্ট্রিং, না হলে null */
    private fun fetchAds(): String? {
        val vc = versionCode()
        val body = JSONObject().apply { if (vc > 0) put("p_version_code", vc) }.toString()
        val text = post("get_app_ads", body) ?: return null
        val o = JSONObject(text)
        if (o.optJSONArray("ads") == null || o.optJSONObject("settings") == null) return null
        return text
    }

    private fun post(fn: String, body: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(BackendConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/rpc/" + fn).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 12_000
                doOutput = true
                setRequestProperty("apikey", BackendConfig.SUPABASE_ANON_KEY)
                setRequestProperty("Authorization", "Bearer " + BackendConfig.SUPABASE_ANON_KEY)
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode in 200..299) conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() } else null
        } catch (_: Throwable) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun notifyJs() {
        main.post {
            try {
                webView.evaluateJavascript("window.PTAds&&window.PTAds.onRemote&&window.PTAds.onRemote()", null)
            } catch (_: Throwable) { }
        }
    }

    private companion object {
        const val FILE = "patheyo_ads"
        const val K_JSON = "json"
        const val OK_GAP_MS = 2L * 60_000L
        const val RETRY_GAP_MS = 20_000L
        val EVENTS = setOf("view", "click", "copy")
    }
}
