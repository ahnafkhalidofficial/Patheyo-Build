package com.gunjoron.patheyo.update

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.view.ContextThemeWrapper
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.ui.DialogText
import com.gunjoron.patheyo.ui.GlassStyle

/** v35: গ্লাস আপডেট পপআপ। চেহারা: res/layout/dialog_update.xml + ui/GlassStyle.kt */
object UpdateDialog {

    fun show(
        activity: Activity,
        info: UpdateInfo,
        onUpdate: () -> Unit,
        onDismiss: () -> Unit
    ): AlertDialog {
        val themed = ContextThemeWrapper(activity, R.style.Theme_Patheyo)
        val view = LayoutInflater.from(themed).inflate(R.layout.dialog_update, null)

        // অ্যাপের নাম (ফোনে অ্যাপের যে নাম আছে সেটাই) + নিচে মাঝখানে ছোট লাইট-ফন্ট ভার্সন ট্যাগ
        val tag = if (info.sizeMb > 0) activity.getString(R.string.update_chip_with_size, info.versionName, info.sizeMb)
                  else activity.getString(R.string.update_chip, info.versionName)
        view.findViewById<TextView>(R.id.tvAppName).text =
            DialogText.nameWithTag(activity, GlassStyle.appLabel(activity), tag, latinTag = true, below = true)

        view.findViewById<TextView>(R.id.tvNotes).text =
            DialogText.formatList(
                activity, info.releaseNotes.ifBlank { activity.getString(R.string.update_no_notes) },
                activity.getColor(R.color.update_tag_text)
            )

        val dialog = AlertDialog.Builder(themed)
            .setView(view)
            .setCancelable(!info.mandatory)     // mandatory=true হলে বাইরে ট্যাপ/ব্যাক করে বন্ধ করা যাবে না
            .create()
        dialog.setOnDismissListener { onDismiss() }
        val prepared = GlassStyle.prepare(activity, dialog)

        GlassStyle.limitHeight(view.findViewById(R.id.svNotes), maxDp = 320)

        view.findViewById<View>(R.id.btnUpdate).setOnClickListener {
            dialog.dismiss()
            onUpdate()
        }
        view.findViewById<View>(R.id.btnLater).apply {
            if (info.mandatory) visibility = View.GONE
            setOnClickListener { dialog.dismiss() }
        }

        dialog.show()
        GlassStyle.present(activity, dialog, view, prepared)
        return dialog
    }
}
