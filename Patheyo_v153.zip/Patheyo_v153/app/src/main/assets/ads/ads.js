/* ===== Patheyo বিজ্ঞাপন (v143) -- ওয়েবসাইটের অ্যাডমিন প্যানেলের "এড" ট্যাব থেকে নিয়ন্ত্রিত =====
   তিনটি জায়গা: (১) হোম স্লাইডার ১২০০×৩৫০  (২) নিচের ফিক্সড ব্যানার ১২০০×৪৫০  (৩) অ্যাপ খুললে পপআপ ১২০০×১২০০
   ডাটা আসে: Kotlin ব্রিজ `PatheyoAds` (window.PatheyoAds) -> Supabase `get_app_ads`। অফলাইনে সর্বশেষ সেভ করা তালিকা চলে।
   ওয়েবসাইট থেকে কোনো এড না এলে (বা প্যানেলে "ডিফল্ট এড" চালু থাকলে) ads/ads-config.js-এর বসানো এডগুলো দেখায় -- আগের মতোই।
   - PTAds.mountFooter(doc): ফিচার পেজের (iframe) নিচে ব্যানার বসায় -- শেল নিজে ডাকে।
   - লিংক সবসময় target="_blank" -- MainActivity.shouldOverrideUrlLoading সেটা ফোনের ব্রাউজারে খোলে।
   এই ফাইলের কোড বদলানোর দরকার নেই। */
(function () {
  var C = window.PT_ADS; if (!C) return;
  var BR = window.PatheyoAds || null;                     /* নেটিভ ব্রিজ (ব্রাউজারে টেস্টের সময় null -- তখন শুধু ডিফল্ট এড) */
  var root = document.documentElement;
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  var bootTs = Date.now();
  var R = null;                                           /* সর্বশেষ রিমোট ডাটা {settings, ads} */
  var sig = {};                                           /* কোনটা শেষবার কী দিয়ে আঁকা হয়েছে (অকারণে আবার আঁকা এড়াতে) */
  var seen = {};                                          /* এই সেশনে যে ভিউ আগেই গোনা হয়েছে */

  function url(p) { try { return new URL(p, document.baseURI).href; } catch (e) { return p; } }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }
  var ARROW = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>';
  var CLOSE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>';

  /* ---------- রিমোট ডাটা ---------- */
  function readRemote() {
    try {
      var s = BR && BR.getCached && BR.getCached(); if (!s) return null;
      var o = JSON.parse(s);
      if (o && o.settings && Object.prototype.toString.call(o.ads) === '[object Array]') return o;
    } catch (e) {}
    return null;
  }
  function allOn() { return !R || R.settings.enabled !== false; }
  function placeOn(p) { return !R || R.settings[p] !== false; }
  function fallbackOn() { return !R || R.settings.fallback !== false; }
  function intervalMs() { var v = R && +R.settings.interval_ms; return v >= 2000 ? v : (C.intervalMs || 5000); }
  function remoteItems(p) {
    if (!R) return [];
    return R.ads.filter(function (a) { return a && a.p === p && /^https:\/\//.test(a.img || ''); });
  }
  function bundled(b) { return { id: null, img: url(b.img), alt: b.alt || '', link: b.link || C.site, promo: '', note: '', btn: '' }; }

  /* ---------- গণনা (ভিউ / ক্লিক / প্রমো কপি) ---------- */
  function track(id, ev) { if (!id || !BR || !BR.track) return; try { BR.track(String(id), ev); } catch (e) {} }
  function viewOnce(kind, id) { if (!id) return; var k = kind + ':' + id; if (seen[k]) return; seen[k] = 1; track(id, 'view'); }
  function homeVisible() { return !document.hidden && !root.classList.contains('pf-paused'); }

  /* ---------- প্রমো কোড কপি ---------- */
  function copyCode(code, id, btn) {
    var ok = false;
    try { if (BR && BR.copyText) ok = BR.copyText(String(code)) !== false; } catch (e) {}
    if (!ok) { try { navigator.clipboard.writeText(String(code)); ok = true; } catch (e) {} }
    if (!ok) {
      try { var t = document.createElement('textarea'); t.value = code; t.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(t); t.select(); ok = document.execCommand('copy'); document.body.removeChild(t); } catch (e) {}
    }
    track(id, 'copy');
    if (btn) {
      var b = btn.querySelector('b'); if (!b) return;
      var old = btn.getAttribute('data-lbl') || b.textContent; btn.setAttribute('data-lbl', old);
      b.textContent = ok ? 'কপি হয়েছে ✓' : 'কপি করুন';
      clearTimeout(btn._t); btn._t = setTimeout(function () { b.textContent = old; }, 1700);
    }
  }
  function promoChip(it, cls) {
    if (!it.promo) return '';
    return '<button class="pt-promo ' + (cls || '') + (it.note ? ' has-note' : '') + '" type="button" data-code="' + esc(it.promo) + '" data-id="' + esc(it.id || '') + '" aria-label="প্রমো কোড কপি করুন">' +
      (it.note ? '<em class="pt-badge">' + esc(it.note) + '</em>' : '') + '<span class="pt-promo-t"><i>কোড: <u>' + esc(it.promo) + '</u></i></span><b>কপি</b></button>';
  }
  /* ছাড়ের ব্যাজ প্রমো কোড ছাড়াও আলাদাভাবে চলে: কোড থাকলে চিপের ভেতরে, না থাকলে একা */
  function soloBadge(it) { return (it.note && !it.promo) ? '<em class="pt-badge solo">' + esc(it.note) + '</em>' : ''; }
  function bindPromo(host) {
    host.addEventListener('click', function (e) {
      var p = e.target.closest && e.target.closest('.pt-promo'); if (!p || !host.contains(p)) return;
      e.preventDefault(); e.stopPropagation(); copyCode(p.getAttribute('data-code'), p.getAttribute('data-id'), p);
    });
  }

  /* ---------- ছবি আগে লোড করে দেখা (ভাঙা লিংকের ফাঁকা এড দেখানো এড়াতে) ---------- */
  function preload(items, done) {
    var ok = [], left = items.length, finished = false;
    if (!left) { done([]); return; }
    items.forEach(function (it, i) {
      var im = new Image(), fin = false, t = 0;
      function end(good) { if (fin) return; fin = true; clearTimeout(t); ok[i] = !!good; if (--left === 0 && !finished) { finished = true; done(items.filter(function (_, k) { return ok[k]; })); } }
      t = setTimeout(function () { end(false); }, 8000);
      im.onload = function () { it._w = im.naturalWidth; it._h = im.naturalHeight; end(true); }; im.onerror = function () { end(false); };
      im.src = it.img;
    });
  }

  /* ================= (১) হোম স্লাইডার ================= */
  var carTok = 0, carCleanup = null;
  function carouselPlan() {
    if (!allOn() || !placeOn('carousel')) return { items: [], remote: false };
    var rem = remoteItems('carousel');
    if (rem.length) return { items: rem, remote: true };
    if (fallbackOn()) return { items: (C.carousel || []).map(bundled), remote: false };
    return { items: [], remote: false };
  }
  function planSig(items) { return items.map(function (i) { return [i.id, i.img, i.link, i.promo, i.note].join('~'); }).join('|'); }
  function renderCarousel() {
    var host = document.getElementById('ad-carousel'); if (!host) return;
    var sec = host.closest ? host.closest('.ad-section') : null;
    var plan = carouselPlan();
    var sg = planSig(plan.items) + '#' + intervalMs();
    if (sg === sig.car) return; sig.car = sg;
    if (carCleanup) { carCleanup(); carCleanup = null; }
    var tok = ++carTok;
    if (!plan.items.length) { host.innerHTML = ''; if (sec) sec.style.display = 'none'; return; }
    if (sec) sec.style.display = '';
    if (!plan.remote) { carCleanup = buildCarousel(host, plan.items); return; }
    preload(plan.items, function (okItems) {
      if (tok !== carTok) return;
      if (!okItems.length) {                                  /* সব ছবি ব্যর্থ -> ডিফল্ট এড (অনুমতি থাকলে), নইলে লুকানো */
        var fb = fallbackOn() ? (C.carousel || []).map(bundled) : [];
        if (!fb.length) { host.innerHTML = ''; if (sec) sec.style.display = 'none'; return; }
        okItems = fb;
      }
      carCleanup = buildCarousel(host, okItems);
    });
  }
  function buildCarousel(host, items) {
    var n = items.length, cur = 0, timer = 0, paused = false, visible = true, idleT = 0, raf = 0, io = null;
    host.innerHTML = '<div class="ad-viewport" id="ad-viewport"><div class="ad-track">' + items.map(function (s, i) {
      return '<div class="ad-slide' + (i === 0 ? ' is-active' : '') + '" data-ad="' + esc(s.id || '') + '"><img src="' + esc(s.img) + '" alt="' + esc(s.alt) + '" draggable="false" width="1200" height="350">' +
        (s.link ? '<a class="ad-hit" href="' + esc(s.link) + '" target="_blank" rel="noopener" aria-label="' + esc(s.alt || 'বিজ্ঞাপন') + '"></a>' +
          '<a class="ad-go" href="' + esc(s.link) + '" target="_blank" rel="noopener" aria-label="ওয়েবসাইটে যান" title="ওয়েবসাইটে যান">' + ARROW + '</a>' : '') +
        promoChip(s, 'in-slide') + soloBadge(s) + '</div>';
    }).join('') + '</div></div>' + (n > 1 ? '<div class="ad-dots" role="tablist" aria-label="বিজ্ঞাপন">' + items.map(function (s, i) {
      return '<button class="ad-dot' + (i === 0 ? ' is-active' : '') + '" type="button" role="tab" aria-label="ছবি ' + (i + 1) + '"></button>';
    }).join('') + '</div>' : '');
    var vp = host.querySelector('#ad-viewport'), slides = host.querySelectorAll('.ad-slide'), dots = host.querySelectorAll('.ad-dot');
    function countView(i) { if (visible && homeVisible() && items[i]) viewOnce('car', items[i].id); }
    function mark(i) {
      if (i === cur && slides[i].classList.contains('is-active')) return;
      cur = i;
      for (var k = 0; k < n; k++) { slides[k].classList.toggle('is-active', k === i); if (dots[k]) dots[k].classList.toggle('is-active', k === i); }
      countView(i);
    }
    function go(i, smooth) { vp.scrollTo({ left: i * vp.clientWidth, behavior: (smooth && !reduce) ? 'smooth' : 'auto' }); mark(i); }
    function onScroll() { if (raf) return; raf = requestAnimationFrame(function () { raf = 0; var w = vp.clientWidth || 1; mark(Math.max(0, Math.min(n - 1, Math.round(vp.scrollLeft / w)))); }); }
    function hold() { paused = true; clearTimeout(idleT); idleT = setTimeout(function () { paused = false; }, intervalMs()); }
    function tick() { if (n < 2 || paused || !visible || document.hidden || root.classList.contains('pf-paused')) return; go((cur + 1) % n, true); }
    function onResize() { vp.scrollLeft = cur * vp.clientWidth; }
    function onVis() { if (!document.hidden) countView(cur); }
    vp.addEventListener('scroll', onScroll, { passive: true });
    dots.forEach(function (d, i) { d.addEventListener('click', function () { hold(); go(i, true); }); });
    ['touchstart', 'pointerdown', 'wheel'].forEach(function (ev) { vp.addEventListener(ev, hold, { passive: true }); });
    host.addEventListener('click', function (e) {                       /* ক্লিক গণনা */
      var a = e.target.closest && e.target.closest('.ad-hit, .ad-go'); if (!a) return;
      var sl = a.closest('.ad-slide'); if (sl) track(sl.getAttribute('data-ad'), 'click');
    });
    bindPromo(host);
    if ('IntersectionObserver' in window) { io = new IntersectionObserver(function (e) { visible = e[0].isIntersecting; if (visible) countView(cur); }, { threshold: 0.4 }); io.observe(host); }
    window.addEventListener('resize', onResize); document.addEventListener('visibilitychange', onVis);
    timer = setInterval(tick, intervalMs());
    countView(0);
    return function () {                                                /* পুরোনো স্লাইডার পরিষ্কার */
      clearInterval(timer); clearTimeout(idleT); if (io) io.disconnect();
      window.removeEventListener('resize', onResize); document.removeEventListener('visibilitychange', onVis);
    };
  }

  /* ================= (২) নিচের ফিক্সড ব্যানার ================= */
  function footerPool() {
    if (!allOn() || !placeOn('footer')) return { items: [], remote: false };
    var rem = remoteItems('footer');
    if (rem.length) return { items: rem, remote: true };
    if (fallbackOn() && C.footer) return { items: [bundled(C.footer)], remote: false };
    return { items: [], remote: false };
  }
  function pick(items) { return items[items.length > 1 ? Math.floor(Math.random() * items.length) : 0]; }
  function footHtml(it, extra) {
    if (!it) return '';
    return '<div class="pt-ad-foot' + (extra ? ' ' + extra : '') + '" data-ad="' + esc(it.id || '') + '"><img src="' + esc(it.img) + '" alt="' + esc(it.alt) + '" width="1200" height="450" onerror="var p=this.parentNode;if(p)p.style.display=\'none\'">' +
      (it.link ? '<a class="pt-ad-hit" href="' + esc(it.link) + '" target="_blank" rel="noopener" aria-label="' + esc(it.alt || 'বিজ্ঞাপন') + '"></a>' : '') + promoChip(it, 'in-foot') + soloBadge(it) + '</div>';
  }
  function wireFoot(el, it) {
    el.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('.pt-ad-hit')) track(it.id, 'click'); });
    bindPromo(el);
    viewOnce('foot', it.id);
  }
  function renderHomeFooter() {
    var h = document.getElementById('ad-footer-home'); if (!h) return;
    var sec = h.closest ? h.closest('.ad-section') : null;
    var pool = footerPool();
    var sg = planSig(pool.items);
    if (sg === sig.foot) return; sig.foot = sg;
    if (!pool.items.length) { h.innerHTML = ''; if (sec) sec.style.display = 'none'; return; }
    if (sec) sec.style.display = '';
    var it = pick(pool.items);
    h.innerHTML = footHtml(it, 'in-home');
    var el = h.firstChild; if (el && el.nodeType === 1) wireFoot(el, it);
  }
  /* ফিচার পেজের (iframe) CSS এখানেই বসানো (file:// fetch ভরসা করা যায় না) -- ads.css-এর নিচের অংশের কপি */
  var FOOT_CSS = [
    '.pt-ad-foot{display:block;position:relative;margin:22px 16px 14px;border-radius:16px;overflow:hidden;line-height:0;aspect-ratio:8/3;background:#E3EDFD;-webkit-tap-highlight-color:transparent;box-shadow:0 10px 24px -14px rgba(0,32,94,.5),0 0 0 1px rgba(35,95,254,.18);animation:ptAdGlow 4.8s ease-in-out infinite}',
    '.pt-ad-foot img{display:block;width:100%;height:100%;object-fit:cover}',
    '.pt-ad-foot::after{content:"";position:absolute;top:0;bottom:0;left:-40%;width:28%;pointer-events:none;background:linear-gradient(100deg,rgba(255,255,255,0) 0%,rgba(255,255,255,.6) 50%,rgba(255,255,255,0) 100%);transform:skewX(-18deg);animation:ptAdShine 4.8s ease-in-out infinite}',
    '.pt-ad-hit{position:absolute;left:0;top:0;right:0;bottom:0;z-index:1;display:block}',
    '.pt-ad-foot:active{transform:scale(.992)}',
    '@keyframes ptAdShine{0%,62%{left:-40%}92%,100%{left:120%}}',
    '@keyframes ptAdGlow{0%,100%{box-shadow:0 10px 24px -14px rgba(0,32,94,.5),0 0 0 1px rgba(35,95,254,.18)}50%{box-shadow:0 12px 30px -12px rgba(35,95,254,.55),0 0 0 1px rgba(35,95,254,.34)}}',
    '@media (prefers-reduced-motion:reduce){.pt-ad-foot,.pt-ad-foot::after{animation:none}}',
    '.pt-ad-foot.in-home{margin:8px 0 0}',
    '.pt-promo{position:absolute;z-index:3;left:8px;bottom:8px;display:flex;align-items:center;gap:8px;max-width:calc(100% - 16px);margin:0;padding:4px 4px 4px 10px;border:1px dashed rgba(35,95,254,.7);border-radius:12px;background:rgba(255,255,255,.94);color:#00205E;line-height:1.2;text-align:left;font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent;box-shadow:0 4px 12px -6px rgba(0,32,94,.6)}',
    '.pt-promo-t{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}',
    '.pt-badge{flex:none;max-width:48%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-style:normal;font-weight:800;font-size:11px;line-height:1.15;color:#fff;background:linear-gradient(135deg,#FF4B55,#D4101C);padding:5px 9px;border-radius:8px;box-shadow:0 4px 10px -4px rgba(212,16,28,.7)}',
    '.pt-promo i{font-style:normal;font-size:12px;font-weight:700;white-space:nowrap}',
    '.pt-promo u{text-decoration:none;letter-spacing:.04em;color:#235FFE;font-family:system-ui,sans-serif}',
    '.pt-promo b{flex:none;font-size:11px;font-weight:700;color:#fff;background:#235FFE;border-radius:8px;padding:4px 9px;line-height:1.2}',
    '.pt-promo:active{transform:scale(.97)}',
    '.pt-badge.solo{position:absolute;z-index:3;left:8px;bottom:8px;max-width:calc(100% - 16px);pointer-events:none}',
    '#pt-ad-foot-wrap{display:block;width:100%;max-width:480px;margin:0 auto;padding:0 0 4px;box-sizing:border-box}',
    '#pt-ad-foot-wrap .pt-ad-foot{margin:22px 0 14px;width:100%;box-sizing:border-box}',
    '#pt-ad-foot-wrap .pt-ad-foot img{max-width:100%!important;width:100%!important;height:100%!important}',
    '#pt-ad-foot-wrap.pt-ad-off{display:none!important}'
  ].join('\n');
  /* কুরআন/হাদিসে বিজ্ঞাপন শুধু প্রথম (তালিকার) পেজে; পড়ার, তরজমার, ডাউনলোড ও অন্য সব ভিতরের পেজে লুকানো */
  function watchView(doc, w) {
    var win = doc.defaultView; if (!win) return;
    function sync() { try { var A = win.QuranApp || win.HadithApp; if (!A || !A.state) return; w.classList.toggle('pt-ad-off', A.state.view !== 'list'); } catch (e) {} }
    sync(); win.setInterval(sync, 200);
  }
  function mountFooter(doc) {
    try {
      if (!doc || !doc.body || doc.getElementById('pt-ad-foot-wrap')) return;
      var pool = footerPool(); if (!pool.items.length) return;
      var it = pick(pool.items);
      var st = doc.createElement('style'); st.textContent = FOOT_CSS; doc.head.appendChild(st);
      var w = doc.createElement('div'); w.id = 'pt-ad-foot-wrap'; w.innerHTML = footHtml(it);
      var host = doc.querySelector('.app') || doc.body;
      var cs = doc.defaultView.getComputedStyle(host);
      if (host === doc.body || (parseFloat(cs.paddingLeft) || 0) < 8) w.style.padding = '0 16px 4px';
      host.appendChild(w);
      var el = w.firstChild; if (el && el.nodeType === 1) wireFoot(el, it);
      if (doc.querySelector('.tabs') || /quran|hadith/i.test(doc.title || '')) watchView(doc, w);
    } catch (e) {}
  }

  /* ================= (৩) অ্যাপ খুললে পপআপ (১২০০×১২০০) ================= */
  var pop = null, popDone = false, popShown = false, splashGone = false, skipFirst = false, popTimer = 0;
  function sameDay(a, b) { return new Date(a).toDateString() === new Date(b).toDateString(); }
  function freqOk(a) {
    var last = +ls('pt_ad_pop_' + a.id) || 0, now = Date.now();
    switch (a.freq) {
      case 'every_open': return true;
      case 'once': return !last;
      case 'weekly': return !last || now - last >= 6.5 * 864e5;
      default: return !last || !sameDay(last, now);                       /* daily */
    }
  }
  function maybePopup() {
    if (popDone || popShown || !splashGone) return;
    if (Date.now() - bootTs > 20000) return;                              /* ডাটা অনেক দেরিতে এলে এবারের মতো বাদ */
    if (!R || !allOn() || !placeOn('popup')) return;
    var list = remoteItems('popup').filter(freqOk);
    if (!list.length) return;
    popDone = true;
    if (skipFirst) return;                                                /* ইনস্টলের পর প্রথমবার খোলায় পপআপ নয় (পারমিশন ডায়ালগ থাকে) */
    var a = list[0];
    clearTimeout(popTimer);
    popTimer = setTimeout(function () {
      if (document.hidden || document.querySelector('.page-overlay.is-open')) return;
      showPopup(a);
    }, Math.max(0, +a.delay || 0) * 1000);
  }
  /* ছবির কিনারা/কোণ স্বচ্ছ কি না নিজে বুঝে নেয় (ব্যাকগ্রাউন্ডহীন PNG হলে true)। সার্ভার CORS না দিলে বোঝা যায় না -> false (তখন প্যানেল থেকে "স্বচ্ছ PNG" বেছে দেওয়া যায়) */
  function detectClear(it, cb) {
    var done = false; function fin(v) { if (done) return; done = true; clearTimeout(tm); cb(v); }
    var tm = setTimeout(function () { fin(false); }, 2500);
    try {
      var im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = function () {
        try {
          var n = 48, c = document.createElement('canvas'); c.width = n; c.height = n;
          var x = c.getContext('2d'); x.drawImage(im, 0, 0, n, n);
          var d = x.getImageData(0, 0, n, n).data, tr = 0, corner = 0, i;
          for (i = 0; i < n * n; i++) if (d[i * 4 + 3] < 128) tr++;
          [0, n - 1, (n - 1) * n, n * n - 1].forEach(function (p) { if (d[p * 4 + 3] < 128) corner++; });
          fin(corner >= 2 || tr / (n * n) > 0.04);
        } catch (e) { fin(false); }
      };
      im.onerror = function () { fin(false); };
      im.src = it.img;
    } catch (e) { fin(false); }
  }
  function showPopup(a) {
    if (pop || popShown) return;
    preload([a], function (ok) {
      if (!ok.length || pop || popShown) return;
      var mode = a.style || (a.clear ? 'clear' : 'auto');                  /* auto = ছবি দেখে নিজে ঠিক করে; card = সাধারণ; clear = স্বচ্ছ PNG */
      if (mode === 'auto') detectClear(a, function (v) { build(v); }); else build(mode === 'clear');
    });
    function build(isClear) {
      if (pop || popShown) return;
      popShown = true; ls('pt_ad_pop_' + a.id, String(Date.now())); track(a.id, 'view');
      var hasBar = !!(a.promo || a.link || a.note);
      var ar = (a._w > 0 && a._h > 0) ? a._w / a._h : 1;                    /* ছবির নিজের অনুপাত -- যেকোনো মাপ চলে */
      var reserve = hasBar ? (a.note ? 250 : 190) : 60;
      var cw = Math.max(200, Math.min(window.innerWidth * 0.88, 440, (window.innerHeight - reserve) * ar));
      var el = document.createElement('div');
      el.className = 'pt-pop'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', a.alt || 'বিজ্ঞাপন');
      el.innerHTML = '<div class="pt-pop-card' + (hasBar ? '' : ' no-bar') + (isClear ? ' is-clear' : '') + '" style="--w:' + Math.round(cw) + 'px;--ar:' + ar.toFixed(4) + '"><button class="pt-pop-x" type="button" aria-label="বন্ধ করুন">' + CLOSE + '</button>' +
        '<div class="pt-pop-img"><img src="' + esc(a.img) + '" alt="' + esc(a.alt || '') + '" draggable="false">' +
        (a.link ? '<a class="pt-pop-hit" href="' + esc(a.link) + '" target="_blank" rel="noopener" aria-label="' + esc(a.alt || 'বিজ্ঞাপন') + '"></a>' : '') + '</div>' +
        (hasBar ? '<div class="pt-pop-bar">' + soloBadge(a) + promoChip(a, 'in-pop') +
          (a.link ? '<a class="pt-pop-cta" href="' + esc(a.link) + '" target="_blank" rel="noopener">' + esc(a.btn || 'বিস্তারিত দেখুন') + '</a>' : '') + '</div>' : '') + '</div>';
      el.addEventListener('click', function (e) {
        var t = e.target;
        if (t.closest('.pt-pop-x')) { closePopup(); return; }
        if (t.closest('.pt-pop-hit, .pt-pop-cta')) { track(a.id, 'click'); setTimeout(closePopup, 250); return; }
        if (t === el && a.bd !== false) closePopup();
      });
      bindPromo(el);
      document.body.appendChild(el); pop = el;
      requestAnimationFrame(function () { requestAnimationFrame(function () { el.classList.add('is-in'); }); });
    }
  }
  function closePopup() {
    if (!pop) return false;
    var el = pop; pop = null; el.classList.remove('is-in'); el.classList.add('is-out');
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, reduce ? 0 : 200);
    return true;
  }

  /* ================= চালু করা ================= */
  function renderAll() { renderCarousel(); renderHomeFooter(); }
  function onRemote() { R = readRemote(); renderAll(); maybePopup(); }
  function refresh() { try { if (BR && BR.refresh) BR.refresh(); } catch (e) {} }

  function watchSplash() {
    var t0 = Date.now();
    var iv = setInterval(function () {
      if (!document.getElementById('pts') || Date.now() - t0 > 12000) { clearInterval(iv); splashGone = true; maybePopup(); }
    }, 250);
  }
  var hiddenAt = 0;
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { hiddenAt = Date.now(); return; }
    refresh();
    if (hiddenAt && Date.now() - hiddenAt > 30 * 60000) {                  /* ৩০ মিনিটের বেশি পরে অ্যাপে ফিরলে আবার পপআপ বিবেচনা */
      hiddenAt = 0; popDone = false; bootTs = Date.now(); splashGone = true; skipFirst = false; setTimeout(maybePopup, 1500);
    }
  });

  window.PTAds = { mountFooter: mountFooter, onRemote: onRemote, closePopup: closePopup };
  function boot() {
    skipFirst = !ls('pt_ads_booted'); ls('pt_ads_booted', '1');
    R = readRemote();
    renderAll();
    watchSplash();
    refresh();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
