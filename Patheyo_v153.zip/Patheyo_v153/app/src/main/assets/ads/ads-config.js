/* ===== Patheyo বিজ্ঞাপন কনফিগ (v143) =====
   এখন সব এড ওয়েবসাইটের অ্যাডমিন প্যানেল → "এড" ট্যাব থেকে বদলায় -- অ্যাপ নতুন করে বিল্ড করতে হয় না।
   এই ফাইলের এডগুলো শুধু "ডিফল্ট/ফলব্যাক": ইন্টারনেট না থাকলে এবং কখনো ওয়েবসাইটের এড আসেনি এমন ফোনে, অথবা কোনো জায়গায়
   (স্লাইডার/ব্যানার) ওয়েবসাইটে কোনো সক্রিয় এড না থাকলে (প্যানেলে "ডিফল্ট এড দেখাও" চালু থাকলে) এগুলোই দেখায়।
   - ছবির মাপ: স্লাইডার ১২০০×৩৫০ px, নিচের ব্যানার ১২০০×৪৫০ px, পপআপ ১২০০×১২০০ px (পপআপের ডিফল্ট নেই -- শুধু ওয়েবসাইট থেকে)।
   - link: ছবিতে চাপলে যেখানে যাবে। */
window.PT_ADS = {
  site: 'https://patheyobygunjoron.github.io/',
  intervalMs: 5000,                                   /* প্রতি কত মিলিসেকেন্ডে নিজে থেকে পরের ছবি */
  carousel: [
    { img: 'ads/img/carousel-1.png', alt: 'পাথেয় বাই গুঞ্জরণ — চিরস্থায়ী সফরের পরম সঙ্গী', link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-2.png', alt: 'নামাজের সময়সূচি — প্রতিটি ওয়াক্তের সঠিক সময়',       link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-3.png', alt: 'কুরআন শরিফ — ১১৪ সূরা, ৩০ পারা এক অ্যাপে',           link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-4.png', alt: 'হাদিস শরিফ — সিহাহ সিত্তার ৬ কিতাব',                  link: 'https://patheyobygunjoron.github.io/' },
    { img: 'ads/img/carousel-5.png', alt: 'আমল, তাসবিহ, কিবলা ও উইজেট — সামনে আসছে দোয়া',         link: 'https://patheyobygunjoron.github.io/' }
  ],
  footer: { img: 'ads/img/footer.png', alt: 'পাথেয় বাই গুঞ্জরণ — আজই ডাউনলোড করুন', link: 'https://patheyobygunjoron.github.io/' }
};
