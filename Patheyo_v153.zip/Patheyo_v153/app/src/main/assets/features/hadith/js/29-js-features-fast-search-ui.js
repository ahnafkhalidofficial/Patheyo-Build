/* ===== js/features/fast-search-ui.js ===== */
/*!
 * js/features/fast-search-ui.js -- ভাসমান সার্চ আইকন + কিতাবের ভিতরের লাইভ সার্চ পেজ
 *
 * Provides : App.FsUi { open, close, isOpen }
 * Needs    : services/fast-search, core/dom, features/chapter-reader, features/navigation
 *
 *  - অধ্যায়ের তালিকায় স্ক্রোল করে নিচে নামলে, আর পড়ার পেজে সব সময় ডান-নিচে সার্চ আইকন দেখা যায়
 *  - আইকনে চাপলে পুরো স্ক্রিনের সার্চ পেজ খোলে; লিখতে লিখতেই ফল আসে (ইনডেক্স মেমরিতে, কয়েক মিলিসেকেন্ড)
 *  - সার্চ শুধু খোলা কিতাবের ভিতরেই
 *  - ফোনের back চাপলে আগে সার্চ পেজ বন্ধ হয় (নিজস্ব history এন্ট্রি)
 */
(function (App) {
  "use strict";

  var SEARCH_SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>';
  var BACK_SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"></path></svg>';
  var X_SVG = '<svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"></path></svg>';

  var PAGE = 25;                // একবারে কয়টা ফল আঁকা হবে
  var LIMIT = 300;              // ইঞ্জিন থেকে সর্বোচ্চ কয়টা ফল
  var fab, ov, input, clearBtn, statusEl, listEl, chipsEl, hintEl;
  var opened = false;
  var last = null;              // শেষ সার্চের ফল
  var shown = 0;
  var raf = 0, ldTimer = 0;
  var pendingNav = null, navTimer = 0;
  var savedQuery = {};          // কিতাব -> শেষ লেখা

  function esc(s){ return App.escapeHtml(s); }
  function bookObj(){ return App.loadedBook && App.loadedBook.id === App.curBookId ? App.loadedBook : null; }

  // ---------------------------------------------------------------- DOM
  function build(){
    fab = document.createElement('button');
    fab.id = 'hs-fab'; fab.type = 'button'; fab.className = 'hs-fab hs-off';
    fab.setAttribute('aria-label', 'কিতাবের ভিতরে খুঁজুন');
    fab.innerHTML = SEARCH_SVG;
    document.body.appendChild(fab);

    ov = document.createElement('div');
    ov.id = 'hs-overlay'; ov.className = 'hs-overlay hidden';
    ov.setAttribute('role', 'dialog');
    ov.innerHTML =
      '<div class="hs-bar">' +
        '<button type="button" class="hs-back" aria-label="ফিরে যান">' + BACK_SVG + '</button>' +
        '<div class="hs-field">' + SEARCH_SVG.replace('class="icon"', 'class="icon icon-sm hs-fi"') +
          '<input id="hs-input" type="search" inputmode="search" enterkeyhint="search" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="অনুবাদ, হাদীসের অংশ বা নম্বর লিখুন">' +
          '<button type="button" class="hs-clear" aria-label="মুছুন">' + X_SVG + '</button>' +
        '</div>' +
      '</div>' +
      '<div class="hs-scroll" id="hs-scroll">' +
        '<div class="hs-status" id="hs-status"></div>' +
        '<div class="hs-chips hidden" id="hs-chips"></div>' +
        '<div class="hs-list" id="hs-list"></div>' +
        '<div class="hs-hint" id="hs-hint"></div>' +
      '</div>';
    document.body.appendChild(ov);

    input = ov.querySelector('#hs-input');
    clearBtn = ov.querySelector('.hs-clear');
    statusEl = ov.querySelector('#hs-status');
    listEl = ov.querySelector('#hs-list');
    chipsEl = ov.querySelector('#hs-chips');
    hintEl = ov.querySelector('#hs-hint');

    fab.addEventListener('click', function(){ open(); });
    ov.querySelector('.hs-back').addEventListener('click', function(){ requestClose(); });
    clearBtn.addEventListener('click', function(){ input.value = ''; run(); input.focus(); });
    input.addEventListener('input', schedule);
    input.addEventListener('keydown', function(e){
      if (e.key === 'Enter'){ e.preventDefault(); input.blur(); }
    });
    listEl.addEventListener('click', onListClick);
    chipsEl.addEventListener('click', onListClick);
    ov.querySelector('#hs-scroll').addEventListener('scroll', onScroll, { passive: true });
    ov.querySelector('#hs-scroll').addEventListener('touchstart', function(){ if (document.activeElement === input) input.blur(); }, { passive: true });
  }

  // ---------------------------------------------------------------- ভাসমান আইকন কখন দেখা যাবে
  function syncFab(){
    if (!fab) return;
    var v = App.state.view, show = false;
    if (opened) show = false;
    else if (v === 'chapter') show = !App.els.chapterPanel.classList.contains('hidden');
    else if (v === 'book') show = App.bookBodyVisible() && !App.els.bookPanel.classList.contains('hidden') &&
                                  App.els.bookResults.classList.contains('hidden') && window.pageYOffset > 220;
    if (App.els.bmModalOverlay && !App.els.bmModalOverlay.classList.contains('hidden')) show = false;
    fab.classList.toggle('hs-off', !show);
  }
  var fabRaf = 0;
  function syncSoon(){ if (fabRaf) return; fabRaf = requestAnimationFrame(function(){ fabRaf = 0; syncFab(); }); }

  // ---------------------------------------------------------------- খোলা / বন্ধ
  function isOpen(){ return opened; }

  function open(){
    var book = bookObj();
    if (!book || opened) return;
    opened = true;
    try{ history.pushState({ qview: App.state.view, qsearch: 1 }, ''); } catch(e){}
    ov.classList.remove('hidden');
    document.documentElement.classList.add('hs-lock');
    syncFab();
    var st = App.FastSearch.prepare(book, onIndexProgress);
    input.value = savedQuery[book.id] || '';
    run();
    // কিবোর্ড সঙ্গে সঙ্গে ওঠে
    setTimeout(function(){ try{ input.focus(); input.select(); } catch(e){} }, 30);
    void st;
  }

  // UI থেকে বন্ধ: history.back() → popstate থেকে আসল বন্ধ
  function requestClose(){
    if (!opened) return;
    if (history.state && history.state.qsearch){ history.back(); } else { hide(); }
  }

  function hide(){
    if (!opened) return;
    var book = bookObj();
    if (book) savedQuery[book.id] = input.value;
    opened = false;
    ov.classList.add('hidden');
    document.documentElement.classList.remove('hs-lock');
    try{ input.blur(); } catch(e){}
    syncFab();
  }

  // ফোনের back বোতাম
  var origPop = App.onPopState;
  App.onPopState = function(e){
    if (pendingNav){
      var fn = pendingNav; pendingNav = null; clearTimeout(navTimer);
      hide();
      fn();
      return;
    }
    if (opened){ hide(); return; }
    var r = origPop.apply(this, arguments);
    syncSoon();
    return r;
  };

  // ফলে চাপলে: সার্চ পেজ বন্ধ করে (history এন্ট্রিসহ) হাদীসে যাই
  function go(fn){
    if (history.state && history.state.qsearch){
      pendingNav = fn;
      navTimer = setTimeout(function(){ if (pendingNav){ var f = pendingNav; pendingNav = null; hide(); f(); } }, 400);
      history.back();
    } else { hide(); fn(); }
  }

  function gotoSeq(seq){
    var book = bookObj();
    if (!book) return;
    var c = App.chapterOfSeq ? App.chapterOfSeq(book, seq) : null;
    if (c && typeof c === 'object') c = c.c;
    if (c == null) c = last && last.bySeq ? last.bySeq[seq] : 0;
    go(function(){ App.openChapter(c, { origin: App.state.view === 'chapter' ? App.state.chapterOrigin : 'book', seq: seq }); });
  }
  function gotoChapter(c){ go(function(){ App.openChapter(c, { origin: App.state.view === 'chapter' ? App.state.chapterOrigin : 'book' }); }); }

  function onListClick(e){
    var t = e.target.closest ? e.target.closest('[data-seq],[data-chap]') : null;
    if (!t) return;
    if (t.hasAttribute('data-seq')) gotoSeq(parseInt(t.getAttribute('data-seq'), 10));
    else gotoChapter(parseInt(t.getAttribute('data-chap'), 10));
  }

  // ---------------------------------------------------------------- সার্চ চালানো
  function schedule(){
    clearBtn.classList.toggle('show', !!input.value);
    if (raf) return;
    raf = requestAnimationFrame(function(){ raf = 0; run(); });
  }

  function onIndexProgress(p, done){
    if (!opened) return;
    if (done){ run(); return; }
    // আংশিক ইনডেক্স হলেও (বাংলা আগে তৈরি হয়) ফল দেখাই
    if (ldTimer) return;
    ldTimer = setTimeout(function(){ ldTimer = 0; if (opened) run(true); }, 250);
  }

  function run(fromProgress){
    clearBtn.classList.toggle('show', !!input.value);
    var book = bookObj();
    if (!book) return;
    var q = input.value;
    var st = App.FastSearch.get(book);
    if (!st){ App.FastSearch.prepare(book, onIndexProgress); st = App.FastSearch.get(book); }
    var res = App.FastSearch.search(book, q, { limit: LIMIT });
    last = res;
    chipsEl.innerHTML = '';
    chipsEl.classList.add('hidden');
    listEl.innerHTML = '';
    hintEl.innerHTML = '';
    shown = 0;
    document.getElementById('hs-scroll').scrollTop = 0;

    var prog = st ? Math.round((st.progress || 0) * 100) : 0;
    var building = !(st && st.ready);

    if (res.mode === 'empty'){
      statusEl.innerHTML = building ? '<span class="hs-spin"></span> সার্চ প্রস্তুত হচ্ছে… ' + App.bn(prog) + '%' : '';
      hintEl.innerHTML = hintHtml();
      return;
    }

    if (res.chapters && res.chapters.length){
      var h = '<div class="hs-chips-t">অধ্যায়</div>';
      res.chapters.forEach(function(c){
        var ch = book.data.ch[c];
        h += '<button type="button" class="hs-chip" data-chap="' + c + '">' + esc(ch.t || ('অধ্যায় ' + App.bn(c + 1))) + '</button>';
      });
      chipsEl.innerHTML = h; chipsEl.classList.remove('hidden');
    }

    var total = res.total || res.items.length;
    var s = '';
    if (res.items.length){
      s = '<b>' + App.bn(total) + '</b> টি হাদীস পাওয়া গেছে';
      if (res.relaxed) s += ' · <span class="hs-soft">কাছাকাছি মিল</span>';
      s += ' <span class="hs-ms">' + App.bn(Math.max(1, Math.round(res.ms))) + ' মি.সে.</span>';
    } else if (!building){
      s = 'কিছু পাওয়া যায়নি';
    }
    if (building) s += (s ? ' ' : '') + '<span class="hs-spin"></span> <span class="hs-soft">সার্চ প্রস্তুত হচ্ছে… ' + App.bn(prog) + '%</span>';
    statusEl.innerHTML = s;

    if (!res.items.length && !building){
      hintEl.innerHTML = '<div class="hs-empty"><div class="hs-empty-t">কোনো হাদীস মেলেনি</div>' +
        '<div class="hs-empty-s">অন্য শব্দ দিয়ে বা শব্দের ছোট অংশ লিখে দেখুন।<br>হাদীস নম্বরও লিখতে পারেন (যেমন: ১২৩)।</div></div>';
      return;
    }
    renderMore();
  }

  function hintHtml(){
    return '<div class="hs-empty"><div class="hs-empty-ic">' + SEARCH_SVG + '</div>' +
      '<div class="hs-empty-t">এই কিতাবের ভিতরে খুঁজুন</div>' +
      '<div class="hs-empty-s">অনুবাদের যেকোনো শব্দ, হাদীসের একটু অংশ, আরবি শব্দ বা হাদীস নম্বর লিখুন — লেখার সাথে সাথেই ফল আসবে।</div>' +
      '<div class="hs-ex"><span>নামাজ ফজর</span><span>১২৩</span><span>সিয়াম</span></div></div>';
  }

  function onScroll(){
    var sc = ov.querySelector('#hs-scroll');
    if (last && shown < last.items.length && sc.scrollHeight - sc.scrollTop - sc.clientHeight < 700) renderMore();
  }

  // ---------------------------------------------------------------- ফল আঁকা
  function mark(text, ranges){
    var out = '', pos = 0;
    for (var i = 0; i < ranges.length; i++){
      var a = ranges[i][0], b = ranges[i][1];
      if (a < pos) continue;
      out += esc(text.slice(pos, a)) + '<mark class="hs-mark">' + esc(text.slice(a, b)) + '</mark>';
      pos = b;
    }
    return out + esc(text.slice(pos));
  }

  // মিলের চারপাশের অংশ কেটে নিই
  function snippet(text, ranges, max){
    if (!text) return '';
    if (!ranges.length || text.length <= max) {
      var t = text.length > max ? text.slice(0, max) + '…' : text;
      var r2 = ranges.filter(function(r){ return r[1] <= t.length; });
      return mark(t, r2);
    }
    var first = ranges[0][0];
    var from = Math.max(0, first - Math.floor(max * 0.35));
    if (from > 0){ var sp = text.indexOf(' ', from); if (sp > -1 && sp < first) from = sp + 1; }
    var to = Math.min(text.length, from + max);
    var piece = text.slice(from, to);
    var rr = [];
    ranges.forEach(function(r){ if (r[0] >= from && r[1] <= to) rr.push([r[0] - from, r[1] - from]); });
    return (from > 0 ? '…' : '') + mark(piece, rr) + (to < text.length ? '…' : '');
  }

  function cardHtml(it, res, book){
    var h = it.h, mode = res.mode;
    var text = (mode === 'ar') ? h[1] : h[2];
    var body;
    if (mode === 'num'){ body = esc((h[2] || h[1] || '').slice(0, 170)) + ((h[2] || h[1] || '').length > 170 ? '…' : ''); }
    else {
      var rg = App.FastSearch.spans(text || '', res.terms, mode);
      body = snippet(text || '', rg, mode === 'ar' ? 150 : 210);
      if (mode === 'ar') body = App.wrapWaqf(body);
    }
    var ch = book.data.ch[it.c];
    var arCls = (mode === 'ar') ? ' hs-ar' : '';
    return '<button type="button" class="hs-card" data-seq="' + it.seq + '">' +
      '<div class="hs-ctop"><span class="hs-num">হাদীস ' + App.bn(h[0]) + '</span>' +
      '<span class="hs-ch">' + esc(ch ? (ch.t || '') : '') + '</span></div>' +
      '<div class="hs-body' + arCls + '">' + body + '</div></button>';
  }

  function renderMore(){
    var book = bookObj();
    if (!book || !last) return;
    var end = Math.min(last.items.length, shown + PAGE), html = [];
    for (var i = shown; i < end; i++) html.push(cardHtml(last.items[i], last, book));
    shown = end;
    listEl.insertAdjacentHTML('beforeend', html.join(''));
    if (shown < last.items.length){
      hintEl.innerHTML = '';
    } else if ((last.total || 0) > last.items.length){
      hintEl.innerHTML = '<div class="hs-more">প্রথম ' + App.bn(last.items.length) + 'টি দেখানো হয়েছে — আরও নির্দিষ্ট করে লিখুন</div>';
    }
  }

  // ---------------------------------------------------------------- ইনডেক্স আগেভাগে তৈরি: কিতাব খুললেই পেছনে শুরু
  var origLoad = App.loadBook;
  if (typeof origLoad === 'function'){
    App.loadBook = function(){
      var p = origLoad.apply(this, arguments);
      return p.then(function(b){
        try{ setTimeout(function(){ App.FastSearch.prepare(b); }, 350); } catch(e){}
        return b;
      });
    };
  }

  // ---------------------------------------------------------------- শুরু
  function init(){
    build();
    window.addEventListener('scroll', syncSoon, { passive: true });
    window.addEventListener('resize', syncSoon);
    if (window.MutationObserver){
      var mo = new MutationObserver(syncSoon);
      [App.els.bookPanel, App.els.chapterPanel, App.els.bookBody, App.els.bookResults, App.els.bmModalOverlay].forEach(function(el){
        if (el) mo.observe(el, { attributes: true, attributeFilter: ['class'] });
      });
    }
    syncFab();
  }

  App.FsUi = { open: open, close: requestClose, isOpen: isOpen };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})(window.HadithApp = window.HadithApp || {});
