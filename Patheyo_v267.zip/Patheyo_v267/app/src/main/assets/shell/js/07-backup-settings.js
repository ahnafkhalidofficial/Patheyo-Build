/* সেটিংস: (১) পুরো-অ্যাপ ব্যাকআপ ও রিস্টোর  (২) পড়ার লেখার সাইজ (কুরআন / হাদিস)।
   ডেটা সবই ফোনের localStorage-এ থাকে — ব্যাকআপ সেটাকে একটা JSON ফাইলে নেয় (ফাইলের ভেতরে checksum থাকে), রিস্টোর সেটা ফেরত বসায়।
   নেটিভ ব্রিজ PatheyoBackup (Kotlin) ফাইল সেভ/শেয়ার/বাছাই করে; ব্রাউজারে (ব্রিজ নেই) ডাউনলোড/ফাইল-ইনপুট দিয়ে চলে। */
(function () {
  'use strict';
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function jget(k, d) { try { var v = lsGet(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }
  function bridge() { return window.PatheyoBackup || null; }

  /* =====================================================================
     ১) পড়ার লেখার সাইজ — CSS zoom দিয়ে ফিচার-পেজের ভেতরে (ফ্রেমে) বসে
     ===================================================================== */
  var FS_KEY = 'pt_fs_v1';
  var FS_DEF = { qa: 100, qb: 100, ha: 100, hb: 100, da: 100, dr: 100, db: 100 };
  var FS_ROWS = [
    ['qa', 'কুরআনের আরবি', '#verses,#web-verses,.tr-arabic'],
    ['qb', 'কুরআনের বাংলা অনুবাদ', '.tr-bn'],
    ['ha', 'হাদিসের আরবি', '.hd-ar'],
    ['hb', 'হাদিসের বাংলা', '.hd-bn'],
    ['da', 'দোয়ার আরবি', '.dar'],
    ['dr', 'দোয়ার উচ্চারণ', '.dtr'],
    ['db', 'দোয়ার অর্থ', '.dbn']
  ];
  function fsGet() {
    var s = jget(FS_KEY, {}), o = {};
    FS_ROWS.forEach(function (r) { var v = parseInt(s[r[0]], 10); o[r[0]] = isNaN(v) ? 100 : Math.min(180, Math.max(80, v)); });
    return o;
  }
  function fsCss(v) {
    var css = '';
    FS_ROWS.forEach(function (r) { if (v[r[0]] !== 100) css += r[2] + '{zoom:' + (v[r[0]] / 100) + '}\n'; });
    return css;
  }
  function applyTo(doc, v) {
    try {
      if (!doc || !doc.head) return;
      var st = doc.getElementById('pt-read-sizes');
      var css = fsCss(v || fsGet());
      if (!css) { if (st) st.remove(); return; }
      if (!st) { st = doc.createElement('style'); st.id = 'pt-read-sizes'; doc.head.appendChild(st); }
      if (st.textContent !== css) st.textContent = css;
    } catch (e) {}
  }
  window.__ptApplyReadSizes = function (doc) { applyTo(doc, null); };     /* ফিচার-পেজ খোলার সময় শেল (05-pages-controller.js) এটা ডাকে */
  function applyAllFrames() {
    var v = fsGet();
    Array.prototype.forEach.call(document.querySelectorAll('iframe'), function (f) { try { applyTo(f.contentDocument, v); } catch (e) {} });
  }

  function buildSizes() {
    var acc = $('rs-acc'); if (!acc) return;
    var v = fsGet();
    FS_ROWS.forEach(function (r) {                    /* v257: প্রতিটা সারি তার গ্রুপে (q কুরআন / h হাদিস / d দোয়া) বসে */
      var box = acc.querySelector('.rs-rows[data-g="' + r[0].charAt(0) + '"]'); if (!box) return;
      box.insertAdjacentHTML('beforeend', '<div class="rs-row" data-k="' + r[0] + '"><div class="rs-l"><b>' + r[1] + '</b><span data-v>' + bn(v[r[0]]) + '%</span></div>' +
        '<div class="rs-c"><button type="button" class="rs-b" data-d="-5" aria-label="ছোট করুন">−</button>' +
        '<input type="range" min="80" max="180" step="5" value="' + v[r[0]] + '" aria-label="' + r[1] + '">' +
        '<button type="button" class="rs-b" data-d="5" aria-label="বড় করুন">+</button></div></div>');
    });
    Array.prototype.forEach.call(acc.querySelectorAll('.rs-real[data-tile]'), function (el) {      /* v258: হোমের টাইলের আসল আইকন */
      var t = document.querySelectorAll('.module-grid .module-tile')[+el.getAttribute('data-tile')], sv = t && t.querySelector('.module-tile-icon svg');
      if (sv) el.innerHTML = sv.outerHTML;
    });
    paintSizes();
    acc.addEventListener('input', function (e) { var row = e.target.closest('.rs-row'); if (row && e.target.type === 'range') setSize(row.getAttribute('data-k'), +e.target.value); });
    acc.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.rs-b') : null; if (!b) return;
      var row = b.closest('.rs-row'), k = row.getAttribute('data-k'); setSize(k, fsGet()[k] + (+b.getAttribute('data-d')));
    });
    /* গুটানো/খোলা: প্রধান সারি পুরোটা খোলে; ভেতরে একবারে একটা গ্রুপ খোলা থাকে */
    function setOpen(btn, panel, on) { btn.setAttribute('aria-expanded', on ? 'true' : 'false'); panel.classList.toggle('is-open', on); }
    var main = $('rs-main');
    if (main) main.addEventListener('click', function () {
      var on = main.getAttribute('aria-expanded') !== 'true';
      setOpen(main, acc, on);
      if (!on) Array.prototype.forEach.call(acc.querySelectorAll('.rs-grp'), function (g) { setOpen(g.querySelector('.rs-gh'), g.querySelector('.rs-collapse'), false); });
    });
    Array.prototype.forEach.call(acc.querySelectorAll('.rs-grp'), function (g) {
      var h = g.querySelector('.rs-gh'), pn = g.querySelector('.rs-collapse');
      h.addEventListener('click', function () {
        var on = h.getAttribute('aria-expanded') !== 'true';
        Array.prototype.forEach.call(acc.querySelectorAll('.rs-grp'), function (o) { if (o !== g) setOpen(o.querySelector('.rs-gh'), o.querySelector('.rs-collapse'), false); });
        setOpen(h, pn, on);
        if (on) setTimeout(function () { try { h.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} }, 320);
      });
    });
    /* v259: ফিচার পেজের "Aa" বাটন থেকে সরাসরি আসা — পুরোটা খুলে সংশ্লিষ্ট গ্রুপ (q/h/d) খোলে, জায়গায় স্ক্রল করে, একটু হাইলাইট */
    window.__ptReadSize = function (g) {
      var grp = acc.querySelector('.rs-grp[data-g="' + g + '"]'); if (!grp || !main) return;
      setOpen(main, acc, true);
      Array.prototype.forEach.call(acc.querySelectorAll('.rs-grp'), function (o) { setOpen(o.querySelector('.rs-gh'), o.querySelector('.rs-collapse'), o === grp); });
      var h = grp.querySelector('.rs-gh');
      setTimeout(function () {
        try {
          var body = document.querySelector('#settings-overlay .page-overlay-body'), sec = $('rs-section');
          var top = sec.getBoundingClientRect().top - body.getBoundingClientRect().top + body.scrollTop - 10;
          body.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
        } catch (e) {}
        h.classList.remove('rs-pulse'); void h.offsetWidth; h.classList.add('rs-pulse');
      }, 120);
    };
    var reset = $('rs-reset'); if (reset) reset.addEventListener('click', function () { lsSet(FS_KEY, JSON.stringify(FS_DEF)); paintSizes(); applyAllFrames(); });
  }
  function setSize(k, val) {
    var v = fsGet(); v[k] = Math.min(180, Math.max(80, Math.round(val / 5) * 5));
    lsSet(FS_KEY, JSON.stringify(v)); paintSizes(); applyAllFrames();
  }
  function paintSizes() {
    var v = fsGet();
    FS_ROWS.forEach(function (r) {
      var row = document.querySelector('.rs-row[data-k="' + r[0] + '"]'); if (!row) return;
      var inp = row.querySelector('input'); inp.value = v[r[0]];
      inp.style.setProperty('--p', ((v[r[0]] - 80) / 100 * 100) + '%');
      row.querySelector('[data-v]').textContent = bn(v[r[0]]) + '%' + (v[r[0]] === 100 ? ' (স্বাভাবিক)' : '');
    });
    ['qa', 'qb', 'ha', 'hb', 'da', 'dr', 'db'].forEach(function (k) { var p = $('rs-p-' + k); if (p) p.style.zoom = v[k] / 100; });
    var SUM = { q: [['আরবি', 'qa'], ['বাংলা', 'qb']], h: [['আরবি', 'ha'], ['বাংলা', 'hb']], d: [['আরবি', 'da'], ['উচ্চারণ', 'dr'], ['অর্থ', 'db']] }, changed = false;
    Object.keys(SUM).forEach(function (g) {
      var el = document.querySelector('[data-sum="' + g + '"]'); if (!el) return;
      var diff = SUM[g].some(function (x) { return v[x[1]] !== 100; });
      if (diff) changed = true;
      el.textContent = diff ? SUM[g].map(function (x) { return x[0] + ' ' + bn(v[x[1]]) + '%'; }).join(' · ') : (g === 'd' ? 'আরবি, উচ্চারণ ও অর্থ' : g === 'h' ? 'আরবি ও বাংলা' : 'আরবি ও বাংলা অনুবাদ');
    });
    var ms = $('rs-main-s'); if (ms) ms.textContent = changed ? 'আপনার পছন্দের সাইজ চালু আছে' : 'কুরআন, হাদিস ও দোয়ার লেখা নিজের মতো ছোট-বড় করুন';
  }

  /* =====================================================================
     ২) ব্যাকআপ ও রিস্টোর
     ===================================================================== */
  var KEYS = [     /* ইউজারের নিজের ডেটা / পছন্দ — ক্যাশ, ডাউনলোডের অবস্থা, অস্থায়ী ফ্ল্যাগ ইচ্ছা করেই বাদ */
    'amol_report_state',
    'tz3_counts', 'tz3_daily', 'tz3_goal', 'tz3_hist', 'tz3_mine', 'tz3_fi', 'tz3_sm', 'tz3_sn', 'tz3_sound', 'tz3_tab', 'tz3_theme',
    'pt_dua_fav', 'pt_dua_custom', 'pt_dua_fs', 'pt_dua_size', 'dua_theme', 'pt_share_card', 'pt_fs_v1',
    'quran-bookmarks', 'quran-last-read', 'quran-khatm', 'pt_qa_prefs', 'quran-theme', 'quran-tr-mode', 'quran-tr-show-arabic', 'quran-fn-hint-seen',
    'hadith-bookmarks', 'hadith-last-read', 'hadith-theme',
    'currentMadhab', 'customTasbihList', 'hijriAdjustment', 'nafalConfigs', 'prayerMethodId', 'waqtConfigs', 'waqtMinuteOffsets', 'userPrayerMethodId',
    'pathey-theme', 'ns_theme', 'pt_profile',
    'pt_zakat', 'pt_asma_memo', 'quran-pf-theme'      /* v247: জাকাতের হিসাব, আসমাউল হুসনার "অর্থ লুকান" পছন্দ, মুসহাফের থিম — আগে ক্লাউডে যেত না */
  ];
  /* v247: নতুন ফিচারের ইউজার-ডেটা ক্লাউডে নেওয়ার সবচেয়ে সহজ নিয়ম — localStorage-এর চাবির নাম "ptu_" দিয়ে শুরু করুন (যেমন ptu_diary)।
     এই প্রিফিক্সের সব চাবি নিজে থেকেই ব্যাকআপ-ফাইলে ও অ্যাকাউন্টের ক্লাউডে যায়, এখানে আলাদা করে যোগ করতে হয় না।
     ডিভাইসের নিজস্ব জিনিস (ক্যাশ, ডাউনলোডের অবস্থা, অস্থায়ী ফ্ল্যাগ) "ptu_" দেবেন না। নেটিভ (Kotlin) ডেটার জন্য: sync/NativeSync.kt */
  var UP = 'ptu_';
  var NK = 'pt_native_v1';      /* নেটিভ ডেটার (নোট, রিমাইন্ডার, তারিখ-কার্ড ও উইজেট-হাবের সেটিংস) JSON — PatheyoNativeSync.exportAll() */
  function userKeys() {         /* "ptu_" চাবিগুলো, নাম ধরে সাজানো (সব ফোনে একই ক্রম — ফিঙ্গারপ্রিন্ট স্থির থাকে) */
    var a = [];
    try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k && k.indexOf(UP) === 0) a.push(k); } } catch (e) {}
    return a.sort();
  }
  function allKeys() { return KEYS.concat(userKeys()); }
  function isSyncKey(k) { return KEYS.indexOf(k) >= 0 || (typeof k === 'string' && k.indexOf(UP) === 0 && k.length > UP.length && k.length <= 80); }
  function nat() { try { var n = window.PatheyoNativeSync; return n && typeof n.exportAll === 'function' ? n : null; } catch (e) { return null; } }
  var LAST_KEY = 'pt_last_backup', UNDO_KEY = 'pt_backup_undo', PENDING_KEY = 'pt_restore_pending';

  function sum32(str) {          /* FNV-1a ৩২-বিট — ফাইল ভাঙা বা হাতে বদলানো ধরার জন্য */
    var h = 0x811c9dc5;
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
    return ('00000000' + h.toString(16)).slice(-8);
  }
  function collect() {
    var data = {};
    allKeys().forEach(function (k) { var v = lsGet(k); if (v != null) data[k] = v; });
    var n = nat();                               /* v247: নেটিভ ডেটা (নোট ইত্যাদি) — একই ব্যাকআপে, একই ক্লাউডে */
    if (n) { try { var s = n.exportAll(); if (s) data[NK] = String(s); } catch (e) {} }
    return data;
  }
  function stamp(d) { d = d || new Date(); function p(n) { return ('0' + n).slice(-2); } return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }
  function makeBackup() {
    var data = collect(), body = JSON.stringify(data);
    return JSON.stringify({ app: 'patheyo', format: 1, created: new Date().toISOString(), keys: Object.keys(data).length, sum: sum32(body), data: data });
  }
  function fname() { return 'patheyo_backup_' + stamp() + '.json'; }

  /* ফাইলে কী কী আছে — মানুষের পড়ার মতো সংক্ষেপ */
  function describe(data) {
    var parts = [];
    function j(k) { try { return k in data ? JSON.parse(data[k]) : null; } catch (e) { return null; } }
    var am = j('amol_report_state');
    if (am && am.days) {
      var dn = Object.keys(am.days).length;
      parts.push('আমলের রিপোর্ট: ' + bn(dn) + ' দিন');
      var q = am.qaza, qn = 0; if (q && q.base) Object.keys(q.base).forEach(function (k) { qn += parseInt(q.base[k], 10) || 0; });
      if (qn || (q && q.log && q.log.length)) parts.push('কাজা নামাজের হিসাব');
      if (am.customAmals && am.customAmals.length) parts.push('নিজস্ব আমল: ' + bn(am.customAmals.length) + 'টি');
    }
    var th = j('tz3_hist'); if (th) parts.push('তাসবিহের ইতিহাস: ' + bn(Object.keys(th).length) + ' দিন');
    var tm = j('tz3_mine'); if (tm && tm.length) parts.push('আমার জিকির: ' + bn(tm.length) + 'টি');
    var df = j('pt_dua_fav'); if (df && df.length) parts.push('প্রিয় দোয়া: ' + bn(df.length) + 'টি');
    function cnt(x) { if (!x) return 0; if (Array.isArray(x)) return x.length; if (typeof x === 'object') return Object.keys(x).length; return 0; }
    var qb = cnt(j('quran-bookmarks')); if (qb) parts.push('কুরআনের বুকমার্ক: ' + bn(qb) + 'টি');
    var hb = cnt(j('hadith-bookmarks')); if (hb) parts.push('হাদিসের বুকমার্ক: ' + bn(hb) + 'টি');
    if ('waqtConfigs' in data || 'nafalConfigs' in data || 'prayerMethodId' in data) parts.push('নামাজের সময়ের সেটিংস');
    if (NK in data) { var nv = j(NK); var nn = nv && nv.notes ? nv.notes.length : 0; if (nn) parts.push('ক্যালেন্ডারের নোট: ' + bn(nn) + 'টি'); }
    if ('pt_zakat' in data) parts.push('জাকাতের হিসাব');
    if ('pathey-theme' in data) parts.push('থিম ও পড়ার পছন্দ');
    return parts;
  }

  /* ---------- UI ---------- */
  function msg(t, kind) {
    var m = $('bk-msg'); if (!m) return;
    m.textContent = t; m.className = 'bk-msg' + (kind ? ' ' + kind : '') + (t ? ' show' : '');
    clearTimeout(msg._t); if (t) { msg._t = setTimeout(function () { m.classList.remove('show'); }, 8000); try { m.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} }
  }
  function fmtDate(iso) {
    var M = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    var d = new Date(iso); if (isNaN(d)) return '';
    return bn(d.getDate()) + ' ' + M[d.getMonth()] + ' ' + bn(d.getFullYear());
  }
  function paintSummary() {
    var box = $('bk-sum'); if (!box) return;
    var parts = describe(collect());
    box.innerHTML = parts.length ? parts.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') : '<li class="mute">এখনো ব্যাকআপ করার মতো কিছু জমেনি</li>';
    var last = lsGet(LAST_KEY), el = $('bk-last');
    if (el) el.textContent = last ? 'শেষ ব্যাকআপ: ' + fmtDate(last) : 'এখনো ব্যাকআপ নেওয়া হয়নি';
    var undo = $('bk-undo'); if (undo) undo.hidden = !lsGet(UNDO_KEY);
    var sv = $('bk-save'); if (sv) { var b = bridge(); sv.style.display = (b && typeof b.canSave === 'function' && !b.canSave()) ? 'none' : ''; }
  }
  function done() { lsSet(LAST_KEY, new Date().toISOString()); paintSummary(); }

  function doSave() {
    var text = makeBackup(), b = bridge(), name = fname();
    if (b && typeof b.saveFile === 'function') {
      var path = ''; try { path = b.saveFile(name, text); } catch (e) {}
      if (path) { done(); msg('ব্যাকআপ সেভ হয়েছে: ' + path, 'ok'); } else msg('সেভ করা যায়নি — "শেয়ার করুন" দিয়ে ফাইলটা পাঠিয়ে রাখুন', 'err');
      return;
    }
    try {                       /* ব্রাউজার */
      var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name;
      document.body.appendChild(a); a.click(); a.remove(); done(); msg('ব্যাকআপ ডাউনলোড হচ্ছে', 'ok');
    } catch (e) { msg('সেভ করা যায়নি', 'err'); }
  }
  function doShare() {
    var text = makeBackup(), b = bridge(), name = fname();
    if (b && typeof b.shareFile === 'function') {
      var ok = false; try { ok = b.shareFile(name, text); } catch (e) {}
      if (ok) { done(); msg('শেয়ার-শিট খুলেছে — Telegram, Google Drive বা Gmail-এ নিজেকে পাঠিয়ে রাখুন', 'ok'); } else msg('শেয়ার করা যায়নি', 'err');
      return;
    }
    doSave();
  }

  /* রিস্টোর: ফাইল বাছাই → যাচাই → নিশ্চিত → (পরের লোডে) বসানো */
  var picked = null;
  function pick() {
    var b = bridge();
    if (b && typeof b.pickFile === 'function') { var ok = false; try { ok = b.pickFile(); } catch (e) {} if (!ok) msg('ফাইল বাছাই খোলা যায়নি', 'err'); return; }
    var inp = $('bk-file'); if (inp) inp.click();
  }
  window.__ptBackupPicked = function (text, name, err) {
    if (err) { if (err !== 'cancel') msg(err === 'big' ? 'ফাইলটা অনেক বড় — এটা পাথেয়-ব্যাকআপ নয়' : 'ফাইলটা পড়া যায়নি', 'err'); return; }
    inspect(text, name);
  };
  function inspect(text, name) {
    var o; try { o = JSON.parse(text); } catch (e) { msg('এটা পাথেয়-ব্যাকআপ ফাইল নয় (পড়া যায়নি)', 'err'); return; }
    if (!o || o.app !== 'patheyo' || o.format !== 1 || !o.data || typeof o.data !== 'object') { msg('এটা পাথেয়-ব্যাকআপ ফাইল নয়', 'err'); return; }
    if (sum32(JSON.stringify(o.data)) !== o.sum) { msg('ফাইলটা ভাঙা বা হাতে বদলানো — নিরাপত্তার জন্য রিস্টোর করা হবে না', 'err'); return; }
    var data = {};
    Object.keys(o.data).forEach(function (k) { if ((isSyncKey(k) || k === NK) && typeof o.data[k] === 'string') data[k] = o.data[k]; });
    var n = Object.keys(data).length;
    if (!n) { msg('ফাইলে ফিরিয়ে আনার মতো কিছু নেই', 'err'); return; }
    picked = { data: data, created: o.created, name: name };
    var cf = $('bk-confirm'); if (!cf) return;
    $('bk-c-date').textContent = o.created ? 'ব্যাকআপের তারিখ: ' + fmtDate(o.created) : '';
    $('bk-c-list').innerHTML = describe(data).map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('');
    cf.hidden = false; cf.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  function confirmRestore() {
    if (!picked) return;
    var snap = collect();      /* আগের অবস্থা রেখে দিই — ভুল হলে "রিস্টোর বাতিল করুন" দিয়ে ফেরা যায় */
    var undoSaved = lsSet(UNDO_KEY, JSON.stringify({ at: new Date().toISOString(), data: snap }));
    if (!lsSet(PENDING_KEY, JSON.stringify({ data: picked.data, nativeMerge: true }))) { msg('জায়গা কম — রিস্টোর শুরু করা যায়নি', 'err'); return; }
    msg(undoSaved ? 'রিস্টোর হচ্ছে… অ্যাপ নতুন করে খুলছে' : 'রিস্টোর হচ্ছে (বাতিলের সুবিধা ছাড়া)…', 'ok');
    setTimeout(function () { location.reload(); }, 500);
  }
  function undoRestore() {
    var u = jget(UNDO_KEY, null); if (!u || !u.data) { msg('বাতিল করার মতো কিছু নেই', 'err'); return; }
    if (!lsSet(PENDING_KEY, JSON.stringify({ data: u.data, removeMissing: true, keys: allKeys() }))) { msg('জায়গা কম — বাতিল করা যায়নি', 'err'); return; }
    try { localStorage.removeItem(UNDO_KEY); } catch (e) {}
    msg('আগের অবস্থায় ফিরছে…', 'ok'); setTimeout(function () { location.reload(); }, 500);
  }

  /* ধাপ ৯: অ্যাকাউন্টের ক্লাউড সিঙ্ক (shell/js/10-account.js) এই একই ব্যাকআপ ব্যবহার করে —
     ক্লাউডে যায় makeBackup()-এর লেখা, ফেরত আসলে একই যাচাই (app/format/sum) পেরিয়ে একই পথে (PENDING → রিলোড) বসে। */
  window.__ptBackup = {
    collect: collect, make: makeBackup, sum32: sum32, describe: describe,
    fingerprint: function () { return sum32(JSON.stringify(collect())); },
    /* opts.merge = true: প্রথমবার সাইন-ইন — ফোনে আগে থেকে থাকা নিজের নোট মোছা হবে না, ক্লাউডেরগুলো যোগ হবে */
    restoreText: function (text, opts) {
      var o; try { o = JSON.parse(text); } catch (e) { return 'bad'; }
      if (!o || o.app !== 'patheyo' || o.format !== 1 || !o.data || typeof o.data !== 'object') return 'bad';
      if (sum32(JSON.stringify(o.data)) !== o.sum) return 'broken';
      var data = {};
      Object.keys(o.data).forEach(function (k) { if ((isSyncKey(k) || k === NK) && typeof o.data[k] === 'string') data[k] = o.data[k]; });
      if (!Object.keys(data).length) return 'empty';
      lsSet(UNDO_KEY, JSON.stringify({ at: new Date().toISOString(), data: collect() }));
      if (!lsSet(PENDING_KEY, JSON.stringify({ data: data, nativeMerge: !!(opts && opts.merge) }))) return 'space';
      setTimeout(function () { location.reload(); }, 400);
      return 'ok';
    },
    /* v194: সাইন-আউটে এই ফোনকে "প্রথম দিনের" অবস্থায় ফেরানো — নাম, ছবি, সব সেটিংস ও হিসাব (KEYS) মুছে অ্যাপ নতুন করে খোলে।
       (অনবোর্ডিং-চিহ্ন, লোকেশন-অনুমতি ইত্যাদি ডিভাইসের জিনিস থাকে।) রিস্টোরের একই পথ — রিলোডের একদম শুরুতে মোছা হয়। */
    resetLocal: function () {
      ['pt_cloud', 'pt_avatar_up', 'pt_avatar_dirty', 'pt_google_mode', LAST_KEY, UNDO_KEY].forEach(function (k) { try { localStorage.removeItem(k); } catch (e) {} });
      lsSet(PENDING_KEY, JSON.stringify({ data: {}, removeMissing: true, keys: allKeys(), nativeReset: true }));   /* v247: নেটিভ নোট ইত্যাদিও সাফ */
      setTimeout(function () { location.reload(); }, 500);
      return true;
    },
    peek: function (text) { try { var o = JSON.parse(text); return o && o.data ? { created: o.created, list: describe(o.data), fp: sum32(JSON.stringify(o.data)) } : null; } catch (e) { return null; } }
  };

  function init() {
    buildSizes();
    paintSummary();
    var map = { 'bk-save': doSave, 'bk-share': doShare, 'bk-pick': pick, 'bk-ok': confirmRestore, 'bk-undo': undoRestore };
    Object.keys(map).forEach(function (id) { var e = $(id); if (e) e.addEventListener('click', map[id]); });
    var no = $('bk-no'); if (no) no.addEventListener('click', function () { picked = null; $('bk-confirm').hidden = true; });
    var fi = $('bk-file');
    if (fi) fi.addEventListener('change', function () {   /* ব্রাউজারে ফাইল-ইনপুট */
      var f = fi.files && fi.files[0]; if (!f) return;
      var r = new FileReader(); r.onload = function () { inspect(String(r.result), f.name); fi.value = ''; }; r.readAsText(f);
    });
    var open = $('btn-settings'); if (open) open.addEventListener('click', function () { setTimeout(paintSummary, 50); });   /* সেটিংস খুললে সারসংক্ষেপ নতুন করে */
    /* সদ্য রিস্টোর হলে জানাই (early script এই চিহ্ন রেখে যায়) */
    if (lsGet('pt_restored_flag')) { try { localStorage.removeItem('pt_restored_flag'); } catch (e) {} setTimeout(function () { msg('রিস্টোর সম্পন্ন হয়েছে — সব ডেটা ফিরে এসেছে', 'ok'); }, 800); }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
