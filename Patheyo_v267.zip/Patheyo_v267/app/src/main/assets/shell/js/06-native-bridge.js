
/* ============================================================================================
   Android (Kotlin) <-> app glue. Design/animation code above is untouched; this block only
   (1) forwards the callbacks MainActivity calls on the TOP window to the page that owns them,
   (2) handles the Android back button, (3) drives the Permission centre in Settings.
   Keep this script LAST in the file: Kotlin may call these at any moment.
   ============================================================================================ */
(function () {
  'use strict';

  /* ---------- 1) Kotlin -> JS callbacks: the namaz frame owns the real implementations ---------- */
  var last = { net: null, hijri: null };
  function nzFrame() { return document.querySelector('#namaz-overlay iframe.qr-frame'); }
  function nzCall(name, arg) {
    try {
      var f = nzFrame(), w = f && f.contentWindow;
      if (w && typeof w[name] === 'function') { w[name](arg); return true; }
    } catch (e) {}
    return false;
  }
  window.setNativeNetworkStatus = function (isOnline) { last.net = !!isOnline; nzCall('setNativeNetworkStatus', last.net); };
  window.setNativeHijriConfig = function (cfg) { if (cfg) { last.hijri = cfg; nzCall('setNativeHijriConfig', cfg); } };
  window.onAzanStopped = function () { nzCall('onAzanStopped'); };

  /* the namaz frame loads a little after start: replay what Kotlin already told us, and make sure every frame sees the native bridge */
  document.addEventListener('load', function (e) {
    var f = e.target;
    if (!f || f.tagName !== 'IFRAME') return;
    try {
      var w = f.contentWindow;
      if (w && !w.AndroidWidgetBridge && window.AndroidWidgetBridge) w.AndroidWidgetBridge = window.AndroidWidgetBridge;
    } catch (err) {}
    if (f.parentNode && f.parentNode.id === 'namaz-overlay') {
      if (last.net !== null) nzCall('setNativeNetworkStatus', last.net);
      if (last.hijri) nzCall('setNativeHijriConfig', last.hijri);
    }
  }, true);

  /* ---------- Kotlin -> কুরআন পেজ: মুসহাফ PDF / তরজমা ডাউনলোডের প্রগ্রেস (kind = 'pdf' | 'tarjama') ---------- */
  window.__quranNativeEvent = function (kind, ev) {
    try {
      var f = document.querySelector('#quran-overlay iframe.qr-frame');
      var app = f && f.contentWindow && f.contentWindow.QuranApp;
      var mod = app && (kind === 'tarjama' ? app.tarjamaDownload : app.pdfDownload);
      if (mod && typeof mod._onNative === 'function') { mod._onNative(ev); return true; }
    } catch (e) {}
    return false;
  };

  /* ---------- Kotlin -> কুরআন পেজ: ব্যাকগ্রাউন্ড প্লেয়ারের অবস্থা (প্লে/পজ/আয়াত বদল/প্রগ্রেস) + সূরা অডিও ডাউনলোডের প্রগ্রেস ---------- */
  window.__quranAudioEvent = function (ev) {
    try {
      var f = document.querySelector('#quran-overlay iframe.qr-frame');
      var qa = f && f.contentWindow && f.contentWindow.QuranAudio;
      if (qa && typeof qa._onNative === 'function') { qa._onNative(ev); return true; }
    } catch (e) {}
    return false;
  };

  /* ---------- Kotlin -> হাদিস পেজ: কিতাব ডাউনলোডের প্রগ্রেস ({id, phase, downloaded, total, error}) ---------- */
  window.__hadithNativeEvent = function (ev) {
    try {
      var f = document.querySelector('#hadith-overlay iframe.qr-frame');
      var app = f && f.contentWindow && f.contentWindow.HadithApp;
      var mod = app && app.bookDl;
      if (mod && typeof mod._onNative === 'function') { mod._onNative(ev); return true; }
    } catch (e) {}
    return false;
  };

  /* ---------- হোমের "তারিখ-কার্ড" টাইল: নেটিভ স্ক্রিন খোলে (পেজ-কন্ট্রোলারের আগে ধরা হয়, তাই ফিচার-পেজ খোলে না) ---------- */
  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest ? e.target.closest('.module-tile[data-native="datecard"]') : null;
    if (!t) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    try { if (window.PatheyoDateCard && window.PatheyoDateCard.open) window.PatheyoDateCard.open(); } catch (err) {}
  }, true);

  /* ---------- 2) Android back button: true = handled here, false = let the app close ---------- */
  window.handleNativeBackPress = function () {
    try {
      if (window.__ptOnbBack && window.__ptOnbBack()) return true;                               /* ধাপ ১১: অনবোর্ডিং চলছে → আগের ধাপ (অ্যাপ বন্ধ নয়) */
      if (window.PTAds && window.PTAds.closePopup && window.PTAds.closePopup()) return true;   /* v143: খোলা এড পপআপ আগে বন্ধ হবে */
      if (window.PT && PT.handleBack && PT.handleBack()) return true;                           /* v2: খোলা মেনু/ডায়লগ/শিট আগে বন্ধ */
      var ov = document.querySelector('.page-overlay.is-open'), fw = null;                            /* ধাপ ৩: খোলা পেজের ভেতরের পপআপ আগে বন্ধ */
      try { var fi = ov && ov.querySelector('iframe.qr-frame'); fw = fi && fi.contentWindow; } catch (e1) {}
      try { if (fw && typeof fw.__ptFrameBack === 'function' && fw.__ptFrameBack()) return true; } catch (e2) {}
      if (document.querySelector('.page-overlay.is-open')) { history.back(); return true; }
    } catch (e) {}
    return false;
  };

  /* ---------- 3) Permission centre (Settings page) ---------- */
  var KEYS = ['exactAlarm', 'notification', 'location', 'battery', 'fullScreen'];
  var overlay = document.getElementById('settings-overlay');
  var note = document.getElementById('perm-note');
  function bridge() { return window.AndroidWidgetBridge || null; }
  function setBadge(key, state) {
    var el = document.getElementById('perm-badge-' + key);
    if (!el) return;
    el.classList.remove('perm-badge--on', 'perm-badge--off');
    if (state === null) { el.textContent = 'শুধু অ্যাপে'; }
    else if (state) { el.textContent = 'চালু আছে'; el.classList.add('perm-badge--on'); }
    else { el.textContent = 'বন্ধ আছে ✗'; el.classList.add('perm-badge--off'); }
    updateSummary();
  }
  /* v264: অনুমতির সারসংক্ষেপ ("৫টির মধ্যে ৩টি চালু") — শুধু অ্যাপের ভেতরে (স্ট্যাটাস জানা গেলে) দেখায় */
  function bn(n) { return String(n).replace(/\d/g, function (d) { return '০১২৩৪৫৬৭৮৯'.charAt(d); }); }
  /* v265: ফুটারের সংস্করণ — অ্যাপের ভেতরে ইনস্টল হওয়া ভার্সন (build.gradle.kts-এর versionName) থেকে নিজে থেকে আসে; ব্রাউজারে/না পেলে লুকানো থাকে */
  function setVersion() {
    var el = document.getElementById('sx-ver'); if (!el) return;
    var v = '';
    try { if (window.PatheyoAppInfo && window.PatheyoAppInfo.getVersionName) v = String(window.PatheyoAppInfo.getVersionName() || ''); } catch (e) {}
    if (!v) { el.hidden = true; return; }
    el.textContent = 'সংস্করণ ' + bn(v).replace(/\./g, '.'); el.hidden = false;
  }
  setVersion();
  /* v266: ফুটারের সাল — ফোনের বর্তমান সাল থেকে নিজে থেকে আসে (বাংলা অঙ্কে) */
  (function () { var y = document.getElementById('sx-year'); if (y) y.textContent = bn(new Date().getFullYear()); })();
  function updateSummary() {
    var sum = document.getElementById('perm-sum'); if (!sum) return;
    var on = 0, known = 0;
    KEYS.forEach(function (k) {
      var e = document.getElementById('perm-badge-' + k); if (!e) return;
      if (e.classList.contains('perm-badge--on')) { on++; known++; } else if (e.classList.contains('perm-badge--off')) known++;
    });
    if (!known) { sum.hidden = true; return; }
    sum.hidden = false; sum.classList.toggle('is-ok', on === KEYS.length); sum.classList.toggle('is-warn', on < KEYS.length);
    sum.textContent = on === KEYS.length ? 'সব চালু ✓' : bn(KEYS.length) + 'টির মধ্যে ' + bn(on) + 'টি চালু';
  }
  function refresh() {
    var b = bridge();
    if (b && typeof b.checkAllPermissionsStatus === 'function') {
      try {
        var st = JSON.parse(b.checkAllPermissionsStatus());
        KEYS.forEach(function (k) { setBadge(k, !!st[k]); });
      } catch (e) { console.error('permission status check failed:', e); }
    } else {
      KEYS.forEach(function (k) { setBadge(k, null); });
    }
  }
  function callBridge(method) {
    var b = bridge();
    if (b && typeof b[method] === 'function') {
      if (note) note.textContent = '';
      try { b[method](); setTimeout(refresh, 800); } catch (e) { console.error('permission bridge call failed:', method, e); }
    } else if (note) {
      note.textContent = 'এই বাটনটা শুধু অ্যাপের ভিতরে কাজ করবে — এখন ব্রাউজারে টেস্ট মোডে আছেন।';
    }
  }
  if (overlay) {
    overlay.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target.closest('[data-perm-call],[data-perm-refresh]') : null;
      if (!t) return;
      if (t.hasAttribute('data-perm-call')) callBridge(t.getAttribute('data-perm-call')); else refresh();
    });
    /* status refreshes whenever the page opens, and when the person comes back from the system settings screen */
    if (window.MutationObserver) {
      new MutationObserver(function () { if (overlay.classList.contains('is-open')) { refresh(); setTimeout(refresh, 450); } })
        .observe(overlay, { attributes: true, attributeFilter: ['class'] });
    }
    var back = function () { if (overlay.classList.contains('is-open')) setTimeout(refresh, 300); };
    document.addEventListener('visibilitychange', function () { if (!document.hidden) back(); });
    window.addEventListener('focus', back);
  }
  refresh();
})();
