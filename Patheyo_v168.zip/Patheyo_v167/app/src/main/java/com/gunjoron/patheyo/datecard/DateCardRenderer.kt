package com.gunjoron.patheyo.datecard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.gunjoron.patheyo.notification.HijriCalendarHelper
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import com.gunjoron.patheyo.widgethub.widget.assets.Fonts
import java.util.Calendar
import java.util.Random
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * তারিখ-কার্ড আঁকা (Canvas → Bitmap)। সব নকশা কোডে — ছবি/ফাইল লাগে না।
 * আঁকা হয় ১০৮০ একক চওড়া "ডিজাইন-স্পেসে"; আউটপুট মাপ (পোস্ট ১০৮০×১৩৫০ / স্টোরি ১০৮০×১৯২০ / থাম্বনেইল) canvas.scale() দিয়ে।
 * তারিখ আসে উইজেট/হোমের একই হিসাব ([Snapshot]) থেকে — তাই হিজরি তারিখ অ্যাপের ফায়ারবেস-অ্যাডজাস্টমেন্ট মেনে চলে।
 */
object DateCardRenderer {

    class Info(
        val weekday: String,
        val greg: String,
        val hijri: String,
        val bangla: String,
        val friday: Boolean,
        val dayOfYear: Int,
        val year: Int
    )

    const val W = 1080f
    private const val BISMILLAH = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ"
    private val WEEKDAYS = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

    fun ratio(format: String): Float = if (format == "story") 1920f / 1080f else 1350f / 1080f

    // ------------------------------------------------------------------ তথ্য

    fun infoFor(ctx: Context, nowMs: Long = System.currentTimeMillis()): Info {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val snap = try { Snapshot.build(ctx.applicationContext, nowMs) } catch (_: Throwable) { null }
        val greg = if (snap != null) "${snap.gregDay} ${snap.gregMonth} ${snap.gregYear}"
        else "${Bn.digits(cal.get(Calendar.DAY_OF_MONTH))} ${Bn.GREG_MONTHS[cal.get(Calendar.MONTH)]} ${Bn.digits(cal.get(Calendar.YEAR))}"
        val bangla = if (snap != null) "${snap.banglaDay} ${snap.banglaMonth} ${snap.banglaYear}" else banglaFallback(cal)
        val hijri = if (snap != null && snap.hijriDay != "--" && snap.hijriYear != "----")
            "${snap.hijriDay} ${snap.hijriMonth} ${snap.hijriYear}"
        else try {
            val h = HijriCalendarHelper.getTodayHijri(false)
            "${Bn.digits(h.day)} ${Bn.HIJRI_MONTHS[(h.month - 1).coerceIn(0, 11)]} ${Bn.digits(h.year)}"
        } catch (_: Throwable) { "" }
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        return Info(WEEKDAYS[dow - 1], greg, hijri, bangla, dow == Calendar.FRIDAY, cal.get(Calendar.DAY_OF_YEAR), cal.get(Calendar.YEAR))
    }

    /** Snapshot না পেলে (প্রায় হয় না) — পহেলা বৈশাখ ১৪ এপ্রিল ধরে বাংলা তারিখ */
    private fun banglaFallback(cal: Calendar): String {
        val y = cal.get(Calendar.YEAR)
        val leap = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
        val dm = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (leap) 30 else 29, 30)
        var by = y - 593
        val today = Calendar.getInstance().apply { set(y, cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), 0, 0, 0); set(Calendar.MILLISECOND, 0) }
        var start = Calendar.getInstance().apply { set(y, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
        if (today.timeInMillis < start.timeInMillis) {
            by -= 1
            start = Calendar.getInstance().apply { set(y - 1, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
        }
        var d = ((today.timeInMillis - start.timeInMillis) / 86_400_000L).toInt() + 1
        var m = 0
        while (m < 11 && d > dm[m]) { d -= dm[m]; m++ }
        return "${Bn.digits(d)} ${Bn.BANGLA_MONTHS[m]} ${Bn.digits(by)}"
    }

    // ------------------------------------------------------------------ প্রধান রেন্ডার

    /** সেটিংস অনুযায়ী আজকের কার্ড (থিম/ছবি/ফরম্যাট prefs থেকে) */
    fun renderFor(ctx: Context, nowMs: Long, prefs: DateCardPrefs, outW: Int = 1080): Bitmap {
        val info = infoFor(ctx, nowMs)
        val theme = DateCardThemes.forDay(prefs.theme, info.dayOfYear, info.year)
        val photo = if (prefs.usePhoto) loadPhoto(prefs) else null
        return try {
            render(ctx, info, theme, prefs.format, photo, prefs.scrim, outW)
        } finally { photo?.recycle() }
    }

    fun loadPhoto(prefs: DateCardPrefs): Bitmap? = try {
        BitmapFactory.decodeFile(prefs.photoFile().absolutePath)
    } catch (_: Throwable) { null }

    fun render(ctx: Context, info: Info, theme: DateCardTheme, format: String, photo: Bitmap?, scrimPct: Int, outW: Int): Bitmap {
        try { Fonts.init(ctx) } catch (_: Throwable) {}
        val ratio = ratio(format)
        val h = W * ratio
        val outH = (outW * ratio).toInt()
        val bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = outW / W
        c.scale(k, k)
        val th = if (photo != null) forPhoto(theme) else theme
        if (photo != null) drawPhotoBg(c, h, photo, scrimPct) else drawThemeBg(c, h, th)
        drawFrame(c, h, th.accent)
        drawContent(ctx, c, h, info, th, photo != null)
        return bmp
    }

    /** ছবির ওপর সবসময় সাদা লেখা + (আলোকিত থিম হলে) সোনালি অ্যাকসেন্ট */
    private fun forPhoto(t: DateCardTheme): DateCardTheme = DateCardTheme(
        t.id, t.name, t.bg, Color.WHITE,
        if (t.light) Color.parseColor("#F0CF7A") else t.accent,
        Color.BLACK, CardPattern.NONE, CardScene.NONE, light = false
    )

    // ------------------------------------------------------------------ ছোট হেল্পার

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
    private fun stroke(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.STROKE; strokeWidth = w; strokeJoin = Paint.Join.ROUND }
    private fun al(color: Int, a: Float) = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color))
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
    private fun lum(c: Int): Float = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun fitSize(p: Paint, text: String, maxW: Float, start: Float): Float {
        p.textSize = start
        val w = p.measureText(text)
        return if (w > maxW && w > 0f) start * maxW / w else start
    }

    private fun star8(path: Path, cx: Float, cy: Float, r: Float) {
        val ri = r * 0.62f
        for (i in 0 until 16) {
            val ang = PI / 8 * i - PI / 2
            val rad = if (i % 2 == 0) r else ri
            val x = cx + (rad * cos(ang)).toFloat()
            val y = cy + (rad * sin(ang)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    private fun diamond(path: Path, cx: Float, cy: Float, d: Float) {
        path.moveTo(cx, cy - d); path.lineTo(cx + d, cy); path.lineTo(cx, cy + d); path.lineTo(cx - d, cy); path.close()
    }

    // ------------------------------------------------------------------ ব্যাকগ্রাউন্ড

    private fun drawThemeBg(c: Canvas, h: Float, t: DateCardTheme) {
        c.drawRect(0f, 0f, W, h, Paint().apply { shader = LinearGradient(0f, 0f, 0f, h, t.bg, null, Shader.TileMode.CLAMP) })
        // ওপরে মৃদু আলোর আভা
        c.drawRect(0f, 0f, W, h, Paint().apply {
            shader = RadialGradient(W / 2, h * 0.28f, W * 0.9f, intArrayOf(al(t.accent, if (t.light) 0.26f else 0.20f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        })
        val pc = if (t.patternColor != 0) t.patternColor else t.accent
        when (t.pattern) {
            CardPattern.STAR -> starPattern(c, h, al(pc, if (t.light) 0.16f else 0.10f))
            CardPattern.FLOWER -> flowerPattern(c, h, al(pc, if (t.light) 0.15f else 0.09f))
            CardPattern.DIAMOND -> diamondPattern(c, h, al(pc, 0.09f))
            CardPattern.NONE -> {}
        }
        when (t.scene) {
            CardScene.MOSQUE -> mosque(c, h, t.sil, if (t.light) null else t.accent)
            CardScene.DAWN -> {
                c.drawRect(0f, h * 0.55f, W, h, Paint().apply {
                    shader = RadialGradient(W / 2, h - 70f, W * 0.95f, intArrayOf(al(t.accent, 0.85f), al(t.accent, 0.25f), Color.TRANSPARENT), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
                })
                mosque(c, h, t.sil, null)
            }
            CardScene.DUNES -> dunes(c, h, t)
            CardScene.LANTERNS -> { lantern(c, 110f, 170f, 96f, t); lantern(c, 250f, 70f, 78f, t); lantern(c, 830f, 70f, 78f, t); lantern(c, 970f, 190f, 100f, t); mosque(c, h, t.sil, t.accent) }
            CardScene.KAABA -> kaaba(c, h, t)
            CardScene.MOON -> moon(c, h, t)
            CardScene.ARCH -> arch(c, h, t)
            CardScene.NONE -> {}
        }
    }

    private fun drawPhotoBg(c: Canvas, h: Float, photo: Bitmap, scrimPct: Int) {
        val sw = photo.width.toFloat(); val sh = photo.height.toFloat()
        val sc = max(W / sw, h / sh)
        val dw = sw * sc; val dh = sh * sc
        c.drawBitmap(photo, null, RectF((W - dw) / 2, (h - dh) / 2, (W + dw) / 2, (h + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.drawColor(Color.argb((scrimPct.coerceIn(0, 80) / 100f * 255).toInt(), 0, 0, 0))
        // লেখা পড়ার সুবিধায় ওপর-নিচে হালকা গাঢ় ছায়া
        c.drawRect(0f, 0f, W, h, Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(al(Color.BLACK, 0.40f), al(Color.BLACK, 0.05f), al(Color.BLACK, 0.05f), al(Color.BLACK, 0.50f)), floatArrayOf(0f, 0.3f, 0.65f, 1f), Shader.TileMode.CLAMP)
        })
    }

    private fun starPattern(c: Canvas, h: Float, col: Int) {
        val t = 135f
        val path = Path()
        for (j in 0..ceil(h / t).toInt()) for (i in 0..ceil(W / t).toInt()) {
            star8(path, i * t, j * t, t * 0.46f)
            diamond(path, i * t + t / 2, j * t + t / 2, t * 0.13f)
        }
        c.drawPath(path, stroke(col, 1.8f))
    }

    private fun flowerPattern(c: Canvas, h: Float, col: Int) {
        val r = 64f
        val dy = r * 0.8660254f
        val path = Path()
        var j = 0
        while (j * dy < h + r) {
            var i = 0
            while (i * r < W + r) {
                path.addCircle(i * r + (if (j % 2 == 1) r / 2 else 0f), j * dy, r, Path.Direction.CW)
                i++
            }
            j++
        }
        c.drawPath(path, stroke(col, 1.6f))
    }

    private fun diamondPattern(c: Canvas, h: Float, col: Int) {
        val p = stroke(col, 1.6f)
        var x = -h
        while (x <= W) { c.drawLine(x, 0f, x + h, h, p); c.drawLine(x, h, x + h, 0f, p); x += 120f }
    }

    // ------------------------------------------------------------------ দৃশ্য (নিচের সিলুয়েট)

    private fun dome(c: Canvas, cx: Float, baseY: Float, w: Float, hgt: Float, p: Paint) {
        val path = Path()
        path.moveTo(cx - w / 2, baseY)
        path.cubicTo(cx - w / 2, baseY - hgt * 0.62f, cx - w * 0.20f, baseY - hgt * 0.80f, cx, baseY - hgt)
        path.cubicTo(cx + w * 0.20f, baseY - hgt * 0.80f, cx + w / 2, baseY - hgt * 0.62f, cx + w / 2, baseY)
        path.close()
        c.drawPath(path, p)
        c.drawRect(cx - 3f, baseY - hgt - 34f, cx + 3f, baseY - hgt + 4f, p)       // চূড়া
        c.drawCircle(cx, baseY - hgt - 34f, 7f, p)
    }

    private fun minaret(c: Canvas, x: Float, ground: Float, hgt: Float, p: Paint) {
        val w = 30f
        c.drawRect(x - w / 2, ground - hgt, x + w / 2, ground, p)                         // কাণ্ড
        c.drawRect(x - w * 0.8f, ground - hgt * 0.16f, x + w * 0.8f, ground, p)           // গোড়া
        c.drawRect(x - w * 0.95f, ground - hgt * 0.78f, x + w * 0.95f, ground - hgt * 0.78f + 12f, p)  // বারান্দা
        c.drawRect(x - w * 0.38f, ground - hgt - 50f, x + w * 0.38f, ground - hgt, p)     // ওপরের চোঙ
        val cap = Path()
        cap.moveTo(x - w * 0.58f, ground - hgt - 50f); cap.lineTo(x, ground - hgt - 124f); cap.lineTo(x + w * 0.58f, ground - hgt - 50f); cap.close()
        c.drawPath(cap, p)
        c.drawCircle(x, ground - hgt - 128f, 5f, p)
    }

    private fun mosque(c: Canvas, h: Float, sil: Int, lit: Int?) {
        val p = fill(sil)
        val ground = h - 70f
        val cx = W / 2
        c.drawRect(0f, ground, W, h, p)
        // মূল ভবন + গম্বুজ
        c.drawRect(cx - 180f, ground - 100f, cx + 180f, ground, p)
        dome(c, cx, ground - 98f, 310f, 160f, p)
        // দুই পাশের ছোট গম্বুজ
        for (s in intArrayOf(-1, 1)) {
            val x = cx + s * 245f
            c.drawRect(x - 75f, ground - 80f, x + 75f, ground, p)
            dome(c, x, ground - 78f, 140f, 84f, p)
            minaret(c, cx + s * 350f, ground, 170f, p)
            minaret(c, cx + s * 478f, ground, 430f, p)
        }
        if (lit != null) {
            val lp = fill(al(lit, 0.85f))
            for (dx in floatArrayOf(-110f, 0f, 110f)) {
                val path = Path()
                path.addRect(cx + dx - 16f, ground - 40f, cx + dx + 16f, ground, Path.Direction.CW)
                path.addCircle(cx + dx, ground - 40f, 16f, Path.Direction.CW)
                c.drawPath(path, lp)
            }
        }
    }

    private fun dunes(c: Canvas, h: Float, t: DateCardTheme) {
        c.drawCircle(W * 0.78f, h * 0.17f, 78f, fill(al(t.accent, 0.20f)))
        c.drawCircle(W * 0.78f, h * 0.17f, 52f, fill(al(t.accent, 0.35f)))
        val ys = floatArrayOf(h * 0.80f, h * 0.87f, h * 0.94f)
        for (i in 0..2) {
            val path = Path()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= W + 10f) {
                path.lineTo(x, ys[i] + (sin(x / W * 2 * PI * 1.15 + i * 1.7) * 30.0).toFloat())
                x += 12f
            }
            path.lineTo(W, h); path.close()
            c.drawPath(path, fill(al(mix(t.sil, Color.BLACK, i * 0.16f), 0.50f + i * 0.17f)))
        }
    }

    private fun lantern(c: Canvas, x: Float, chain: Float, w: Float, t: DateCardTheme) {
        val top = chain
        c.drawLine(x, 0f, x, top, stroke(al(t.accent, 0.65f), 3f))
        c.drawCircle(x, top + w * 0.7f, w * 1.25f, Paint().apply {
            shader = RadialGradient(x, top + w * 0.7f, w * 1.25f, intArrayOf(al(t.accent, 0.38f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        })
        val body = mix(t.sil, t.accent, 0.22f)
        val cap = Path()
        cap.moveTo(x - w * 0.22f, top); cap.lineTo(x + w * 0.22f, top); cap.lineTo(x + w * 0.5f, top + w * 0.28f); cap.lineTo(x - w * 0.5f, top + w * 0.28f); cap.close()
        c.drawPath(cap, fill(body))
        val b = Path()
        b.moveTo(x - w * 0.5f, top + w * 0.28f); b.lineTo(x + w * 0.5f, top + w * 0.28f); b.lineTo(x + w * 0.38f, top + w * 1.15f); b.lineTo(x, top + w * 1.42f); b.lineTo(x - w * 0.38f, top + w * 1.15f); b.close()
        c.drawPath(b, fill(body))
        c.drawPath(b, stroke(al(t.accent, 0.85f), 2.5f))
        val g = Path()
        g.moveTo(x - w * 0.34f, top + w * 0.40f); g.lineTo(x + w * 0.34f, top + w * 0.40f); g.lineTo(x + w * 0.26f, top + w * 1.05f); g.lineTo(x, top + w * 1.25f); g.lineTo(x - w * 0.26f, top + w * 1.05f); g.close()
        c.drawPath(g, fill(al(t.accent, 0.88f)))
        val bar = stroke(body, 3f)
        c.drawLine(x, top + w * 0.40f, x, top + w * 1.25f, bar)
        c.drawLine(x - w * 0.34f, top + w * 0.72f, x + w * 0.34f, top + w * 0.72f, bar)
        c.drawCircle(x, top - 8f, 7f, stroke(al(t.accent, 0.9f), 3f))
    }

    private fun kaaba(c: Canvas, h: Float, t: DateCardTheme) {
        val ground = h - 70f
        val cx = W / 2
        val w = 340f; val hh = 290f; val dep = 96f; val rise = 28f
        val x0 = cx - w / 2; val top = ground - hh
        c.drawRect(0f, 0f, W, h, Paint().apply {
            shader = RadialGradient(cx, ground - hh / 2, 420f, intArrayOf(al(t.accent, 0.24f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        })
        c.drawRect(0f, ground, W, h, fill(Color.BLACK))
        val front = RectF(x0, top, x0 + w, ground)
        c.drawRect(front, fill(Color.parseColor("#0B0B0B")))
        val side = Path()
        side.moveTo(x0 + w, top); side.lineTo(x0 + w + dep, top - rise); side.lineTo(x0 + w + dep, ground - rise); side.lineTo(x0 + w, ground); side.close()
        c.drawPath(side, fill(Color.parseColor("#050505")))
        val tp = Path()
        tp.moveTo(x0, top); tp.lineTo(x0 + dep, top - rise); tp.lineTo(x0 + w + dep, top - rise); tp.lineTo(x0 + w, top); tp.close()
        c.drawPath(tp, fill(Color.parseColor("#1C1C1C")))
        val bandY = top + hh * 0.20f; val bandH = 30f
        c.drawRect(x0, bandY, x0 + w, bandY + bandH, fill(al(t.accent, 0.95f)))
        val sb = Path()
        sb.moveTo(x0 + w, bandY); sb.lineTo(x0 + w + dep, bandY - rise); sb.lineTo(x0 + w + dep, bandY - rise + bandH); sb.lineTo(x0 + w, bandY + bandH); sb.close()
        c.drawPath(sb, fill(al(t.accent, 0.75f)))
        c.drawRect(x0 + w * 0.60f, ground - 140f, x0 + w * 0.60f + 74f, ground, fill(al(t.accent, 0.92f)))
        c.drawRect(x0 + w * 0.60f + 10f, ground - 130f, x0 + w * 0.60f + 64f, ground, stroke(Color.parseColor("#0B0B0B"), 3f))
        c.drawRect(front, stroke(al(t.accent, 0.5f), 2.5f))
    }

    private fun moon(c: Canvas, h: Float, t: DateCardTheme) {
        val rnd = Random(7)
        val sp = fill(al(Color.WHITE, 0.7f))
        for (i in 0 until 48) {
            val x = rnd.nextFloat() * W; val y = rnd.nextFloat() * h * 0.82f
            c.drawCircle(x, y, 1.2f + rnd.nextFloat() * 2.4f, sp.apply { alpha = 90 + rnd.nextInt(150) })
        }
        for ((x, y, r) in listOf(Triple(130f, 150f, 20f), Triple(940f, 120f, 26f), Triple(880f, 560f, 16f), Triple(170f, 600f, 18f))) {
            val s = Path()
            s.moveTo(x, y - r); s.quadTo(x, y, x + r, y); s.quadTo(x, y, x, y + r); s.quadTo(x, y, x - r, y); s.quadTo(x, y, x, y - r); s.close()
            c.drawPath(s, fill(al(t.accent, 0.9f)))
        }
        val cx = W / 2; val cy = h * 0.90f; val r = 205f
        c.drawCircle(cx, cy, r * 1.7f, Paint().apply {
            shader = RadialGradient(cx, cy, r * 1.7f, intArrayOf(al(t.accent, 0.30f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        })
        val outer = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        val inner = Path().apply { addCircle(cx + r * 0.36f, cy - r * 0.10f, r * 0.86f, Path.Direction.CW) }
        outer.op(inner, Path.Op.DIFFERENCE)
        c.drawPath(outer, fill(al(t.accent, 0.97f)))
    }

    private fun archPath(h: Float, inset: Float): Path {
        val xl = 96f + inset; val xr = W - 96f - inset
        val yb = h - 110f
        val spring = h * 0.20f + inset
        val apex = 46f + inset
        val p = Path()
        p.moveTo(xl, yb)
        p.lineTo(xl, spring)
        p.cubicTo(xl, spring - (spring - apex) * 0.55f, W / 2 - 150f, apex + 70f, W / 2, apex)
        p.cubicTo(W / 2 + 150f, apex + 70f, xr, spring - (spring - apex) * 0.55f, xr, spring)
        p.lineTo(xr, yb)
        p.close()
        return p
    }

    private fun arch(c: Canvas, h: Float, t: DateCardTheme) {
        c.drawPath(archPath(h, 0f), fill(al(t.accent, 0.07f)))
        c.drawPath(archPath(h, 0f), stroke(al(t.accent, 0.85f), 4f))
        c.drawPath(archPath(h, 24f), stroke(al(t.accent, 0.35f), 2f))
        c.drawRect(0f, h - 110f, W, h, fill(t.sil))
        c.drawLine(0f, h - 110f, W, h - 110f, stroke(al(t.accent, 0.8f), 3f))
    }

    private fun drawFrame(c: Canvas, h: Float, accent: Int) {
        c.drawRoundRect(RectF(28f, 28f, W - 28f, h - 28f), 40f, 40f, stroke(al(accent, 0.55f), 3f))
        c.drawRoundRect(RectF(46f, 46f, W - 46f, h - 46f), 28f, 28f, stroke(al(accent, 0.22f), 1.5f))
        val d = Path()
        for ((x, y) in listOf(Pair(28f, 28f), Pair(W - 28f, 28f), Pair(28f, h - 28f), Pair(W - 28f, h - 28f))) diamond(d, x, y, 11f)
        c.drawPath(d, fill(al(accent, 0.95f)))
    }

    // ------------------------------------------------------------------ লেখা

    private fun drawContent(ctx: Context, c: Canvas, h: Float, info: Info, t: DateCardTheme, photoMode: Boolean) {
        val s = h / 1350f
        val s2 = 1f + (s - 1f) * 0.55f
        val bold = try { Fonts.bold } catch (_: Throwable) { Typeface.DEFAULT_BOLD }
        val reg = try { Fonts.regular } catch (_: Throwable) { Typeface.DEFAULT }
        fun tp(face: Typeface, color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = face; this.color = color; textAlign = Paint.Align.CENTER
            if (photoMode) setShadowLayer(10f, 0f, 3f, al(Color.BLACK, 0.55f))
        }

        // বিসমিল্লাহ
        val bp = tp(Typeface.DEFAULT, al(t.accent, 0.97f))
        bp.textSize = fitSize(bp, BISMILLAH, 560f, 58f)
        c.drawText(BISMILLAH, W / 2, 132f * s, bp)

        // অলংকরণ-রেখা
        val dy = 176f * s
        val lp = stroke(al(t.accent, 0.6f), 2.5f)
        c.drawLine(W / 2 - 250f, dy, W / 2 - 34f, dy, lp)
        c.drawLine(W / 2 + 34f, dy, W / 2 + 250f, dy, lp)
        val dm = Path(); diamond(dm, W / 2, dy, 11f); c.drawPath(dm, fill(t.accent))
        val dm2 = Path(); diamond(dm2, W / 2 - 40f, dy, 5f); diamond(dm2, W / 2 + 40f, dy, 5f); c.drawPath(dm2, fill(al(t.accent, 0.8f)))

        // বার
        val wp = tp(bold, t.text)
        wp.textSize = fitSize(wp, info.weekday, 820f, 176f * s2)
        c.drawText(info.weekday, W / 2, 380f * s, wp)

        // জুমার ব্যাজ
        if (info.friday) {
            val label = "জুমার মোবারক"
            val pp = tp(bold, if (lum(t.accent) > 0.55f) Color.parseColor("#1B1B1B") else Color.WHITE)
            pp.clearShadowLayer()
            pp.textSize = 36f
            val tw = pp.measureText(label)
            val cy = 436f * s
            c.drawRoundRect(RectF(W / 2 - tw / 2 - 34f, cy - 30f, W / 2 + tw / 2 + 34f, cy + 28f), 29f, 29f, fill(t.accent))
            c.drawText(label, W / 2, cy + 12f, pp)
        }

        // তিন তারিখ
        val rows = listOf(
            Pair("ইংরেজি তারিখ", info.greg),
            Pair("হিজরি তারিখ", info.hijri),
            Pair("বাংলা তারিখ", info.bangla)
        )
        val rh = 132f * s2
        val gap = 18f * s2
        var top = 500f * s
        for ((label, value) in rows) {
            if (value.isBlank()) continue
            val rect = RectF(100f, top, W - 100f, top + rh)
            c.drawRoundRect(rect, 34f, 34f, fill(if (t.light) al(Color.WHITE, 0.58f) else al(Color.WHITE, 0.09f)))
            c.drawRoundRect(rect, 34f, 34f, stroke(al(t.accent, 0.60f), 2.2f))
            val cy = top + rh / 2
            val st = Path(); star8(st, 168f, cy, 26f); star8(st, W - 168f, cy, 26f)
            c.drawPath(st, fill(al(t.accent, 0.92f)))
            val ip = Path(); ip.addCircle(168f, cy, 7f, Path.Direction.CW); ip.addCircle(W - 168f, cy, 7f, Path.Direction.CW)
            c.drawPath(ip, fill(if (t.light) al(Color.WHITE, 0.9f) else al(Color.BLACK, 0.45f)))
            val lb = tp(reg, t.accent); lb.clearShadowLayer(); lb.textSize = 27f; lb.letterSpacing = 0.05f
            if (photoMode) lb.setShadowLayer(8f, 0f, 2f, al(Color.BLACK, 0.5f))
            c.drawText(label, W / 2, top + rh * 0.34f, lb)
            val vp = tp(bold, t.text)
            vp.textSize = fitSize(vp, value, 640f, 58f * s2)
            c.drawText(value, W / 2, top + rh * 0.80f, vp)
            top += rh + gap
        }

        // নিচে ব্র্যান্ড
        val darkBand = lum(t.sil) < 0.55f || photoMode
        val brand = tp(bold, if (photoMode) al(Color.WHITE, 0.9f) else if (t.scene == CardScene.NONE) al(t.accent, 0.95f) else if (darkBand) al(Color.WHITE, 0.92f) else al(Color.parseColor("#1B1B1B"), 0.9f))
        brand.textSize = 30f; brand.letterSpacing = 0.12f
        c.drawText("পাথেয়", W / 2, h - 34f, brand)
    }
}
