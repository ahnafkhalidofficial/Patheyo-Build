package com.gunjoron.patheyo

// app/src/main/java/com/gunjoron/Patheyo/MainActivity.kt
//
// পরিবর্তন (এই রাউন্ডে):
//  - setMinimumFetchIntervalInSeconds(0) → 3600 (১ ঘন্টা) — আগে প্রতিবার খুললেই টানত, এখন ব্যাটারি বাঁচবে
//  - FirebaseDataManager.startRtdbListener() — RTDB থেকে রিয়েল-টাইম আরবি তারিখ
//  - FirebaseMessaging topic subscribe — FCM push পাওয়ার জন্য

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.widget.TextView
import android.view.animation.DecelerateInterpolator
import android.view.View
import android.text.style.StyleSpan
import android.text.style.ForegroundColorSpan
import android.text.SpannableString
import android.text.Spannable
import android.graphics.Typeface
import android.telephony.TelephonyManager
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.work.*
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.remoteconfig.ConfigUpdate
import com.google.firebase.remoteconfig.ConfigUpdateListener
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigException
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.gunjoron.patheyo.alarm.AlarmScheduler
import com.gunjoron.patheyo.alarm.AzanForegroundService
import com.gunjoron.patheyo.notification.IslamicNotificationWorker
import com.gunjoron.patheyo.notification.NotificationInbox
import com.gunjoron.patheyo.notification.ScheduledNotificationScheduler
import com.gunjoron.patheyo.ui.AlarmPermissionDialog
import com.gunjoron.patheyo.ui.LocationPermissionDialog
import com.gunjoron.patheyo.ui.NotificationPermissionDialog
import com.gunjoron.patheyo.update.UpdateManager
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import com.gunjoron.patheyo.widget.WidgetJSBridge
import com.gunjoron.patheyo.widget.WidgetRefreshScheduler
import com.gunjoron.patheyo.widget.WidgetUpdateWorker
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var jsBridge: WidgetJSBridge
    private lateinit var remoteConfig: FirebaseRemoteConfig
    private var pageLoadedOnce = false
    private var pendingHijriAdjustment = 0
    private var pendingMethodId = 1
    private var pendingDirectDate: String? = null
    private var pendingOverrideJson: String? = null   // ভাষা-ভিত্তিক হিজরি ওভাররাইড (bn/en…) JSON
    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    // v47: WebView-র রেন্ডারার প্রসেস মরে গেলে অ্যাপ ক্র্যাশ না করে নিজেকে সামলাতে — শেষবার কখন সামলানো হয়েছে
    private var lastRendererRecoverAt = 0L

    /**
     * v47: স্টার্টআপের যেসব কাজ অ্যাপ চালু হওয়ার জন্য অপরিহার্য নয় (অ্যালার্ম/ওয়ার্কার/Firebase ইত্যাদি),
     * সেগুলোর কোনোটায় কোনো ফোনে (বিশেষত OEM/নতুন Android ভার্সনে) সমস্যা হলেও যেন পুরো অ্যাপ ক্র্যাশ না করে —
     * ব্যর্থ হলে শুধু লগ হবে, বাকি কাজ ও অ্যাপ চলতেই থাকবে।
     */
    private inline fun safely(tag: String = "", block: () -> Unit) {
        try { block() } catch (t: Throwable) { android.util.Log.e("PatheyoSafe", "step failed: $tag", t) }
    }

    /** v47: পপআপ দেখাতে গিয়ে সমস্যা হলে ক্র্যাশ না করে [onFail] দিয়ে ধারা এগিয়ে নেওয়া */
    private fun showPopupSafely(onFail: () -> Unit, show: () -> Unit) {
        try {
            show()
        } catch (t: Throwable) {
            android.util.Log.e("PatheyoSafe", "popup failed", t)
            try { onFail() } catch (_: Throwable) { }
        }
    }

    // v47: লোকেশন "সঠিক (Fine)" বা "আনুমানিক (Coarse)" — যেকোনো একটা থাকলেই চলবে (Android 12+ এ ইউজার আনুমানিক দিতে পারেন)
    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    // v35: শুরুর ধাপে লোকেশন → (শেষ হলে) নোটিফিকেশন, যাতে দুটো পপআপ একসাথে না আসে
    private var inStartupPermFlow = false

    // v44: লোকেশন → নোটিফিকেশন → (আজান নির্ভরযোগ্যতার ধাপগুলো: অ্যালার্ম/ব্যাটারি/অটো-স্টার্ট/ফুলস্ক্রিন)
    // — শুরুর এই পুরো ধারাটা চলছে কিনা, আর ইউজার সেটিংস স্ক্রিন থেকে ফেরার অপেক্ষায় আছে কিনা
    private var startupChainActive = false
    // সেটিংস স্ক্রিন থেকে ফিরলে যে কাজটা চালাতে হবে (আর কখন "অপেক্ষা" শুরু হয়েছে)।
    // অনেক ফোনে সেটিংস খোলার ঠিক আগে একটা ভুয়া onResume আসে, তাই ১.২ সেকেন্ডের আগের onResume গ্রাহ্য নয়।
    private var resumeAction: (() -> Unit)? = null
    private var resumeArmedAt = 0L
    private fun armResume(action: () -> Unit) {
        resumeAction = action
        resumeArmedAt = SystemClock.elapsedRealtime()
    }

    // v40: ফোনের পপআপ আদৌ দেখানো হয়েছে কিনা বোঝার জন্য — "আর জিজ্ঞেস করবেন না" দেওয়া থাকলে অ্যান্ড্রয়েড
    // পপআপ না দেখিয়ে সঙ্গে সঙ্গে (মানুষের পক্ষে অসম্ভব দ্রুত) "denied" ফেরত দেয়
    private var locReqFromApp = false
    private var locReqStartedAt = 0L

    // ✅ v47 (লোকেশন পপআপের আসল বাগ): Android 12+ (API 31+) এ শুধু ACCESS_FINE_LOCATION চাইলে সিস্টেম অনুরোধটা
    // পপআপ না দেখিয়েই বাতিল করে দেয় (ডকুমেন্টেড আচরণ: FINE চাইলে COARSE-ও একই অনুরোধে চাইতে হয়)।
    // তাই এখন দুটোই একসাথে চাওয়া হয় — সব Android ভার্সনে ফোনের আসল লোকেশন-পপআপ আসবে।
    private val locationPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val granted = results.values.any { it }
        val phoneDialogSkipped = !granted && locReqFromApp &&
            (SystemClock.elapsedRealtime() - locReqStartedAt) < 700L
        locReqFromApp = false
        if (phoneDialogSkipped) {
            // ফোন আর পপআপ দেখাবে না → ইউজার আমাদের পপআপে "অনুমতি" চেপেছেন, তাই সরাসরি অ্যাপ সেটিংসে পাঠাই
            inStartupPermFlow = false
            if (startupChainActive) armResume { requestNotificationIfNeeded() } // সেটিংস থেকে ফিরে নোটিফিকেশনের ধাপ
            openLocationSettingsWithHint()
            return@registerForActivityResult
        }
        if (inStartupPermFlow) { inStartupPermFlow = false; requestNotificationIfNeeded() }
    }

    // v42: নোটিফিকেশনের ক্ষেত্রেও লোকেশনের মতোই — ফোনের পপআপ আদৌ এসেছিল কিনা বোঝার জন্য
    private var notifReqStartedAt = 0L
    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val phoneDialogSkipped = !granted && (SystemClock.elapsedRealtime() - notifReqStartedAt) < 700L
        notifReqStartedAt = 0L
        // "আর জিজ্ঞেস করবেন না" দেওয়া থাকলে ফোন পপআপ না দেখিয়ে সঙ্গে সঙ্গে denied দেয় →
        // ইউজার আমাদের পপআপে "অনুমতি" চেপেছেন, তাই সরাসরি অ্যাপের নোটিফিকেশন সেটিংসে পাঠাই
        if (phoneDialogSkipped) {
            if (startupChainActive) armResume { startAlarmSetupFlow() } // সেটিংস থেকে ফিরলে ধারা চলবে
            openNotificationSettingsWithHint()
        } else {
            afterNotificationStep()
        }
    }

    // ✅ v165: পুরো-অ্যাপ ব্যাকআপের রিস্টোর — সিস্টেম ডকুমেন্ট-পিকার থেকে বাছা ফাইল BackupBridge-এ যায়
    private var backupBridge: com.gunjoron.patheyo.backup.BackupBridge? = null
    // ✅ v168: কুরআন তিলাওয়াতের নেটিভ ব্রিজ (অ্যাক্টিভিটি ধ্বংস হলে JS-কে আর ইভেন্ট না পাঠাতে detach করা হয়)
    private var quranAudioBridge: com.gunjoron.patheyo.audio.QuranAudioBridge? = null
    private val backupPickLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        backupBridge?.onPicked(uri)
    }

    // v40: "পারমিশন" ট্যাবের বাটন থেকে লোকেশন চাইলেও এখন আগে আমাদের গ্লাস পপআপ,
    // তারপর (✓ চাপলে) ফোনের পারমিশন। WidgetJSBridge-এর কোড অপরিবর্তিত।
    fun requestLocationPermissionFromJs() {
        if (isFinishing || isDestroyed) return
        showPopupSafely(onFail = { }) {
            LocationPermissionDialog.show(
                this,
                onAllow = { launchLocationRequest(startup = false) },
                onDone = { }
            )
        }
    }
    // v42: "পারমিশন" ট্যাব থেকেও এখন আগে আমাদের গ্লাস পপআপ, তারপর (অনুমতি চাপলে) ফোনের পপআপ
    fun requestNotificationPermissionFromJs() {
        if (isFinishing || isDestroyed) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            showPopupSafely(onFail = { }) {
                NotificationPermissionDialog.show(
                    this,
                    onAllow = { launchNotificationRequest() },
                    onDone = { }
                )
            }
        }
    }

    // v42: নোটিফিকেশন পপআপের "অনুমতি" বাটনের সিদ্ধান্ত ফোনের কাছে পৌঁছে দেওয়ার একমাত্র জায়গা
    private fun launchNotificationRequest() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        notifReqStartedAt = SystemClock.elapsedRealtime()
        try {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } catch (t: Throwable) {
            android.util.Log.e("PatheyoSafe", "notification permission launch failed", t)
            notifReqStartedAt = 0L
            afterNotificationStep()
        }
    }

    private fun openNotificationSettingsWithHint() {
        android.widget.Toast.makeText(this, getString(R.string.notif_perm_open_settings), android.widget.Toast.LENGTH_LONG).show()
        try {
            startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName))
        } catch (_: Exception) { }
    }

    // v40: আমাদের পপআপের "অনুমতি" বাটনের সিদ্ধান্ত ফোনের কাছে পৌঁছে দেওয়ার একমাত্র জায়গা
    private fun launchLocationRequest(startup: Boolean) {
        inStartupPermFlow = startup
        locReqFromApp = true
        locReqStartedAt = SystemClock.elapsedRealtime()
        try {
            locationPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        } catch (t: Throwable) {
            android.util.Log.e("PatheyoSafe", "location permission launch failed", t)
            locReqFromApp = false
            if (inStartupPermFlow) { inStartupPermFlow = false; requestNotificationIfNeeded() }
        }
    }

    private fun openLocationSettingsWithHint() {
        android.widget.Toast.makeText(this, getString(R.string.loc_perm_open_settings), android.widget.Toast.LENGTH_LONG).show()
        try {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                android.net.Uri.fromParts("package", packageName, null)))
        } catch (_: Exception) { }
    }

    // v35: লোকেশন লাগে কেন — আগে সুন্দর পপআপে বুঝিয়ে, তারপর সিস্টেমের অনুমতি-পপআপ
    private fun startPermissionFlow() {
        val granted = hasLocationPermission()
        if (granted || LocationPermissionDialog.alreadyDeclined(this)) {
            requestNotificationIfNeeded()
            return
        }
        window.decorView.post {
            if (isFinishing || isDestroyed) return@post
            showPopupSafely(onFail = { requestNotificationIfNeeded() }) {
                LocationPermissionDialog.show(
                    this,
                    onAllow = { launchLocationRequest(startup = true) },
                    onDone = { requestNotificationIfNeeded() }
                )
            }
        }
    }

    // v42: লোকেশনের ধাপ শেষ হলে (অনুমতি/না যাই হোক) নোটিফিকেশন কেন লাগে তা আগে আমাদের পপআপে বুঝিয়ে,
    // "অনুমতি" চাপলে তবেই ফোনের নোটিফিকেশন-পপআপ। Android 12 বা নিচে রানটাইম পারমিশনই নেই, তাই কিছু দেখানো হয় না।
    private fun requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) { afterNotificationStep(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) { afterNotificationStep(); return }
        if (NotificationPermissionDialog.alreadyDeclined(this)) { afterNotificationStep(); return }
        window.decorView.post {
            if (isFinishing || isDestroyed) return@post
            showPopupSafely(onFail = { afterNotificationStep() }) {
                NotificationPermissionDialog.show(
                    this,
                    onAllow = { launchNotificationRequest() },   // ফোনের পপআপের ফল notifPermLauncher থেকে এসে ধারা চালু রাখবে
                    onDone = { afterNotificationStep() }
                )
            }
        }
    }

    // v44: নোটিফিকেশনের ধাপ শেষ → আজান নির্ভরযোগ্যতার ধাপগুলো (শুধু শুরুর ধারায়; "পারমিশন" ট্যাবের বাটনে নয়)
    private fun afterNotificationStep() {
        if (startupChainActive) startAlarmSetupFlow()
    }

    // v44: আজান যেকোনো ফোনে (বিশেষত Honor/Huawei সহ পুরনো OEM ফোনে) বাজার জন্য দরকারি সেটিংসগুলো একটার পর একটা,
    // প্রতিটার আগে একই গ্লাস পপআপে কারণ বুঝিয়ে। যেটা আগে থেকেই চালু আছে সেটা দেখানো হয় না।
    private fun startAlarmSetupFlow() {
        window.decorView.post {
            if (isFinishing || isDestroyed) return@post
            // v47: কোনো ধাপের পপআপ দেখাতে সমস্যা হলে ধারাটা এখানেই থামে (একই ধাপে বারবার চেষ্টার লুপ হবে না), অ্যাপ ক্র্যাশ করবে না
            showPopupSafely(onFail = { startupChainActive = false }) {
                val step = AlarmPermissionDialog.Step.values().firstOrNull { AlarmPermissionDialog.needed(this, it) }
                if (step == null) { startupChainActive = false; return@showPopupSafely }
                AlarmPermissionDialog.show(
                    this, step,
                    onAllow = { armResume { startAlarmSetupFlow() } }, // সেটিংস থেকে ফিরলে পরের ধাপ দেখাবে
                    onDone = { startAlarmSetupFlow() }                  // "না" চাপলে সরাসরি পরের ধাপ
                )
            }
        }
    }

    // ✅ ইন-অ্যাপ আপডেট: অ্যাপ সামনে এলেই নতুন ভার্সন চেক
    override fun onStart() {
        super.onStart()
        safely("update-check") { UpdateManager.checkAndPrompt(this) }
    }

    // ✅ ইন-অ্যাপ আপডেট: "অজানা সোর্স" সেটিংস থেকে ফিরে এলে ডাউনলোড চালু
    override fun onResume() {
        super.onResume()
        safely("status-bar-edge") { SystemBarsBridge.drawBehindStatusBar(this) }   // v150: কিছু ফোন ফ্ল্যাগ রিসেট করলে আবার বসানো
        safely("update-resume") { UpdateManager.resumePending(this) }
        // v151: ব্যাকগ্রাউন্ডে নতুন নোটিফিকেশন এসে থাকলে ফিরে আসামাত্র ঘণ্টার লাল ব্যাজ হালনাগাদ
        safely("inbox-refresh") { refreshInboxBadge() }
        // ✅ v44: অ্যাপ সামনে এলেই আজান অ্যালার্মগুলো নিশ্চিত করে আবার বসানো হয় (ফোন/OEM মুছে দিয়ে থাকলে ফিরে আসে);
        // সেটিংস থেকে ফিরলে (যেমন এক্সাক্ট অ্যালার্ম অনুমতি দেওয়ার পর) নতুন অবস্থা অনুযায়ী সাথে সাথে।
        try { AlarmScheduler.scheduleAllAlarms(this) } catch (_: Throwable) {}
        // ✅ অ্যাপ সামনে এলেই (১৫ সেকেন্ডে একবার) সার্ভার থেকে সর্বশেষ হিজরি কনফিগ টেনে উইজেট সাথে সাথে আপডেট
        safely("rtdb-sync") { FirebaseDataManager.syncNow(this) }
        val pending = resumeAction
        if (pending != null && SystemClock.elapsedRealtime() - resumeArmedAt > 1200L) {
            resumeAction = null
            safely("resume-action") { if (startupChainActive) pending() }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        safely("update-dialog-cleanup") { UpdateManager.onActivityDestroyed(this) }
        // v151: এই অ্যাক্টিভিটির ইনবক্স-কলব্যাক খুলে ফেলা (ধ্বংস হওয়া ওয়েবভিউতে JS ডাকা এড়াতে)
        NotificationInbox.onChanged = null
        // v168: ধ্বংস-হওয়া ওয়েবভিউকে আর অডিও/ডাউনলোড ইভেন্ট নয় (ব্যাকগ্রাউন্ড সার্ভিস কিন্তু বাজতেই থাকে)
        safely("quran-audio-detach") { quranAudioBridge?.detach(); quranAudioBridge = null }
        // Unregister network callback
        // v47: callback রেজিস্টার না হয়ে থাকলে unregister IllegalArgumentException ছোঁড়ে — সুরক্ষিত করা হলো
        safely("unregister-network") {
            networkCallback?.let { connectivityManager.unregisterNetworkCallback(it) }
        }
        networkCallback = null
        // ✅ FIX #13 (অফলাইনে UI/UX ডিজাইন ভেঙে যাওয়ার আসল কারণ):
        // এই অ্যাপের ডিজাইন (Tailwind CSS, Font Awesome আইকন, Google Fonts) index.html-এর
        // ভেতর থেকে ইন্টারনেট (CDN) থেকে লোড হয়। WebView এগুলো নিজে থেকেই ডিস্ক-ক্যাশে জমা
        // রাখে, তাই একবার অনলাইনে লোড হয়ে গেলে পরে অফলাইনে থাকলেও ক্যাশ থেকেই দেখানো সম্ভব।
        // কিন্তু আগে এখানে প্রতিবার অ্যাপ বন্ধ হওয়ার সময় clearCache(true) কল করে সেই পুরো
        // ডিস্ক-ক্যাশটাই মুছে ফেলা হতো — ফলে অ্যাপ বন্ধ করার পরের বার যদি ইন্টারনেট ছাড়া খোলা
        // হতো, Tailwind/Font Awesome/Fonts কিছুই ক্যাশে না থাকায় পুরো ডিজাইনটাই ভেঙে (স্টাইল
        // ছাড়া কাঁচা HTML হিসেবে) দেখাত। সমাধান: clearCache(true) বাদ দেওয়া হলো, যাতে ডিস্ক-
        // ক্যাশ একবার তৈরি হলে অ্যাপ বন্ধ/চালু হওয়া সত্ত্বেও থেকে যায় এবং অফলাইনেও আসল ডিজাইনটাই
        // দেখায়। (clearHistory() রাখা হয়েছে — এটা শুধু ব্যাক/ফরোয়ার্ড ন্যাভিগেশন হিস্টোরি মোছে,
        // CDN রিসোর্স ক্যাশের সাথে সম্পর্কহীন, তাই এতে কোনো ক্ষতি নেই।)
        // v47: onCreate মাঝপথে থেমে গেলে (যেমন WebView না থাকা) webView চালুই হয়নি — তখন এখানে ক্র্যাশ নয়
        if (::webView.isInitialized) {
            safely("webview-destroy") {
                webView.apply {
                    stopLoading()
                    clearHistory()
                    removeAllViews()
                    destroy()
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        safely("status-bar-edge") { SystemBarsBridge.drawBehindStatusBar(this) }   // v150: সব ফোনে স্ট্যাটাস বার অ্যাপের ব্যাকগ্রাউন্ডের সাথে মেলে
        safely("firebase-init") { FirebaseApp.initializeApp(this) }

        // ✅ v47: কিছু ফোনে সিস্টেম "Android System WebView" নেই/বন্ধ/আপডেট হচ্ছে — তখন layout inflate করতেই
        // অ্যাপ ক্র্যাশ করত। এখন ক্র্যাশের বদলে পরিষ্কার বার্তা দেখিয়ে অ্যাপ শান্তভাবে বন্ধ হয়।
        try {
            setContentView(R.layout.activity_main)
            webView = findViewById(R.id.webview)
        } catch (t: Throwable) {
            android.util.Log.e("PatheyoSafe", "WebView/layout init failed", t)
            try {
                android.widget.Toast.makeText(
                    this,
                    "এই ফোনে \"Android System WebView\" চালু নেই বা আপডেট দরকার। Play Store থেকে আপডেট/চালু করে আবার চেষ্টা করুন।",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            } catch (_: Throwable) { }
            finish()
            return
        }

        safely("system-bars") { SystemBarsBridge.applySaved(this) }   // v139: শেষ থিম অনুযায়ী স্ট্যাটাস বারের আইকন, প্রথম ফ্রেম থেকেই
        safely("splash") { findViewById<SplashView>(R.id.splash_root)?.start() }
        jsBridge = WidgetJSBridge(this)
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        setupWebView()
        safely("safe-insets") { setupSafeInsets() }
        setupBackNavigation()
        safely("network-monitor") { setupNetworkMonitoring() }

        safely("stop-azan") {
            if (intent?.getBooleanExtra("stopAzan", false) == true) {
                startService(Intent(this, AzanForegroundService::class.java).apply { action = AzanForegroundService.ACTION_STOP })
            }
        }

        startupChainActive = true
        try {
            startPermissionFlow()
        } catch (t: Throwable) {
            android.util.Log.e("PatheyoSafe", "permission flow failed", t)
            startupChainActive = false
        }

        // ✅ এখন থেকে বাকি পারমিশনগুলো (Exact Alarm, ব্যাটারি অপ্টিমাইজেশন, ফুল-স্ক্রিন অ্যালার্ম)
        // অ্যাপ চালু হওয়ার সাথে সাথে একসাথে/জোর করে চাওয়া হয় না — আগে একসাথে অনেকগুলো Settings
        // স্ক্রিন পরপর খোলার চেষ্টা হতো, যেটা অনেক ফোনে (বিশেষত পুরনো/কম দামি ফোনে) ঠিকমতো কাজ
        // করত না — কোনোটা স্ক্রিনেই আসত না, বা ইউজার বুঝতে পারত না কোনটার জন্য কোন পপ-আপ। এখন
        // এইগুলো "উইজেট হাব" ট্যাবের পাশে নতুন "পারমিশন" ট্যাবে আলাদা আলাদা বাটনে পরিষ্কার বাংলা
        // ব্যাখ্যাসহ দেওয়া আছে — ইউজার নিজে বুঝে-শুনে একটার পর একটা অন করতে পারবে, এবং সেটাই
        // সবচেয়ে বিশ্বাসযোগ্যভাবে কাজ করে (Android নিজেই একসাথে অনেক Settings intent পছন্দ করে না)।

        // ✅ v47: নিচের প্রতিটা ব্যাকগ্রাউন্ড-সেটআপ আলাদা সুরক্ষিত — একটায় (যেমন কোনো OEM-এ অ্যালার্ম/WorkManager/Firebase)
        // সমস্যা হলেও অ্যাপে ঢোকা আটকাবে না, বাকি কাজগুলোও চলবে। (আগে এগুলো একটার পর একটা অসুরক্ষিতভাবে চলত —
        // মাঝে একটা exception হলেই পুরো অ্যাপ ক্র্যাশ করে বেরিয়ে যেত।)

        // ✅ v24: উইজেটের ৮০-মিনিট WorkManager ব্যাকআপ এখন এক জায়গা থেকে (WidgetRefreshScheduler)
        safely("widget-backup-work") { WidgetRefreshScheduler.ensureBackupWork(this) }

        safely("notif-check-work") {
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "ibadat_notif_check",
                ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<IslamicNotificationWorker>(1, TimeUnit.HOURS).build())
        }
        safely("azan-alarms") { AlarmScheduler.scheduleAllAlarms(this) }
        safely("widget-schedule") { WidgetRefreshScheduler.scheduleAll(this) } // উইজেট রিফ্রেশ শিডিউলার চালু করা

        // জুমার নোটিফিকেশন স্কেজুল করা
        safely("scheduled-notifications") { ScheduledNotificationScheduler.scheduleAllNotifications(this) }
        // ✅ FIX #NEW: Doze-প্রতিরোধী হার্টবিট চেইনও এখানে (আবারও, নিরাপদে) শুরু/রিফ্রেশ করা হচ্ছে
        safely("heartbeat") { ScheduledNotificationScheduler.scheduleHeartbeat(this) }

        // Firebase Realtime Database — আরবি তারিখ সরাসরি widget-এ এবং WebView-এর জন্য এডজাস্টমেন্ট
        safely("rtdb") {
            FirebaseDataManager.onConfigChanged = cb@{ adj, directDate, overrideJson ->
                // v47: অ্যাক্টিভিটি বন্ধ/ধ্বংস হয়ে গেলে পুরনো WebView-এ আর কিছু পাঠানো হবে না
                if (isFinishing || isDestroyed) return@cb
                try {
                    pendingHijriAdjustment = adj
                    pendingDirectDate = directDate
                    pendingOverrideJson = overrideJson
                    jsBridge.injectHijriConfig(adj, pendingMethodId)
                    if (pageLoadedOnce) {
                        injectHijriConfigToJS(adj, pendingMethodId, directDate, overrideJson)
                    }
                } catch (t: Throwable) {
                    android.util.Log.e("PatheyoSafe", "hijri config apply failed", t)
                }
            }
            FirebaseDataManager.startRtdbListener(this)
            FirebaseDataManager.syncNow(this, force = true)   // সার্ভার থেকে সর্বশেষ তারিখ সাথে সাথে টেনে উইজেটে বসানো
        }

        // Firebase Remote Config — শুধুমাত্র method_id (যদি ভবিষ্যতে প্রয়োজন হয়)
        safely("remote-config") { setupFirebaseRemoteConfig() }

        // FCM topic subscribe — অ্যাপ বন্ধ থাকলেও push পাওয়ার জন্য
        safely("fcm-subscribe") { PatheyoMessagingService.subscribeAll() }
        // v65: এই ফোনের push token Supabase-এ নিবন্ধন (ওয়েবসাইট থেকে সরাসরি পাঠানোর জন্য)
        safely("push-token") { PushTokenRegistrar.register(this) }   // "all" + "prayer_updates"
        // টেস্ট মেসেজ (Firebase Console → Send test message) এর জন্য টোকেন Logcat-এ দেখা যাবে (ট্যাগ: PatheyoFCM)
        safely("fcm-token") {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { tok ->
                android.util.Log.d("PatheyoFCM", "token=$tok")
            }
        }

        // ✅ v49: ভার্সন-ভিত্তিক টপিক (অ্যাডমিন প্যানেল থেকে নির্দিষ্ট ভার্সনের ইউজারকে পাঠানোর জন্য)
        safely("fcm-version-topic") { PatheyoMessagingService.syncVersionTopic(this) }
        // ✅ v49: অ্যাপ সামনে থাকলে ~৫ মিনিটে একবার "আমি সক্রিয়" সংকেত (অ্যাডমিন প্যানেলে ব্যবহারকারী গণনা)
        safely("heartbeat-loop") { com.gunjoron.patheyo.stats.AppHeartbeat.startLoop(this) }
        // ✅ v49: ওয়েবসাইটের "অ্যাপ আপডেট করুন" বাটন থেকে (patheyo://update) এলে সাথে সাথে আপডেট চেক
        safely("update-deeplink") { handleUpdateLink(intent) }
    }

    // v94: স্ট্যাটাস বার / নচ কতটা WebView-র ওপর **সত্যিই চেপে বসেছে** সেটা (dp = CSS px) পেজে পাঠানো।
    // - Edge-to-edge ফোনে (WebView স্ক্রিনের একদম ওপর থেকে শুরু): পুরো স্ট্যাটাস বারের উচ্চতা -> হেডার তার নিচ থেকে শুরু হয়।
    // - যে ফোনে সিস্টেম নিজেই স্ট্যাটাস বারের নিচে থেকে WebView বসায়: ওভারল্যাপ ০ -> বাড়তি ফাঁক নেই (আগে এই ফোনে হেডার অনেক নিচে নামত)।
    // হিসাব: max(0, স্ট্যাটাস বারের উচ্চতা - WebView-র ওপরের কিনারা উইন্ডোর কোথায়)।
    private var safeTopDp: Float = -1f
    private var barTopPx: Int = 0

    private fun recomputeSafeTop() {
        val loc = IntArray(2)
        webView.getLocationInWindow(loc)
        val overlapPx = (barTopPx - loc[1]).coerceAtLeast(0)
        val d = resources.displayMetrics.density
        val dp = if (d > 0f) overlapPx / d else 0f
        if (dp != safeTopDp) { safeTopDp = dp; pushSafeTop() }
    }

    private fun pushSafeTop() {
        if (safeTopDp < 0f) return
        val v = safeTopDp
        webView.post {
            try { webView.evaluateJavascript("if(typeof window.setNativeSafeTop==='function') window.setNativeSafeTop($v);", null) } catch (_: Throwable) { }
        }
    }

    private fun setupSafeInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(webView) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            barTopPx = b.top
            recomputeSafeTop()
            insets
        }
        webView.addOnLayoutChangeListener { _, _, top, _, _, _, oldTop, _, _ -> if (top != oldTop) recomputeSafeTop() }
        ViewCompat.requestApplyInsets(webView)
        webView.post { recomputeSafeTop() }
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setGeolocationEnabled(true)
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = true
            databaseEnabled = true
            textZoom = 100 // ✅ ফোনের সিস্টেম ফন্ট-সাইজ বড়/ছোট করা থাকলেও অ্যাপের লে-আউট যেন না ভাঙে
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // অ্যাপে সব API কল HTTPS-এ হয়, তাই আর ALWAYS_ALLOW (নিরাপত্তা ঝুঁকিপূর্ণ) দরকার নেই
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }
        }

        // ✅ পারফরম্যান্স: ওভারস্ক্রল গ্লো ইফেক্ট বন্ধ করা হলো (কম দামি ফোনে টানাটানি/স্ক্রলের
        // সময় এই গ্লো এফেক্টটা মাঝেমধ্যে জ্যাঙ্ক/আটকে থাকার মতো অনুভূতি তৈরি করে)। হার্ডওয়্যার
        // এক্সিলারেশন এমনিতেই ডিফল্টভাবে চালু থাকে (API 14+), তাই এখানে জোর করে লেয়ার-টাইপ পাল্টানো
        // হচ্ছে না — কিছু পুরনো/কম-RAM ফোনে জোর করা লেয়ার উল্টো রেন্ডারিং সমস্যা তৈরি করতে পারে।
        webView.overScrollMode = android.view.View.OVER_SCROLL_NEVER

        webView.addJavascriptInterface(jsBridge, "AndroidWidgetBridge")
        // ✅ v139: স্ট্যাটাস বারের আইকনের রং অ্যাপের থিম (লাইট/ডার্ক) অনুযায়ী — JS এখান থেকেই জানায়
        webView.addJavascriptInterface(SystemBarsBridge(this), "PatheyoSystemBars")
        // ✅ কুরআন পেজের মুসহাফ PDF ও তরজমা ডাউনলোড: Kotlin ডাউনলোডার (অ্যাপের স্টোরেজে সেভ) — JS এগুলোই খোঁজে
        webView.addJavascriptInterface(
            com.gunjoron.patheyo.quran.QuranFileBridge(applicationContext, webView, com.gunjoron.patheyo.quran.QuranFileBridge.Kind.PDF), "QuranNative")
        webView.addJavascriptInterface(
            com.gunjoron.patheyo.quran.QuranFileBridge(applicationContext, webView, com.gunjoron.patheyo.quran.QuranFileBridge.Kind.TARJAMA), "QuranTarjamaNative")

        // ✅ v83: হাদিসের ৬টি কিতাব GitHub Release থেকে নামানোর ডাউনলোডার (অ্যাপে আর বসানো নেই) — JS এটাই খোঁজে
        webView.addJavascriptInterface(
            com.gunjoron.patheyo.hadith.HadithFileBridge(applicationContext, webView), "HadithNative")

        // ✅ v143: ওয়েবসাইটের অ্যাডমিন প্যানেল থেকে নিয়ন্ত্রিত বিজ্ঞাপন (স্লাইডার / নিচের ব্যানার / অ্যাপ-খোলা পপআপ) — JS এটাই খোঁজে
        webView.addJavascriptInterface(
            com.gunjoron.patheyo.ads.AdsBridge(applicationContext, webView), "PatheyoAds")

        // ✅ v151: ঘণ্টা আইকনের নোটিফিকেশন ইনবক্স (লাল ব্যাজ + তালিকা + ট্যাপে একটা করে কমা) — JS এটাই খোঁজে
        webView.addJavascriptInterface(
            com.gunjoron.patheyo.notification.NotificationInboxBridge(this), "PatheyoInbox")
        // ✅ v161: আয়াত/হাদিস/দোয়ার শেয়ার কার্ড — ছবি শেয়ার-শিটে পাঠানো / গ্যালারিতে সেভ — JS এটাই খোঁজে
        webView.addJavascriptInterface(com.gunjoron.patheyo.share.ShareBridge(this), "PatheyoShare")
        // ✅ v165: পুরো-অ্যাপ ব্যাকআপ/রিস্টোর (সেটিংস) — ফাইল সেভ / শেয়ার / বাছাই
        backupBridge = com.gunjoron.patheyo.backup.BackupBridge(this, webView) {
            backupPickLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*"))
        }
        webView.addJavascriptInterface(backupBridge!!, "PatheyoBackup")
        // ✅ v168: কুরআন তিলাওয়াতের পূর্ণ ব্যাকগ্রাউন্ড প্লেয়ার (নেটিভ সার্ভিস) + সূরা অডিও অফলাইন ডাউনলোড — JS এটাই খোঁজে
        quranAudioBridge = com.gunjoron.patheyo.audio.QuranAudioBridge(applicationContext, webView)
        webView.addJavascriptInterface(quranAudioBridge!!, "PatheyoQuranAudio")
        // ✅ v168: প্রতিদিনের তারিখ-কার্ড (হোমের "তারিখ-কার্ড" টাইল এখান দিয়েই নেটিভ স্ক্রিন খোলে)
        webView.addJavascriptInterface(com.gunjoron.patheyo.datecard.DateCardBridge(this), "PatheyoDateCard")
        // নতুন নোটিফিকেশন এলে (পুশ/আপডেট) বা পঠিত হলে ওয়েবভিউকে জানানো — অ্যাপ খোলা থাকলে ব্যাজ সাথে সাথে বদলায়
        NotificationInbox.onChanged = { webView.post { safely("inbox-js") { refreshInboxBadge() } } }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                // সরাসরি পারমিশন গ্রান্ট করে দিচ্ছি, কারণ অ্যাপ লেভেলে লোকেশন পারমিশন অলরেডি হ্যান্ডেল করা আছে
                callback?.invoke(origin, true, false)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            // ✅ ডাউনলোড করা কুরআন ফাইল https://quran-local.invalid/… ঠিকানায় দেখানো (JS সরাসরি বাইট পড়ে)
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                // ফিচার পেজের ফাইল (https://appassets.patheyo.invalid/…), হাদিসের কিতাব, কুরআনের ফাইল — তিনটাই assets/স্টোরেজ থেকে দেওয়া
                val local = try {
                    com.gunjoron.patheyo.web.AssetServer.intercept(applicationContext, request)
                        ?: com.gunjoron.patheyo.hadith.HadithLocalServer.intercept(applicationContext, request)
                        ?: com.gunjoron.patheyo.quran.QuranLocalServer.intercept(applicationContext, request)
                } catch (_: Throwable) { null }
                return local ?: super.shouldInterceptRequest(view, request)
            }

            // v100: বিজ্ঞাপন/ওয়েবসাইট লিংকে (https, অ্যাপের নিজস্ব *.invalid ঠিকানা ছাড়া) চাপ দিলে অ্যাপ বদলে ফোনের ব্রাউজারে খোলে --
            // নইলে লিংকটা অ্যাপের WebView-তেই লোড হয়ে পুরো অ্যাপ ঢেকে দিত। ফিচার পেজের (iframe) লিংকও এখান দিয়েই যায়।
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val scheme = u.scheme?.lowercase()
                val host = u.host?.lowercase() ?: ""
                if ((scheme == "http" || scheme == "https") && !host.endsWith(".invalid")) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Throwable) { }
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                pageLoadedOnce = true
                pushSafeTop()
                findViewById<SplashView>(R.id.splash_root)?.markPageLoaded()
                injectHijriConfigToJS(pendingHijriAdjustment, pendingMethodId, pendingDirectDate, pendingOverrideJson)
            }

            // ✅ v47: কম-RAM ফোনে (বা WebView আপডেটের সময়) সিস্টেম WebView-র রেন্ডারার প্রসেসটা মেরে ফেলতে পারে।
            // এই মেথড না থাকলে অ্যান্ড্রয়েড পুরো অ্যাপটাকেই ক্র্যাশ করিয়ে দেয় (সরাসরি "অ্যাপ বন্ধ হয়ে গেল")।
            // এখন অ্যাপ ক্র্যাশ না করে পেজটা নতুন করে তুলে আনে; ১০ সেকেন্ডের মধ্যে আবার ঘটলে অসীম লুপ এড়াতে বন্ধ হয়।
            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                android.util.Log.e("PatheyoSafe", "WebView renderer gone")
                val now = SystemClock.elapsedRealtime()
                val tooSoon = lastRendererRecoverAt != 0L && now - lastRendererRecoverAt < 10_000L
                lastRendererRecoverAt = now
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (tooSoon) finish() else recreate()
                }
                return true
            }
        }

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("window.handleNativeBackPress ? window.handleNativeBackPress() : false") { result ->
                    if (result == "false" || result == "null") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
    }

    private fun setupNetworkMonitoring() {
        val networkRequest = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                webView.post {
                    webView.evaluateJavascript("if(typeof window.setNativeNetworkStatus==='function') window.setNativeNetworkStatus(true);", null)
                }
            }

            override fun onLost(network: Network) {
                webView.post {
                    webView.evaluateJavascript("if(typeof window.setNativeNetworkStatus==='function') window.setNativeNetworkStatus(false);", null)
                }
            }
        }

        connectivityManager.registerNetworkCallback(networkRequest, networkCallback!!)

        // Initial network status check
        val isOnline = isNetworkAvailable()
        webView.postDelayed({
            webView.evaluateJavascript("if(typeof window.setNativeNetworkStatus==='function') window.setNativeNetworkStatus($isOnline);", null)
        }, 500)
    }

    private fun isNetworkAvailable(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun setupFirebaseRemoteConfig() {
        remoteConfig = FirebaseRemoteConfig.getInstance()

        // ✅ আগে ছিল 0 (প্রতিবার খুলেই টানত) — এখন ১ ঘন্টা পরপর টানবে
        val configSettings = FirebaseRemoteConfigSettings.Builder()
            .setMinimumFetchIntervalInSeconds(3600)
            .build()
        remoteConfig.setConfigSettingsAsync(configSettings)
        // hijri_adjustment এখন RTDB থেকে আসে, তাই এখানে ডিফল্ট প্রয়োজন নেই
        remoteConfig.setDefaultsAsync(mapOf("app_version" to "1.0.0"))

        remoteConfig.fetchAndActivate().addOnCompleteListener(this) { task ->
            if (task.isSuccessful) {
                updateAndApplyConfig()
            }
        }

        // রিয়েল-টাইম লিসেনার (অ্যাপ খোলা থাকলে Remote Config পরিবর্তন হলেই ধরবে)
        remoteConfig.addOnConfigUpdateListener(object : ConfigUpdateListener {
            override fun onUpdate(configUpdate: ConfigUpdate) {
                remoteConfig.activate().addOnCompleteListener { task ->
                    if (task.isSuccessful) updateAndApplyConfig()
                }
            }
            override fun onError(error: FirebaseRemoteConfigException) {}
        })
    }

    private fun updateAndApplyConfig() {
        // v47: Remote Config-এর কলব্যাক মেইন থ্রেডে চলে — এখানকার কোনো exception সরাসরি অ্যাপ ক্র্যাশ করাত
        if (isFinishing || isDestroyed) return
        safely("apply-config") { updateAndApplyConfigUnsafe() }
    }

    private fun updateAndApplyConfigUnsafe() {
        // নোট: hijri_adjustment এখন RTDB (FirebaseDataManager) থেকে আসে
        val method = getIslamicMethodId()
        pendingMethodId = method

        jsBridge.injectHijriConfig(pendingHijriAdjustment, method)
        PrayerWidgetProvider.updateAllWidgets(this@MainActivity)

        if (pageLoadedOnce) {
            injectHijriConfigToJS(pendingHijriAdjustment, method, pendingDirectDate, pendingOverrideJson)
        }

        // Remote Config-এ notifications_config_json থাকলে/বদলে গেলে সেটাও এখানেই
        // সাথে সাথে প্রয়োগ করা হচ্ছে — আলাদা fetch করার দরকার নেই, remoteConfig
        // ইতিমধ্যে fetchAndActivate() হয়ে গেছে
        com.gunjoron.patheyo.notification.NotificationRemoteConfigSync.applyFromActivatedConfig(
            this@MainActivity, remoteConfig
        ) { updated ->
            if (updated) {
                com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(this@MainActivity)
            }
        }
    }

    private fun injectHijriConfigToJS(adjustment: Int, methodId: Int, directDate: String?, overrideJson: String?) {
        webView.post {
            // JSONObject.quote: মাসের নামে ' বা " থাকলেও (যেমন Rabi' al-Thani) JS ভাঙবে না
            val dateParam = if (directDate != null) org.json.JSONObject.quote(directDate) else "null"
            val overrideParam = overrideJson ?: "null"
            webView.evaluateJavascript(
                "if(typeof window.setNativeHijriConfig==='function') window.setNativeHijriConfig({adjustment:$adjustment,methodId:$methodId,directDate:$dateParam,override:$overrideParam});",
                null
            )
        }
    }

    private fun getIslamicMethodId(): Int {
        return try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            when (tm.simCountryIso.lowercase(Locale.getDefault())) {
                "bd", "in", "pk" -> 1
                "sa", "ae", "qa", "kw", "bh", "om" -> 4
                "us", "ca" -> 2
                "eg" -> 5
                "tr" -> 13
                else -> 3
            }
        } catch (_: Exception) { 1 }
    }

    /** ওয়েবভিউর ঘণ্টার ব্যাজ ও (খোলা থাকলে) নোটিফিকেশন তালিকা নতুন করে আঁকতে বলে */
    private fun refreshInboxBadge() {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("if(typeof window.__inboxChanged==='function') window.__inboxChanged();", null)
    }

    override fun onNewIntent(intent: Intent) {
        @Suppress("DEPRECATION")
        super.onNewIntent(intent)
        safely("update-deeplink") { handleUpdateLink(intent) }
        if (intent.getBooleanExtra("stopAzan", false) == true) {
            startService(Intent(this, AzanForegroundService::class.java).apply { action = AzanForegroundService.ACTION_STOP })
            webView.post { webView.evaluateJavascript("if(typeof window.onAzanStopped==='function') window.onAzanStopped();", null) }
        }
    }

    /** v49: patheyo://update লিংক (ওয়েবসাইটের আপডেট বাটন) এলে জোর করে আপডেট চেক চালায় */
    private fun handleUpdateLink(i: Intent?) {
        val d = i?.data ?: return
        if (i.action == Intent.ACTION_VIEW && d.scheme == "patheyo" && d.host == "update") {
            i.data = null      // একই ইনটেন্ট দ্বিতীয়বার প্রসেস না হতে
            UpdateManager.checkNow(this)
        }
    }
}
