package com.gunjoron.patheyo.datecard

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.Executors

/**
 * তারিখ-কার্ডের স্ক্রিন: আজকের কার্ডের প্রিভিউ, ১২টি ইসলামিক থিম (বা "অটো" = প্রতিদিন নতুন), পোস্ট/স্টোরি মাপ,
 * ফোনের গ্যালারি থেকে নিজের ব্যাকগ্রাউন্ড, শেয়ার / গ্যালারিতে সেভ, আর রাত ১২টার অটো-তৈরির সুইচ।
 */
class DateCardActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: DateCardPrefs
    private lateinit var preview: ImageView
    private lateinit var themeNote: TextView
    private lateinit var themeRow: LinearLayout
    private lateinit var formatRow: LinearLayout
    private lateinit var photoBox: LinearLayout
    private lateinit var removePhotoBtn: TextView
    private var token = 0
    private var current: Bitmap? = null
    private var wantShare = false

    private val NAVY = Color.parseColor("#0E264D")
    private val CARD = Color.parseColor("#16355F")
    private val GOLD = Color.parseColor("#E5B94A")
    private val DIM = Color.parseColor("#9FB3D1")

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) importPhoto(uri) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        prefs = DateCardPrefs(this)
        wantShare = intent?.getBooleanExtra("share", false) == true
        setContentView(buildUi())
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
        refreshAll()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("share", false)) { wantShare = true; renderPreview() }
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdownNow()
    }

    // ------------------------------------------------------------------ UI গঠন

    private fun tv(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 14f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) Color.parseColor("#1B1B1B") else Color.WHITE)
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); if (filled) setColor(GOLD) else { setColor(Color.TRANSPARENT); setStroke(dp(1), DIM) } }
        setPadding(dp(16), dp(11), dp(16), dp(11))
        setOnClickListener { onClick() }
    }

    private fun label(t: String) = tv(t, 13f, DIM, true).apply { setPadding(dp(2), dp(20), 0, dp(8)) }

    private fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(10), dp(10), dp(10))
        background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(CARD) }
        addView(tv(text, 14.5f).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        addView(SwitchCompat(this@DateCardActivity).apply { isChecked = checked; setOnCheckedChangeListener { _, v -> onChange(v) } })
    }

    private fun buildUi(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(NAVY) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(28)) }
        scroll.addView(col)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }

        // শিরোনাম
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("←", 26f).apply { setPadding(dp(4), dp(8), dp(16), dp(8)); setOnClickListener { finish() } })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(tv("প্রতিদিনের তারিখ-কার্ড", 20f, Color.WHITE, true))
        ht.addView(tv("প্রতি রাত ১২টায় নিজে তৈরি হয়", 13f, DIM))
        head.addView(ht)
        col.addView(head)

        // প্রিভিউ
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setBackgroundColor(CARD)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat()) }
            }
            elevation = dp(6).toFloat()
        }
        col.addView(preview, LinearLayout.LayoutParams(-1, 10).apply { topMargin = dp(14) })
        themeNote = tv("", 13f, DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        col.addView(themeNote, LinearLayout.LayoutParams(-1, -2))

        // শেয়ার / সেভ
        val acts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        acts.addView(pill("শেয়ার করুন", true) { shareNow() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            acts.addView(pill("গ্যালারিতে সেভ", false) { saveNow() }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(acts, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // থিম
        col.addView(label("থিম বাছুন"))
        themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(themeRow) })

        // মাপ
        col.addView(label("কার্ডের মাপ"))
        formatRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(formatRow)

        // ব্যাকগ্রাউন্ড
        col.addView(label("নিজের ব্যাকগ্রাউন্ড"))
        col.addView(pill("ফোনের গ্যালারি থেকে ছবি বাছুন", false) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }, LinearLayout.LayoutParams(-1, -2))
        photoBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        photoBox.addView(tv("ছবির ওপর কালো পর্দা (লেখা পড়ার সুবিধায়)", 13f, DIM).apply { setPadding(dp(2), dp(14), 0, dp(4)) })
        photoBox.addView(SeekBar(this).apply {
            max = 80; progress = prefs.scrim
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { prefs.scrim = s?.progress ?: 45; renderPreview() }
            })
        })
        removePhotoBtn = pill("ছবি সরিয়ে থিমের ব্যাকগ্রাউন্ডে ফিরুন", false) { prefs.usePhoto = false; refreshAll() }
        photoBox.addView(removePhotoBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(photoBox)

        // অটো
        col.addView(label("স্বয়ংক্রিয়"))
        val sw = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun gap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        sw.addView(switchRow("প্রতিদিন রাত ১২টায় নিজে তৈরি করুন", prefs.autoDaily) { prefs.autoDaily = it; DateCardScheduler.schedule(this) }, gap())
        sw.addView(switchRow("তৈরি হলে নোটিফিকেশনে দেখান (শব্দ হয় না)", prefs.notify) { prefs.notify = it }, gap())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            sw.addView(switchRow("প্রতিদিনের কার্ড নিজে গ্যালারিতে সেভ করুন", prefs.saveGallery) { prefs.saveGallery = it }, gap())
        }
        col.addView(sw)
        col.addView(tv("হিজরি তারিখ অ্যাপের হোম/উইজেটের হিসাব মেনেই আসে।", 12f, DIM).apply { setPadding(dp(2), dp(10), 0, 0) })
        return root
    }

    // ------------------------------------------------------------------ অবস্থা অনুযায়ী পুনর্গঠন

    private fun refreshAll() {
        buildFormatChips()
        buildThemeChips()
        photoBox.visibility = if (prefs.usePhoto) View.VISIBLE else View.GONE
        renderPreview()
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(if (selected) Color.parseColor("#1B1B1B") else Color.WHITE)
        background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(if (selected) GOLD else CARD) }
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setOnClickListener { onClick() }
    }

    private fun buildFormatChips() {
        formatRow.removeAllViews()
        val lp = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) } }
        formatRow.addView(chip("পোস্ট (৪:৫)", prefs.format == "post") { prefs.format = "post"; refreshAll() }, lp())
        formatRow.addView(chip("স্টোরি (৯:১৬)", prefs.format == "story") { prefs.format = "story"; refreshAll() }, lp())
    }

    private fun buildThemeChips() {
        themeRow.removeAllViews()
        val tw = dp(78); val th = (tw * 1.25f).toInt()
        fun cell(title: String, selected: Boolean, thumb: Bitmap?, onClick: () -> Unit): View {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 0, dp(10), 0) }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setBackgroundColor(CARD)
                if (thumb != null) setImageBitmap(thumb)
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat()) }
                }
                foreground = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(if (selected) 3 else 1), if (selected) GOLD else Color.parseColor("#33FFFFFF")) }
            }
            box.addView(iv, LinearLayout.LayoutParams(tw, th))
            box.addView(tv(title, 11.5f, if (selected) GOLD else DIM, selected).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0); maxLines = 2; width = tw })
            box.setOnClickListener { onClick() }
            return box
        }
        val sel = prefs.theme
        val autoCell = cell("অটো (প্রতিদিন নতুন)", sel == "auto", null) { prefs.theme = "auto"; refreshAll() }
        themeRow.addView(autoCell)
        // থাম্বনেইল পেছনে আঁকা
        val info = DateCardRenderer.infoFor(this)
        val holders = HashMap<String, ImageView>()
        DateCardThemes.ALL.forEach { t ->
            val v = cell(t.name, sel == t.id, null) { prefs.theme = t.id; refreshAll() }
            themeRow.addView(v)
            holders[t.id] = ((v as LinearLayout).getChildAt(0)) as ImageView
        }
        ((autoCell as LinearLayout).getChildAt(0) as ImageView).setImageDrawable(null)
        val ctx = applicationContext
        val fmt = prefs.format
        worker.execute {
            try {
                DateCardThemes.ALL.forEach { t ->
                    val b = DateCardRenderer.render(ctx, info, t, fmt, null, 0, 240)
                    ui.post { holders[t.id]?.setImageBitmap(b) }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun renderPreview() {
        val my = ++token
        val w = resources.displayMetrics.widthPixels - dp(32)
        val ratio = DateCardRenderer.ratio(prefs.format)
        preview.layoutParams = (preview.layoutParams as LinearLayout.LayoutParams).apply { width = -1; height = (w * ratio).toInt() }
        val ctx = applicationContext
        worker.execute {
            try {
                val now = System.currentTimeMillis()
                val bmp = DateCardRenderer.renderFor(ctx, now, prefs, 1080)
                val info = DateCardRenderer.infoFor(ctx, now)
                val name = if (prefs.usePhoto) "আপনার ছবি" else DateCardThemes.forDay(prefs.theme, info.dayOfYear, info.year).name
                ui.post {
                    if (my != token || isFinishing) return@post
                    current = bmp
                    preview.setImageBitmap(bmp)
                    themeNote.text = (if (prefs.usePhoto) "ব্যাকগ্রাউন্ড: " else if (prefs.theme == "auto") "আজকের থিম (অটো): " else "থিম: ") + name
                    if (wantShare) { wantShare = false; shareNow() }
                }
            } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------ ছবি বাছাই

    private fun importPhoto(uri: Uri) {
        val ctx = applicationContext
        worker.execute {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: throw IllegalStateException()
                val deg = try {
                    contentResolver.openInputStream(uri)?.use {
                        when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                } catch (_: Throwable) { 0f }
                if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
                DateCardPrefs(ctx).photoFile().outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                bmp.recycle()
                ui.post { prefs.usePhoto = true; refreshAll() }
            } catch (_: Throwable) {
                ui.post { Toast.makeText(this, "ছবিটা খোলা যায়নি, অন্য ছবি বাছুন", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    // ------------------------------------------------------------------ শেয়ার / সেভ

    private fun shareNow() {
        val bmp = current ?: run { Toast.makeText(this, "কার্ড তৈরি হচ্ছে, একটু অপেক্ষা করুন", Toast.LENGTH_SHORT).show(); return }
        val uri = DateCardGenerator.shareUri(this, bmp) ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(send, "শেয়ার করুন").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) {}
    }

    private fun saveNow() {
        val bmp = current ?: return
        val ok = DateCardGenerator.saveToGallery(this, bmp, "patheyo_datecard_" + System.currentTimeMillis())
        Toast.makeText(this, if (ok) "গ্যালারির Pictures/Patheyo ফোল্ডারে সেভ হয়েছে" else "সেভ করা যায়নি", Toast.LENGTH_SHORT).show()
    }
}
