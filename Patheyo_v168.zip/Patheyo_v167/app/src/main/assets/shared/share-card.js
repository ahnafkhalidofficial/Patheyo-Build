/* পাথেয় — শেয়ার কার্ড (আয়াত / হাদিস / দোয়া)।
   দোয়া, হাদিস ও কুরআন — তিন ফিচারই এই একটি ফাইল ব্যবহার করে:
     <script src="https://appassets.patheyo.invalid/shared/share-card.js"></script>
     PtShareCard.open({ kind:'dua'|'ayah'|'hadith', title, ar, tr, bn, ref });
   - 1080×1350 (৪:৫) PNG ছবি আঁকে (WhatsApp / Facebook / Instagram-এ সুন্দর দেখায়)।
   - নিচে পপআপে: প্রিভিউ, ৬টি রঙের থিম, "উচ্চারণ/অর্থ" চালু-বন্ধ, শেয়ার / গ্যালারিতে সেভ / লেখা কপি।
   - নেটিভ ব্রিজ PatheyoShare (Kotlin) থাকলে সেটা দিয়ে শেয়ার; না থাকলে (ব্রাউজারে) ডাউনলোড/Web Share। */
(function () {
  'use strict';
  if (window.PtShareCard) return;

  var BASE = 'https://appassets.patheyo.invalid/';
  var W = 1080, H = 1350;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }

  /* ---------- থিম ---------- */
  var THEMES = [
    { id: 'night',  n: 'নীল রাত',  bg: ['#0A1F4D', '#123A7A'], glow: 'rgba(120,170,255,.22)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.78)', gold: '#F5C95A', pat: 'rgba(255,255,255,.055)', dot: '#1B4FA3' },
    { id: 'emerald',n: 'পান্না সবুজ', bg: ['#06382B', '#0E6B4E'], glow: 'rgba(120,255,200,.20)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.80)', gold: '#F5D56E', pat: 'rgba(255,255,255,.055)', dot: '#0E8A63' },
    { id: 'sand',   n: 'মরুর বালি',  bg: ['#F7EBD0', '#EBD5A6'], glow: 'rgba(255,255,255,.55)', ink: '#3A2A10', mut: '#6B5530', gold: '#B4690E', pat: 'rgba(120,80,20,.07)', dot: '#C9983A' },
    { id: 'dusk',   n: 'গোধূলি',    bg: ['#2B1650', '#7A2F6B'], glow: 'rgba(255,170,220,.20)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.80)', gold: '#FFD27A', pat: 'rgba(255,255,255,.05)', dot: '#8E3D86' },
    { id: 'pearl',  n: 'মুক্তা সাদা', bg: ['#FFFFFF', '#EEF3FA'], glow: 'rgba(255,255,255,0)', ink: '#0C1B33', mut: '#4F6280', gold: '#0E7BB8', pat: 'rgba(14,60,120,.06)', dot: '#9DB4D6' },
    { id: 'ink',    n: 'গাঢ় কালো',  bg: ['#0B0B10', '#1C1C26'], glow: 'rgba(255,215,120,.12)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.75)', gold: '#E8B84A', pat: 'rgba(255,255,255,.04)', dot: '#3A3A4A' }
  ];
  var KIND = { dua: 'দোয়া', ayah: 'কুরআনের আয়াত', hadith: 'হাদিস' };

  /* ---------- ফন্ট (কার্ডের ছবিতে নিজের ফন্ট লাগে — ফিচারের CSS-এর উপর ভরসা না করে নিজেই লোড করি) ---------- */
  var fontsP = null;
  function loadFonts() {
    if (fontsP) return fontsP;
    function face(name, file, weight) {
      try { var f = new FontFace(name, 'url(' + BASE + file + ')', { weight: weight || '400' }); document.fonts.add(f); return f.load(); }
      catch (e) { return Promise.resolve(); }
    }
    fontsP = Promise.all([
      face('PtCardAr', 'fonts/web/uthmanic-hafs-4baeb996.woff2'),
      face('PtCardBn', 'fonts/Gunjoron-Font-Normal.ttf', '400'),
      face('PtCardBn', 'fonts/Gunjoron-Font-Bold.ttf', '700')
    ]).catch(function () {});
    return fontsP;
  }

  /* ---------- আঁকার সহায়ক ---------- */
  function wrapLines(ctx, text, maxW) {
    var words = String(text || '').replace(/\s+/g, ' ').trim().split(' '), lines = [], cur = '';
    words.forEach(function (w) {
      var t = cur ? cur + ' ' + w : w;
      if (cur && ctx.measureText(t).width > maxW) { lines.push(cur); cur = w; } else cur = t;
    });
    if (cur) lines.push(cur);
    return lines;
  }
  /* maxH-এর মধ্যে ধরানোর জন্য ফন্ট ছোট করে (max → min) */
  function fit(ctx, text, fontFn, maxW, maxH, lhMul, max, min) {
    for (var s = max; s >= min; s -= 2) {
      ctx.font = fontFn(s);
      var lines = wrapLines(ctx, text, maxW);
      if (lines.length * s * lhMul <= maxH) return { size: s, lines: lines, h: lines.length * s * lhMul };
    }
    ctx.font = fontFn(min);
    var ls = wrapLines(ctx, text, maxW), maxLines = Math.max(1, Math.floor(maxH / (min * lhMul)));
    var cut = false;
    if (ls.length > maxLines) { cut = true; ls = ls.slice(0, maxLines); ls[maxLines - 1] = ls[maxLines - 1].replace(/\s*\S*$/, '') + ' …'; }
    return { size: min, lines: ls, h: ls.length * min * lhMul, cut: cut };
  }
  function star8(ctx, cx, cy, r, fill) {
    ctx.save(); ctx.translate(cx, cy); ctx.fillStyle = fill;
    for (var k = 0; k < 2; k++) { ctx.rotate(k * Math.PI / 4); roundRect(ctx, -r, -r, r * 2, r * 2, r * 0.14); ctx.fill(); }
    ctx.restore();
  }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function pattern(ctx, th) {
    ctx.save(); ctx.strokeStyle = th.pat; ctx.lineWidth = 2;
    var step = 150;
    for (var y = -step; y < H + step; y += step) for (var x = -step; x < W + step; x += step) {
      var cx = x + ((Math.round(y / step) % 2) ? step / 2 : 0);
      ctx.save(); ctx.translate(cx, y); 
      for (var k = 0; k < 2; k++) { ctx.rotate(k * Math.PI / 4); ctx.strokeRect(-34, -34, 68, 68); }
      ctx.restore();
    }
    ctx.restore();
  }
  function divider(ctx, th, y) {
    ctx.save();
    var g = ctx.createLinearGradient(W / 2 - 360, 0, W / 2 + 360, 0);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(.5, th.gold); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(W / 2 - 360, y - 1.5, 720, 3);
    star8(ctx, W / 2, y, 15, th.gold);
    ctx.fillStyle = th.bg[0]; ctx.beginPath(); ctx.arc(W / 2, y, 4.5, 0, 7); ctx.fill();
    ctx.restore();
  }

  /* ---------- কার্ড আঁকা ---------- */
  function render(data, opt) {
    return loadFonts().then(function () {
      var th = THEMES.filter(function (t) { return t.id === opt.theme; })[0] || THEMES[0];
      var c = document.createElement('canvas'); c.width = W; c.height = H;
      var ctx = c.getContext('2d');
      /* পটভূমি */
      var g = ctx.createLinearGradient(0, 0, W * 0.4, H); g.addColorStop(0, th.bg[0]); g.addColorStop(1, th.bg[1]);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      pattern(ctx, th);
      var rg = ctx.createRadialGradient(W / 2, H * 0.34, 40, W / 2, H * 0.34, 760); rg.addColorStop(0, th.glow); rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
      /* ভেতরের ফ্রেম */
      ctx.strokeStyle = th.gold; ctx.globalAlpha = .55; ctx.lineWidth = 3; roundRect(ctx, 46, 46, W - 92, H - 92, 34); ctx.stroke();
      ctx.globalAlpha = .22; ctx.lineWidth = 2; roundRect(ctx, 62, 62, W - 124, H - 124, 26); ctx.stroke(); ctx.globalAlpha = 1;

      ctx.textBaseline = 'alphabetic';
      /* উপরের লেবেল */
      ctx.textAlign = 'center'; ctx.direction = 'ltr';
      star8(ctx, W / 2, 150, 26, th.gold);
      ctx.fillStyle = th.bg[0]; ctx.beginPath(); ctx.arc(W / 2, 150, 8, 0, 7); ctx.fill();
      ctx.fillStyle = th.gold; ctx.font = '700 40px PtCardBn, sans-serif';
      ctx.fillText(KIND[data.kind] || 'দোয়া', W / 2, 232);
      if (data.title) { ctx.fillStyle = th.mut; ctx.font = '400 34px PtCardBn, sans-serif'; var tl = fit(ctx, data.title, function (s) { return '400 ' + s + 'px PtCardBn, sans-serif'; }, 820, 50, 1.2, 34, 24); ctx.font = '400 ' + tl.size + 'px PtCardBn, sans-serif'; ctx.fillText(tl.lines[0], W / 2, 284); }

      /* মাঝের অংশ: আরবি + (উচ্চারণ) + অর্থ — জায়গা ভাগ করে ফন্ট নিজে ঠিক হয় */
      var top = 330, bottom = H - 230, avail = bottom - top;
      var showAr = opt.ar !== false, showTr = opt.tr && data.tr, showBn = opt.bn && data.bn, cut = {};
      var rest = (showTr ? 1 : 0) + (showBn ? 1 : 0);
      var hAr = !showAr ? 0 : (rest ? avail * (showBn && showTr ? 0.46 : 0.52) : avail * 0.82);
      var hTr = showTr ? avail * (showBn ? 0.17 : 0.28) : 0;
      var hBn = showBn ? (showAr ? avail - hAr - hTr - 60 : avail - hTr - 30) : 0;
      var y = top;
      /* আরবি */
      if (showAr) {
        ctx.direction = 'rtl'; ctx.textAlign = 'center';
        var ar = fit(ctx, data.ar, function (s) { return s + 'px PtCardAr, serif'; }, 860, hAr - 40, 1.95, rest ? 92 : 128, 30);
        cut.ar = ar.cut;
        ctx.font = ar.size + 'px PtCardAr, serif'; ctx.fillStyle = th.ink; ctx.strokeStyle = th.ink; ctx.lineWidth = Math.max(.7, ar.size / 60);
        var yy = y + (hAr - ar.h) / 2 + ar.size * 1.25;
        ar.lines.forEach(function (ln, i) { var ly = yy + i * ar.size * 1.95; ctx.fillText(ln, W / 2, ly); ctx.strokeText(ln, W / 2, ly); });
        y += hAr;
        ctx.direction = 'ltr'; ctx.lineWidth = 1;
        if (rest) { divider(ctx, th, y + 18); y += 60; }
      }
      ctx.direction = 'ltr'; ctx.textAlign = 'center';
      /* উচ্চারণ */
      if (showTr) {
        var tr = fit(ctx, data.tr, function (s) { return 'italic 400 ' + s + 'px PtCardBn, sans-serif'; }, 840, hTr, 1.5, 38, 22);
        cut.tr = tr.cut;
        ctx.font = 'italic 400 ' + tr.size + 'px PtCardBn, sans-serif'; ctx.fillStyle = th.gold;
        tr.lines.forEach(function (ln, i) { ctx.fillText(ln, W / 2, y + tr.size * 1.1 + i * tr.size * 1.5); });
        y += hTr;
      }
      /* অর্থ */
      if (showBn) {
        var bt = fit(ctx, data.bn, function (s) { return '400 ' + s + 'px PtCardBn, sans-serif'; }, 840, hBn, 1.55, 44, 24);
        cut.bn = bt.cut;
        ctx.font = '400 ' + bt.size + 'px PtCardBn, sans-serif'; ctx.fillStyle = th.ink;
        var by = y + (hBn - bt.h) / 2 + bt.size * 1.05;
        bt.lines.forEach(function (ln, i) { ctx.fillText(ln, W / 2, by + i * bt.size * 1.55); });
      }
      c._cut = !!(cut.ar || cut.tr || cut.bn);

      /* নিচের অংশ: সূত্র + ব্র্যান্ড */
      divider(ctx, th, H - 200);
      ctx.fillStyle = th.gold; ctx.font = '700 36px PtCardBn, sans-serif'; ctx.textAlign = 'center';
      if (data.ref) { var rf = fit(ctx, data.ref, function (s) { return '700 ' + s + 'px PtCardBn, sans-serif'; }, 860, 44, 1.2, 36, 24); ctx.font = '700 ' + rf.size + 'px PtCardBn, sans-serif'; ctx.fillText(rf.lines[0], W / 2, H - 140); }
      ctx.fillStyle = th.mut; ctx.font = '400 30px PtCardBn, sans-serif';
      ctx.fillText('পাথেয় বাই গুঞ্জরণ  ·  patheyobygunjoron.github.io', W / 2, H - 92);
      return c;
    });
  }

  /* ---------- UI ---------- */
  var css = ''
    + '.pcs-veil{position:fixed;inset:0;background:rgba(2,12,40,.55);opacity:0;pointer-events:none;transition:opacity .3s;z-index:1990}'
    + '.pcs-veil.on{opacity:1;pointer-events:auto}'
    + '.pcs-sheet{position:fixed;left:50%;bottom:0;width:min(100%,480px);max-height:92svh;overflow:auto;transform:translate(-50%,105%);transition:transform .4s cubic-bezier(.2,.9,.2,1);z-index:2000;'
    + 'background:#EEF3FA;color:#0C1B33;border-radius:26px 26px 0 0;padding:10px 18px calc(env(safe-area-inset-bottom,0px) + 22px + var(--pt-nav-fix,0px));border:1px solid rgba(0,32,94,.1);font-family:"GunjoronFont",Inter,sans-serif;overscroll-behavior:contain;box-sizing:border-box}'
    + '[data-theme="dark"] .pcs-sheet{background:#0E2040;color:#F5F8FD;border-color:rgba(255,255,255,.1)}'
    + '[data-theme="sepia"] .pcs-sheet{background:#F6EDD9;color:#3F331E;border-color:rgba(92,66,30,.2)}'
    + '.pcs-sheet.on{transform:translate(-50%,0)}'
    + '.pcs-grab{width:42px;height:5px;border-radius:9px;background:currentColor;opacity:.18;margin:4px auto 10px}'
    + '.pcs-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}'
    + '.pcs-t{font-size:19px;font-weight:700}'
    + '.pcs-x{width:36px;height:36px;border:0;border-radius:50%;background:rgba(127,140,170,.2);color:inherit;display:grid;place-items:center;cursor:pointer;padding:0}'
    + '.pcs-x svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round}'
    + '.pcs-prev{display:grid;place-items:center;background:rgba(127,140,170,.14);border-radius:18px;padding:10px;min-height:120px}'
    + '.pcs-prev canvas{display:block;width:auto;height:auto;max-width:100%;max-height:44svh;border-radius:12px;box-shadow:0 14px 30px -14px rgba(0,0,0,.55)}'
    + '.pcs-hint{font-size:12.5px;line-height:1.5;opacity:.75;margin:8px 2px 0}'
    + '.pcs-lb{font-size:13px;font-weight:700;opacity:.7;margin:14px 2px 7px}'
    + '.pcs-th{display:flex;gap:10px;overflow-x:auto;padding:2px 2px 6px;scrollbar-width:none}.pcs-th::-webkit-scrollbar{display:none}'
    + '.pcs-th button{flex:none;display:flex;flex-direction:column;align-items:center;gap:5px;background:none;border:0;padding:0;color:inherit;font-family:inherit;font-size:12px;cursor:pointer;opacity:.8}'
    + '.pcs-th i{display:block;width:46px;height:46px;border-radius:50%;border:2.5px solid transparent;box-shadow:0 0 0 1px rgba(127,140,170,.45) inset}'
    + '.pcs-th button.on{opacity:1;font-weight:700}.pcs-th button.on i{border-color:#0E7BB8;box-shadow:0 0 0 3px rgba(14,123,184,.25)}'
    + '.pcs-tg{display:flex;gap:8px;flex-wrap:wrap}'
    + '.pcs-tg button{font-family:inherit;font-size:14px;font-weight:600;color:inherit;background:rgba(127,140,170,.18);border:1.5px solid transparent;border-radius:999px;padding:9px 15px;cursor:pointer}'
    + '.pcs-tg button.on{background:#0E7BB8;color:#fff}'
    + '.pcs-ac{display:grid;grid-template-columns:1.6fr 1fr;gap:10px;margin-top:16px}'
    + '.pcs-ac button{font-family:inherit;font-size:16px;font-weight:700;border-radius:999px;padding:14px 10px;cursor:pointer;border:0;display:flex;align-items:center;justify-content:center;gap:8px}'
    + '.pcs-ac svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}'
    + '.pcs-go{background:#0E7BB8;color:#fff}.pcs-sv{background:rgba(127,140,170,.22);color:inherit}'
    + '.pcs-ac button[disabled]{opacity:.55}'
    + '.pcs-cp{display:block;margin:12px auto 0;font-family:inherit;font-size:14px;font-weight:600;background:none;border:0;color:inherit;opacity:.75;cursor:pointer;text-decoration:underline;text-underline-offset:3px}'
    + '.pcs-msg{position:fixed;left:50%;bottom:calc(30px + env(safe-area-inset-bottom,0px) + var(--pt-nav-fix,0px));transform:translate(-50%,20px);opacity:0;pointer-events:none;z-index:2100;background:#0A1C46;color:#fff;font-family:"GunjoronFont",Inter,sans-serif;font-size:14px;font-weight:600;padding:11px 18px;border-radius:14px;transition:opacity .22s,transform .22s;max-width:calc(100% - 40px);text-align:center}'
    + '.pcs-msg.show{opacity:1;transform:translate(-50%,0)}'
    + 'html.pcs-lock,html.pcs-lock body{overflow:hidden}'
    + '@media (prefers-reduced-motion:reduce){.pcs-sheet,.pcs-veil,.pcs-msg{transition:none}}';

  var UI = null, cur = null, st = { theme: 'night', ar: true, tr: false, bn: true }, opened = false, renderTick = 0, lastCanvas = null;
  try { var sv = JSON.parse(localStorage.getItem('pt_share_card') || 'null'); if (sv) { if (THEMES.some(function (t) { return t.id === sv.theme; })) st.theme = sv.theme; if (typeof sv.ar === 'boolean') st.ar = sv.ar; if (typeof sv.tr === 'boolean') st.tr = sv.tr; if (typeof sv.bn === 'boolean') st.bn = sv.bn; } } catch (e) {}
  function persist() { try { localStorage.setItem('pt_share_card', JSON.stringify(st)); } catch (e) {} }

  function bridge() { return window.PatheyoShare || (window.parent && window.parent !== window && window.parent.PatheyoShare) || null; }

  var msgT = 0;
  function msg(t) { var m = UI.msg; m.textContent = t; m.classList.add('show'); clearTimeout(msgT); msgT = setTimeout(function () { m.classList.remove('show'); }, 2200); }

  function build() {
    var style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);
    var veil = document.createElement('div'); veil.className = 'pcs-veil';
    var sheet = document.createElement('div'); sheet.className = 'pcs-sheet'; sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'শেয়ার কার্ড');
    var m = document.createElement('div'); m.className = 'pcs-msg'; m.setAttribute('role', 'status');
    sheet.innerHTML =
      '<div class="pcs-grab"></div>' +
      '<div class="pcs-hd"><div class="pcs-t">শেয়ার কার্ড</div><button type="button" class="pcs-x" aria-label="বন্ধ করুন"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>' +
      '<div class="pcs-prev"></div>' +
      '<div class="pcs-hint" style="display:none">লেখা বড় হওয়ায় কার্ডে সংক্ষেপে দেখানো হয়েছে। পুরো লেখা লাগলে নিচের “শুধু লেখা কপি করুন” চাপুন, অথবা আরবি/অর্থের একটা বন্ধ করে দিন।</div>' +
      '<div class="pcs-lb">রঙের থিম</div><div class="pcs-th"></div>' +
      '<div class="pcs-lb">কার্ডে যা থাকবে</div><div class="pcs-tg"></div>' +
      '<div class="pcs-ac"><button type="button" class="pcs-go"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6.5" cy="12" r="2.3"/><circle cx="17.5" cy="6.5" r="2.3"/><circle cx="17.5" cy="17.5" r="2.3"/><path d="M8.5 10.9l7-3.3M8.5 13.1l7 3.3"/></svg><span>শেয়ার করুন</span></button>' +
      '<button type="button" class="pcs-sv"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19h14"/></svg><span>সেভ</span></button></div>' +
      '<button type="button" class="pcs-cp">শুধু লেখা কপি করুন</button>';
    document.body.appendChild(veil); document.body.appendChild(sheet); document.body.appendChild(m);
    UI = { veil: veil, sheet: sheet, msg: m, prev: sheet.querySelector('.pcs-prev'), hint: sheet.querySelector('.pcs-hint'), th: sheet.querySelector('.pcs-th'), tg: sheet.querySelector('.pcs-tg'),
           go: sheet.querySelector('.pcs-go'), sv: sheet.querySelector('.pcs-sv'), cp: sheet.querySelector('.pcs-cp') };
    UI.th.innerHTML = THEMES.map(function (t) {
      return '<button type="button" data-th="' + t.id + '"><i style="background:linear-gradient(135deg,' + t.bg[0] + ',' + t.bg[1] + ')"></i><span>' + t.n + '</span></button>';
    }).join('');
    veil.addEventListener('click', requestClose);
    sheet.querySelector('.pcs-x').addEventListener('click', requestClose);
    UI.th.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-th]') : null; if (!b) return; st.theme = b.getAttribute('data-th'); persist(); sync(); redraw(); });
    UI.tg.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-tg]') : null; if (!b) return; var k = b.getAttribute('data-tg'); var nx = !st[k]; var left = [k === 'ar' ? nx : st.ar, k === 'tr' ? nx : (st.tr && cur.tr), k === 'bn' ? nx : (st.bn && cur.bn)].some(Boolean); if (!left) { msg('অন্তত একটা লেখা রাখতে হবে'); return; } st[k] = nx; persist(); sync(); redraw(); });
    UI.go.addEventListener('click', doShare);
    UI.sv.addEventListener('click', doSave);
    UI.cp.addEventListener('click', doCopy);
    window.addEventListener('popstate', function () { if (opened) hide(); });
  }

  function sync() {
    Array.prototype.forEach.call(UI.th.children, function (b) { b.classList.toggle('on', b.getAttribute('data-th') === st.theme); });
    var h = '';
    if (cur.tr || cur.bn) h += '<button type="button" data-tg="ar" class="' + (st.ar ? 'on' : '') + '">আরবি</button>';
    if (cur.tr) h += '<button type="button" data-tg="tr" class="' + (st.tr ? 'on' : '') + '">উচ্চারণ</button>';
    if (cur.bn) h += '<button type="button" data-tg="bn" class="' + (st.bn ? 'on' : '') + '">অর্থ</button>';
    UI.tg.innerHTML = h || '<span style="opacity:.7;font-size:13px">এই কার্ডে শুধু আরবি থাকবে</span>';
    UI.tg.previousElementSibling.style.display = UI.tg.style.display = (cur.tr || cur.bn) ? '' : 'none';
    var b = bridge();
    UI.sv.style.display = (b && typeof b.canSave === 'function' && !b.canSave()) ? 'none' : '';
    UI.ac = null;
  }

  function redraw() {
    var my = ++renderTick;
    render(cur, { theme: st.theme, ar: st.ar, tr: st.tr, bn: st.bn }).then(function (c) {
      if (my !== renderTick) return;
      lastCanvas = c; UI.prev.innerHTML = ''; UI.prev.appendChild(c);
      UI.hint.style.display = c._cut ? '' : 'none';
    });
  }

  function pngB64() { return lastCanvas ? lastCanvas.toDataURL('image/png') : null; }
  function textOf() {
    var s = (cur.title ? cur.title + '\n\n' : '') + cur.ar;
    if (!st.ar) s = (cur.title ? cur.title + '\n\n' : '') + (st.bn && cur.bn ? '' : cur.ar);
    if (st.tr && cur.tr) s += '\n\nউচ্চারণ: ' + cur.tr;
    if (st.bn && cur.bn) s += '\n\nঅর্থ: ' + cur.bn;
    if (cur.ref) s += '\n\n(' + cur.ref + ')';
    return s + '\n\n— পাথেয় বাই গুঞ্জরণ\npatheyobygunjoron.github.io';
  }
  function fname() { return 'patheyo_' + (cur.kind || 'card') + '_' + Date.now(); }
  function dataUrlToBlob(u) { var p = u.split(','), mime = /:(.*?);/.exec(p[0])[1], bin = atob(p[1]), n = bin.length, a = new Uint8Array(n); while (n--) a[n] = bin.charCodeAt(n); return new Blob([a], { type: mime }); }

  function doShare() {
    var u = pngB64(); if (!u) return;
    var b = bridge(), caption = (cur.ref ? cur.ref + ' — ' : '') + 'পাথেয় বাই গুঞ্জরণ';
    if (b && typeof b.shareImage === 'function') { var ok = false; try { ok = b.shareImage(u, caption); } catch (e) {} if (!ok) msg('শেয়ার করা যায়নি'); return; }
    /* ব্রাউজার/অন্য পরিবেশ: Web Share (ফাইলসহ) → না হলে ডাউনলোড */
    try {
      var f = new File([dataUrlToBlob(u)], fname() + '.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) { navigator.share({ files: [f], text: caption }).catch(function () {}); return; }
    } catch (e) {}
    download(u);
  }
  function download(u) { var a = document.createElement('a'); a.href = u; a.download = fname() + '.png'; document.body.appendChild(a); a.click(); a.remove(); msg('ছবি ডাউনলোড হচ্ছে'); }
  function doSave() {
    var u = pngB64(); if (!u) return;
    var b = bridge();
    if (b && typeof b.saveImage === 'function') { var ok = false; try { ok = b.saveImage(u, fname()); } catch (e) {} msg(ok ? 'গ্যালারিতে সেভ হয়েছে (Pictures/Patheyo)' : 'সেভ করা যায়নি'); return; }
    download(u);
  }
  function doCopy() {
    var s = textOf(), b = bridge();
    function fb() { try { var ta = document.createElement('textarea'); ta.value = s; ta.style.cssText = 'position:fixed;left:-9999px;opacity:0'; document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); ta.remove(); msg(ok ? 'লেখা কপি হয়েছে' : 'কপি করা যায়নি'); } catch (e) { msg('কপি করা যায়নি'); } }
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(s).then(function () { msg('লেখা কপি হয়েছে'); }, fb); return; } } catch (e) {}
    fb();
  }

  function open(data) {
    if (!data || !data.ar) return;
    if (!UI) build();
    cur = { kind: data.kind || 'dua', title: data.title || '', ar: data.ar, tr: data.tr || '', bn: data.bn || '', ref: data.ref || '' };
    if (!cur.bn) st.bn = false; else if (!cur.tr) st.tr = false;
    sync(); UI.prev.innerHTML = '<span style="opacity:.6;font-size:13px">কার্ড তৈরি হচ্ছে…</span>';
    if (!opened) {
      opened = true;
      try { history.pushState({ pcs: 1 }, ''); } catch (e) {}
      UI.veil.classList.add('on'); UI.sheet.classList.add('on'); UI.sheet.scrollTop = 0;
      document.documentElement.classList.add('pcs-lock');
    }
    redraw();
  }
  function hide() { if (!opened) return; opened = false; UI.veil.classList.remove('on'); UI.sheet.classList.remove('on'); document.documentElement.classList.remove('pcs-lock'); }
  function requestClose() { if (!opened) return; if (history.state && history.state.pcs) history.back(); else hide(); }

  /* ---------- হাদিস/কুরআনের কার্ডে বসানোর ছোট "শেয়ার কার্ড" বোতাম (ফিচারের নিজের রঙের টোকেন নেয়) ---------- */
  var SHARE_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="4.5" width="17" height="15" rx="3.2"/><path d="M3.5 15.5l4.6-4.4 3.6 3.4 3-2.8 5.8 5.2M16.6 9.2h.01"/></svg>';
  var BTN_CSS = '.pt-sc-btn{width:38px;height:38px;border-radius:50%;border:0;display:grid;place-items:center;cursor:pointer;background:var(--accent-soft,rgba(14,123,184,.12));color:var(--accent,#0E7BB8);flex:none;padding:0;transition:transform .15s,background-color .25s}'
    + '.pt-sc-btn:active{transform:scale(.9)}'
    + '.pt-sc-btn svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;display:block}'
    + '.hd-acts{display:flex;align-items:center;gap:8px}'
    + '.tr-ayah{position:relative}.tr-ayah>.pt-sc-btn{position:absolute;top:14px;right:0;z-index:1}'
    + '.bm-share{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin:2px 0 14px;padding:11px 12px;border-radius:12px;border:1.5px dashed var(--accent,#0E7BB8);background:var(--accent-soft,rgba(14,123,184,.1));color:var(--accent,#0E7BB8);font-family:inherit;font-size:15px;font-weight:600;cursor:pointer}'
    + '.bm-share.hidden{display:none}.bm-share svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}';
  (function () { var st = document.createElement('style'); st.setAttribute('data-pt-sc', '1'); st.textContent = BTN_CSS; (document.head || document.documentElement).appendChild(st); })();
  function btnHtml() { return '<button type="button" class="pt-sc-btn" data-pt-share aria-label="শেয়ার কার্ড বানান" title="শেয়ার কার্ড">' + SHARE_ICON + '</button>'; }

  window.PtShareCard = { open: open, close: requestClose, themes: THEMES, btnHtml: btnHtml, _render: render };
})();
