package com.gunjoron.patheyo.ui

import android.content.Context
import android.graphics.Typeface

/**
 * v37: পপআপে ব্যবহৃত সব ফন্ট এক জায়গায়। ফাইলগুলো থাকে app/src/main/assets/fonts/ ফোল্ডারে।
 * ফন্ট বদলাতে চাইলে শুধু ঐ ফোল্ডারের ফাইল বদলান (বা নিচের নাম বদলান) — আর কোথাও হাত দিতে হবে না।
 *
 *  APP_NAME   → অ্যাপের নাম (Helvetica, রেগুলার)
 *  BN_*       → বাংলা লেখা (Kothamala)
 *  EN_*       → বাকি ইংরেজি/সংখ্যা (Poppins)
 *  CLOCK_*    → শুধু আজান পপআপের ঘড়ি (Outfit)
 */
object AppFonts {
    const val APP_NAME = "Helvetica.ttf"
    const val BN_REGULAR = "Kothamala-Regular.ttf"
    const val BN_BOLD = "Kothamala-Bold.ttf"
    const val EN_REGULAR = "Poppins-Regular.ttf"
    const val EN_BOLD = "Poppins-Bold.ttf"
    const val EN_LIGHT = "Poppins-Light.ttf"
    // v46: আজান পপআপের ঘড়ির প্রিমিয়াম ফন্ট (Outfit, OFL লাইসেন্স) — শুধু ঘড়ির জন্য
    const val CLOCK_LIGHT = "Outfit-Light.ttf"
    const val CLOCK_MEDIUM = "Outfit-Medium.ttf"

    private const val DIR = "fonts/"
    private val cache = HashMap<String, Typeface>()

    /** assets/fonts/[file] থেকে ফন্ট লোড (একবারই); ফাইল না পেলে [fallback] */
    fun load(ctx: Context, file: String, fallback: Typeface = Typeface.DEFAULT): Typeface =
        cache.getOrPut(file) {
            try { Typeface.createFromAsset(ctx.assets, DIR + file) } catch (_: Throwable) { fallback }
        }

    fun bengali(ctx: Context, bold: Boolean) =
        if (bold) load(ctx, BN_BOLD, Typeface.DEFAULT_BOLD) else load(ctx, BN_REGULAR)

    fun english(ctx: Context, bold: Boolean) =
        if (bold) load(ctx, EN_BOLD, Typeface.DEFAULT_BOLD) else load(ctx, EN_REGULAR)
}
