package com.gunjoron.patheyo.alarm

// app/src/main/java/com/gunjoron/Patheyo/alarm/AzanOverlayActivity.kt
//
// ✅ v45: ফুল-স্ক্রীন আজান পপআপ (লক-স্ক্রীনের উপরে) — পারমিশন পপআপের (ui/GlassStyle) হুবহু একই গ্লাস ডিজাইন, পুরো স্ক্রীন জুড়ে।
//  • আইকনের জায়গায় অ্যাপের লোগো, তারপর অ্যাপের নাম (+ছোট ট্যাগ), কোন ওয়াক্তের আজান, ঘড়ি
//  • দুই বাটন: লাল "আজান বন্ধ করুন" (আজান থামে, এই ওয়াক্তে আর বাজে না) ও ধূসর "স্নুজ" (থামে, ১০ মিনিট পর আবার বাজে)
//  • ইউজার বাটন না চাপা পর্যন্ত (ব্যাক চাপলেও) থাকে; আজান শেষ হয়ে গেলে নিজে থেকেই বন্ধ হয়
//  ✅ v48: (১) লোগো কোডে আঁকা গোল Bitmap (AzanLogo) — কোণা নেই; (২) বাটন চাপলে সাউন্ড সাথে সাথে বন্ধ (সার্ভিসকে সরাসরি ডাকা);
//          (৩) ভলিউম বাটন চাপলে শুধু সাউন্ড বন্ধ — পপআপ থাকে; (৪) বাটন দুটো নতুন রঙে (রোজ-ক্রিমসন / অ্যাম্বার-গোল্ড)।
//  • ৩য় (শেষ) আজানে স্নুজ বাটন থাকে না, কারণ এরপর আর রিপিট নেই

import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.ui.AppFonts
import com.gunjoron.patheyo.ui.DialogText
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AzanOverlayActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    // সার্ভিস চালু হতে সামান্য সময় লাগে — এই সময়ের আগে "আজান শেষ" ধরে পপআপ বন্ধ করা হয় না
    private var graceUntil = 0L

    private var waqtName: String = "নামাজ"
    private var ring: Int = 1

    private val tickRunnable = object : Runnable {
        override fun run() {
            updateTime()
            // আজান শেষ (বা অন্য কোনোভাবে বন্ধ) হয়ে গেলে পপআপও সরে যায়
            if (SystemClock.elapsedRealtime() > graceUntil && !AzanForegroundService.isRunning) {
                finish()
                return
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ১. ফোন লক থাকলেও যেন আজানের স্ক্রিনটি লক স্ক্রিনের উপরে ভেসে ওঠে
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                        or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        // স্ক্রিন ব্রাইটনেস ম্যাক্সিমাম করা
        val layoutParams = window.attributes
        layoutParams.screenBrightness = 1.0f
        window.attributes = layoutParams

        applyGlassWindow()
        setContentView(R.layout.activity_azan_overlay)

        // ব্যাক বাটনে পপআপ বন্ধ হবে না — শুধু দুই বাটনের একটা চাপলে (বা আজান শেষ হলে) বন্ধ হবে
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* ইচ্ছাকৃতভাবে কিছু করা হয় না */ }
        })

        // আজান বন্ধ করুন — সাউন্ড তৎক্ষণাৎ বন্ধ (চলমান সার্ভিসকে সরাসরি ডেকে; ইন্টেন্টের অপেক্ষা নেই)
        findViewById<View>(R.id.btnStop).setOnClickListener {
            if (!AzanForegroundService.requestStop(applicationContext)) {
                // সার্ভিস তখনও চালু হয়নি/ইনস্ট্যান্স নেই — ইন্টেন্টেও জানিয়ে রাখা (ব্যর্থ হলেও ক্ষতি নেই)
                try {
                    startService(Intent(this, AzanForegroundService::class.java).apply {
                        action = AzanForegroundService.ACTION_STOP
                    })
                } catch (_: Throwable) { }
            }
            finish()
        }

        // স্নুজ — সাউন্ড তৎক্ষণাৎ বন্ধ, ১০ মিনিট পর আবার আজান
        findViewById<View>(R.id.btnSnooze).setOnClickListener {
            if (!AzanForegroundService.requestSnooze(applicationContext, waqtName, ring)) {
                try {
                    startService(Intent(this, AzanForegroundService::class.java).apply {
                        action = AzanForegroundService.ACTION_SNOOZE
                        putExtra("waqt", waqtName)
                        putExtra(AzanRepeat.EXTRA_RING, ring)
                    })
                } catch (_: Throwable) { }
            }
            finish()
        }

        bind(intent)
        graceUntil = SystemClock.elapsedRealtime() + 6_000L
        handler.post(tickRunnable)
    }

    // singleInstance: আজান চলাকালীন আবার খুলতে চাইলে (যেমন নোটিফিকেশনে ট্যাপ) এখানেই নতুন ইন্টেন্ট আসে
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        bind(intent)
        graceUntil = SystemClock.elapsedRealtime() + 6_000L
    }

    /** ইন্টেন্ট থেকে ওয়াক্ত ও আজান-নম্বর নিয়ে স্ক্রীনের লেখা সাজানো */
    private fun bind(src: Intent?) {
        waqtName = src?.getStringExtra("waqtName") ?: "নামাজ"
        ring = (src?.getIntExtra(AzanRepeat.EXTRA_RING, 1) ?: 1).coerceIn(1, AzanContent.MAX_RINGS)
        val isLast = ring >= AzanContent.MAX_RINGS

        findViewById<TextView>(R.id.tvAppName).text = DialogText.nameWithTag(
            this, appLabel(), getString(R.string.azan_popup_tag), latinTag = false
        )
        findViewById<TextView>(R.id.tvTitle).text = AzanContent.title(waqtName)
        // নামাজের প্রতি আহ্বান — ওয়াক্ত অনুযায়ী হাদিস/আয়াত
        val (quote, source) = AzanContent.call(waqtName)
        findViewById<TextView>(R.id.tvQuote).text = quote
        findViewById<TextView>(R.id.tvQuoteSource).text = source
        findViewById<TextView>(R.id.tvHint).setText(
            if (isLast) R.string.azan_popup_last_hint else R.string.azan_popup_snooze_hint
        )
        findViewById<View>(R.id.btnSnooze).visibility = if (isLast) View.GONE else View.VISIBLE

        // ফন্ট: পারমিশন পপআপের মতোই (বাংলা Kothamala, ইংরেজি/সংখ্যা Poppins, নাম Helvetica)
        DialogText.applyFonts(this, findViewById(R.id.azanRoot))
        // ঘড়ির জন্য আলাদা প্রিমিয়াম ফন্ট (Outfit) — সরাসরি বসানো, তাই লেখা বদলালেও ঠিক থাকে
        findViewById<TextView>(R.id.tvClock).typeface = AppFonts.load(this, AppFonts.CLOCK_LIGHT, Typeface.DEFAULT)
        findViewById<TextView>(R.id.tvAmPm).typeface = AppFonts.load(this, AppFonts.CLOCK_MEDIUM, Typeface.DEFAULT_BOLD)
        lastClockText = ""
        updateTime()
        bindLogo()
    }

    // v48: লোগো গোল ভিত্তির ভেতরে — কোডে আঁকা গোল Bitmap (ব্যর্থ হলে লেআউটের আগের ইমেজই থাকে)
    private fun bindLogo() {
        try {
            val px = (98 * resources.displayMetrics.density).toInt()
            AzanLogo.circle(this, px)?.let { findViewById<ImageView>(R.id.ivLogo)?.setImageBitmap(it) }
        } catch (_: Throwable) { }
    }

    // v48: ভলিউম বাটন চাপলে শুধু আজানের সাউন্ড বন্ধ হয় — পপআপ থাকে, ইউজার দুই বাটনের একটা চাপলে তবেই যায়
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isVolumeKey(keyCode)) {
            AzanForegroundService.silenceNow()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (isVolumeKey(keyCode)) return true
        return super.onKeyUp(keyCode, event)
    }

    private fun isVolumeKey(code: Int) =
        code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN || code == KeyEvent.KEYCODE_VOLUME_MUTE

    // পারমিশন পপআপের মতো গ্লাস: Android 12+ এ আসল window-blur, না থাকলে প্রায়-অস্বচ্ছ গ্লাস (ui/GlassStyle.prepare এর মতোই)
    private fun applyGlassWindow() {
        var blur = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blur = try { windowManager.isCrossWindowBlurEnabled } catch (_: Throwable) { false }
        }
        window.setBackgroundDrawableResource(
            if (blur) R.drawable.bg_azan_fullscreen_glass else R.drawable.bg_azan_fullscreen_solid
        )
        if (blur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                window.attributes = window.attributes.apply { blurBehindRadius = 20 }
                window.setBackgroundBlurRadius(50)
            } catch (_: Throwable) { /* ব্লার ব্যর্থ হলে গ্লাস গ্রেডিয়েন্টই থাকবে */ }
        }
    }

    private fun appLabel(): String = try {
        applicationInfo.loadLabel(packageManager).toString()
    } catch (_: Throwable) { getString(R.string.app_name) }

    // ১২ ঘণ্টা ফরম্যাট, সেকেন্ড ছাড়া — লেখা শুধু মিনিট বদলালেই বদলায় (স্ক্রীনে সেকেন্ডের নড়াচড়া নেই)
    private var lastClockText = ""

    private fun updateTime() {
        val now = Calendar.getInstance().time
        val hm = SimpleDateFormat("h:mm", Locale.US).format(now)      // যেমন 7:38
        val ap = SimpleDateFormat("a", Locale.US).format(now).uppercase(Locale.US) // AM / PM
        val text = "$hm $ap"
        if (text == lastClockText) return
        lastClockText = text
        findViewById<TextView>(R.id.tvClock)?.text = hm
        findViewById<TextView>(R.id.tvAmPm)?.text = ap
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
