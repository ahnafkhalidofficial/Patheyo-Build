package com.gunjoron.patheyo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.style.LeadingMarginSpan
import android.text.style.MetricAffectingSpan
import android.text.style.ReplacementSpan
import android.view.ViewGroup
import android.widget.TextView
import com.gunjoron.patheyo.R

/**
 * v36: পপআপের সব লেখা-সংক্রান্ত কাজ এক জায়গায়।
 *  • বাংলা লেখা  → Kothamala (অ্যাপের নিজস্ব ফন্ট)
 *  • ইংরেজি/সংখ্যা → Poppins (পরিষ্কার, আধুনিক, সহজে পড়া যায়)
 *  • নামের পাশে ছোট লাইট-ফন্ট ট্যাগ, এবং সুন্দর বুলেট-লিস্ট
 */
object DialogText {

    // ───────────── ফন্ট (ফাইল/নাম: AppFonts.kt) ─────────────
    /** ভিউ-ট্রির সব TextView-তে বাংলা ফন্ট বসায় এবং ভেতরের ইংরেজি অংশে Poppins লাগায়। */
    fun applyFonts(ctx: Context, root: android.view.View) {
        if (root is TextView) {
            val bold = root.typeface?.isBold == true
            root.typeface = AppFonts.bengali(ctx, bold)
            root.text = withLatinFont(root.text, AppFonts.english(ctx, bold))
        } else if (root is ViewGroup) {
            for (i in 0 until root.childCount) applyFonts(ctx, root.getChildAt(i))
        }
    }

    private fun isLatin(c: Char) = c.code in 0x21..0x24F

    /** [from,to) এর মধ্যে ইংরেজি অংশগুলোতে [tf] বসায়; আগে থেকে নিজস্ব ফন্ট পাওয়া অংশ বাদ যায়। */
    private fun applyLatinRuns(sb: SpannableStringBuilder, from: Int, to: Int, tf: Typeface) {
        val skip = sb.getSpans(0, sb.length, Any::class.java)
            .filter { it is ReplacementSpan || it is TypefaceRunSpan }
            .map { sb.getSpanStart(it) to sb.getSpanEnd(it) }
        fun skipped(i: Int) = skip.any { i >= it.first && i < it.second }
        var i = from
        while (i < to) {
            if (isLatin(sb[i]) && !skipped(i)) {
                var j = i + 1
                while (j < to && !skipped(j)) {
                    val c = sb[j]
                    val spaceBetween = c == ' ' && j + 1 < to && isLatin(sb[j + 1]) && !skipped(j + 1)
                    if (isLatin(c) || spaceBetween) j++ else break
                }
                sb.setSpan(TypefaceRunSpan(tf), i, j, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                i = j
            } else i++
        }
    }

    private fun withLatinFont(src: CharSequence, tf: Typeface): CharSequence {
        val sb = SpannableStringBuilder(src)
        applyLatinRuns(sb, 0, sb.length, tf)
        return sb
    }

    private class TypefaceRunSpan(private val tf: Typeface) : MetricAffectingSpan() {
        override fun updateDrawState(p: TextPaint) { p.typeface = tf }
        override fun updateMeasureState(p: TextPaint) { p.typeface = tf }
    }

    // ───────────── নাম + ছোট "ট্যাগ" ─────────────
    /** [below]=true হলে ট্যাগ নামের নিচের লাইনে মাঝ বরাবর (আপডেট: ভার্সন); false হলে নামের ঠিক পাশে (লোকেশন: "অনুমতি দরকার")। */
    fun nameWithTag(ctx: Context, name: String, tag: String, latinTag: Boolean, below: Boolean = false): CharSequence {
        val d = ctx.resources.displayMetrics.density
        val sb = SpannableStringBuilder(name)
        applyLatinRuns(sb, 0, sb.length, AppFonts.load(ctx, AppFonts.APP_NAME))   // নাম: Helvetica রেগুলার
        sb.append(if (below) '\n' else ' ')
        val start = sb.length
        sb.append(tag)
        sb.setSpan(
            PillSpan(
                bg = ctx.getColor(R.color.update_tag_bg), fg = ctx.getColor(R.color.update_tag_text),
                textSizePx = 11f * d, tf = if (latinTag) AppFonts.load(ctx, AppFonts.EN_LIGHT) else AppFonts.bengali(ctx, false),
                padH = 9f * d, padV = 3f * d, margin = if (below) 0f else 7f * d
            ),
            start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        return sb
    }

    private class PillSpan(
        private val bg: Int, private val fg: Int, private val textSizePx: Float, private val tf: Typeface,
        private val padH: Float, private val padV: Float, private val margin: Float
    ) : ReplacementSpan() {
        private fun pen(base: Paint) = Paint(base).apply { textSize = textSizePx; typeface = tf; color = fg; isFakeBoldText = false }

        override fun getSize(paint: Paint, text: CharSequence, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int =
            (pen(paint).measureText(text, start, end) + padH * 2 + margin).toInt()

        override fun draw(c: Canvas, text: CharSequence, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
            val p = pen(paint)
            val fm = p.fontMetrics
            val w = p.measureText(text, start, end)
            val h = (fm.descent - fm.ascent) + padV * 2
            val cy = y + (paint.ascent() + paint.descent()) / 2f + (paint.descent() - paint.ascent()) * 0.08f
            val r = RectF(x + margin, cy - h / 2, x + margin + w + padH * 2, cy + h / 2)
            c.drawRoundRect(r, h / 2, h / 2, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg })
            c.drawText(text, start, end, r.left + padH, cy - (fm.ascent + fm.descent) / 2f, p)
        }
    }

    // ───────────── ফিচার-লিস্ট (বক্স ছাড়া, হ্যাং-ইন্ডেন্ট সহ) ─────────────
    /**
     * প্রতিটি লাইন একটি পয়েন্ট। শুরুর "•" গুনে লেভেল ঠিক করা হয়:
     *  – ইমোজি দিয়ে শুরু হলে শিরোনাম (মার্কার ছাড়া)
     *  – সাধারণ লাইনে "•" মার্কার; ভেতরের (দ্বিতীয় লেভেলের) লাইনে "–" মার্কার ও বাড়তি ইন্ডেন্ট
     *  এতে "• •" ডাবল-বুলেটের সমস্যা হয় না এবং লম্বা লাইন ভাঙলেও লেখা সুন্দরভাবে সাজানো থাকে।
     */
    fun formatList(ctx: Context, raw: String, markerColor: Int): CharSequence {
        val d = ctx.resources.displayMetrics.density
        val bullets = "•·●○◦▪-–—*"
        val lines = raw.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        val out = SpannableStringBuilder()
        lines.forEachIndexed { idx, original ->
            var line = original
            var level = 0
            while (line.isNotEmpty() && bullets.indexOf(line[0]) >= 0) { level++; line = line.substring(1).trim() }
            if (line.isEmpty()) return@forEachIndexed

            val start = out.length
            out.append(line)
            if (idx != lines.lastIndex) out.append('\n')

            val isHeading = level <= 1 && !line[0].isLetterOrDigit()
            val span = when {
                isHeading -> null
                level >= 2 -> HangSpan("–", 14f * d, (30f * d).toInt(), markerColor)
                else -> HangSpan("•", 0f, (16f * d).toInt(), markerColor)
            }
            if (span != null) out.setSpan(span, start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return out
    }

    private class HangSpan(
        private val marker: String, private val markerX: Float, private val indent: Int, private val color: Int
    ) : LeadingMarginSpan {
        override fun getLeadingMargin(first: Boolean) = indent
        override fun drawLeadingMargin(
            c: Canvas, p: Paint, x: Int, dir: Int, top: Int, baseline: Int, bottom: Int,
            text: CharSequence, start: Int, end: Int, first: Boolean, layout: Layout?
        ) {
            if (!first) return
            val old = p.color
            p.color = color
            c.drawText(marker, x + dir * markerX, baseline.toFloat(), p)
            p.color = old
        }
    }
}
