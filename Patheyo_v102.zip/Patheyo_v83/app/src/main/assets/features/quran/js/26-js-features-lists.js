
/*!
 * js/features/lists.js -- Sura list and Para list rendering
 *
 * Provides : App.renderParaList, App.renderSuraList, App.renderTarjamaList
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/para-meta, data/surah-meta,
               features/para-choice, features/sura-reader, features/tarjama-reader
 */
(function (App) {
  "use strict";

  // একই সূরা-সারি (হুবহু একই ডিজাইন) তিলাওয়াত করুন ও তরজমা পড়ুন -- দুই জায়গাতেই ব্যবহার হয়
  function renderSuraRows(container, onOpen){
    var frag = document.createDocumentFragment();
    App.quranModel.forEach(function(sura){
      var en = App.SURAH_EN[sura.index-1] || '';
      var bnName = App.SURAH_BN[sura.index-1] || '';
      var row = document.createElement('div');
      row.className = 'list-item';
      row.setAttribute('data-name', sura.name + ' ' + en + ' ' + bnName);
      row.setAttribute('data-index', sura.index);
      row.innerHTML =
        '<div class="li-badge">' + App.bn(sura.index) + '</div>' +
        '<div class="li-name-block">' +
          '<div class="li-name-en">' + en + '</div>' +
          '<div class="li-sub">' + App.bn(sura.ayahs.length) + ' আয়াত</div>' +
        '</div>' +
        '<div class="li-arabic">' + App.surahGlyph(sura.index, 'sg-list') + '</div>' +
        '<div class="li-name-bn">' + bnName + '</div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(idx){
        return function(){ onOpen(idx); };
      }(sura.index));
      frag.appendChild(row);
    });
    container.appendChild(frag);
  }

  function renderSuraList(){ renderSuraRows(App.els.suraList, function(idx){ App.openReader(idx); }); }
  App.renderSuraList = renderSuraList;

  function renderTarjamaList(){ renderSuraRows(App.els.trList, function(idx){ App.openTarjamaReader(idx); }); }
  App.renderTarjamaList = renderTarjamaList;

  function renderParaList(){
    var frag = document.createDocumentFragment();
    for (var p=1; p<=30; p++){
      var start = App.JUZ_START[p-1];
      var startSura = App.quranModel[start[0]-1];
      var row = document.createElement('div');
      row.className = 'list-item';
      row.setAttribute('data-name', startSura.name);
      row.setAttribute('data-index', p);
      row.innerHTML =
        '<div class="li-badge">' + App.bn(p) + '</div>' +
        '<div class="li-name-block">' +
          '<div class="li-name-en">পারা ' + App.bn(p) + '</div>' +
          '<div class="li-sub">শুরু: সূরা ' + App.bn(start[0]) + ', আয়াত ' + App.bn(start[1]) + '</div>' +
        '</div>' +
        '<div class="li-arabic">' + App.surahGlyph(startSura.index, 'sg-list') + '</div>' +
        '<div class="li-name-bn">' + (App.SURAH_BN[startSura.index-1]||'') + '</div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(idx){
        return function(){ App.openParaChoice(idx); };
      }(p));
      frag.appendChild(row);
    }
    App.els.paraList.appendChild(frag);
  }
  App.renderParaList = renderParaList;

})(window.QuranApp = window.QuranApp || {});

