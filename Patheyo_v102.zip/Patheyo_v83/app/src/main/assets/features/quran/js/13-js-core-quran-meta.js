
/*!
 * js/core/quran-meta.js -- Helpers over the Quran metadata: surah-name / Bismillah SVG markup, Para <-> page lookups
 *
 * Provides : App.bismillahSvg, App.pageIndexInPara, App.paraForPage, App.surahGlyph
 * Needs    : data/para-meta, data/surah-meta
 */
(function (App) {
  "use strict";

  function surahGlyph(index, cls){
    var vb = App.SURAH_VB[index] || [0, 0, 60, 32];
    return '<svg class="surah-glyph ' + cls + '" width="' + vb[2] + '" height="' + vb[3] + '" viewBox="' + vb[0] + ' ' + vb[1] + ' ' + vb[2] + ' ' + vb[3] + '" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true"><use href="#sn' + index + '" xlink:href="#sn' + index + '"></use></svg>';
  }
  App.surahGlyph = surahGlyph;

  function bismillahSvg(){
    return '<svg class="bismillah-svg" width="936" height="180" viewBox="' + App.BISMILLAH_VB + '" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true"><use href="#bismillah-g" xlink:href="#bismillah-g"></use></svg>';
  }
  App.bismillahSvg = bismillahSvg;

  function paraForPage(n){
    for (var i=0;i<App.PARA_PAGE_RANGE.length;i++){
      if (n >= App.PARA_PAGE_RANGE[i][0] && n <= App.PARA_PAGE_RANGE[i][1]) return i+1;
    }
    return 1;
  }
  App.paraForPage = paraForPage;

  function pageIndexInPara(n){ return n - App.PARA_PAGE_RANGE[paraForPage(n)-1][0] + 1; }
  App.pageIndexInPara = pageIndexInPara;

})(window.QuranApp = window.QuranApp || {});

