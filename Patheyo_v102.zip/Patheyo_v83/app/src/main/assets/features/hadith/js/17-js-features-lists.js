
/* ===== js/features/lists.js ===== */
/*!
 * js/features/lists.js -- Book list rendering (same rows as the Quran app's sura list)
 *
 * Provides : App.renderBookList
 * Needs    : core/dom, core/books, core/utils, services/book-download, features/book-view
 */
(function (App) {
  "use strict";

  function statusHtml(id){
    return App.bookDl.isReady(id)
      ? '<span class="st ok">ডাউনলোড করা</span>'
      : '<span class="st">ডাউনলোড বাকি</span>';
  }

  function renderBookList(){
    var frag = document.createDocumentFragment();
    App.BOOKS.forEach(function(b, i){
      var row = document.createElement('div');
      row.className = 'list-item';
      row.setAttribute('data-name', b.nameBn + ' ' + b.nameEn + ' ' + b.nameAr);
      row.setAttribute('data-index', i + 1);
      row.setAttribute('data-book', b.id);
      row.innerHTML =
        '<div class="li-badge">' + App.bn(i + 1) + '</div>' +
        '<div class="li-name-block">' +
          '<div class="li-name-main">' + App.escapeHtml(b.nameBn) + '</div>' +
          '<div class="li-sub">' + App.bn(b.count) + ' হাদীস<span class="sep">·</span>' + statusHtml(b.id) + '</div>' +
        '</div>' +
        '<div class="li-arabic">' + App.bookGlyph(b.id, 'sg-list') + '</div>' +
        '<svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg>';
      row.addEventListener('click', function(){ App.openBook(b.id); });
      frag.appendChild(row);
    });
    App.els.booksList.innerHTML = '';
    App.els.booksList.appendChild(frag);
  }
  App.renderBookList = renderBookList;

})(window.HadithApp = window.HadithApp || {});

