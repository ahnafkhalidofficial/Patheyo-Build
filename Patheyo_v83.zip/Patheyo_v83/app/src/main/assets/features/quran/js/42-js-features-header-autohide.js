
/*!
 * js/features/header-autohide.js -- নিচে স্ক্রল করলে হেডার (লোগো, নাম, থিম বাটন) লুকায়;
 * উপরের দিকে একটু জোরে স্ক্রল করলে (যেখানেই থাকুক) আবার নেমে আসে। কোনো নির্ধারিত জায়গা ধরা নেই -- শুধু স্ক্রলের দিক ও গতি দেখে।
 *
 * Needs : CSS  .app-header.hdr-hidden  (css/header.css)
 */
(function (App) {
  "use strict";

  var header = document.querySelector('.app-header');
  if (!header) return;

  var HIDE_AFTER = 14;   // এই পরিমাণ (px) নিচে নামলে লুকাবে
  var SHOW_AFTER = 28;   // এই পরিমাণ (px) উপরে উঠলে ফিরে আসবে (আস্তে নাড়লে আসবে না)
  var FAST_PX    = 1.1;  // বা এত px/ms গতিতে উঠলে সঙ্গে সঙ্গে ফিরবে
  var lastY = window.pageYOffset, lastT = Date.now(), acc = 0, hidden = false, ticking = false;

  function setHidden(v) {
    if (v === hidden) return;
    hidden = v;
    header.classList.toggle('hdr-hidden', v);
  }

  function searchFocused() {
    var a = document.activeElement;
    return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA');
  }

  function onScroll() {
    var y = Math.max(0, window.pageYOffset), now = Date.now();
    var dy = y - lastY, dt = Math.max(1, now - lastT);
    lastY = y; lastT = now;

    header.classList.toggle('hdr-lifted', y > 4);
    if (y <= 4) { acc = 0; setHidden(false); return; }       // একেবারে উপরে: সবসময় দেখা যাবে
    if (searchFocused()) { setHidden(false); return; }        // লেখার সময় হেডার থাকবে

    if (dy > 0) {                                             // নিচে
      acc = acc > 0 ? acc + dy : dy;
      if (acc >= HIDE_AFTER && y > header.offsetHeight) setHidden(true);
    } else if (dy < 0) {                                      // উপরে
      acc = acc < 0 ? acc + dy : dy;
      if (-acc >= SHOW_AFTER || (-dy / dt) >= FAST_PX) setHidden(false);
    }
  }

  window.addEventListener('scroll', function () {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () { ticking = false; onScroll(); });
  }, { passive: true });

  // পাতা বদলালে (সূরা/পারা খোলা, ট্যাব) হেডার ফিরিয়ে আনা
  window.addEventListener('popstate', function () { setHidden(false); });
  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('.tab, .mode-tab, .tr-mode-btn, .list-item, .back-btn')) setHidden(false);
  }, true);

  App.showHeader = function () { setHidden(false); };

})(window.QuranApp = window.QuranApp || {});

