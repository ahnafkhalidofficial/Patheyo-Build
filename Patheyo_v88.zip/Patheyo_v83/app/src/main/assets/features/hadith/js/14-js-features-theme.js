
/* ===== js/features/theme.js ===== */
/*!
 * js/features/theme.js -- Light / sepia / dark theme switching
 *
 * Provides : App.setTheme
 * Needs    : core/dom
 */
(function (App) {
  "use strict";

  function setTheme(name){
    document.documentElement.setAttribute('data-theme', name);
    App.els.themeBtns.forEach(function(btn){
      btn.classList.toggle('active', btn.getAttribute('data-theme-btn') === name);
    });
    try{ localStorage.setItem('hadith-theme', name); } catch(e){}
  }
  App.setTheme = setTheme;

})(window.HadithApp = window.HadithApp || {});

