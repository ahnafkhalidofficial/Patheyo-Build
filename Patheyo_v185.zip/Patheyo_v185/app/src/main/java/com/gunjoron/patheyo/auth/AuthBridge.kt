package com.gunjoron.patheyo.auth

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.CancellationSignal
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.gunjoron.patheyo.stats.BackendConfig
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * ধাপ ৯ — অ্যাকাউন্ট (JS-এ নাম: PatheyoAuth)
 *
 *  • Google: Android Credential Manager-এর "Sign in with Google" শিট → Google ID টোকেন → Firebase Auth।
 *  • ইমেইল: সাইন-আপ (নাম সহ, যাচাইয়ের ইমেইল যায়), লগইন, পাসওয়ার্ড রিসেট, যাচাই আবার পাঠানো।
 *  • ক্লাউড সিঙ্ক (v185 থেকে Supabase): অ্যাকাউন্ট Firebase-এ, কিন্তু ব্যাকআপ Supabase-এর user_backups টেবিলে।
 *    অ্যাপ Firebase ID টোকেন দিয়ে Edge Function "cloud-sync" ডাকে; সে টোকেন যাচাই করে শুধু ওই uid-এর সারি পড়ে/লেখে/মোছে।
 *    (data = সেটিংসের "ব্যাকআপ" ফাইলের হুবহু লেখা — তাই রিস্টোরও একই যাচাই দিয়ে হয়)। সেটআপ: docs/SUPABASE_CLOUD_SYNC.md
 *    পুরনো (v184-পর্যন্ত) ব্যাকআপ Firebase-এ থাকলে প্রথমবার সেখান থেকে পড়া হয়; পরের সেভ Supabase-এ গিয়ে পুরনোটা মুছে যায়।
 *  • অ্যাকাউন্ট মুছে ফেলা: Supabase-এর ব্যাকআপ + ছবি + Firebase-এর users/{uid} + অ্যাকাউন্ট (দরকার হলে আবার যাচাই করে)।
 *
 * সব কাজ async: JS একটা reqId দেয়, ফলাফল আসে  window.__ptAuthCb(reqId, json)
 *   json = {"ok":true, "state":{…}, …}  অথবা  {"ok":false, "code":"…", "msg":"বাংলায় কারণ"}
 * সাইন-ইন/আউট হলে আলাদা করে  window.__ptAuthChanged(state)।
 */
class AuthBridge(private val activity: Activity, private val webView: WebView) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val io = Executors.newSingleThreadExecutor()
    private val creds by lazy { CredentialManager.create(activity) }

    init {
        try {
            auth.addAuthStateListener { emit("window.__ptAuthChanged&&window.__ptAuthChanged(" + JSONObject.quote(stateJson().toString()) + ")") }
        } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ JS-এর দিকে

    private fun emit(js: String) {
        try { webView.post { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} } } catch (_: Throwable) {}
    }

    private fun reply(req: String, o: JSONObject) {
        emit("window.__ptAuthCb&&window.__ptAuthCb(" + JSONObject.quote(req) + "," + JSONObject.quote(o.toString()) + ")")
    }

    private fun ok(req: String, extra: JSONObject? = null) {
        val o = extra ?: JSONObject()
        o.put("ok", true); o.put("state", stateJson()); reply(req, o)
    }

    private fun fail(req: String, code: String, msg: String) {
        reply(req, JSONObject().put("ok", false).put("code", code).put("msg", msg))
    }

    private fun fail(req: String, t: Throwable?) {
        val (code, msg) = explain(t)
        fail(req, code, msg)
    }

    /** Firebase/Credential-এর ত্রুটি → সহজ বাংলা */
    private fun explain(t: Throwable?): Pair<String, String> = when (t) {
        is GetCredentialCancellationException -> "cancel" to ""
        is NoCredentialException -> "no-account" to "এই ফোনে কোনো Google অ্যাকাউন্ট পাওয়া যায়নি। ফোনের সেটিংসে Google অ্যাকাউন্ট যোগ করে আবার চেষ্টা করুন।"
        is GetCredentialException -> "google" to "Google সাইন-ইন খোলা গেল না। একটু পরে আবার চেষ্টা করুন।"
        is FirebaseNetworkException -> "network" to "ইন্টারনেট সংযোগ নেই। সংযোগ দিয়ে আবার চেষ্টা করুন।"
        is FirebaseTooManyRequestsException -> "many" to "অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।"
        is FirebaseAuthException -> when (t.errorCode) {
            "ERROR_INVALID_EMAIL" -> "email" to "ইমেইল ঠিকানাটা সঠিক নয়।"
            "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL", "ERROR_USER_NOT_FOUND", "ERROR_INVALID_LOGIN_CREDENTIALS" ->
                "wrong" to "ইমেইল বা পাসওয়ার্ড মেলেনি।"
            "ERROR_EMAIL_ALREADY_IN_USE" -> "exists" to "এই ইমেইলে আগে থেকেই অ্যাকাউন্ট আছে — সাইন-ইন করুন।"
            "ERROR_WEAK_PASSWORD" -> "weak" to "পাসওয়ার্ড অন্তত ৬ অক্ষরের দিন।"
            "ERROR_USER_DISABLED" -> "disabled" to "এই অ্যাকাউন্টটি বন্ধ করা আছে।"
            "ERROR_REQUIRES_RECENT_LOGIN" -> "recent" to "নিরাপত্তার জন্য আবার সাইন-ইন করে চেষ্টা করুন।"
            "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" -> "other-provider" to "এই ইমেইলটি অন্যভাবে (Google/ইমেইল) খোলা — সেভাবে সাইন-ইন করুন।"
            else -> (t.errorCode ?: "auth") to "কাজটা করা গেল না। একটু পরে আবার চেষ্টা করুন।"
        }
        else -> "error" to "কাজটা করা গেল না। ইন্টারনেট দেখে আবার চেষ্টা করুন।"
    }

    private fun stateJson(u: FirebaseUser? = try { auth.currentUser } catch (_: Throwable) { null }): JSONObject {
        val o = JSONObject()
        if (u == null) return o.put("signedIn", false)
        val provider = u.providerData.map { it.providerId }.firstOrNull { it == "google.com" || it == "password" } ?: "password"
        return o.put("signedIn", true).put("uid", u.uid)
            .put("name", u.displayName ?: "").put("email", u.email ?: "")
            .put("photo", u.photoUrl?.toString() ?: "")
            .put("provider", if (provider == "google.com") "google" else "email")
            .put("verified", u.isEmailVerified || provider == "google.com")
    }

    private fun db() = FirebaseDatabase.getInstance(RTDB_URL)

    /** অ্যাকাউন্টের ছোট পরিচিতি (নাম/ইমেইল/শেষ দেখা) — পরে প্রিমিয়াম ইত্যাদির জন্য */
    private fun touchProfile(u: FirebaseUser) {
        try {
            db().getReference("users").child(u.uid).child("profile").updateChildren(mapOf(
                "name" to (u.displayName ?: ""), "email" to (u.email ?: ""),
                "provider" to (stateJson(u).optString("provider")), "lastSeen" to ServerValue.TIMESTAMP,
                "device" to (Build.MANUFACTURER + " " + Build.MODEL)))
        } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ অবস্থা

    @JavascriptInterface
    fun state(): String = try { stateJson().toString() } catch (_: Throwable) { "{\"signedIn\":false}" }

    @JavascriptInterface
    fun available(): Boolean = true

    // ------------------------------------------------------------------ Google

    private fun googleToken(onToken: (String) -> Unit, onFail: (Throwable?) -> Unit) {
        val id = activity.resources.getIdentifier("default_web_client_id", "string", activity.packageName)
        if (id == 0) { onFail(IllegalStateException("no web client id")); return }
        val option = GetSignInWithGoogleOption.Builder(activity.getString(id)).build()
        val req = GetCredentialRequest.Builder().addCredentialOption(option).build()
        activity.runOnUiThread {
            try {
                creds.getCredentialAsync(activity, req, CancellationSignal(), io,
                    object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                        override fun onResult(result: GetCredentialResponse) {
                            val c = result.credential
                            if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                try { onToken(GoogleIdTokenCredential.createFrom(c.data).idToken) } catch (t: Throwable) { onFail(t) }
                            } else onFail(null)
                        }
                        override fun onError(e: GetCredentialException) { onFail(e) }
                    })
            } catch (t: Throwable) { onFail(t) }
        }
    }

    @JavascriptInterface
    fun google(req: String) {
        googleToken({ token ->
            val cred = GoogleAuthProvider.getCredential(token, null)
            auth.signInWithCredential(cred).addOnCompleteListener { t ->
                val u = auth.currentUser
                if (t.isSuccessful && u != null) { touchProfile(u); ok(req, JSONObject().put("isNew", t.result?.additionalUserInfo?.isNewUser == true)) }
                else fail(req, t.exception)
            }
        }, { e -> fail(req, e) })
    }

    // ------------------------------------------------------------------ ইমেইল

    @JavascriptInterface
    fun emailIn(req: String, email: String, pass: String) {
        try {
            auth.signInWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                val u = auth.currentUser
                if (t.isSuccessful && u != null) { touchProfile(u); ok(req) } else fail(req, t.exception)
            }
        } catch (t: Throwable) { fail(req, t) }
    }

    @JavascriptInterface
    fun emailUp(req: String, name: String, email: String, pass: String) {
        try {
            auth.createUserWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                val u = auth.currentUser
                if (!t.isSuccessful || u == null) { fail(req, t.exception); return@addOnCompleteListener }
                u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim().take(40)).build()).addOnCompleteListener {
                    try { auth.setLanguageCode("bn") } catch (_: Throwable) {}
                    u.sendEmailVerification()
                    touchProfile(u)
                    ok(req, JSONObject().put("isNew", true))
                }
            }
        } catch (t: Throwable) { fail(req, t) }
    }

    @JavascriptInterface
    fun reset(req: String, email: String) {
        try {
            try { auth.setLanguageCode("bn") } catch (_: Throwable) {}
            auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { t ->
                if (t.isSuccessful) ok(req) else fail(req, t.exception)
            }
        } catch (t: Throwable) { fail(req, t) }
    }

    @JavascriptInterface
    fun sendVerify(req: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        try { auth.setLanguageCode("bn") } catch (_: Throwable) {}
        u.sendEmailVerification().addOnCompleteListener { t -> if (t.isSuccessful) ok(req) else fail(req, t.exception) }
    }

    /** ইমেইল যাচাই করার পর "যাচাই করেছি" চাপলে সার্ভার থেকে নতুন অবস্থা */
    @JavascriptInterface
    fun reload(req: String) {
        val u = auth.currentUser ?: return ok(req)
        u.reload().addOnCompleteListener { t -> if (t.isSuccessful) ok(req) else fail(req, t.exception) }
    }

    @JavascriptInterface
    fun setName(req: String, name: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim().take(40)).build())
            .addOnCompleteListener { t -> if (t.isSuccessful) { touchProfile(u); ok(req) } else fail(req, t.exception) }
    }

    /** অ্যাকাউন্টের ছবি (Google) ২৫৬px JPEG dataURL হিসেবে — হোমের প্রোফাইল-ছবিতে বসে, অফলাইনেও দেখা যায় */
    @JavascriptInterface
    fun photo(req: String) {
        val url = auth.currentUser?.photoUrl?.toString().orEmpty()
        if (url.isEmpty()) return ok(req, JSONObject().put("data", ""))
        io.execute {
            try {
                val big = if (url.contains("googleusercontent.com")) url.replace(Regex("=s\\d+(-c)?$"), "") + "=s256-c" else url
                val c = (URL(big).openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000 }
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) } ?: throw IllegalStateException("decode")
                val s = minOf(bmp.width, bmp.height)
                val sq = Bitmap.createBitmap(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s)
                val out = ByteArrayOutputStream()
                Bitmap.createScaledBitmap(sq, 256, 256, true).compress(Bitmap.CompressFormat.JPEG, 86, out)
                ok(req, JSONObject().put("data", "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)))
            } catch (t: Throwable) { ok(req, JSONObject().put("data", "")) }
        }
    }

    @JavascriptInterface
    fun signOut(req: String) {
        try { auth.signOut() } catch (_: Throwable) {}
        try {
            creds.clearCredentialStateAsync(ClearCredentialStateRequest(), CancellationSignal(), io,
                object : CredentialManagerCallback<Void?, ClearCredentialException> {
                    override fun onResult(result: Void?) {}
                    override fun onError(e: ClearCredentialException) {}
                })
        } catch (_: Throwable) {}
        ok(req)
    }

    /**
     * অ্যাকাউন্ট মুছে ফেলা (Play-এর নিয়ম): আগে আবার যাচাই (Google = শিট থেকে অ্যাকাউন্ট বাছাই, ইমেইল = পাসওয়ার্ড),
     * তারপর ক্লাউডের সব ডেটা (Supabase-এর ব্যাকআপ ও ছবি + Firebase-এর users/{uid}) মুছে অ্যাকাউন্ট মুছে ফেলা।
     */
    @JavascriptInterface
    fun deleteAccount(req: String, password: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        val google = stateJson(u).optString("provider") == "google"
        val proceed: (AuthCredential) -> Unit = { cred ->
            u.reauthenticate(cred).addOnCompleteListener { r ->
                if (!r.isSuccessful) { fail(req, r.exception); return@addOnCompleteListener }
                val uid = u.uid
                // v185: আগে Supabase-এর ব্যাকআপ মোছা (না মুছলে অ্যাকাউন্ট মোছা হবে না — ডেটা পড়ে থাকা চলবে না)
                u.getIdToken(true).addOnCompleteListener { tt ->
                    val tok = tt.result?.token
                    if (!tt.isSuccessful || tok.isNullOrEmpty()) { fail(req, tt.exception); return@addOnCompleteListener }
                    io.execute {
                        val cloudGone = try {
                            !BackendConfig.enabled() || syncCall(tok, JSONObject().put("action", "delete")).optBoolean("ok")
                        } catch (_: Throwable) { false }
                        if (!cloudGone) {
                            fail(req, "net", "ক্লাউডের ডেটা মোছা গেল না — ইন্টারনেট দেখে আবার চেষ্টা করুন।")
                        } else {
                            try { avatarCall("DELETE", uid, null) } catch (_: Throwable) {}   // v184: Supabase-এর প্রোফাইল ছবিও মোছা
                            db().getReference("users").child(uid).removeValue().addOnCompleteListener {   // প্রোফাইল/প্রিমিয়াম/পুরনো ব্যাকআপ (Firebase)
                                u.delete().addOnCompleteListener { d ->
                                    if (d.isSuccessful) { try { auth.signOut() } catch (_: Throwable) {}; ok(req) } else fail(req, d.exception)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (google) googleToken({ tok -> proceed(GoogleAuthProvider.getCredential(tok, null)) }, { e -> fail(req, e) })
        else {
            if (password.isEmpty()) return fail(req, "need-password", "পাসওয়ার্ড দিন।")
            proceed(EmailAuthProvider.getCredential(u.email ?: "", password))
        }
    }

    // ------------------------------------------------------------------ প্রোফাইল ছবি (Supabase Storage) — v184
    // বাকেট: avatars (পাবলিক), ফাইল: {firebase uid}.jpg, সর্বোচ্চ ১০০KB। বাকেটের নিজস্ব সীমাও ১০০KB (docs/SUPABASE_AVATARS.sql)।
    private val avatarMax = 100 * 1024

    private fun avatarCall(method: String, uid: String, body: ByteArray?): Int {
        val key = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_ANON_KEY
        val url = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_URL.trimEnd('/') + "/storage/v1/object/avatars/" + uid + ".jpg"
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("apikey", key); setRequestProperty("Authorization", "Bearer $key")
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "image/jpeg"); setFixedLengthStreamingMode(body.size) }
        }
        try {
            if (body != null) c.outputStream.use { it.write(body) }
            return c.responseCode
        } finally { c.disconnect() }
    }

    /** ১০০KB-এর বেশি হলে (JS-এর ছোট করা সত্ত্বেও) এখানে আবার ছোট করা — Supabase-এ কখনো ১০০KB-এর বেশি যাবে না */
    private fun fitAvatar(raw: ByteArray): ByteArray {
        if (raw.size <= avatarMax) return raw
        val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: throw IllegalStateException("decode")
        val s0 = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - s0) / 2, (bmp.height - s0) / 2, s0, s0)
        var side = minOf(s0, 512)
        while (side >= 64) {
            val scaled = Bitmap.createScaledBitmap(sq, side, side, true)
            var q = 85
            while (q >= 40) {
                val out = ByteArrayOutputStream(); scaled.compress(Bitmap.CompressFormat.JPEG, q, out)
                if (out.size() <= avatarMax) return out.toByteArray()
                q -= 9
            }
            side = (side * 0.8).toInt()
        }
        throw IllegalStateException("big")
    }

    @JavascriptInterface
    fun uploadAvatar(req: String, dataUrl: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        if (!com.gunjoron.patheyo.stats.BackendConfig.enabled()) return fail(req, "off", "ছবি রাখার সুবিধা চালু নেই।")
        val uid = u.uid
        io.execute {
            try {
                val raw = Base64.decode(dataUrl.substringAfter(',', ""), Base64.DEFAULT)
                val bytes = fitAvatar(raw)
                var code = avatarCall("POST", uid, bytes)
                if (code == 400 || code == 409) code = avatarCall("PUT", uid, bytes)     // আগের ছবি আছে → বদলে দেওয়া
                if (code in 200..299) ok(req, JSONObject().put("size", bytes.size)) else fail(req, "http", "ছবি ক্লাউডে রাখা গেল না (কোড $code)।")
            } catch (t: Throwable) { fail(req, "net", "ছবি ক্লাউডে রাখা গেল না — ইন্টারনেট দেখুন।") }
        }
    }

    @JavascriptInterface
    fun deleteAvatar(req: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        if (!com.gunjoron.patheyo.stats.BackendConfig.enabled()) return ok(req)
        val uid = u.uid
        io.execute {
            try {
                val code = avatarCall("DELETE", uid, null)
                if (code in 200..299 || code == 404) ok(req) else fail(req, "http", "ছবি মোছা গেল না (কোড $code)।")
            } catch (t: Throwable) { fail(req, "net", "ছবি মোছা গেল না — ইন্টারনেট দেখুন।") }
        }
    }

    // ------------------------------------------------------------------ ক্লাউড সিঙ্ক (Supabase, v185)

    /** Edge Function "cloud-sync"-কে ডাকা। io থ্রেড থেকে ডাকতে হবে। ফেরত: সার্ভারের JSON + "http" (স্ট্যাটাস কোড) */
    private fun syncCall(idToken: String, body: JSONObject): JSONObject {
        val url = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/cloud-sync"
        val key = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_ANON_KEY
        val bytes = body.toString().toByteArray(Charsets.UTF_8)
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 40000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", key); setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("x-firebase-token", idToken)
            setFixedLengthStreamingMode(bytes.size)
        }
        try {
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val o = try { JSONObject(txt) } catch (_: Throwable) { JSONObject() }
            return o.put("http", code)
        } finally { c.disconnect() }
    }

    /** সাইন-ইন করা ইউজারের Firebase টোকেন নিয়ে (io থ্রেডে) কাজ চালানো */
    private fun withToken(req: String, block: (String) -> Unit) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        if (!com.gunjoron.patheyo.stats.BackendConfig.enabled()) return fail(req, "off", "ক্লাউড ব্যাকআপ চালু নেই।")
        u.getIdToken(false).addOnCompleteListener { t ->
            val tok = t.result?.token
            if (!t.isSuccessful || tok.isNullOrEmpty()) { fail(req, t.exception); return@addOnCompleteListener }
            io.execute {
                try { block(tok) } catch (_: Throwable) { fail(req, "net", "ইন্টারনেট সংযোগ নেই। সংযোগ দিয়ে আবার চেষ্টা করুন।") }
            }
        }
    }

    @JavascriptInterface
    fun cloudSave(req: String, text: String) {
        if (text.length > 4_000_000) return fail(req, "big", "ডেটা অনেক বড় — ক্লাউডে রাখা গেল না।")
        withToken(req) { tok ->
            val r = syncCall(tok, JSONObject().put("action", "save").put("data", text)
                .put("device", Build.MANUFACTURER + " " + Build.MODEL))
            if (r.optBoolean("ok")) {
                ok(req, JSONObject().put("at", r.optLong("at", System.currentTimeMillis())))
                dropLegacyBackup()
            } else fail(req, "http", "ক্লাউডে রাখা গেল না (কোড " + r.optInt("http") + ")।")
        }
    }

    @JavascriptInterface
    fun cloudLoad(req: String) {
        withToken(req) { tok ->
            val r = syncCall(tok, JSONObject().put("action", "load"))
            if (!r.optBoolean("ok")) {
                fail(req, "http", "ক্লাউড থেকে আনা গেল না (কোড " + r.optInt("http") + ")।")
            } else if (!r.optBoolean("empty", true) && r.optString("data").isNotEmpty()) {
                ok(req, JSONObject().put("empty", false).put("at", r.optLong("at"))
                    .put("device", r.optString("device")).put("data", r.optString("data")))
            } else {
                loadLegacyBackup(req)   // Supabase-এ কিছু নেই → v184-পর্যন্ত Firebase-এ রাখা পুরনো ব্যাকআপ আছে কি দেখা
            }
        }
    }

    /** v184-পর্যন্ত ব্যাকআপ ছিল Firebase Realtime Database-এ users/{uid}/backup — নতুন ভার্সনে এলে যেন কিছু না হারায় */
    private fun loadLegacyBackup(req: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        try {
            db().getReference("users").child(u.uid).child("backup").get().addOnCompleteListener { t ->
                if (!t.isSuccessful) { ok(req, JSONObject().put("empty", true)); return@addOnCompleteListener }
                val s = t.result
                if (s == null || !s.exists()) { ok(req, JSONObject().put("empty", true)); return@addOnCompleteListener }
                val at = (s.child("at").value as? Number)?.toLong() ?: 0L
                ok(req, JSONObject().put("empty", false).put("at", at)
                    .put("device", s.child("device").value?.toString() ?: "").put("data", s.child("data").value?.toString() ?: ""))
            }
        } catch (_: Throwable) { ok(req, JSONObject().put("empty", true)) }
    }

    /** Supabase-এ সেভ হয়ে গেলে Firebase-এর পুরনো ব্যাকআপ (যদি থাকে) মুছে ফেলা — ডেটা একটাই জায়গায় থাকবে */
    private fun dropLegacyBackup() {
        try { auth.currentUser?.let { db().getReference("users").child(it.uid).child("backup").removeValue() } } catch (_: Throwable) {}
    }

    companion object {
        const val RTDB_URL = "https://hijri-tarikh-default-rtdb.firebaseio.com"
    }
}
