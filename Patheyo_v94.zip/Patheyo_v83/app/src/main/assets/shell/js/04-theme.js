
/* theme switcher + settings page */
(function () {
  var KEY = 'pathey-theme';
  var root = document.documentElement;
  var mq = window.matchMedia ? matchMedia('(prefers-color-scheme: light)') : null;
  var overlay = document.getElementById('settings-overlay');
  var openBtn = document.getElementById('btn-settings');
  var backBtn = document.getElementById('settings-back');
  var label = document.getElementById('theme-current-label');
  var meta = document.getElementById('meta-theme-color');
  var opts = Array.prototype.slice.call(document.querySelectorAll('[data-theme-choice]'));
  var NAMES = { light: 'লাইট মোড', dark: 'ডার্ক মোড' };

  var pref = root.getAttribute('data-theme-pref') || 'dark';

  function effective() { return pref === 'auto' ? ((mq && mq.matches) ? 'light' : 'dark') : pref; }

  var swapT = 0;
  function apply() {
    var t = effective();
    if (root.getAttribute('data-theme') !== t) {       /* v91: লাইট/ডার্ক বদল চোখের পলকে -- বদলের মুহূর্তে সব transition বন্ধ (CSS: html.pt-themeswap *) */
      root.classList.add('pt-themeswap');
      clearTimeout(swapT); swapT = setTimeout(function () { root.classList.remove('pt-themeswap'); }, 220);
    }
    root.setAttribute('data-theme', t);
    root.setAttribute('data-theme-pref', pref);
    if (meta) meta.setAttribute('content', t === 'light' ? '#F2F6FB' : '#00122F');
    opts.forEach(function (o) {
      var on = o.getAttribute('data-theme-choice') === pref;
      o.classList.toggle('is-selected', on);
      o.setAttribute('aria-checked', on ? 'true' : 'false');
    });
    if (label) label.textContent = (pref === 'auto' ? 'অটো · ' : '') + NAMES[t];
  }

  function setPref(p) {
    pref = p;
    try { localStorage.setItem(KEY, p); } catch (e) {}
    apply();
  }

  opts.forEach(function (o) {
    o.addEventListener('click', function () { setPref(o.getAttribute('data-theme-choice')); });
  });

  if (mq) {
    var onSys = function () { if (pref === 'auto') apply(); };
    if (mq.addEventListener) mq.addEventListener('change', onSys); else if (mq.addListener) mq.addListener(onSys);
  }

  function setOrigin() {
    var r = openBtn.getBoundingClientRect();
    overlay.style.setProperty('--ov-x', Math.round(r.left + r.width / 2) + 'px');
    overlay.style.setProperty('--ov-y', Math.round(r.top + r.height / 2) + 'px');
  }
  function openSettings() {
    setOrigin();
    overlay.removeAttribute('inert');
    overlay.setAttribute('aria-hidden', 'false');
    overlay.classList.add('is-open');
    setTimeout(function () { backBtn.focus({ preventScroll: true }); }, 120);
  }
  function closeSettings() {
    setOrigin();
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    overlay.setAttribute('inert', '');
    openBtn.focus({ preventScroll: true });
  }
  /* opening/closing of settings is handled by the shared popup controller below */

  apply();

})();
