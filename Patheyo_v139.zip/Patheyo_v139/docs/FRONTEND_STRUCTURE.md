# ফ্রন্টএন্ড কাঠামো (v83)

প্রতিটি ফিচার আলাদা ফোল্ডারে — HTML, ডিজাইন (CSS), লজিক (JS) আলাদা ফাইলে। ফন্ট সব এক জায়গায়।

```
app/src/main/assets/
  index.html                  ← শেল: হোম পেজ, ফুটার, সেটিংস, স্প্ল্যাশ (শুধু কাঠামো)
  shell/
    css/                      ← শেলের ডিজাইন (01-fonts, 02-app, 04-splash, 05-feature-frames, 06-permissions …)
    js/                       ← শেলের লজিক (01-splash … 05-pages-controller, 06-native-bridge)
  features/                   ← প্রতিটি ফিচার আলাদা
    namaz/   namaz.html  css/  js/  img/
    quran/   quran.html  css/  js/  vendor/(pdf.js)
    hadith/  hadith.html css/  js/
    amol/    amol.html   css/  js/  vendor/(Chart.js)
    tasbih/  tasbih.html css/  js/
    widget/  widget.html css/  js/
    qibla/   qibla.html  css/  js/
  fonts/                      ← সব ফন্ট: Kotlin যেগুলো ব্যবহার করে (Gunjoron-Font, Poppins, Outfit …)
    web/                      ← শুধু ওয়েব পেজের ফন্ট (কুরআনি আরবি, Noto Serif Bengali, FontAwesome …)
  widget_preview_images/      ← উইজেট হাবের প্রিভিউ ছবি 01–24.png (README.md দেখুন)
  notification_images/        ← নোটিফিকেশনের ছবি (Kotlin)
  notifications_config.json   ← নোটিফিকেশন কনফিগ (Kotlin)
  widget_style_config.json    ← উইজেট স্টাইল কনফিগ (Kotlin)
  azan.mp3                    ← আজান (Kotlin AzanForegroundService + নামাজ পেজ)
```

## কীভাবে চলে
- মূল পেজ `file:///android_asset/index.html` (লোকাল স্টোরেজ আগের মতোই)।
- ফিচারের HTML `shell/js/05-pages-controller.js`-এর `frFetch()` আনে এবং আগের মতোই iframe-এর `srcdoc`-এ বসায় — তাই ফ্রেম মূল পেজের একই অরিজিনে থাকে (থিম সিঙ্ক, হোমের সময়/তারিখ, হেডার-আইকন ফ্লাই সব অপরিবর্তিত)।
- **ফুটার ও গ্লাস (v137):** ফিচারের ফ্রেম পুরো স্ক্রিন-উচ্চতার; ফুটার (`.bottom-nav`, z-index 1000) তার ওপরে বসে, তাই কনটেন্ট তার নিচ দিয়ে স্ক্রল করে ও ফুটারের গ্লাস কাজ করে। ফিচারের CSS/JS-এ নিচে-লাগানো (`position: fixed; bottom`) কিছু যোগ করলে `var(--pt-nav-fix, 0px)` যোগ করুন (দেখুন `NAV_CLEAR`, `shell/js/05-pages-controller.js`)।
- ফিচারের ফাইল (HTML/CSS/JS/ফন্ট/ছবি) `https://appassets.patheyo.invalid/<assets-পাথ>` ঠিকানায় আসে; Kotlin-এর `web/AssetServer.kt` সেটা সরাসরি assets থেকে দেয় (`MainActivity.shouldInterceptRequest`)।
- ফিচারের ভেতরে ফাইলের ক্রম নাম-সংখ্যা (`01-…`, `02-…`) — HTML-এ যে ক্রমে `<link>`/`<script>` আছে সেই ক্রমেই চলে।

## কোথায় কী বদলাবেন
| কাজ | ফাইল |
|---|---|
| কোনো ফিচারের ডিজাইন | `features/<নাম>/css/…` |
| কোনো ফিচারের লজিক | `features/<নাম>/js/…` |
| হোম/ফুটার/স্প্ল্যাশ/সেটিংসের ডিজাইন | `shell/css/…` |
| পেজ খোলা-বন্ধ, আইকন ফ্লাই, থিম সিঙ্ক | `shell/js/05-pages-controller.js` |
| Kotlin ↔ JS সংযোগ | `shell/js/06-native-bridge.js` |
| হাদিসের কিতাবের GitHub লিংক | `features/hadith/js/05-data-books-config.js` |
| কুরআনের মুসহাফ/তরজমার লিংক | `features/quran/js/06-data-pdf-config.js`, `07-data-tarjama-config.js` |
| ওয়েব ফন্ট বদলানো | `fonts/web/` + ওই ফিচারের CSS-এর `@font-face` |

## Kotlin ↔ ডাউনলোড
- কুরআন: `quran/QuranFileBridge.kt`, `quran/QuranLocalServer.kt` — `docs/QURAN_DOWNLOAD_NOTE.md`
- হাদিস (v83 থেকে): `hadith/HadithFileBridge.kt`, `hadith/HadithLocalServer.kt` — `docs/HADITH_DOWNLOAD_NOTE.md`

**`shell/js/06-native-bridge.js` সবসময় সবার শেষে লোড হয় — `index.html`-এ এর ক্রম বদলাবেন না।**
