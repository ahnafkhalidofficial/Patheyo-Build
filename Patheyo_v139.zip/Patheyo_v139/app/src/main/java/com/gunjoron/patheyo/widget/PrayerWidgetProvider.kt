package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/PrayerWidgetProvider.kt
//
// ✅ v135: হোম স্ক্রিন উইজেট এখন "উইজেট হাব"-এর ৯টি ডিজাইনে (com.gunjoron.patheyo.widgethub) আঁকা হয়।
//   • পুরনো উইজেটের ডিজাইন/লেআউট/স্টাইল-কনফিগ সম্পূর্ণ মুছে ফেলা হয়েছে।
//   • তারিখ-পরিবর্তন (Firebase হিজরি অ্যাডজাস্টমেন্ট/ওভাররাইড), নোটিফিকেশন, বার-ও-সময় রিফ্রেশ
//     (WidgetRefreshScheduler, WidgetSystemEventReceiver, WidgetUpdateWorker, RtdbSyncWorker) আগের মতোই
//     এই ক্লাসের মাধ্যমে নতুন উইজেটে যুক্ত — তাই বাকি সব জায়গায় ক্লাসের নাম ও API হুবহু আগের মতো।
//   • নামাজের সময় ও নিষিদ্ধ সময় নামাজ ফিচার থেকে; ইংরেজি/বাংলা/আরবি তারিখ অ্যাপের হোমের নিয়মে
//     (দেখুন widgethub/data/Snapshot.kt)।

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.gunjoron.patheyo.widgethub.widget.WidgetUpdater

class PrayerWidgetProvider : AppWidgetProvider() {

    companion object {
        const val PREFS_NAME = "ibadat_widget_prefs"
        const val KEY_TIMINGS = "timings_json"

        /** সব উইজেটে আপডেট-ব্রডকাস্ট পাঠায় (সিস্টেম সাথে সাথে রিফ্রেশ করে) */
        fun updateAllWidgets(context: Context) {
            val appContext = context.applicationContext
            val mgr = AppWidgetManager.getInstance(appContext)
            val cn = ComponentName(appContext, PrayerWidgetProvider::class.java)
            val ids = mgr.getAppWidgetIds(cn)
            if (ids.isNotEmpty()) {
                val intent = Intent(appContext, PrayerWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                appContext.sendBroadcast(intent)
            }
        }

        /** সরাসরি (ব্রডকাস্ট ছাড়া) সব উইজেট আবার আঁকে — একটার সমস্যা বাকিগুলো আটকায় না */
        fun updateWidgetDirectly(context: Context) {
            try { WidgetUpdater.updateAll(context.applicationContext) } catch (_: Throwable) { }
        }

        fun updateWidget(context: Context, mgr: AppWidgetManager, widgetId: Int) {
            try { WidgetUpdater.update(context.applicationContext, mgr, intArrayOf(widgetId)) } catch (_: Throwable) { }
        }
    }

    // অ্যালার্ম (৮০-মিনিট / ওয়াক্ত / মাগরিব / মধ্যরাত / নিষিদ্ধ-সময়) ফায়ার হলে "হার্ড রিসেট"।
    // Android নিয়ম: onReceive মেইন থ্রেডে ও ~১০ সেকেন্ডের মধ্যে শেষ হতে হয়। তাই goAsync() + ব্যাকগ্রাউন্ড থ্রেড,
    // কাজ শেষে finish()। সবার আগে scheduleAll() (hardReset-এর প্রথম ধাপ) ⇒ রেন্ডার ব্যর্থ হলেও পরের অ্যালার্ম সেট থাকে।
    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)
        val ctx = context?.applicationContext ?: return
        when (intent?.action) {
            WidgetRefreshScheduler.REFRESH_ACTION -> {
                val pending = try { goAsync() } catch (_: Throwable) { null }
                val job = Runnable {
                    try {
                        WidgetRefreshScheduler.hardReset(ctx)
                        try {
                            // নোটিফিকেশন সিস্টেমের স্বাধীন অতিরিক্ত নিরাপত্তা-স্তর (আগের মতোই)
                            com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(ctx)
                        } catch (_: Throwable) { /* উইজেট চেইনের সাথে সম্পর্কহীন */ }
                    } catch (_: Throwable) {
                        // কোনো অবস্থাতেই এখান থেকে ক্র্যাশ নয়
                    } finally {
                        try { pending?.finish() } catch (_: Throwable) {}
                    }
                }
                if (pending != null) {
                    try { Thread(job, "patheyo-widget-reset").start() } catch (_: Throwable) { job.run() }
                } else job.run()
            }
            // হাবের মিনিট/ওয়াক্ত-সীমার টিক এবং "উইজেট যুক্ত করুন"-এর কলব্যাক
            WidgetUpdater.ACTION_TICK, WidgetUpdater.ACTION_REFRESH -> {
                try { WidgetUpdater.updateAll(ctx) } catch (_: Throwable) {}
                try { WidgetRefreshScheduler.scheduleAll(ctx) } catch (_: Throwable) {}
            }
            // ফোন আনলক: ডিজাইন ৬-এ সূর্য/চাঁদের ছোট অ্যানিমেশন (কাজ পাশের থ্রেডে; শেষে pendingResult.finish())
            Intent.ACTION_USER_PRESENT -> {
                val pr = try { goAsync() } catch (_: Throwable) { null }
                Thread {
                    try { WidgetUpdater.playUnlockAnim(ctx) } catch (_: Throwable) {} finally { try { pr?.finish() } catch (_: Throwable) {} }
                }.start()
            }
            Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                try { WidgetUpdater.updateAll(ctx) } catch (_: Throwable) {}
            }
        }
    }

    // scheduleAll() সবার আগে — নিচের লুপে কিছু ভুল হলেও পরবর্তী রিফ্রেশ অ্যালার্ম ইতোমধ্যে সেট থাকে।
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        try { WidgetRefreshScheduler.scheduleAll(context) } catch (_: Throwable) { /* পরের সাইকেলে ঠিক হবে */ }
        try { WidgetUpdater.update(context, appWidgetManager, appWidgetIds) } catch (_: Throwable) { }
    }

    // ইউজার উইজেট রিসাইজ করলে নতুন মাপে আবার আঁকা হয়
    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        try { WidgetUpdater.update(context, appWidgetManager, intArrayOf(appWidgetId)) } catch (_: Throwable) { }
    }

    // শেষ উইজেটটা সরালে সব অ্যালার্মও বাতিল (অকারণ ওয়েকআপ নয়)
    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        try { WidgetRefreshScheduler.cancelAll(context) } catch (_: Throwable) {}
        try { WidgetUpdater.cancel(context) } catch (_: Throwable) {}
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        // উইজেট প্রথমবার যোগ হলে সব schedule সেট করো
        try { WidgetRefreshScheduler.scheduleAll(context) } catch (_: Throwable) { }
    }
}
