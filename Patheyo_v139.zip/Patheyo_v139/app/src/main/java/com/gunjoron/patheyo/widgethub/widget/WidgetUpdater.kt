package com.gunjoron.patheyo.widgethub.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.SystemClock
import android.widget.RemoteViews
import com.gunjoron.patheyo.MainActivity
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import com.gunjoron.patheyo.widget.WidgetRefreshScheduler
import com.gunjoron.patheyo.widgethub.data.Prefs
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.widget.assets.Fonts
import com.gunjoron.patheyo.widgethub.widget.theme.Look
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * হোমস্ক্রিন উইজেট আপডেট।
 *
 * গতির কৌশল:
 *  • সব স্ট্যাটিক/ধীর-বদলানো অংশ একবারই একটা বিটম্যাপে আঁকা হয় (কয়েক মিলিসেকেন্ড)।
 *  • ঘড়ির সেকেন্ড/মিনিট ও কাউন্টডাউন লঞ্চারের নিজস্ব TextClock/Chronometer টিক করে — আমাদের প্রসেস
 *    প্রতি সেকেন্ডে জাগে না, ব্যাটারি প্রায় শূন্য খরচ।
 *  • শুধু ওয়াক্তের সীমানা, দুপুর ১২টা ও মধ্যরাতে একটাই অ্যালার্ম — তখন উইজেট আবার আঁকা হয়।
 */
object WidgetUpdater {
    const val ACTION_TICK = "com.gunjoron.patheyo.widgethub.ACTION_TICK"
    const val ACTION_REFRESH = "com.gunjoron.patheyo.widgethub.ACTION_REFRESH"
    private const val BITMAP_W = 1100f

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        updatePickerPreview(ctx, mgr)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerWidgetProvider::class.java))
        if (ids.isEmpty()) { cancel(ctx); return }
        update(ctx, mgr, ids)
    }

    /**
     * উইজেট-পিকারে (হোম স্ক্রিন → উইজেট) ইউজারের বাছা ডিজাইন/থিমই প্রিভিউ হিসেবে দেখায়।
     * অ্যান্ড্রয়েড ১৫+ (API 35) "generated previews" সাপোর্ট করে; পুরনো ভার্শনে শুধু স্ট্যাটিক previewImage চলে।
     * (compileSdk 34 তাই reflection; সিস্টেমের রেট-লিমিট এড়াতে শুধু ডিজাইন/থিম বদলালে পাঠানো হয়।)
     */
    private fun updatePickerPreview(ctx: Context, mgr: AppWidgetManager) {
        if (Build.VERSION.SDK_INT < 35) return
        try {
            val app = ctx.applicationContext
            val prefs = Prefs.get(app)
            val sig = listOf(prefs.widgetDesign, prefs.theme, prefs.nobgMode, prefs.customBg, prefs.customOpacity, prefs.customTone).joinToString("|")
            val sp = app.getSharedPreferences("hub_preview", Context.MODE_PRIVATE)
            if (sp.getString("sig", "") == sig) return
            Fonts.init(app)
            val rv = build(app, mgr, -1, Look.from(prefs, design = prefs.widgetDesign), Snapshot.build(app))
            val m = AppWidgetManager::class.java.getMethod("setWidgetPreview", ComponentName::class.java, Int::class.javaPrimitiveType, android.widget.RemoteViews::class.java)
            m.invoke(mgr, ComponentName(app, PrayerWidgetProvider::class.java), 1 /* WIDGET_CATEGORY_HOME_SCREEN */, rv)
            sp.edit().putString("sig", sig).apply()
        } catch (_: Throwable) {}
    }

    fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val app = ctx.applicationContext
        Fonts.init(app)
        val look = Look.from(Prefs.get(app).let { it }, design = Prefs.get(app).widgetDesign)
        val snap = Snapshot.build(app)
        // অ্যাপ এখনো নামাজের সময় সেভ করেনি — নেটওয়ার্ক পেলেই ব্যাকগ্রাউন্ডে সময় এনে উইজেট আবার আঁকা হবে
        if (!Snapshot.hasSavedTimings(app)) { try { WidgetRefreshScheduler.enqueueFetchNow(app) } catch (_: Throwable) {} }
        for (id in ids) {
            try {
                mgr.updateAppWidget(id, build(app, mgr, id, look, snap))
            } catch (t: Throwable) {
                // একটা উইজেটের সমস্যা বাকিগুলো আটকাবে না
            }
        }
        // ঘণ্টা:মিনিট বিটম্যাপে আঁকা, তাই প্রতি মিনিটের শুরুতে (অথবা ওয়াক্ত বদলের সময়, যেটা আগে) নতুন করে আঁকা
        val nextMinute = (snap.nowMs / 60000L + 1) * 60000L + 150L
        schedule(app, minOf(snap.nextChangeMs, nextMinute))
    }

    /** লঞ্চারের জানানো আনুমানিক মাপ (px)। শুধু "প্রস্থ-সীমিত না উচ্চতা-সীমিত" বাছতে লাগে — সঠিক হওয়া জরুরি নয়। */
    private fun sizePx(ctx: Context, mgr: AppWidgetManager, id: Int): Pair<Float, Float> {
        val o = mgr.getAppWidgetOptions(id)
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 130
        // কিছু হুয়াওয়ে/অনার লঞ্চার প্রস্থ ~১৪% বেশি জানায় (পরীক্ষায় দেখা গেছে)
        val m = Build.MANUFACTURER.lowercase()
        val fw = if (m.contains("huawei") || m.contains("honor")) 0.875f else 1f
        return Pair(wDp * fw, hDp.toFloat())
    }

    private val LAYOUT_W = intArrayOf(0, R.layout.wv15_d1_w, R.layout.wv15_d2_w, R.layout.wv15_d3_w, R.layout.wv15_d4_w, R.layout.wv15_d5_w, R.layout.wv15_d6_w, R.layout.wv15_d7_w, R.layout.wv15_d8_w, R.layout.wv15_d9_w)
    private val LAYOUT_H = intArrayOf(0, R.layout.wv15_d1_h, R.layout.wv15_d2_h, R.layout.wv15_d3_h, R.layout.wv15_d4_h, R.layout.wv15_d5_h, R.layout.wv15_d6_h, R.layout.wv15_d7_h, R.layout.wv15_d8_h, R.layout.wv15_d9_h)

    private fun layoutOf(ctx: Context, mgr: AppWidgetManager, id: Int, d: Int, compact: Boolean = false): Int {
        val regionW = WidgetRenderer.cardW(d) + 2 * WidgetRenderer.PAD
        val regionH = WidgetRenderer.cardH(d, compact) + 2 * WidgetRenderer.PAD
        val (wv, hv) = sizePx(ctx, mgr, id)
        return (if (wv / hv >= regionW / regionH) LAYOUT_H else LAYOUT_W)[d]
    }

    @Volatile private var lastAnimMs = 0L
    private const val ANIM_STEP_MS = 70L

    /**
     * আনলক অ্যানিমেশন (শুধু ডিজাইন ৬)। ফ্রেমগুলো ছোট (শুধু আকাশ-অংশ) বিটম্যাপ; লঞ্চারের ViewFlipper-এ বসিয়ে
     * প্রতি ~৭০ms-এ setDisplayedChild দিয়ে এগোনো হয় — তাই শেষ ফ্রেমে থামে, অনন্ত লুপ নেই।
     * শেষে স্বাভাবিক আপডেট আসে (ফ্রেম মুছে যায়, মেমরি ছাড়ে)। মাঝপথে প্রসেস মারা গেলেও পরের মিনিট-টিকে ঠিক হয়ে যায়।
     */
    fun playUnlockAnim(ctx: Context) {
        val prefs = Prefs.get(ctx)
        if (prefs.widgetDesign != 6) return
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerWidgetProvider::class.java))
        if (ids.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - lastAnimMs < 8000L) return          // বারবার আনলকে অকারণ কাজ নয়
        lastAnimMs = now
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (!pm.isInteractive) return                  // স্ক্রিন বন্ধ থাকলে কেউ দেখছে না
        Fonts.init(ctx)
        val look = Look.from(prefs, design = prefs.widgetDesign)
        val snap = Snapshot.build(ctx)
        val fEnd = WidgetRenderer.skyFraction(snap, snap.nowMs)
        if (fEnd < 0.03f) return

        // মেমরি বাজেট: সব বিটম্যাপ মিলিয়ে স্ক্রিনের (W×H×৪×১.৫)-এর ৬০%-এর মধ্যে
        val dm = ctx.resources.displayMetrics
        val cap = dm.widthPixels.toLong() * dm.heightPixels * 4L * 3L / 2L
        val regionW = WidgetRenderer.cardW(6) + 2 * WidgetRenderer.PAD
        val regionH = WidgetRenderer.cardH(6) + 2 * WidgetRenderer.PAD
        val k = BITMAP_W / regionW
        val bgBytes = (regionW * k * regionH * k * 4f).toLong()
        val sc = k * 0.6f
        val fw = (WidgetRenderer.SKY_W * sc).roundToInt(); val fh = (WidgetRenderer.SKY_H * sc).roundToInt()
        val perFrame = fw.toLong() * fh * 4L
        val n = minOf(14L, (cap * 6L / 10L - bgBytes) / perFrame).toInt()
        if (n < 6) return

        val frames = ArrayList<Bitmap>(n)
        for (i in 0 until n) {
            val t = i.toFloat() / (n - 1)
            val e = 1f - (1f - t) * (1f - t) * (1f - t)    // শুরুতে দ্রুত, শেষে ধীরে থামা
            val b = Bitmap.createBitmap(fw, fh, Bitmap.Config.ARGB_8888)
            WidgetRenderer.drawSkyFrame(ctx, Canvas(b), look, snap, snap.nowMs, fEnd * e, sc)
            frames.add(b)
        }
        val layouts = HashMap<Int, Int>()
        for (id in ids) {
            try {
                layouts[id] = layoutOf(ctx, mgr, id, 6)
                mgr.updateAppWidget(id, build(ctx, mgr, id, look, snap, frames))
            } catch (_: Throwable) { layouts.remove(id) }
        }
        for (i in 1 until n) {
            try { Thread.sleep(ANIM_STEP_MS) } catch (_: InterruptedException) {}
            for ((id, lay) in layouts) {
                try {
                    val part = RemoteViews(ctx.packageName, lay)
                    part.setDisplayedChild(R.id.anim, i)
                    mgr.partiallyUpdateAppWidget(id, part)
                } catch (_: Throwable) {}
            }
        }
        try { Thread.sleep(120) } catch (_: InterruptedException) {}
        updateAll(ctx)    // স্বাভাবিক চূড়ান্ত ছবি: আইকন একই জায়গায়, ফ্রেমগুলো বাদ
    }

    private fun build(ctx: Context, mgr: AppWidgetManager, id: Int, look: Look, snap: Snapshot, frames: List<Bitmap>? = null): RemoteViews {
        val d = look.design
        // বিটম্যাপ সবসময় ডিজাইনের নিজস্ব অনুপাতে (কার্ড + চারপাশে PAD) — তাই কখনো চ্যাপ্টা/টানা হয় না।
        val regionW = WidgetRenderer.cardW(d) + 2 * WidgetRenderer.PAD
        val regionH = WidgetRenderer.cardH(d, WidgetRenderer.isCompact(d, snap)) + 2 * WidgetRenderer.PAD
        val k = BITMAP_W / regionW
        val bw = (regionW * k).roundToInt(); val bh = (regionH * k).roundToInt()
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val ov = WidgetRenderer.draw(ctx, cv, bw.toFloat(), bh.toFloat(), look, snap, false, snap.nowMs, frames != null)

        val (wv, hv) = sizePx(ctx, mgr, id)
        val heightLimited = wv / hv >= regionW / regionH
        val rv = RemoteViews(ctx.packageName, (if (heightLimited) LAYOUT_H else LAYOUT_W)[d])
        rv.setImageViewBitmap(R.id.bg, bmp)
        if (d == 6) {
            rv.removeAllViews(R.id.anim)
            if (frames != null) {
                for (fb in frames) {
                    val fr = RemoteViews(ctx.packageName, R.layout.anim_frame)
                    fr.setImageViewBitmap(R.id.frame, fb)
                    rv.addView(R.id.anim, fr)
                }
                rv.setDisplayedChild(R.id.anim, 0)
                rv.setViewVisibility(R.id.anim, android.view.View.VISIBLE)
            } else rv.setViewVisibility(R.id.anim, android.view.View.GONE)
        }

        // সেকেন্ডের লাইভ ঘড়ি (ডিজাইন ১ ও ৫: "ss", ডিজাইন ৩: ":ss")
        val sec = if (d == 3) ov.s3 else ov.ss
        if (sec != null) rv.setTextColor(R.id.tc_ss, sec.color)

        if ((d in 1..9) && ov.chrono == null) rv.setViewVisibility(R.id.ch_main, android.view.View.GONE)   // "–" অবস্থায় টাইমার নেই
        if (ov.chrono != null) {
            if (d in 1..9) rv.setViewVisibility(R.id.ch_main, android.view.View.VISIBLE)
            rv.setTextColor(R.id.ch_main, ov.chrono!!.color)
            val elapsedNow = SystemClock.elapsedRealtime()
            val countDown = look.design >= 3 || !snap.running || (d <= 2 && snap.forbid == 1)
            val base: Long
            val secs: Long
            if (countDown) {
                val remain = (if ((d in 1..9) && snap.forbid == 1) snap.forbidEndMs else snap.periodEndMs) - snap.nowMs
                base = elapsedNow + remain
                secs = remain / 1000
            } else {
                val el = snap.nowMs - snap.periodStartMs
                base = elapsedNow - el
                secs = el / 1000
            }
            // হাবের প্রিভিউর মতো সবসময় "00:20:59" ফরম্যাট (Chronometer নিজে ঘণ্টা না থাকলে "20:59" দেখায়)
            val fmt = when {
                abs(secs) < 3600 -> "00:%s"
                abs(secs) < 36000 -> "0%s"
                else -> "%s"
            }
            rv.setChronometerCountDown(R.id.ch_main, countDown)
            rv.setChronometer(R.id.ch_main, base, fmt, true)
        }

        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, open)
        return rv
    }

    fun schedule(ctx: Context, atMs: Long) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = tickIntent(ctx)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        } catch (_: SecurityException) {
            // এক্সাক্ট-অ্যালার্ম অনুমতি বাতিল হলে: ইনএক্সাক্টে ফলব্যাক
            try {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, tickIntent(ctx))
            } catch (_: Throwable) {}
        }
    }

    fun cancel(ctx: Context) {
        try {
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(ctx))
        } catch (_: Throwable) {}
    }

    private fun tickIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, PrayerWidgetProvider::class.java).setAction(ACTION_TICK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
