package com.gunjoron.patheyo.widgethub.widget.designs

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import com.gunjoron.patheyo.widgethub.widget.WidgetRenderer.cardW
import com.gunjoron.patheyo.widgethub.widget.assets.Fonts
import com.gunjoron.patheyo.widgethub.widget.render.*
import com.gunjoron.patheyo.widgethub.widget.theme.Look
import com.gunjoron.patheyo.widgethub.widget.theme.Palettes
import java.util.Calendar

/** ডিজাইন ৭ (এডিটোরিয়াল): বক্সহীন, চিকন রেখায় ভাগ করা হেডার · বড় ঘড়ি · আইকন-সারি · পাঁচ ওয়াক্ত। */
internal object EditorialDesign {
    /** ডিজাইন ৭ (এডিটোরিয়াল): বক্স ছাড়া — চিকন রেখা দিয়ে ভাগ করা হেডার · বড় ঘড়ি · তিন আইকন-সারি · পাঁচ ওয়াক্ত (শুধু চলমানটা হাইলাইট) */
    fun draw(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(7)
        val L = 40f; val R = cw - 40f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val hair = (m.primary and 0xFFFFFF) or 0x38000000
        fun hline(x0: Float, x1: Float, y: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x0, y - 0.75f, x1, y + 0.75f, p) }
        fun vline(x: Float, y0: Float, y1: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x - 0.75f, y0, x + 0.75f, y1, p) }

        // হেডার: লোগো · হিজরি · ইংরেজি | বাংলা · ডানে কোণায় বার
        logoRing(ctx, c, p, m, L + 35f, 62f, 35f)
        val hx = L + 70f + 22f
        val hijri = if (snap.gregFirst) snap.gregorianLine else snap.hijriLine
        val wd = weekday(nowMs)
        val wdW = measure(p, wd, Fonts.bold, 42f)
        text(c, p, wd, R, 82f, 42f, m.accent, Fonts.bold, Paint.Align.RIGHT)
        vline(R - wdW - 22f, 36f, 96f)
        val avail = R - wdW - 44f - hx
        val hSz = fit(p, hijri, Fonts.bold, 44f, avail)
        text(c, p, hijri, hx, 62f, hSz, m.primary, Fonts.bold)
        val g1 = if (snap.gregFirst) snap.hijriLine else snap.gregorianLine; val g2 = snap.banglaLine
        var ds = 33f
        val tw = measure(p, g1, Fonts.regular, ds) + 34f + measure(p, g2, Fonts.regular, ds)
        if (tw > avail) ds *= avail / tw
        val w1 = measure(p, g1, Fonts.regular, ds)
        text(c, p, g1, hx, 100f, ds, m.secondary, Fonts.regular)
        vline(hx + w1 + 17f, 76f, 104f)
        text(c, p, g2, hx + w1 + 34f, 100f, ds, m.secondary, Fonts.regular)
        hline(L, R, 124f)

        // বড় ঘড়ি: ঘড়ি · লাইভ সেকেন্ড + (একই লাইনে) AM/PM · প্রগ্রেস · ওয়াক্ত + বাকি সময় (লাইভ)
        val ty0 = 136f; val tr = 516f
        val clockSize = 372f / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        slimClock(c, p, hmOf(nowMs), L, 282f, clockSize, m.primary)
        // মিনিটের পাশে ছোট লাইভ সেকেন্ড (আসল ঘড়ি লঞ্চারের TextClock) + তার ডানে একই বেসলাইনে AM/PM
        if (live) text(c, p, pad2a(Calendar.getInstance().also { it.timeInMillis = nowMs }.get(Calendar.SECOND)), L + 364f, 282f, 50f, m.accent, Fonts.outfit)
        else ov.ss = TextSpec(0f, 0f, 0f, m.accent)
        text(c, p, if (snap.isPm) "PM" else "AM", L + 436f, 282f, 32f, m.secondary, Fonts.outfit)

        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f7 = snap.forbid     // ০ স্বাভাবিক · ১ নিষিদ্ধ সময় · ২ সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত ("–")
        val f7Frac = when (f7) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        barK(c, p, L + 6f, tr - 8f, 328f, 8f, f7Frac, m.track, if (f7 == 1) warn else m.accent)
        when (f7) {
            2 -> {
                text(c, p, "–", L + 4f, 390f, 46f, m.secondary, Fonts.bold)
                text(c, p, "–", tr - 8f, 390f, 40f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", L + 4f, 390f, 40f, warn, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 435f, 390f, 38f, 35f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, L + 4f, 390f, 42f, m.accent, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 435f, 390f, 38f, 35f, m.primary, m.primary)
            }
        }

        // তিন আইকন-সারি (চিকন রেখায় আলাদা)
        val labels = arrayOf(snap.sunLabel, "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunTime, snap.sehri, snap.iftar)
        val tx0 = 562f; val rh = 90f
        vline(tx0 - 26f, ty0 + 6f, ty0 + rh * 3 - 6f)
        for (i in 0 until 3) {
            val y0 = ty0 + rh * i
            if (i > 0) hline(tx0, R, y0)
            medal(c, p, art, i, tx0 + 31f, y0 + rh / 2f, 62f)
            text(c, p, labels[i], tx0 + 84f, y0 + rh / 2f + 12f, 33f, m.secondary, Fonts.regular)
            text(c, p, times[i], R, y0 + rh / 2f + 16f, 46f, m.primary, Fonts.bold, Paint.Align.RIGHT)
        }
        hline(L, R, 424f)

        // পাঁচ ওয়াক্ত: শুধু চলমানটা হালকা রঙের পিলে
        val sy0 = 434f; val sy1 = 540f
        val colW = (R - L) / 5f
        for (i in 0 until 5) {
            val cc = L + colW * (i + 0.5f)
            val on = f7 == 0 && snap.current == i
            if (on) tile(c, p, cc - colW / 2f + 6f, sy0, cc + colW / 2f - 6f, sy1, 30f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x66000000)
            text(c, p, snap.prayerNames[i], cc, 476f, 32f, if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cc, 522f, 42f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }
}
