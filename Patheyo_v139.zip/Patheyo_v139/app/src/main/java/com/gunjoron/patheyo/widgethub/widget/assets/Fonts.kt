package com.gunjoron.patheyo.widgethub.widget.assets

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.gunjoron.patheyo.R

/** ফন্ট একবারই লোড হয় (static TTF — ভেরিয়েবল ফন্ট নয়, তাই পুরনো ফোনেও উইজেট ভাঙে না)। */
object Fonts {
    @Volatile private var ready = false
    lateinit var regular: Typeface; private set   // গুঞ্জরণ রেগুলার
    lateinit var bold: Typeface; private set      // গুঞ্জরণ বোল্ড
    lateinit var bebas: Typeface; private set     // ডিজিটাল সংখ্যা
    lateinit var clockBold: Typeface; private set // ডিজাইন ৩-এর বড় ঘড়ি (EB Garamond Bold)
    lateinit var clockReg: Typeface; private set  // AM/PM ও সেকেন্ড (EB Garamond Regular)
    lateinit var outfit: Typeface; private set    // ডিজাইন ৪/৫-এর পাতলা আধুনিক ঘড়ি (Outfit Light)

    private fun font(ctx: Context, id: Int, fallback: Typeface): Typeface =
        try { ResourcesCompat.getFont(ctx, id) ?: fallback } catch (_: Throwable) { fallback }

    fun init(ctx: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            val c = ctx.applicationContext
            regular = font(c, R.font.gunjoron_regular, Typeface.DEFAULT)
            bold = font(c, R.font.gunjoron_bold, Typeface.DEFAULT_BOLD)
            bebas = font(c, R.font.bebas_neue, Typeface.DEFAULT_BOLD)
            clockBold = font(c, R.font.ebgaramond_bold, Typeface.DEFAULT_BOLD)
            clockReg = font(c, R.font.ebgaramond_regular, Typeface.DEFAULT)
            outfit = font(c, R.font.outfit_light, Typeface.DEFAULT)
            ready = true
        }
    }
}
