package com.gunjoron.patheyo

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import androidx.core.view.WindowCompat

/**
 * v139: স্ট্যাটাস বার (সময়/নেটওয়ার্ক/ব্যাটারি) ও নেভিগেশন বারের আইকনের রং এখন সিস্টেমের থিম নয়,
 * অ্যাপের স্ক্রিনে এই মুহূর্তে যে থিম (লাইট/ডার্ক/সেপিয়া) দেখা যাচ্ছে সেটা অনুযায়ী ঠিক হয়।
 *  - লাইট/সেপিয়া স্ক্রিন → গাঢ় আইকন
 *  - ডার্ক স্ক্রিন      → সাদা আইকন
 * JS (shell/js/05-pages-controller.js) থেকে PatheyoSystemBars.setLightTheme(true/false) দিয়ে ডাকা হয়।
 * শেষ মানটা সেভ থাকে, তাই পরের বার অ্যাপ খুললে প্রথম ফ্রেম থেকেই সঠিক রং থাকে।
 */
class SystemBarsBridge(private val activity: Activity) {

    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun setLightTheme(light: Boolean) {
        try { activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LIGHT, light).apply() } catch (_: Throwable) { }
        main.post { apply(activity, light) }
    }

    companion object {
        private const val PREFS = "patheyo_system_bars"
        private const val KEY_LIGHT = "light_theme"

        /** অ্যাপ চালুর সময় (onCreate) শেষ জানা থিম অনুযায়ী আইকনের রং বসানো */
        fun applySaved(activity: Activity) {
            try {
                val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                if (prefs.contains(KEY_LIGHT)) apply(activity, prefs.getBoolean(KEY_LIGHT, false))
            } catch (_: Throwable) { }
        }

        private fun apply(activity: Activity, light: Boolean) {
            try {
                if (activity.isFinishing || activity.isDestroyed) return
                val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                c.isAppearanceLightStatusBars = light       // true = গাঢ় আইকন (হালকা ব্যাকগ্রাউন্ডের জন্য)
                c.isAppearanceLightNavigationBars = light
            } catch (_: Throwable) { }
        }
    }
}
