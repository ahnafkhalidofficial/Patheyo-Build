package com.gunjoron.patheyo.widgethub.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** হাবের সব সেটিং (থিম, ডিজাইন, কাস্টম রঙ ইত্যাদি) — SharedPreferences-এ সেভ। */
class Prefs private constructor(private val sp: SharedPreferences) {

    var theme: String                       // glass | nobg | light | custom
        get() = sp.getString("theme", "glass") ?: "glass"
        set(v) = sp.edit().putString("theme", v).apply()

    var nobgMode: String                    // dark | light
        get() = sp.getString("nobgMode", "dark") ?: "dark"
        set(v) = sp.edit().putString("nobgMode", v).apply()

    var design: Int
        get() = sp.getInt("design", 1).coerceIn(1, 9)
        set(v) = sp.edit().putInt("design", v).apply()

    /** হোম স্ক্রিনে যে ডিজাইনের উইজেট সেট করা (সবুজ টিক); আলাদা সেট না থাকলে ডিফল্ট ক্লাসিক (১) — কার্ড বাছাইয়ের সাথে বদলায় না */
    var widgetDesign: Int
        get() = sp.getInt("wdesign", 1).coerceIn(1, 9)
        set(v) = sp.edit().putInt("wdesign", v.coerceIn(1, 9)).apply()

    var customBg: Int                       // 0xRRGGBB
        get() = sp.getInt("customBg", 0x1E293B)
        set(v) = sp.edit().putInt("customBg", v and 0xFFFFFF).apply()

    var customOpacity: Int                  // ১০–১০০
        get() = sp.getInt("customOpacity", 90).coerceIn(10, 100)
        set(v) = sp.edit().putInt("customOpacity", v.coerceIn(10, 100)).apply()

    var customTone: String                  // auto | dark | light
        get() = sp.getString("customTone", "auto") ?: "auto"
        set(v) = sp.edit().putString("customTone", v).apply()

    /** ইংরেজি তারিখ আগে: যে ডিজাইনে হিজরি তারিখ প্রথমে (বড়/বোল্ড), সেখানে ইংরেজি ও হিজরির জায়গা বদল। ডিফল্ট বন্ধ। */
    var gregFirst: Boolean
        get() = sp.getBoolean("gregFirst", false)
        set(v) = sp.edit().putBoolean("gregFirst", v).apply()

    /** কাস্টম থিমে লেখা/আইকন হালকা (= গাঢ় লেখা) হবে কি না — হাবের wcIsLightTone()-এর হুবহু সূত্র। */
    fun customIsLightTone(): Boolean = when (customTone) {
        "light" -> true
        "dark" -> false
        else -> {
            val c = customBg
            (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 > 0.6
        }
    }

    companion object {
        @Volatile private var inst: Prefs? = null
        fun get(ctx: Context): Prefs = inst ?: synchronized(this) {
            inst ?: Prefs(ctx.applicationContext.getSharedPreferences("patheyo_widget_hub", Context.MODE_PRIVATE)).also { inst = it }
        }
    }
}
