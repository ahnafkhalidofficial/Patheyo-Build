package com.gunjoron.patheyo.widgethub.widget.assets

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.widgethub.widget.theme.Variant

/** স্ট্যাটিক আর্ট-লেয়ার (লোগো, আইকন, পিল, ঘড়ির টাইল) — আপনার শিট থেকে হুবহু এক্সপোর্ট করা। */
object Art {
    private val cache = LruCache<Int, Bitmap>(4)

    private fun resId(d: Int, v: Variant): Int = when (d) {
        1 -> when (v) {
            Variant.GLASS -> R.drawable.art_d1_glass; Variant.LIGHT -> R.drawable.art_d1_light
            Variant.NOBG_DARK -> R.drawable.art_d1_nobg_dark; Variant.NOBG_LIGHT -> R.drawable.art_d1_nobg_light
        }
        2 -> when (v) {
            Variant.GLASS -> R.drawable.art_d2_glass; Variant.LIGHT -> R.drawable.art_d2_light
            Variant.NOBG_DARK -> R.drawable.art_d2_nobg_dark; Variant.NOBG_LIGHT -> R.drawable.art_d2_nobg_light
        }
        else -> 0   // ডিজাইন ৩-এ আর্ট নেই — সবকিছু কোডে আঁকা
    }

    @Synchronized
    fun get(ctx: Context, d: Int, v: Variant): Bitmap {
        val id = resId(d, v)
        cache.get(id)?.let { return it }
        val o = BitmapFactory.Options().apply { inScaled = false; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val b = BitmapFactory.decodeResource(ctx.applicationContext.resources, id, o)
        cache.put(id, b)
        return b
    }

    private val sunsetCache = LruCache<Int, Bitmap>(2)

    /**
     * "সূর্যাস্ত" আইকন: সূর্যোদয়ের আইকনের হুবহু কপি, শুধু ভেতরের তীরটা উল্টে নিচের দিকে (ওপরের তীর → নিচের তীর)।
     * তীরের এলাকা (x 865–893, y 60–89, ডিজাইন ১/২-এর আর্ট ও ডিজাইন ৭/৮/৯-এর আইকন-মেডালিয়ন দুটোতেই একই জায়গা) ওপর-নিচ আয়না করা হয়।
     */
    @Synchronized
    fun sunsetArt(ctx: Context, d: Int, v: Variant): Bitmap {
        val id = resId(d, v)
        sunsetCache.get(id)?.let { return it }
        val src = get(ctx, d, v)
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val x0 = 865; val y0 = 60; val w = 29; val h = 30
        val px = IntArray(w * h); src.getPixels(px, 0, w, x0, y0, w, h)
        val fl = IntArray(w * h)
        for (r in 0 until h) System.arraycopy(px, r * w, fl, (h - 1 - r) * w, w)
        out.setPixels(fl, 0, w, x0, y0, w, h)
        sunsetCache.put(id, out)
        return out
    }

    private val pathCache = HashMap<Boolean, Bitmap>()

    /** লোগোর সাদা পাথ (স্বচ্ছ ব্যাকগ্রাউন্ডে): light = true হলে সাদা, নয়তো গাঢ়। ডিজাইন ৬-এর লোগো-বৃত্তে বসে। */
    @Synchronized
    fun logoPath(ctx: Context, light: Boolean): Bitmap {
        pathCache[light]?.let { return it }
        val o = BitmapFactory.Options().apply { inScaled = false; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val b = BitmapFactory.decodeResource(ctx.applicationContext.resources,
            if (light) R.drawable.logo_path_w else R.drawable.logo_path_d, o)
        pathCache[light] = b
        return b
    }
}
