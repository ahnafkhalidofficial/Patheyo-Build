package com.gunjoron.patheyo.widgethub.widget.designs

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import com.gunjoron.patheyo.widgethub.widget.WidgetRenderer.cardW
import com.gunjoron.patheyo.widgethub.widget.assets.Fonts
import com.gunjoron.patheyo.widgethub.widget.render.*
import com.gunjoron.patheyo.widgethub.widget.theme.Look
import com.gunjoron.patheyo.widgethub.widget.theme.Palettes
import java.util.Calendar

/** ডিজাইন ৯ (ডায়াল): বাঁয়ে গোল ডায়াল ও প্রগ্রেস-রিং, ডানে তারিখ ও ওয়াক্ত। */
internal object DialDesign {
    /** ডিজাইন ৯ (ডায়াল): বাঁয়ে গোল ডায়াল — ভেতরে লোগো, ঘড়ি, AM/PM+সেকেন্ড, চলমান ওয়াক্ত ও বাকি সময়; ডায়ালের কিনারায় ওয়াক্তের প্রগ্রেস-রিং। ডানে তারিখ, সূর্যোদয়-সেহরি-ইফতার ও পাঁচ ওয়াক্ত। */
    fun draw(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val R = cardW(9) - 44f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f9 = snap.forbid
        val hair = (m.primary and 0xFFFFFF) or 0x38000000
        fun hline(x0: Float, x1: Float, y: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x0, y - 0.75f, x1, y + 0.75f, p) }
        fun vline(x: Float, y0: Float, y1: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x - 0.75f, y0, x + 0.75f, y1, p) }

        // ---------- বাঁয়ে ডায়াল ----------
        val dcx = 250f; val dcy = 270f; val dR = 210f; val ringR = 195f
        p.style = Paint.Style.FILL; p.shader = null; p.color = (m.primary and 0xFFFFFF) or 0x0F000000
        c.drawCircle(dcx, dcy, dR, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = hair
        c.drawCircle(dcx, dcy, dR, p)
        // প্রগ্রেস-রিং: ট্র্যাক + চলমান ওয়াক্তের অংশ (নিষিদ্ধ সময়ে লাল-কমলা; "–" সময়ে খালি)
        p.strokeWidth = 12f; p.color = m.track
        c.drawCircle(dcx, dcy, ringR, p)
        val rf = when (f9) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        val ringCol = if (f9 == 1) warn else m.accent
        if (rf > 0.002f) {
            val steps = (rf * 240f).toInt().coerceAtLeast(2)
            val path = Path()
            for (i in 0..steps) {
                val a = Math.toRadians(-90.0 + 360.0 * rf * i / steps)
                val x = dcx + ringR * Math.cos(a).toFloat(); val y = dcy + ringR * Math.sin(a).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 12f; p.color = ringCol
            c.drawPath(path, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        if (f9 != 2) {
            val a = Math.toRadians(-90.0 + 360.0 * rf)
            val kx = dcx + ringR * Math.cos(a).toFloat(); val ky = dcy + ringR * Math.sin(a).toFloat()
            p.style = Paint.Style.FILL; p.color = ringCol; c.drawCircle(kx, ky, 15f, p)
            p.color = m.primary; c.drawCircle(kx, ky, 6.5f, p)
        }
        p.style = Paint.Style.FILL

        logoRing(ctx, c, p, m, dcx, 138f, 28f)
        val hm = hmOf(nowMs)
        val clockSize = 296f / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        val cwid = measure(p, hm.substring(0, 2), Fonts.outfit, clockSize) + measure(p, ":", Fonts.outfit, clockSize) + measure(p, hm.substring(3), Fonts.outfit, clockSize)
        slimClock(c, p, hm, dcx - cwid / 2f, 270f, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", dcx - 8f, 324f, 34f, m.accent, Fonts.outfit, Paint.Align.RIGHT)
        if (live) text(c, p, pad2a(Calendar.getInstance().also { it.timeInMillis = nowMs }.get(Calendar.SECOND)), dcx + 10f, 324f, 34f, m.primary, Fonts.outfit)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)
        when (f9) {
            2 -> {
                text(c, p, "–", dcx, 392f, 46f, m.secondary, Fonts.bold, Paint.Align.CENTER)
                text(c, p, "–", dcx, 436f, 38f, m.secondary, Fonts.bold, Paint.Align.CENTER)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", dcx, 390f, 40f, warn, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 270f, 432f, 32f, 30f, m.primary, m.secondary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, dcx, 390f, 42f, m.accent, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 270f, 432f, 32f, 30f, m.primary, m.secondary)
            }
        }

        // ---------- ডানে ----------
        val X0 = 520f
        p.style = Paint.Style.FILL; p.color = (m.accent and 0xFFFFFF) or 0xCC000000.toInt()
        c.drawRect(X0 - 18f, 56f, X0 - 14.5f, 218f, p)
        text(c, p, weekday(nowMs), X0, 84f, 30f, m.accent, Fonts.bold)
        val lines = if (snap.gregFirst) arrayOf(snap.gregorianLine, snap.hijriLine, snap.banglaLine) else arrayOf(snap.hijriLine, snap.gregorianLine, snap.banglaLine)
        val s0 = fit(p, lines[0], Fonts.bold, 46f, R - X0)
        text(c, p, lines[0], X0, 134f, s0, m.primary, Fonts.bold)
        text(c, p, lines[1], X0, 176f, fit(p, lines[1], Fonts.bold, 34f, R - X0), m.secondary, Fonts.bold)
        text(c, p, lines[2], X0, 214f, fit(p, lines[2], Fonts.bold, 34f, R - X0), m.secondary, Fonts.bold)
        hline(X0 - 18f, R, 240f)

        val labels = arrayOf(snap.sunLabel, "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunTime, snap.sehri, snap.iftar)
        val c3 = (R - (X0 - 18f)) / 3f
        for (i in 0 until 3) {
            val cx = X0 - 18f + c3 * (i + 0.5f)
            medal(c, p, art, i, cx, 296f, 60f)
            text(c, p, labels[i], cx, 358f, 27f, m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, times[i], cx, 402f, 38f, m.primary, Fonts.bold, Paint.Align.CENTER)
            if (i > 0) vline(X0 - 18f + c3 * i, 268f, 408f)
        }
        hline(X0 - 18f, R, 428f)

        val px0 = X0 - 32f
        val colW = (R - px0) / 5f
        for (i in 0 until 5) {
            val cc = px0 + colW * (i + 0.5f)
            val on = f9 == 0 && snap.current == i
            if (on) tile(c, p, cc - colW / 2f + 3f, 440f, cc + colW / 2f - 3f, 520f, 22f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x66000000)
            val nm = snap.prayerNames[i]; val tm = snap.prayerTimes[i]
            text(c, p, nm, cc, 474f, fit(p, nm, Fonts.regular, 27f, colW - 8f), if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, tm, cc, 508f, fit(p, tm, Fonts.bold, 32f, colW - 8f), if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }
}
