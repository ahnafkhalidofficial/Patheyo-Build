
/* ===== js/features/book-view.js ===== */
/*!
 * js/features/book-view.js -- Book screen: head, download gate / chapter list, opening a hadith directly
 *
 * Provides : App.openBook, App.enterBook, App.closeBook, App.openHadith, App.bookBodyVisible, App.renderChapterList,
 *            App.showBookMode, App.pendingJump
 * Needs    : core/dom, core/books, core/state, core/utils, services/book-download, services/book-store,
 *            features/chapter-reader, features/download-ui, features/feedback, features/navigation, features/search
 */
(function (App) {
  "use strict";

  App.pendingJump = null;   // set when a hadith was requested but the book still has to be downloaded first

  var BOOK_ICON = '<svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>';

  function bookBodyVisible(){ return !App.els.bookBody.classList.contains('hidden'); }
  App.bookBodyVisible = bookBodyVisible;

  // হেডার-কার্ডের পরিসংখ্যান-স্ট্রিপ: [[সংখ্যা, লেবেল], ...]
  App.heroStatsHtml = function(items){
    return '<div class="rm-strip n' + items.length + '">' + items.map(function(it){
      return '<div class="rm-stat"><span class="rm-v">' + App.bn(it[0]) + '</span><span class="rm-l">' + it[1] + '</span></div>';
    }).join('') + '</div>';
  };

  function fillHead(b){
    var idx = App.bookIndex(b.id);
    App.els.bookBadge.textContent = 'কিতাব ' + App.bn(idx + 1);
    App.els.bookArabicName.innerHTML = App.bookGlyph(b.id, 'sg-header');
    App.els.bookNameCaption.innerHTML = '<span class="rn-en">' + App.escapeHtml(b.nameEn) + '</span><span class="rn-dot">·</span>' + App.escapeHtml(b.nameBn);
    App.els.bookMeta.innerHTML = App.heroStatsHtml([[b.count, 'হাদীস'], [b.chapters, 'অধ্যায়']]);
    App.els.bookMeta.setAttribute('aria-label', 'হাদীস সংখ্যা: ' + App.bn(b.count) + ' · অধ্যায়: ' + App.bn(b.chapters));
  }

  // mode: 'loading' | 'gate' | 'body'
  function showBookMode(mode){
    App.els.bookLoading.classList.toggle('hidden', mode !== 'loading');
    App.els.bookGate.classList.toggle('hidden', mode !== 'gate');
    App.els.bookBody.classList.toggle('hidden', mode !== 'body');
    document.getElementById('book-panel').classList.toggle('dl-mode', mode === 'gate');   // ডাউনলোড কার্ডের সময় হেডার ছোট
    App.updateSearchUi();
  }
  App.showBookMode = showBookMode;

  function resetBookSearch(){
    App.els.searchInput.value = '';
    App.els.searchClear.classList.remove('show');
    App.cancelBookSearch();
    App.els.chapterList.classList.remove('hidden');
    App.els.bookResults.classList.add('hidden');
    App.els.bookResults.innerHTML = '';
    App.els.bookEmpty.classList.add('hidden');
  }

  // ---------------------------------------------------------------- chapter list
  function renderChapterList(book){
    var frag = document.createDocumentFragment();
    book.data.ch.forEach(function(ch, c){
      var count = 0;
      ch.s.forEach(function(s){ count += s.h.length; });
      var row = document.createElement('div');
      row.className = 'list-item ch-row';
      row.setAttribute('data-ch', c);
      row.innerHTML =
        '<div class="ch-no">' + (ch.n != null ? App.bn(ch.n) : BOOK_ICON) + '</div>' +
        '<div class="ch-main">' +
          '<div class="ch-title">' + App.escapeHtml(ch.t || ('অধ্যায় ' + App.bn(c + 1))) + '</div>' +
          '<div class="ch-count"><svg class="ch-count-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5"/><path d="M9 13h7M9 17h5"/></svg>' + App.bn(count) + ' হাদীস</div>' +
        '</div>' +
        '<span class="ch-go"><svg class="icon icon-sm li-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg></span>';
      row.addEventListener('click', function(){ App.openChapter(c, { origin:'book' }); });
      frag.appendChild(row);
    });
    App.els.chapterList.innerHTML = '';
    App.els.chapterList.appendChild(frag);
  }
  App.renderChapterList = renderChapterList;

  // ---------------------------------------------------------------- opening a book
  function openBook(id, jump){
    var b = App.bookById(id);
    if (!b) return;
    if (App.state.view === 'list'){ App.returnTab = App.state.tab; App.state.listScroll = window.pageYOffset; }
    App.curBookId = id;
    App.pendingJump = jump || null;
    App.els.booksPanel.classList.add('hidden');
    App.els.bookmarksPanel.classList.add('hidden');
    App.els.continueCard.classList.add('hidden');
    App.els.chapterPanel.classList.add('hidden');
    App.els.bookPanel.classList.remove('hidden');
    window.scrollTo(0, 0);
    resetBookSearch();
    fillHead(b);
    App.pushHistory('book');
    enterBook(id);
  }
  App.openBook = openBook;

  // Decides what the book screen shows: the download card, or (once the book is on the phone) its chapters.
  function enterBook(id){
    var b = App.bookById(id);
    if (!b || App.curBookId !== id) return;
    if (!App.bookDl.isReady(id)){
      showBookMode('gate');
      App.syncDownloadCard();
      return;
    }
    showBookMode('loading');
    App.loadBook(id).then(function(book){
      if (App.curBookId !== id) return;
      renderChapterList(book);
      var jump = App.pendingJump; App.pendingJump = null;
      if (App.state.view === 'book'){
        showBookMode('body');
        if (jump){ var loc = resolveJump(book, jump); App.openChapter(loc.c, { origin:'book', seq: loc.seq, bookmarkId: jump.bookmarkId }); }
      } else {
        // the user already moved on (e.g. opened a chapter); keep the body ready for when they come back
        App.els.bookBody.classList.remove('hidden');
        App.els.bookLoading.classList.add('hidden'); App.els.bookGate.classList.add('hidden');
      }
    }).catch(function(){
      if (App.curBookId !== id) return;
      // file unreadable / damaged -> delete it so the user can download it again
      App.bookDl.discard(id);
      App.bookDl.fail(id, 'corrupt');
      showBookMode('gate');
      App.syncDownloadCard();
    });
  }
  App.enterBook = enterBook;

  function closeBook(){
    App.els.bookPanel.classList.add('hidden');
    App.pendingJump = null;
    App.switchTab(App.returnTab);
    var y = App.state.listScroll || 0;
    requestAnimationFrame(function(){ window.scrollTo(0, y); });
  }
  App.closeBook = closeBook;

  // ---------------------------------------------------------------- jump straight to one hadith
  // (used by "পড়া চালিয়ে যান" and by the bookmarks list)
  function resolveJump(book, jump){
    var seq = jump.seq;
    var hit = (seq != null) ? App.hadithAtSeq(book, seq) : null;
    if (hit && (jump.num == null || hit.h[0] === jump.num)) return { c: hit.c, seq: seq };
    if (jump.num != null){
      var s2 = App.findSeqByNumber(book, jump.num);
      if (s2 >= 0) return { c: App.chapterOfSeq(book, s2), seq: s2 };
    }
    var c = Math.min(Math.max(jump.ch || 0, 0), book.data.ch.length - 1);
    return { c: c, seq: book.chStart[c] };
  }

  function openHadith(id, jump){
    var b = App.bookById(id);
    if (!b) return;
    if (!App.bookDl.isReady(id)){ openBook(id, jump); return; }   // download first, then it opens by itself
    if (App.state.view === 'list'){ App.returnTab = App.state.tab; App.state.listScroll = window.pageYOffset; }
    App.curBookId = id;
    if (!App.loadedBook || App.loadedBook.id !== id) App.showCenterToast('কিতাব খোলা হচ্ছে…');
    App.loadBook(id).then(function(book){
      var loc = resolveJump(book, jump);
      App.els.booksPanel.classList.add('hidden');
      App.els.bookmarksPanel.classList.add('hidden');
      App.els.continueCard.classList.add('hidden');
      renderChapterList(book);       // ready for the moment the user goes "back" to the book
      fillHead(b);
      App.openChapter(loc.c, { origin:'list', seq: loc.seq, bookmarkId: jump.bookmarkId });
    }).catch(function(){
      App.bookDl.discard(id);
      App.bookDl.fail(id, 'corrupt');
      openBook(id, jump);
    });
  }
  App.openHadith = openHadith;

})(window.HadithApp = window.HadithApp || {});

