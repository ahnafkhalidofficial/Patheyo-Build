
/* ===== js/core/utils.js ===== */
/*!
 * js/core/utils.js -- Small shared helpers: Bengali digits, HTML escaping, search normalisation
 *
 * Provides : App.BN_DIGITS, App.bn, App.escapeHtml, App.normalizeSearchText, App.toEnglishDigits,
 *            App.normBn, App.normAr, App.hasArabic
 * Needs    : (nothing)
 */
(function (App) {
  "use strict";

  var BN_DIGITS = '০১২৩৪৫৬৭৮৯';
  App.BN_DIGITS = BN_DIGITS;

  function bn(n){ return String(n).replace(/\d/g, function(d){ return BN_DIGITS[d]; }); }
  App.bn = bn;

  function toEnglishDigits(s){ return String(s).replace(/[০-৯]/g, function(d){ return String(BN_DIGITS.indexOf(d)); }); }
  App.toEnglishDigits = toEnglishDigits;

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }
  App.escapeHtml = escapeHtml;

  // ওয়াকফ-চিহ্ন (ۖ ۗ ۘ ۙ ۚ ۛ ۜ) আলাদা <span class="waqf">-এ মোড়ানো -- ডার্ক মোডে হালকা-সাদা রং দেওয়ার জন্য (কুরআন অ্যাপের মতোই)
  function wrapWaqf(html){ return String(html).replace(/[\u06D6-\u06DC]/g, '<span class="waqf">$&</span>'); }
  App.wrapWaqf = wrapWaqf;

  // Strips spaces/hyphens/apostrophes so e.g. "সহীহ বুখারী" or "sahihbukhari" still matches "Sahih al-Bukhari".
  function normalizeSearchText(s){
    return String(s || '').toLowerCase().replace(/[-\s'’]/g, '');
  }
  App.normalizeSearchText = normalizeSearchText;

  // Bengali text search: unify composed / decomposed letters (য় etc.), drop joiners, ignore case
  function normBn(s){
    s = String(s || '');
    try{ s = s.normalize('NFC'); } catch(e){}
    return s.replace(/[‌‍]/g, '').toLowerCase();
  }
  App.normBn = normBn;

  // Arabic text search: ignore harakat / tatweel / small marks and unify the alef / yeh / heh variants
  function normAr(s){
    return String(s || '')
      .replace(/[ؐ-ًؚ-ٰٟۖ-ۭـ]/g, '')
      .replace(/[آأإٱ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/ة/g, 'ه');
  }
  App.normAr = normAr;

  App.hasArabic = function(s){ return /[ؠ-يٱ-ۓ]/.test(s); };

})(window.HadithApp = window.HadithApp || {});

