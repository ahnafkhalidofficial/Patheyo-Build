/* js/core/native-callbacks.js */
/* =============================================================================
   নেটিভ (Kotlin) → JS entry-point
   MainActivity যে ফাংশনগুলো কল করে: setNativeNetworkStatus, onAzanStopped, handleNativeBackPress।
   ⚠️ এই ফাইল বাকি সব ফাইলের পরে (শেষের দিকে) লোড হবে। কারণ: Kotlin এগুলো যেকোনো সময়
   কল করতে পারে (typeof চেক করে) — এমনকি পেজ লোড চলাকালেও। মূল একক স্ক্রিপ্টে সব ফাংশন
   একসাথে তৈরি হতো; এখানেও তাই এগুলো সবার শেষে রাখা হয়েছে, যাতে ফাংশনটা "আছে" বলে
   ধরা পড়ার সময় তার সব নির্ভরতাও তৈরি থাকে।
   ============================================================================= */

// Android native network status callback
window.setNativeNetworkStatus = function(isOnline) {
    const wasOffline = (nativeNetworkStatus === false) || isShowingOfflineData || !globalTimings;
    nativeNetworkStatus = isOnline;
    if (isOnline) {
        // শুধু তখনই আবার ফেচ করা হবে যদি আগে অফলাইন/ব্যর্থ অবস্থায় ছিলাম — নাহলে প্রতিটা মিনর
        // নেটওয়ার্ক কলব্যাকে (যেমন ওয়াইফাই↔মোবাইল ডেটা পরিবর্তন) অযথা বারবার ফেচ হবে না
        if (wasOffline) { fetchCorePrayerData(); } else { notifyOfflineBannerState(false); }
    } else {
        notifyOfflineBannerState(true);
    }
};

// আজান বন্ধ হলে UI-তে জানানোর receiver (MainActivity onNewIntent থেকে কল হয়)
window.onAzanStopped = function() {
    azanAudioEngine.pause();
    document.getElementById('azan-toast-overlay')?.classList.add('hidden');
    const btn = document.getElementById('stop-azan-btn');
    if (btn) btn.classList.add('hidden');
};

// JS ব্যাক নেভিগেশন হ্যান্ডেলার — Android ব্যাক বাটনে MainActivity এটা কল করে
// true = JS নিজে হ্যান্ডেল করেছে, false = অ্যাপ বের হোক
window.handleNativeBackPress = function() {
    const tabs = ['dashboard', 'quran', 'tasbih', 'widgets', 'qibla'];
    const activeTab = tabs.find(t => {
        const v = document.getElementById('view-' + t);
        return v && v.style.display !== 'none' && !v.classList.contains('hidden');
    });
    // ড্যাশবোর্ডে আছি → বেরিয়ে যাও (false)
    if (!activeTab || activeTab === 'dashboard') return false;
    // অন্য ট্যাবে আছি → ড্যাশবোর্ডে ফেরত যাও (true)
    switchTab('dashboard');
    return true;
};

