
/*!
 * js/core/utils.js -- Small shared helpers: Bengali/Arabic digits, HTML escaping, search normalisation, base64 decoding
 *
 * Provides : App.BN_DIGITS, App.ar, App.bn, App.escapeHtml, App.formatArabic, App.normalizeSearchText, App.toEnglishDigits
 * Needs    : (nothing)
 */
(function (App) {
  "use strict";

  var BN_DIGITS = '০১২৩৪৫৬৭৮৯';
  App.BN_DIGITS = BN_DIGITS;

  var AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

  function bn(n){ return String(n).replace(/\d/g, function(d){ return BN_DIGITS[d]; }); }
  App.bn = bn;

  function ar(n){ return String(n).replace(/\d/g, function(d){ return AR_DIGITS[d]; }); }
  App.ar = ar;

  function toEnglishDigits(s){ return String(s).replace(/[০-৯]/g, function(d){ return String(BN_DIGITS.indexOf(d)); }); }
  App.toEnglishDigits = toEnglishDigits;

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }
  App.escapeHtml = escapeHtml;

  // Arabic ayah text -> safe HTML. (No ruku sign is drawn any more -- the ruku marks were removed from the text and the UI.)
  // ওয়াকফ-চিহ্ন (ۖ ۗ ۘ ۙ ۚ ۛ ۜ) আলাদা <span class="waqf">-এ মোড়ানো হয়, যাতে ডার্ক মোডে আলাদা হালকা-সাদা রং পায়।
  // আয়াত পড়ার (তিলাওয়াত, ওয়েব-পেজ, তরজমা, সার্চ) সব জায়গাই এই একই ফাংশন/রেজেক্স ব্যবহার করে।
  var WAQF_RE = /[\u06D6-\u06DC]/g;
  function wrapWaqf(html){
    return String(html).replace(WAQF_RE, '<span class="waqf">$&</span>');
  }
  App.wrapWaqf = wrapWaqf;

  function formatArabic(text){
    return wrapWaqf(escapeHtml(text));
  }
  App.formatArabic = formatArabic;

  // Strips spaces/hyphens/apostrophes so e.g. "আল বাকারা" or "albaqarah" still matches
  // "আল-বাকারাহ" / "Al-Baqarah" -- makes সুরা নাম সার্চ (Bengali/Arabic/English) forgiving.
  function normalizeSearchText(s){
    return String(s || '').toLowerCase().replace(/[-\s']/g, '');
  }
  App.normalizeSearchText = normalizeSearchText;

})(window.QuranApp = window.QuranApp || {});

