
/*!
 * js/features/sura-reader.js -- Sura reader: builds the ayah flow, renders it, opens / closes the reader
 *
 * Provides : App.buildFatihaFlat, App.closeReader, App.currentOpenSuraIndex, App.openReader,
               App.renderFlatList, App.completeRender
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/surah-meta, features/bookmark-fab,
               features/bookmark-modal, features/last-read, features/navigation
 */
(function (App) {
  "use strict";

  // Al-Fatiha display: the Bismillah is shown (unnumbered, as the decorative line) and then the 7 ayahs are numbered 1-7.
  // The Taqi Usmani text already stores Al-Fatiha as exactly 7 ayahs WITHOUT the Bismillah, so they are used as they are.
  function buildFatihaFlat(){
    var f = App.quranModel[0];
    var out = [{ suraIndex:1, ayahIndex:0, text:'', isFirstOfSura:true, isOpeningBismillah:true, bismillah:null }];
    f.ayahs.forEach(function(a){
      out.push({ suraIndex:1, ayahIndex:a.index, text:a.text, isFirstOfSura:false, isOpeningBismillah:false, bismillah:null });
    });
    return out;
  }
  App.buildFatihaFlat = buildFatihaFlat;

  function buildSuraFlat(sura){
    if (sura.index === 1){ return buildFatihaFlat(); }
    return sura.ayahs.map(function(a, i){
      return { suraIndex: sura.index, ayahIndex: a.index, text: a.text, bismillah: a.bismillah, isFirstOfSura: (i===0), isOpeningBismillah:false };
    });
  }

  function makeBismillahRow(){
    var row = document.createElement('div');
    row.className = 'bismillah-row';
    row.innerHTML = '<span class="bl-line"></span>' + App.bismillahSvg() + '<span class="bl-line"></span>';
    return row;
  }

  // ---- Progressive rendering for long suras --------------------------------------------------------------------
  // Shaping the Arabic text is what costs time, not the JavaScript. So the first screenful is rendered at once (the
  // sura appears instantly) and the rest is appended to the SAME paragraph in small slices, one per animation frame.
  // Appending to one paragraph gives exactly the same line breaking as rendering it all at once (verified: identical height).
  var FIRST_CHUNK = 24, NEXT_CHUNK = 36;
  var fillJobs = [], fillRunning = false;

  function fillStep(){
    var job = fillJobs[0];
    if (!job){ fillRunning = false; return; }
    if (!job.el.isConnected){ fillJobs.shift(); requestAnimationFrame(fillStep); return; }   // reader closed / another sura opened
    var part = job.items.slice(job.pos, job.pos + NEXT_CHUNK);
    job.pos += NEXT_CHUNK;
    job.el.insertAdjacentHTML('beforeend', ' ' + part.join(' '));
    if (job.pos >= job.items.length) fillJobs.shift();
    requestAnimationFrame(fillStep);
  }
  function startFill(){ if (!fillRunning){ fillRunning = true; requestAnimationFrame(fillStep); } }

  // Finish any unfinished slices at once (needed before jumping to a bookmarked ayah / measuring positions).
  function completeRender(){
    while (fillJobs.length){
      var job = fillJobs.shift();
      if (job.el.isConnected && job.pos < job.items.length) job.el.insertAdjacentHTML('beforeend', ' ' + job.items.slice(job.pos).join(' '));
    }
  }
  App.completeRender = completeRender;

  // Renders a flat list of {suraIndex, ayahIndex, text, bismillah, isFirstOfSura, isOpeningBismillah} as
  // continuous justified paragraphs, with optional per-sura dividers (used for Para view).
  function renderFlatList(list, showDividers, container){
    container = container || App.els.verses;
    var progressive = (container === App.els.verses);        // only the sura reader renders in slices
    var frag = document.createDocumentFragment();
    var buffer = [], jobs = [];
    function flushBuffer(){
      if (buffer.length){
        var div = document.createElement('div');
        div.className = 'quran-flow';
        if (progressive && buffer.length > FIRST_CHUNK + 8){
          div.innerHTML = buffer.slice(0, FIRST_CHUNK).join(' ');
          jobs.push({ el:div, items:buffer.slice(FIRST_CHUNK), pos:0 });
        } else {
          div.innerHTML = buffer.join(' ');
        }
        frag.appendChild(div);
        buffer = [];
      }
    }
    list.forEach(function(item){
      if (item.isFirstOfSura){
        flushBuffer();
        if (showDividers){
          var div = document.createElement('div');
          div.className = 'sura-divider';
          div.innerHTML = '<div class="sd-line"></div><div class="sd-name">' + App.surahGlyph(item.suraIndex, 'sg-divider') + '</div><div class="sd-sub"><span class="rn-en">' + (App.SURAH_EN[item.suraIndex-1]||'') + '</span> · ' + (App.SURAH_BN[item.suraIndex-1]||'') + '</div>';
          frag.appendChild(div);
        }
      }
      var showBismillah = false;
      var skipContent = false;
      if (item.isOpeningBismillah){
        showBismillah = true;
        skipContent = true;
      } else if (item.bismillah){
        showBismillah = true;
      }
      if (showBismillah){
        frag.appendChild(makeBismillahRow());
      }
      if (!skipContent){
        if (item.noNumber){
          buffer.push(App.formatArabic(item.text));
        } else {
          buffer.push(App.formatArabic(item.text) + ' <span class="aya-number" id="ayah-' + item.suraIndex + '-' + item.ayahIndex + '" data-sura="' + item.suraIndex + '" data-ayah="' + item.ayahIndex + '">' + App.ar(item.ayahIndex) + '</span>');
        }
      }
    });
    flushBuffer();
    container.appendChild(frag);
    if (jobs.length){ fillJobs = fillJobs.concat(jobs); startFill(); }
  }
  App.renderFlatList = renderFlatList;

  App.currentOpenSuraIndex = 1;

  // হেডার-কার্ডের পরিসংখ্যান-স্ট্রিপ: আয়াত · রুকু · মাক্কী/মাদানী (তিলাওয়াত ও তরজমা -- দুই জায়গাতেই এক)
  App.heroStatsHtml = function(sura){
    var madani = App.isMadani(sura.index), ruku = App.SURAH_RUKU[sura.index-1] || 0;
    var place = madani ? 'মাদানী' : 'মাক্কী';
    return '<div class="rm-strip n3">' +
      '<div class="rm-stat"><span class="rm-v">' + App.bn(sura.ayahs.length) + '</span><span class="rm-l">আয়াত</span></div>' +
      '<div class="rm-stat"><span class="rm-v">' + App.bn(ruku) + '</span><span class="rm-l">রুকু</span></div>' +
      '<div class="rm-stat"><span class="rm-v rm-place ' + (madani ? 'rm-madani' : 'rm-makki') + '">' + place + '</span><span class="rm-l">অবতীর্ণ</span></div>' +
    '</div>';
  };

 // set only when the current view was opened FROM a saved bookmark
  function openReader(idx){
    var already = (App.state.view === 'sura-reader');       // সার্চ থেকে এক সূরা থেকে আরেক সূরায় গেলে নতুন history ধাপ নয়
    if (!already) App.returnTab = App.state.tab;
    App.activeBookmarkId = null; App.activeBookmarkPos = null; App.updateBmFabIcon();
    App.els.suraPanel.classList.add('hidden');
    App.els.continueCard.classList.add('hidden');
    App.els.readerPanel.classList.remove('hidden');
    App.els.verses.innerHTML = '';
    window.scrollTo(0,0);
    App.currentOpenSuraIndex = idx;

    var sura = App.quranModel[idx-1];
    App.els.readerBadge.textContent = 'সূরা ' + App.bn(idx);
    App.els.readerArabicName.innerHTML = App.surahGlyph(sura.index, 'sg-header');
    App.els.readerNameCaption.innerHTML = '<span class="rn-en">' + (App.SURAH_EN[sura.index-1]||'') + '</span><span class="rn-dot">·</span>' + (App.SURAH_BN[sura.index-1]||'');
    App.els.readerMeta.innerHTML = App.heroStatsHtml(sura);
    App.els.readerMeta.setAttribute('aria-label', 'আয়াত সংখ্যা: ' + App.bn(sura.ayahs.length));
    renderFlatList(buildSuraFlat(sura), false);
    App.saveLastRead('sura', idx, 'সূরা ' + App.bn(idx) + ' — ' + (App.SURAH_EN[sura.index-1]||''), { ayahIndex: 1 });
    if (!already) App.pushHistory('sura-reader');
  }
  App.openReader = openReader;

  function closeReader(){
    App.els.readerPanel.classList.add('hidden');
    App.switchTab(App.returnTab);
  }
  App.closeReader = closeReader;

})(window.QuranApp = window.QuranApp || {});

