
/* হোমস্ক্রিনে উইজেট যুক্ত করা / PWA ইনস্টল */
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    document.getElementById('btn-install-pwa-widget')?.classList.remove('hidden');
});

function installAppToHomeScreen() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                document.getElementById('btn-install-pwa-widget')?.classList.add('hidden');
            }
            deferredPrompt = null;
        });
    } else {
        alert('আপনার ব্রাউজার বা ডিভাইসে শর্টকাট তৈরির সুবিধাটি এখন রেডি আছে। আপনি ব্রাউজারের থ্রি-ডট (Menu) অপশনে ক্লিক করে "Add to Home Screen" বা "Install App" এ ট্যাপ করে সরাসরি ইনস্টল করতে পারেন!');
    }
}

// অ্যান্ড্রয়েড অ্যাপের WebView-তে নেটিভ "হোমস্ক্রিনে উইজেট পিন করুন" সিস্টেম প্রম্পট চালু হয়।
function oneClickMakeWidget() {
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.pinWidgetToHomeScreen === 'function') {
        try { window.AndroidWidgetBridge.pinWidgetToHomeScreen(); } catch (e) { console.error('pin widget failed', e); }
        return;
    }
    if (deferredPrompt) { installAppToHomeScreen(); return; }
    alert('এই বাটনটা শুধু অ্যাপের ভিতরে কাজ করবে — হোমস্ক্রিনে উইজেট যুক্ত করার সিস্টেম প্রম্পট অ্যান্ড্রয়েড অ্যাপ থেকেই আসে। এখন ব্রাউজারে টেস্ট মোডে আছেন।');
}

