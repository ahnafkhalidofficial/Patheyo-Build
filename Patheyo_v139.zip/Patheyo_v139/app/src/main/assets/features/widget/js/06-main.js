/* =============================================================================
   লাইভ প্রিভিউ ও ডিজাইন কার্ড
   ছবিগুলো নেটিভ রেন্ডারার (হোম স্ক্রিন উইজেটের হুবহু একই কোড) থেকে আসে।
   ============================================================================= */
function wdThemeKey() {
    if (activeWidgetTheme === 'custom') return 'custom';
    return (activeWidgetTheme === 'nobg' && activeNobgMode === 'light') ? 'nobg_light' : activeWidgetTheme;
}

function wdRefreshChips() {
    const names = { glass: 'গ্লাস (ডার্ক)', nobg: 'ট্রান্সপারেন্ট · ডার্ক', nobg_light: 'ট্রান্সপারেন্ট · লাইট', light: 'লাইট', custom: 'কাস্টম · ' + wcHex() };
    const c1 = document.getElementById('wh-chip-theme');
    if (c1) c1.textContent = names[wdThemeKey()] || '';
    const c2 = document.getElementById('wh-chip-design');
    if (c2) c2.textContent = WD_DESIGN_TITLES[wdDesign - 1] || '';
}

function wdRender(design, w) {
    const b = WD_BRIDGE();
    if (!b || typeof b.renderHubPreview !== 'function') return '';
    try { return b.renderHubPreview(design, w) || ''; } catch (e) { return ''; }
}

let _wdPrevBusy = false;
function wdRequestPreview() {
    if (_wdPrevBusy) return;
    _wdPrevBusy = true;
    requestAnimationFrame(function () {
        _wdPrevBusy = false;
        const img = document.getElementById('widget-preview-image');
        const missing = document.getElementById('widget-preview-missing');
        if (!img) return;
        const wrap = img.closest('.wh-stage') || document.body;
        const cssW = Math.max(240, (wrap.clientWidth || 360) - 20);
        const px = Math.min(760, Math.round(cssW * (window.devicePixelRatio || 2)));
        const url = wdRender(wdDesign, px);
        if (!url) { img.style.display = 'none'; if (missing) missing.classList.remove('hidden'); return; }
        img.style.display = ''; if (missing) missing.classList.add('hidden');
        img.src = url;
        img.style.width = cssW + 'px';
    });
}

// প্রতি সেকেন্ডে ঘড়ি ও কাউন্টার চলে — শুধু যখন প্রিভিউ স্ক্রিনে দেখা যায়
let _wdVisible = true, _wdTimer = null;
function wdStartTicker() {
    const img = document.getElementById('widget-preview-image');
    if (img && 'IntersectionObserver' in window) {
        new IntersectionObserver(function (es) { _wdVisible = es[0].isIntersecting; if (_wdVisible) wdRequestPreview(); }).observe(img);
    }
    (function loop() {
        const now = Date.now();
        _wdTimer = setTimeout(function () {
            if (_wdVisible && !document.hidden) wdRequestPreview();
            loop();
        }, 1000 - (now % 1000) + 5);
    })();
}

let _wdThumbT = null;
function wdScheduleThumbs() {
    clearTimeout(_wdThumbT);
    _wdThumbT = setTimeout(wdRenderThumbs, 220);
}
function wdRenderThumbs() {
    for (let n = 1; n <= 9; n++) {
        const im = document.querySelector('.wd-dsg-card[data-n="' + n + '"] img');
        if (!im) continue;
        const u = wdRender(n, 320);
        if (u) im.src = u;
    }
}

const WD_CHECK_SVG = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
function wdBuildDesignGrid() {
    const g = document.getElementById('wd-dsg-grid');
    if (!g || g.dataset.built) return;
    g.dataset.built = '1';
    for (let n = 1; n <= 9; n++) {
        const c = document.createElement('div');
        c.className = 'wd-dsg-card'; c.dataset.n = n; c.setAttribute('role', 'button');
        c.innerHTML = '<div class="wd-dsg-thumb"><img alt=""></div><div class="wd-dsg-title"></div>' +
            '<button type="button" class="wd-dsg-check" aria-label="হোম স্ক্রিনের উইজেট হিসেবে সেট করুন"><span class="ring"></span><span class="green">' + WD_CHECK_SVG + '</span></button>';
        c.querySelector('.wd-dsg-title').textContent = WD_DESIGN_TITLES[n - 1];
        c.addEventListener('click', function () { wdSelectDesign(n); });
        c.querySelector('.wd-dsg-check').addEventListener('click', function (ev) { ev.stopPropagation(); wdSetAsHomeWidget(n); });
        g.appendChild(c);
    }
}

function wdRefreshCards() {
    document.querySelectorAll('.wd-dsg-card').forEach(function (c) {
        const n = parseInt(c.dataset.n, 10);
        c.classList.toggle('sel', n === wdDesign);
        c.classList.toggle('on', n === wdWidgetDesign);
    });
}

function wdSelectDesign(n) {
    wdDesign = n;
    const b = WD_BRIDGE(); if (b && b.setHubDesign) { try { b.setHubDesign(n); } catch (e) {} }
    wdRefreshCards(); wdRefreshChips(); wdRequestPreview();
}

// গোল বাটনে চাপ: সবুজ বৃত্ত স্প্রিংয়ের মতো ফুটে ওঠে, তারপর টিক আঁকা হয়
function wdSetAsHomeWidget(n) {
    const already = (wdWidgetDesign === n);
    wdDesign = n; wdWidgetDesign = n;
    const b = WD_BRIDGE(); if (b && b.setHubWidgetDesign) { try { b.setHubWidgetDesign(n); } catch (e) {} }
    wdRefreshCards(); wdRefreshChips(); wdRequestPreview();
    const card = document.querySelector('.wd-dsg-card[data-n="' + n + '"]');
    if (!card || !card.animate) return;
    const g = card.querySelector('.green'), tick = card.querySelector('.green svg');
    if (!already) {
        g.animate([{ opacity: 0, transform: 'scale(.3)' }, { opacity: 1, transform: 'scale(1)' }], { duration: 320, easing: 'cubic-bezier(.34,2.1,.64,1)' });
        tick.animate([{ transform: 'scale(0)' }, { transform: 'scale(1)' }], { duration: 260, delay: 140, easing: 'cubic-bezier(.34,2.4,.64,1)', fill: 'backwards' });
    } else {
        g.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.18)', offset: .4 }, { transform: 'scale(1)' }], { duration: 270, easing: 'ease-out' });
    }
}
