/* স্টার্টআপ — নেটিভে সেভ থাকা সেটিং পড়ে UI সাজানো */
window.addEventListener('load', function () {
    const b = WD_BRIDGE();
    if (b && typeof b.getHubState === 'function') {
        try {
            const st = JSON.parse(b.getHubState());
            activeWidgetTheme = ['glass', 'nobg', 'light', 'custom'].indexOf(st.theme) >= 0 ? st.theme : 'glass';
            activeNobgMode = st.nobgMode === 'light' ? 'light' : 'dark';
            wdDesign = st.design || 1; wdWidgetDesign = st.widgetDesign || 1;
            wdCustomOpacity = st.customOpacity || 90;
            wdCustomTone = ['auto', 'dark', 'light'].indexOf(st.customTone) >= 0 ? st.customTone : 'auto';
            wcSetFromHex(st.customBg || '#1E293B');
            wdGregFirst = !!st.gregFirst;
        } catch (e) { console.error('hub state restore error:', e); }
    }
    const gf = document.getElementById('toggle-wd-greg-first'); if (gf) gf.checked = wdGregFirst;
    wdBuildDesignGrid();
    wdRefreshCards();
    wdPaintThemeButtons();
    wdRefreshChips();
    wdRequestPreview();
    wdRenderThumbs();
    wdStartTicker();
});
// অ্যান্ড্রয়েড ব্যাক বাটন: এখানে একটাই পেজ, তাই অ্যাপকে নিজের মতো বেরোতে দেওয়া হয়
window.handleNativeBackPress = function () { return false; };
