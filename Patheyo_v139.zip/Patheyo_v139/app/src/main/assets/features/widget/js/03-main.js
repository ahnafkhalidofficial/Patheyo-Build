
/* গ্লোবাল স্টেট — আসল মান নেটিভে (Prefs) সেভ থাকে; এখানে শুধু প্রতিচ্ছবি */
let activeWidgetTheme = 'glass';
let activeNobgMode = 'dark'; // ট্রান্সপারেন্ট থিমের মোড — 'dark' (সাদা লেখা) | 'light' (গাঢ় লেখা)
let wdCustomOpacity = 90;    // কাস্টম থিম: স্বচ্ছতা (১০–১০০%)
let wdCustomTone = 'auto';   // কাস্টম থিম: লেখা/আইকন টোন (auto|dark|light)
let wdDesign = 1;            // প্রিভিউতে দেখা ডিজাইন
let wdWidgetDesign = 1;      // হোম স্ক্রিনের উইজেটের ডিজাইন (সবুজ টিক)
let wdGregFirst = false;
let deferredPrompt = null;   // PWA ইনস্টল প্রম্পট
