
/* আইকন অ্যানিমেশন — চোখের পলক */
(function () {
    'use strict';
    var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var rnd = function (a, b) { return a + Math.random() * (b - a); };

    /* ১) মানুষের মতো চোখের পলক: একবার, দুইবার, একবার, দুইবার... (র‍্যান্ডম বিরতিতে) */
    var eye = document.querySelector('.wa-eye .eye-all');
    if (eye && eye.animate) {
        var blink = function () {
            var a = eye.animate(
                [{ transform: 'scaleY(1)' }, { transform: 'scaleY(.07)', offset: .45 }, { transform: 'scaleY(1)' }],
                { duration: 340, easing: 'ease-in-out' }
            );
            return a.finished.catch(function () {});
        };
        (async function loop() {
            var dbl = false;
            while (true) {
                await wait(rnd(2200, 5200));
                await blink();
                if (dbl) { await wait(rnd(120, 190)); await blink(); }
                dbl = !dbl;
            }
        })();
    }

})();
