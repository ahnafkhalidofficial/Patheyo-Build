/* =============================================================================
   উইজেট সেটিংস — থিম/মোড বদল, তারিখ সেটিং, নেটিভে সিঙ্ক ও রিফ্রেশ
   ============================================================================= */
function wdAfterSettingChange() {
    wdRefreshChips(); wdRequestPreview(); wdScheduleThumbs();
}

function changeNobgMode(mode) {
    activeNobgMode = (mode === 'light') ? 'light' : 'dark';
    const b = WD_BRIDGE(); if (b && b.setHubNobgMode) { try { b.setHubNobgMode(activeNobgMode); } catch (e) {} }
    refreshNobgModeButtons();
    wdAfterSettingChange();
}

function refreshNobgModeButtons() {
    const box = document.getElementById('wd-nobg-modes');
    if (box) box.classList.toggle('hidden', activeWidgetTheme !== 'nobg');
    ['dark', 'light'].forEach(m => {
        const bt = document.getElementById(`wmode-${m}`);
        if (bt) bt.classList.toggle('active', activeNobgMode === m);
    });
    refreshCustomPanel();
}

function wdPaintThemeButtons() {
    ['glass', 'nobg', 'light', 'custom'].forEach(t => {
        const btn = document.getElementById(`wtheme-${t}`);
        if (btn) btn.classList.toggle('active', t === activeWidgetTheme);
    });
    refreshNobgModeButtons();
}

function changeWidgetStyleTheme(themeKey) {
    activeWidgetTheme = themeKey;
    const b = WD_BRIDGE(); if (b && b.setHubTheme) { try { b.setHubTheme(themeKey); } catch (e) {} }
    wdPaintThemeButtons();
    if (themeKey === 'custom') syncWidgetSettingsToNativeBridge();
    wdAfterSettingChange();
}

// কাস্টম থিমের রঙ/স্বচ্ছতা/টোন নেটিভে পাঠানো
function syncWidgetSettingsToNativeBridge() {
    const b = WD_BRIDGE();
    if (b && typeof b.setHubCustom === 'function') {
        try { b.setHubCustom(wcHex(), wdCustomOpacity, wdCustomTone); } catch (e) { console.error('widget settings sync failed', e); }
    }
}

function onGregFirstChanged(checked) {
    wdGregFirst = !!checked;
    const b = WD_BRIDGE(); if (b && b.setHubGregFirst) { try { b.setHubGregFirst(wdGregFirst); } catch (e) {} }
    wdRequestPreview(); wdScheduleThumbs();
}

// "উইজেট রিফ্রেশ করুন" — হোমস্ক্রিনের উইজেট জোর করে সাথে সাথে আবার আঁকা হয় (নেটিভ টোস্টসহ)
function forceRefreshWidgetNow() {
    syncWidgetSettingsToNativeBridge();
    const b = WD_BRIDGE();
    if (b && typeof b.refreshWidgetNow === 'function') {
        try { b.refreshWidgetNow(); } catch (e) { console.error('force refresh failed', e); }
        wdRequestPreview(); wdScheduleThumbs();
    } else {
        alert('এই বাটনটা শুধু অ্যাপের ভিতরে কাজ করবে — এখন ব্রাউজারে টেস্ট মোডে আছেন।');
    }
}
