package com.gunjoron.patheyo.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.webkit.JavascriptInterface
import com.gunjoron.patheyo.alarm.AlarmScheduler
import com.gunjoron.patheyo.notification.IslamicNotification
import com.gunjoron.patheyo.notification.ScheduledNotificationScheduler
import org.json.JSONObject

/**
 * ধাপ ১১: স্মার্ট রিমাইন্ডার — প্রতিটি বিষয় আলাদা অন/অফ ("শান্ত" অ্যাপের প্রতিশ্রুতি: যেটি চান শুধু সেটিই আসবে)।
 *
 * আগে থেকেই থাকা ইসলামিক নোটিফিকেশন (assets/notifications_config.json → ScheduledNotificationScheduler) এখন দলে ভাগ:
 *   kahf     — জুমার দিন সূরা কাহফ ও দরুদ          (weekly_jumma_kahf, weekly_friday_durood) → ট্যাপে সূরা কাহফ খোলে
 *   monthu   — সোম-বৃহস্পতির রোজা (আগের রাতে)       (weekly_sunnah_fasting_mon_thu)
 *   ayyam    — আইয়ামে বিযের রোজা (আগের রাতে, রমজান/তাশরিক বাদ) (monthly_ayyam_*)
 *   zikr     — সকাল-সন্ধ্যার জিকির                   (type = daily)               → ট্যাপে সকাল-সন্ধ্যার দোয়া
 *   islamic  — ইসলামিক দিন ও মাস (আশুরা, রমজান, ঈদ, শবে কদর…) (বাকি হিজরি/সাপ্তাহিক)
 *   national — বাংলা মাস ও জাতীয় দিবস               (annual_bengali, annual_gregorian)
 * নতুন:
 *   sleep    — ঘুমের আগের দোয়া ও আমল, ব্যবহারকারীর বাছাই করা সময়ে (ডিফল্ট বন্ধ, ২২:৩০) → ট্যাপে "ঘুমের আগের আমল" ক্রমিক পপআপ (go = sleep)
 *   tasbih   — প্রতি ওয়াক্ত নামাজের পর তাসবিহ আদায়ের মনে করানো (ডিফল্ট বন্ধ; নামাজের সময়ের ৩০ মিনিট পরে, মিনিট ব্যবহারকারী বদলাতে পারেন) → ট্যাপে ডিজিটাল তাসবিহ
 *
 * JS (shell/js/15-reminders.js): PatheyoReminders.get() → JSON, PatheyoReminders.set(JSON)।
 * নোটিফিকেশনে ট্যাপ → MainActivity "go" extra → window.__ptGo('quran:18' | 'dua:sleep' | 'dua:morning')।
 */
object SmartReminders {
    private const val PREFS = "patheyo_reminders"
    private const val KEY = "smart_json"
    private const val SLEEP_REQ = 9220
    const val KIND_SLEEP = "smart:sleep"
    const val KIND_TASBIH = "smart:tasbih:"          // + fajr | dhuhr | asr | maghrib | isha
    private const val TASBIH_DEFAULT_MIN = 30
    private const val TASBIH_MIN_LIMIT = 1
    private const val TASBIH_MAX_LIMIT = 180
    private val TASBIH_WAQT = linkedMapOf(          // কী → (রিকোয়েস্ট কোড, নামাজের নাম — "-এর" যুক্ত)
        "fajr" to Pair(9231, "ফজরের"), "dhuhr" to Pair(9232, "যোহরের"), "asr" to Pair(9233, "আসরের"),
        "maghrib" to Pair(9234, "মাগরিবের"), "isha" to Pair(9235, "ইশার")
    )

    private val DEFAULTS = JSONObject()
        .put("kahf", true).put("monthu", true).put("ayyam", true).put("zikr", true)
        .put("islamic", true).put("national", true)
        .put("sleep", false).put("sleepTime", "22:30")
        .put("tasbih", false).put("tasbihMin", TASBIH_DEFAULT_MIN)

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(ctx: Context): JSONObject {
        val saved = try { JSONObject(prefs(ctx).getString(KEY, null) ?: "{}") } catch (_: Throwable) { JSONObject() }
        val out = JSONObject()
        DEFAULTS.keys().forEach { k -> out.put(k, if (saved.has(k)) saved.get(k) else DEFAULTS.get(k)) }
        return out
    }

    fun set(ctx: Context, json: String) {
        val inc = try { JSONObject(json) } catch (_: Throwable) { return }
        val cur = get(ctx)
        DEFAULTS.keys().forEach { k ->
            if (!inc.has(k)) return@forEach
            if (k == "sleepTime") {
                val t = inc.optString(k, "")
                if (Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(t)) cur.put(k, t)
            } else if (k == "tasbihMin") {
                val m = inc.optInt(k, -1)
                if (m in TASBIH_MIN_LIMIT..TASBIH_MAX_LIMIT) cur.put(k, m)
            } else cur.put(k, inc.optBoolean(k, cur.optBoolean(k)))
        }
        prefs(ctx).edit().putString(KEY, cur.toString()).apply()
        schedule(ctx)
        // দল বন্ধ/চালু হলে আজকের শিডিউল সাথে সাথে মিলিয়ে নেওয়া
        try { ScheduledNotificationScheduler.scheduleAllNotifications(ctx.applicationContext) } catch (_: Throwable) {}
    }

    /** কোন দলের নোটিফিকেশন (অজানা নতুন রিমোট আইটেম → তার ধরন দেখে) */
    fun groupOf(item: IslamicNotification): String = groupOf(item.id, item.type)

    fun groupOf(id: String, type: String): String = when {
        id == "weekly_jumma_kahf" || id == "weekly_friday_durood" -> "kahf"
        id == "weekly_sunnah_fasting_mon_thu" -> "monthu"
        id.startsWith("monthly_ayyam") -> "ayyam"
        type == "daily" -> "zikr"
        type == "annual_bengali" || type == "annual_gregorian" -> "national"
        else -> "islamic"
    }

    /** ব্যবহারকারী এই দল বন্ধ রেখেছেন কি না */
    fun allows(ctx: Context, item: IslamicNotification): Boolean =
        try { get(ctx).optBoolean(groupOf(item), true) } catch (_: Throwable) { true }

    /** নোটিফিকেশনে ট্যাপ করলে অ্যাপের কোথায় যাবে (না থাকলে শুধু অ্যাপ খোলে) */
    fun goFor(id: String): String? = when (id) {
        "weekly_jumma_kahf" -> "quranpick:18"        // সূরা কাহাফ — আসল মুসহাফ / ওয়েব পেজ / সূরা: তিন অপশনের শিট (quran/js/53-read-choice.js)
        "daily_morning_zikr" -> "dua:id:m1"          // সকালের দোয়া (সকাল-সন্ধ্যা অধ্যায় খুলে সরাসরি সেই দোয়ায়)
        "daily_evening_zikr" -> "dua:id:m2"          // সন্ধ্যার দোয়া
        else -> null
    }

    // ---------------------------------------------------------------- ঘুমের আগের রিমাইন্ডার

    private fun pi(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(ctx, SLEEP_REQ,
            Intent(ctx, ReminderReceiver::class.java).putExtra(ReminderAlarms.EXTRA_KIND, KIND_SLEEP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(ctx: Context) {
        try { scheduleTasbih(ctx) } catch (_: Throwable) {}     // নামাজের পর তাসবিহ — ঘুমের রিমাইন্ডারের আগেই, যাতে একটি অন্যটিকে আটকাতে না পারে
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val p = pi(app)
        val o = get(app)
        if (!o.optBoolean("sleep", false)) { am.cancel(p); return }
        val at = AlarmScheduler.nextOccurrence(o.optString("sleepTime", "22:30")) ?: return
        try {   // রিমাইন্ডার — এক্সাক্ট না হলেও চলে (খতমের মতো), তাই স্ট্যাটাস বারে অ্যালার্ম-ঘড়ি দেখায় না
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.set(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: Throwable) {}
    }

    fun fire(ctx: Context, kind: String) {
        val app = ctx.applicationContext
        if (kind.startsWith(KIND_TASBIH)) { fireTasbih(app, kind.removePrefix(KIND_TASBIH)); return }
        if (kind != KIND_SLEEP) return
        try {
            if (get(app).optBoolean("sleep", false)) {
                ReminderAlarms.post(app, SLEEP_REQ, "ঘুমের আগে কয়েকটি আমল",
                    "আয়াতুল কুরসি, তাসবিহ ও ইস্তেগফার ১০০ বার করে, তারপর ঘুমের দোয়া — ট্যাপ করলে ক্রমানুসারে আমলের তালিকা খুলবে।",
                    -1, "sleep")
            }
        } finally { schedule(app) }
    }

    // ---------------------------------------------------------------- নামাজের পর তাসবিহ

    private fun tasbihPi(ctx: Context, key: String): PendingIntent? {
        val req = TASBIH_WAQT[key]?.first ?: return null
        return PendingIntent.getBroadcast(ctx, req,
            Intent(ctx, ReminderReceiver::class.java).putExtra(ReminderAlarms.EXTRA_KIND, KIND_TASBIH + key),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** ওয়াক্তের সময় ("HH:mm", পেছনে অতিরিক্ত লেখা থাকলে বাদ) + মিনিট → পরের যে মুহূর্তটি এখনও আসেনি (আজ বা কাল) */
    private fun nextAfter(hhmm: String, plusMin: Int): Long? = try {
        val parts = hhmm.trim().split(" ")[0].split(":")
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, parts[0].toInt())
        cal.set(java.util.Calendar.MINUTE, parts[1].toInt())
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        cal.add(java.util.Calendar.MINUTE, plusMin)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        cal.timeInMillis
    } catch (_: Throwable) { null }

    /**
     * পাঁচ ওয়াক্তের জন্য আলাদা অ্যালার্ম। সময় আসে নামাজ পেজের সেভ করা সময়সূচি থেকে (উইজেট/আজানের একই উৎস),
     * তাই জায়গা বা হিসাবের পদ্ধতি বদলালে এটিও সাথে সাথে মিলে যায়। বন্ধ থাকলে পাঁচটিই বাতিল।
     * এক-বারের অ্যালার্ম — বাজার পর fireTasbih() নিজেই পরের দিনেরটা বসায়; সময়সূচি সেভ/রিবুটে আবার বসে।
     */
    fun scheduleTasbih(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val o = get(app)
        val on = o.optBoolean("tasbih", false)
        val min = o.optInt("tasbihMin", TASBIH_DEFAULT_MIN).coerceIn(TASBIH_MIN_LIMIT, TASBIH_MAX_LIMIT)
        val timings = try {
            app.getSharedPreferences(com.gunjoron.patheyo.widget.PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
                .getString(com.gunjoron.patheyo.widget.PrayerWidgetProvider.KEY_TIMINGS, null)?.let { JSONObject(it) }
        } catch (_: Throwable) { null }
        for ((key, _) in TASBIH_WAQT) {
            try {
                val p = tasbihPi(app, key) ?: continue
                val t = timings?.optString(key, "") ?: ""
                if (!on || t.isEmpty()) { am.cancel(p); continue }
                val at = nextAfter(t, min) ?: continue
                try {   // রিমাইন্ডার — এক্সাক্ট না হলেও চলে, তাই স্ট্যাটাস বারে অ্যালার্ম-ঘড়ি দেখায় না
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                    else am.set(AlarmManager.RTC_WAKEUP, at, p)
                } catch (_: Throwable) {}
            } catch (_: Throwable) { /* এই ওয়াক্ত স্কিপ, বাকিগুলো চলবে */ }
        }
    }

    private fun fireTasbih(app: Context, key: String) {
        val meta = TASBIH_WAQT[key] ?: return
        try {
            if (get(app).optBoolean("tasbih", false)) {
                ReminderAlarms.post(app, meta.first, "${meta.second} নামাজের পর তাসবিহ",
                    "নামাজের পরের তাসবিহ — সুবহানাল্লাহ, আলহামদুলিল্লাহ ও আল্লাহু আকবার — পড়ে নিন। ট্যাপ করলে ডিজিটাল তাসবিহ খুলবে।",
                    -1, "f6")
            }
        } finally { scheduleTasbih(app) }
    }
}

/** JS ↔ স্মার্ট রিমাইন্ডার (window.PatheyoReminders) */
class RemindersBridge(private val ctx: Context) {
    @JavascriptInterface
    fun get(): String = try { SmartReminders.get(ctx).toString() } catch (_: Throwable) { "{}" }

    @JavascriptInterface
    fun set(json: String) { try { SmartReminders.set(ctx, json) } catch (_: Throwable) {} }
}
