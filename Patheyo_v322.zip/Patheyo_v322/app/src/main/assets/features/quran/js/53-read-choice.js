/*!
 * js/53-read-choice.js — "কীভাবে পড়তে চান?" তিন অপশনের শিট (নোটিফিকেশন থেকে)
 * ব্যবহার: window.__ptGo('quranpick:18') → shell/js/12-go.js → App.openReadChoice(18)
 *   (জুমার দিনের "সূরা কাহাফ" নোটিফিকেশনে ট্যাপ করলে — reminder/SmartReminders.kt goFor)
 * তিন অপশন: আসল মুসহাফে পড়ুন · ওয়েব পেজে পড়ুন · সূরা আকারে পড়ুন — যেটা বাছবে সেটাতেই সেই সূরার শুরু থেকে খোলে।
 * অ্যাপ আগে থেকে কোনো রিডারে খোলা থাকলে সেটা বন্ধ করে নিয়ে তারপর খোলে।
 */
(function (App) {
  'use strict';
  var D = document;
  function $(id) { return D.getElementById(id); }
  var pending = 0;

  function overlay() { return $('rc-overlay'); }
  function close() { var el = overlay(); if (el) el.classList.add('hidden'); }
  function isOpen() { var el = overlay(); return !!el && !el.classList.contains('hidden'); }

  /* খোলা রিডার/পেজ বন্ধ করে তালিকায় ফেরা (mode-switch.js-এর leaveCurrentView-এর মতো)। কিছু বন্ধ করলে true */
  function leaveReader() {
    var v = App.state.view;
    if (!v || v === 'list') return false;
    try {
      if (v === 'tr-fn') { App.closeFootnote(true); v = 'tr-reader'; }
      if (v === 'para-fullscreen') { App.closeFullscreenPage(); v = 'para-pages'; }
      if (v === 'sura-reader') App.closeReader();
      else if (v === 'para-pages') App.closeParaPages();
      else if (v === 'para-web') App.closeParaWebPage();
      else if (v === 'tr-reader') App.closeTarjamaReader();
    } catch (e) {}
    App.state.view = 'list';
    try { if (history.state && history.state.qview) history.back(); } catch (e) {}
    return true;
  }

  /* "তরজমা পড়ুন" মোডে থাকলে মুসহাফ/ওয়েব পেজের জন্য আগে "তিলাওয়াত করুন"-এ ফেরা */
  function ensureTilawat() {
    if (App.state.mode === 'tarjama' && App.setMode) { App.setMode('tilawat'); return true; }
    return false;
  }

  function hideLists() {
    try {
      App.els.suraPanel.classList.add('hidden'); App.els.paraPanel.classList.add('hidden');
      App.els.bookmarksPanel.classList.add('hidden'); App.els.searchWrap.classList.add('hidden');
      App.els.continueCard.classList.add('hidden');
      var kc = $('khatm-card'); if (kc) kc.classList.add('hidden');
    } catch (e) {}
  }

  function openIn(mode, s) {
    var page = App.pageOfAyah ? App.pageOfAyah(s, 1) : 1;
    var para = App.paraForPage(page);
    if (mode === 'mushaf') {
      App.openParaPages(para);
      App.showPreviewPage(page);
      App.openFullscreenPage(page);
    } else if (mode === 'web') {
      App.openParaWebPage(para);
      if (page > App.PARA_PAGE_RANGE[para - 1][0]) {
        var go = function () { try { App.scrollToWebPage(page); } catch (e) {} };
        setTimeout(go, 150);
        if (D.fonts && D.fonts.status === 'loading') D.fonts.ready.then(function () { setTimeout(go, 60); });
      }
    } else {
      hideLists();
      App.openReader(s);
    }
  }

  function pick(mode) {
    var s = pending || 18;
    close();
    var needWait = leaveReader();
    if (mode !== 'sura' && ensureTilawat()) needWait = true;
    /* history.back() / মোড বদলের কাজ শেষ হওয়ার জন্য একটু অপেক্ষা — নইলে নতুন history ধাপ উল্টে মুছে যায় */
    if (needWait) setTimeout(function () { openIn(mode, s); }, 450); else openIn(mode, s);
  }

  App.openReadChoice = function (s) {
    s = Math.max(1, Math.min(114, s | 0));
    var el = overlay(); if (!el) return;
    pending = s;
    if (D.activeElement && D.activeElement.blur) D.activeElement.blur();
    var nm = (App.SURAH_BN && App.SURAH_BN[s - 1]) || '';
    $('rc-title').textContent = 'সূরা ' + nm + ' — কীভাবে পড়তে চান?';
    el.classList.remove('hidden');
  };

  (function bind() {
    var el = overlay(); if (!el) return;
    $('rc-mushaf').addEventListener('click', function () { pick('mushaf'); });
    $('rc-web').addEventListener('click', function () { pick('web'); });
    $('rc-sura').addEventListener('click', function () { pick('sura'); });
    $('rc-cancel').addEventListener('click', close);
    el.addEventListener('click', function (e) { if (e.target === el) close(); });
  })();

  /* Android ব্যাক: আগে এই শিট বন্ধ */
  var prevBack = window.__ptFrameBack;
  window.__ptFrameBack = function () {
    if (isOpen()) { close(); return true; }
    return typeof prevBack === 'function' ? prevBack.apply(this, arguments) : false;
  };
})(window.QuranApp = window.QuranApp || {});
