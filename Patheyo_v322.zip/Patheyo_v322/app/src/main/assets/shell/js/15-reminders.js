/* =============================================================================
   ধাপ ১১: স্মার্ট রিমাইন্ডার — প্রতিটি বিষয় আলাদা অন/অফ (মাঝখানের পপআপ #rm-sheet)
   নেটিভ: window.PatheyoReminders.get()/set(json) — reminder/SmartReminders.kt (দল ধরে আগের ইসলামিক নোটিফিকেশনও
   নিয়ন্ত্রণ করে; ঘুমের আগের রিমাইন্ডার নতুন)। ব্রাউজারে (ব্রিজ নেই) localStorage 'pt_reminders'-এ রাখে।
   খোলে: সেটিংসের "রিমাইন্ডার" সারি, হোমের "দরকারি" সারি, সার্চ, __ptGo('reminders'), অনবোর্ডিংয়ের শেষ ধাপ।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, $ = function (id) { return D.getElementById(id); };
  var sheet = $('rm-sheet'), list = $('rm-list'); if (!sheet || !list) return;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  function ic(n, c) { return window.PT ? PT.icon(n, c || '') : ''; }

  /* [কী, শিরোনাম, কখন আসে, আইকন] — ক্রম: মানুষ যেটি বেশি চায় আগে */
  var ITEMS = [
    ['kahf', 'জুমার দিন সূরা কাহফ', 'শুক্রবার সকালে · চাপলেই সূরা কাহফ খোলে', 'quran'],
    ['monthu', 'সোম ও বৃহস্পতিবারের রোজা', 'আগের রাত ৯টায় — সেহরির নিয়তের জন্য', 'moon'],
    ['ayyam', 'আইয়ামে বিযের রোজা', 'হিজরি ১৩, ১৪, ১৫ তারিখের আগের রাতে (রমজান বাদে)', 'crescent'],
    ['sleep', 'ঘুমের আগের দোয়া ও আমল', '', 'sun-moon'],
    ['tasbih', 'নামাজের পর তাসবিহ', '', 'tasbih'],
    ['zikr', 'সকাল-সন্ধ্যার জিকির', 'সূর্যোদয় ও সূর্যাস্তে', 'sunrise'],
    ['islamic', 'ইসলামিক দিন ও মাস', 'আশুরা, শবে কদর, রমজান, ঈদ, আরাফা…', 'calendar'],
    ['national', 'বাংলা মাস ও জাতীয় দিবস', 'পহেলা বৈশাখ, ২১ ফেব্রুয়ারি, বিজয় দিবস…', 'bell']
  ];
  var DEF = { kahf: true, monthu: true, ayyam: true, zikr: true, islamic: true, national: true, sleep: false, sleepTime: '22:30', tasbih: false, tasbihMin: 30 };
  var LK = 'pt_reminders';
  var TMINS = [10, 15, 20, 30, 45, 60];          /* নামাজের পর তাসবিহের দ্রুত বাছাই (মিনিট); নিজের মতো ১–১৮০ও দেওয়া যায় */
  var tOpen = false;                             /* মিনিট বাছাইয়ের অংশ খোলা আছে কি */

  function nat() { var b = window.PatheyoReminders; return b && typeof b.get === 'function' ? b : null; }
  function load() {
    var o = {};
    try { o = nat() ? JSON.parse(nat().get() || '{}') : JSON.parse(localStorage.getItem(LK) || '{}'); } catch (e) { o = {}; }
    var r = {}; for (var k in DEF) r[k] = o[k] == null ? DEF[k] : o[k]; return r;
  }
  function save(o) {
    var s = JSON.stringify(o);
    try { if (nat()) nat().set(s); else localStorage.setItem(LK, s); } catch (e) {}
  }
  function t12(hm) {
    var p = String(hm || '22:30').split(':'), h = +p[0], m = p[1] || '00';
    var part = h < 4 ? 'রাত' : h < 6 ? 'ভোর' : h < 12 ? 'সকাল' : h < 15 ? 'দুপুর' : h < 18 ? 'বিকাল' : h < 20 ? 'সন্ধ্যা' : 'রাত';
    return part + ' ' + bn((h % 12 || 12) + ':' + m);
  }

  function notifOk() {
    try { var b = window.AndroidWidgetBridge; if (b && b.checkAllPermissionsStatus) return !!JSON.parse(b.checkAllPermissionsStatus()).notification; } catch (e) {}
    return true;
  }

  /* নামাজের পর কত মিনিটে তাসবিহের নোটিফিকেশন — দ্রুত বাছাই + নিজের মতো সংখ্যা (১–১৮০) */
  function tasbihChips(o, on) {
    if (!on || !tOpen) return '';
    var cur = +o.tasbihMin || 30;
    var chips = TMINS.map(function (m) {
      return '<button type="button" class="pt-chip rm-chip' + (m === cur ? ' is-on' : '') + '" data-tmin="' + m + '">' + bn(m) + '</button>';
    }).join('');
    return '<span class="rm-chips" id="rm-chips"><span class="rm-chips__l">নামাজের কত মিনিট পরে?</span><span class="rm-chips__r">' + chips + '</span>' +
      '<span class="rm-own"><input type="number" inputmode="numeric" min="1" max="180" id="rm-tmin-in" class="rm-own__in" placeholder="অন্য" value="' + (TMINS.indexOf(cur) < 0 ? cur : '') + '" aria-label="নিজের মতো মিনিট">' +
      '<span class="rm-own__u">মিনিট</span><button type="button" class="pt-btn pt-btn--sm" id="rm-tmin-ok">ঠিক আছে</button></span></span>';
  }
  function setTasbihMin(m, quiet) {
    m = Math.round(+m);
    if (!(m >= 1 && m <= 180)) { if (window.PT) PT.toast('১ থেকে ১৮০ মিনিটের মধ্যে দিন'); return false; }
    var o = load(); o.tasbihMin = m; save(o); render();
    if (!quiet && window.PT) PT.toast('প্রতি ওয়াক্তের ' + bn(m) + ' মিনিট পরে মনে করানো হবে', { type: 'success' });
    return true;
  }

  function render() {
    var o = load();
    list.innerHTML = ITEMS.map(function (it) {
      var on = !!o[it[0]];
      var sub = it[0] === 'sleep'
        ? '<span class="rm-s">প্রতিদিন <button type="button" class="rm-time" id="rm-time-btn"' + (on ? '' : ' disabled') + '>' + t12(o.sleepTime) + '</button> · চাপলে ঘুমের আমলের তালিকা খোলে</span>'
        : it[0] === 'tasbih'
        ? '<span class="rm-s">প্রতি ওয়াক্ত নামাজের <button type="button" class="rm-time" id="rm-tmin-btn"' + (on ? '' : ' disabled') + '>' + bn(o.tasbihMin) + ' মিনিট</button> পরে · চাপলে তাসবিহ খোলে</span>' + tasbihChips(o, on)
        : '<span class="rm-s">' + it[2] + '</span>';
      return '<div class="rm-row' + (on ? ' on' : '') + (it[0] === 'tasbih' && on && tOpen ? ' rm-row--open' : '') + '"><span class="pt-medal rm-medal">' + ic(it[3]) + '</span>' +
        '<span class="rm-tx"><span class="rm-t">' + it[1] + '</span>' + sub + '</span>' +
        '<label class="pt-switch" aria-label="' + it[1] + '"><input type="checkbox" data-rm="' + it[0] + '"' + (on ? ' checked' : '') + '><span class="pt-switch__track"></span></label></div>';
    }).join('') + '<input type="time" id="rm-time" class="rm-time-in" value="' + (o.sleepTime || '22:30') + '" tabindex="-1" aria-hidden="true">';
    $('rm-perm').hidden = notifOk();
  }

  list.addEventListener('change', function (e) {
    var k = e.target.getAttribute && e.target.getAttribute('data-rm');
    if (k) {
      var o = load(); o[k] = !!e.target.checked; save(o);
      if (window.PT && PT.haptic) PT.haptic('light');
      var row = e.target.closest('.rm-row'); if (row) row.classList.toggle('on', o[k]);
      var tb = $('rm-time-btn'); if (k === 'sleep' && tb) tb.disabled = !o[k];
      if (k === 'tasbih') { tOpen = false; render(); }
      if (window.PT) PT.toast(o[k] ? (k === 'tasbih' ? 'চালু হলো — প্রতি ওয়াক্ত নামাজের ' + bn(o.tasbihMin) + ' মিনিট পরে মনে করানো হবে, ইনশাআল্লাহ' : 'চালু হলো — সময়মতো মনে করিয়ে দেওয়া হবে, ইনশাআল্লাহ') : 'বন্ধ হলো — এটি আর আসবে না', { type: o[k] ? 'success' : '' });
      return;
    }
    if (e.target.id === 'rm-time' && e.target.value) {
      var o2 = load(); o2.sleepTime = e.target.value; save(o2); render();
      if (window.PT) PT.toast('ঘুমের আগের রিমাইন্ডার ' + t12(o2.sleepTime) + '-এ', { type: 'success' });
    }
  });
  list.addEventListener('click', function (e) {
    var T = e.target.closest ? e.target : null; if (!T) return;
    if (T.closest('#rm-tmin-btn')) { tOpen = !tOpen; render(); return; }
    var chip = T.closest('[data-tmin]');
    if (chip) { if (window.PT && PT.haptic) PT.haptic('light'); setTasbihMin(chip.getAttribute('data-tmin')); return; }
    if (T.closest('#rm-tmin-ok')) { var inp = $('rm-tmin-in'); if (inp && inp.value !== '') { if (setTasbihMin(inp.value)) { tOpen = false; render(); } } else { tOpen = false; render(); } return; }
    if (!(T.closest('#rm-time-btn'))) return;
    var ti = $('rm-time');
    try { if (ti.showPicker) ti.showPicker(); else ti.click(); } catch (er) { ti.click(); }
  });
  sheet.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('[data-rm-close]')) { if (window.PT) PT.sheet.close(sheet); }
    if (e.target.closest && e.target.closest('#rm-perm-btn')) {
      try { window.AndroidWidgetBridge.requestNotificationPermission(); } catch (er) {}
      setTimeout(render, 1500);
    }
  });

  window.ptOpenReminders = function () { tOpen = false; render(); if (window.PT) PT.sheet.open(sheet); };
  window.__ptReminders = { load: load, save: save, ITEMS: ITEMS };   /* অনবোর্ডিং ব্যবহার করে */

  /* সেটিংসের সারির ছোট লেখা: কয়টি চালু */
  function paintRow() {
    var s = $('st-rm-s'); if (!s) return;
    var o = load(), n = ITEMS.filter(function (it) { return o[it[0]]; }).length;
    s.textContent = bn(n) + 'টি চালু · কাহফ, রোজা, ঘুমের দোয়া — শুধু আপনার বেছে নেওয়াগুলো';
  }
  var row = $('st-rm-row');
  if (row) row.addEventListener('click', window.ptOpenReminders);
  sheet.addEventListener('pt:close', paintRow);
  var so = $('settings-overlay');
  if (so && window.MutationObserver) new MutationObserver(paintRow).observe(so, { attributes: true, attributeFilter: ['class'] });
  paintRow();
})();

/* =============================================================================
   v287: ঘুমের আগের আমল — ঘুমের রিমাইন্ডারে ট্যাপ করলে (go = 'sleep') সরাসরি দোয়া না খুলে এই ক্রমিক পপআপ আসে:
   ১ আয়াতুল কুরসি → ২ তাসবিহ ১০০ বার → ৩ ইস্তেগফার ১০০ বার → ৪ ঘুমের দোয়া। তাসবিহ ও ইস্তেগফার খোলে আমাদের ডিজিটাল তাসবিহে।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, $ = function (id) { return D.getElementById(id); };
  var sh = $('sl-sheet'), list = $('sl-list'); if (!sh || !list) return;
  function ic(n) { return window.PT ? PT.icon(n, '') : ''; }
  /* [শিরোনাম, ছোট লেখা, গন্তব্য (__ptGo), বাটন, আইকন] */
  var STEPS = [
    ['আয়াতুল কুরসি', 'সূরা বাকারা, আয়াত ২৫৫ — একবার', 'quran:2:255', 'পড়ুন', 'quran'],
    ['তাসবিহ — ১০০ বার', 'সুবহানাল্লাহ ৩৩ · আলহামদুলিল্লাহ ৩৩ · আল্লাহু আকবার ৩৪ — ডিজিটাল তাসবিহে', 'tasbih:farz', 'গুনুন', 'tasbih'],
    ['ইস্তেগফার — ১০০ বার', 'আসতাগফিরুল্লাহ — ডিজিটাল তাসবিহে', 'tasbih:n6', 'গুনুন', 'tasbih'],
    ['ঘুমের দোয়া', 'ঘুমানোর আগের দোয়া পড়ে ডান কাতে শুয়ে পড়ুন', 'dua:id:s1', 'পড়ুন', 'sun-moon']
  ];
  var BN = '০১২৩৪৫৬৭৮৯';
  function render() {
    list.innerHTML = STEPS.map(function (s, i) {
      return '<button type="button" class="sl-step" data-go-to="' + s[2] + '"><span class="sl-no">' + BN[i + 1] + '</span>' +
        '<span class="sl-tx"><span class="sl-t">' + s[0] + '</span><span class="sl-s">' + s[1] + '</span></span>' +
        '<span class="sl-go">' + s[3] + '</span></button>';
    }).join('');
  }
  list.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-go-to]'); if (!b) return;
    var g = b.getAttribute('data-go-to');
    if (window.PT && PT.haptic) PT.haptic('light');
    if (window.PT) PT.sheet.close(sh);
    setTimeout(function () { if (window.__ptGo) window.__ptGo(g); }, 260);
  });
  sh.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('[data-sl-close]')) { if (window.PT) PT.sheet.close(sh); }
  });
  window.ptOpenSleep = function () { render(); if (window.PT) PT.sheet.open(sh); };
})();
