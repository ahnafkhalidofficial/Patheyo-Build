/* =============================================================================
   v322: হোম ট্যুর — অ্যাপের প্রতিটি ফিচারের পরিচিতি (হাইলাইট + ছোট পপআপ, "আগে / পরে / স্কিপ করুন")
   কখন দেখায়: প্রতিটি অ্যাপ-সংস্করণে (versionName) একবার —
     • নতুন ইনস্টলে: স্বাগতম গাইড + সব অনুমতির ধাপ শেষ হয়ে প্রথমবার হোম ফাঁকা হলে
     • পুরনো ইউজার আপডেটের পর: প্রথমবার হোম খুললে (অনুমতি/আপডেট-ধারা শেষ হলে)
   নতুন ফিচার যোগ করলে নিচের STEPS-এ একটি লাইন যোগ করুন (sel = CSS সিলেক্টর; না মিললে ধাপ নিজে বাদ পড়ে, সংখ্যা নিজে ঠিক হয়)।
   হাতে চালাতে: window.__ptTour.start(true)
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function ver() { try { return (W.PatheyoAppInfo && PatheyoAppInfo.getVersionName()) || 'web'; } catch (e) { return 'web'; } }
  var KEY = 'pt_tour_v';

  var T = '.module-grid .module-tile:nth-child(';
  var STEPS = [
    { sel: '#btn-donate', t: 'ডোনেট', d: 'পাথেয় সবার জন্য বিনামূল্যে। আপনার সদকায়ে জারিয়া এই কাজ চালু রাখতে সাহায্য করে।' },
    { sel: '#btn-notif', t: 'নোটিফিকেশন', d: 'অ্যাপের খবর ও নতুন আপডেট এখানে জমা থাকে। লাল সংখ্যা মানে না-পড়া খবর।' },
    { sel: '#btn-profile', t: 'প্রোফাইল', d: 'এখানে অ্যাকাউন্ট, ছবি ও প্রিমিয়াম দেখা যায়। লগইন করলে আপনার তথ্য সুরক্ষিত থাকে।' },
    { sel: '.hero-card', t: 'আজকের দিন', d: 'সালাম, লাইভ ঘড়ি আর হিজরি, ইংরেজি ও বাংলা — তিন তারিখ এক জায়গায়।' },
    { sel: '.hub-waqt-strip', t: 'আজকের ৫ ওয়াক্ত', d: 'প্রতিটি ওয়াক্তের সময় দেখুন। নামাজ পড়া হলে ওয়াক্তে চাপ দিয়ে "আদায় করেছি" চিহ্নিত করুন — আমলের রিপোর্টে জমা হবে।' },
    { sel: '#waqt-progress', t: 'চলমান ওয়াক্ত', d: 'এখন কোন ওয়াক্ত চলছে, কত সময় বাকি আর নিষিদ্ধ সময় কখন — সব এখানে।' },
    { sel: '#dp-section', t: 'আজকের পাঠ', d: 'প্রতিদিন একটি আয়াত, হাদিস ও দোয়া। কপি করুন বা সুন্দর কার্ড বানিয়ে শেয়ার করুন।' },
    { sel: T + '1)', t: 'নামাজের সময়', d: 'আপনার এলাকার ওয়াক্তের শুরু-শেষ, আজান অ্যালার্ম ও মাযহাব অনুযায়ী সময়সূচি।' },
    { sel: T + '2)', t: 'কুরআন শরিফ', d: 'আরবি, বাংলা অনুবাদ ও তাফসির সহ পুরো কুরআন। অফলাইনে পড়া যায়, বুকমার্ক ও অডিও আছে।' },
    { sel: T + '3)', t: 'হাদিস শরিফ', d: 'নির্ভরযোগ্য হাদিসগ্রন্থ বই ও অধ্যায় ধরে পড়ুন। ডাউনলোড করলে অফলাইনেও চলে; খোঁজা ও বুকমার্ক আছে।' },
    { sel: T + '4)', t: 'আমলের রিপোর্ট', d: 'নামাজ ও দৈনন্দিন আমল কতটা করলেন, তার হিসাব ও অগ্রগতি দেখুন।' },
    { sel: T + '5)', t: 'দোয়া', d: 'প্রয়োজনের দোয়া আরবি, উচ্চারণ ও অর্থ সহ — ক্যাটাগরি ধরে খুঁজে নিন।' },
    { sel: T + '6)', t: 'কিবলা কম্পাস', d: 'ফোন ঘুরিয়ে কিবলার দিক খুঁজুন। যেখানেই থাকুন, নামাজের দিক ঠিক থাকবে।' },
    { sel: T + '7)', t: 'ডিজিটাল তাসবিহ', d: 'আঙুলের এক চাপে গণনা। লক্ষ্য ঠিক করুন, আগের হিসাবও দেখা যায়।' },
    { sel: T + '8)', t: 'উইজেট হাব', d: 'হোম স্ক্রিনের জন্য সুন্দর উইজেট বেছে নিন — নামাজের সময় ও তারিখ ফোন খুললেই চোখের সামনে।' },
    { sel: T + '9)', t: 'ক্যালেন্ডার', d: 'হিজরি, ইংরেজি ও বাংলা তারিখ একসাথে। দিনের নোট রাখুন, তারিখের কার্ড বানিয়ে শেয়ার করুন।' },
    { sel: '#btn-settings', t: 'সেটিংস', d: 'থিম, ভাষা, আজান ও রিমাইন্ডার, অনুমতি এবং ব্যাকআপ — সব নিয়ন্ত্রণ এখানে।' },
    { sel: '.tools-card', t: 'দরকারি সরঞ্জাম', d: 'যাকাত ক্যালকুলেটর (নিসাবসহ), আল্লাহর ৯৯ নাম, আর রিমাইন্ডার — সূরা কাহফ, রোজা, ঘুমের দোয়া মনে করিয়ে দেবে।' },
    { sel: '.share-app', t: 'প্রিয়জনকে পাথেয় দিন', d: 'অ্যাপটি শেয়ার করুন। আপনার মাধ্যমে কেউ উপকৃত হলে সদকায়ে জারিয়ার সওয়াব পাবেন, ইনশাআল্লাহ।' },
    { sel: '.bottom-nav-inner', t: 'নিচের মেনু', d: 'এক ট্যাপে হোম, নামাজ, কুরআন ও হাদিসে যান। "আরও" থেকে সেটিংসসহ বাকি সব।' }
  ];

  var root, spot, card, steps, i, running = false;

  function build() {
    root = D.createElement('div'); root.className = 'tour'; root.hidden = true; root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true');
    root.innerHTML = '<div class="tour__spot"></div><div class="tour__card"><i class="tour__arrow"></i>' +
      '<div class="tour__count"></div><h2 class="tour__title"></h2><p class="tour__text"></p>' +
      '<div class="tour__acts"><button type="button" class="tour__skip" data-a="skip">স্কিপ করুন</button>' +
      '<button type="button" class="pt-btn pt-btn--secondary pt-btn--sm" data-a="prev">আগে</button>' +
      '<button type="button" class="pt-btn pt-btn--sm" data-a="next">পরে</button></div></div>';
    D.body.appendChild(root);
    spot = root.querySelector('.tour__spot'); card = root.querySelector('.tour__card');
    root.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-a]') : null;
      if (b) { var a = b.getAttribute('data-a'); if (a === 'next') go(i + 1); else if (a === 'prev') go(i - 1); else end(); }
      e.stopPropagation();
    });
    W.addEventListener('resize', function () { if (running) place(); });
  }

  function visible(el) { var r = el.getBoundingClientRect(); return r.width > 4 && r.height > 4; }
  function target() { var s = steps[i]; return D.querySelector(s.sel); }

  function place() {
    var el = target(); if (!el) return;
    var r = el.getBoundingClientRect(), vw = W.innerWidth, vh = W.innerHeight, pad = 6;
    var x = Math.max(4, r.left - pad), y = Math.max(4, r.top - pad);
    var w = Math.min(vw - 8, r.width + pad * 2), h = Math.min(vh - 8, r.height + pad * 2);
    spot.style.left = x + 'px'; spot.style.top = y + 'px'; spot.style.width = w + 'px'; spot.style.height = h + 'px';
    var ch = card.offsetHeight, cw = card.offsetWidth, gap = 14;
    var below = (y + h + gap + ch) <= vh - 8, above = (y - gap - ch) >= 8;
    var pos = below ? 'below' : above ? 'above' : 'below';
    var top = pos === 'below' ? y + h + gap : y - gap - ch;
    if (!below && !above) top = Math.max(8, vh - ch - 12);   /* বড় টার্গেট: কার্ড নিচে বসে */
    var left = Math.min(Math.max(12, x + w / 2 - cw / 2), vw - cw - 12);
    card.style.top = top + 'px'; card.style.left = left + 'px'; card.setAttribute('data-pos', below || above ? pos : 'none');
    var ar = card.querySelector('.tour__arrow'), ax = Math.min(Math.max(22, x + w / 2 - left - 8), cw - 38);
    ar.style.left = ax + 'px'; ar.style.display = (below || above) ? '' : 'none';
  }

  function go(n) {
    if (n < 0) return;
    if (n >= steps.length) return end();
    i = n; var s = steps[i], el = target();
    if (!el) return go(n + (n >= i ? 1 : -1));
    card.style.opacity = '0';
    try { el.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) {}
    card.querySelector('.tour__count').textContent = bn(i + 1) + ' / ' + bn(steps.length);
    card.querySelector('.tour__title').textContent = s.t;
    card.querySelector('.tour__text').textContent = s.d;
    var last = i === steps.length - 1;
    card.querySelector('[data-a="prev"]').hidden = i === 0;
    card.querySelector('[data-a="next"]').textContent = last ? 'শুরু করুন' : 'পরে';
    card.querySelector('[data-a="skip"]').hidden = last;
    if (W.PT && PT.haptic) PT.haptic('light');
    setTimeout(function () { if (!running) return; place(); card.style.opacity = ''; }, i === 0 ? 120 : 320);
    place();
  }

  function end() {
    if (!running) return; running = false;
    root.classList.remove('is-on');
    setTimeout(function () { root.hidden = true; }, 220);
    if (W.PT && PT.__back === backHandler) PT.__back = null;
    try { var m = D.querySelector('.app-main'); if (m) m.scrollTop = 0; W.scrollTo(0, 0); } catch (e) {}
  }
  function backHandler() { if (!running) return false; if (i > 0) go(i - 1); else end(); return true; }

  function start(force) {
    if (running) return; if (!root) build();
    steps = STEPS.filter(function (s) { var e = D.querySelector(s.sel); return e && visible(e); });
    if (!steps.length) return;
    running = true; if (!force) ls(KEY, ver());
    root.hidden = false; i = 0;
    if (W.PT) PT.__back = backHandler;
    requestAnimationFrame(function () { root.classList.add('is-on'); go(0); });
  }

  /* ---------- কখন শুরু: স্প্ল্যাশ, গাইড, অনুমতি-ধারা, খোলা পপআপ সব শেষ হলে ---------- */
  function ready() {
    var sp = D.getElementById('pts'); if (sp && !sp.classList.contains('pts-out')) return false;
    var onb = D.getElementById('onb'); if (onb && !onb.hidden) return false;
    try { if (W.PatheyoOnboard && PatheyoOnboard.pending && PatheyoOnboard.pending() && ls('pt_onboarded') !== '1') return false; } catch (e) {}
    try { if (W.PatheyoOnboard && PatheyoOnboard.chainActive && PatheyoOnboard.chainActive()) return false; } catch (e) {}
    var busy = D.querySelectorAll('.page-overlay.is-open, .pt-scrim, .pt-dialog, .pt-sheet');   /* লুকানো শিটগুলো DOM-এ সবসময় থাকে — শুধু দৃশ্যমানগুলো গোনা */
    for (var k = 0; k < busy.length; k++) { if (!busy[k].hidden && busy[k].getClientRects().length) return false; }
    return !D.hidden;
  }
  W.__ptTour = { start: start, STEPS: STEPS };
  if (ls(KEY) === ver()) return;
  var ok = 0;
  var iv = setInterval(function () {
    if (ls(KEY) === ver()) return clearInterval(iv);
    if (running) return;
    ok = ready() ? ok + 1 : 0;
    if (ok >= 3) { clearInterval(iv); start(); }   /* ~২ সেকেন্ড টানা শান্ত থাকলে */
  }, 700);
})();
