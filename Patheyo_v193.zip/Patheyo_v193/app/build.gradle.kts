import java.util.Properties
import java.io.FileInputStream

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.services)
}

// ✅ ইন-অ্যাপ আপডেট: keystore.properties থেকে সাইনিং তথ্য পড়া (ফাইলটি GitHub-এ আপলোড করবেন না)
val keystoreProps = Properties()
val keystoreFile = rootProject.file("keystore.properties")
if (keystoreFile.exists()) keystoreProps.load(FileInputStream(keystoreFile))

android {
    namespace = "com.gunjoron.patheyo"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.gunjoron.patheyo"
        minSdk = 24
        targetSdk = 37
        versionCode = 6
        versionName = "1.6.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // ✅ ধাপ ১০: প্রিমিয়ামের পেমেন্ট লেয়ার (docs/PREMIUM_SETUP.md)
        //  DISTRIBUTION = "github" → বাংলাদেশি গেটওয়ে (bKash/Nagad/কার্ড) — আমাদের সার্ভার (server/payments) হয়ে
        //  DISTRIBUTION = "play"   → Google Play Billing (Play Store-এ গেলে শুধু এটা বদলান)
        //  PAY_API_URL  = সার্ভারের ঠিকানা (যেমন https://….cloudfunctions.net/pay) — খালি থাকলে পেওয়ালে "শীঘ্রই চালু" দেখায়
        buildConfigField("String", "DISTRIBUTION", "\"github\"")
        buildConfigField("String", "PAY_API_URL", "\"https://patheyo-pay-delta.vercel.app\"")   // SSLCommerz স্যান্ডবক্স (পরীক্ষা) — Vercel
    }

    buildFeatures { buildConfig = true }

    // ✅ ধাপ ১২: লাইব্রেরিগুলোর ১০০+ ভাষার অনুবাদ বাদ — অ্যাপ শুধু বাংলা ও ইংরেজি
    androidResources {
        localeFilters += listOf("en", "bn")
    }

    // ✅ ইন-অ্যাপ আপডেট: সাইনিং কনফিগ
    signingConfigs {
        create("release") {
            if (keystoreFile.exists()) {
                storeFile = file(keystoreProps["storeFile"] as String)
                storePassword = keystoreProps["storePassword"] as String
                keyAlias = keystoreProps["keyAlias"] as String
                keyPassword = keystoreProps["keyPassword"] as String
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")   // ✅ ইন-অ্যাপ আপডেট
            // ✅ ধাপ ১২: R8 — অব্যবহৃত কোড ও রিসোর্স বাদ, APK অনেক ছোট ও দ্রুত। নিয়ম: proguard-rules.pro
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    @Suppress("DEPRECATION")
    aaptOptions {
        noCompress("mp3")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation("com.google.firebase:firebase-config-ktx:21.6.3")
    // ✅ নতুন: FCM push (অ্যাপ বন্ধ থাকলেও আরবি তারিখ আপডেট করতে)
    implementation("com.google.firebase:firebase-messaging-ktx:24.1.0")
    // ✅ নতুন: Realtime Database (রিয়েল-টাইম push-based sync)
    implementation("com.google.firebase:firebase-database-ktx:21.0.0")
    // ✅ ধাপ ৯: অ্যাকাউন্ট — Firebase Authentication (Google + ইমেইল) ও Android Credential Manager (Google-এর এক-ট্যাপ সাইন-ইন)
    implementation("com.google.firebase:firebase-auth:23.1.0")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    // ✅ ধাপ ১০: Google Play Billing — কোড তৈরি, কিন্তু DISTRIBUTION = "play" না হলে কখনো চালু হয় না
    implementation("com.android.billingclient:billing-ktx:7.1.1")
    
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    // ✅ v168: কুরআন তিলাওয়াতের পূর্ণ ব্যাকগ্রাউন্ড প্লেয়ার (ফোরগ্রাউন্ড সার্ভিস + নোটিফিকেশন কন্ট্রোল + মিডিয়া-সেশন)
    implementation("androidx.media3:media3-exoplayer:1.8.0")
    implementation("androidx.media3:media3-session:1.8.0")
    implementation("com.google.guava:guava:33.3.1-android")
    // ✅ ইন-অ্যাপ আপডেট: lifecycleScope ও ProcessLifecycleOwner-এর জন্য
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}
