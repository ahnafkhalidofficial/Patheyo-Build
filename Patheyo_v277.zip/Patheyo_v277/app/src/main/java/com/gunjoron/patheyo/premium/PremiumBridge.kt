package com.gunjoron.patheyo.premium

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.gunjoron.patheyo.BuildConfig
import com.gunjoron.patheyo.auth.AuthBridge
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * ধাপ ১০ — প্রিমিয়াম ও পেমেন্ট লেয়ার (JS-এ নাম: PatheyoPremium)
 *
 * প্রিমিয়ামের আসল অবস্থা থাকে অ্যাকাউন্টে: Realtime Database  users/{uid}/premium
 *   {plan: "monthly"|"yearly"|"lifetime", until: <ms, আজীবনে 0>, since, source, order}
 * এটি শুধু সার্ভার লেখে (ডেটাবেস রুলসে  premium/.write = false) — তাই কেউ নিজে নিজে প্রিমিয়াম চালু করতে পারে না,
 * আর যেকোনো ফোনে একই অ্যাকাউন্টে সাইন-ইন করলেই প্রিমিয়াম পায়। অফলাইনের জন্য শেষ জানা অবস্থা ফোনে রাখা হয়।
 *
 * কেনার দুই পথ, একটাই বাটনের পেছনে (BuildConfig.DISTRIBUTION):
 *  • "github": সার্ভার (BuildConfig.PAY_API_URL, কোড: server/payments) গেটওয়েতে পেমেন্ট তৈরি করে লিংক দেয় →
 *    ব্রাউজারে bKash/Nagad/কার্ডে পেমেন্ট → সার্ভার গেটওয়ের কাছে যাচাই করে premium লেখে →
 *    patheyo://pay?status=… দিয়ে অ্যাপে ফেরত।
 *  • "play": Google Play Billing (PlayBilling.kt) → কেনার টোকেন সার্ভারে যাচাই → premium লেখে।
 * PAY_API_URL খালি থাকলে (এখনকার অবস্থা) পেওয়ালে "শীঘ্রই চালু" দেখায় — কিছুই ভাঙে না।
 *
 * JS-এর দিকে: ফলাফল  window.__ptPremiumCb(id, json),  অবস্থা বদলালে  window.__ptPremiumChanged(json),
 * পেমেন্ট থেকে ফেরত এলে  window.__ptPayReturn(json)।
 */
class PremiumBridge(private val activity: Activity, private val webView: WebView) {

    private val io = Executors.newSingleThreadExecutor()
    private val prefs = activity.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private var ref: DatabaseReference? = null
    private var listener: ValueEventListener? = null
    private val play: PlayBilling? = if (isPlay()) PlayBilling(activity, ::verifyPlay) else null

    init {
        instance = this
        try { FirebaseAuth.getInstance().addAuthStateListener { watch() } } catch (_: Throwable) {}
    }

    private fun isPlay() = BuildConfig.DISTRIBUTION == "play"
    private fun payUrl() = BuildConfig.PAY_API_URL.trim().trimEnd('/')

    // ------------------------------------------------------------------ JS-এর দিকে

    private fun emit(js: String) { try { webView.post { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} } } catch (_: Throwable) {} }
    private fun reply(req: String, o: JSONObject) = emit("window.__ptPremiumCb&&window.__ptPremiumCb(" + JSONObject.quote(req) + "," + JSONObject.quote(o.toString()) + ")")
    private fun ok(req: String, extra: JSONObject = JSONObject()) = reply(req, extra.put("ok", true).put("state", stateJson()))
    private fun fail(req: String, code: String, msg: String) = reply(req, JSONObject().put("ok", false).put("code", code).put("msg", msg))

    // ------------------------------------------------------------------ অবস্থা

    private fun stateJson(): JSONObject {
        val raw = try { JSONObject(prefs.getString(KEY, null) ?: "{}") } catch (_: Throwable) { JSONObject() }
        return compute(raw)
    }

    private fun compute(p: JSONObject): JSONObject {
        val plan = p.optString("plan", "")
        val until = p.optLong("until", 0L)
        val active = plan == "lifetime" || (plan.isNotEmpty() && until > System.currentTimeMillis())
        return JSONObject().put("active", active).put("plan", plan).put("until", until)
            .put("since", p.optLong("since", 0L)).put("source", p.optString("source", ""))
            .put("had", plan.isNotEmpty())
            .put("code", if (plan.isNotEmpty()) memberCode() else "")
    }

    /**
     * v274: বেনামী "সদস্য কোড" (যেমন PM-3F9A-C21B) = SHA-256("patheyo-premium:" + uid)-এর প্রথম ৮ অক্ষর।
     * অ্যাডমিন প্যানেল শুধু এই কোড, প্ল্যান ও মেয়াদ দেখে — নাম, ইমেইল, uid কখনো নয়। একমুখী হ্যাশ, তাই কোড থেকে অ্যাকাউন্ট বের করা যায় না।
     * ইউজার নিজে সহায়তার জন্য কোডটি জানালে তবেই অ্যাডমিন তাকে চিনতে পারেন।
     */
    private fun memberCode(): String = try {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: ""
        if (uid.isEmpty()) "" else {
            val h = MessageDigest.getInstance("SHA-256").digest(("patheyo-premium:" + uid).toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }.uppercase().take(8)
            "PM-" + h.take(4) + "-" + h.drop(4)
        }
    } catch (_: Throwable) { "" }

    /**
     * v274: প্রিমিয়াম নোটিফিকেশনের টপিক — অ্যাডমিন প্যানেল থেকে শুধু প্রিমিয়াম সদস্য/নির্দিষ্ট সদস্যকে পাঠানোর জন্য।
     *   premium            → এখন সক্রিয় সব সদস্য
     *   premium_<plan>     → সক্রিয় মাসিক / বার্ষিক / আজীবন
     *   pm_<কোড>           → একজন নির্দিষ্ট সদস্য (মেয়াদ শেষ হলেও থাকে, যাতে নবায়নের কথা জানানো যায়; সাইন-আউটে মুছে যায়)
     * টপিকে কোনো ব্যক্তিগত তথ্য নেই; FCM শুধু ফোনকে টপিকের সাথে যুক্ত করে।
     */
    private fun syncTopics(st: JSONObject) {
        try {
            val want = mutableSetOf<String>()
            val code = st.optString("code", "")
            if (code.isNotEmpty()) want.add("pm_" + code.replace("PM-", "").replace("-", "").lowercase())
            if (st.optBoolean("active")) { want.add("premium"); st.optString("plan").takeIf { it.isNotEmpty() }?.let { want.add("premium_$it") } }
            val had = try { JSONArray(prefs.getString(KEY_TOPICS, "[]")).let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } } catch (_: Throwable) { emptySet() }
            if (want == had) return
            val fm = FirebaseMessaging.getInstance()
            (had - want).forEach { t -> try { fm.unsubscribeFromTopic(t) } catch (_: Throwable) {} }
            (want - had).forEach { t -> try { fm.subscribeToTopic(t) } catch (_: Throwable) {} }
            prefs.edit().putString(KEY_TOPICS, JSONArray(want.toList()).toString()).apply()
        } catch (_: Throwable) {}
    }

    private fun save(p: JSONObject?) {
        prefs.edit().putString(KEY, (p ?: JSONObject()).toString()).apply()
        syncTopics(stateJson())
        emit("window.__ptPremiumChanged&&window.__ptPremiumChanged(" + JSONObject.quote(stateJson().toString()) + ")")
    }

    /** সাইন-ইন থাকলে অ্যাকাউন্টের premium শোনা; সাইন-আউটে ফোনের অবস্থা মুছে দেওয়া (প্রিমিয়াম অ্যাকাউন্টের) */
    private fun watch() {
        try {
            listener?.let { l -> ref?.removeEventListener(l) }
            listener = null; ref = null
            val u = FirebaseAuth.getInstance().currentUser
            if (u == null) { save(null); return }
            val r = FirebaseDatabase.getInstance(AuthBridge.RTDB_URL).getReference("users").child(u.uid).child("premium")
            val l = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) { save(snapJson(s)) }
                override fun onCancelled(e: DatabaseError) {}
            }
            r.addValueEventListener(l); ref = r; listener = l
        } catch (_: Throwable) {}
    }

    private fun snapJson(s: DataSnapshot): JSONObject? {
        if (!s.exists()) return null
        return JSONObject().put("plan", s.child("plan").value?.toString() ?: "")
            .put("until", (s.child("until").value as? Number)?.toLong() ?: 0L)
            .put("since", (s.child("since").value as? Number)?.toLong() ?: 0L)
            .put("source", s.child("source").value?.toString() ?: "")
    }

    @JavascriptInterface
    fun state(): String = try { stateJson().toString() } catch (_: Throwable) { "{\"active\":false}" }

    @JavascriptInterface
    fun config(): String = JSONObject()
        .put("distribution", BuildConfig.DISTRIBUTION)
        .put("ready", if (isPlay()) payUrl().isNotEmpty() else payUrl().isNotEmpty())
        .put("prices", JSONObject().put("monthly", 49).put("yearly", 399).put("lifetime", 999))
        .toString()

    // ------------------------------------------------------------------ কেনা

    @JavascriptInterface
    fun buy(req: String, plan: String) {
        if (plan !in setOf("monthly", "yearly", "lifetime")) return fail(req, "plan", "প্ল্যান বাছাই করুন।")
        val u = FirebaseAuth.getInstance().currentUser ?: return fail(req, "signin", "আগে সাইন-ইন করুন — প্রিমিয়াম আপনার অ্যাকাউন্টে থাকবে।")
        if (payUrl().isEmpty()) return fail(req, "not-ready", "পেমেন্ট ব্যবস্থা এখনো চালু হয়নি — ইনশাআল্লাহ শীঘ্রই চালু হবে।")
        if (play != null) { play.buy(plan) { code, msg -> if (code == "ok") ok(req) else fail(req, code, msg) }; return }
        u.getIdToken(false).addOnCompleteListener { t ->
            val token = t.result?.token
            if (!t.isSuccessful || token == null) { fail(req, "network", "ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।"); return@addOnCompleteListener }
            io.execute {
                try {
                    val res = post(payUrl() + "/create", token, JSONObject().put("plan", plan))
                    val url = res.optString("url", "")
                    if (url.startsWith("https://")) {
                        activity.runOnUiThread {
                            try { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Throwable) {}
                        }
                        ok(req, JSONObject().put("opened", true).put("order", res.optString("order")))
                    } else fail(req, "server", res.optString("msg", "পেমেন্ট শুরু করা যায়নি। একটু পরে চেষ্টা করুন।"))
                } catch (_: Throwable) { fail(req, "network", "সার্ভারে পৌঁছানো যায়নি। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।") }
            }
        }
    }

    // ------------------------------------------------------------------ দান (v277)
    /**
     * দান — সাইন-ইন লাগে না, কোনো ব্যক্তিগত তথ্য যায় না (শুধু অঙ্ক ও পছন্দের পদ্ধতি)।
     * সার্ভার: POST {PAY_API_URL}/donate/create {amount, method, src:"app"} → {url} → ব্রাউজারে পেমেন্ট পেজ
     * শেষে patheyo://pay?status=…&order=DON…&kind=donate → onPayReturn → JS ধন্যবাদ দেখায়।
     * method: bkash | nagad | rocket | bank
     */
    @JavascriptInterface
    fun donate(req: String, amount: Int, method: String) {
        if (payUrl().isEmpty()) return fail(req, "not-ready", "ডোনেশন ব্যবস্থা এখনো চালু হয়নি — ইনশাআল্লাহ শীঘ্রই চালু হবে।")
        if (amount < 10 || amount > 100000) return fail(req, "amount", "ডোনেশনের পরিমাণ ৳১০ থেকে ৳১,০০,০০০-এর মধ্যে দিন।")
        val m = if (method in setOf("bkash", "nagad", "rocket", "bank")) method else ""
        io.execute {
            try {
                val res = post(payUrl() + "/donate/create", null, JSONObject().put("amount", amount).put("method", m).put("src", "app"))
                val url = res.optString("url", "")
                if (url.startsWith("https://")) {
                    activity.runOnUiThread {
                        try { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Throwable) {}
                    }
                    reply(req, JSONObject().put("ok", true).put("opened", true).put("id", res.optString("id")).put("sandbox", res.optBoolean("sandbox")))
                } else fail(req, "server", res.optString("msg", "পেমেন্ট পেজ খোলা যায়নি। একটু পরে চেষ্টা করুন।"))
            } catch (_: Throwable) { fail(req, "network", "সার্ভারে পৌঁছানো যায়নি। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।") }
        }
    }

    /** দানের তথ্য (পরীক্ষামূলক কিনা, ন্যূনতম/সর্বোচ্চ) — সার্ভার থেকে; না পেলে ডিফল্ট */
    @JavascriptInterface
    fun donateInfo(req: String) {
        if (payUrl().isEmpty()) return reply(req, JSONObject().put("ok", false).put("code", "not-ready"))
        io.execute {
            val o = try { httpGet(payUrl() + "/donate/config") } catch (_: Throwable) { JSONObject().put("ok", false).put("code", "network") }
            reply(req, o)
        }
    }

    /** "আগে কিনেছি" — অ্যাকাউন্ট থেকে আবার পড়া (Play-তে আগের কেনাগুলোও আবার যাচাই) */
    @JavascriptInterface
    fun restore(req: String) {
        val u = FirebaseAuth.getInstance().currentUser ?: return fail(req, "signin", "যে অ্যাকাউন্টে কিনেছিলেন সেটিতে সাইন-ইন করুন।")
        play?.restore()
        try {
            FirebaseDatabase.getInstance(AuthBridge.RTDB_URL).getReference("users").child(u.uid).child("premium").get()
                .addOnCompleteListener { t ->
                    if (!t.isSuccessful) { fail(req, "network", "ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।"); return@addOnCompleteListener }
                    save(t.result?.let { snapJson(it) }); ok(req)
                }
        } catch (_: Throwable) { fail(req, "error", "কাজটি সম্পন্ন করা যায়নি।") }
    }

    /** গেটওয়ে থেকে ফেরত: patheyo://pay?status=success|failed|cancelled&order=… */
    fun onPayReturn(uri: Uri) {
        val st = uri.getQueryParameter("status") ?: ""
        val kind = uri.getQueryParameter("kind") ?: ""
        emit("window.__ptPayReturn&&window.__ptPayReturn(" + JSONObject.quote(JSONObject().put("status", st).put("order", uri.getQueryParameter("order") ?: "")
            .put("kind", kind).put("amount", uri.getQueryParameter("amount") ?: "").toString()) + ")")
        if (kind == "donate") return   // দানে প্রিমিয়াম বদলায় না
        // সার্ভার premium লিখে দেয়; লিসেনার নিজেই ধরবে — তবু নিশ্চিত হতে একবার পড়া
        try {
            val u = FirebaseAuth.getInstance().currentUser ?: return
            FirebaseDatabase.getInstance(AuthBridge.RTDB_URL).getReference("users").child(u.uid).child("premium").get()
                .addOnSuccessListener { s -> save(snapJson(s)) }
        } catch (_: Throwable) {}
    }

    /** Play-তে কেনা হলে টোকেন সার্ভারে যাচাই (সার্ভার Google Play Developer API দিয়ে দেখে premium লেখে) */
    private fun verifyPlay(productId: String, purchaseToken: String, done: (Boolean) -> Unit) {
        val u = FirebaseAuth.getInstance().currentUser ?: return done(false)
        if (payUrl().isEmpty()) return done(false)
        u.getIdToken(false).addOnCompleteListener { t ->
            val token = t.result?.token ?: return@addOnCompleteListener done(false)
            io.execute {
                val okv = try { post(payUrl() + "/play/verify", token, JSONObject().put("productId", productId).put("purchaseToken", purchaseToken)).optBoolean("ok") } catch (_: Throwable) { false }
                done(okv)
            }
        }
    }

    private fun post(url: String, idToken: String?, body: JSONObject): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 20000; doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (idToken != null) setRequestProperty("Authorization", "Bearer $idToken")
        }
        OutputStreamWriter(c.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
        return try { JSONObject(text) } catch (_: Throwable) { JSONObject().put("ok", false) }
    }

    private fun httpGet(url: String): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply { requestMethod = "GET"; connectTimeout = 10000; readTimeout = 15000 }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
        return try { JSONObject(text) } catch (_: Throwable) { JSONObject().put("ok", false) }
    }

    companion object {
        private const val PREFS = "patheyo_premium"
        private const val KEY = "state"
        private const val KEY_TOPICS = "topics"
        @Volatile var instance: PremiumBridge? = null

        /** নেটিভ জায়গা থেকে (যেমন ভবিষ্যতে উইজেট/তারিখ-কার্ডের প্রিমিয়াম থিম) দ্রুত জানা */
        fun isActive(ctx: Context): Boolean = try {
            val p = JSONObject(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: "{}")
            p.optString("plan") == "lifetime" || (p.optString("plan").isNotEmpty() && p.optLong("until") > System.currentTimeMillis())
        } catch (_: Throwable) { false }
    }
}
