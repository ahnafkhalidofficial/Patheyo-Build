/* কুরআন — তিলাওয়াত শোনা (ইন-অ্যাপ প্লেয়ার)।
   অডিও অ্যাপে বান্ডেল নেই (APK-র সাইজ বাড়ে না) — প্রতিটা আয়াতের আলাদা MP3 ইন্টারনেট থেকে চলে (everyayah.com, ফাইল-নাম SSSAAA.mp3)।
   - সূরা-পাঠ ও তরজমা-পাঠ দুই পেজেই চলে; চলতি আয়াত হাইলাইট হয় ও লেখা সাথে সাথে স্ক্রল করে (বন্ধ করা যায়)।
   - মিনি-প্লেয়ার (নিচে) + বড় প্লেয়ার (তিলাওয়াতকারী বাছাই, গতি, রিপিট, ঘুমের টাইমার)।
   - ফাতিহার সংখ্যা-মিল: everyayah-তে ০০১০০১ = বিসমিল্লাহ, ০০১০০২–০০১০০৬ = আয়াত ১–৫, ০০১০০৭ = আয়াত ৬ ও ৭ একসাথে (নিচের buildQueue দেখুন)।
   - তিলাওয়াতের সূত্র: everyayah.com — অ্যাপের ভেতরে ক্রেডিট দেখানো হয়। */
(function (App) {
  'use strict';
  var BASE = 'https://everyayah.com/data/';
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function $(id) { return document.getElementById(id); }
  function pad3(n) { return ('00' + n).slice(-3); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* তিলাওয়াতকারী — পূর্ণ নাম (ফোল্ডার-নাম everyayah.com-এর তালিকা থেকে মিলিয়ে নেওয়া) */
  var RECITERS = [
    { id: 'alafasy',   n: 'মিশারি ইবনে রাশিদ আল-আফাসি',        sub: 'কুয়েত',                         f: 'Alafasy_128kbps',                       k: 128 },
    { id: 'abdulbasit',n: 'আব্দুল বাসিত মুহাম্মাদ আব্দুস সামাদ (মুরাত্তাল)', sub: 'মিসর',               f: 'Abdul_Basit_Murattal_192kbps',          k: 192 },
    { id: 'abdulbasitm',n:'আব্দুল বাসিত মুহাম্মাদ আব্দুস সামাদ (মুজাওয়াদ)', sub: 'মিসর',               f: 'Abdul_Basit_Mujawwad_128kbps',          k: 128 },
    { id: 'sudais',    n: 'আব্দুর রহমান ইবনে আব্দুল আযীয আস-সুদাইস', sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Abdurrahmaan_As-Sudais_192kbps',  k: 192 },
    { id: 'shuraim',   n: 'সউদ ইবনে ইবরাহীম আশ-শুরাইম',          sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Saood_ash-Shuraym_128kbps',       k: 128 },
    { id: 'juhany',    n: 'আব্দুল্লাহ আওয়াদ আল-জুহানি',          sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Abdullaah_3awwaad_Al-Juhaynee_128kbps', k: 128 },
    { id: 'maher',     n: 'মাহির ইবনে হামাদ আল-মুআইকিলি',        sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Maher_AlMuaiqly_64kbps',          k: 64 },
    { id: 'husary',    n: 'মাহমুদ খলিল আল-হুসারি',                sub: 'মিসর',                           f: 'Husary_128kbps',                        k: 128 },
    { id: 'hudhaify',  n: 'আলী ইবনে আব্দুর রহমান আল-হুযাইফি',     sub: 'মসজিদে নববীর (মদিনা) ইমাম',       f: 'Hudhaify_128kbps',                      k: 128 },
    { id: 'ayyoub',    n: 'মুহাম্মাদ আইয়ুব',                      sub: 'মসজিদে নববীর (মদিনা) ইমাম',       f: 'Muhammad_Ayyoub_128kbps',               k: 128 },
    { id: 'minshawi',  n: 'মুহাম্মাদ সিদ্দিক আল-মিনশাবি (মুরাত্তাল)', sub: 'মিসর',                         f: 'Minshawy_Murattal_128kbps',             k: 128 },
    { id: 'shatri',    n: 'আবু বকর আশ-শাত্রি',                    sub: '',                               f: 'Abu_Bakr_Ash-Shaatree_128kbps',         k: 128 },
    { id: 'basfar',    n: 'আব্দুল্লাহ বাসফার',                     sub: '',                               f: 'Abdullah_Basfar_192kbps',               k: 192 },
    { id: 'rifai',     n: 'হানি আর-রিফাঈ',                         sub: '',                               f: 'Hani_Rifai_192kbps',                    k: 192 }
  ];
  function reciterById(id) { for (var i = 0; i < RECITERS.length; i++) if (RECITERS[i].id === id) return RECITERS[i]; return RECITERS[0]; }
  function shortName(r) { var p = r.n.replace(/\s*\(.*\)\s*$/, '').split(' '); return p.slice(-2).join(' '); }

  var REPEATS = [['off', 'বন্ধ'], ['a2', 'আয়াত ২ বার'], ['a3', 'আয়াত ৩ বার'], ['a5', 'আয়াত ৫ বার'], ['ainf', 'আয়াত ∞'], ['sinf', 'পুরো সূরা ∞']];
  var SPEEDS = [0.75, 1, 1.25, 1.5];
  var SLEEPS = [[0, 'বন্ধ'], [15, '১৫ মি.'], [30, '৩০ মি.'], [45, '৪৫ মি.'], [60, '৬০ মি.']];
  var KEY = 'pt_qa_prefs';
  var P = { reciter: 'alafasy', speed: 1, repeat: 'off', follow: true };
  try { var sv = JSON.parse(localStorage.getItem(KEY) || 'null'); if (sv) { if (sv.reciter) P.reciter = sv.reciter; if (SPEEDS.indexOf(sv.speed) > -1) P.speed = sv.speed; if (sv.repeat) P.repeat = sv.repeat; if (typeof sv.follow === 'boolean') P.follow = sv.follow; } } catch (e) {}
  function savePrefs() { try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) {} }

  var S = { sura: 0, queue: [], i: -1, playing: false, rep: 0, err: 0, sleepAt: 0, sleepT: 0, hiddenPause: false };
  var audio = new Audio(); audio.preload = 'auto';
  var pre = new Audio(); pre.preload = 'metadata';          /* পরের আয়াত শুধু শুরুটা আগে ছুঁয়ে রাখি — পুরোটা দুইবার নামে না (ডেটা বাঁচাতে) */
  var UI = null, userScrollUntil = 0;

  /* ---------- কিউ: সূরার প্লে-তালিকা ---------- */
  function buildQueue(sura) {
    var q = [], n = App.quranModel[sura - 1].ayahs.length;
    if (sura !== 9) q.push({ t: 'bis', file: '001001', covers: [] });
    for (var a = 1; a <= n; a++) {
      if (sura === 1) {                       /* হাফস গণনা ↔ everyayah ফাইল: ১–৫ → ০০২–০০৬, ৬+৭ → ০০৭ */
        if (a <= 5) q.push({ t: 'ayah', file: pad3(1) + pad3(a + 1), covers: [a], ayah: a });
        else if (a === 6) q.push({ t: 'ayah', file: '001007', covers: [6, 7], ayah: 6 });
      } else q.push({ t: 'ayah', file: pad3(sura) + pad3(a), covers: [a], ayah: a });
    }
    return q;
  }
  function urlOf(item) { return BASE + reciterById(P.reciter).f + '/' + (item.t === 'bis' ? '001001' : item.file) + '.mp3'; }
  function indexOfAyah(q, a) { for (var i = 0; i < q.length; i++) if (q[i].covers.indexOf(a) > -1) return i; return 0; }

  /* ---------- চালানো ---------- */
  function playFrom(sura, ayah) {
    sura = +sura; ayah = +ayah || 1;
    if (!App.quranModel[sura - 1]) return;
    ensureUI();
    S.sura = sura; S.queue = buildQueue(sura);
    S.i = ayah > 1 ? indexOfAyah(S.queue, ayah) : 0;
    S.rep = 0; S.err = 0; S.hiddenPause = false;
    startItem();
    show(true);
  }
  function playSura(sura) {
    if (S.sura === +sura && S.i > -1 && S.queue.length) { toggle(); return; }
    playFrom(sura, 1);
  }
  function startItem() {
    var it = S.queue[S.i]; if (!it) return;
    audio.src = urlOf(it); audio.playbackRate = P.speed; try { audio.preservesPitch = true; } catch (e) {}
    var pr = audio.play(); S.playing = true;
    if (pr && pr.catch) pr.catch(function () { if (!S.err) { S.err = 1; setTimeout(function () { audio.load(); audio.play().catch(onFail); }, 500); } else onFail(); });
    var nx = S.queue[S.i + 1]; if (nx) pre.src = urlOf(nx);          /* পরেরটা আগে থেকে নামিয়ে রাখি, যাতে মাঝে থামতে না হয় */
    refreshUI(); applyHighlight(true);
  }
  function onFail() {
    S.playing = false; refreshUI(); msg('তিলাওয়াত লোড হয়নি — ইন্টারনেট সংযোগ দেখুন, তারপর আবার চালান');
  }
  function next(auto) {
    var it = S.queue[S.i], rp = P.repeat;
    if (auto && it) {                         /* রিপিটের নিয়ম */
      if (rp === 'ainf') { S.rep++; startItem(); return; }
      if ((rp === 'a2' || rp === 'a3' || rp === 'a5') && it.t === 'ayah') {
        var times = +rp.slice(1);
        if (S.rep + 1 < times) { S.rep++; startItem(); return; }
      }
    }
    S.rep = 0;
    if (S.i + 1 < S.queue.length) { S.i++; startItem(); return; }
    if (P.repeat === 'sinf') { S.i = 0; startItem(); return; }
    S.playing = false; S.i = S.queue.length - 1; refreshUI(); applyHighlight(false); msg('সূরা শেষ হয়েছে');
  }
  function prev() {
    if (audio.currentTime > 3) { audio.currentTime = 0; return; }
    S.rep = 0; if (S.i > 0) { S.i--; startItem(); } else audio.currentTime = 0;
  }
  function toggle() {
    if (S.i < 0) return;
    if (S.playing) { audio.pause(); S.playing = false; } else { var pr = audio.play(); S.playing = true; if (pr && pr.catch) pr.catch(onFail); S.hiddenPause = false; }
    refreshUI();
  }
  function stop() {
    audio.pause(); S.playing = false; S.i = -1; S.queue = []; S.sura = 0; clearSleep();
    clearHighlight(); show(false); closeSheet();
  }
  audio.addEventListener('ended', function () { next(true); });
  audio.addEventListener('error', function () { if (!S.playing) return; if (!S.err) { S.err = 1; setTimeout(function () { audio.load(); audio.play().catch(onFail); }, 600); } else onFail(); });
  audio.addEventListener('playing', function () { S.err = 0; S.playing = true; refreshUI(); });
  audio.addEventListener('timeupdate', function () { if (UI && audio.duration) UI.bar.style.width = Math.min(100, audio.currentTime / audio.duration * 100) + '%'; });

  /* ---------- হাইলাইট ও স্ক্রল ---------- */
  function currentCovers() { var it = S.queue[S.i]; return it && it.t === 'ayah' ? it.covers : []; }
  function clearHighlight() {
    try { if (window.CSS && CSS.highlights) CSS.highlights.delete('pt-qa'); } catch (e) {}
    Array.prototype.forEach.call(document.querySelectorAll('.qa-playing,.qa-num-on'), function (e) { e.classList.remove('qa-playing', 'qa-num-on'); });
  }
  function openSuraNow() {
    if (App.els.readerPanel && !App.els.readerPanel.classList.contains('hidden')) return { k: 'flow', s: App.currentOpenSuraIndex };
    if (App.els.trReaderPanel && !App.els.trReaderPanel.classList.contains('hidden')) {
      var f = App.els.trVerses.querySelector('.tr-ayah'); return f ? { k: 'tr', s: +f.getAttribute('data-sura') } : null;
    }
    return null;
  }
  function applyHighlight(scroll) {
    clearHighlight();
    var cv = currentCovers(), o = openSuraNow();
    if (!cv.length || !o || o.s !== S.sura) return;
    var first = cv[0], last = cv[cv.length - 1], target = null;
    if (o.k === 'tr') {
      cv.forEach(function (a) { var e = $('trayah-' + a); if (e) { e.classList.add('qa-playing'); if (!target) target = e; } });
    } else {
      var endEl = $('ayah-' + S.sura + '-' + last), prevEl = first > 1 ? $('ayah-' + S.sura + '-' + (first - 1)) : null;
      if (endEl) {
        endEl.classList.add('qa-num-on'); target = endEl;
        try {
          if (window.CSS && CSS.highlights && window.Highlight) {
            var r = document.createRange();
            if (prevEl) r.setStartAfter(prevEl);
            else {
              var w = document.createTreeWalker(App.els.verses, NodeFilter.SHOW_TEXT, null), tn;
              while ((tn = w.nextNode())) { if (tn.nodeValue.replace(/\s+/g, '')) break; }
              if (tn) r.setStart(tn, 0); else r.setStartBefore(endEl);
            }
            r.setEndBefore(endEl);
            CSS.highlights.set('pt-qa', new Highlight(r));
          }
        } catch (e) {}
      }
    }
    if (scroll && target && P.follow && Date.now() > userScrollUntil) { try { target.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) {} }
  }
  ['wheel', 'touchmove'].forEach(function (ev) { window.addEventListener(ev, function () { userScrollUntil = Date.now() + 6000; }, { passive: true }); });

  /* ---------- UI ---------- */
  var PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.4-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>';
  var PAUSE = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="5" width="4.2" height="14" rx="1.4"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.4"/></svg>';
  var PREV = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5.5v13M19 6.2v11.6a.8.8 0 0 1-1.25.66L9.6 12.66a.8.8 0 0 1 0-1.32l8.15-5.8A.8.8 0 0 1 19 6.2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var NEXT = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 5.5v13M5 6.2v11.6a.8.8 0 0 0 1.25.66l8.15-5.8a.8.8 0 0 0 0-1.32l-8.15-5.8A.8.8 0 0 0 5 6.2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var X = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>';
  var UP = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 14 6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function ensureUI() {
    if (UI) return;
    var mini = document.createElement('div'); mini.className = 'qa-mini'; mini.hidden = true;
    mini.innerHTML =
      '<i class="qa-bar"><u></u></i>' +
      '<button type="button" class="qa-ex" aria-label="প্লেয়ার বড় করুন">' + UP + '</button>' +
      '<div class="qa-info"><b class="qa-t"></b><small class="qa-s"></small></div>' +
      '<div class="qa-ctl"><button type="button" class="qa-b" data-c="prev" aria-label="আগের">' + PREV + '</button>' +
      '<button type="button" class="qa-b main" data-c="toggle" aria-label="চালান/থামান">' + PLAY + '</button>' +
      '<button type="button" class="qa-b" data-c="next" aria-label="পরের">' + NEXT + '</button>' +
      '<button type="button" class="qa-b x" data-c="stop" aria-label="বন্ধ করুন">' + X + '</button></div>' +
      '<div class="qa-msg" role="status"></div>';
    document.body.appendChild(mini);
    var veil = document.createElement('div'); veil.className = 'qa-veil';
    var sheet = document.createElement('div'); sheet.className = 'qa-sheet'; sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'তিলাওয়াত প্লেয়ার');
    document.body.appendChild(veil); document.body.appendChild(sheet);
    UI = { mini: mini, bar: mini.querySelector('.qa-bar u'), t: mini.querySelector('.qa-t'), s: mini.querySelector('.qa-s'), main: mini.querySelector('.main'), m: mini.querySelector('.qa-msg'), veil: veil, sheet: sheet, open: false };
    mini.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
      if (b.classList.contains('qa-ex')) { openSheet(); return; }
      var c = b.getAttribute('data-c');
      if (c === 'toggle') toggle(); else if (c === 'next') { S.rep = 0; if (S.i + 1 < S.queue.length) { S.i++; startItem(); } } else if (c === 'prev') prev(); else if (c === 'stop') stop();
    });
    mini.querySelector('.qa-info').addEventListener('click', openSheet);
    veil.addEventListener('click', closeSheet);
    sheet.addEventListener('click', onSheetClick);
    sheet.addEventListener('change', function (e) { if (e.target.id === 'qa-rec') { P.reciter = e.target.value; savePrefs(); renderSheet(); if (S.i > -1) { var keep = S.i; S.queue = buildQueue(S.sura); S.i = Math.min(keep, S.queue.length - 1); startItem(); } } });
    window.addEventListener('popstate', function () { if (UI && UI.open) hideSheet(); });
    setInterval(function () {                 /* কুরআন পেজ বন্ধ হলে তিলাওয়াত থামিয়ে দিই (ভুলে ব্যাকগ্রাউন্ডে বাজতে না থাকে) */
      if (!S.playing) return;
      try { var ov = window.frameElement && window.frameElement.parentElement; if (ov && (ov.hasAttribute('inert') || ov.getAttribute('aria-hidden') === 'true')) { audio.pause(); S.playing = false; S.hiddenPause = true; refreshUI(); } } catch (e) {}
    }, 900);
    setInterval(function () { if (S.playing) applyHighlight(false); }, 1500);       /* পড়ার পেজ বদলালে/ধীরে আঁকা শেষ হলে হাইলাইট ঠিক করে নিই */
  }
  function show(on) { ensureUI(); UI.mini.hidden = !on; document.documentElement.classList.toggle('qa-on', !!on); }
  var msgT = 0;
  function msg(t) { ensureUI(); UI.m.textContent = t; UI.m.classList.add('show'); clearTimeout(msgT); msgT = setTimeout(function () { UI.m.classList.remove('show'); }, 3500); }
  function refreshUI() {
    if (!UI) return;
    var it = S.queue[S.i], total = App.quranModel[S.sura - 1] ? App.quranModel[S.sura - 1].ayahs.length : 0, r = reciterById(P.reciter);
    var where = it ? (it.t === 'bis' ? 'বিসমিল্লাহ' : 'আয়াত ' + bn(it.covers.length > 1 ? it.covers[0] + '–' + it.covers[1] : it.ayah) + '/' + bn(total)) : '';
    UI.t.textContent = 'সূরা ' + (App.SURAH_BN[S.sura - 1] || '');
    UI.s.textContent = where + ' · ' + shortName(r);
    UI.where = where;
    UI.main.innerHTML = S.playing ? PAUSE : PLAY;
    if (UI.open) renderSheet();
  }

  /* ---------- বড় প্লেয়ার (শিট) ---------- */
  function openSheet() {
    ensureUI(); if (UI.open) return;
    UI.open = true; try { history.pushState({ qaSheet: 1 }, ''); } catch (e) {}
    renderSheet(); UI.veil.classList.add('on'); UI.sheet.classList.add('on'); UI.sheet.scrollTop = 0;
  }
  function hideSheet() { if (!UI || !UI.open) return; UI.open = false; UI.veil.classList.remove('on'); UI.sheet.classList.remove('on'); }
  function closeSheet() { if (!UI || !UI.open) return; if (history.state && history.state.qaSheet) history.back(); else hideSheet(); }
  function chips(list, cur, k) { return list.map(function (x) { var v = Array.isArray(x) ? x[0] : x, l = Array.isArray(x) ? x[1] : bn(x) + '×'; return '<button type="button" class="qa-chip' + (String(v) === String(cur) ? ' on' : '') + '" data-k="' + k + '" data-v="' + v + '">' + l + '</button>'; }).join(''); }
  function renderSheet() {
    var r = reciterById(P.reciter), left = S.sleepAt ? Math.max(0, Math.ceil((S.sleepAt - Date.now()) / 60000)) : 0;
    var opts = RECITERS.map(function (x) { return '<option value="' + x.id + '"' + (x.id === P.reciter ? ' selected' : '') + '>' + esc(x.n + (x.sub ? ' — ' + x.sub : '') + (x.k < 128 ? ' (' + bn(x.k) + 'kbps)' : '')) + '</option>'; }).join('');
    UI.sheet.innerHTML =
      '<div class="qa-grab"></div><div class="qa-hd"><div class="qa-ht">তিলাওয়াত</div><button type="button" class="qa-x" data-act="close" aria-label="বন্ধ করুন">' + X + '</button></div>' +
      '<div class="qa-now"><b>সূরা ' + esc(App.SURAH_BN[S.sura - 1] || '') + '</b><span>' + esc(UI.where || '') + '</span></div>' +
      '<div class="qa-big">' +
        '<button type="button" class="qa-bb" data-act="prev" aria-label="আগের">' + PREV + '</button>' +
        '<button type="button" class="qa-bb main" data-act="toggle" aria-label="চালান/থামান">' + (S.playing ? PAUSE : PLAY) + '</button>' +
        '<button type="button" class="qa-bb" data-act="next" aria-label="পরের">' + NEXT + '</button></div>' +
      '<div class="qa-lb">তিলাওয়াতকারী</div><select id="qa-rec" class="qa-sel" aria-label="তিলাওয়াতকারী">' + opts + '</select>' +
      '<div class="qa-lb">গতি</div><div class="qa-chips">' + SPEEDS.map(function (v) { return '<button type="button" class="qa-chip' + (v === P.speed ? ' on' : '') + '" data-k="speed" data-v="' + v + '">' + bn(v).replace('.', '.') + '×</button>'; }).join('') + '</div>' +
      '<div class="qa-lb">রিপিট</div><div class="qa-chips">' + chips(REPEATS, P.repeat, 'repeat') + '</div>' +
      '<div class="qa-lb">ঘুমের টাইমার' + (left ? ' — আর ' + bn(left) + ' মিনিট' : '') + '</div><div class="qa-chips">' + chips(SLEEPS, S.sleepMin || 0, 'sleep') + '</div>' +
      '<div class="qa-lb">লেখা অনুসরণ</div><div class="qa-chips"><button type="button" class="qa-chip' + (P.follow ? ' on' : '') + '" data-k="follow" data-v="1">তিলাওয়াতের সাথে লেখা স্ক্রল হবে</button></div>' +
      '<p class="qa-credit">তিলাওয়াতের সূত্র: <b>everyayah.com</b> — ' + esc(r.n) + '। অডিও ইন্টারনেট থেকে চলে, ফোনে জমা থাকে না।</p>';
  }
  function setSleep(min) {
    clearSleep(); S.sleepMin = min;
    if (min) { S.sleepAt = Date.now() + min * 60000; S.sleepT = setTimeout(function () { audio.pause(); S.playing = false; S.sleepAt = 0; S.sleepMin = 0; refreshUI(); msg('ঘুমের টাইমার শেষ — তিলাওয়াত থেমেছে'); }, min * 60000); }
  }
  function clearSleep() { clearTimeout(S.sleepT); S.sleepAt = 0; S.sleepMin = 0; }
  function onSheetClick(e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    var a = b.getAttribute('data-act'), k = b.getAttribute('data-k'), v = b.getAttribute('data-v');
    if (a === 'close') closeSheet(); else if (a === 'toggle') toggle(); else if (a === 'prev') prev(); else if (a === 'next') { S.rep = 0; if (S.i + 1 < S.queue.length) { S.i++; startItem(); } }
    else if (k === 'speed') { P.speed = +v; audio.playbackRate = P.speed; savePrefs(); renderSheet(); }
    else if (k === 'repeat') { P.repeat = v; S.rep = 0; savePrefs(); renderSheet(); }
    else if (k === 'sleep') { setSleep(+v); renderSheet(); }
    else if (k === 'follow') { P.follow = !P.follow; savePrefs(); renderSheet(); if (P.follow) applyHighlight(true); }
  }

  /* ---------- বাইরের জায়গা থেকে ডাকা ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-qa]') : null; if (!b) return;
    var k = b.getAttribute('data-qa');
    if (k === 'sura') { e.preventDefault(); playSura(b.getAttribute('data-sura')); }
    else if (k === 'ayah') {
      e.preventDefault(); e.stopPropagation();
      var card = b.closest('.tr-ayah'); if (card) playFrom(card.getAttribute('data-sura'), card.getAttribute('data-ayah'));
    }
  }, true);
  var origHero = App.heroStatsHtml;
  App.heroStatsHtml = function (sura) {
    return origHero(sura) + '<button type="button" class="qa-hero" data-qa="sura" data-sura="' + sura.index + '">' + PLAY + '<span>তিলাওয়াত শুনুন</span></button>';
  };
  window.QuranAudio = {
    playFrom: playFrom, playSura: playSura, toggle: toggle, stop: stop, isPlaying: function () { return S.playing; },
    ayahBtnHtml: function () { return '<button type="button" class="qa-abtn" data-qa="ayah" aria-label="এই আয়াত থেকে শুনুন" title="এই আয়াত থেকে শুনুন">' + PLAY + '</button>'; },
    reciters: RECITERS, _state: S
  };
})(window.QuranApp = window.QuranApp || {});
