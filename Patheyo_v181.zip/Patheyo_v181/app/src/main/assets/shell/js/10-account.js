/* =============================================================================
   ধাপ ৯ — অ্যাকাউন্ট ও ক্লাউড সিঙ্ক
   নেটিভ: PatheyoAuth (app/.../auth/AuthBridge.kt) — Google (Credential Manager) + ইমেইল, Firebase Auth,
          ক্লাউড = Realtime Database users/{uid}/backup  (শুধু নিজের uid পড়তে/লিখতে পারে)।
   ওয়েব:  প্রোফাইল বোতাম / সেটিংস → অ্যাকাউন্ট কেন্দ্র (#pf-sheet, মাঝখানের পপআপ)।
   সিঙ্ক: সেটিংসের ব্যাকআপ-ফাইলের একই লেখা (window.__ptBackup) — ডেটা বদলালে নিজে থেকে ক্লাউডে
          (অ্যাপ পেছনে গেলে / প্রতি ১০ মিনিটে, বদল থাকলে)। নতুন ফোনে প্রথম সাইন-ইনে ক্লাউডে হিসাব থাকলে
          জিজ্ঞেস করে ফেরত আনে। এই ফোনের অল্প ডেটা দিয়ে ক্লাউডের পুরনো হিসাব নিজে থেকে কখনো মোছে না।
   লগইন ঐচ্ছিক — অতিথি হিসেবে সব কাজ চলে।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window;
  var A = function () { return W.PatheyoAuth || null; };
  var CK = 'pt_cloud';                       /* {uid, on, at, fp, hold} — এই ফোনের সিঙ্কের অবস্থা (ব্যাকআপে যায় না) */
  var $ = function (id) { return D.getElementById(id); };
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(x) { return String(x).replace(/\d/g, function (d) { return BN[d]; }); }
  function jget(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function jset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function toast(t, type) { if (W.PT) PT.toast(t, { type: type || '' }); }

  var sheet = $('pf-sheet');
  if (!sheet) return;

  /* ---------------------------------------------------------------- নেটিভ কল (Promise) */
  var seq = 0, wait = {};
  W.__ptAuthCb = function (id, json) {
    var f = wait[id]; if (!f) return; delete wait[id];
    var r; try { r = JSON.parse(json); } catch (e) { r = { ok: false, msg: 'কাজটা করা গেল না' }; }
    if (r && r.state) S = r.state;
    f(r);
  };
  function call(fn) {
    var args = [].slice.call(arguments, 1);
    return new Promise(function (res) {
      var a = A(); if (!a || typeof a[fn] !== 'function') { res({ ok: false, code: 'na', msg: 'এই সুবিধা শুধু অ্যাপের ভেতরে কাজ করে।' }); return; }
      var id = 'a' + (++seq); wait[id] = res;
      try { a[fn].apply(a, [id].concat(args)); } catch (e) { delete wait[id]; res({ ok: false, msg: 'কাজটা করা গেল না' }); }
    });
  }
  var S = { signedIn: false };
  function readState() { try { var a = A(); if (a && a.state) S = JSON.parse(a.state()) || S; } catch (e) {} return S; }
  W.__ptAuthChanged = function (json) { try { S = JSON.parse(json); } catch (e) {} paintAll(); };

  /* ---------------------------------------------------------------- দেখানো */
  var view = 'guest', mode = 'in', busy = false;
  function show(v) {
    view = v; sheet.setAttribute('data-view', v);
    [].forEach.call(sheet.querySelectorAll('.ac-pane'), function (p) { p.hidden = (' ' + p.getAttribute('data-v') + ' ').indexOf(' ' + v + ' ') < 0; });
    var t = { guest: 'আপনার অ্যাকাউন্ট', email: 'ইমেইল দিয়ে', user: 'আমার অ্যাকাউন্ট', local: 'নাম ও ছবি', del: 'অ্যাকাউন্ট মোছা' }[v];
    $('pf-title').textContent = t || 'আপনার অ্যাকাউন্ট';
    sheet.querySelector('.ac-back').hidden = !(v === 'email' || v === 'local' || v === 'del');
    sheet.querySelector('.ac-back').setAttribute('data-ac-go', v === 'del' ? 'user' : 'guest');
    if (v === 'email') { var sg = sheet.querySelector('.ac-seg'); if (sg && W.PT) PT.seg(sg); setMode(mode); }
    if (v === 'user' || v === 'local') { if (W.__ptProfileFill) W.__ptProfileFill(); }
    if (v === 'del') { $('ac-del-err').hidden = true; $('ac-del-pass').value = ''; }
    errOff();
  }
  function setMode(m) {
    mode = m; sheet.setAttribute('data-mode', m);
    $('ac-submit').textContent = m === 'up' ? 'অ্যাকাউন্ট খুলুন' : 'সাইন-ইন করুন';
    $('ac-pass').setAttribute('autocomplete', m === 'up' ? 'new-password' : 'current-password');
    errOff();
  }
  function err(t, id) { var e = $(id || 'ac-err'); if (!e) return; e.textContent = t; e.hidden = !t; if (t && W.PT) PT.haptic('warn'); }
  function errOff() { err('', 'ac-err'); }
  function setBusy(b, btn) {
    busy = b; sheet.classList.toggle('is-busy', b);
    if (btn) { btn.disabled = b; btn.classList.toggle('is-loading', b); }
  }

  function provLabel(s) { return s.provider === 'google' ? 'Google' : 'ইমেইল'; }
  function fmtAgo(ms) {
    if (!ms) return '';
    var d = Math.round((Date.now() - ms) / 60000);
    if (d < 1) return 'এইমাত্র'; if (d < 60) return bn(d) + ' মিনিট আগে';
    var h = Math.round(d / 60); if (h < 24) return bn(h) + ' ঘণ্টা আগে';
    var dt = new Date(ms); return bn(dt.getDate()) + ' ' + ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'][dt.getMonth()];
  }
  function paintUser() {
    if (!S.signedIn) return;
    $('ac-mail').textContent = S.email || '';
    var pv = $('ac-prov'); pv.innerHTML = (W.PT ? PT.icon(S.provider === 'google' ? 'google' : 'mail', 'pt-ic--sm') : '') + provLabel(S);
    $('ac-verify').hidden = !!S.verified;
    var c = jget(CK) || {};
    $('ac-auto').checked = c.on !== false;
    $('ac-last').textContent = c.hold ? 'বিরতি — "এখনই সিঙ্ক" চাপলে চালু হবে' : (c.at && c.uid === S.uid ? 'শেষ সিঙ্ক: ' + fmtAgo(c.at) : 'এখনো সিঙ্ক হয়নি');
    sheet.classList.toggle('ac-email-user', S.provider !== 'google');
  }
  function paintSettings() {
    var t = $('st-acc-t'), s = $('st-acc-s'), img = $('st-acc-img'); if (!t) return;
    var p = jget('pt_profile') || {};
    if (S.signedIn) {
      t.textContent = p.name || S.name || 'আমার অ্যাকাউন্ট';
      var c = jget(CK) || {};
      s.textContent = (S.email || '') + (c.at && c.uid === S.uid ? ' · সিঙ্ক ' + fmtAgo(c.at) : '');
    } else { t.textContent = 'সাইন-ইন করুন'; s.textContent = 'নিজে থেকে ক্লাউড ব্যাকআপ — নতুন ফোনে সব ফেরত'; }
    if (p.photo) { img.src = p.photo; img.hidden = false; } else { img.hidden = true; img.removeAttribute('src'); }
    var hb = $('btn-profile'); if (hb) hb.classList.toggle('is-signed', !!S.signedIn);
  }
  function paintAll() {
    paintSettings();
    if (!sheet.hidden) { if (S.signedIn && (view === 'guest' || view === 'email')) show('user'); else if (!S.signedIn && (view === 'user' || view === 'del')) show('guest'); paintUser(); }
  }

  W.__ptAccountOpen = function () {
    if (!W.PT) return;
    readState();
    show(S.signedIn ? 'user' : 'guest'); paintUser();
    PT.sheet.open(sheet);
  };
  var row = $('st-acc-row'); if (row) row.addEventListener('click', W.__ptAccountOpen);

  /* ---------------------------------------------------------------- সাইন-ইনের পরে */
  function adoptProfile(isNew) {
    var p = jget('pt_profile') || {};
    var changed = false;
    if (S.name && (!p.name || isNew)) { p.name = S.name; changed = true; }
    if (changed) { jset('pt_profile', p); if (W.__ptPaintProfile) W.__ptPaintProfile(); }
    if (!p.photo && S.photo) call('photo').then(function (r) {
      if (r && r.ok && r.data) { var q = jget('pt_profile') || {}; q.photo = r.data; jset('pt_profile', q); if (W.__ptPaintProfile) W.__ptPaintProfile(); paintSettings(); if (!sheet.hidden && W.__ptProfileFill) W.__ptProfileFill(); }
    });
  }
  function afterSignIn(r, how) {
    S = r.state || readState();
    adoptProfile(r.isNew);
    show('user'); paintUser(); paintSettings();
    toast(how === 'up' ? 'অ্যাকাউন্ট খোলা হয়েছে — ইমেইল যাচাই করে নিন' : 'আসসালামু আলাইকুম' + (S.name ? ', ' + S.name.split(/\s+/)[0] : '') + '!', 'success');
    firstSync();
  }

  /* ---------------------------------------------------------------- ক্লাউড সিঙ্ক */
  var B = function () { return W.__ptBackup || null; };
  function cloudState() { var c = jget(CK) || {}; if (c.uid !== S.uid) c = { uid: S.uid, on: true }; return c; }

  function push(force) {
    if (!S.signedIn || !B()) return Promise.resolve(false);
    var c = cloudState();
    if (!force && (c.on === false || c.hold)) return Promise.resolve(false);
    var fp = B().fingerprint();
    if (!force && fp === c.fp) return Promise.resolve(false);
    return call('cloudSave', B().make()).then(function (r) {
      if (r && r.ok) { c.fp = fp; c.at = Date.now(); c.hold = false; jset(CK, c); paintUser(); paintSettings(); return true; }
      return false;
    });
  }

  /** নতুন ফোন / নতুন সাইন-ইন: ক্লাউডে হিসাব থাকলে জিজ্ঞেস করে আনা, না থাকলে এই ফোনেরটা পাঠানো */
  function firstSync() {
    if (!S.signedIn || !B()) return;
    var c = cloudState();
    if (c.at) { push(false); return; }          /* এই অ্যাকাউন্ট এই ফোনে আগেই সিঙ্ক হয়েছে */
    call('cloudLoad').then(function (r) {
      if (!r || !r.ok) return;
      if (r.empty || !r.data) { push(true); return; }
      var pk = B().peek(r.data);
      if (pk && pk.fp === B().fingerprint()) { c.fp = pk.fp; c.at = Date.now(); jset(CK, c); paintUser(); return; }
      var localN = B().describe(B().collect()).length;
      PT.dialog({
        icon: 'cloud-check', title: 'ক্লাউডে আপনার হিসাব আছে',
        body: 'শেষ সিঙ্ক ' + fmtAgo(r.at) + (r.device ? ' (' + r.device + ')' : '') + '। ' + (pk && pk.list.length ? pk.list.slice(0, 3).join(' · ') + '। ' : '') +
          'এই ফোনে ফিরিয়ে আনবেন?' + (localN ? ' (এই ফোনের এখনকার হিসাব তার জায়গায় বসবে)' : ''),
        ok: 'ফিরিয়ে আনুন', cancel: 'এখন না'
      }).then(function (yes) {
        if (yes) { restoreFrom(r.data); return; }
        c.hold = true; jset(CK, c); paintUser();      /* ক্লাউডেরটা নিজে থেকে মুছব না — ইউজার "এখনই সিঙ্ক" চাপলে তবেই */
      });
    });
  }
  function restoreFrom(text) {
    var res = B().restoreText(text);
    if (res === 'ok') { var c = cloudState(); c.at = Date.now(); c.hold = false; c.fp = (B().peek(text) || {}).fp; jset(CK, c); toast('ক্লাউড থেকে আনা হচ্ছে… অ্যাপ নতুন করে খুলছে', 'success'); }
    else toast(res === 'empty' ? 'ক্লাউডে ফেরত আনার মতো কিছু নেই' : 'ক্লাউডের ডেটা পড়া গেল না', 'danger');
  }

  /* স্বয়ংক্রিয়: অ্যাপ পেছনে গেলে, আর খোলা থাকলে প্রতি ১০ মিনিটে (বদল থাকলে) */
  var lastTry = 0;
  function autoPush() { if (Date.now() - lastTry < 30000) return; lastTry = Date.now(); push(false); }
  D.addEventListener('visibilitychange', function () { if (D.visibilityState === 'hidden') autoPush(); });
  setInterval(autoPush, 600000);

  /* ---------------------------------------------------------------- বোতাম */
  sheet.addEventListener('click', function (e) {
    var go = e.target.closest('[data-ac-go]'); if (go) { show(go.getAttribute('data-ac-go')); if (go.getAttribute('data-ac-go') === 'user') paintUser(); return; }
    var m = e.target.closest('[data-ac-mode]'); if (m) { setMode(m.getAttribute('data-ac-mode')); return; }
    var b = e.target.closest('[data-ac]'); if (!b || busy) return;
    var a = b.getAttribute('data-ac');
    if (a === 'google') {
      setBusy(true, b);
      call('google').then(function (r) {
        setBusy(false, b);
        if (r.ok) afterSignIn(r, 'google'); else if (r.code !== 'cancel') toast(r.msg || 'Google সাইন-ইন হলো না', 'danger');
      });
    } else if (a === 'eye') {
      var pi = $('ac-pass'), shown = pi.type === 'text'; pi.type = shown ? 'password' : 'text';
      b.innerHTML = W.PT ? PT.icon(shown ? 'eye' : 'eye-off') : ''; b.setAttribute('aria-label', shown ? 'পাসওয়ার্ড দেখান' : 'পাসওয়ার্ড লুকান');
    } else if (a === 'forgot') {
      var em = $('ac-email').value.trim();
      if (!/^\S+@\S+\.\S+$/.test(em)) { err('আগে ইমেইল ঠিকানাটা লিখুন, তারপর এখানে চাপুন।'); $('ac-email').focus(); return; }
      setBusy(true, b);
      call('reset', em).then(function (r) { setBusy(false, b); if (r.ok) { errOff(); toast('পাসওয়ার্ড বদলানোর লিংক ' + em + '-এ পাঠানো হয়েছে', 'success'); } else err(r.msg); });
    } else if (a === 'resend') {
      setBusy(true, b); call('sendVerify').then(function (r) { setBusy(false, b); toast(r.ok ? 'যাচাইয়ের ইমেইল আবার পাঠানো হয়েছে' : r.msg, r.ok ? 'success' : 'danger'); });
    } else if (a === 'verified') {
      setBusy(true, b); call('reload').then(function (r) { setBusy(false, b); paintUser(); toast(S.verified ? 'ইমেইল যাচাই হয়েছে — জাযাকাল্লাহ' : 'এখনো যাচাই হয়নি — ইমেইলের লিংকে চাপুন', S.verified ? 'success' : ''); });
    } else if (a === 'push') {
      var c = cloudState();
      var go2 = function () { setBusy(true, b); push(true).then(function (ok) { setBusy(false, b); toast(ok ? 'ক্লাউডে সিঙ্ক হয়েছে' : 'সিঙ্ক হলো না — ইন্টারনেট দেখুন', ok ? 'success' : 'danger'); }); };
      if (c.hold) PT.dialog({ icon: 'upload', title: 'ক্লাউডের হিসাব বদলে যাবে', body: 'ক্লাউডে থাকা আগের হিসাবের জায়গায় এই ফোনের হিসাব বসবে।', ok: 'সিঙ্ক করুন' }).then(function (y) { if (y) go2(); });
      else go2();
    } else if (a === 'pull') {
      setBusy(true, b);
      call('cloudLoad').then(function (r) {
        setBusy(false, b);
        if (!r.ok) { toast(r.msg, 'danger'); return; }
        if (r.empty || !r.data) { toast('ক্লাউডে এখনো কিছু নেই — "এখনই সিঙ্ক" চাপুন'); return; }
        var pk = B() && B().peek(r.data);
        PT.dialog({ icon: 'download', title: 'ক্লাউড থেকে ফিরিয়ে আনবেন?', body: 'শেষ সিঙ্ক ' + fmtAgo(r.at) + (r.device ? ' (' + r.device + ')' : '') + '। ' + (pk && pk.list.length ? pk.list.slice(0, 3).join(' · ') + '। ' : '') + 'এই ফোনের এখনকার হিসাব তার জায়গায় বসবে।', ok: 'ফিরিয়ে আনুন' })
          .then(function (y) { if (y) restoreFrom(r.data); });
      });
    } else if (a === 'signout') {
      PT.dialog({ icon: 'logout', title: 'সাইন-আউট করবেন?', body: 'এই ফোনের সব হিসাব যেমন আছে তেমনই থাকবে। আবার সাইন-ইন করলে সিঙ্ক চালু হবে।', ok: 'সাইন-আউট' }).then(function (y) {
        if (!y) return;
        push(false).then(function () { return call('signOut'); }).then(function () { S = { signedIn: false }; show('guest'); paintSettings(); toast('সাইন-আউট হয়েছে'); });
      });
    } else if (a === 'delete') {
      var pw = $('ac-del-pass').value;
      if (S.provider !== 'google' && !pw) { err('পাসওয়ার্ড দিন।', 'ac-del-err'); return; }
      setBusy(true, b);
      call('deleteAccount', S.provider === 'google' ? '' : pw).then(function (r) {
        setBusy(false, b);
        if (r.ok) { try { localStorage.removeItem(CK); } catch (e) {} S = { signedIn: false }; show('guest'); paintSettings(); toast('অ্যাকাউন্ট ও ক্লাউডের ডেটা মুছে ফেলা হয়েছে', 'success'); }
        else if (r.code !== 'cancel') err(r.msg, 'ac-del-err');
      });
    }
  });

  $('ac-form').addEventListener('submit', function (e) {
    e.preventDefault(); if (busy) return;
    var name = $('ac-name').value.trim(), em = $('ac-email').value.trim(), pw = $('ac-pass').value;
    if (mode === 'up' && name.length < 2) { err('আপনার নাম লিখুন।'); $('ac-name').focus(); return; }
    if (!/^\S+@\S+\.\S+$/.test(em)) { err('ইমেইল ঠিকানাটা সঠিক নয়।'); $('ac-email').focus(); return; }
    if (pw.length < 6) { err('পাসওয়ার্ড অন্তত ৬ অক্ষরের দিন।'); $('ac-pass').focus(); return; }
    var btn = $('ac-submit'); setBusy(true, btn);
    (mode === 'up' ? call('emailUp', name, em, pw) : call('emailIn', em, pw)).then(function (r) {
      setBusy(false, btn);
      if (r.ok) { $('ac-pass').value = ''; afterSignIn(r, mode); }
      else { err(r.msg); if (r.code === 'exists') setTimeout(function () { var sg = sheet.querySelector('.ac-seg'); if (sg && sg.ptSelect) sg.ptSelect(0); setMode('in'); err(r.msg); }, 10); }
    });
  });
  var seg = sheet.querySelector('.ac-seg');
  if (seg) seg.addEventListener('pt:change', function (e) { setMode(e.detail.index ? 'up' : 'in'); });

  $('ac-auto').addEventListener('change', function () { var c = cloudState(); c.on = this.checked; if (c.on) c.hold = false; jset(CK, c); paintUser(); if (c.on) push(false); });

  /* সাইন-ইন অবস্থায় নাম বদলালে অ্যাকাউন্টেও (সেভ বোতামের নিজের কাজ 09-home.js করে) */
  $('pf-save').addEventListener('click', function () {
    if (!S.signedIn) return;
    var n = $('pf-name').value.trim(); if (n && n !== S.name) call('setName', n);
  });

  /* ---------------------------------------------------------------- শুরু */
  readState(); paintSettings();
  if (S.signedIn) setTimeout(function () { var c = cloudState(); if (!c.at && !c.hold) firstSync(); else push(false); }, 4000);
})();
