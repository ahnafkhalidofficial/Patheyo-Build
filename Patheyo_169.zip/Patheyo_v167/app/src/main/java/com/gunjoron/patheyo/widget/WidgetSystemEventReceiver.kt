package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/WidgetSystemEventReceiver.kt
//
// ✅ v24: যেসব সিস্টেম ইভেন্টে Android অ্যালার্ম মুছে ফেলে বা "এখন কয়টা বাজে" বদলে যায়, সেখানে উইজেট সাথে
// সাথে হার্ড রিসেট হয়। সবগুলোই implicit-broadcast নিষেধাজ্ঞার (Android 8+) ছাড়প্রাপ্ত, ম্যানিফেস্টে নিবন্ধন বৈধ:
//   • ACTION_TIME_CHANGED / ACTION_DATE_CHANGED / ACTION_TIMEZONE_CHANGED — ইউজার/নেটওয়ার্ক সময়-তারিখ-টাইমজোন
//     বদলালে (নাহলে অ্যালার্ম ভুল সময়ে থেকে যায়, তারিখ আটকে থাকে)
//   • ACTION_MY_PACKAGE_REPLACED — অ্যাপ আপডেটের পর সব অ্যালার্ম বাতিল হয়ে যায়
//   • ACTION_LOCKED_BOOT_COMPLETED / BOOT_COMPLETED — রিবুট (BootCompletedReceiver আলাদা, এটা শুধু দ্রুত রিসেট)
//   • ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED (API 31+) — Exact-Alarm অনুমতি বদলালে
// ইভেন্টগুলো সিস্টেম-সুরক্ষিত (protected) ব্রডকাস্ট, তাই বাইরের অ্যাপ নকল করতে পারে না।

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class WidgetSystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        val pending = try { goAsync() } catch (_: Throwable) { null }
        val job = Runnable {
            try {
                WidgetRefreshScheduler.hardReset(ctx)
                // সময়/টাইমজোন/অ্যাপ-আপডেটে আজান ও নোটিফিকেশন অ্যালার্মও নতুন করে (BootCompletedReceiver-এর মতো)
                try { com.gunjoron.patheyo.alarm.AlarmScheduler.scheduleAllAlarms(ctx) } catch (_: Throwable) {}
                try { com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(ctx) } catch (_: Throwable) {}
                try { com.gunjoron.patheyo.datecard.DateCardScheduler.schedule(ctx) } catch (_: Throwable) {}
            } catch (_: Throwable) {
            } finally {
                try { pending?.finish() } catch (_: Throwable) {}
            }
        }
        if (pending != null) {
            try { Thread(job, "patheyo-widget-sysevent").start() } catch (_: Throwable) { job.run() }
        } else job.run()
    }
}
