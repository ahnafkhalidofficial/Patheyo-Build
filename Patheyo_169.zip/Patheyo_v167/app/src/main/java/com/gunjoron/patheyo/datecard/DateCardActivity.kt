package com.gunjoron.patheyo.datecard

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.graphics.drawable.GradientDrawable.Orientation
import com.gunjoron.patheyo.MainActivity
import com.gunjoron.patheyo.alarm.AzanLogo
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.graphics.PixelFormat
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.Executors

/**
 * তারিখ-কার্ডের স্ক্রিন: আজকের কার্ডের প্রিভিউ, ১২টি ইসলামিক থিম (বা "অটো" = প্রতিদিন নতুন), পোস্ট/স্টোরি মাপ,
 * ফোনের গ্যালারি থেকে নিজের ব্যাকগ্রাউন্ড, শেয়ার / গ্যালারিতে সেভ, আর রাত ১২টার অটো-তৈরির সুইচ।
 */
class DateCardActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: DateCardPrefs
    private lateinit var preview: ImageView
    private lateinit var themeNote: TextView
    private lateinit var themeRow: LinearLayout
    private lateinit var formatRow: LinearLayout
    private lateinit var photoBox: LinearLayout
    private lateinit var removePhotoBtn: TextView
    private var token = 0
    private var current: Bitmap? = null
    private var wantShare = false

    private val NAVY = Color.parseColor("#0E264D")
    private val CARD = Color.parseColor("#14305A")
    private val GOLD = Color.parseColor("#E5B94A")
    private val DIM = Color.parseColor("#9FB3D1")

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) importPhoto(uri) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        prefs = DateCardPrefs(this)
        wantShare = intent?.getBooleanExtra("share", false) == true
        setContentView(buildUi())
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
        refreshAll()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("share", false)) { wantShare = true; renderPreview() }
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdownNow()
    }

    // ------------------------------------------------------------------ UI গঠন

    private fun tv(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 14f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) Color.parseColor("#1B1B1B") else Color.WHITE)
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); if (filled) setColor(GOLD) else { setColor(Color.parseColor("#0FFFFFFF")); setStroke(dp(1), Color.parseColor("#33FFFFFF")) } }
        setPadding(dp(16), dp(11), dp(16), dp(11))
        setOnClickListener { onClick() }
    }

    private fun label(t: String) = tv(t, 12.5f, GOLD, true).apply { letterSpacing = 0.04f; setPadding(dp(2), dp(22), 0, dp(10)) }

    private fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(10), dp(10), dp(10))
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(CARD); setStroke(dp(1), Color.parseColor("#1AFFFFFF")) }
        addView(tv(text, 14.5f).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        addView(SwitchCompat(this@DateCardActivity).apply { isChecked = checked; setOnCheckedChangeListener { _, v -> onChange(v) } })
    }

    /** হোম/অন্য ফিচারের নিচের নেভিগেশনের আইকন (SVG পাথের মতোই), stroke-only */
    private class NavIcon(private val kind: Int, private val col: Int, private val d: Float) : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.8f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        override fun draw(c: Canvas) {
            p.color = col
            val sc = bounds.width() / 24f
            c.save(); c.translate(bounds.left.toFloat(), bounds.top.toFloat()); c.scale(sc, sc)
            val path = Path()
            when (kind) {
                0 -> { path.moveTo(4f, 11.5f); path.lineTo(12f, 4f); path.lineTo(20f, 11.5f)
                    path.moveTo(6f, 10f); path.lineTo(6f, 19f); path.lineTo(10.5f, 20f); path.lineTo(10.5f, 14.5f); path.lineTo(13.5f, 14.5f); path.lineTo(13.5f, 20f); path.lineTo(18f, 19f); path.lineTo(18f, 10f) }
                1 -> { path.moveTo(8f, 21f); path.lineTo(8f, 15f); path.cubicTo(8f, 9.5f, 16f, 9.5f, 16f, 15f); path.lineTo(16f, 21f)
                    path.moveTo(12f, 11f); path.lineTo(12f, 7.5f)
                    path.moveTo(3f, 21f); path.lineTo(3f, 12.8f); path.lineTo(4.25f, 10.5f); path.lineTo(5.5f, 12.8f); path.lineTo(5.5f, 21f)
                    path.moveTo(18.5f, 21f); path.lineTo(18.5f, 12.8f); path.lineTo(19.75f, 10.5f); path.lineTo(21f, 12.8f); path.lineTo(21f, 21f)
                    path.moveTo(2f, 21f); path.lineTo(22f, 21f) }
                2 -> { path.moveTo(12f, 5.5f); path.cubicTo(10.4f, 4.5f, 8.4f, 4.1f, 6f, 4.3f); path.lineTo(6f, 17.7f); path.cubicTo(8.4f, 17.5f, 10.4f, 17.9f, 12f, 18.9f)
                    path.cubicTo(13.6f, 17.9f, 15.6f, 17.5f, 18f, 17.7f); path.lineTo(18f, 4.3f); path.cubicTo(15.6f, 4.1f, 13.6f, 4.5f, 12f, 5.5f)
                    path.moveTo(12f, 5.5f); path.lineTo(12f, 18.9f) }
                3 -> { path.addRoundRect(RectF(5f, 3.5f, 19f, 20f), 1.6f, 1.6f, Path.Direction.CW)
                    path.moveTo(5f, 18.5f); path.lineTo(19f, 17f)
                    path.moveTo(9f, 8f); path.lineTo(15f, 8f); path.moveTo(9f, 11f); path.lineTo(13f, 11f) }
                else -> { p.style = Paint.Style.FILL; c.drawCircle(5f, 12f, 1.3f, p); c.drawCircle(12f, 12f, 1.3f, p); c.drawCircle(19f, 12f, 1.3f, p); c.restore(); return }
            }
            c.drawPath(path, p); c.restore()
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
        override fun getIntrinsicWidth() = d.toInt()
        override fun getIntrinsicHeight() = d.toInt()
    }

    private fun goNav(index: Int) {
        run {
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("nav", index)
            })
        }
        finish()
    }

    private fun buildHeader(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(12))
        }
        val logo = ImageView(this).apply {
            try { setImageBitmap(AzanLogo.circle(this@DateCardActivity, dp(54) * 2)) } catch (_: Throwable) {}
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        bar.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(12) })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(tv("তারিখ-কার্ড", 20f, Color.WHITE, true))
        ht.addView(tv("প্রতি রাত ১২টায় নিজে তৈরি হয়", 12.5f, DIM).apply { setPadding(0, dp(2), 0, 0) })
        bar.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        val back = TextView(this).apply {
            text = "✕"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.parseColor("#14FFFFFF")); setStroke(dp(1), Color.parseColor("#26FFFFFF")) }
            setOnClickListener { finish() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(bar)
        wrap.addView(View(this).apply {
            background = GradientDrawable(Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, Color.parseColor("#99E5B94A"), Color.TRANSPARENT))
        }, LinearLayout.LayoutParams(-1, dp(1)))
        return wrap
    }

    private fun buildFooter(): View {
        val names = arrayOf("হোম", "নামাজ", "কুরআন", "হাদিস", "আরও")
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0A1E3F")) }
        wrap.addView(View(this).apply { setBackgroundColor(Color.parseColor("#26FFFFFF")) }, LinearLayout.LayoutParams(-1, dp(1)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        names.forEachIndexed { i, n ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(4))
                setOnClickListener { goNav(i) }
            }
            val ic = ImageView(this).apply { setImageDrawable(NavIcon(i, DIM, dp(24).toFloat())) }
            item.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(tv(n, 11.5f, DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
            row.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        wrap.addView(row)
        return wrap
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(NAVY) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(28)) }
        scroll.addView(col)
        val footer = buildFooter()
        root.addView(buildHeader(), LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }

        // প্রিভিউ
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setBackgroundColor(CARD)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(22).toFloat()) }
            }
            elevation = dp(10).toFloat()
        }
        col.addView(preview, LinearLayout.LayoutParams(-1, 10).apply { topMargin = dp(14) })
        themeNote = tv("", 13f, DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        col.addView(themeNote, LinearLayout.LayoutParams(-1, -2))

        // শেয়ার / সেভ
        val acts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        acts.addView(pill("শেয়ার করুন", true) { shareNow() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            acts.addView(pill("গ্যালারিতে সেভ", false) { saveNow() }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(acts, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // থিম
        col.addView(label("থিম বাছুন"))
        themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(themeRow) })

        // মাপ
        col.addView(label("কার্ডের মাপ"))
        formatRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(formatRow)

        // ব্যাকগ্রাউন্ড
        col.addView(label("নিজের ব্যাকগ্রাউন্ড"))
        col.addView(pill("ফোনের গ্যালারি থেকে ছবি বাছুন", false) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }, LinearLayout.LayoutParams(-1, -2))
        photoBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        photoBox.addView(tv("ছবির ওপর কালো পর্দা (লেখা পড়ার সুবিধায়)", 13f, DIM).apply { setPadding(dp(2), dp(14), 0, dp(4)) })
        photoBox.addView(SeekBar(this).apply {
            max = 80; progress = prefs.scrim
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { prefs.scrim = s?.progress ?: 45; renderPreview() }
            })
        })
        removePhotoBtn = pill("ছবি সরিয়ে থিমের ব্যাকগ্রাউন্ডে ফিরুন", false) { prefs.usePhoto = false; refreshAll() }
        photoBox.addView(removePhotoBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(photoBox)

        // অটো
        col.addView(label("স্বয়ংক্রিয়"))
        val sw = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun gap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        sw.addView(switchRow("প্রতিদিন রাত ১২টায় নিজে তৈরি করুন", prefs.autoDaily) { prefs.autoDaily = it; DateCardScheduler.schedule(this) }, gap())
        sw.addView(switchRow("তৈরি হলে নোটিফিকেশনে দেখান (শব্দ হয় না)", prefs.notify) { prefs.notify = it }, gap())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            sw.addView(switchRow("প্রতিদিনের কার্ড নিজে গ্যালারিতে সেভ করুন", prefs.saveGallery) { prefs.saveGallery = it }, gap())
        }
        col.addView(sw)
        col.addView(tv("হিজরি তারিখ অ্যাপের হোম/উইজেটের হিসাব মেনেই আসে।", 12f, DIM).apply { setPadding(dp(2), dp(10), 0, 0) })
        return root
    }

    // ------------------------------------------------------------------ অবস্থা অনুযায়ী পুনর্গঠন

    private fun refreshAll() {
        buildFormatChips()
        buildThemeChips()
        photoBox.visibility = if (prefs.usePhoto) View.VISIBLE else View.GONE
        renderPreview()
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(if (selected) Color.parseColor("#1B1B1B") else Color.WHITE)
        background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(if (selected) GOLD else CARD) }
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setOnClickListener { onClick() }
    }

    private fun buildFormatChips() {
        formatRow.removeAllViews()
        val lp = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) } }
        formatRow.addView(chip("পোস্ট (৪:৫)", prefs.format == "post") { prefs.format = "post"; refreshAll() }, lp())
        formatRow.addView(chip("স্টোরি (৯:১৬)", prefs.format == "story") { prefs.format = "story"; refreshAll() }, lp())
    }

    private fun buildThemeChips() {
        themeRow.removeAllViews()
        val tw = dp(78); val th = (tw * 1.25f).toInt()
        fun cell(title: String, selected: Boolean, thumb: Bitmap?, onClick: () -> Unit): View {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 0, dp(10), 0) }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setBackgroundColor(CARD)
                if (thumb != null) setImageBitmap(thumb)
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat()) }
                }
                foreground = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(if (selected) 3 else 1), if (selected) GOLD else Color.parseColor("#33FFFFFF")) }
            }
            box.addView(iv, LinearLayout.LayoutParams(tw, th))
            box.addView(tv(title, 11.5f, if (selected) GOLD else DIM, selected).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0); maxLines = 2; width = tw })
            box.setOnClickListener { onClick() }
            return box
        }
        val sel = prefs.theme
        val autoCell = cell("অটো (প্রতিদিন নতুন)", sel == "auto", null) { prefs.theme = "auto"; refreshAll() }
        themeRow.addView(autoCell)
        // থাম্বনেইল পেছনে আঁকা
        val info = DateCardRenderer.infoFor(this)
        val holders = HashMap<String, ImageView>()
        DateCardThemes.ALL.forEach { t ->
            val v = cell(t.name, sel == t.id, null) { prefs.theme = t.id; refreshAll() }
            themeRow.addView(v)
            holders[t.id] = ((v as LinearLayout).getChildAt(0)) as ImageView
        }
        ((autoCell as LinearLayout).getChildAt(0) as ImageView).setImageDrawable(null)
        val ctx = applicationContext
        val fmt = prefs.format
        worker.execute {
            try {
                DateCardThemes.ALL.forEach { t ->
                    val b = DateCardRenderer.render(ctx, info, t, fmt, null, 0, 240)
                    ui.post { holders[t.id]?.setImageBitmap(b) }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun renderPreview() {
        val my = ++token
        val w = resources.displayMetrics.widthPixels - dp(32)
        val ratio = DateCardRenderer.ratio(prefs.format)
        preview.layoutParams = (preview.layoutParams as LinearLayout.LayoutParams).apply { width = -1; height = (w * ratio).toInt() }
        val ctx = applicationContext
        worker.execute {
            try {
                val now = System.currentTimeMillis()
                val bmp = DateCardRenderer.renderFor(ctx, now, prefs, 1080)
                val info = DateCardRenderer.infoFor(ctx, now)
                val name = if (prefs.usePhoto) "আপনার ছবি" else DateCardThemes.forDay(prefs.theme, info.dayOfYear, info.year).name
                ui.post {
                    if (my != token || isFinishing) return@post
                    current = bmp
                    preview.setImageBitmap(bmp)
                    themeNote.text = (if (prefs.usePhoto) "ব্যাকগ্রাউন্ড: " else if (prefs.theme == "auto") "আজকের থিম (অটো): " else "থিম: ") + name
                    if (wantShare) { wantShare = false; shareNow() }
                }
            } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------ ছবি বাছাই

    private fun importPhoto(uri: Uri) {
        val ctx = applicationContext
        worker.execute {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: throw IllegalStateException()
                val deg = try {
                    contentResolver.openInputStream(uri)?.use {
                        when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                } catch (_: Throwable) { 0f }
                if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
                DateCardPrefs(ctx).photoFile().outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                bmp.recycle()
                ui.post { prefs.usePhoto = true; refreshAll() }
            } catch (_: Throwable) {
                ui.post { Toast.makeText(this, "ছবিটা খোলা যায়নি, অন্য ছবি বাছুন", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    // ------------------------------------------------------------------ শেয়ার / সেভ

    private fun shareNow() {
        val bmp = current ?: run { Toast.makeText(this, "কার্ড তৈরি হচ্ছে, একটু অপেক্ষা করুন", Toast.LENGTH_SHORT).show(); return }
        val uri = DateCardGenerator.shareUri(this, bmp) ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(send, "শেয়ার করুন").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) {}
    }

    private fun saveNow() {
        val bmp = current ?: return
        val ok = DateCardGenerator.saveToGallery(this, bmp, "patheyo_datecard_" + System.currentTimeMillis())
        Toast.makeText(this, if (ok) "গ্যালারির Pictures/Patheyo ফোল্ডারে সেভ হয়েছে" else "সেভ করা যায়নি", Toast.LENGTH_SHORT).show()
    }
}
