/* পাথেয় — শেয়ার কার্ড (আয়াত / হাদিস / দোয়া)।
   দোয়া, হাদিস ও কুরআন — তিন ফিচারই এই একটি ফাইল ব্যবহার করে:
     <script src="https://appassets.patheyo.invalid/shared/share-card.js"></script>
     PtShareCard.open({ kind:'dua'|'ayah'|'hadith', title, ar, tr, bn, ref });
   - 1080×1350 (৪:৫) PNG ছবি আঁকে (WhatsApp / Facebook / Instagram-এ সুন্দর দেখায়)।
   - নিচে পপআপে: প্রিভিউ, ৬টি রঙের থিম, "উচ্চারণ/অর্থ" চালু-বন্ধ, শেয়ার / গ্যালারিতে সেভ / লেখা কপি।
   - নেটিভ ব্রিজ PatheyoShare (Kotlin) থাকলে সেটা দিয়ে শেয়ার; না থাকলে (ব্রাউজারে) ডাউনলোড/Web Share। */
(function () {
  'use strict';
  if (window.PtShareCard) return;


  /* ---------- বিষয়ভিত্তিক আইকন সিস্টেম ----------
     প্রতিটা আয়াত/হাদিস/দোয়ার লেখা (ও দোয়ার ক্যাটাগরি) দেখে বিষয় ঠিক হয় → সেই বিষয়ের আইকন ও নাম হোম কার্ড আর শেয়ার কার্ডে আসে।
     নতুন বিষয় যোগ করতে: TOPICS-এ আইকন+নাম, RULES-এ শব্দগুলো বসান। (উপরের দিকের নিয়ম আগে মিলে — তাই নির্দিষ্টগুলো উপরে রাখুন।) */
  var TOPICS = {
    sabr:     { n: 'ধৈর্য',        d: 'M3 19l6.2-10.5 3.6 6 2.2-3.2L21 19zM9.2 8.5l1.6 2.6' },
    salah:    { n: 'নামাজ',       d: 'M5 20v-6c0-3.9 3.1-7 7-7s7 3.1 7 7v6M3 20h18M12 7V3M10 4.5h4' },
    zikr:     { n: 'আল্লাহর স্মরণ', d: 'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9zM18.5 16.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z' },
    tawakkul: { n: 'ভরসা',        d: 'M12 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM12 7v14M5 12H3a9 9 0 0 0 18 0h-2M8.5 11h7' },
    tawhid:   { n: 'তাওহিদ',      d: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z' },
    brother:  { n: 'ভ্রাতৃত্ব',     d: 'M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 20c0-3.3 2.7-6 6-6s6 2.7 6 6M16.5 11a2.5 2.5 0 1 0 0-5M17 14.2c2.7.4 4.5 2.7 4.5 5.8' },
    mercy:    { n: 'দয়া ও কল্যাণ', d: 'M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z' },
    knowledge:{ n: 'ইলম',         d: 'M12 6.5C10 5 7.2 4.6 4 5v13c3.2-.4 6 0 8 1.5 2-1.5 4.8-1.9 8-1.5V5c-3.2-.4-6 0-8 1.5zM12 6.5v13' },
    niyyah:   { n: 'নিয়ত',        d: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zM12 11.4v1.2' },
    hope:     { n: 'আশা ও স্বস্তি', d: 'M3 18h18M7 18a5 5 0 0 1 10 0M12 5v3M5.6 9.6l1.8 1.8M18.4 9.6l-1.8 1.8' },
    blessing: { n: 'নিয়ামত',      d: 'M4 11h16v9H4zM3 8h18v3H3zM12 8v12M12 8C10 4.8 7 4.8 7 6.6S10 8 12 8zM12 8c2-3.2 5-3.2 5-1.4S14 8 12 8z' },
    taqwa:    { n: 'তাকওয়া',      d: 'M12 3l7.5 3v5.5c0 4.6-3.2 8.3-7.5 9.5-4.3-1.2-7.5-4.9-7.5-9.5V6zM8.8 12l2.2 2.2 4.2-4.4' },
    purity:   { n: 'পবিত্রতা',     d: 'M12 3s6 6.3 6 11a6 6 0 0 1-12 0c0-4.7 6-11 6-11zM9.5 14.5a2.6 2.6 0 0 0 2.5 2.5' },
    speech:   { n: 'ভালো কথা',    d: 'M4 5h16v11H9.5L4 20zM8 9.5h8M8 12.5h5' },
    sadaqah:  { n: 'সদকা',        d: 'M4 7c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 7v4.5c0 1.7 3.6 3 8 3s8-1.3 8-3V7M4 11.5V16c0 1.7 3.6 3 8 3s8-1.3 8-3v-4.5' },
    deeds:    { n: 'নেক আমল',     d: 'M12 21v-9M12 12C12 8 9 6 5 6c0 4 2 6 7 6zM12 14.5c0-3 2.5-5 6-5 0 3-2 5-6 5z' },
    anger:    { n: 'ক্রোধ দমন',    d: 'M12 3c1 3.4 5.5 5.4 5.5 10.2A5.5 5.5 0 0 1 12 19a5.5 5.5 0 0 1-5.5-5.8c0-2.2 1.2-3.7 2.4-4.8.1 1.9 1 3 2.2 3 .2-3-1-4.8.9-8.4z' },
    akhlaq:   { n: 'উত্তম চরিত্র',  d: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8.4 14c1 1.6 2.3 2.3 3.6 2.3s2.6-.7 3.6-2.3M9 9.6h.01M15 9.6h.01' },
    istighfar:{ n: 'ক্ষমা প্রার্থনা', d: 'M20 12a8 8 0 1 1-2.4-5.7M20 4v5h-5M12 8v4.5l3 1.5' },
    trouble:  { n: 'বিপদ-আপদ',    d: 'M7 17a4 4 0 0 1-.4-8A5.5 5.5 0 0 1 17 7.8 4.6 4.6 0 0 1 17 17zM9 20l1-2M13 20l1-2' },
    morning:  { n: 'সকাল-সন্ধ্যা',   d: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1' },
    sleep:    { n: 'ঘুম',          d: 'M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5zM16 4v3M14.5 5.5h3' },
    food:     { n: 'খাওয়া-দাওয়া',  d: 'M4 11h16a8 8 0 0 1-16 0zM8 7.5c0-1.2 1-1.8 1-3.2M12 7.5c0-1.2 1-1.8 1-3.2M16 7.5c0-1.2 1-1.8 1-3.2' },
    home:     { n: 'ঘর ও পোশাক',   d: 'M4 11l8-7 8 7v9H4zM10 20v-6h4v6' },
    travel:   { n: 'সফর',          d: 'M12 21s7-6 7-11a7 7 0 1 0-14 0c0 5 7 11 7 11zM12 7.5a2.8 2.8 0 1 0 0 5.6 2.8 2.8 0 0 0 0-5.6z' },
    family:   { n: 'পরিবার',       d: 'M12 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6.5 20c0-3 2.5-5.5 5.5-5.5s5.5 2.5 5.5 5.5M5 12.5a2 2 0 1 0 0-4M19 12.5a2 2 0 1 0 0-4' },
    dua:      { n: 'দোয়া',        d: 'M3 10c1 5 4 8 9 8s8-3 9-8M3 10c3 0 6 1 9 4 3-3 6-4 9-4M12 3v3.5M10.2 4.7h3.6' },
    quran:    { n: 'কুরআন',        d: 'M5 5.5A1.5 1.5 0 0 1 6.5 4H19v13H6.5A1.5 1.5 0 0 0 5 18.5zM5 18.5A1.5 1.5 0 0 0 6.5 20H19v-3M12 7.2l1 1.6 1.8.3-1.3 1.3.3 1.8-1.8-.9-1.8.9.3-1.8-1.3-1.3 1.8-.3z' },
    hadith:   { n: 'হাদিস',        d: 'M7 4h10a2 2 0 0 1 2 2v14l-3-2-2 2-2-2-2 2-2-2-3 2V6a2 2 0 0 1 2-2zM9 9h6M9 12.5h4' }
  };
  var CATMAP = { morning: 'morning', sleep: 'sleep', food: 'food', home: 'home', salah: 'salah', travel: 'travel', istigfar: 'istighfar', trouble: 'trouble', family: 'family' };
  var RULES = [
    ['hope',      ['স্বস্তি', 'ত্যাগ করেননি', 'অচিরেই', 'নিরাশ', 'আশা করো']],
    ['anger',     ['রাগ']],
    ['sabr',      ['ধৈর্য', 'সবর', 'বিপদে পড়', 'দুর্বল হয়ো না', 'দুঃখ করো না', 'পরীক্ষা']],
    ['taqwa',     ['ভয় করো', 'তাকওয়া']],
    ['salah',     ['নামাজ', 'নামায', 'সালাত', 'ওযু', 'সিজদা', 'রুকু']],
    ['knowledge', ['ইলম', 'শেখ', 'শিক্ষা', 'জ্ঞান', 'পৌঁছে দাও', 'হিদায়াত']],
    ['niyyah',    ['নিয়ত']],
    ['purity',    ['পবিত্রতা', 'পরিচ্ছন্ন', 'তাওবাকারী']],
    ['tawakkul',  ['ভরসা', 'তাওয়াক্কুল', 'যথেষ্ট', 'লিখে রেখেছেন', 'কর্মবিধায়ক']],
    ['istighfar', ['ক্ষমা', 'ইস্তিগফার', 'তাওবা', 'গুনাহ']],
    ['zikr',      ['স্মরণ', 'জিকির', 'যিকির', 'তাসবিহ', 'সুবহান', 'প্রশংসা', 'শুকরিয়া']],
    ['akhlaq',    ['হাসিমুখে']],
    ['brother',   ['ভাই ভাই', 'ভাইয়ের', 'পরস্পর', 'মুসলিমরা', 'প্রতিবেশী']],
    ['mercy',     ['দয়া', 'রহমত', 'দয়ালু', 'কল্যাণকামিতা', 'হিতোপদেশ', 'ক্ষমাশীল']],
    ['akhlaq',    ['চরিত্র', 'আখলাক', 'হাসিমুখে', 'বিনয়', 'নম্র', 'সত্য']],
    ['speech',    ['ভালো কথা', 'জিহ্বা', 'চুপ থাক']],
    ['blessing',  ['নিয়ামত', 'কাউছার', 'অনুগ্রহ']],
    ['sadaqah',   ['সদকা', 'দান করো', 'খরচ']],
    ['deeds',     ['ভালো কাজ', 'সওয়াব', 'নেক', 'আমল']],
    ['dua',       ['দোয়া', 'প্রার্থনা']],
    ['tawhid',    ['ইবাদত', 'এক-অদ্বিতীয়', 'অদ্বিতীয়', 'ইলাহ', 'তাওহিদ', 'শিরক']],
    ['family',    ['সন্তান', 'পিতা-মাতা', 'মাতা-পিতা', 'স্ত্রী', 'পরিবার']]
  ];
  function topicOf(it) {
    it = it || {};
    if (it.topic && TOPICS[it.topic]) return it.topic;
    if (it.cat && CATMAP[it.cat]) return CATMAP[it.cat];
    var txt = (it.title || it.t || '') + ' ' + (it.bn || '');
    for (var i = 0; i < RULES.length; i++) for (var j = 0; j < RULES[i][1].length; j++) if (txt.indexOf(RULES[i][1][j]) > -1) return RULES[i][0];
    return it.kind === 'dua' ? 'dua' : (it.kind === 'hadith' ? 'hadith' : 'quran');
  }
  function topicSvg(id) { var t = TOPICS[id] || TOPICS.quran; return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' + t.d + '"/></svg>'; }
  window.PtTopics = { of: topicOf, label: function (id) { return (TOPICS[id] || TOPICS.quran).n; }, svg: topicSvg, path: function (id) { return (TOPICS[id] || TOPICS.quran).d; }, all: TOPICS };

  var BASE = 'https://appassets.patheyo.invalid/';
  var W = 1080, H = 1350;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }

  /* ---------- থিম ---------- */
  var THEMES = [
    { id: 'night',  n: 'নীল রাত',  bg: ['#0A1F4D', '#123A7A'], glow: 'rgba(120,170,255,.22)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.78)', gold: '#F5C95A', pat: 'rgba(255,255,255,.055)', dot: '#1B4FA3' },
    { id: 'emerald',n: 'পান্না সবুজ', bg: ['#06382B', '#0E6B4E'], glow: 'rgba(120,255,200,.20)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.80)', gold: '#F5D56E', pat: 'rgba(255,255,255,.055)', dot: '#0E8A63' },
    { id: 'sand',   n: 'মরুর বালি',  bg: ['#F7EBD0', '#EBD5A6'], glow: 'rgba(255,255,255,.55)', ink: '#3A2A10', mut: '#6B5530', gold: '#B4690E', pat: 'rgba(120,80,20,.07)', dot: '#C9983A' },
    { id: 'dusk',   n: 'গোধূলি',    bg: ['#2B1650', '#7A2F6B'], glow: 'rgba(255,170,220,.20)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.80)', gold: '#FFD27A', pat: 'rgba(255,255,255,.05)', dot: '#8E3D86' },
    { id: 'pearl',  n: 'মুক্তা সাদা', bg: ['#FFFFFF', '#EEF3FA'], glow: 'rgba(255,255,255,0)', ink: '#0C1B33', mut: '#4F6280', gold: '#0E7BB8', pat: 'rgba(14,60,120,.06)', dot: '#9DB4D6' },
    { id: 'ink',    n: 'গাঢ় কালো',  bg: ['#0B0B10', '#1C1C26'], glow: 'rgba(255,215,120,.12)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.75)', gold: '#E8B84A', pat: 'rgba(255,255,255,.04)', dot: '#3A3A4A' }
  ];
  var KIND = { dua: 'দোয়া', ayah: 'কুরআনের আয়াত', hadith: 'হাদিস' };

  /* ---------- ফন্ট (কার্ডের ছবিতে নিজের ফন্ট লাগে — ফিচারের CSS-এর উপর ভরসা না করে নিজেই লোড করি) ---------- */
  var fontsP = null;
  function loadFonts() {
    if (fontsP) return fontsP;
    function face(name, file, weight) {
      try { var f = new FontFace(name, 'url(' + BASE + file + ')', { weight: weight || '400' }); document.fonts.add(f); return f.load(); }
      catch (e) { return Promise.resolve(); }
    }
    fontsP = Promise.all([
      face('PtCardAr', 'fonts/web/uthmanic-hafs-4baeb996.woff2'),
      face('PtCardBn', 'fonts/Gunjoron-Font-Normal.ttf', '400'),
      face('PtCardBn', 'fonts/Gunjoron-Font-Bold.ttf', '700'),
      face('PtCardHome', 'fonts/web/noto-serif-bengali-3ed1b30d.woff2', '100 900'),
      face('PtCardLat', 'fonts/web/inter-260c81a4.woff2', '100 900')
    ]).catch(function () {});
    return fontsP;
  }

  /* ---------- আঁকার সহায়ক ---------- */
  function wrapLines(ctx, text, maxW) {
    var words = String(text || '').replace(/\s+/g, ' ').trim().split(' '), lines = [], cur = '';
    words.forEach(function (w) {
      var t = cur ? cur + ' ' + w : w;
      if (cur && ctx.measureText(t).width > maxW) { lines.push(cur); cur = w; } else cur = t;
    });
    if (cur) lines.push(cur);
    return lines;
  }
  /* maxH-এর মধ্যে ধরানোর জন্য ফন্ট ছোট করে (max → min) */
  function fit(ctx, text, fontFn, maxW, maxH, lhMul, max, min) {
    for (var s = max; s >= min; s -= 2) {
      ctx.font = fontFn(s);
      var lines = wrapLines(ctx, text, maxW);
      if (lines.length * s * lhMul <= maxH) return { size: s, lines: lines, h: lines.length * s * lhMul };
    }
    ctx.font = fontFn(min);
    var ls = wrapLines(ctx, text, maxW), maxLines = Math.max(1, Math.floor(maxH / (min * lhMul)));
    var cut = false;
    if (ls.length > maxLines) { cut = true; ls = ls.slice(0, maxLines); ls[maxLines - 1] = ls[maxLines - 1].replace(/\s*\S*$/, '') + ' …'; }
    return { size: min, lines: ls, h: ls.length * min * lhMul, cut: cut };
  }
  function star8(ctx, cx, cy, r, fill) {
    ctx.save(); ctx.translate(cx, cy); ctx.fillStyle = fill;
    for (var k = 0; k < 2; k++) { ctx.rotate(k * Math.PI / 4); roundRect(ctx, -r, -r, r * 2, r * 2, r * 0.14); ctx.fill(); }
    ctx.restore();
  }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function pattern(ctx, th) {
    ctx.save(); ctx.strokeStyle = th.pat; ctx.lineWidth = 2;
    var step = 150;
    for (var y = -step; y < H + step; y += step) for (var x = -step; x < W + step; x += step) {
      var cx = x + ((Math.round(y / step) % 2) ? step / 2 : 0);
      ctx.save(); ctx.translate(cx, y); 
      for (var k = 0; k < 2; k++) { ctx.rotate(k * Math.PI / 4); ctx.strokeRect(-34, -34, 68, 68); }
      ctx.restore();
    }
    ctx.restore();
  }
  function divider(ctx, th, y) {
    ctx.save();
    var g = ctx.createLinearGradient(W / 2 - 360, 0, W / 2 + 360, 0);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(.5, th.gold); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(W / 2 - 360, y - 1.5, 720, 3);
    star8(ctx, W / 2, y, 15, th.gold);
    ctx.fillStyle = th.bg[0]; ctx.beginPath(); ctx.arc(W / 2, y, 4.5, 0, 7); ctx.fill();
    ctx.restore();
  }

  /* ---------- ব্র্যান্ড লোগো (অ্যাপের হেডারের লোগোই) ---------- */
  /* অ্যাপের লোগো (হেডারের সেটাই) ইনলাইন — তাই নেটওয়ার্ক লাগে না, আর ক্যানভাস "tainted" হয় না */
  var LOGO_URI = 'data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxuczpjMnBhPSJodHRwOi8vYzJwYS5vcmcvbWFuaWZlc3QiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMTE1OC40IDExNTguNCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMTE1OC40IDExNTguNDsiIHhtbDpzcGFjZT0icHJlc2VydmUiPiA8c3R5bGUgdHlwZT0idGV4dC9jc3MiPiAuc3Qwe2ZpbGw6dXJsKCNTVkdJRF8xXyk7fSAuc3Qxe2NsaXAtcGF0aDp1cmwoI1NWR0lEXzNfKTt9IC5zdDJ7ZmlsbDp1cmwoI1NWR0lEXzRfKTt9IC5zdDN7ZmlsbDp1cmwoI1NWR0lEXzVfKTt9IC5zdDR7ZmlsbDp1cmwoI1NWR0lEXzZfKTt9IC5zdDV7b3BhY2l0eTowLjUxO2ZpbGw6bm9uZTtzdHJva2U6IzlEOUQ5QztzdHJva2Utd2lkdGg6NTt9IDwvc3R5bGU+IDxnPiA8cmFkaWFsR3JhZGllbnQgaWQ9IlNWR0lEXzFfIiBjeD0iNTc5LjE5NSIgY3k9IjU3OS4xOCIgcj0iNzczLjcyMzYiIGZ4PSIzNzEuMzE5OSIgZnk9IjEzNS4zMDYzIiBncmFkaWVudFRyYW5zZm9ybT0ibWF0cml4KDEgMCAwIDAuOTg2NCAwIDcuODkwOSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4gPHN0b3Agb2Zmc2V0PSIwIiBzdHlsZT0ic3RvcC1jb2xvcjojNEY4NkZGIi8+IDxzdG9wIG9mZnNldD0iMC4yMDMxIiBzdHlsZT0ic3RvcC1jb2xvcjojNDM3Q0ZGIi8+IDxzdG9wIG9mZnNldD0iMC41NjU0IiBzdHlsZT0ic3RvcC1jb2xvcjojMjU2MEZFIi8+IDxzdG9wIG9mZnNldD0iMC41ODI5IiBzdHlsZT0ic3RvcC1jb2xvcjojMjM1RkZFIi8+IDxzdG9wIG9mZnNldD0iMC42NTYxIiBzdHlsZT0ic3RvcC1jb2xvcjojMjE1QkY3Ii8+IDxzdG9wIG9mZnNldD0iMC43NjM0IiBzdHlsZT0ic3RvcC1jb2xvcjojMUI0RkUzIi8+IDxzdG9wIG9mZnNldD0iMC44OTExIiBzdHlsZT0ic3RvcC1jb2xvcjojMTIzQ0MzIi8+IDxzdG9wIG9mZnNldD0iMC45ODgyIiBzdHlsZT0ic3RvcC1jb2xvcjojMEEyQUE2Ii8+IDwvcmFkaWFsR3JhZGllbnQ+IDxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMTU4LjQsNTc5LjJjMCw4MC0xNi4yLDE1Ni4yLTQ1LjUsMjI1LjVjLTU4LjQsMTM4LTE2OC44LDI0OC43LTMwNi42LDMwNy41Yy0xMy45LDUuOS0yOC4xLDExLjMtNDIuNSwxNi4yIGMtNTgsMTkuNS0xMjAsMzAtMTg0LjYsMzBoMEMyNTkuMywxMTU4LjQsMCw4OTkuMSwwLDU3OS4yYzAtODAsMTYuMi0xNTYuMSw0NS41LTIyNS41QzEzMy40LDE0NS44LDMzOS4zLDAsNTc5LjIsMGgwIGM2OS41LDAsMTM2LjEsMTIuMiwxOTcuOSwzNC43YzE4LDYuNSwzNS41LDEzLjksNTIuNiwyMi4xQzEwMjQuMiwxNTAuMiwxMTU4LjQsMzQ5LDExNTguNCw1NzkuMnoiLz4gPGc+IDxkZWZzPiA8Y2lyY2xlIGlkPSJTVkdJRF8yXyIgY3g9IjU3OS4yIiBjeT0iNTc5LjIiIHI9IjU3OCIvPiA8L2RlZnM+IDxjbGlwUGF0aCBpZD0iU1ZHSURfM18iPiA8dXNlIHhsaW5rOmhyZWY9IiNTVkdJRF8yXyIgc3R5bGU9Im92ZXJmbG93OnZpc2libGU7Ii8+IDwvY2xpcFBhdGg+IDxnIGNsYXNzPSJzdDEiPiA8bGluZWFyR3JhZGllbnQgaWQ9IlNWR0lEXzRfIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9Ii0xOS40ODE1IiB5MT0iMTE3OS45Njc4IiB4Mj0iLTE5LjQ4MTUiIHkyPSIxMTc4Ljk2NzgiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMTA4MCAwIDAgLTYyMCAyMTYxOS4xOTkyIDczMTQyMCkiPiA8c3RvcCBvZmZzZXQ9IjAiIHN0eWxlPSJzdG9wLWNvbG9yOiNGRkZGRkY7c3RvcC1vcGFjaXR5OjAuNDIiLz4gPHN0b3Agb2Zmc2V0PSIxIiBzdHlsZT0ic3RvcC1jb2xvcjojRkZGRkZGO3N0b3Atb3BhY2l0eTowIi8+IDwvbGluZWFyR3JhZGllbnQ+IDxlbGxpcHNlIGNsYXNzPSJzdDIiIGN4PSI1NzkuMiIgY3k9IjE1MCIgcng9IjU0MCIgcnk9IjMxMCIvPiA8L2c+IDwvZz4gPGxpbmVhckdyYWRpZW50IGlkPSJTVkdJRF81XyIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiIHgxPSIzMTMuOTkxOCIgeTE9IjU3OS4yNzUiIHgyPSI5NDYuNzciIHkyPSI1NzkuMjc1Ij4gPHN0b3Agb2Zmc2V0PSIwIiBzdHlsZT0ic3RvcC1jb2xvcjojRkZGRkZGIi8+IDxzdG9wIG9mZnNldD0iMSIgc3R5bGU9InN0b3AtY29sb3I6I0RDRTZGRiIvPiA8L2xpbmVhckdyYWRpZW50PiA8cGF0aCBjbGFzcz0ic3QzIiBkPSJNOTQ2LjgsMzU3LjZsLTYuNyw1LjhjLTMuNSwzLTcsNi4xLTEwLjQsOS4yYy02LjgsNS45LTEzLjQsMTItMTkuNiwxNy43Yy05LjgsOS4xLTE5LjcsMTguNS0yOS4yLDI3LjkgYy0yLjksMi44LTUuOCw1LjgtOC42LDguNmwtMC45LDAuOWMtMy41LDMuNS02LjYsNi42LTkuNSw5LjZjLTMuMSwzLjItNi4zLDYuNC05LjQsOS43Yy0yLjgsMi45LTUuNSw1LjgtOC4zLDguN2wtMC4xLDAuMSBjLTAuNSwwLjUtMC45LDAuOS0xLjMsMS40bC0wLjIsMC4yYy0yLjksMy01LjcsNi4xLTguNSw5LjJjLTMsMy4yLTUuOSw2LjQtOSw5LjlsLTAuMSwwLjFjLTIuMSwyLjItNC4xLDQuNS02LDYuNyBjLTEuNiwxLjgtMy4xLDMuNS00LjcsNS4yYy0yLjMsMi43LTQuNyw1LjMtNyw4bC0wLjMsMC4zbC0wLjIsMC4yYy0yLjUsMi45LTUuMSw1LjktNy42LDguOEw3OTksNTA2Yy0wLjUsMC41LTEsMS4xLTEuNSwxLjggbC0wLjEsMC4xYy0yLjQsMi44LTQuOSw1LjgtNy40LDguN2wtMC4zLDAuNGMtMS43LDIuMS0zLjUsNC4xLTUuMiw2LjJsLTQuMSw1bDEuNCw2LjNjMS43LDcuNy0xLjEsMTcuNi05LjcsMjEuOSBjLTMsMS41LTYuNCwyLjMtOS43LDIuM2wtNi4zLDAuMWMwLDAtNC4zLDUuNy00LjYsNmMtMC4zLDAuNC0wLjYsMC44LTEsMS4yYy03LjMsOS42LTE0LjUsMTkuMy0yMS4zLDI4LjljLTEsMS4zLTEuOSwyLjYtMi44LDMuOSBsLTAuNiwwLjljLTYuMiw4LjgtMTIuNCwxNy42LTE4LjMsMjYuM2MtMzUuMiw1Mi4xLTY3LDEwNy4xLTk0LjYsMTYzLjVjLTcuOSwxNi4zLTE1LjIsMzMuOS0yMS42LDQ5LjUgYy0xNC45LDM2LjItMzAuNCw3My43LTU1LDEwMi40bC0yLjMsMi43bC0zLjUtMC43Yy01LjgtMS4yLTEzLjgtNC41LTIwLjItNy4zbC0wLjItMC4xYy0xLjQtMC42LTIuNC0xLTMuNC0xLjUgYy0xLTAuNC0yLjItMC45LTMuNi0xLjRjLTEwLjUtNC4xLTE3LTcuMi0yMC41LTkuOGwtMi4xLTEuNmwtMC4yLTIuNmMtMTAuOC0xMTAuOS0yOS4xLTIyMi4yLTU0LjMtMzMwLjhsLTguNi0zN2wxNiwyLjJsMC4yLDAgYzYsMS4yLDExLjksMi45LDE3LjYsNS4xYzIuMiwwLjgsNC4zLDEuNyw2LjQsMi43bDIuNiwxLjJsMC43LDIuOGMxMC43LDQxLjYsMjAuNCw4NC4xLDI4LjksMTI2LjJjOC44LDQzLjIsMTYuNSw4Ny4xLDIzLDEzMC43IGw3LDQ2LjhsMjEuOC01Mi43YzcuMS0xNy4xLDEzLjctMzMuMiwyMS4zLTQ4LjdjMjYuNy01NC40LDU3LjUtMTA3LjQsOTEuNC0xNTcuNmMxOC4xLTI2LjgsMzcuNy01My42LDU4LjMtNzkuNWw2LjItNy45TDU0MS42LDI4MiBsLTEwLDE3LjZDNDkwLDM3Mi40LDQ1My41LDQ0OSw0MjMsNTI3bC0yMi4yLDYwLjJjLTEyLjksMzctMjQuNSw3NC42LTM0LjYsMTExLjZjLTIuNiw5LjYtOS4yLDE0LjUtMTkuOCwxNC41IGMtMTAuNywwLTIyLTUuNC0yOC4xLTEzLjRjLTQuMS01LjMtNS4zLTExLjItMy42LTE3LjRjNDMuOS0xNjEuNiwxMTAuNS0zMTUuOSwxOTguMS00NTguN2M0LTYuNSw5LjctOS43LDE3LjItOS43IGMxMC4zLDAsMjIuMiw2LjIsMjguNywxNS4yTDc0OC43LDQ4N2wxMC44LTEyLjJjMy4yLTMuNiw2LjctNy42LDEwLjItMTEuNGMxLTEuMSwyLTIuMiwzLTMuM2MzLjItMy41LDYuMy02LjksOS41LTEwLjNsMC4zLTAuMyBjMC4zLTAuMywwLjYtMC42LDAuOS0wLjljNC40LTQuOCw5LTkuNiwxMy41LTE0LjJjMS4yLTEuMywyLjUtMi42LDMuOC0zLjljMC44LTAuOSwxLjctMS43LDIuNS0yLjZjMTEuNy0xMiwyMy44LTI0LDM1LjktMzUuNSBjMS44LTEuNywzLjctMy41LDUuNS01LjJsMS4zLTEuMmM3LjItNi44LDE0LjUtMTMuNSwyMS44LTIwYzEuOS0xLjcsMy45LTMuNSw1LjgtNS4ybDEuNS0xLjNjMi41LTIuMiw0LjktNC40LDcuNC02LjUgYzUuNS00LjgsMTAuMy05LDE0LjktMTIuOGwyLjEtMS43bDIuNywwLjRjNS44LDAuOSwxNC4yLDQuMywyMSw3LjNjMS42LDAuNywyLjksMS4zLDQsMS43YzMuMywxLjQsOSw0LjMsMTIuMSw1LjlMOTQ2LjgsMzU3LjZ6Ii8+IDxsaW5lYXJHcmFkaWVudCBpZD0iU1ZHSURfNl8iIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiB4MT0iNzg0LjQyODEiIHkxPSIzNC42ODAxIiB4Mj0iNzg0LjQyODEiIHkyPSIxMTI4LjMzIj4gPHN0b3Agb2Zmc2V0PSIwIiBzdHlsZT0ic3RvcC1jb2xvcjojRkZGRkZGIi8+IDxzdG9wIG9mZnNldD0iMSIgc3R5bGU9InN0b3AtY29sb3I6I0RDRTZGRiIvPiA8L2xpbmVhckdyYWRpZW50PiA8cGF0aCBjbGFzcz0ic3Q0IiBkPSJNNzkxLjEsNTE1LjRjLTYuOCwxODgtMi42LDM3OC4yLDEyLjYsNTY2YzAuOCwxMC4zLDEuNywyMC41LDIuNiwzMC44Yy0xMy45LDUuOS0yOC4xLDExLjMtNDIuNSwxNi4ybC0wLjEtMS40IGMtMS05LjUtMS45LTE4LjktMi44LTI4LjVjLTUuNC01Ni45LTkuOC0xMTQuMi0xMy4yLTE3MWMtNi44LTExNC43LTkuNi0yMzEuMS04LjEtMzQ2LjV2MGMwLjEtNi4xLDAuMi0xMi4zLDAuMy0xOC40IGMwLjMtMjIuNCwwLjktNDUuMSwxLjYtNjcuNWMwLjItNS44LDAuNC0xMS41LDAuNS0xNy4zYzQuNy0xMzcuNywxNS4yLTI3Ni41LDMxLjUtNDEzLjJ2MGMxLjEtOS41LDIuMy0xOC45LDMuNS0yOC40bDAuMi0xLjQgYzE4LDYuNSwzNS41LDEzLjksNTIuNiwyMi4xYy0xLjQsMTAuMi0yLjcsMjAuNC00LDMwLjZjLTE0LjYsMTE1LjMtMjUsMjMyLjUtMzEuMiwzNDkuMnYwYy0wLjMsNS40LTAuNiwxMC44LTAuOCwxNi4yIGMtMSwyMC4xLTEuOSw0MC40LTIuNiw2MC41djEuMUM3OTEuMSw1MTQuOCw3OTEuMSw1MTUuMSw3OTEuMSw1MTUuNEw3OTEuMSw1MTUuNHoiLz4gPHBhdGggY2xhc3M9InN0NSIgZD0iTTU3OS4yLDExMjkuMkw1NzkuMiwxMTI5LjJjLTMwMy43LDAtNTUwLTI0Ni4yLTU1MC01NTB2MGMwLTMwMy43LDI0Ni4yLTU1MCw1NTAtNTUwaDAgYzMwMy43LDAsNTUwLDI0Ni4yLDU1MCw1NTB2MEMxMTI5LjIsODgyLjksODgyLjksMTEyOS4yLDU3OS4yLDExMjkuMnoiLz4gPC9nPiA8L3N2Zz4g';
  var logoP = null;
  function loadLogo() {
    if (logoP) return logoP;
    logoP = new Promise(function (res) {
      try { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = LOGO_URI; }
      catch (e) { res(null); }
    });
    return logoP;
  }
  /* পাতলা বিভাজক: দুই পাশে মিলিয়ে যাওয়া রেখা, মাঝে ছোট হীরা */
  function rule(ctx, th, y, half) {
    ctx.save();
    [[-1, 0], [1, 1]].forEach(function (d) {
      var x0 = W / 2 + d[0] * 26, x1 = W / 2 + d[0] * (half || 300);
      var g = ctx.createLinearGradient(x0, 0, x1, 0); g.addColorStop(0, th.gold); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.globalAlpha = .75; ctx.strokeStyle = g; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
    });
    ctx.globalAlpha = 1; ctx.fillStyle = th.gold; ctx.translate(W / 2, y); ctx.rotate(Math.PI / 4); ctx.fillRect(-7, -7, 14, 14);
    ctx.restore();
  }

  /* ---------- কার্ড আঁকা ---------- */
  var SERIF = 'PtCardHome, "Noto Serif Bengali", PtCardBn, serif';   /* হোমের হেডারের ফন্টই */
  function drawIcon(ctx, id, cx, cy, size, color, lw) {
    try {
      ctx.save(); ctx.translate(cx - size / 2, cy - size / 2); var k = size / 24; ctx.scale(k, k);
      ctx.lineWidth = lw; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = color; ctx.stroke(new Path2D(window.PtTopics.path(id)));
      ctx.restore();
    } catch (e) { try { ctx.restore(); } catch (e2) {} }
  }
  function spaced(ctx, px) { try { ctx.letterSpacing = px + 'px'; } catch (e) {} }
  /* দুই পাশে ছোট রেখা দিয়ে বসানো ছোট লেখা (আইব্রো) */
  function flank(ctx, th, text, y, font, gap, len) {
    ctx.font = font; var w = ctx.measureText(text).width;
    ctx.textAlign = 'center'; ctx.fillStyle = th.gold; ctx.fillText(text, W / 2, y);
    ctx.save(); ctx.globalAlpha = .6; ctx.fillStyle = th.gold;
    ctx.fillRect(W / 2 - w / 2 - gap - len, y - 11, len, 2.5); ctx.fillRect(W / 2 + w / 2 + gap, y - 11, len, 2.5);
    ctx.restore();
  }
  function render(data, opt) {
    return Promise.all([loadFonts(), loadLogo()]).then(function (rs) {
      var logo = rs[1];
      var th = THEMES.filter(function (t) { return t.id === opt.theme; })[0] || THEMES[0];
      var c = document.createElement('canvas'); c.width = W; c.height = H;
      var ctx = c.getContext('2d');
      var M = 88;
      /* পটভূমি — পরিষ্কার গ্রেডিয়েন্ট + নরম আলো */
      var g = ctx.createLinearGradient(0, 0, W * 0.5, H); g.addColorStop(0, th.bg[0]); g.addColorStop(1, th.bg[1]);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      var rg = ctx.createRadialGradient(W * 0.85, H * 0.06, 20, W * 0.85, H * 0.06, 860); rg.addColorStop(0, th.glow); rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = th.gold; ctx.globalAlpha = .34; ctx.lineWidth = 2.5; roundRect(ctx, 40, 40, W - 80, H - 80, 40); ctx.stroke(); ctx.globalAlpha = 1;
      var tid = window.PtTopics.of(data);
      /* বিষয়ের বড় ঝাপসা জলছাপ (খুব হালকা) */
      ctx.save(); roundRect(ctx, 40, 40, W - 80, H - 80, 40); ctx.clip(); ctx.globalAlpha = .055;
      drawIcon(ctx, tid, W - 250, H - 470, 620, th.gold, .55); ctx.restore();
      ctx.textBaseline = 'alphabetic'; ctx.direction = 'ltr';

      /* ── হেডার: হোমের মতোই — লোগো, "পাথেয় বাই গুঞ্জরণ", নিচে স্লোগান ── */
      var LS = 112, ly = 92;
      if (logo) { try { ctx.save(); ctx.shadowColor = 'rgba(0,16,60,.35)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 8; ctx.drawImage(logo, M, ly, LS, LS); ctx.restore(); } catch (e) {} }
      var tx = logo ? M + LS + 28 : M;
      ctx.textAlign = 'left'; spaced(ctx, .4);
      ctx.fillStyle = th.ink; ctx.font = '700 52px ' + SERIF; ctx.fillText('পাথেয়', tx, ly + 54);
      var nw = ctx.measureText('পাথেয় ').width;
      ctx.globalAlpha = .82; ctx.font = '400 52px ' + SERIF; ctx.fillText('বাই গুঞ্জরণ', tx + nw, ly + 54); ctx.globalAlpha = 1;
      ctx.fillStyle = th.mut; ctx.font = '300 30px ' + SERIF; spaced(ctx, .6); ctx.fillText('চিরস্থায়ী সফরের পরম সঙ্গী', tx, ly + 100);
      spaced(ctx, 0);
      ctx.globalAlpha = .14; ctx.fillStyle = th.ink; ctx.fillRect(M, ly + LS + 44, W - M * 2, 2); ctx.globalAlpha = 1;

      /* ── বিষয়ের আইকন-ব্যাজ + আইব্রো (বিষয় · ধরন) + হেডলাইন ── */
      var kind = KIND[data.kind] || 'দোয়া', bcy = ly + LS + 44 + 74, br = 40;
      ctx.save(); ctx.fillStyle = th.gold; ctx.globalAlpha = .14; ctx.beginPath(); ctx.arc(W / 2, bcy, br, 0, 7); ctx.fill();
      ctx.globalAlpha = .75; ctx.strokeStyle = th.gold; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(W / 2, bcy, br, 0, 7); ctx.stroke(); ctx.restore();
      drawIcon(ctx, tid, W / 2, bcy, 44, th.gold, 1.7);
      var y0 = bcy + br + 54;
      spaced(ctx, 2.5); flank(ctx, th, window.PtTopics.label(tid) + '  ·  ' + kind, y0, '700 28px ' + SERIF, 24, 56); spaced(ctx, 0);
      var top = y0 + 36, hasHead = data.title && !(data.ref && String(data.ref).indexOf(data.title) === 0);
      ctx.textAlign = 'center';
      if (hasHead) {
        var tl = fit(ctx, data.title, function (s) { return '700 ' + s + 'px ' + SERIF; }, 860, 64, 1.2, 52, 30);
        ctx.font = '700 ' + tl.size + 'px ' + SERIF; ctx.fillStyle = th.ink; ctx.fillText(tl.lines[0], W / 2, top + 58);
        top += 96;
      }

      /* ── মূল অংশ ── */
      top += 14; var bottom = H - 262, avail = bottom - top;
      var showAr = opt.ar !== false, showTr = opt.tr && data.tr, showBn = opt.bn && data.bn, cut = {};
      var rest = (showTr ? 1 : 0) + (showBn ? 1 : 0);
      var hAr = !showAr ? 0 : (rest ? avail * (showBn && showTr ? 0.46 : 0.52) : avail * 0.86);
      var hTr = showTr ? avail * (showBn ? 0.17 : 0.28) : 0;
      var hBn = showBn ? (showAr ? avail - hAr - hTr - 64 : avail - hTr - 30) : 0;
      var y = top;
      if (showAr) {
        ctx.direction = 'rtl'; ctx.textAlign = 'center';
        var ar = fit(ctx, data.ar, function (s) { return s + 'px PtCardAr, serif'; }, 880, hAr - 24, 1.95, rest ? 96 : 132, 30);
        cut.ar = ar.cut;
        ctx.font = ar.size + 'px PtCardAr, serif'; ctx.fillStyle = th.ink; ctx.strokeStyle = th.ink; ctx.lineWidth = Math.max(.7, ar.size / 60);
        var yy = y + (hAr - ar.h) / 2 + ar.size * 1.25;
        ar.lines.forEach(function (ln, i) { var ly2 = yy + i * ar.size * 1.95; ctx.fillText(ln, W / 2, ly2); ctx.strokeText(ln, W / 2, ly2); });
        y += hAr; ctx.direction = 'ltr'; ctx.lineWidth = 1;
        if (rest) { rule(ctx, th, y + 20, 250); y += 64; }
      }
      ctx.direction = 'ltr'; ctx.textAlign = 'center';
      if (showTr) {
        var tr = fit(ctx, data.tr, function (s) { return 'italic 400 ' + s + 'px PtCardBn, sans-serif'; }, 860, hTr, 1.5, 38, 22);
        cut.tr = tr.cut;
        ctx.font = 'italic 400 ' + tr.size + 'px PtCardBn, sans-serif'; ctx.fillStyle = th.gold;
        tr.lines.forEach(function (ln, i) { ctx.fillText(ln, W / 2, y + tr.size * 1.1 + i * tr.size * 1.5); });
        y += hTr;
      }
      if (showBn) {
        var bt = fit(ctx, data.bn, function (s) { return '400 ' + s + 'px PtCardBn, sans-serif'; }, 840, hBn, 1.62, 44, 24);
        cut.bn = bt.cut;
        ctx.font = '400 ' + bt.size + 'px PtCardBn, sans-serif'; ctx.fillStyle = th.ink;
        var by = y + (hBn - bt.h) / 2 + bt.size * 1.1;
        bt.lines.forEach(function (ln, i) { ctx.fillText(ln, W / 2, by + i * bt.size * 1.62); });
      }
      c._cut = !!(cut.ar || cut.tr || cut.bn);

      /* ── ফুটার: সূত্র, রেখা, নিচে মাঝবরাবর URL ── */
      ctx.textAlign = 'center';
      if (data.ref) {
        var rf = fit(ctx, data.ref, function (s) { return '700 ' + s + 'px ' + SERIF; }, 820, 44, 1.2, 34, 24);
        ctx.font = '700 ' + rf.size + 'px ' + SERIF; var rw = ctx.measureText(rf.lines[0]).width;
        ctx.fillStyle = th.gold; ctx.fillText(rf.lines[0], W / 2, H - 196);
        ctx.save(); ctx.translate(W / 2 - rw / 2 - 30, H - 196 - 11); ctx.rotate(Math.PI / 4); ctx.fillRect(-5, -5, 10, 10); ctx.restore();
        ctx.save(); ctx.translate(W / 2 + rw / 2 + 30, H - 196 - 11); ctx.rotate(Math.PI / 4); ctx.fillRect(-5, -5, 10, 10); ctx.restore();
      }
      ctx.globalAlpha = .14; ctx.fillStyle = th.ink; ctx.fillRect(M, H - 144, W - M * 2, 2); ctx.globalAlpha = 1;
      ctx.fillStyle = th.mut; ctx.font = '500 28px PtCardLat, Inter, sans-serif'; spaced(ctx, 1.6);
      ctx.fillText('patheyobygunjoron.github.io', W / 2, H - 88); spaced(ctx, 0);
      return c;
    });
  }

  /* ---------- UI ---------- */
  var css = ''
    + '.pcs-veil{position:fixed;inset:0;background:rgba(2,12,40,.55);opacity:0;pointer-events:none;transition:opacity .3s;z-index:1990}'
    + '.pcs-veil.on{opacity:1;pointer-events:auto}'
    + '.pcs-sheet{position:fixed;left:50%;bottom:0;width:min(100%,480px);max-height:92svh;overflow:auto;transform:translate(-50%,105%);transition:transform .4s cubic-bezier(.2,.9,.2,1);z-index:2000;'
    + 'background:#EEF3FA;color:#0C1B33;border-radius:30px 30px 0 0;padding:10px 18px calc(env(safe-area-inset-bottom,0px) + 22px + var(--pt-nav-fix,0px));border:1px solid rgba(0,32,94,.1);font-family:"GunjoronFont",Inter,sans-serif;overscroll-behavior:contain;box-sizing:border-box}'
    + '[data-theme="dark"] .pcs-sheet{background:#0E2040;color:#F5F8FD;border-color:rgba(255,255,255,.1)}'
    + '[data-theme="sepia"] .pcs-sheet{background:#F6EDD9;color:#3F331E;border-color:rgba(92,66,30,.2)}'
    + '.pcs-sheet.on{transform:translate(-50%,0)}'
    + '.pcs-grab{width:42px;height:5px;border-radius:9px;background:currentColor;opacity:.18;margin:4px auto 10px}'
    + '.pcs-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}'
    + '.pcs-t{font-size:19px;font-weight:700}'
    + '.pcs-x{width:36px;height:36px;border:0;border-radius:50%;background:rgba(127,140,170,.2);color:inherit;display:grid;place-items:center;cursor:pointer;padding:0}'
    + '.pcs-x svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round}'
    + '.pcs-prev{display:grid;place-items:center;background:rgba(127,140,170,.12);border-radius:22px;padding:14px;min-height:120px}'
    + '.pcs-prev canvas{display:block;width:auto;height:auto;max-width:100%;max-height:46svh;border-radius:14px;box-shadow:0 22px 40px -18px rgba(0,0,0,.6)}'
    + '.pcs-hint{font-size:12.5px;line-height:1.5;opacity:.75;margin:8px 2px 0}'
    + '.pcs-lb{font-size:13px;font-weight:700;opacity:.7;margin:14px 2px 7px}'
    + '.pcs-th{display:flex;gap:10px;overflow-x:auto;padding:2px 2px 6px;scrollbar-width:none}.pcs-th::-webkit-scrollbar{display:none}'
    + '.pcs-th button{flex:none;display:flex;flex-direction:column;align-items:center;gap:5px;background:none;border:0;padding:0;color:inherit;font-family:inherit;font-size:12px;cursor:pointer;opacity:.8}'
    + '.pcs-th i{display:block;width:46px;height:46px;border-radius:50%;border:2.5px solid transparent;box-shadow:0 0 0 1px rgba(127,140,170,.45) inset}'
    + '.pcs-th button.on{opacity:1;font-weight:700}.pcs-th button.on i{border-color:#0E7BB8;box-shadow:0 0 0 3px rgba(14,123,184,.25)}'
    + '.pcs-tg{display:flex;gap:8px;flex-wrap:wrap}'
    + '.pcs-tg button{font-family:inherit;font-size:14px;font-weight:600;color:inherit;background:rgba(127,140,170,.18);border:1.5px solid transparent;border-radius:999px;padding:9px 15px;cursor:pointer}'
    + '.pcs-tg button.on{background:#0E7BB8;color:#fff}'
    + '.pcs-ac{display:grid;grid-template-columns:1.6fr 1fr;gap:10px;margin-top:16px}'
    + '.pcs-ac button{font-family:inherit;font-size:16px;font-weight:700;border-radius:999px;padding:14px 10px;cursor:pointer;border:0;display:flex;align-items:center;justify-content:center;gap:8px}'
    + '.pcs-ac svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}'
    + '.pcs-go{background:linear-gradient(150deg,#235FFE,#0E4FD0);color:#fff;box-shadow:0 14px 24px -14px #235FFE}.pcs-sv{background:rgba(127,140,170,.22);color:inherit}'
    + '.pcs-ac button[disabled]{opacity:.55}'
    + '.pcs-cp{display:block;margin:12px auto 0;font-family:inherit;font-size:14px;font-weight:600;background:none;border:0;color:inherit;opacity:.75;cursor:pointer;text-decoration:underline;text-underline-offset:3px}'
    + '.pcs-msg{position:fixed;left:50%;bottom:calc(30px + env(safe-area-inset-bottom,0px) + var(--pt-nav-fix,0px));transform:translate(-50%,20px);opacity:0;pointer-events:none;z-index:2100;background:#0A1C46;color:#fff;font-family:"GunjoronFont",Inter,sans-serif;font-size:14px;font-weight:600;padding:11px 18px;border-radius:14px;transition:opacity .22s,transform .22s;max-width:calc(100% - 40px);text-align:center}'
    + '.pcs-msg.show{opacity:1;transform:translate(-50%,0)}'
    + 'html.pcs-lock,html.pcs-lock body{overflow:hidden}'
    + '@media (prefers-reduced-motion:reduce){.pcs-sheet,.pcs-veil,.pcs-msg{transition:none}}';

  var UI = null, cur = null, st = { theme: 'night', ar: true, tr: false, bn: true }, opened = false, renderTick = 0, lastCanvas = null;
  try { var sv = JSON.parse(localStorage.getItem('pt_share_card') || 'null'); if (sv) { if (THEMES.some(function (t) { return t.id === sv.theme; })) st.theme = sv.theme; if (typeof sv.ar === 'boolean') st.ar = sv.ar; if (typeof sv.tr === 'boolean') st.tr = sv.tr; if (typeof sv.bn === 'boolean') st.bn = sv.bn; } } catch (e) {}
  function persist() { try { localStorage.setItem('pt_share_card', JSON.stringify(st)); } catch (e) {} }

  function bridge() { return window.PatheyoShare || (window.parent && window.parent !== window && window.parent.PatheyoShare) || null; }

  var msgT = 0;
  function msg(t) { var m = UI.msg; m.textContent = t; m.classList.add('show'); clearTimeout(msgT); msgT = setTimeout(function () { m.classList.remove('show'); }, 2200); }

  function build() {
    var style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);
    var veil = document.createElement('div'); veil.className = 'pcs-veil';
    var sheet = document.createElement('div'); sheet.className = 'pcs-sheet'; sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'শেয়ার কার্ড');
    var m = document.createElement('div'); m.className = 'pcs-msg'; m.setAttribute('role', 'status');
    sheet.innerHTML =
      '<div class="pcs-grab"></div>' +
      '<div class="pcs-hd"><div class="pcs-t">শেয়ার কার্ড</div><button type="button" class="pcs-x" aria-label="বন্ধ করুন"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>' +
      '<div class="pcs-prev"></div>' +
      '<div class="pcs-hint" style="display:none">লেখা বড় হওয়ায় কার্ডে সংক্ষেপে দেখানো হয়েছে। পুরো লেখা লাগলে নিচের “শুধু লেখা কপি করুন” চাপুন, অথবা আরবি/অর্থের একটা বন্ধ করে দিন।</div>' +
      '<div class="pcs-lb">রঙের থিম</div><div class="pcs-th"></div>' +
      '<div class="pcs-lb">কার্ডে যা থাকবে</div><div class="pcs-tg"></div>' +
      '<div class="pcs-ac"><button type="button" class="pcs-go"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6.5" cy="12" r="2.3"/><circle cx="17.5" cy="6.5" r="2.3"/><circle cx="17.5" cy="17.5" r="2.3"/><path d="M8.5 10.9l7-3.3M8.5 13.1l7 3.3"/></svg><span>শেয়ার করুন</span></button>' +
      '<button type="button" class="pcs-sv"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19h14"/></svg><span>সেভ</span></button></div>' +
      '<button type="button" class="pcs-cp">শুধু লেখা কপি করুন</button>';
    document.body.appendChild(veil); document.body.appendChild(sheet); document.body.appendChild(m);
    UI = { veil: veil, sheet: sheet, msg: m, prev: sheet.querySelector('.pcs-prev'), hint: sheet.querySelector('.pcs-hint'), th: sheet.querySelector('.pcs-th'), tg: sheet.querySelector('.pcs-tg'),
           go: sheet.querySelector('.pcs-go'), sv: sheet.querySelector('.pcs-sv'), cp: sheet.querySelector('.pcs-cp') };
    UI.th.innerHTML = THEMES.map(function (t) {
      return '<button type="button" data-th="' + t.id + '"><i style="background:linear-gradient(135deg,' + t.bg[0] + ',' + t.bg[1] + ')"></i><span>' + t.n + '</span></button>';
    }).join('');
    veil.addEventListener('click', requestClose);
    sheet.querySelector('.pcs-x').addEventListener('click', requestClose);
    UI.th.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-th]') : null; if (!b) return; st.theme = b.getAttribute('data-th'); persist(); sync(); redraw(); });
    UI.tg.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-tg]') : null; if (!b) return; var k = b.getAttribute('data-tg'); var nx = !st[k]; var left = [k === 'ar' ? nx : st.ar, k === 'tr' ? nx : (st.tr && cur.tr), k === 'bn' ? nx : (st.bn && cur.bn)].some(Boolean); if (!left) { msg('অন্তত একটা লেখা রাখতে হবে'); return; } st[k] = nx; persist(); sync(); redraw(); });
    UI.go.addEventListener('click', doShare);
    UI.sv.addEventListener('click', doSave);
    UI.cp.addEventListener('click', doCopy);
    window.addEventListener('popstate', function () { if (opened) hide(); });
  }

  function sync() {
    Array.prototype.forEach.call(UI.th.children, function (b) { b.classList.toggle('on', b.getAttribute('data-th') === st.theme); });
    var h = '';
    if (cur.tr || cur.bn) h += '<button type="button" data-tg="ar" class="' + (st.ar ? 'on' : '') + '">আরবি</button>';
    if (cur.tr) h += '<button type="button" data-tg="tr" class="' + (st.tr ? 'on' : '') + '">উচ্চারণ</button>';
    if (cur.bn) h += '<button type="button" data-tg="bn" class="' + (st.bn ? 'on' : '') + '">অর্থ</button>';
    UI.tg.innerHTML = h || '<span style="opacity:.7;font-size:13px">এই কার্ডে শুধু আরবি থাকবে</span>';
    UI.tg.previousElementSibling.style.display = UI.tg.style.display = (cur.tr || cur.bn) ? '' : 'none';
    var b = bridge();
    UI.sv.style.display = (b && typeof b.canSave === 'function' && !b.canSave()) ? 'none' : '';
    UI.ac = null;
  }

  function redraw() {
    var my = ++renderTick;
    render(cur, { theme: st.theme, ar: st.ar, tr: st.tr, bn: st.bn }).then(function (c) {
      if (my !== renderTick) return;
      lastCanvas = c; UI.prev.innerHTML = ''; UI.prev.appendChild(c);
      UI.hint.style.display = c._cut ? '' : 'none';
    });
  }

  function pngB64() { return lastCanvas ? lastCanvas.toDataURL('image/png') : null; }
  function textOf() {
    var s = (cur.title ? cur.title + '\n\n' : '') + cur.ar;
    if (!st.ar) s = (cur.title ? cur.title + '\n\n' : '') + (st.bn && cur.bn ? '' : cur.ar);
    if (st.tr && cur.tr) s += '\n\nউচ্চারণ: ' + cur.tr;
    if (st.bn && cur.bn) s += '\n\nঅর্থ: ' + cur.bn;
    if (cur.ref) s += '\n\n(' + cur.ref + ')';
    return s + '\n\n— পাথেয় বাই গুঞ্জরণ\npatheyobygunjoron.github.io';
  }
  function fname() { return 'patheyo_' + (cur.kind || 'card') + '_' + Date.now(); }
  function dataUrlToBlob(u) { var p = u.split(','), mime = /:(.*?);/.exec(p[0])[1], bin = atob(p[1]), n = bin.length, a = new Uint8Array(n); while (n--) a[n] = bin.charCodeAt(n); return new Blob([a], { type: mime }); }

  function doShare() {
    var u = pngB64(); if (!u) return;
    var b = bridge(), caption = (cur.ref ? cur.ref + ' — ' : '') + 'পাথেয় বাই গুঞ্জরণ';
    if (b && typeof b.shareImage === 'function') { var ok = false; try { ok = b.shareImage(u, caption); } catch (e) {} if (!ok) msg('শেয়ার করা যায়নি'); return; }
    /* ব্রাউজার/অন্য পরিবেশ: Web Share (ফাইলসহ) → না হলে ডাউনলোড */
    try {
      var f = new File([dataUrlToBlob(u)], fname() + '.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) { navigator.share({ files: [f], text: caption }).catch(function () {}); return; }
    } catch (e) {}
    download(u);
  }
  function download(u) { var a = document.createElement('a'); a.href = u; a.download = fname() + '.png'; document.body.appendChild(a); a.click(); a.remove(); msg('ছবি ডাউনলোড হচ্ছে'); }
  function doSave() {
    var u = pngB64(); if (!u) return;
    var b = bridge();
    if (b && typeof b.saveImage === 'function') { var ok = false; try { ok = b.saveImage(u, fname()); } catch (e) {} msg(ok ? 'গ্যালারিতে সেভ হয়েছে (Pictures/Patheyo)' : 'সেভ করা যায়নি'); return; }
    download(u);
  }
  function doCopy() {
    var s = textOf(), b = bridge();
    function fb() { try { var ta = document.createElement('textarea'); ta.value = s; ta.style.cssText = 'position:fixed;left:-9999px;opacity:0'; document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); ta.remove(); msg(ok ? 'লেখা কপি হয়েছে' : 'কপি করা যায়নি'); } catch (e) { msg('কপি করা যায়নি'); } }
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(s).then(function () { msg('লেখা কপি হয়েছে'); }, fb); return; } } catch (e) {}
    fb();
  }

  function open(data) {
    if (!data || !data.ar) return;
    if (!UI) build();
    cur = { kind: data.kind || 'dua', cat: data.cat || '', topic: data.topic || '', title: data.title || '', ar: data.ar, tr: data.tr || '', bn: data.bn || '', ref: data.ref || '' };
    if (!cur.bn) st.bn = false; else if (!cur.tr) st.tr = false;
    sync(); UI.prev.innerHTML = '<span style="opacity:.6;font-size:13px">কার্ড তৈরি হচ্ছে…</span>';
    if (!opened) {
      opened = true;
      try { history.pushState({ pcs: 1 }, ''); } catch (e) {}
      UI.veil.classList.add('on'); UI.sheet.classList.add('on'); UI.sheet.scrollTop = 0;
      document.documentElement.classList.add('pcs-lock');
    }
    redraw();
  }
  function hide() { if (!opened) return; opened = false; UI.veil.classList.remove('on'); UI.sheet.classList.remove('on'); document.documentElement.classList.remove('pcs-lock'); }
  function requestClose() { if (!opened) return; if (history.state && history.state.pcs) history.back(); else hide(); }

  /* ---------- হাদিস/কুরআনের কার্ডে বসানোর ছোট "শেয়ার কার্ড" বোতাম (ফিচারের নিজের রঙের টোকেন নেয়) ---------- */
  var SHARE_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="4.5" width="17" height="15" rx="3.2"/><path d="M3.5 15.5l4.6-4.4 3.6 3.4 3-2.8 5.8 5.2M16.6 9.2h.01"/></svg>';
  var BTN_CSS = '.pt-sc-btn{width:38px;height:38px;border-radius:50%;border:0;display:grid;place-items:center;cursor:pointer;background:var(--accent-soft,rgba(14,123,184,.12));color:var(--accent,#0E7BB8);flex:none;padding:0;transition:transform .15s,background-color .25s}'
    + '.pt-sc-btn:active{transform:scale(.9)}'
    + '.pt-sc-btn svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;display:block}'
    + '.hd-acts{display:flex;align-items:center;gap:8px}'
    + '.tr-ayah{position:relative}.tr-ayah>.pt-sc-btn{position:absolute;top:14px;right:0;z-index:1}'
    + '.bm-share{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin:2px 0 14px;padding:11px 12px;border-radius:12px;border:1.5px dashed var(--accent,#0E7BB8);background:var(--accent-soft,rgba(14,123,184,.1));color:var(--accent,#0E7BB8);font-family:inherit;font-size:15px;font-weight:600;cursor:pointer}'
    + '.bm-share.hidden{display:none}.bm-share svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}';
  (function () { var st = document.createElement('style'); st.setAttribute('data-pt-sc', '1'); st.textContent = BTN_CSS; (document.head || document.documentElement).appendChild(st); })();
  function btnHtml() { return '<button type="button" class="pt-sc-btn" data-pt-share aria-label="শেয়ার কার্ড বানান" title="শেয়ার কার্ড">' + SHARE_ICON + '</button>'; }

  window.PtShareCard = { open: open, close: requestClose, themes: THEMES, btnHtml: btnHtml, _render: render };
})();
