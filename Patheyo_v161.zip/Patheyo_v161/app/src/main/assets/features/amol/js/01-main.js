
/* ============================================================
   AMOL REPORT — data model, content, and interaction logic
   ============================================================ */

/* ---------- defensive event binding ----------
   Prevents a single missing element or a thrown error inside one
   handler from ever blocking the rest of the script's button
   bindings (each call is isolated in its own try/catch). */
function on(id, evt, handler){
  try{
    const el = document.getElementById(id);
    if(!el){ return; }
    el.addEventListener(evt, function(e){
      try{ handler(e); }catch(err){ console.error('[amol] handler error on #'+id, err); }
    });
  }catch(err){ console.error('[amol] failed to bind #'+id, err); }
}

/* ---------- ripple micro-interaction (delegated, works on dynamic content) ---------- */
function attachRipple(root){
  try{
    root.addEventListener('pointerdown', function(e){
      const btn = e.target.closest('.rippleable');
      if(!btn) return;
      try{
        const rect = btn.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height) * 1.5;
        const span = document.createElement('span');
        span.className = 'ripple';
        span.style.width = span.style.height = size+'px';
        span.style.left = (e.clientX - rect.left - size/2)+'px';
        span.style.top = (e.clientY - rect.top - size/2)+'px';
        btn.appendChild(span);
        setTimeout(()=> { try{ span.remove(); }catch(err){} }, 620);
      }catch(err){}
    });
  }catch(err){}
}

/* ---------- refined icon set (original line-icon style, 24x24) ---------- */
const ICONS = {
  check:`<svg viewBox="0 0 24 24" fill="none"><path d="M6.5 12.5l3.5 3.5 7.5-8" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  cross:`<svg viewBox="0 0 24 24" fill="none"><path d="M7.5 7.5l9 9M16.5 7.5l-9 9" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  jamaat:`<svg viewBox="0 0 24 24" fill="none"><circle cx="8.3" cy="7.3" r="2.6" stroke="currentColor" stroke-width="1.8"/><path d="M3.2 18.5c0-2.9 2.3-5.1 5.1-5.1s5.1 2.2 5.1 5.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="16.2" cy="6.6" r="2.1" stroke="currentColor" stroke-width="1.8" opacity=".8"/><path d="M13.6 18.5c0-2.4 1.7-4.3 4.2-4.7 1.7-.3 3 .9 3 2.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" opacity=".8"/></svg>`,
  alone:`<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="7.6" r="3.6" stroke="currentColor" stroke-width="1.9"/><path d="M4.8 19.4c0-3.4 3.2-6.1 7.2-6.1s7.2 2.7 7.2 6.1" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>`,
  qaza:`<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="13" r="7.6" stroke="currentColor" stroke-width="1.9"/><path d="M12 9.2v4.1l2.8 1.9" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.4 3.4h5.2M12 3.4v2.2" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>`,
  moon:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.2 14.9A8.7 8.7 0 1 1 9.1 3.8a7.2 7.2 0 0 0 11.1 11.1Z"/></svg>`,
  clipboard:`<svg viewBox="0 0 24 24" fill="none"><rect x="5.5" y="4.5" width="13" height="16" rx="2.2" stroke="currentColor" stroke-width="1.8"/><path d="M9 4.2h6a1 1 0 0 1 1 1v.8H8v-.8a1 1 0 0 1 1-1Z" fill="currentColor" opacity=".18" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 12h7M8.5 15.5h5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>`,
  sparkleStar:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l1.9 6.3L20 10.5l-6.1 1.9L12 18.5l-1.9-6.1L4 10.5l6.1-1.7L12 2.5Z"/></svg>`,
  speakerOn:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.2 9.3h2.9l3.9-3.3c.7-.6 1.8-.1 1.8.8v10.4c0 .9-1.1 1.4-1.8.8l-3.9-3.3H4.2c-.7 0-1.2-.5-1.2-1.2v-3c0-.7.5-1.2 1.2-1.2z" fill="currentColor" stroke="none"/><path d="M16 9.1a4.2 4.2 0 0 1 0 5.8"/><path d="M18.7 6.5a8 8 0 0 1 0 11" opacity=".65"/></svg>`,
  speakerOff:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.2 9.3h2.9l3.9-3.3c.7-.6 1.8-.1 1.8.8v10.4c0 .9-1.1 1.4-1.8.8l-3.9-3.3H4.2c-.7 0-1.2-.5-1.2-1.2v-3c0-.7.5-1.2 1.2-1.2z" fill="currentColor" stroke="none"/><path d="M16.2 9.6l4.6 4.8M20.8 9.6l-4.6 4.8"/></svg>`,
  trash:`<svg viewBox="0 0 24 24" fill="none"><path d="M5 7h14M9.5 7V5.3a1.3 1.3 0 0 1 1.3-1.3h2.4a1.3 1.3 0 0 1 1.3 1.3V7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 7l.8 12.1A1.8 1.8 0 0 0 9.6 20.7h4.8a1.8 1.8 0 0 0 1.8-1.6L17 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.2 11v6M13.8 11v6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`,
  pdf:`<svg viewBox="0 0 24 24" fill="none"><path d="M7 3h7l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M14 3v4h4" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M8.3 17v-4.3h1.1c.9 0 1.5.6 1.5 1.5s-.6 1.5-1.5 1.5h-.4M12.6 17v-4.3h1c1.1 0 1.9.9 1.9 2.15S14.7 17 13.6 17h-1ZM17.2 17v-4.3h2.2M17.2 15h1.7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

/* ---------- gentle synthesized sound effects (Web Audio; no external files) ---------- */
const SoundFX = (function(){
  let ctx = null, boostNode = null;
  function ensureCtx(){
    if(ctx) return ctx;
    try{
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      // A gentle limiter lets us push tones louder without risking clipping,
      // and a boost stage in front of it raises perceived loudness on phone speakers.
      const compressor = ctx.createDynamicsCompressor();
      compressor.threshold.value = -14;
      compressor.knee.value = 20;
      compressor.ratio.value = 6;
      compressor.attack.value = 0.003;
      compressor.release.value = 0.16;
      compressor.connect(ctx.destination);
      boostNode = ctx.createGain();
      boostNode.gain.value = 1.9;
      boostNode.connect(compressor);
    }catch(e){ ctx = null; boostNode = null; }
    return ctx;
  }
  function tone(c, freq, start, dur, type, peakGain){
    try{
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.type = type || 'sine';
      osc.frequency.value = freq;
      const t0 = c.currentTime + start;
      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.exponentialRampToValueAtTime(peakGain || 0.24, t0 + 0.014);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      osc.connect(gain);
      gain.connect(boostNode || c.destination);
      osc.start(t0);
      osc.stop(t0 + dur + 0.03);
    }catch(e){}
  }
  function play(seq){
    if(!STATE.soundOn) return;
    const c = ensureCtx();
    if(!c) return;
    if(c.state === 'suspended'){ c.resume().catch(()=>{}); }
    seq.forEach(n=> tone(c, n.f, n.t, n.d, n.type, n.g));
  }
  return {
    tick(){ play([{f:640, t:0, d:.09, g:.22}]); },
    soft(){ play([{f:494, t:0, d:.16, g:.22}]); },
    success(){ play([{f:659, t:0, d:.12, g:.26}, {f:880, t:.09, d:.17, g:.26}]); },
    jamaat(){ play([{f:523, t:0, d:.1, g:.24}, {f:659, t:.08, d:.1, g:.24}, {f:784, t:.16, d:.24, g:.27}]); },
    miss(){ play([{f:349, t:0, d:.15, g:.26}, {f:262, t:.12, d:.26, g:.26}]); },
    complete(){ play([{f:523, t:0, d:.09, g:.22}, {f:659, t:.08, d:.09, g:.22}, {f:784, t:.16, d:.09, g:.22}, {f:988, t:.24, d:.3, g:.25}]); }
  };
})();

/* ---------- Bengali helpers ---------- */
const BN_DIGITS = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
function toBn(n){ return String(n).replace(/[0-9]/g, d => BN_DIGITS[d]); }
const WEEKDAYS_BN = ['রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','শনিবার'];
const MONTHS_BN = ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
function pad2(n){ return n<10 ? '0'+n : ''+n; }
function dateKey(d){ return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()); }
function monthKey(d){ return d.getFullYear()+'-'+pad2(d.getMonth()+1); }
function bnFullDate(d){
  return toBn(d.getDate())+' '+MONTHS_BN[d.getMonth()]+', '+toBn(d.getFullYear())+' ('+WEEKDAYS_BN[d.getDay()]+')';
}
function bnMonthLabel(d){ return MONTHS_BN[d.getMonth()]+' '+toBn(d.getFullYear()); }
function daysInMonth(y,m){ return new Date(y, m+1, 0).getDate(); }

/* ---------- slot definitions ----------
   Storage keys are position-based so Friday/weekday share one column set.
*/
const SLOT_DEFS = [
  {id:'fajr_s1', type:'sunnah', label:()=> 'ফজরের আগে সুন্নত', short:'ফজর সু.'},
  {id:'fajr',    type:'fard',   label:()=> 'ফজর', short:'ফজর'},
  {id:'midday_s1', type:'sunnah', label:(fri)=> fri? 'জুমুআর আগে সুন্নত':'যোহরের আগে সুন্নত', short:(fri)=>fri?'জুমুআ সু.':'যোহর সু.'},
  {id:'midday',    type:'fard',   label:(fri)=> fri? 'জুমুআ':'যোহর', short:(fri)=>fri?'জুমুআ':'যোহর'},
  {id:'midday_s2', type:'sunnah', label:(fri)=> fri? 'জুমুআর পরে সুন্নত':'যোহরের পরে সুন্নত', short:(fri)=>fri?'জুমুআ সু.২':'যোহর সু.২'},
  {id:'asr_s1',  type:'sunnah', label:()=> 'আসরের আগে সুন্নত', short:'আসর সু.'},
  {id:'asr',     type:'fard',   label:()=> 'আসর', short:'আসর'},
  {id:'maghrib', type:'fard',   label:()=> 'মাগরিব', short:'মাগরিব'},
  {id:'maghrib_s1', type:'sunnah', label:()=> 'মাগরিবের পরে সুন্নত', short:'মাগরিব সু.'},
  {id:'isha_s1', type:'sunnah', label:()=> 'এশার আগে সুন্নত', short:'এশা সু.'},
  {id:'isha',    type:'fard',   label:()=> 'এশা', short:'এশা'},
  {id:'isha_s2', type:'sunnah', label:()=> 'এশার পরে সুন্নত', short:'এশা সু.২'},
  {id:'witr',    type:'fard',   label:()=> 'বিতর', short:'বিতর'},
];
function slotLabel(def, isFriday){ return typeof def.label==='function' ? def.label(isFriday) : def.label; }
function slotShort(def, isFriday){ return typeof def.short==='function' ? def.short(isFriday) : def.short; }

const FARD_GROUPS = [
  {key:'fajr', label:'ফজর', slots:['fajr']},
  {key:'midday', label:'যোহর/জুমুআ', slots:['midday']},
  {key:'asr', label:'আসর', slots:['asr']},
  {key:'maghrib', label:'মাগরিব', slots:['maghrib']},
  {key:'isha', label:'এশা', slots:['isha']},
  {key:'witr', label:'বিতর', slots:['witr']},
];
const SUNNAH_IDS = SLOT_DEFS.filter(s=>s.type==='sunnah').map(s=>s.id);
const FARD_IDS = SLOT_DEFS.filter(s=>s.type==='fard').map(s=>s.id);

/* ---------- content pools (ayat/hadith, ভাবার্থ — paraphrased meaning, not verbatim translation) ---------- */
const POOL_CONGRATS = [
  {kind:'আয়াত', ref:'সূরা আল-বাকারা, ২:২৭৭', text:'যারা ঈমান আনে, সৎকাজ করে, সালাত কায়েম করে ও যাকাত আদায় করে — তাদের জন্য তাদের রবের কাছে প্রতিদান রয়েছে; তাদের কোনো ভয় নেই এবং তারা দুঃখিতও হবে না।'},
  {kind:'আয়াত', ref:'সূরা আল-মাআরিজ, ৭০:৩৪-৩৫', text:'যারা নিজেদের সালাতের প্রতি যত্নবান ও নিয়মিত, তারাই জান্নাতে সম্মানিতভাবে থাকবে।'},
  {kind:'আয়াত', ref:'সূরা আল-মুমিনুন, ২৩:১-২, ৯-১১', text:'মুমিনগণ সফলকাম — যারা নিজেদের সালাতে বিনম্র এবং তার যত্ন নেয়; তারাই জান্নাতের ওয়ারিশ।'},
  {kind:'আয়াত', ref:'সূরা ত্বা-হা, ২০:১৩২', text:'নিজের পরিবারকে সালাতের নির্দেশ দাও এবং নিজেও তাতে ধৈর্যশীল থাকো; শুভ পরিণতি মুত্তাকীদের জন্যই।'},
  {kind:'আয়াত', ref:'সূরা আল-আনকাবুত, ২৯:৪৫', text:'সালাত কায়েম করো — নিশ্চয় সালাত অশ্লীলতা ও গর্হিত কাজ থেকে বিরত রাখে, আর আল্লাহর স্মরণই সর্বশ্রেষ্ঠ।'},
];
const POOL_JAMAAT = [
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'জামাতে আদায়কৃত সালাত একাকী আদায়কৃত সালাতের চেয়ে সাতাশ গুণ বেশি মর্যাদাপূর্ণ।'},
  {kind:'হাদিস', ref:'আবু দাউদ ও তিরমিযী', text:'যে ব্যক্তি এশার সালাত জামাতে আদায় করে, সে যেন অর্ধরাত ইবাদত করলো; আর যে ফজরও জামাতে আদায় করে, সে যেন সারা রাত ইবাদতে কাটালো।'},
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'মসজিদের দিকে ফেলা প্রতিটি কদমে একটি নেকী লেখা হয় ও একটি গুনাহ মোচন করা হয়।'},
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'এক সালাতের পর পরবর্তী সালাতের অপেক্ষায় বসে থাকা ব্যক্তির জন্য ফেরেশতারা ক্রমাগত ক্ষমা প্রার্থনা করতে থাকেন।'},
  {kind:'আয়াত', ref:'সূরা আল-জুমুআ, ৬২:৯', text:'যখন জুমুআর দিন সালাতের জন্য আহ্বান করা হয়, তখন আল্লাহর স্মরণের দিকে দ্রুত ধাবিত হও — এটাই তোমাদের জন্য উত্তম।'},
];
const POOL_ALONE = [
  {kind:'হাদিস', ref:'সহীহ বুখারী', text:'জামাতে অনুপস্থিত থাকা এতটাই গুরুত্বপূর্ণ বিষয় বলে গণ্য হতো যে, রাসূল সা. তাদের ঘরে গিয়ে সালাতের গুরুত্ব স্মরণ করিয়ে দেওয়ার কথা ভাবতেন।'},
  {kind:'হাদিস', ref:'আবু দাউদ, তিরমিযী, নাসায়ী', text:'তিন ব্যক্তি এক এলাকায় থেকেও যদি জামাতে সালাত আদায় না করে, শয়তান তাদের উপর প্রভাব বিস্তার করে — তাই জামাতের সাথে থাকা জরুরি।'},
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'এক দৃষ্টিহীন সাহাবী অব্যাহতি চাইলে রাসূল সা. জিজ্ঞেস করলেন, তুমি কি আযান শুনতে পাও? তিনি বললেন হ্যাঁ। রাসূল সা. বললেন, তাহলে সাড়া দাও।'},
  {kind:'আয়াত', ref:'সূরা আন-নিসা, ৪:১০২', text:'যুদ্ধ-বিপদের সময়েও জামাতে সালাত আদায়ের নির্দেশ এসেছে — স্বাভাবিক অবস্থায় এর গুরুত্ব আরও বেশি।'},
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'জামাতে সালাত আদায়কারীর সালাত একাকী সালাতের চেয়ে বহুগুণ শ্রেষ্ঠ — সাধ্যমতো পরের বার জামাতে শামিল হওয়ার চেষ্টা রাখুন।'},
];
const POOL_QAZA = [
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'কেউ ঘুমিয়ে পড়ার কারণে বা ভুলে সালাত ছুটিয়ে ফেললে, স্মরণ হওয়ামাত্র তা আদায় করে নেবে — এটাই তার কাফফারা।'},
  {kind:'আয়াত', ref:'সূরা আন-নিসা, ৪:১০৩', text:'নিশ্চয় সালাত মুমিনদের উপর নির্দিষ্ট সময়ে ফরয করে দেওয়া হয়েছে।'},
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'সর্বোত্তম আমলগুলোর একটি হলো — সালাত তার নির্ধারিত সময়ে আদায় করা।'},
  {kind:'হাদিস', ref:'জামে তিরমিযী', text:'কিয়ামতের দিন বান্দার আমলের মধ্যে সর্বপ্রথম সালাতের হিসাব নেওয়া হবে; তা ঠিক থাকলে বাকি আমলও ঠিক থাকবে।'},
  {kind:'আয়াত', ref:'সূরা আল-বাকারা, ২:২৩৮', text:'সালাতসমূহের এবং বিশেষভাবে মধ্যবর্তী সালাতের হেফাজত করো, আর আল্লাহর উদ্দেশ্যে বিনীতভাবে দাঁড়াও।'},
];
const POOL_MISSED = [
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'বান্দা ও কুফরের মধ্যে পার্থক্যকারী বিষয় হলো সালাত ত্যাগ করা — তাই ফিরে আসার পথ সবসময় খোলা।'},
  {kind:'আয়াত', ref:'সূরা আল-মুদ্দাসসির, ৭৪:৪২-৪৩', text:'জাহান্নামীদের জিজ্ঞাসা করা হবে, কিসে তোমাদের এখানে নিয়ে এলো? তারা বলবে, আমরা সালাত আদায়কারীদের অন্তর্ভুক্ত ছিলাম না।'},
  {kind:'আয়াত', ref:'সূরা মারইয়াম, ১৯:৫৯', text:'তাদের পরে এমন এক প্রজন্ম এলো যারা সালাত নষ্ট করলো এবং প্রবৃত্তির অনুসরণ করলো — তারা শীঘ্রই বিপথগামিতার পরিণাম দেখবে।'},
  {kind:'হাদিস', ref:'জামে তিরমিযী', text:'বান্দা ও শিরকের মাঝে পার্থক্যকারী বিষয় হলো সালাত ত্যাগ করা — আজই আবার শুরু করার সুযোগ আছে।'},
  {kind:'আয়াত', ref:'সূরা আত-তাওবা, ৯:১১', text:'তারা যদি তওবা করে, সালাত কায়েম করে ও যাকাত দেয়, তবে তারা দ্বীনে তোমাদের ভাই।'},
];
function pickQuote(pool, seed){ return pool[seed % pool.length]; }

/* ---------- global state ---------- */
let STATE = { theme:'light', soundOn:true, customAmals:[], days:{} };
let dbNs = null, stateRef = null, writeChain = Promise.resolve();
let today = new Date();
let sheetMonthCursor = new Date(today.getFullYear(), today.getMonth(), 1);
let flowQueue = [];
let flowIndex = 0;
let flowDateKey = dateKey(today);
let flowResults = {}; // buffered results for the active flow session

/* ---------- persistence ---------- */
function withTimeout(promise, ms){
  return Promise.race([
    promise,
    new Promise((resolve)=> setTimeout(()=> resolve(null), ms))
  ]);
}
function loadLocalFallback(){
  try{
    const raw = localStorage.getItem('amol_report_state');
    if(raw){
      const parsed = JSON.parse(raw);
      if(parsed){
        STATE = parsed;
        if(typeof STATE.soundOn !== 'boolean') STATE.soundOn = true;
      }
    }
  }catch(e){}
}
async function initStorage(){
  // Load whatever we have locally first, synchronously-ish, so the UI
  // never waits on the network/db before becoming interactive.
  loadLocalFallback();
  try{
    if(window.claude && window.claude.use){
      dbNs = await withTimeout(window.claude.use('db'), 4000);
    }
  }catch(e){ dbNs = null; }

  // Prefer a private per-viewer path (data/users/<id>/...) so the same
  // published link never lets two different people share or overwrite
  // each other's report — falls back to a shared doc if no identity
  // is available (e.g. an anonymous preview).
  let docPath = 'state/app';
  try{
    if(window.claude && window.claude.use){
      const userNs = await withTimeout(window.claude.use('user'), 3000);
      if(userNs){
        const uid = await withTimeout(userNs.id(), 3000);
        if(uid){ docPath = 'data/users/'+uid+'/state/app'; }
      }
    }
  }catch(e){}

  if(dbNs){
    stateRef = dbNs.doc(docPath);
    try{
      const snap = await withTimeout(stateRef.get(), 4000);
      if(snap && snap.exists && snap.data()){
        const d = snap.data();
        STATE = { theme:d.theme||STATE.theme, soundOn: (typeof d.soundOn==='boolean'? d.soundOn : STATE.soundOn), customAmals:d.customAmals||STATE.customAmals, days:d.days||STATE.days };
      }
    }catch(e){}
    try{
      stateRef.onSnapshot((snap)=>{
        if(!snap || !snap.exists) return;
        const d = snap.data();
        if(!d) return;
        STATE = { theme:d.theme||STATE.theme, soundOn: (typeof d.soundOn==='boolean'? d.soundOn : STATE.soundOn), customAmals:d.customAmals||STATE.customAmals, days:d.days||STATE.days };
        applyTheme();
        applySound();
        renderHome();
      }, ()=>{});
    }catch(e){}
  }
}
function persist(){
  const snapshot = JSON.parse(JSON.stringify(STATE));
  writeChain = writeChain.then(()=>{
    if(dbNs && stateRef){
      try{ localStorage.setItem('amol_report_state', JSON.stringify(snapshot)); }catch(e){}
      return stateRef.set(snapshot).catch(()=>{});
    } else {
      try{ localStorage.setItem('amol_report_state', JSON.stringify(snapshot)); }catch(e){}
      return Promise.resolve();
    }
  });
}

/* ---------- theme ---------- */
function applyTheme(){
  document.documentElement.setAttribute('data-theme', STATE.theme==='dark' ? 'dark':'light');
}
on('themeBtn', 'click', ()=>{
  STATE.theme = STATE.theme==='dark' ? 'light':'dark';
  applyTheme();
  applySound();
  persist();
});

function applySound(){
  try{
    const hs = document.getElementById('headSnd');
    if(hs){ hs.classList.toggle('on', !!STATE.soundOn); hs.setAttribute('aria-pressed', STATE.soundOn ? 'true':'false'); }
    const onEl = document.getElementById('soundIcoOn');
    const offEl = document.getElementById('soundIcoOff');
    if(onEl) onEl.innerHTML = ICONS.speakerOn;
    if(offEl) offEl.innerHTML = ICONS.speakerOff;
    // NOTE: must match the CSS centering rule's display value (flex) —
    // setting 'block' here would win over the .flow-sound span{display:flex}
    // rule (inline styles beat class rules) and silently break centering.
    if(onEl) onEl.style.display = STATE.soundOn ? 'flex' : 'none';
    if(offEl) offEl.style.display = STATE.soundOn ? 'none' : 'flex';
  }catch(e){}
}
function toggleSound(){
  STATE.soundOn = !STATE.soundOn;
  applySound();
  persist();
  if(STATE.soundOn){ SoundFX.tick(); }
}
on('soundToggleBtn', 'click', toggleSound);
on('headSnd', 'click', toggleSound);

/* ---------- day helpers ---------- */
function getDaySlots(d){
  const isFriday = d.getDay()===5;
  let slots = SLOT_DEFS.map(def=>({
    id:def.id, type:def.type, label:slotLabel(def,isFriday), short:slotShort(def,isFriday)
  }));
  // inject linked custom amals right after their anchor slot
  const anchorMap = {'after:fajr':'fajr','before:zuhr':'midday_s1','after:asr':'asr','after:maghrib':'maghrib','after:isha':'isha'};
  const withCustom = [];
  slots.forEach(s=>{
    withCustom.push(s);
    STATE.customAmals.forEach(ca=>{
      if(anchorMap[ca.when]===s.id){
        withCustom.push({id:'custom_'+ca.id, type:'custom', label:ca.name, short:ca.name});
      }
    });
  });
  // evening-only custom amals appended at the end
  STATE.customAmals.forEach(ca=>{
    if(ca.when==='evening'){
      withCustom.push({id:'custom_'+ca.id, type:'custom', label:ca.name, short:ca.name});
    }
  });
  return withCustom;
}
function getDayRecord(key){ return STATE.days[key] || {}; }
function setDayRecord(key, slotId, value){
  if(!STATE.days[key]) STATE.days[key] = {};
  STATE.days[key][slotId] = value;
  persist();
}
function isPositive(type, val){
  if(!val) return false;
  if(type==='fard') return val==='jamaat' || val==='alone';
  return val==='done';
}

/* ---------- render: header/date ---------- */
function renderHeaderDate(){
  document.getElementById('todayLabel').textContent = bnFullDate(today);
}

/* ---------- render: hero ring ---------- */
function renderHero(){
  const key = dateKey(today);
  const slots = getDaySlots(today);
  const rec = getDayRecord(key);
  const total = slots.length;
  let done = 0;
  slots.forEach(s=>{ if(rec[s.id]) done++; });
  const circumference = 207;
  const ratio = total? done/total : 0;
  document.getElementById('ringProgress').setAttribute('stroke-dashoffset', circumference - circumference*ratio);
  document.getElementById('ringText').textContent = toBn(done)+'/'+toBn(total);
  const startBtn = document.getElementById('startFlowBtn');
  const editBtn = document.getElementById('editTodayBtn');
  const sub = document.getElementById('heroSub');
  if(done>=total && total>0){
    startBtn.style.display='none';
    editBtn.style.display='block';
    sub.textContent = 'আজকের রিপোর্ট সম্পন্ন হয়েছে — মাশাআল্লাহ';
  } else if(done>0){
    startBtn.textContent = 'চালিয়ে যান';
    startBtn.style.display='block';
    editBtn.style.display='block';
    sub.textContent = toBn(total-done)+' টি এন্ট্রি বাকি আছে';
  } else {
    startBtn.textContent = 'রিপোর্ট শুরু করুন';
    startBtn.style.display='block';
    editBtn.style.display='none';
    sub.textContent = 'আজকের নামাজ ও সুন্নত এন্ট্রি করুন';
  }
}

/* ---------- render: custom amal list on home ---------- */
function renderCustomAmalList(){
  const wrap = document.getElementById('customAmalList');
  wrap.innerHTML='';
  if(STATE.customAmals.length===0){
    wrap.innerHTML = '<p class="hint" style="margin-top:6px;">এখনো কোনো নিজস্ব আমল যুক্ত করা হয়নি।</p>';
    return;
  }
  const rec = getDayRecord(dateKey(today));
  const whenLabel = {'after:fajr':'ফজরের পরে','before:zuhr':'যোহর/জুমুআর আগে','after:asr':'আসরের পরে','after:maghrib':'মাগরিবের পরে','after:isha':'এশার পরে','evening':'রাত ১০টায়'};
  STATE.customAmals.forEach(ca=>{
    const val = rec['custom_'+ca.id];
    const row = document.createElement('div');
    row.className='amal-item';
    let chipHtml;
    if(val==='done') chipHtml = '<span class="chip done">সম্পন্ন</span>';
    else if(val==='missed') chipHtml = '<span class="chip missed">হয়নি</span>';
    else chipHtml = '<span class="chip pending">বাকি</span>';
    row.innerHTML = '<div><div class="name">'+escapeHtml(ca.name)+'</div><span class="when">'+ (whenLabel[ca.when]||ca.when) +'</span></div>'
      + '<div class="amal-item-right">' + chipHtml
      + '<button type="button" class="amal-del-btn rippleable" data-id="'+ca.id+'" data-name="'+escapeHtml(ca.name)+'" aria-label="মুছুন">'+ICONS.trash+'</button></div>';
    wrap.appendChild(row);
  });
  wrap.querySelectorAll('.amal-del-btn').forEach(btn=>{
    btn.addEventListener('click', ()=> openDeleteAmalConfirm(btn.dataset.id, btn.dataset.name));
  });
}
function escapeHtml(s){ return s.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

let pendingDeleteAmalId = null;
function openDeleteAmalConfirm(id, name){
  pendingDeleteAmalId = id;
  const textEl = document.getElementById('confirmDeleteText');
  if(textEl) textEl.textContent = '"'+name+'" আমলটি মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা যাবে না।';
  const mask = document.getElementById('confirmDeleteMask');
  if(mask) mask.classList.add('show');
}

/* ---------- render: monthly summary on home ---------- */
function computeMonthStats(y,m){
  const dim = daysInMonth(y,m);
  const now = new Date();
  const isCurrent = (y===now.getFullYear() && m===now.getMonth());
  const upto = isCurrent ? now.getDate() : dim;
  const groupStats = {};
  FARD_GROUPS.forEach(g=> groupStats[g.key] = {pos:0, total:0});
  let sunnahPos=0, sunnahTotal=0;
  for(let day=1; day<=upto; day++){
    const d = new Date(y,m,day);
    const key = dateKey(d);
    const rec = STATE.days[key] || {};
    const isFriday = d.getDay()===5;
    FARD_IDS.forEach(id=>{
      const group = FARD_GROUPS.find(g=>g.slots.includes(id));
      if(!group) return;
      groupStats[group.key].total++;
      if(isPositive('fard', rec[id])) groupStats[group.key].pos++;
    });
    SUNNAH_IDS.forEach(id=>{
      sunnahTotal++;
      if(isPositive('sunnah', rec[id])) sunnahPos++;
    });
  }
  let fardPos=0, fardTotal=0;
  Object.values(groupStats).forEach(g=>{ fardPos+=g.pos; fardTotal+=g.total; });
  const overallPos = fardPos+sunnahPos, overallTotal = fardTotal+sunnahTotal;
  const pct = overallTotal? Math.round((overallPos/overallTotal)*100) : 0;
  const groupPct = {};
  FARD_GROUPS.forEach(g=>{ groupPct[g.key] = groupStats[g.key].total? Math.round((groupStats[g.key].pos/groupStats[g.key].total)*100):0; });
  const sunnahPct = sunnahTotal? Math.round((sunnahPos/sunnahTotal)*100):0;
  return {pct, groupPct, sunnahPct, upto};
}
function renderMonthlySummary(){
  const cur = computeMonthStats(today.getFullYear(), today.getMonth());
  const prevD = new Date(today.getFullYear(), today.getMonth()-1, 1);
  const prev = computeMonthStats(prevD.getFullYear(), prevD.getMonth());
  document.getElementById('curMonthPct').textContent = toBn(cur.pct)+'%';
  document.getElementById('prevMonthPct').textContent = toBn(prev.pct)+'%';
  const delta = cur.pct - prev.pct;
  const deltaEl = document.getElementById('deltaMonthPct');
  deltaEl.textContent = (delta>=0?'▲ ':'▼ ')+toBn(Math.abs(delta))+'%';
  deltaEl.className = 'val ' + (delta>=0?'up':'down');
}

/* ---------- ধারা (streak): টানা কত দিন পাঁচ ওয়াক্তই আদায় হয়েছে ---------- */
const FIVE_WAQT = ['fajr','midday','asr','maghrib','isha'];
const WD_SHORT = ['রবি','সোম','মঙ্গল','বুধ','বৃহ','শুক্র','শনি'];
const MILESTONES = [3,7,14,21,40,100,365];
function keyAdd(key, n){ const p = key.split('-').map(Number); return dateKey(new Date(p[0], p[1]-1, p[2]+n)); }
function waqtDone(rec, id, needJamaat){ return needJamaat ? rec[id]==='jamaat' : isPositive('fard', rec[id]); }
function dayFull(key, needJamaat){ const rec = STATE.days[key]; return !!rec && FIVE_WAQT.every(id=> waqtDone(rec, id, needJamaat)); }
function dayDoneCount(key){ const rec = STATE.days[key] || {}; return FIVE_WAQT.filter(id=> isPositive('fard', rec[id])).length; }
function dayHasLoss(key){ const rec = STATE.days[key] || {}; return FIVE_WAQT.some(id=> rec[id] && !isPositive('fard', rec[id])); }   // কাজা/বাদ লেখা আছে
function streakNow(needJamaat){
  const tk = dateKey(today);
  let k = tk;
  if(!dayFull(k, needJamaat)){
    if(dayHasLoss(tk)) return 0;                  // আজ ওয়াক্ত বাদ/কাজা — ধারা ভেঙেছে
    k = keyAdd(k, -1);                            // আজ এখনো চলছে — গতকাল পর্যন্ত ধারা ধরে রাখা হয়
  }
  let n = 0;
  while(dayFull(k, needJamaat) && n < 4000){ n++; k = keyAdd(k, -1); }
  return n;
}
function streakBest(needJamaat){
  const ks = Object.keys(STATE.days).sort();
  let run = 0, best = 0, prev = null;
  ks.forEach(k=>{
    if(!dayFull(k, needJamaat)){ run = 0; prev = null; return; }
    run = (prev && keyAdd(prev, 1)===k) ? run+1 : 1;
    prev = k; if(run>best) best = run;
  });
  return best;
}
function renderStreak(){
  const card = document.getElementById('streakCard'); if(!card) return;
  const tk = dateKey(today);
  const n = streakNow(false), nj = streakNow(true);
  const best = Math.max(streakBest(false), n);
  document.getElementById('skNow').textContent = toBn(n);
  document.getElementById('skBest').textContent = toBn(best);
  document.getElementById('skJam').textContent = toBn(nj)+' দিন';
  card.classList.toggle('off', n===0);
  // এ মাসের পূর্ণ দিন
  let monthFull = 0;
  for(let d=1; d<=today.getDate(); d++){ if(dayFull(dateKey(new Date(today.getFullYear(), today.getMonth(), d)), false)) monthFull++; }
  document.getElementById('skMon').textContent = toBn(monthFull)+'/'+toBn(today.getDate());
  // গত ৭ দিনের বৃত্ত
  let dots = '';
  for(let i=6; i>=0; i--){
    const k = keyAdd(tk, -i), p = k.split('-').map(Number), wd = new Date(p[0], p[1]-1, p[2]).getDay();
    const full = dayFull(k, false), cnt = dayDoneCount(k);
    const cls = full ? 'full' : (cnt>0 ? 'part' : 'none');
    dots += '<div class="sk-d '+cls+(k===tk?' now':'')+'"><span class="sk-c">'+(full ? '✓' : (cnt>0 ? toBn(cnt) : ''))+'</span><span class="sk-w">'+WD_SHORT[wd]+'</span></div>';
  }
  document.getElementById('skWeek').innerHTML = dots;
  // আজকের বার্তা
  const msg = document.getElementById('skMsg');
  const doneToday = dayDoneCount(tk);
  if(dayFull(tk, false)){ msg.textContent = 'আজকের পাঁচ ওয়াক্তই পূর্ণ — মাশাআল্লাহ'; msg.className = 'sk-msg ok'; }
  else if(dayHasLoss(tk)){ msg.textContent = 'আজ একটি ওয়াক্ত বাদ/কাজা — আজকের ধারা ভেঙেছে। কাল নতুন করে শুরু করুন, ইনশাআল্লাহ।'; msg.className = 'sk-msg warn'; }
  else if(n>0){ msg.textContent = 'আজ আর '+toBn(5-doneToday)+' ওয়াক্ত বাকি — ধারা ধরে রাখুন'; msg.className = 'sk-msg'; }
  else { msg.textContent = 'আজ পাঁচ ওয়াক্ত পূর্ণ করে নতুন ধারা শুরু করুন'; msg.className = 'sk-msg'; }
  // পরের মাইলফলক
  const nm = MILESTONES.find(m=> m>n);
  document.getElementById('skBar').style.width = (nm ? Math.min(100, n/nm*100) : 100)+'%';
  document.getElementById('skNext').textContent = nm ? 'পরের মাইলফলক: '+toBn(nm)+' দিন (আর '+toBn(nm-n)+' দিন)' : 'মাশাআল্লাহ! সব মাইলফলক পার করেছেন';
}

function renderHome(){
  renderHeaderDate();
  renderHero();
  renderStreak();
  renderCustomAmalList();
  renderMonthlySummary();
}

/* ================= FLOW ================= */
function buildFlowQueue(dKey){
  const d = new Date(dKey+'T00:00:00');
  const slots = getDaySlots(d);
  const rec = getDayRecord(dKey);
  return slots.filter(s=> !rec[s.id]);
}

/* ---------- back-navigation (in-app button + real browser/hardware back) ----------
   flowScreenStack remembers every screen the person has moved forward from inside
   the current flow session, so both the on-screen back arrow and the device's own
   back button can undo one step at a time. A single "trap" history entry is kept
   armed while any overlay is open; the trap is re-armed after every step-back so
   repeated back presses keep being caught until there's nothing left to undo. */
let flowScreenStack = [];
let navTrapArmed = false;
let intentionalNavClose = false;

function isFlowOpen(){ const el=document.getElementById('flowOverlay'); return !!(el && el.classList.contains('show')); }
function isSheetOpen(){ const el=document.getElementById('sheetOverlay'); return !!(el && el.classList.contains('show')); }

function armNavTrap(){
  try{ history.pushState({amolNav:true, t:Date.now()}, '', location.href); navTrapArmed = true; }
  catch(e){ navTrapArmed = false; }
}
function updateFlowBackBtn(){
  const btn = document.getElementById('flowBackBtn');
  if(!btn) return;
  btn.style.display = flowScreenStack.length>0 ? 'flex' : 'none';
}
/* Pushes an undo point for the screen being left, then renders the next one. */
function goForward(desc, renderFn){
  flowScreenStack.push(desc);
  renderFn();
  updateFlowBackBtn();
}
/* Re-renders a screen popped off the undo stack — never pushes anything itself. */
function renderDescriptor(desc){
  const item = flowQueue[desc.index];
  flowIndex = desc.index;
  if(!item){ renderFlowStep(); return; }
  if(desc.type==='ask'){
    setFlowTint('flow-tint-neutral');
    if(item.type==='fard') renderFardAsk(item); else renderSimpleAsk(item);
  } else if(desc.type==='congrats'){
    renderCongrats(item);
  } else if(desc.type==='subResult'){
    renderSubResult(item, desc.kind);
  } else if(desc.type==='missedResult'){
    renderMissedResult(item);
  } else {
    renderFlowStep();
  }
}
function hideFlowOverlayOnly(){ document.getElementById('flowOverlay').classList.remove('show'); }
function hideSheetOverlayOnly(){
  document.getElementById('sheetOverlay').classList.remove('show');
  const pop = document.getElementById('popMask'); if(pop) pop.classList.remove('show');
}
/* The in-app arrow acts immediately (no waiting on the browser's async
   popstate round-trip, which can feel unresponsive on some phones). It
   still nudges history back to keep the hardware/browser back button in
   sync — suppressNextPopstate stops that resulting popstate from acting
   a second time. */
let suppressNextPopstate = false;
on('flowBackBtn', 'click', ()=>{
  if(flowScreenStack.length===0) return;
  const desc = flowScreenStack.pop();
  renderDescriptor(desc);
  updateFlowBackBtn();
  if(navTrapArmed){
    suppressNextPopstate = true;
    try{ history.back(); }catch(e){ suppressNextPopstate = false; }
    setTimeout(()=>{ if(suppressNextPopstate){ suppressNextPopstate = false; armNavTrap(); } }, 700);
  }
});

window.addEventListener('popstate', function(){
  if(suppressNextPopstate){
    suppressNextPopstate = false;
    armNavTrap();
    return;
  }
  if(intentionalNavClose){
    intentionalNavClose = false;
    navTrapArmed = false;
    if(isFlowOpen()){ hideFlowOverlayOnly(); flowScreenStack = []; }
    if(isSheetOpen()){ hideSheetOverlayOnly(); }
    renderHome();
    return;
  }
  if(isFlowOpen()){
    if(flowScreenStack.length>0){
      const desc = flowScreenStack.pop();
      renderDescriptor(desc);
      updateFlowBackBtn();
      armNavTrap();
    } else {
      navTrapArmed = false;
      hideFlowOverlayOnly();
      renderHome();
    }
    return;
  }
  if(isSheetOpen()){
    navTrapArmed = false;
    hideSheetOverlayOnly();
    return;
  }
});

function openFlow(dKey, forceAll){
  flowDateKey = dKey;
  const d = new Date(dKey+'T00:00:00');
  flowQueue = forceAll ? getDaySlots(d) : buildFlowQueue(dKey);
  flowIndex = 0;
  flowResults = {};
  flowScreenStack = [];
  document.getElementById('flowOverlay').classList.add('show');
  renderFlowStep();
  updateFlowBackBtn();
  armNavTrap();
}
function closeFlow(opts){
  opts = opts || {};
  if(opts.silent){
    hideFlowOverlayOnly();
    flowScreenStack = [];
    renderHome();
    return;
  }
  if(navTrapArmed){
    intentionalNavClose = true;
    history.back();
  } else {
    hideFlowOverlayOnly();
    flowScreenStack = [];
    renderHome();
  }
}
on('flowCloseBtn', 'click', ()=> closeFlow());
on('startFlowBtn', 'click', ()=> openFlow(dateKey(today), false));
on('editTodayBtn', 'click', ()=> openFlow(dateKey(today), true));

function setFlowTint(cls){
  const inner = document.getElementById('flowInner');
  inner.className = 'flow-inner ' + cls;
}
function updateFlowChrome(){
  const total = flowQueue.length;
  const pct = total? Math.round((flowIndex/total)*100) : 100;
  document.getElementById('flowProgressBar').style.transform = 'scaleX('+(pct/100)+')';
  document.getElementById('flowCount').textContent = toBn(Math.min(flowIndex,total))+'/'+toBn(total);
}
function sparkleBurstHTML(colorVar){
  let html = '<div class="sparkle-burst">';
  const n = 8;
  for(let i=0;i<n;i++){
    const angle = (Math.PI*2/n)*i;
    const dist = 34 + (i%2)*8;
    const dx = Math.round(Math.cos(angle)*dist);
    const dy = Math.round(Math.sin(angle)*dist);
    html += `<span style="--dx:${dx}px;--dy:${dy}px; background:${colorVar}; animation-delay:${i*22}ms;"></span>`;
  }
  html += '</div>';
  return html;
}
/* Cross-fades the flow body between steps; onReady binds listeners on the freshly-inserted markup. */
function setFlowBodyContent(html, onReady){
  const body = document.getElementById('flowBody');
  body.classList.remove('fx-in');
  body.classList.add('fx-out');
  setTimeout(()=>{
    body.innerHTML = html;
    body.classList.remove('fx-out');
    void body.offsetWidth; // restart animation
    body.classList.add('fx-in');
    try{ if(onReady) onReady(); }catch(err){ console.error('[amol] render bind error', err); }
    setTimeout(()=> body.classList.remove('fx-in'), 460);
  }, 130);
}

function renderFlowStep(){
  updateFlowChrome();
  if(flowIndex >= flowQueue.length){
    setFlowTint('flow-tint-neutral');
    renderFlowDone();
    return;
  }
  const item = flowQueue[flowIndex];
  if(item.type==='fard'){
    setFlowTint('flow-tint-neutral');
    renderFardAsk(item);
  } else {
    setFlowTint('flow-tint-neutral');
    renderSimpleAsk(item);
  }
}

function renderFardAsk(item){
  const html = `
    <div class="flow-label">${ICONS.clipboard.replace('<svg ', '<svg class="lbl-ico" ')}নামাজের রিপোর্ট</div>
    <div class="flow-prayer-name">${item.label}</div>
    <div class="choice-grid">
      <button type="button" class="choice-btn pos rippleable" id="btnPrayed">
        <span class="ico">${ICONS.check}</span>
        নামাজ পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
      <button type="button" class="choice-btn neg rippleable" id="btnNotPrayed">
        <span class="ico">${ICONS.cross}</span>
        নামাজ পড়িনি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    on('btnPrayed', 'click', ()=>{
      SoundFX.tick();
      goForward({type:'ask', index:flowIndex}, ()=> renderCongrats(item));
    });
    on('btnNotPrayed', 'click', ()=>{
      setDayRecord(flowDateKey, item.id, 'missed');
      SoundFX.miss();
      goForward({type:'ask', index:flowIndex}, ()=> renderMissedResult(item));
    });
  });
}

function seedFor(item){
  // rotate through pools deterministically by date + slot, so it doesn't repeat every day
  const d = new Date(flowDateKey+'T00:00:00');
  return d.getDate() + item.id.length;
}

function renderCongrats(item){
  setFlowTint('flow-tint-green');
  const q = pickQuote(POOL_CONGRATS, seedFor(item));
  const html = `
    <div class="result-panel">
      <div class="result-badge-wrap">
        <div class="result-badge g">${ICONS.check}</div>
        ${sparkleBurstHTML('var(--green)')}
      </div>
      <div class="result-title">আলহামদুলিল্লাহ!</div>
      <div class="result-sub">${item.label} আদায় করেছেন — সুসংবাদ গ্রহণ করুন</div>
    </div>
    <div class="quote-card">
      <span class="quote-kind">${q.kind} • ${q.ref}</span>
      <div class="quote-text">${q.text}</div>
    </div>
    <div class="flow-label" style="margin-top:24px;">কীভাবে আদায় করেছেন?</div>
    <div class="choice-grid" style="margin-top:10px;">
      <button type="button" class="choice-btn pos rippleable" id="btnJamaat">
        <span class="ico">${ICONS.jamaat}</span>
        জামাতে পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
      <button type="button" class="choice-btn mid rippleable" id="btnAlone">
        <span class="ico">${ICONS.alone}</span>
        একাকি পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
      <button type="button" class="choice-btn warn rippleable" id="btnQaza">
        <span class="ico">${ICONS.qaza}</span>
        কাযা পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    SoundFX.success();
    on('btnJamaat', 'click', ()=>{ setDayRecord(flowDateKey,item.id,'jamaat'); goForward({type:'congrats', index:flowIndex}, ()=> renderSubResult(item,'jamaat')); });
    on('btnAlone', 'click', ()=>{ setDayRecord(flowDateKey,item.id,'alone'); goForward({type:'congrats', index:flowIndex}, ()=> renderSubResult(item,'alone')); });
    on('btnQaza', 'click', ()=>{ setDayRecord(flowDateKey,item.id,'qaza'); goForward({type:'congrats', index:flowIndex}, ()=> renderSubResult(item,'qaza')); });
  });
}

function renderSubResult(item, kind){
  let pool, tint, badgeClass, title, icon, sound, sparkle;
  if(kind==='jamaat'){ pool=POOL_JAMAAT; tint='flow-tint-green'; badgeClass='g'; title='জাযাকাল্লাহু খাইরান!'; icon=ICONS.jamaat; sound='jamaat'; sparkle=true; }
  else if(kind==='alone'){ pool=POOL_ALONE; tint='flow-tint-neutral'; badgeClass='a'; title='জাযাকাল্লাহু খাইরান'; icon=ICONS.alone; sound='success'; sparkle=false; }
  else { pool=POOL_QAZA; tint='flow-tint-amber'; badgeClass='a'; title='জাযাকাল্লাহু খাইরান'; icon=ICONS.qaza; sound='soft'; sparkle=false; }
  setFlowTint(tint);
  const q = pickQuote(pool, seedFor(item)+1);
  const subMsg = kind==='jamaat' ? 'জামাতে আদায়ের ফযীলত অর্জন করেছেন'
    : kind==='alone' ? 'পরবর্তীতে জামাতে শামিল হওয়ার চেষ্টা রাখুন'
    : 'সময়মতো আদায়ের প্রতি যত্নশীল হওয়ার চেষ্টা করুন';
  const html = `
    <div class="result-panel">
      <div class="result-badge-wrap">
        <div class="result-badge ${badgeClass}">${icon}</div>
        ${sparkle ? sparkleBurstHTML('var(--green)') : ''}
      </div>
      <div class="result-title">${title}</div>
      <div class="result-sub">${subMsg}</div>
    </div>
    <div class="quote-card">
      <span class="quote-kind">${q.kind} • ${q.ref}</span>
      <div class="quote-text">${q.text}</div>
    </div>
    <div class="flow-cta">
      <button type="button" class="btn-block rippleable" id="btnContinue">চালিয়ে যান</button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    SoundFX[sound]();
    on('btnContinue', 'click', ()=> goForward({type:'subResult', index:flowIndex, kind}, nextFlowStep));
  });
}

function renderMissedResult(item){
  setFlowTint('flow-tint-red');
  const q = pickQuote(POOL_MISSED, seedFor(item));
  const html = `
    <div class="result-panel shake">
      <div class="result-badge-wrap">
        <div class="result-badge r">${ICONS.cross}</div>
      </div>
      <div class="result-title">জাযাকাল্লাহু খাইরান</div>
      <div class="result-sub">ইনশাআল্লাহ পরবর্তী সালাত মিস করবেন না</div>
    </div>
    <div class="quote-card">
      <span class="quote-kind">${q.kind} • ${q.ref}</span>
      <div class="quote-text">${q.text}</div>
    </div>
    <div class="flow-cta">
      <button type="button" class="btn-block rippleable" id="btnContinue">চালিয়ে যান</button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    on('btnContinue', 'click', ()=> goForward({type:'missedResult', index:flowIndex}, nextFlowStep));
  });
}

function renderSimpleAsk(item){
  const isSunnah = item.type==='sunnah';
  const yesWord = isSunnah ? 'পড়েছি' : 'করেছি';
  const noWord = isSunnah ? 'পড়িনি' : 'করিনি';
  const labelIcon = isSunnah ? ICONS.moon.replace('<svg ', '<svg class="lbl-ico" ') : ICONS.sparkleStar.replace('<svg ', '<svg class="lbl-ico" ');
  const html = `
    <div class="flow-label">${labelIcon}${isSunnah ? 'সুন্নত' : 'নিজস্ব আমল'}</div>
    <div class="flow-prayer-name">${item.label}</div>
    <div class="simple-toggle">
      <button type="button" class="yes rippleable" id="btnYes"><span class="t-ico">${ICONS.check}</span>${yesWord}</button>
      <button type="button" class="no rippleable" id="btnNo"><span class="t-ico">${ICONS.cross}</span>${noWord}</button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    on('btnYes','click', ()=>{
      setDayRecord(flowDateKey, item.id, 'done');
      SoundFX.success();
      setFlowTint('flow-tint-green');
      setTimeout(()=> goForward({type:'ask', index:flowIndex}, nextFlowStep), 420);
    });
    on('btnNo','click', (e)=>{
      setDayRecord(flowDateKey, item.id, 'missed');
      SoundFX.miss();
      setFlowTint('flow-tint-red');
      const btn = document.getElementById('btnNo');
      if(btn){ btn.style.animation='shakeSm .4s ease'; }
      setTimeout(()=> goForward({type:'ask', index:flowIndex}, nextFlowStep), 420);
    });
  });
}

function nextFlowStep(){
  flowIndex++;
  renderFlowStep();
}

function renderFlowDone(){
  const d = new Date(flowDateKey+'T00:00:00');
  const rec = getDayRecord(flowDateKey);
  const slots = getDaySlots(d);
  let jamaat=0, alone=0, qaza=0, missed=0, sunnahDone=0;
  slots.forEach(s=>{
    const v = rec[s.id];
    if(s.type==='fard'){
      if(v==='jamaat') jamaat++;
      else if(v==='alone') alone++;
      else if(v==='qaza') qaza++;
      else if(v==='missed') missed++;
    } else if(v==='done'){ sunnahDone++; }
  });
  const html = `
    <div class="done-screen">
      <div class="big-badge">${ICONS.check}</div>
      <h2>আজকের আমল সম্পন্ন</h2>
      <p>আজকের রিপোর্ট সংরক্ষণ করা হয়েছে। আল্লাহ আপনার আমল কবুল করুন।</p>
      <div class="done-stats">
        <span class="done-pill">জামাত ${toBn(jamaat)}</span>
        <span class="done-pill">একাকি ${toBn(alone)}</span>
        <span class="done-pill">কাযা ${toBn(qaza)}</span>
        <span class="done-pill">ছুটেছে ${toBn(missed)}</span>
        <span class="done-pill">সুন্নত ${toBn(sunnahDone)}</span>
      </div>
      <div class="flow-cta" style="width:100%;">
        <button type="button" class="btn-block rippleable" id="btnSeeReport">মাসিক রিপোর্ট দেখুন</button>
        <button type="button" class="btn-block outline rippleable" id="btnBackHome" style="margin-top:10px;">হোমে ফিরুন</button>
      </div>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    SoundFX.complete();
    on('btnSeeReport', 'click', ()=>{ closeFlow({silent:true}); openSheet(); });
    on('btnBackHome', 'click', ()=> closeFlow());
  });
}

/* ================= SHEET / MONTHLY REPORT ================= */
let trendChart = null;
function openSheet(){
  sheetMonthCursor = new Date(today.getFullYear(), today.getMonth(), 1);
  document.getElementById('sheetOverlay').classList.add('show');
  renderSheet();
  armNavTrap();
}
function closeSheet(){
  if(navTrapArmed){
    intentionalNavClose = true;
    history.back();
  } else {
    hideSheetOverlayOnly();
  }
}
on('openSheetBtn', 'click', openSheet);
on('sheetCloseBtn', 'click', closeSheet);
on('prevMonthBtn', 'click', ()=>{
  sheetMonthCursor = new Date(sheetMonthCursor.getFullYear(), sheetMonthCursor.getMonth()-1, 1);
  renderSheet();
});
on('nextMonthBtn', 'click', ()=>{
  const nextC = new Date(sheetMonthCursor.getFullYear(), sheetMonthCursor.getMonth()+1, 1);
  if(nextC > new Date(today.getFullYear(), today.getMonth(), 1)) return;
  sheetMonthCursor = nextC;
  renderSheet();
});

function renderSheet(){
  document.getElementById('sheetMonthLabel').textContent = bnMonthLabel(sheetMonthCursor);
  const y = sheetMonthCursor.getFullYear(), m = sheetMonthCursor.getMonth();
  const cur = computeMonthStats(y,m);
  const prevD = new Date(y, m-1, 1);
  const prev = computeMonthStats(prevD.getFullYear(), prevD.getMonth());
  const delta = cur.pct - prev.pct;

  const body = document.getElementById('sheetBody');
  body.innerHTML = '';

  // summary grid
  const summary = document.createElement('div');
  summary.className='summary-grid';
  summary.innerHTML = `
    <div class="card"><div class="val">${toBn(cur.pct)}%</div><div class="lbl">এই মাস</div></div>
    <div class="card"><div class="val">${toBn(prev.pct)}%</div><div class="lbl">গত মাস</div></div>
    <div class="card"><div class="val" style="color:${delta>=0?'var(--green)':'var(--red)'}">${delta>=0?'▲':'▼'} ${toBn(Math.abs(delta))}%</div><div class="lbl">পরিবর্তন</div></div>
  `;
  body.appendChild(summary);

  // PDF report action
  const pdfCard = document.createElement('button');
  pdfCard.type = 'button';
  pdfCard.className = 'btn-block pdf-report-btn rippleable';
  pdfCard.id = 'pdfReportBtn';
  pdfCard.innerHTML = ICONS.pdf + ' <span>এই মাসের PDF রিপোর্ট ডাউনলোড করুন</span>';
  body.appendChild(pdfCard);
  pdfCard.addEventListener('click', ()=> openPdfReport(y, m));

  // trend chart card
  const trendCard = document.createElement('div');
  trendCard.className='card trend-card';
  trendCard.innerHTML = `<h3>ওয়াক্তভিত্তিক তুলনা</h3><p class="hint">এই মাস বনাম গত মাস (%)</p><canvas id="trendCanvas" height="180"></canvas>`;
  body.appendChild(trendCard);

  // delta list (increase/decrease per group)
  const deltaCard = document.createElement('div');
  deltaCard.className='card';
  let deltaRows = '';
  const labels = FARD_GROUPS.map(g=>({key:g.key,label:g.label})).concat([{key:'sunnah',label:'সুন্নত (সার্বিক)'}]);
  labels.forEach(g=>{
    const curV = g.key==='sunnah' ? cur.sunnahPct : cur.groupPct[g.key];
    const prevV = g.key==='sunnah' ? prev.sunnahPct : prev.groupPct[g.key];
    const d = curV - prevV;
    deltaRows += `<div class="delta-row"><span class="name">${g.label}</span><span class="amt ${d>=0?'up':'down'}">${d>=0?'▲':'▼'} ${toBn(Math.abs(d))}%</span></div>`;
  });
  deltaCard.innerHTML = `<h3>কোন আমল বেড়েছে, কোনটি কমেছে</h3>${'<div class="delta-list">'+deltaRows+'</div>'}`;
  body.appendChild(deltaCard);

  // table
  const tableCard = document.createElement('div');
  const dim = daysInMonth(y,m);
  const sampleFriday = new Date(y,m,1).getDay()===5;
  let headCols = '';
  SLOT_DEFS.forEach(def=>{
    headCols += `<th>${slotShort(def, sampleFriday)}</th>`;
  });
  STATE.customAmals.forEach(ca=> headCols += `<th>${escapeHtml(ca.name)}</th>`);

  let rowsHtml = '';
  for(let day=1; day<=dim; day++){
    const d = new Date(y,m,day);
    const key = dateKey(d);
    const isFriday = d.getDay()===5;
    const rec = getDayRecord(key);
    const slots = SLOT_DEFS; // fixed columns
    let cells = '';
    slots.forEach(def=>{
      const val = rec[def.id];
      cells += `<td>${cellButton(def.id, def.type, val, key, slotLabel(def,isFriday))}</td>`;
    });
    STATE.customAmals.forEach(ca=>{
      const cid = 'custom_'+ca.id;
      const val = rec[cid];
      cells += `<td>${cellButton(cid, 'custom', val, key, ca.name)}</td>`;
    });
    rowsHtml += `<tr class="${isFriday?'friday':''}"><td class="date-cell">${toBn(day)} তারিখ<span class="wd">${WEEKDAYS_BN[d.getDay()]}</span></td>${cells}</tr>`;
  }

  tableCard.innerHTML = `
    <h3 style="margin-top:18px;">দৈনিক বিস্তারিত হিসাব</h3>
    <p class="hint">প্রতিটি ঘরে ক্লিক করে এডিট করা যাবে</p>
    <div class="table-wrap">
      <table class="amol-table">
        <thead><tr><th style="text-align:right;">তারিখ</th>${headCols}</tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
    <div class="legend">
      <span><i style="background:var(--green)"></i> জামাত/সম্পন্ন</span>
      <span><i style="background:var(--blue)"></i> একাকি</span>
      <span><i style="background:var(--amber)"></i> কাযা</span>
      <span><i style="background:var(--red)"></i> ছুটেছে</span>
      <span><i style="background:var(--text-faint)"></i> এন্ট্রি নেই</span>
    </div>
  `;
  body.appendChild(tableCard);

  // bind cell buttons
  body.querySelectorAll('.cell-btn').forEach(btn=>{
    btn.addEventListener('click', ()=> openCellPopover(btn.dataset.key, btn.dataset.id, btn.dataset.type, btn.dataset.label));
  });

  drawTrendChart(cur, prev);
}

function cellButton(id, type, val, key, label){
  let cls='st-none', text='–';
  if(type==='fard'){
    if(val==='jamaat'){cls='st-jamaat'; text='জ';}
    else if(val==='alone'){cls='st-alone'; text='এ';}
    else if(val==='qaza'){cls='st-qaza'; text='ক';}
    else if(val==='missed'){cls='st-missed'; text='✕';}
  } else {
    if(val==='done'){cls='st-done'; text='✓';}
    else if(val==='missed'){cls='st-missed'; text='✕';}
  }
  return `<button class="cell-btn ${cls}" data-key="${key}" data-id="${id}" data-type="${type}" data-label="${escapeHtml(label)}">${text}</button>`;
}

function drawTrendChart(cur, prev){
  const canvas = document.getElementById('trendCanvas');
  if(!canvas || !window.Chart) return;
  const labels = FARD_GROUPS.map(g=>g.label).concat(['সুন্নত']);
  const curData = FARD_GROUPS.map(g=>cur.groupPct[g.key]).concat([cur.sunnahPct]);
  const prevData = FARD_GROUPS.map(g=>prev.groupPct[g.key]).concat([prev.sunnahPct]);
  const styles = getComputedStyle(document.documentElement);
  const navy = styles.getPropertyValue('--navy').trim();
  const blue = styles.getPropertyValue('--blue').trim();
  const textMuted = styles.getPropertyValue('--text-muted').trim();
  const borderSoft = styles.getPropertyValue('--border-soft').trim();
  if(trendChart){ trendChart.destroy(); }
  trendChart = new Chart(canvas.getContext('2d'), {
    type:'bar',
    data:{
      labels,
      datasets:[
        {label:'এই মাস', data:curData, backgroundColor:navy, borderRadius:6, maxBarThickness:16},
        {label:'গত মাস', data:prevData, backgroundColor:blue, borderRadius:6, maxBarThickness:16, borderColor:'transparent'}
      ]
    },
    options:{
      responsive:true,
      plugins:{ legend:{position:'bottom', labels:{color:textMuted, font:{family:"'GunjoronFont'"}, boxWidth:10, padding:14}} },
      scales:{
        y:{ beginAtZero:true, max:100, ticks:{color:textMuted, font:{family:"'GunjoronFont'"}}, grid:{color:borderSoft} },
        x:{ ticks:{color:textMuted, font:{family:"'GunjoronFont'"}}, grid:{display:false} }
      }
    }
  });
}

/* ---------- PDF report (native browser print → Save as PDF, keeps Bengali fonts intact) ---------- */
function openPdfReport(y, m){
  const cur = computeMonthStats(y, m);
  const prevD = new Date(y, m-1, 1);
  const prev = computeMonthStats(prevD.getFullYear(), prevD.getMonth());
  const delta = cur.pct - prev.pct;
  const monthDate = new Date(y, m, 1);

  const groups = FARD_GROUPS.map(g=>({label:g.label, cur:cur.groupPct[g.key], prev:prev.groupPct[g.key]}))
    .concat([{label:'সুন্নত (সার্বিক)', cur:cur.sunnahPct, prev:prev.sunnahPct}]);

  const barsHtml = groups.map(g=>{
    const d = g.cur - g.prev;
    return `
      <div class="pr-cat">
        <div class="pr-cat-title"><span>${g.label}</span><span class="d ${d>=0?'up':'down'}">${d>=0?'▲':'▼'} ${toBn(Math.abs(d))}%</span></div>
        <div class="pr-bar"><div class="pr-bar-fill cur" style="width:${Math.max(g.cur,4)}%">${toBn(g.cur)}% (এই মাস)</div></div>
        <div class="pr-bar"><div class="pr-bar-fill prev" style="width:${Math.max(g.prev,4)}%">${toBn(g.prev)}% (গত মাস)</div></div>
      </div>`;
  }).join('');

  const dim = daysInMonth(y, m);
  const sampleFriday = new Date(y,m,1).getDay()===5;
  let headCols = SLOT_DEFS.map(def=> `<th>${slotShort(def, sampleFriday)}</th>`).join('');
  STATE.customAmals.forEach(ca=> headCols += `<th>${escapeHtml(ca.name)}</th>`);

  let rowsHtml = '';
  const statusText = {jamaat:'জ', alone:'এ', qaza:'ক', missed:'✕', done:'✓'};
  for(let day=1; day<=dim; day++){
    const d = new Date(y,m,day);
    const key = dateKey(d);
    const rec = getDayRecord(key);
    let cells = SLOT_DEFS.map(def=> `<td>${statusText[rec[def.id]] || '–'}</td>`).join('');
    STATE.customAmals.forEach(ca=>{ cells += `<td>${statusText[rec['custom_'+ca.id]] || '–'}</td>`; });
    rowsHtml += `<tr><td class="dcell">${toBn(day)} ${WEEKDAYS_BN[d.getDay()]}</td>${cells}</tr>`;
  }

  const html = `
    <div class="pr-header">
      <h1>আমলের মাসিক রিপোর্ট — ${bnMonthLabel(monthDate)}</h1>
      <div class="pr-sub">তৈরি হয়েছে ${bnFullDate(new Date())}</div>
    </div>
    <div class="pr-summary">
      <div class="box"><div class="v">${toBn(cur.pct)}%</div><div class="l">এই মাস</div></div>
      <div class="box"><div class="v">${toBn(prev.pct)}%</div><div class="l">গত মাস</div></div>
      <div class="box"><div class="v">${delta>=0?'▲':'▼'} ${toBn(Math.abs(delta))}%</div><div class="l">পরিবর্তন</div></div>
    </div>
    <div class="pr-section-title">ওয়াক্তভিত্তিক হিসাব (এই মাস বনাম গত মাস)</div>
    ${barsHtml}
    <div class="pr-section-title">দৈনিক বিস্তারিত হিসাব</div>
    <div class="pr-legend">জ = জামাতে, এ = একাকি, ক = কাযা, ✓ = সম্পন্ন, ✕ = হয়নি/ছুটেছে, – = এন্ট্রি নেই</div>
    <table class="pr-table">
      <thead><tr><th>তারিখ</th>${headCols}</tr></thead>
      <tbody>${rowsHtml}</tbody>
    </table>
    <div class="pr-footer">আমলের রিপোর্ট অ্যাপ থেকে তৈরি</div>
  `;
  const area = document.getElementById('printArea');
  area.innerHTML = html;
  setTimeout(()=>{ try{ window.print(); }catch(e){} }, 80);
}

/* ---------- cell edit popover ---------- */
function openCellPopover(key, id, type, label){
  const mask = document.getElementById('popMask');
  document.getElementById('popTitle').textContent = label;
  document.getElementById('popSub').textContent = key.split('-').reverse().join('/') ;
  const grid = document.getElementById('popGrid');
  const rec = getDayRecord(key);
  const cur = rec[id];
  let options;
  if(type==='fard'){
    options = [
      {v:'jamaat', c:'var(--green)', t:'জামাতে পড়েছি'},
      {v:'alone', c:'var(--blue)', t:'একাকি পড়েছি'},
      {v:'qaza', c:'var(--amber)', t:'কাযা পড়েছি'},
      {v:'missed', c:'var(--red)', t:'পড়িনি'},
    ];
  } else {
    options = [
      {v:'done', c:'var(--green)', t:'করেছি'},
      {v:'missed', c:'var(--red)', t:'করিনি'},
    ];
  }
  grid.innerHTML = options.map(o=>`<button class="pop-opt ${cur===o.v?'active':''}" data-v="${o.v}"><span class="pop-dot" style="background:${o.c}"></span>${o.t}</button>`).join('')
    + `<button class="pop-opt" data-v="__clear"><span class="pop-dot" style="background:var(--text-faint)"></span>এন্ট্রি মুছুন</button>`;
  grid.querySelectorAll('.pop-opt').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const v = btn.dataset.v;
      if(v==='__clear'){
        if(STATE.days[key]) delete STATE.days[key][id];
        persist();
      } else {
        setDayRecord(key, id, v);
      }
      mask.classList.remove('show');
      renderSheet();
      renderHome();
    });
  });
  mask.classList.add('show');
}
on('popMask', 'click', (e)=>{
  if(e.target.id==='popMask') e.currentTarget.classList.remove('show');
});

/* ---------- add custom amal modal ---------- */
const amalMask = document.getElementById('amalModalMask');
on('addAmalBtn', 'click', ()=>{
  document.getElementById('amalNameInput').value='';
  amalMask.classList.add('show');
});
on('amalCancelBtn', 'click', ()=> amalMask.classList.remove('show'));
amalMask.addEventListener('click', (e)=>{ if(e.target===amalMask) amalMask.classList.remove('show'); });
on('amalSaveBtn', 'click', ()=>{
  const name = document.getElementById('amalNameInput').value.trim();
  if(!name) return;
  const when = document.getElementById('amalTimeSelect').value;
  STATE.customAmals.push({ id: 'c'+Date.now(), name, when });
  persist();
  amalMask.classList.remove('show');
  renderHome();
});

/* ---------- confirm delete custom amal ---------- */
const confirmDeleteMask = document.getElementById('confirmDeleteMask');
on('confirmDeleteCancelBtn', 'click', ()=>{
  pendingDeleteAmalId = null;
  confirmDeleteMask.classList.remove('show');
});
confirmDeleteMask.addEventListener('click', (e)=>{ if(e.target===confirmDeleteMask){ pendingDeleteAmalId = null; confirmDeleteMask.classList.remove('show'); } });
on('confirmDeleteOkBtn', 'click', ()=>{
  if(pendingDeleteAmalId){
    STATE.customAmals = STATE.customAmals.filter(a=> a.id !== pendingDeleteAmalId);
    pendingDeleteAmalId = null;
    persist();
    renderHome();
  }
  confirmDeleteMask.classList.remove('show');
});

/* ---------- backup export / import ---------- */
let downloadsNs = null;
async function getDownloadsNs(){
  if(downloadsNs) return downloadsNs;
  try{
    if(window.claude && window.claude.use){
      downloadsNs = await withTimeout(window.claude.use('downloads'), 3000);
    }
  }catch(e){ downloadsNs = null; }
  return downloadsNs;
}
on('exportBackupBtn', 'click', async ()=>{
  const btn = document.getElementById('exportBackupBtn');
  const original = btn.innerHTML;
  try{
    const snapshot = JSON.stringify(STATE, null, 2);
    const fname = 'amoler-report-backup-'+dateKey(new Date())+'.json';
    const dl = await getDownloadsNs();
    if(dl){
      await dl.save({ filename: fname, data: snapshot });
    } else {
      // Fallback: a plain in-page download (works outside the artifact sandbox too).
      const blob = new Blob([snapshot], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = fname;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(()=> URL.revokeObjectURL(url), 2000);
    }
    btn.innerHTML = '✓ সংরক্ষিত হয়েছে';
    setTimeout(()=> btn.innerHTML = original, 1800);
  }catch(e){
    if(e && e.code !== 'declined'){
      btn.innerHTML = 'ব্যর্থ হয়েছে';
      setTimeout(()=> btn.innerHTML = original, 1800);
    } else {
      btn.innerHTML = original;
    }
  }
});
on('importBackupBtn', 'click', ()=>{
  document.getElementById('importFileInput').click();
});
on('importFileInput', 'change', (e)=>{
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = ()=>{
    try{
      const parsed = JSON.parse(reader.result);
      if(parsed && typeof parsed === 'object'){
        STATE = {
          theme: parsed.theme || STATE.theme,
          soundOn: typeof parsed.soundOn === 'boolean' ? parsed.soundOn : STATE.soundOn,
          customAmals: Array.isArray(parsed.customAmals) ? parsed.customAmals : STATE.customAmals,
          days: parsed.days && typeof parsed.days === 'object' ? parsed.days : STATE.days
        };
        applyTheme();
        applySound();
        persist();
        renderHome();
      }
    }catch(err){ console.error('[amol] backup import failed', err); }
    e.target.value = '';
  };
  reader.readAsText(file);
});

/* ---------- init ---------- */
(function initSync(){
  // Render synchronously first with whatever local data exists so the
  // page is fully interactive before any async storage call resolves.
  try{ loadLocalFallback(); }catch(e){}
  try{ applyTheme(); }catch(e){}
  try{ applySound(); }catch(e){}
  try{ attachRipple(document); }catch(e){}
  try{ renderHome(); }catch(e){ console.error('[amol] initial render failed', e); }
})();

(async function initAsync(){
  try{
    await initStorage();
    applyTheme();
    applySound();
    renderHome();
  }catch(e){ console.error('[amol] storage init failed', e); }
})();
