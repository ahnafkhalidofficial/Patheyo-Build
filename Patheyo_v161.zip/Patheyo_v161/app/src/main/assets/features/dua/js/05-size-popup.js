/* দোয়া — লেখার সাইজ পপআপ (জুম বোতাম চাপলে খোলে)।
   কোন লেখা কতটুকু বড় হবে ইউজার নিজে ঠিক করেন (শিরোনাম / আরবি / উচ্চারণ / অর্থ — প্রতিটার আলাদা স্লাইডার)।
   উপরে চারটা রেডিমেড মাপ, নিচে সাথে সাথে বদলানো প্রিভিউ। "প্রয়োগ করুন" চাপলে সংরক্ষিত হয়ে পুরো পেজে কাজ করে। */
(function () {
  'use strict';
  var ROWS = [['t', 'শিরোনাম'], ['ar', 'আরবি লেখা'], ['tr', 'উচ্চারণ'], ['bn', 'অর্থ']];
  var PRESETS = [['ছোট', 0.88], ['মাঝারি', 1], ['বড়', 1.2], ['অনেক বড়', 1.45]];
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }

  var veil, sheet, prev, tmp, opened = false, built = false;
  var rowEls = {};

  function build() {
    built = true;
    veil = document.createElement('div'); veil.className = 'veil'; veil.id = 'szveil';
    sheet = document.createElement('div'); sheet.className = 'sheet'; sheet.id = 'szsheet';
    sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'লেখার সাইজ');
    var h = '<div class="grab"></div>' +
      '<div class="szhd"><div class="szhd-t">লেখার সাইজ</div><button type="button" class="szx" aria-label="বন্ধ করুন"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>' +
      '<div class="szprev" id="szprev" aria-label="প্রিভিউ"></div>' +
      '<p class="szsub">কোনটা কতটুকু বড় চান নিজে ঠিক করুন — প্রিভিউতে সাথে সাথে দেখা যাবে।</p>' +
      '<div class="szpre" id="szpre">' + PRESETS.map(function (p, i) { return '<button type="button" data-p="' + i + '">' + p[0] + '</button>'; }).join('') + '</div>';
    ROWS.forEach(function (r) {
      var lim = DuaFS.LIM[r[0]];
      h += '<div class="szrow" data-k="' + r[0] + '"><div class="szl"><b>' + r[1] + '</b><span></span></div>' +
        '<div class="szc"><button type="button" data-d="-1" aria-label="ছোট করুন">−</button>' +
        '<input type="range" min="' + lim[0] + '" max="' + lim[1] + '" step="1" aria-label="' + r[1] + '">' +
        '<button type="button" data-d="1" aria-label="বড় করুন">+</button></div></div>';
    });
    h += '<div class="szbtn"><button type="button" id="szreset">ডিফল্ট</button><button type="button" class="szok" id="szok">প্রয়োগ করুন</button></div>';
    sheet.innerHTML = h;
    document.body.appendChild(veil); document.body.appendChild(sheet);

    prev = sheet.querySelector('#szprev');
    var sample = null; DUA_ITEMS.forEach(function (d) { if (d.id === 'a3') sample = d; });
    prev.innerHTML = window.DuaItemHtml(sample || DUA_ITEMS[0], false);

    ROWS.forEach(function (r) {
      var row = sheet.querySelector('.szrow[data-k="' + r[0] + '"]');
      rowEls[r[0]] = { val: row.querySelector('.szl span'), range: row.querySelector('input') };
      row.querySelector('input').addEventListener('input', function (e) { set(r[0], +e.target.value); });
      Array.prototype.forEach.call(row.querySelectorAll('.szc button'), function (b) {
        b.addEventListener('click', function () { set(r[0], tmp[r[0]] + (+b.getAttribute('data-d'))); });
      });
    });
    Array.prototype.forEach.call(sheet.querySelectorAll('#szpre button'), function (b) {
      b.addEventListener('click', function () {
        var f = PRESETS[+b.getAttribute('data-p')][1];
        ROWS.forEach(function (r) { tmp[r[0]] = DuaFS.clamp(r[0], DuaFS.DEF[r[0]] * f); });
        paint();
      });
    });
    sheet.querySelector('#szreset').addEventListener('click', function () { tmp = JSON.parse(JSON.stringify(DuaFS.DEF)); paint(); });
    sheet.querySelector('#szok').addEventListener('click', apply);
    sheet.querySelector('.szx').addEventListener('click', requestClose);
    veil.addEventListener('click', requestClose);
  }

  function set(k, v) { tmp[k] = DuaFS.clamp(k, v); paint(); }

  /* স্লাইডার, সংখ্যা, মাপের বোতাম আর প্রিভিউ — সব একসাথে মেলায় */
  function paint() {
    ROWS.forEach(function (r) {
      var k = r[0], lim = DuaFS.LIM[k], el = rowEls[k];
      el.range.value = tmp[k];
      el.range.style.setProperty('--p', ((tmp[k] - lim[0]) / (lim[1] - lim[0]) * 100) + '%');
      el.val.textContent = bn(tmp[k]) + (tmp[k] === DuaFS.DEF[k] ? ' (ডিফল্ট)' : '');
    });
    Array.prototype.forEach.call(sheet.querySelectorAll('#szpre button'), function (b) {
      var f = PRESETS[+b.getAttribute('data-p')][1], same = ROWS.every(function (r) { return tmp[r[0]] === DuaFS.clamp(r[0], DuaFS.DEF[r[0]] * f); });
      b.classList.toggle('on', same);
    });
    DuaFS.paint(prev, tmp);
  }

  function open() {
    if (!built) build();
    if (opened) return;
    opened = true;
    tmp = DuaFS.get();
    try { history.pushState({ dsz: 1 }, ''); } catch (e) {}
    paint();
    document.documentElement.classList.add('hs-lock', 'dsz-open');
    veil.classList.add('on'); sheet.classList.add('on');
    sheet.scrollTop = 0;
  }
  function hide() {
    if (!opened) return;
    opened = false;
    veil.classList.remove('on'); sheet.classList.remove('on');
    document.documentElement.classList.remove('hs-lock', 'dsz-open');
  }
  function requestClose() {
    if (!opened) return;
    if (history.state && history.state.dsz) history.back(); else hide();
  }
  function apply() {
    DuaFS.save(tmp); DuaFS.paint(document.documentElement, tmp);
    if (window.DuaToast) window.DuaToast('লেখার সাইজ সংরক্ষিত হয়েছে');
    requestClose();
  }

  window.addEventListener('popstate', function () { if (opened) hide(); });   /* ফোনের Back চাপলে পপআপ বন্ধ (সাইজ বদলায় না) */
  window.DuaSize = { open: open, close: requestClose };
})();
