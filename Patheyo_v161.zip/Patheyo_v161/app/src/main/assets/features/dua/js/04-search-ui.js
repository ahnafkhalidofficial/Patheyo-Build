/* দোয়া — ভাসমান সার্চ আইকন + পূর্ণ-পর্দা লাইভ সার্চ।
   কুরআন ও হাদিসের সার্চের (fast-search-ui) একই কাঠামো, একই আচরণ:
   স্ক্রোল করে নিচে নামলে ডান-নিচে আইকন আসে → চাপলে সার্চ পেজ → লিখতে লিখতেই ফল → ফোনের Back আগে সার্চ বন্ধ করে। */
(function () {
  'use strict';

  var SEARCH_SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>';
  var BACK_SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"></path></svg>';
  var X_SVG = '<svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"></path></svg>';

  try { history.scrollRestoration = 'manual'; } catch (e) {}   /* Back চাপলে পেজ আগের জায়গায় ঝাঁকুনি দিয়ে না সরে */
  var PAGE = 25;
  var fab, ov, input, clearBtn, statusEl, listEl, chipsEl, hintEl, scrollEl;
  var opened = false, last = null, shown = 0, raf = 0, savedQuery = '';
  var pendingNav = null, navTimer = 0, fabRaf = 0;
  var BN = '০১২৩৪৫৬৭৮৯';
  var catName = {}; DUA_CATS.forEach(function (c) { catName[c.id] = c.n; });

  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function build() {
    fab = document.createElement('button');
    fab.id = 'hs-fab'; fab.type = 'button'; fab.className = 'hs-fab hs-off';
    fab.setAttribute('aria-label', 'দোয়ার ভিতরে খুঁজুন');
    fab.innerHTML = SEARCH_SVG;
    document.body.appendChild(fab);

    ov = document.createElement('div');
    ov.id = 'hs-overlay'; ov.className = 'hs-overlay hidden'; ov.setAttribute('role', 'dialog');
    ov.innerHTML =
      '<div class="hs-bar">' +
        '<button type="button" class="hs-back" aria-label="ফিরে যান">' + BACK_SVG + '</button>' +
        '<div class="hs-field">' + SEARCH_SVG.replace('class="icon"', 'class="icon icon-sm hs-fi"') +
          '<input id="hs-input" type="search" inputmode="search" enterkeyhint="search" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="দোয়ার নাম, অর্থ বা আরবি শব্দ লিখুন">' +
          '<button type="button" class="hs-clear" aria-label="মুছুন">' + X_SVG + '</button>' +
        '</div>' +
      '</div>' +
      '<div class="hs-scroll" id="hs-scroll">' +
        '<div class="hs-status" id="hs-status"></div>' +
        '<div class="hs-chips hidden" id="hs-chips"></div>' +
        '<div class="hs-list" id="hs-list"></div>' +
        '<div class="hs-hint" id="hs-hint"></div>' +
      '</div>';
    document.body.appendChild(ov);

    input = ov.querySelector('#hs-input'); clearBtn = ov.querySelector('.hs-clear');
    statusEl = ov.querySelector('#hs-status'); listEl = ov.querySelector('#hs-list');
    chipsEl = ov.querySelector('#hs-chips'); hintEl = ov.querySelector('#hs-hint'); scrollEl = ov.querySelector('#hs-scroll');

    fab.addEventListener('click', open);
    ov.querySelector('.hs-back').addEventListener('click', requestClose);
    clearBtn.addEventListener('click', function () { input.value = ''; run(); input.focus(); });
    input.addEventListener('input', schedule);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } });
    listEl.addEventListener('click', onListClick);
    chipsEl.addEventListener('click', onListClick);
    scrollEl.addEventListener('scroll', onScroll, { passive: true });
    scrollEl.addEventListener('touchstart', function () { if (document.activeElement === input) input.blur(); }, { passive: true });
  }

  /* ভাসমান আইকন: তালিকায় একটু নিচে নামলে দেখা যায় (কুরআন/হাদিসের মতোই) */
  function syncFab() {
    if (!fab) return;
    var show = !opened && (window.pageYOffset || document.documentElement.scrollTop || 0) > 220;
    fab.classList.toggle('hs-off', !show);
  }
  function syncSoon() { if (fabRaf) return; fabRaf = requestAnimationFrame(function () { fabRaf = 0; syncFab(); }); }

  function open() {
    if (opened) return;
    opened = true;
    try { history.pushState({ dsearch: 1 }, ''); } catch (e) {}
    ov.classList.remove('hidden');
    document.documentElement.classList.add('hs-lock');
    syncFab();
    input.value = savedQuery;
    run();
    setTimeout(function () { try { input.focus(); input.select(); } catch (e) {} }, 30);
  }
  function requestClose() {
    if (!opened) return;
    if (history.state && history.state.dsearch) history.back(); else hide();
  }
  function hide() {
    if (!opened) return;
    savedQuery = input.value;
    opened = false;
    ov.classList.add('hidden');
    document.documentElement.classList.remove('hs-lock');
    try { input.blur(); } catch (e) {}
    syncFab();
  }

  /* ফোনের Back: আগে সার্চ পেজ বন্ধ হয় */
  window.addEventListener('popstate', function () {
    if (pendingNav) { var fn = pendingNav; pendingNav = null; clearTimeout(navTimer); hide(); setTimeout(fn, 60); return; }   /* ব্রাউজারের স্ক্রোল-পুনরুদ্ধারের পরে যাতে আমাদের স্ক্রোল মুছে না যায় */
    if (opened) hide();
    syncSoon();
  });
  function go(fn) {
    if (history.state && history.state.dsearch) {
      pendingNav = fn;
      navTimer = setTimeout(function () { if (pendingNav) { var f = pendingNav; pendingNav = null; hide(); f(); } }, 400);
      history.back();
    } else { hide(); fn(); }
  }

  function onListClick(e) {
    var t = e.target.closest ? e.target.closest('[data-id],[data-cat]') : null;
    if (!t) return;
    if (t.hasAttribute('data-id')) { var id = t.getAttribute('data-id'); go(function () { window.DuaApp.reveal(id); }); }
    else { var c = t.getAttribute('data-cat'); go(function () { window.DuaApp.reveal(null, c); }); }
  }

  function schedule() {
    clearBtn.classList.toggle('show', !!input.value);
    if (raf) return;
    raf = requestAnimationFrame(function () { raf = 0; run(); });
  }

  function run() {
    clearBtn.classList.toggle('show', !!input.value);
    var res = DuaEngine.search(input.value);
    last = res; shown = 0;
    chipsEl.innerHTML = ''; chipsEl.classList.add('hidden');
    listEl.innerHTML = ''; hintEl.innerHTML = '';
    scrollEl.scrollTop = 0;

    if (res.mode === 'empty') { statusEl.innerHTML = ''; hintEl.innerHTML = hintHtml(); return; }

    var cats = DuaEngine.catMatches(res.terms, !!res.relaxed);
    if (cats.length) {
      var h = '<div class="hs-chips-t">ক্যাটাগরি</div>';
      cats.forEach(function (c) { h += '<button type="button" class="hs-chip" data-cat="' + c.id + '">' + esc(c.n) + '</button>'; });
      chipsEl.innerHTML = h; chipsEl.classList.remove('hidden');
    }

    var s = '';
    if (res.items.length) {
      s = '<b>' + bn(res.total) + '</b> টি দোয়া পাওয়া গেছে';
      if (res.relaxed) s += ' · <span class="hs-soft">কাছাকাছি মিল</span>';
      s += ' <span class="hs-ms">' + bn(Math.max(1, Math.round(res.ms))) + ' মি.সে.</span>';
    } else s = 'কিছু পাওয়া যায়নি';
    statusEl.innerHTML = s;

    if (!res.items.length) {
      hintEl.innerHTML = '<div class="hs-empty"><div class="hs-empty-t">কোনো দোয়া মেলেনি</div>' +
        '<div class="hs-empty-s">অন্য শব্দ দিয়ে বা শব্দের ছোট অংশ লিখে দেখুন।<br>আরবি শব্দ দিয়েও খুঁজতে পারেন।</div></div>';
      return;
    }
    renderMore();
  }

  function hintHtml() {
    return '<div class="hs-empty"><div class="hs-empty-ic">' + SEARCH_SVG + '</div>' +
      '<div class="hs-empty-t">দোয়ার ভিতরে খুঁজুন</div>' +
      '<div class="hs-empty-s">দোয়ার নাম, অর্থের যেকোনো শব্দ, উচ্চারণ বা আরবি শব্দ লিখুন — লেখার সাথে সাথেই ফল আসবে।</div>' +
      '<div class="hs-ex"><span>ঘুম</span><span>সফর</span><span>ক্ষমা</span></div></div>';
  }

  function onScroll() {
    if (last && shown < last.items.length && scrollEl.scrollHeight - scrollEl.scrollTop - scrollEl.clientHeight < 700) renderMore();
  }

  function mark(text, ranges) {
    var out = '', pos = 0;
    for (var i = 0; i < ranges.length; i++) {
      var a = ranges[i][0], b = ranges[i][1];
      if (a < pos) continue;
      out += esc(text.slice(pos, a)) + '<mark class="hs-mark">' + esc(text.slice(a, b)) + '</mark>';
      pos = b;
    }
    return out + esc(text.slice(pos));
  }
  function snippet(text, ranges, max) {
    if (!text) return '';
    if (!ranges.length || text.length <= max) {
      var t = text.length > max ? text.slice(0, max) + '…' : text;
      return mark(t, ranges.filter(function (r) { return r[1] <= t.length; }));
    }
    var first = ranges[0][0], from = Math.max(0, first - Math.floor(max * 0.35));
    if (from > 0) { var sp = text.indexOf(' ', from); if (sp > -1 && sp < first) from = sp + 1; }
    var to = Math.min(text.length, from + max), piece = text.slice(from, to), rr = [];
    ranges.forEach(function (r) { if (r[0] >= from && r[1] <= to) rr.push([r[0] - from, r[1] - from]); });
    return (from > 0 ? '…' : '') + mark(piece, rr) + (to < text.length ? '…' : '');
  }

  function cardHtml(it, res) {
    var d = it.d, rel = !!res.relaxed, body, cls = '', rg;
    if (res.mode === 'ar') {
      rg = DuaEngine.spans(d.ar, res.terms, rel); body = snippet(d.ar, rg, 150); cls = ' hs-ar';
    } else {
      /* যেখানে মিল পাওয়া গেছে সেই লেখাটাই দেখাই: অর্থ → উচ্চারণ → (শুধু নামে মিললে) অর্থের শুরু */
      var rb = DuaEngine.spans(d.bn, res.terms, rel), rt = DuaEngine.spans(d.tr, res.terms, rel);
      if (rb.length) body = snippet(d.bn, rb, 210);
      else if (rt.length) body = snippet(d.tr, rt, 210);
      else body = snippet(d.bn, [], 210);
    }
    var title = mark(d.t, DuaEngine.spans(d.t, res.terms, rel));
    return '<button type="button" class="hs-card" data-id="' + esc(d.id) + '">' +
      '<div class="hs-ctop"><span class="hs-num">' + esc(catName[d.cat]) + '</span>' +
      '<span class="hs-ch">' + title + '</span></div>' +
      '<div class="hs-body' + cls + '">' + body + '</div></button>';
  }

  function renderMore() {
    if (!last) return;
    var end = Math.min(last.items.length, shown + PAGE), html = [];
    for (var i = shown; i < end; i++) html.push(cardHtml(last.items[i], last));
    shown = end;
    listEl.insertAdjacentHTML('beforeend', html.join(''));
    hintEl.innerHTML = '';
  }

  function init() {
    build();
    window.addEventListener('scroll', syncSoon, { passive: true });
    window.addEventListener('resize', syncSoon);
    syncFab();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
