/* দোয়া — মূল লজিক। ডেটা: 01-data.js (DUA_CATS, DUA_ITEMS)। আইকন: 01-icons.js। সার্চ: 02-engine.js। */
function ld(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
function sv(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
function $(id) { return document.getElementById(id); }

/* থিম: শেল (হোম) এই দুটো নামে থিম মেলায় — theme ভ্যারিয়েবল ও applyTheme() */
var theme = ld('dua_theme', (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light');
if (theme !== 'light' && theme !== 'dark' && theme !== 'sepia') theme = 'light';
function applyTheme() {
  document.documentElement.setAttribute('data-theme', theme);
  $('eye').classList.toggle('active', theme === 'sepia');       /* কুরআন/হাদিসের মতো: আই-কেয়ার চালু থাকলে 👁 জ্বলে */
  $('theme').classList.toggle('active', theme !== 'sepia');     /* আর লাইট/ডার্ক বোতাম জ্বলে বাকি দুই মোডে */
}
$('theme').onclick = function () { theme = theme === 'light' ? 'dark' : 'light'; sv('dua_theme', theme); applyTheme(); };   /* সেপিয়া → লাইট → ডার্ক → লাইট */
$('eye').onclick = function () { theme = 'sepia'; sv('dua_theme', theme); applyTheme(); };
applyTheme();

/* লেখার সাইজ (px): শিরোনাম / আরবি / উচ্চারণ / অর্থ — প্রতিটা আলাদা। পপআপ (05-size-popup.js) এটা বদলায়। */
var DuaFS = (function () {
  var DEF = { t: 17, ar: 28, tr: 15, bn: 15 };
  var LIM = { t: [14, 28], ar: [20, 52], tr: [12, 28], bn: [12, 28] };
  var KEY = 'pt_dua_fs';
  function clamp(k, v) { v = Math.round(+v); if (isNaN(v)) v = DEF[k]; return Math.min(LIM[k][1], Math.max(LIM[k][0], v)); }
  function get() {
    var s = ld(KEY, null), o = {};
    if (!s) {                                              /* আগের সংস্করণের তিন-ধাপের সাইজ থাকলে সেটা থেকে নিই */
      var old = ld('pt_dua_size', null);
      s = old === 0 ? { ar: 24 } : old === 2 ? { ar: 34 } : {};
    }
    for (var k in DEF) o[k] = clamp(k, s[k] == null ? DEF[k] : s[k]);
    return o;
  }
  function paint(el, v) {
    el.style.setProperty('--fs-t', v.t + 'px'); el.style.setProperty('--fs-ar', v.ar + 'px');
    el.style.setProperty('--fs-tr', v.tr + 'px'); el.style.setProperty('--fs-bn', v.bn + 'px');
  }
  function save(v) { sv(KEY, v); }
  return { DEF: DEF, LIM: LIM, get: get, paint: paint, save: save, clamp: clamp };
})();
DuaFS.paint(document.documentElement, DuaFS.get());

(function () {
  var KEY_FAV = 'pt_dua_fav';
  var st = { cat: 'all', view: 'all', q: '', fav: ld(KEY_FAV, []) };
  var catName = {}; DUA_CATS.forEach(function (c) { catName[c.id] = c.n; });

  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  var ICON_STAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.4l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.7l6-.8z"/></svg>';
  var ICON_COPY = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8.5" y="8.5" width="11" height="11" rx="2.6"/><path d="M15.5 8.5V6.6A2.1 2.1 0 0 0 13.4 4.5H6.6A2.1 2.1 0 0 0 4.5 6.6v6.8a2.1 2.1 0 0 0 2.1 2.1h1.9"/></svg>';
  var ICON_SHARE = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6.5" cy="12" r="2.3"/><circle cx="17.5" cy="6.5" r="2.3"/><circle cx="17.5" cy="17.5" r="2.3"/><path d="M8.5 10.9l7-3.3M8.5 13.1l7 3.3"/></svg>';
  var ICON_BOOK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.2A2.2 2.2 0 0 1 7.2 3H19v15.5H7.2A2.2 2.2 0 0 0 5 20.7z"/><path d="M5 20.7A2.2 2.2 0 0 0 7.2 23H19v-4.5"/></svg>';

  function isFav(id) { return st.fav.indexOf(id) > -1; }
  function toggleFav(id) { var i = st.fav.indexOf(id); if (i > -1) st.fav.splice(i, 1); else st.fav.push(id); sv(KEY_FAV, st.fav); }

  var toastT = 0;
  function toast(m) { var t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, 1700); }
  window.DuaToast = toast;

  function visible() {
    var base = DUA_ITEMS;
    if (st.q.trim()) { var r = DuaEngine.search(st.q); base = r.mode === 'empty' ? DUA_ITEMS : r.items.map(function (x) { return x.d; }); }
    return base.filter(function (d) {
      if (st.view === 'fav' && !isFav(d.id)) return false;
      if (st.cat !== 'all' && d.cat !== st.cat) return false;
      return true;
    });
  }

  /* একটি দোয়া — বক্স নেই: শিরোনাম, আরবি, উচ্চারণ, অর্থ, তারপর রেফারেন্স ও ছোট আইকন-বোতাম */
  function itemHtml(d, showLoc) {
    var f = isFav(d.id);
    return '<article class="ditem" data-id="' + esc(d.id) + '">' +
      (showLoc ? '<div class="dloc">' + DUA_ICON[d.cat] + '<span>' + esc(catName[d.cat]) + '</span></div>' : '') +
      '<div class="dhead"><div class="dt">' + esc(d.t) + '</div>' +
      '<button class="dfav' + (f ? ' on' : '') + '" data-fav="' + esc(d.id) + '" aria-pressed="' + f + '" aria-label="' + (f ? 'প্রিয় থেকে সরান' : 'প্রিয় করুন') + '">' + ICON_STAR + '</button></div>' +
      '<div class="dar" lang="ar" dir="rtl">' + esc(d.ar) + '</div>' +
      (d.note ? '<div class="dnote">' + esc(d.note) + '</div>' : '') +
      '<div class="dlb">উচ্চারণ</div><p class="dtr">' + esc(d.tr) + '</p>' +
      '<div class="dlb">অর্থ</div><p class="dbn">' + esc(d.bn) + '</p>' +
      '<div class="dfoot"><div class="dref">' + ICON_BOOK + '<span>' + esc(d.ref) + '</span></div>' +
      '<div class="dacts"><button class="dact" data-copy="' + esc(d.id) + '" aria-label="কপি করুন">' + ICON_COPY + '</button>' +
      '<button class="dact" data-share="' + esc(d.id) + '" aria-label="শেয়ার কার্ড বানান">' + ICON_SHARE + '</button></div></div>' +
      '</article>';
  }
  window.DuaItemHtml = itemHtml;          /* সাইজ-পপআপের প্রিভিউও একই কাঠামো ব্যবহার করে */

  function count(cat) { return DUA_ITEMS.filter(function (d) { return d.cat === cat; }).length; }

  function renderRail() {
    var h = '<button class="dch' + (st.cat === 'all' ? ' on' : '') + '" data-cat="all"><span class="dico">' + DUA_ICON.all + '</span><span>সব</span></button>';
    DUA_CATS.forEach(function (c) { h += '<button class="dch' + (st.cat === c.id ? ' on' : '') + '" data-cat="' + c.id + '"><span class="dico">' + DUA_ICON[c.id] + '</span><span>' + esc(c.n) + '</span></button>'; });
    $('rail').innerHTML = h;
    var on = $('rail').querySelector('.dch.on');          /* বাছাই করা অধ্যায়টা সারিতে দেখা যাক */
    if (on && on.scrollIntoView) { try { $('rail').scrollLeft = on.offsetLeft - ($('rail').clientWidth - on.offsetWidth) / 2; } catch (e) {} }
  }
  function renderSeg() {
    var tabs = document.querySelectorAll('.dseg button'), i;
    for (i = 0; i < tabs.length; i++) tabs[i].setAttribute('aria-selected', tabs[i].getAttribute('data-v') === st.view ? 'true' : 'false');
    $('thumb').style.transform = 'translateX(' + (st.view === 'fav' ? 100 : 0) + '%)';
  }
  function renderList() {
    var items = visible(), el = $('list');
    $('cnt').textContent = bn(items.length) + 'টি দোয়া' + (st.view === 'fav' ? ' (প্রিয়)' : '');
    if (!items.length) {
      el.innerHTML = st.view === 'fav' && !st.q && st.cat === 'all'
        ? '<div class="dempty"><b>এখনো কোনো প্রিয় দোয়া নেই</b>যেকোনো দোয়ার ☆ চাপলে সেটি এখানে জমা হবে।</div>'
        : '<div class="dempty"><b>কিছু পাওয়া যায়নি</b>অন্য শব্দে খুঁজুন অথবা অন্য অধ্যায় বেছে দেখুন।</div>';
      return;
    }
    var h = '';
    if (st.q.trim() || st.view === 'fav') {                /* সার্চ বা প্রিয় তালিকা: অধ্যায়ের নামসহ একটানা তালিকা */
      h = items.map(function (d) { return itemHtml(d, true); }).join('');
    } else {                                               /* সাধারণ দেখা: অধ্যায় ধরে ধরে সাজানো */
      DUA_CATS.forEach(function (c) {
        var inCat = items.filter(function (d) { return d.cat === c.id; });
        if (!inCat.length) return;
        h += '<section class="dsecw" data-sec="' + c.id + '"><div class="dsec"><span class="dico">' + DUA_ICON[c.id] + '</span>' +
          '<div><div class="dsec-t">' + esc(c.n) + '</div><div class="dsec-n">' + bn(inCat.length) + 'টি দোয়া</div></div></div>' +
          inCat.map(function (d) { return itemHtml(d, false); }).join('') + '</section>';
      });
    }
    el.innerHTML = h;
  }
  function renderAll() { renderRail(); renderSeg(); renderList(); }

  function find(id) { for (var i = 0; i < DUA_ITEMS.length; i++) if (DUA_ITEMS[i].id === id) return DUA_ITEMS[i]; return null; }
  function textOf(d) { return d.t + '\n\n' + d.ar + '\n\nউচ্চারণ: ' + d.tr + '\n\nঅর্থ: ' + d.bn + '\n\n(' + d.ref + ')'; }
  function copyText(s, done) {
    function fallback() {
      try {
        var ta = document.createElement('textarea'); ta.value = s; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
        document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, s.length);
        var ok = document.execCommand('copy'); document.body.removeChild(ta); done(ok);
      } catch (e) { done(false); }
    }
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(s).then(function () { done(true); }, fallback); return; } } catch (e) {}
    fallback();
  }

  $('list').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    var id;
    if ((id = b.getAttribute('data-fav'))) {
      toggleFav(id);
      if (st.view === 'fav') { renderList(); toast('প্রিয় থেকে সরানো হয়েছে'); }
      else { var on = isFav(id); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); b.setAttribute('aria-label', on ? 'প্রিয় থেকে সরান' : 'প্রিয় করুন'); toast(on ? 'প্রিয় দোয়ায় যোগ হয়েছে' : 'প্রিয় থেকে সরানো হয়েছে'); }
    } else if ((id = b.getAttribute('data-copy'))) {
      var d = find(id); if (d) copyText(textOf(d), function (ok) { toast(ok ? 'দোয়াটি কপি হয়েছে' : 'কপি করা যায়নি'); });
    } else if ((id = b.getAttribute('data-share'))) {
      var s = find(id); if (s && window.PtShareCard) window.PtShareCard.open({ kind: 'dua', title: s.t, ar: s.ar, tr: s.tr, bn: s.bn, ref: s.ref });
    }
  });
  $('rail').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    st.cat = b.getAttribute('data-cat'); renderRail(); renderList(); window.scrollTo(0, 0);
  });
  Array.prototype.forEach.call(document.querySelectorAll('.dseg button'), function (b) {
    b.addEventListener('click', function () { st.view = b.getAttribute('data-v'); if (st.view === 'fav') st.cat = 'all'; renderAll(); window.scrollTo(0, 0); });
  });
  var qEl = $('q'), qx = $('qx');
  qEl.addEventListener('input', function () { st.q = qEl.value; qx.classList.toggle('show', !!qEl.value); renderList(); });
  qx.addEventListener('click', function () { qEl.value = ''; st.q = ''; qx.classList.remove('show'); renderList(); qEl.focus(); });
  qEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); qEl.blur(); } });

  /* জুম বোতাম → লেখার সাইজ পপআপ */
  $('sz').addEventListener('click', function () { if (window.DuaSize) window.DuaSize.open(); });

  /* পূর্ণ-পর্দা সার্চ থেকে একটি দোয়ায় যাওয়া: ফিল্টার মুছে সেই দোয়ায় স্ক্রোল করে একটু জ্বালিয়ে দেখায় */
  function reveal(id, cat) {
    st.view = 'all'; st.q = ''; qEl.value = ''; qx.classList.remove('show');
    st.cat = cat && !id ? cat : 'all';
    renderAll();
    if (!id) { window.scrollTo(0, 0); return; }
    var el = document.querySelector('.ditem[data-id="' + id + '"]');
    if (!el) return;
    var y = el.getBoundingClientRect().top + (window.pageYOffset || 0) - 96;
    window.scrollTo(0, Math.max(0, y));
    el.classList.remove('dflash'); void el.offsetWidth; el.classList.add('dflash');
    setTimeout(function () { el.classList.remove('dflash'); }, 2000);
  }
  window.DuaApp = { reveal: reveal };

  $('hsub').textContent = bn(DUA_ITEMS.length) + 'টি দোয়া · ' + bn(DUA_CATS.length) + 'টি অধ্যায়';     /* কুরআনের "১১৪ সূরা · ৩০ পারা"-র মতো */
  renderAll();
})();
