package com.gunjoron.patheyo.notification

// v151: অ্যাপের নোটিফিকেশন ইনবক্স (ঘণ্টা আইকনের পেজ)।
//
// কী জমা হয়:
//   • ওয়েবসাইট/অ্যাডমিন প্যানেল থেকে পাঠানো সব পুশ (PatheyoMessagingService-এর সাধারণ ঘোষণা)
//   • নতুন অ্যাপ ভার্সনের খবর (app_update পুশ, ব্যাকগ্রাউন্ড চেক, অ্যাপ খুলে চেক)
// কী জমা হয় না: নামাজ/আজান/ইসলামিক রিমাইন্ডার (ওগুলো রোজ আসে — ইনবক্স ভরে যেত)।
//
// নিয়ম:
//   • একবার জমা হলে ইনবক্সে থেকে যায়। সীমা (অ্যাপ যেন কখনো ভারী না হয়): সর্বোচ্চ MAX_ITEMS টা,
//     পঠিত নোটিফিকেশন ৯০ দিন পর মুছে যায়, প্রতিটার লেখার দৈর্ঘ্যের ঊর্ধ্বসীমা আছে।
//     (সবচেয়ে খারাপ অবস্থাতেও ~২৫০ KB — সাধারণত ২০ KB-এর নিচে)
//   • "অপঠিত" সংখ্যাই ঘণ্টার পাশের লাল ব্যাজ।
//   • ইউজার একটা নোটিফিকেশনে ট্যাপ করলে শুধু সেটা পঠিত হয় → ব্যাজ ১ কমে।
//   • পেজ খুললেই কিছু পঠিত হয় না।
//   • ইউজার ইতিমধ্যে আপডেট করে ফেললে ওই ভার্সনের আপডেট-নোটিফিকেশন নিজে থেকেই পঠিত ধরা হয়।

import android.content.Context
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.update.UpdateChecker
import com.gunjoron.patheyo.update.UpdateInfo
import org.json.JSONArray
import org.json.JSONObject

object NotificationInbox {

    const val KIND_PUSH = "push"
    const val KIND_UPDATE = "update"

    private const val FILE = "patheyo_inbox"
    private const val K_ITEMS = "items"
    private const val MAX_ITEMS = 100                      // সর্বোচ্চ কতটা জমা থাকবে (পুরনোগুলো আগে ঝরে)
    private const val READ_TTL_MS = 90L * 24 * 60 * 60 * 1000 // পঠিত নোটিফিকেশন ৯০ দিন পর নিজে মুছে যায় (অপঠিতগুলো নয়)
    private const val MAX_TITLE = 200                      // একটা নোটিফিকেশনের সর্বোচ্চ আকার (অস্বাভাবিক বড় পুশে স্টোরেজ ফুলে ওঠা ঠেকাতে)
    private const val MAX_TEXT = 2000
    private const val MAX_UPDATE_TEXT = 8000               // v154: আপডেটের পুরো নোট (পপআপের মতোই সম্পূর্ণ) রাখার জন্য
    private const val MAX_LINK = 500
    private const val DUP_WINDOW_MS = 2 * 60 * 1000L   // একই লেখা ২ মিনিটের মধ্যে আবার এলে ডুপ্লিকেট

    /** ইনবক্স বদলালে (নতুন এলে / পঠিত হলে) ডাকা হয় — MainActivity এটা দিয়ে ওয়েবভিউর ব্যাজ রিফ্রেশ করে */
    @Volatile
    var onChanged: (() -> Unit)? = null

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun load(ctx: Context): JSONArray =
        try { JSONArray(sp(ctx).getString(K_ITEMS, null) ?: "[]") } catch (_: Throwable) { JSONArray() }

    private fun save(ctx: Context, arr: JSONArray) {
        sp(ctx).edit().putString(K_ITEMS, arr.toString()).apply()
    }

    private fun fire() {
        try { onChanged?.invoke() } catch (_: Throwable) {}
    }

    /**
     * নতুন নোটিফিকেশন জমা করে। আগেই থাকলে (একই id, বা ২ মিনিটের মধ্যে একই শিরোনাম+লেখা) false।
     * যেকোনো থ্রেড থেকে ডাকা নিরাপদ।
     */
    @Synchronized
    fun add(
        ctx: Context,
        id: String,
        title: String,
        text: String,
        link: String = "",
        kind: String = KIND_PUSH,
        ver: String = ""
    ): Boolean {
        if (id.isBlank() || (title.isBlank() && text.isBlank())) return false
        val title = title.take(MAX_TITLE)
        val text = text.take(if (kind == KIND_UPDATE) MAX_UPDATE_TEXT else MAX_TEXT)
        val link = link.take(MAX_LINK)
        val arr = prune(load(ctx))
        val now = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("id") == id) {
                // v154: একই আপডেট আবার এলে এবং নতুন লেখা বেশি বড় (পুরো নোট) হলে আগেরটা হালনাগাদ — নতুন আইটেম নয়
                if (kind == KIND_UPDATE && text.length > o.optString("text").length) {
                    o.put("text", text); save(ctx, arr); fire()
                }
                return false
            }
            if (kind == KIND_PUSH && o.optString("kind") == KIND_PUSH &&
                o.optString("title") == title && o.optString("text") == text &&
                now - o.optLong("ts") in 0..DUP_WINDOW_MS
            ) return false
        }
        val item = JSONObject()
            .put("id", id).put("title", title).put("text", text).put("link", link)
            .put("kind", kind).put("ver", ver).put("ts", now).put("read", false)
        // নতুনটা সবার আগে
        val out = JSONArray().put(item)
        var i = 0
        while (i < arr.length() && out.length() < MAX_ITEMS) { out.put(arr.get(i)); i++ }
        save(ctx, out)
        fire()
        return true
    }

    /** নতুন অ্যাপ ভার্সনের খবর জমা করে (একই ভার্সন একবারই জমা হয়) */
    fun addUpdate(ctx: Context, info: UpdateInfo): Boolean {
        val c = ctx.applicationContext
        val notes = info.releaseNotes.trim()
        // v154: ছোট অবস্থায় প্রথম লাইন হিসেবে এই বাক্যটাই দেখায়; ট্যাপ করলে নিচে পুরো নোট খোলে
        val lead = c.getString(R.string.inbox_update_line, info.versionName)
        val text = if (notes.isNotEmpty()) lead + "\n\n" + notes else c.getString(R.string.notif_update_text, info.versionName)
        return add(
            c,
            id = "update_" + info.versionName,
            title = c.getString(R.string.notif_update_title) + " (v" + info.versionName + ")",
            text = text,
            kind = KIND_UPDATE,
            ver = info.versionName
        )
    }

    /** যে আপডেট ইনস্টল হয়ে গেছে তার নোটিফিকেশন পঠিত করে দেয় (ব্যাজ ফাঁকা না থাকার ভুল এড়াতে) */
    @Synchronized
    private fun reconcile(ctx: Context, arr: JSONArray) {
        val installed = UpdateChecker.installedVersionName(ctx)
        if (installed.isBlank()) return
        var changed = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("kind") == KIND_UPDATE && !o.optBoolean("read") &&
                o.optString("ver").isNotBlank() &&
                UpdateChecker.semverCompare(o.optString("ver"), installed) <= 0
            ) { o.put("read", true); changed = true }
        }
        if (changed) save(ctx, arr)
    }

    /** ৯০ দিনের পুরনো পঠিত নোটিফিকেশন বাদ + MAX_ITEMS-এর বেশি হলে পুরনোগুলো বাদ। বদল না হলে একই অ্যারে ফেরত */
    private fun prune(arr: JSONArray): JSONArray {
        val now = System.currentTimeMillis()
        val keep = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val expired = o.optBoolean("read") && now - o.optLong("ts") > READ_TTL_MS
            if (!expired && keep.length() < MAX_ITEMS) keep.put(o)
        }
        return if (keep.length() == arr.length()) arr else keep
    }

    /** সব নোটিফিকেশন JSON অ্যারে হিসেবে (নতুনটা আগে) */
    @Synchronized
    fun allJson(ctx: Context): String {
        val loaded = load(ctx)
        val arr = prune(loaded)
        if (arr !== loaded) save(ctx, arr)
        reconcile(ctx, arr)
        return arr.toString()
    }

    @Synchronized
    fun unreadCount(ctx: Context): Int {
        val arr = load(ctx)
        reconcile(ctx, arr)
        var n = 0
        for (i in 0 until arr.length()) if (!(arr.optJSONObject(i)?.optBoolean("read") ?: true)) n++
        return n
    }

    /** শুধু এই একটা নোটিফিকেশন পঠিত করে। বদলালে true */
    @Synchronized
    fun markRead(ctx: Context, id: String): Boolean {
        val arr = load(ctx)
        var changed = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("id") == id && !o.optBoolean("read")) { o.put("read", true); changed = true }
        }
        if (changed) { save(ctx, arr); fire() }
        return changed
    }
}
