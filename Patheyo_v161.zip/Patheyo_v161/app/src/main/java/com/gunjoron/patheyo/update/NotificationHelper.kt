package com.gunjoron.patheyo.update

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.gunjoron.patheyo.R

object NotificationHelper {

    private const val CHANNEL_ID = "app_update"
    private const val ID_UPDATE = 7001
    private const val ID_INSTALL = 7002

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val ch = NotificationChannel(
            CHANNEL_ID,
            ctx.getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_HIGH      // হেডস-আপ (স্ক্রিনের উপরে ভেসে ওঠা) নোটিফিকেশন
        ).apply { description = ctx.getString(R.string.notif_channel_desc) }
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    /** নতুন আপডেটের নোটিফিকেশন। দেখানো গেলে true, পারমিশন না থাকলে false */
    @SuppressLint("MissingPermission")
    fun showUpdateAvailable(ctx: Context, info: UpdateInfo): Boolean {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return false

        // ট্যাপ করলে অ্যাপের লঞ্চার অ্যাক্টিভিটি খুলবে → সেখানে ডায়ালগ আসবে
        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return false
        val pi = PendingIntent.getActivity(
            ctx, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ctx.getColor(R.color.brand_notif_color))
            // v154: ছোট অবস্থায় = বোল্ড টাইটেল + মাত্র এক লাইন। নিচের তীর টেনে বড় করলে শুধু শিরোনামের তালিকা;
            // পুরো নোট পড়তে ট্যাপ করলে অ্যাপের আপডেট পপআপে খোলে।
            .setContentTitle(ctx.getString(R.string.notif_update_title))
            .setContentText(ctx.getString(R.string.notif_update_text, info.versionName))
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle(ctx.getString(R.string.notif_update_title))
                    .bigText(
                        UpdateChecker.highlights(info.releaseNotes).ifBlank {
                            ctx.getString(R.string.notif_update_text, info.versionName)
                        } + "\n\n" + ctx.getString(R.string.notif_tap_for_full)
                    )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            .setOnlyAlertOnce(true)     // একই ID-তে আবার এলে (চেকার/পুশ) আবার শব্দ/হেডস-আপ নয়
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(ID_UPDATE, n)
        return true
    }

    /** ডাউনলোড শেষ, কিন্তু অ্যাপ ব্যাকগ্রাউন্ডে → ট্যাপ করলে ইনস্টলার খুলবে */
    @SuppressLint("MissingPermission")
    fun showInstallReady(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val pi = PendingIntent.getActivity(
            ctx, 1, UpdateDownloader.buildInstallIntent(ctx),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ctx.getColor(R.color.brand_notif_color))
            .setContentTitle(ctx.getString(R.string.notif_install_title))
            .setContentText(ctx.getString(R.string.notif_install_text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(ID_INSTALL, n)
    }
}
