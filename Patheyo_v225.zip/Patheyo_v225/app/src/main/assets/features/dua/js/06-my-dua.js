/* দোয়া — নিজের পছন্দের দোয়া যোগ (ধাপ ২২৫)। শুধু প্রিমিয়াম সদস্য যোগ/বদলাতে পারেন।
   • + চাপলে: প্রিমিয়াম হলে "দোয়া যোগ" পপআপ (নাম · আইকন · আরবি · উচ্চারণ · অর্থ);
     প্রিমিয়াম না হলে বার্তা — এটা প্রিমিয়াম সুবিধা, আর আগে সাইন-ইন করতে হবে (অ্যাকাউন্টেই সেভ থাকে)।
   • ফন্ট নিজে থেকে মেলে: আরবি = কুরআনের Uthmanic Hafs, বাংলা = অ্যাপের GunjoronFont (.dar/.dtr/.dbn-এর একই ফন্ট) — আলাদা কিছু বসানো হয়নি।
   • সংরক্ষণ/মোছা: window.DuaCore (03-main.js)। প্রিমিয়াম/সাইন-ইনের অবস্থা: মূল পেজ (parent) থেকে। */
(function () {
  'use strict';
  var D = document, root = D.documentElement;
  var LIM = { n: 40, ar: 2000, tr: 2000, bn: 2000 };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function par() { try { return window.parent && window.parent !== window ? window.parent : null; } catch (e) { return null; } }
  function isPremium() {
    try { var p = par(); if (p && typeof p.ptIsPremium === 'function') return !!p.ptIsPremium(); } catch (e) {}
    return root.classList.contains('is-premium');
  }
  function signedIn() {
    try { var p = par(), a = p && p.PatheyoAuth; if (a && typeof a.state === 'function') return !!JSON.parse(a.state()).signedIn; } catch (e) {}
    return false;
  }
  function toast(m) { if (window.DuaToast) window.DuaToast(m); }

  /* ---------- পপআপের ভিত্তি (.veil + .sheet — লেখার-সাইজ পপআপের মতোই; ব্যাক চাপলে বন্ধ) ---------- */
  function mk(id, label, html) {
    var veil = D.createElement('div'); veil.className = 'veil'; veil.id = id + 'veil';
    var sh = D.createElement('div'); sh.className = 'sheet mysheet'; sh.id = id; sh.setAttribute('role', 'dialog'); sh.setAttribute('aria-label', label);
    sh.innerHTML = html; D.body.appendChild(veil); D.body.appendChild(sh);
    var o = { veil: veil, sh: sh, opened: false };
    o.open = function () {
      if (o.opened) return; o.opened = true;
      try { history.pushState({ dmy: id }, ''); } catch (e) {}
      root.classList.add('hs-lock', 'dsz-open'); veil.classList.add('on'); sh.classList.add('on'); sh.scrollTop = 0;
    };
    o.hide = function () {
      if (!o.opened) return; o.opened = false;
      veil.classList.remove('on'); sh.classList.remove('on'); root.classList.remove('hs-lock', 'dsz-open');
    };
    o.close = function () { if (!o.opened) return; if (history.state && history.state.dmy === id) history.back(); else o.hide(); };
    veil.addEventListener('click', o.close);
    return o;
  }
  var all = [];
  window.addEventListener('popstate', function () { all.forEach(function (o) { if (o.opened) o.hide(); }); });

  /* ---------- ১) প্রিমিয়াম/সাইন-ইনের বার্তা ---------- */
  var gate = null;
  function openGate() {
    if (!gate) {
      gate = mk('mygate', 'প্রিমিয়াম সুবিধা',
        '<div class="mg-top"><span class="mg-ic">' + DUA_ICON.crown + '</span><h3>নিজের দোয়া যোগ করুন</h3><span class="mg-badge">প্রিমিয়াম সুবিধা</span></div>' +
        '<p class="mg-p">নিজের পছন্দের যেকোনো দোয়া নাম ও আইকন দিয়ে এখানে যোগ করে রাখতে পারবেন — যত ইচ্ছা। আরবি ও বাংলা লেখা কুরআনের ফন্টেই দেখাবে।</p>' +
        '<div class="mg-note" id="mgsign"></div>' +
        '<p class="mg-free">অ্যাপের সব দোয়া আগের মতোই সবার জন্য ফ্রি থাকবে।</p>' +
        '<div class="mg-btns"><button type="button" class="mg-b2" data-g="close">এখন নয়</button><button type="button" class="mg-b1" data-g="go"></button></div>');
      all.push(gate);
      gate.sh.addEventListener('click', function (e) {
        var b = e.target.closest ? e.target.closest('button[data-g]') : null; if (!b) return;
        var k = b.getAttribute('data-g'), p = par(), need = !signedIn();
        gate.close();
        if (k !== 'go') return;
        setTimeout(function () {
          try {
            if (need) {                                     /* আগে সাইন-ইন: মূল পেজের প্রোফাইল/অ্যাকাউন্ট পর্দা */
              if (p && typeof p.__ptAccountOpen === 'function') p.__ptAccountOpen();
              else { var pb = p && p.document.getElementById('btn-profile'); if (pb) pb.click(); else toast('উপরের প্রোফাইল বোতাম থেকে সাইন-ইন করুন'); }
            } else if (p && typeof p.ptOpenPremium === 'function') p.ptOpenPremium('dua');
          } catch (er) { toast('এখন খোলা গেল না'); }
        }, 260);
      });
    }
    var inn = signedIn();
    gate.sh.querySelector('#mgsign').innerHTML = inn
      ? '<b>আপনি সাইন-ইন করা আছেন।</b> প্রিমিয়াম নিলেই এটা চালু হবে — আপনার যোগ করা দোয়া অ্যাকাউন্টে নিজে থেকে সেভ থাকবে।'
      : '<b>প্রথমে সাইন-ইন করুন।</b> প্রিমিয়াম আপনার অ্যাকাউন্টে থাকে, আর যোগ করা দোয়াও অ্যাকাউন্টে সেভ হয় — ফোন বদলালেও হারাবে না।';
    gate.sh.querySelector('[data-g="go"]').textContent = inn ? 'প্রিমিয়াম দেখুন' : 'সাইন-ইন করুন';
    gate.open();
  }

  /* ---------- ২) দোয়া যোগ/বদল ---------- */
  var form = null, pick = 'heart', editId = '', delArm = 0;
  function pickHtml() {
    return DUA_PICK.map(function (k) { return '<button type="button" class="dch pk" data-ic="' + k + '" aria-label="আইকন বাছুন"><span class="dico">' + DUA_ICON[k] + '</span></button>'; }).join('');
  }
  function paintPick() {
    [].forEach.call(form.sh.querySelectorAll('.pk'), function (b) { var on = b.getAttribute('data-ic') === pick; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
  }
  function buildForm() {
    form = mk('myform', 'দোয়া যোগ',
      '<div class="szhd"><h3 id="myttl">নিজের দোয়া যোগ করুন</h3><button type="button" class="szx" data-f="close" aria-label="বন্ধ করুন"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>' +
      '<label class="mf-l" for="my-n">দোয়ার নাম</label>' +
      '<input class="mf-i" id="my-n" type="text" maxlength="' + LIM.n + '" placeholder="যেমন: রিযিকের দোয়া" autocomplete="off">' +
      '<div class="mf-l">আইকন বাছুন</div><div class="mf-pick" id="my-pick">' + pickHtml() + '</div>' +
      '<label class="mf-l" for="my-ar">আরবি <i>(ঐচ্ছিক)</i></label>' +
      '<textarea class="mf-i mf-ar" id="my-ar" rows="2" lang="ar" dir="rtl" maxlength="' + LIM.ar + '" placeholder="আরবি লেখা"></textarea>' +
      '<label class="mf-l" for="my-tr">উচ্চারণ <i>(ঐচ্ছিক)</i></label>' +
      '<textarea class="mf-i" id="my-tr" rows="2" maxlength="' + LIM.tr + '" placeholder="বাংলা উচ্চারণ"></textarea>' +
      '<label class="mf-l" for="my-bn">অর্থ <i>(ঐচ্ছিক)</i></label>' +
      '<textarea class="mf-i" id="my-bn" rows="2" maxlength="' + LIM.bn + '" placeholder="বাংলা অর্থ"></textarea>' +
      '<div class="mf-err" id="my-err" role="alert"></div>' +
      '<div class="szbtn"><button type="button" id="my-del" class="mf-del" hidden>মুছুন</button><button type="button" data-f="close">বাতিল</button><button type="button" class="szok" data-f="save">সংরক্ষণ করুন</button></div>');
    all.push(form);
    form.sh.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
      if (b.hasAttribute('data-ic')) { pick = b.getAttribute('data-ic'); paintPick(); return; }
      var k = b.getAttribute('data-f');
      if (k === 'close') form.close();
      else if (k === 'save') save();
      else if (b.id === 'my-del') del(b);
    });
  }
  function f(id) { return form.sh.querySelector('#' + id); }
  function openForm(id) {
    if (!form) buildForm();
    editId = id || ''; delArm = 0;
    var c = id && window.DuaCore ? window.DuaCore.get(id) : null;
    pick = c && DUA_ICON[c.ic] ? c.ic : 'heart';
    f('myttl').textContent = c ? 'দোয়া বদলান' : 'নিজের দোয়া যোগ করুন';
    f('my-n').value = c ? c.n : ''; f('my-ar').value = c ? (c.ar || '') : ''; f('my-tr').value = c ? (c.tr || '') : ''; f('my-bn').value = c ? (c.bn || '') : '';
    f('my-err').textContent = ''; var d = f('my-del'); d.hidden = !c; d.textContent = 'মুছুন'; d.classList.remove('arm');
    paintPick(); form.open();
  }
  function save() {
    var n = f('my-n').value.trim(), ar = f('my-ar').value.trim(), tr = f('my-tr').value.trim(), bn = f('my-bn').value.trim(), er = f('my-err');
    if (!n) { er.textContent = 'দোয়ার একটা নাম দিন'; f('my-n').focus(); return; }
    if (!ar && !tr && !bn) { er.textContent = 'আরবি, উচ্চারণ বা অর্থের অন্তত একটা লিখুন'; return; }
    var rec = { id: editId || ('u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5)), n: n, ic: pick, ar: ar, tr: tr, bn: bn };
    window.DuaCore.save(rec);
    form.close();
    toast(editId ? 'দোয়া বদলানো হয়েছে' : 'দোয়া যোগ হয়েছে');
  }
  function del(b) {
    if (!delArm) { delArm = 1; b.textContent = 'আবার চাপলে মুছবে'; b.classList.add('arm'); setTimeout(function () { if (delArm) { delArm = 0; b.textContent = 'মুছুন'; b.classList.remove('arm'); } }, 3000); return; }
    window.DuaCore.remove(editId); form.close(); toast('দোয়াটি মুছে ফেলা হয়েছে');
  }

  window.DuaMy = {
    add: function () { if (isPremium()) openForm(''); else openGate(); },
    edit: function (id) { if (isPremium()) openForm(id); else openGate(); }
  };
})();
