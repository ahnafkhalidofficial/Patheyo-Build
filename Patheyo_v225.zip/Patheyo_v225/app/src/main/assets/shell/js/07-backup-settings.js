/* সেটিংস: (১) পুরো-অ্যাপ ব্যাকআপ ও রিস্টোর  (২) পড়ার লেখার সাইজ (কুরআন / হাদিস)।
   ডেটা সবই ফোনের localStorage-এ থাকে — ব্যাকআপ সেটাকে একটা JSON ফাইলে নেয় (ফাইলের ভেতরে checksum থাকে), রিস্টোর সেটা ফেরত বসায়।
   নেটিভ ব্রিজ PatheyoBackup (Kotlin) ফাইল সেভ/শেয়ার/বাছাই করে; ব্রাউজারে (ব্রিজ নেই) ডাউনলোড/ফাইল-ইনপুট দিয়ে চলে। */
(function () {
  'use strict';
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function jget(k, d) { try { var v = lsGet(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }
  function bridge() { return window.PatheyoBackup || null; }

  /* =====================================================================
     ১) পড়ার লেখার সাইজ — CSS zoom দিয়ে ফিচার-পেজের ভেতরে (ফ্রেমে) বসে
     ===================================================================== */
  var FS_KEY = 'pt_fs_v1';
  var FS_DEF = { qa: 100, qb: 100, ha: 100, hb: 100 };
  var FS_ROWS = [
    ['qa', 'কুরআনের আরবি', '#verses,#web-verses,.tr-arabic'],
    ['qb', 'কুরআনের বাংলা অনুবাদ', '.tr-bn'],
    ['ha', 'হাদিসের আরবি', '.hd-ar'],
    ['hb', 'হাদিসের বাংলা', '.hd-bn']
  ];
  function fsGet() {
    var s = jget(FS_KEY, {}), o = {};
    FS_ROWS.forEach(function (r) { var v = parseInt(s[r[0]], 10); o[r[0]] = isNaN(v) ? 100 : Math.min(180, Math.max(80, v)); });
    return o;
  }
  function fsCss(v) {
    var css = '';
    FS_ROWS.forEach(function (r) { if (v[r[0]] !== 100) css += r[2] + '{zoom:' + (v[r[0]] / 100) + '}\n'; });
    return css;
  }
  function applyTo(doc, v) {
    try {
      if (!doc || !doc.head) return;
      var st = doc.getElementById('pt-read-sizes');
      var css = fsCss(v || fsGet());
      if (!css) { if (st) st.remove(); return; }
      if (!st) { st = doc.createElement('style'); st.id = 'pt-read-sizes'; doc.head.appendChild(st); }
      if (st.textContent !== css) st.textContent = css;
    } catch (e) {}
  }
  window.__ptApplyReadSizes = function (doc) { applyTo(doc, null); };     /* ফিচার-পেজ খোলার সময় শেল (05-pages-controller.js) এটা ডাকে */
  function applyAllFrames() {
    var v = fsGet();
    Array.prototype.forEach.call(document.querySelectorAll('iframe'), function (f) { try { applyTo(f.contentDocument, v); } catch (e) {} });
  }

  function buildSizes() {
    var box = $('rs-rows'); if (!box) return;
    var v = fsGet();
    box.innerHTML = FS_ROWS.map(function (r) {
      return '<div class="rs-row" data-k="' + r[0] + '"><div class="rs-l"><b>' + r[1] + '</b><span data-v>' + bn(v[r[0]]) + '%</span></div>' +
        '<div class="rs-c"><button type="button" class="rs-b" data-d="-5" aria-label="ছোট করুন">−</button>' +
        '<input type="range" min="80" max="180" step="5" value="' + v[r[0]] + '" aria-label="' + r[1] + '">' +
        '<button type="button" class="rs-b" data-d="5" aria-label="বড় করুন">+</button></div></div>';
    }).join('');
    paintSizes();
    box.addEventListener('input', function (e) { var row = e.target.closest('.rs-row'); if (row && e.target.type === 'range') setSize(row.getAttribute('data-k'), +e.target.value); });
    box.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.rs-b') : null; if (!b) return;
      var row = b.closest('.rs-row'), k = row.getAttribute('data-k'); setSize(k, fsGet()[k] + (+b.getAttribute('data-d')));
    });
    var reset = $('rs-reset'); if (reset) reset.addEventListener('click', function () { lsSet(FS_KEY, JSON.stringify(FS_DEF)); paintSizes(); applyAllFrames(); });
  }
  function setSize(k, val) {
    var v = fsGet(); v[k] = Math.min(180, Math.max(80, Math.round(val / 5) * 5));
    lsSet(FS_KEY, JSON.stringify(v)); paintSizes(); applyAllFrames();
  }
  function paintSizes() {
    var v = fsGet();
    FS_ROWS.forEach(function (r) {
      var row = document.querySelector('.rs-row[data-k="' + r[0] + '"]'); if (!row) return;
      var inp = row.querySelector('input'); inp.value = v[r[0]];
      inp.style.setProperty('--p', ((v[r[0]] - 80) / 100 * 100) + '%');
      row.querySelector('[data-v]').textContent = bn(v[r[0]]) + '%' + (v[r[0]] === 100 ? ' (স্বাভাবিক)' : '');
    });
    ['qa', 'qb', 'ha', 'hb'].forEach(function (k) { var p = $('rs-p-' + k); if (p) p.style.zoom = v[k] / 100; });
  }

  /* =====================================================================
     ২) ব্যাকআপ ও রিস্টোর
     ===================================================================== */
  var KEYS = [     /* ইউজারের নিজের ডেটা / পছন্দ — ক্যাশ, ডাউনলোডের অবস্থা, অস্থায়ী ফ্ল্যাগ ইচ্ছা করেই বাদ */
    'amol_report_state',
    'tz3_counts', 'tz3_daily', 'tz3_goal', 'tz3_hist', 'tz3_mine', 'tz3_fi', 'tz3_sm', 'tz3_sn', 'tz3_sound', 'tz3_tab', 'tz3_theme',
    'pt_dua_fav', 'pt_dua_custom', 'pt_dua_fs', 'pt_dua_size', 'dua_theme', 'pt_share_card', 'pt_fs_v1',
    'quran-bookmarks', 'quran-last-read', 'quran-khatm', 'pt_qa_prefs', 'quran-theme', 'quran-tr-mode', 'quran-tr-show-arabic', 'quran-fn-hint-seen',
    'hadith-bookmarks', 'hadith-last-read', 'hadith-theme',
    'currentMadhab', 'customTasbihList', 'hijriAdjustment', 'nafalConfigs', 'prayerMethodId', 'waqtConfigs', 'waqtMinuteOffsets', 'userPrayerMethodId',
    'pathey-theme', 'ns_theme', 'pt_profile'
  ];
  var LAST_KEY = 'pt_last_backup', UNDO_KEY = 'pt_backup_undo', PENDING_KEY = 'pt_restore_pending';

  function sum32(str) {          /* FNV-1a ৩২-বিট — ফাইল ভাঙা বা হাতে বদলানো ধরার জন্য */
    var h = 0x811c9dc5;
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
    return ('00000000' + h.toString(16)).slice(-8);
  }
  function collect() {
    var data = {};
    KEYS.forEach(function (k) { var v = lsGet(k); if (v != null) data[k] = v; });
    return data;
  }
  function stamp(d) { d = d || new Date(); function p(n) { return ('0' + n).slice(-2); } return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }
  function makeBackup() {
    var data = collect(), body = JSON.stringify(data);
    return JSON.stringify({ app: 'patheyo', format: 1, created: new Date().toISOString(), keys: Object.keys(data).length, sum: sum32(body), data: data });
  }
  function fname() { return 'patheyo_backup_' + stamp() + '.json'; }

  /* ফাইলে কী কী আছে — মানুষের পড়ার মতো সংক্ষেপ */
  function describe(data) {
    var parts = [];
    function j(k) { try { return k in data ? JSON.parse(data[k]) : null; } catch (e) { return null; } }
    var am = j('amol_report_state');
    if (am && am.days) {
      var dn = Object.keys(am.days).length;
      parts.push('আমলের রিপোর্ট: ' + bn(dn) + ' দিন');
      var q = am.qaza, qn = 0; if (q && q.base) Object.keys(q.base).forEach(function (k) { qn += parseInt(q.base[k], 10) || 0; });
      if (qn || (q && q.log && q.log.length)) parts.push('কাজা নামাজের হিসাব');
      if (am.customAmals && am.customAmals.length) parts.push('নিজস্ব আমল: ' + bn(am.customAmals.length) + 'টি');
    }
    var th = j('tz3_hist'); if (th) parts.push('তাসবিহের ইতিহাস: ' + bn(Object.keys(th).length) + ' দিন');
    var tm = j('tz3_mine'); if (tm && tm.length) parts.push('আমার জিকির: ' + bn(tm.length) + 'টি');
    var df = j('pt_dua_fav'); if (df && df.length) parts.push('প্রিয় দোয়া: ' + bn(df.length) + 'টি');
    var dc = j('pt_dua_custom'); if (dc && dc.length) parts.push('নিজের যোগ করা দোয়া: ' + bn(dc.length) + 'টি');
    function cnt(x) { if (!x) return 0; if (Array.isArray(x)) return x.length; if (typeof x === 'object') return Object.keys(x).length; return 0; }
    var qb = cnt(j('quran-bookmarks')); if (qb) parts.push('কুরআনের বুকমার্ক: ' + bn(qb) + 'টি');
    var hb = cnt(j('hadith-bookmarks')); if (hb) parts.push('হাদিসের বুকমার্ক: ' + bn(hb) + 'টি');
    if ('waqtConfigs' in data || 'nafalConfigs' in data || 'prayerMethodId' in data) parts.push('নামাজের সময়ের সেটিংস');
    if ('pathey-theme' in data) parts.push('থিম ও পড়ার পছন্দ');
    return parts;
  }

  /* ---------- UI ---------- */
  function msg(t, kind) {
    var m = $('bk-msg'); if (!m) return;
    m.textContent = t; m.className = 'bk-msg' + (kind ? ' ' + kind : '') + (t ? ' show' : '');
    clearTimeout(msg._t); if (t) { msg._t = setTimeout(function () { m.classList.remove('show'); }, 8000); try { m.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} }
  }
  function fmtDate(iso) {
    var M = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    var d = new Date(iso); if (isNaN(d)) return '';
    return bn(d.getDate()) + ' ' + M[d.getMonth()] + ' ' + bn(d.getFullYear());
  }
  function paintSummary() {
    var box = $('bk-sum'); if (!box) return;
    var parts = describe(collect());
    box.innerHTML = parts.length ? parts.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') : '<li class="mute">এখনো ব্যাকআপ করার মতো কিছু জমেনি</li>';
    var last = lsGet(LAST_KEY), el = $('bk-last');
    if (el) el.textContent = last ? 'শেষ ব্যাকআপ: ' + fmtDate(last) : 'এখনো ব্যাকআপ নেওয়া হয়নি';
    var undo = $('bk-undo'); if (undo) undo.hidden = !lsGet(UNDO_KEY);
    var sv = $('bk-save'); if (sv) { var b = bridge(); sv.style.display = (b && typeof b.canSave === 'function' && !b.canSave()) ? 'none' : ''; }
  }
  function done() { lsSet(LAST_KEY, new Date().toISOString()); paintSummary(); }

  function doSave() {
    var text = makeBackup(), b = bridge(), name = fname();
    if (b && typeof b.saveFile === 'function') {
      var path = ''; try { path = b.saveFile(name, text); } catch (e) {}
      if (path) { done(); msg('ব্যাকআপ সেভ হয়েছে: ' + path, 'ok'); } else msg('সেভ করা যায়নি — "শেয়ার করুন" দিয়ে ফাইলটা পাঠিয়ে রাখুন', 'err');
      return;
    }
    try {                       /* ব্রাউজার */
      var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name;
      document.body.appendChild(a); a.click(); a.remove(); done(); msg('ব্যাকআপ ডাউনলোড হচ্ছে', 'ok');
    } catch (e) { msg('সেভ করা যায়নি', 'err'); }
  }
  function doShare() {
    var text = makeBackup(), b = bridge(), name = fname();
    if (b && typeof b.shareFile === 'function') {
      var ok = false; try { ok = b.shareFile(name, text); } catch (e) {}
      if (ok) { done(); msg('শেয়ার-শিট খুলেছে — Telegram, Google Drive বা Gmail-এ নিজেকে পাঠিয়ে রাখুন', 'ok'); } else msg('শেয়ার করা যায়নি', 'err');
      return;
    }
    doSave();
  }

  /* রিস্টোর: ফাইল বাছাই → যাচাই → নিশ্চিত → (পরের লোডে) বসানো */
  var picked = null;
  function pick() {
    var b = bridge();
    if (b && typeof b.pickFile === 'function') { var ok = false; try { ok = b.pickFile(); } catch (e) {} if (!ok) msg('ফাইল বাছাই খোলা যায়নি', 'err'); return; }
    var inp = $('bk-file'); if (inp) inp.click();
  }
  window.__ptBackupPicked = function (text, name, err) {
    if (err) { if (err !== 'cancel') msg(err === 'big' ? 'ফাইলটা অনেক বড় — এটা পাথেয়-ব্যাকআপ নয়' : 'ফাইলটা পড়া যায়নি', 'err'); return; }
    inspect(text, name);
  };
  function inspect(text, name) {
    var o; try { o = JSON.parse(text); } catch (e) { msg('এটা পাথেয়-ব্যাকআপ ফাইল নয় (পড়া যায়নি)', 'err'); return; }
    if (!o || o.app !== 'patheyo' || o.format !== 1 || !o.data || typeof o.data !== 'object') { msg('এটা পাথেয়-ব্যাকআপ ফাইল নয়', 'err'); return; }
    if (sum32(JSON.stringify(o.data)) !== o.sum) { msg('ফাইলটা ভাঙা বা হাতে বদলানো — নিরাপত্তার জন্য রিস্টোর করা হবে না', 'err'); return; }
    var data = {}, allowed = {}; KEYS.forEach(function (k) { allowed[k] = 1; });
    Object.keys(o.data).forEach(function (k) { if (allowed[k] && typeof o.data[k] === 'string') data[k] = o.data[k]; });
    var n = Object.keys(data).length;
    if (!n) { msg('ফাইলে ফিরিয়ে আনার মতো কিছু নেই', 'err'); return; }
    picked = { data: data, created: o.created, name: name };
    var cf = $('bk-confirm'); if (!cf) return;
    $('bk-c-date').textContent = o.created ? 'ব্যাকআপের তারিখ: ' + fmtDate(o.created) : '';
    $('bk-c-list').innerHTML = describe(data).map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('');
    cf.hidden = false; cf.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  function confirmRestore() {
    if (!picked) return;
    var snap = collect();      /* আগের অবস্থা রেখে দিই — ভুল হলে "রিস্টোর বাতিল করুন" দিয়ে ফেরা যায় */
    var undoSaved = lsSet(UNDO_KEY, JSON.stringify({ at: new Date().toISOString(), data: snap }));
    if (!lsSet(PENDING_KEY, JSON.stringify({ data: picked.data }))) { msg('জায়গা কম — রিস্টোর শুরু করা যায়নি', 'err'); return; }
    msg(undoSaved ? 'রিস্টোর হচ্ছে… অ্যাপ নতুন করে খুলছে' : 'রিস্টোর হচ্ছে (বাতিলের সুবিধা ছাড়া)…', 'ok');
    setTimeout(function () { location.reload(); }, 500);
  }
  function undoRestore() {
    var u = jget(UNDO_KEY, null); if (!u || !u.data) { msg('বাতিল করার মতো কিছু নেই', 'err'); return; }
    if (!lsSet(PENDING_KEY, JSON.stringify({ data: u.data, removeMissing: true, keys: KEYS }))) { msg('জায়গা কম — বাতিল করা যায়নি', 'err'); return; }
    try { localStorage.removeItem(UNDO_KEY); } catch (e) {}
    msg('আগের অবস্থায় ফিরছে…', 'ok'); setTimeout(function () { location.reload(); }, 500);
  }

  /* ধাপ ৯: অ্যাকাউন্টের ক্লাউড সিঙ্ক (shell/js/10-account.js) এই একই ব্যাকআপ ব্যবহার করে —
     ক্লাউডে যায় makeBackup()-এর লেখা, ফেরত আসলে একই যাচাই (app/format/sum) পেরিয়ে একই পথে (PENDING → রিলোড) বসে। */
  window.__ptBackup = {
    collect: collect, make: makeBackup, sum32: sum32, describe: describe,
    fingerprint: function () { return sum32(JSON.stringify(collect())); },
    restoreText: function (text) {
      var o; try { o = JSON.parse(text); } catch (e) { return 'bad'; }
      if (!o || o.app !== 'patheyo' || o.format !== 1 || !o.data || typeof o.data !== 'object') return 'bad';
      if (sum32(JSON.stringify(o.data)) !== o.sum) return 'broken';
      var data = {}, allowed = {}; KEYS.forEach(function (k) { allowed[k] = 1; });
      Object.keys(o.data).forEach(function (k) { if (allowed[k] && typeof o.data[k] === 'string') data[k] = o.data[k]; });
      if (!Object.keys(data).length) return 'empty';
      lsSet(UNDO_KEY, JSON.stringify({ at: new Date().toISOString(), data: collect() }));
      if (!lsSet(PENDING_KEY, JSON.stringify({ data: data }))) return 'space';
      setTimeout(function () { location.reload(); }, 400);
      return 'ok';
    },
    /* v194: সাইন-আউটে এই ফোনকে "প্রথম দিনের" অবস্থায় ফেরানো — নাম, ছবি, সব সেটিংস ও হিসাব (KEYS) মুছে অ্যাপ নতুন করে খোলে।
       (অনবোর্ডিং-চিহ্ন, লোকেশন-অনুমতি ইত্যাদি ডিভাইসের জিনিস থাকে।) রিস্টোরের একই পথ — রিলোডের একদম শুরুতে মোছা হয়। */
    resetLocal: function () {
      ['pt_cloud', 'pt_avatar_up', 'pt_avatar_dirty', 'pt_google_mode', LAST_KEY, UNDO_KEY].forEach(function (k) { try { localStorage.removeItem(k); } catch (e) {} });
      lsSet(PENDING_KEY, JSON.stringify({ data: {}, removeMissing: true, keys: KEYS }));
      setTimeout(function () { location.reload(); }, 500);
      return true;
    },
    peek: function (text) { try { var o = JSON.parse(text); return o && o.data ? { created: o.created, list: describe(o.data), fp: sum32(JSON.stringify(o.data)) } : null; } catch (e) { return null; } }
  };

  function init() {
    buildSizes();
    paintSummary();
    var map = { 'bk-save': doSave, 'bk-share': doShare, 'bk-pick': pick, 'bk-ok': confirmRestore, 'bk-undo': undoRestore };
    Object.keys(map).forEach(function (id) { var e = $(id); if (e) e.addEventListener('click', map[id]); });
    var no = $('bk-no'); if (no) no.addEventListener('click', function () { picked = null; $('bk-confirm').hidden = true; });
    var fi = $('bk-file');
    if (fi) fi.addEventListener('change', function () {   /* ব্রাউজারে ফাইল-ইনপুট */
      var f = fi.files && fi.files[0]; if (!f) return;
      var r = new FileReader(); r.onload = function () { inspect(String(r.result), f.name); fi.value = ''; }; r.readAsText(f);
    });
    var open = $('btn-settings'); if (open) open.addEventListener('click', function () { setTimeout(paintSummary, 50); });   /* সেটিংস খুললে সারসংক্ষেপ নতুন করে */
    /* সদ্য রিস্টোর হলে জানাই (early script এই চিহ্ন রেখে যায়) */
    if (lsGet('pt_restored_flag')) { try { localStorage.removeItem('pt_restored_flag'); } catch (e) {} setTimeout(function () { msg('রিস্টোর সম্পন্ন হয়েছে — সব ডেটা ফিরে এসেছে', 'ok'); }, 800); }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
