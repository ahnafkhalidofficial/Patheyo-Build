/* =============================================================================
   ধাপ ১০ — পাথেয় প্রিমিয়াম (পেওয়াল ও অবস্থা)
   নেটিভ: PatheyoPremium (app/.../premium/PremiumBridge.kt) — অবস্থা অ্যাকাউন্টে (users/{uid}/premium, শুধু সার্ভার লেখে)।
   নিয়ম: কোনো জোরাজুরি পপআপ নেই — পেওয়াল খোলে শুধু সেটিংসের "প্রিমিয়াম" সারি বা "বিজ্ঞাপন সরান" থেকে।
          ধর্মীয় কোনো কিছুই কখনো প্রিমিয়ামের পেছনে নয়।
   অন্য কোড প্রিমিয়াম জানতে:  window.ptIsPremium()  ·  html.is-premium  ·  'pt:premium' ইভেন্ট
   খোলার জন্য:  window.ptOpenPremium(from)   (from = 'settings' | 'ads' | …)
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window, root = D.documentElement;
  var $ = function (id) { return D.getElementById(id); };
  var P = function () { return W.PatheyoPremium || null; };
  var BN = '০১২৩৪৫৬৭৮৯', MONTHS = ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
  function bn(x) { return String(x).replace(/\d/g, function (d) { return BN[d]; }); }
  function fdate(ms) { var d = new Date(ms); return bn(d.getDate()) + ' ' + MONTHS[d.getMonth()] + ' ' + bn(d.getFullYear()); }
  function daysLeft(ms) { return Math.ceil((ms - Date.now()) / 86400000); }
  function toast(t, type, o) { if (W.PT) PT.toast(t, Object.assign({ type: type || '' }, o || {})); }

  var sheet = $('pw-sheet');
  var PRICE = { monthly: 49, yearly: 399, lifetime: 999 };
  var LABEL = { monthly: 'মাসিক', yearly: 'বার্ষিক', lifetime: 'আজীবন' };

  /* ---------------------------------------------------------------- অবস্থা */
  var S = { active: false }, CFG = { ready: false, distribution: 'github' };
  function read() {
    try { var p = P(); if (p) { S = JSON.parse(p.state()) || S; CFG = JSON.parse(p.config()) || CFG; } } catch (e) {}
    return S;
  }
  W.ptIsPremium = function () { return !!S.active; };
  function apply() {
    root.classList.toggle('is-premium', !!S.active);
    /* খোলা ফিচার-পেজগুলোতেও (ভবিষ্যতের প্রিমিয়াম থিম ইত্যাদির জন্য) */
    [].forEach.call(D.querySelectorAll('iframe'), function (f) { try { f.contentDocument.documentElement.classList.toggle('is-premium', !!S.active); } catch (e) {} });
    paintRow();
    try { W.dispatchEvent(new CustomEvent('pt:premium', { detail: S })); } catch (e) {}
  }
  W.__ptPremiumChanged = function (json) {
    var was = !!S.active;
    try { S = JSON.parse(json); } catch (e) {}
    apply();
    if (!was && S.active) { celebrate(); }
    if (sheet && !sheet.hidden) paint();
  };

  /* ---------------------------------------------------------------- নেটিভ কল */
  var seq = 0, wait = {};
  W.__ptPremiumCb = function (id, json) { var f = wait[id]; if (!f) return; delete wait[id]; var r; try { r = JSON.parse(json); } catch (e) { r = { ok: false }; } if (r.state) S = r.state; f(r); };
  function call(fn) {
    var args = [].slice.call(arguments, 1);
    return new Promise(function (res) {
      var p = P(); if (!p || typeof p[fn] !== 'function') { res({ ok: false, code: 'na', msg: 'এই সুবিধা শুধু অ্যাপের ভেতরে কাজ করে।' }); return; }
      var id = 'p' + (++seq); wait[id] = res;
      try { p[fn].apply(p, [id].concat(args)); } catch (e) { delete wait[id]; res({ ok: false, msg: 'কাজটি সম্পন্ন করা যায়নি' }); }
    });
  }
  function signedIn() { try { var a = W.PatheyoAuth; return !!(a && JSON.parse(a.state()).signedIn); } catch (e) { return false; } }

  /* ---------------------------------------------------------------- সেটিংসের সারি */
  function paintRow() {
    var t = $('st-prem-t'), s = $('st-prem-s'), row = $('st-prem-row'); if (!t) return;
    row.classList.toggle('is-on', !!S.active);
    if (S.active) {
      t.textContent = 'প্রিমিয়াম সদস্য';
      s.textContent = S.plan === 'lifetime' ? 'আজীবন · জাযাকাল্লাহু খাইরান' : 'মেয়াদ ' + fdate(S.until) + ' পর্যন্ত';
    } else if (S.had) { t.textContent = 'প্রিমিয়ামের মেয়াদ শেষ'; s.textContent = 'নবায়ন করলে আবার বিজ্ঞাপন ছাড়া'; }
    else { t.textContent = 'পাথেয় প্রিমিয়াম'; s.textContent = 'বিজ্ঞাপন ছাড়া · আপনার সহযোগিতায় সবার জন্য ফ্রি থাকে'; }
  }

  /* ---------------------------------------------------------------- পেওয়াল */
  var plan = 'yearly', busy = false;
  function selPlan(p) {
    plan = p;
    [].forEach.call(sheet.querySelectorAll('.pw-plan'), function (b) { b.setAttribute('aria-checked', b.getAttribute('data-plan') === p ? 'true' : 'false'); });
    paintCta();
  }
  function paintCta() {
    var cta = $('pw-cta'), small = $('pw-small');
    cta.disabled = false; cta.classList.remove('is-soon');
    var renew = S.active && S.plan !== 'lifetime';
    if (S.active && S.plan === 'lifetime') { cta.textContent = 'জাযাকাল্লাহু খাইরান'; cta.disabled = true; small.textContent = 'আপনার আজীবন প্রিমিয়াম চালু আছে।'; return; }
    if (!CFG.ready) {
      cta.textContent = 'শীঘ্রই চালু হচ্ছে'; cta.classList.add('is-soon');
      small.textContent = 'পেমেন্ট ব্যবস্থা (bKash · Nagad · কার্ড) চালু হলে ইনশাআল্লাহ এখান থেকেই নিতে পারবেন।';
      return;
    }
    if (!signedIn()) { cta.textContent = 'সাইন-ইন করে চালিয়ে যান'; small.textContent = 'প্রিমিয়াম আপনার অ্যাকাউন্টে থাকে — সব ফোনে, ফোন বদলালেও।'; return; }
    cta.textContent = (renew ? 'নবায়ন: ' : '') + '৳' + bn(PRICE[plan]) + ' — ' + LABEL[plan] + (renew ? '' : ' প্রিমিয়াম নিন');
    small.textContent = CFG.distribution === 'play' ? 'Google Play-র মাধ্যমে নিরাপদ পেমেন্ট।' : 'bKash · Nagad · কার্ড — মেয়াদ শেষে স্বয়ংক্রিয়ভাবে টাকা কাটা হয় না; আগেই মনে করিয়ে দেওয়া হবে।';
  }
  function paint() {
    read();
    var mem = !!S.active;
    sheet.setAttribute('data-view', mem ? 'member' : 'buy');
    $('pw-mem-until').textContent = mem ? (S.plan === 'lifetime' ? 'আজীবন প্রিমিয়াম — আপনার সহযোগিতার জন্য জাযাকাল্লাহু খাইরান।' :
      LABEL[S.plan] + ' প্ল্যান · মেয়াদ ' + fdate(S.until) + ' পর্যন্ত (' + bn(Math.max(0, daysLeft(S.until))) + ' দিন বাকি)') : '';
    /* v274: বেনামী সদস্য কোড — সহায়তার সময় জানালে অ্যাডমিন সদস্যপদ খুঁজে পান (নাম/ইমেইল ছাড়াই) */
    var cd = $('pw-mem-code');
    if (cd) { cd.hidden = !(mem && S.code); cd.textContent = S.code ? 'সদস্য কোড: ' + S.code : ''; }
    /* সদস্য হলেও নবায়নের জন্য প্ল্যান দেখাই, যদি মেয়াদ ১০ দিনের কম */
    var showPlans = !mem || (S.plan !== 'lifetime' && daysLeft(S.until) <= 10);
    sheet.classList.toggle('pw-renew', mem && showPlans);
    if (mem && S.plan && S.plan !== 'lifetime') selPlan(S.plan); else paintCta();
  }
  W.ptOpenPremium = function (from) {
    if (!sheet || !W.PT) return;
    paint(); PT.sheet.open(sheet);
    try { localStorage.setItem('pt_pw_last', JSON.stringify({ from: from || '', at: Date.now() })); } catch (e) {}
  };

  if (sheet) {
    sheet.addEventListener('click', function (e) {
      if (e.target.closest('[data-pw-close]')) { PT.sheet.close(sheet); return; }
      var pl = e.target.closest('.pw-plan'); if (pl) { selPlan(pl.getAttribute('data-plan')); if (W.PT) PT.haptic('light'); return; }
      var rs = e.target.closest('[data-pw="restore"]');
      if (rs && !busy) {
        if (!signedIn()) { PT.sheet.close(sheet); if (W.__ptAccountOpen) W.__ptAccountOpen(); toast('যে অ্যাকাউন্টে কিনেছিলেন সেটিতে সাইন-ইন করুন'); return; }
        busy = true;
        call('restore').then(function (r) { busy = false; paint(); toast(r.ok ? (S.active ? 'প্রিমিয়াম ফিরে এসেছে — জাযাকাল্লাহ' : 'এই অ্যাকাউন্টে কোনো সক্রিয় প্রিমিয়াম পাওয়া যায়নি') : r.msg, r.ok && S.active ? 'success' : ''); });
      }
    });
    $('pw-cta').addEventListener('click', function () {
      var cta = this; if (busy || cta.disabled) return;
      if (!CFG.ready) { toast('পেমেন্ট ব্যবস্থা চালু হলে জানিয়ে দেওয়া হবে, ইনশাআল্লাহ'); return; }
      if (!signedIn()) { PT.sheet.close(sheet); if (W.__ptAccountOpen) W.__ptAccountOpen(); return; }
      busy = true; cta.classList.add('is-loading');
      call('buy', plan).then(function (r) {
        busy = false; cta.classList.remove('is-loading');
        if (r.ok && r.opened) toast('পেমেন্ট পেজ খোলা হয়েছে — পেমেন্ট শেষে অ্যাপে ফিরে আসুন');
        else if (!r.ok && r.code !== 'cancel') toast(r.msg || 'পেমেন্ট শুরু করা যায়নি', 'danger');
      });
    });
  }
  /* গেটওয়ে থেকে ফেরত */
  W.__ptPayReturn = function (json) {
    var r = {}; try { r = JSON.parse(json); } catch (e) {}
    if (r.status === 'success') toast('পেমেন্ট সম্পন্ন — প্রিমিয়াম চালু হচ্ছে…', 'success');
    else if (r.status === 'cancelled') toast('পেমেন্ট বাতিল করা হয়েছে');
    else toast('পেমেন্ট সম্পন্ন হয়নি — টাকা কাটা হয়ে থাকলে কয়েক মিনিটের মধ্যে প্রিমিয়াম নিজে থেকে চালু হবে; না হলে আমাদের সাথে যোগাযোগ করুন', 'danger', { ms: 6000 });
  };
  function celebrate() {
    toast('আলহামদুলিল্লাহ! প্রিমিয়াম চালু হয়েছে — আপনার সহযোগিতার জন্য জাযাকাল্লাহু খাইরান', 'success', { ms: 5000 });
  }

  /* প্রবেশপথ: সেটিংসের সারি ও "বিজ্ঞাপন সরান" */
  D.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-premium]'); if (!b) return;
    W.ptOpenPremium(b.getAttribute('data-premium'));
  });

  /* ---------------------------------------------------------------- নবায়নের কথা মনে করানো (দিনে একবার, শেষ ৫ দিনে) */
  function remind() {
    if (!S.active || S.plan === 'lifetime' || !S.until) return;
    var left = daysLeft(S.until); if (left > 5) return;
    var key = 'pt_pw_remind', today = new Date().toDateString();
    try { if (localStorage.getItem(key) === today) return; localStorage.setItem(key, today); } catch (e) {}
    toast(left <= 0 ? 'প্রিমিয়ামের মেয়াদ আজ শেষ হচ্ছে' : 'প্রিমিয়ামের মেয়াদ ' + bn(left) + ' দিনে শেষ হবে', '', { action: 'নবায়ন', onAction: function () { W.ptOpenPremium('renew'); }, ms: 7000 });
  }

  read(); apply();
  setTimeout(remind, 6000);
  /* ফিচার-পেজ খুললে তাতেও চিহ্ন */
  W.addEventListener('pt-frame-chrome', function () { apply(); });
})();
