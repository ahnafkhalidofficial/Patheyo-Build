package com.gunjoron.patheyo.datecard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import java.util.Calendar

/**
 * হিজরি ক্যালেন্ডার + আসন্ন বিশেষ দিন (আগে নামাজ ফিচারে ছিল, v211 থেকে তারিখ-কার্ড ফিচারের শুরুতে)।
 * নকশা ও হিসাব নামাজ ফিচারের আগের ওয়েব-সংস্করণের (25-js-ui-extras.js → nzRenderCal) হুবহু কোটলিন রূপ।
 * আজকের হিজরি তারিখ আসে হোম/উইজেটের একই হিসাব ([Snapshot]) থেকে — তাই ফায়ারবেস-অ্যাডজাস্টমেন্ট মেনে চলে।
 */
class HijriCalendarCard(private val ctx: Context, private val p: Pal) {

    class Pal(
        val surf: Int, val surfHi: Int, val surf2: Int, val line: Int,
        val text: Int, val text2: Int, val text3: Int,
        val primary: Int, val press: Int, val onPrimary: Int, val primaryText: Int,
        val gold: Int, val goldLine: Int, val goldSoft: Int,
        val bold: Typeface, val reg: Typeface
    )

    class Ev(val m: Int, val d: Int, val t: String, val s: String? = null)
    class Up(val k: Int, val g: Calendar, val title: String, val sub: String?, val day: Int, val month: Int)
    class H(val day: Int, val month: Int, val year: Int)

    companion object {
        /** মাসের নাম — নামাজ ফিচারের hijriMonthsBN-এর সাথে হুবহু */
        val MONTHS = arrayOf(
            "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল উলা", "জমাদিউস সানি",
            "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
        )
        private val EVENTS = listOf(
            Ev(0, 1, "হিজরি নববর্ষ"),
            Ev(0, 10, "আশুরা", "৯ ও ১০ বা ১০ ও ১১ মুহাররম রোজা"),
            Ev(6, 26, "শবে মিরাজ", "২৬ রজব দিবাগত রাত"),
            Ev(7, 14, "শবে বরাত", "১৪ শাবান দিবাগত রাত"),
            Ev(8, 1, "রমজান শুরু", "প্রথম রোজা (চাঁদ দেখা সাপেক্ষে)"),
            Ev(8, 26, "শবে কদর", "২৬ রমজান দিবাগত রাত"),
            Ev(9, 1, "ঈদুল ফিতর", "আজ রোজা রাখা হারাম"),
            Ev(11, 9, "আরাফাহর দিন", "নফল রোজা — দুই বছরের গুনাহ মাফ"),
            Ev(11, 10, "ঈদুল আজহা", "কোরবানির দিন")
        )
        private val WD = arrayOf("শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র")
        private val WD_FULL = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

        // ---------------------------------------------------------------- হিসাব

        private fun midnight(base: Calendar, plusDays: Int): Calendar =
            (base.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.DAY_OF_YEAR, plusDays)
            }

        /** Tabular Islamic Calendar (অ্যাডজাস্টমেন্ট ছাড়া) — ওয়েবের localGregorianToHijri(date, true)-এর সমান */
        private fun tabular(c: Calendar): H {
            val y = c.get(Calendar.YEAR); val m = c.get(Calendar.MONTH) + 1; val d = c.get(Calendar.DAY_OF_MONTH)
            val a = (14 - m) / 12
            val y2 = y + 4800 - a
            val m2 = m + 12 * a - 3
            val jdn = d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 - 32045
            var l = jdn - 1948440 + 10632
            val n = (l - 1) / 10631
            l = l - 10631 * n + 354
            val j = (10985 - l) / 5316 * (50 * l / 17719) + (l / 5670) * (43 * l / 15238)
            l = l - (30 - j) / 15 * (17719 * j / 50) - (j / 16) * (15238 * j / 43) + 29
            val month = (24 * l) / 709
            val day = l - (709 * month) / 24
            return H(day, month - 1, 30 * n + j - 30)
        }

        private fun monthIndexOf(name: String): Int {
            val n = name.trim()
            for (i in MONTHS.indices) if (n == MONTHS[i]) return i
            for (i in Bn.HIJRI_MONTHS.indices) if (n == Bn.HIJRI_MONTHS[i]) return i
            for (i in MONTHS.indices) if (n.contains(MONTHS[i]) || MONTHS[i].contains(n)) return i
            return -1
        }

        /**
         * হিজরি তারিখ ঠিক [atMs] সময়ে — হোম/উইজেটের একই উৎস ([Snapshot]) থেকে, তাই ফায়ারবেসের hijri_adjustment /
         * hijri_override / মাগরিব-শিফট সব মেনে চলে। না পেলে ফোনের সূত্র + সেভ করা অ্যাডজাস্টমেন্ট।
         */
        private fun hijriAt(ctx: Context, atMs: Long, civil: Calendar): H {
            try {
                val snap = Snapshot.build(ctx.applicationContext, atMs)
                val day = FirebaseDataManager.convertBengaliToEnglish(snap.hijriDay).trim().toIntOrNull()
                val year = FirebaseDataManager.convertBengaliToEnglish(snap.hijriYear).trim().toIntOrNull()
                val mi = monthIndexOf(snap.hijriMonth)
                if (day != null && year != null && mi >= 0 && day in 1..30) return H(day, mi, year)
            } catch (_: Throwable) {}
            val adj = try { ctx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE).getInt("last_rtdb_adjustment", 0) } catch (_: Throwable) { 0 }
            return tabular(midnight(civil, adj))
        }

        /** ক্যালেন্ডারের সঠিক "চিহ্ন" (এখন অ্যাপের হোমে যে হিজরি তারিখ দেখায়) — বদলালে ক্যালেন্ডার নতুন করে আঁকতে হয় */
        fun signature(ctx: Context): String {
            val civil = midnight(Calendar.getInstance(), 0)
            val h = hijriAt(ctx, System.currentTimeMillis(), civil)
            return "${h.day}-${h.month}-${h.year}|${civil.get(Calendar.DAY_OF_YEAR)}"
        }
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * ctx.resources.displayMetrics.density

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text; textSize = size; setTextColor(color); typeface = if (bold) p.bold else p.reg
    }

    private class StarDrawable(private val col: Int) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        override fun draw(cv: Canvas) {
            paint.color = col
            val s = bounds.width() / 100f
            val pts = floatArrayOf(50f, 1f, 64f, 15f, 85f, 15f, 85f, 36f, 99f, 50f, 85f, 64f, 85f, 85f, 64f, 85f, 50f, 99f, 36f, 85f, 15f, 85f, 15f, 64f, 1f, 50f, 15f, 36f, 15f, 15f, 36f, 15f)
            val path = Path()
            var i = 0
            while (i < pts.size) { val x = bounds.left + pts[i] * s; val y = bounds.top + pts[i + 1] * s; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y); i += 2 }
            path.close(); cv.drawPath(path, paint)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    private fun dot(size: Int, color: Int) = View(ctx).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        layoutParams = LinearLayout.LayoutParams(size, size)
    }

    // ---------------------------------------------------------------- গঠন

    fun build(): View {
        val civil = midnight(Calendar.getInstance(), 0)
        // অ্যাপের হোমে এখন যে হিজরি তারিখ দেখায় (মাগরিবের পর পরের দিন) — ক্যালেন্ডারে ঠিক সেই দিনটাই চিহ্নিত হবে
        val shown = hijriAt(ctx, System.currentTimeMillis(), civil)
        val base = hijriAt(ctx, civil.timeInMillis + 60_000L, civil)       // একই দিনের মাগরিব-শিফট ছাড়া তারিখ
        val shift = if (shown.day == base.day && shown.month == base.month && shown.year == base.year) 0 else 1
        val now = midnight(civil, shift)      // দেখানো হিজরি দিনটির সাথে মেলানো ইংরেজি তারিখ
        val h0 = shown

        // হিজরি ↔ ফোনের সূত্রের পার্থক্য (দিন) — ওয়েবের nzHijriDelta
        var delta = 0
        for (d in -3..3) { val x = tabular(midnight(now, d)); if (x.day == h0.day && x.month == h0.month) { delta = d; break } }
        val lenProbe = tabular(midnight(now, 30 - h0.day + delta))
        val len = if (lenProbe.month == h0.month && lenProbe.day == 30) 30 else 29
        val first = midnight(now, 1 - h0.day)
        val lead = (((first.get(Calendar.DAY_OF_WEEK) - 1) + 1) % 7)      // শনিবার থেকে সপ্তাহ

        val evIn = HashMap<Int, Ev>(); EVENTS.forEach { if (it.m == h0.month) evIn[it.d] = it }

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surfHi, p.surf)).apply {
                cornerRadius = dpf(22f); setStroke(dp(1), p.line)
            }
        }

        // মাথা: মাসের নাম + সাল | ইঙ্গিত
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv(MONTHS[h0.month], 20f, p.gold, true).apply { setLineSpacing(0f, 1.1f) })
        titles.addView(tv("${Bn.digits(h0.year)} হিজরি", 12f, p.text3).apply { setPadding(0, dp(4), 0, 0) })
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val legend = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        legend.addView(dot(dp(7), p.primaryText))
        legend.addView(tv("আইয়ামে বিয", 11f, p.text3).apply { setPadding(dp(4), 0, dp(10), 0) })
        legend.addView(View(ctx).apply { background = StarDrawable(p.gold) }, LinearLayout.LayoutParams(dp(9), dp(9)))
        legend.addView(tv("বিশেষ দিন", 11f, p.text3).apply { setPadding(dp(4), 0, 0, 0) })
        head.addView(legend, LinearLayout.LayoutParams(-2, -2))
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        // গ্রিড
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val wdRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(4)) }
        WD.forEachIndexed { i, w ->
            wdRow.addView(tv(w, 11f, if (i == 6) p.gold else p.text3).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(0, -2, 1f))
        }
        grid.addView(wdRow, LinearLayout.LayoutParams(-1, -2))

        val cellW = (ctx.resources.displayMetrics.widthPixels - dp(32) - dp(32)) / 7
        val cellH = (cellW * 1.05f).toInt()
        var row: LinearLayout? = null
        var col = 0
        fun newRow() { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; grid.addView(row, LinearLayout.LayoutParams(-1, cellH).apply { topMargin = dp(2) }); col = 0 }
        newRow()
        for (i in 0 until lead) { row!!.addView(View(ctx), LinearLayout.LayoutParams(0, cellH, 1f)); col++ }
        for (d in 1..len) {
            if (col == 7) newRow()
            val g = midnight(first, d - 1)
            val isT = d == h0.day
            val white = d in 13..15
            val ev = evIn[d]
            val jsDow = g.get(Calendar.DAY_OF_WEEK) - 1
            val fri = jsDow == 5
            row!!.addView(cell(d, g, isT, d < h0.day, white, ev, fri, h0.month, jsDow), LinearLayout.LayoutParams(0, cellH, 1f))
            col++
        }
        while (col in 1..6) { row!!.addView(View(ctx), LinearLayout.LayoutParams(0, cellH, 1f)); col++ }
        card.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // আসন্ন বিশেষ দিন
        val ups = ArrayList<Up>()
        val seen = HashSet<String>()
        var seenWhite = false
        var k = 0
        while (k < 400 && ups.size < 12) {
            val x = tabular(midnight(now, k + delta)); val g = midnight(now, k)
            for (e in EVENTS) if (e.m == x.month && e.d == x.day && seen.add(e.t)) ups.add(Up(k, g, e.t, e.s, x.day, x.month))
            if (!seenWhite && x.day == 13 && k > 0) { seenWhite = true; ups.add(Up(k, g, "আইয়ামে বিয রোজা", "১৩, ১৪ ও ১৫ তারিখ — সুন্নাত রোজা", x.day, x.month)) }
            k++
        }
        ups.sortBy { it.k }

        card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(20) })
        card.addView(tv("আসন্ন বিশেষ দিন", 15f, p.text, true).apply { setPadding(0, dp(16), 0, dp(4)) })
        ups.take(4).forEachIndexed { i, u ->
            if (i > 0) card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)))
            card.addView(eventRow(u))
        }
        card.addView(tv("চাঁদ দেখার ওপর ভিত্তি করে তারিখ এক দিন আগে-পরে হতে পারে।", 11f, p.text3).apply { setPadding(0, dp(12), 0, 0) })
        return card
    }

    private fun cell(d: Int, g: Calendar, isToday: Boolean, past: Boolean, white: Boolean, ev: Ev?, fri: Boolean, monthIdx: Int, jsDow: Int): View {
        val box = android.widget.FrameLayout(ctx)
        val inner = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        if (isToday) inner.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply {
            cornerRadius = dpf(12f); setStroke(dp(1), p.goldLine)
        }
        val dayCol = if (isToday) p.onPrimary else if (fri) p.gold else p.text
        inner.addView(tv(Bn.digits(d), 15f, dayCol, true))
        inner.addView(tv(Bn.digits(g.get(Calendar.DAY_OF_MONTH)), 11f, if (isToday) p.onPrimary else p.text3).apply {
            setPadding(0, dp(2), 0, 0); if (isToday) alpha = .8f
        })
        if (past) inner.alpha = .45f
        box.addView(inner, android.widget.FrameLayout.LayoutParams(-1, -1).apply { if (isToday) { setMargins(dp(1), dp(1), dp(1), dp(1)) } })
        if (white) box.addView(dot(dp(4), p.primaryText), android.widget.FrameLayout.LayoutParams(dp(4), dp(4), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(3) })
        if (ev != null) box.addView(View(ctx).apply { background = StarDrawable(p.gold) },
            android.widget.FrameLayout.LayoutParams(dp(8), dp(8), Gravity.TOP or Gravity.END).apply { topMargin = dp(3); rightMargin = dp(3) })

        val gm = Bn.GREG_MONTHS[g.get(Calendar.MONTH)]
        val tip = "${Bn.digits(d)} ${MONTHS[monthIdx]} · ${Bn.digits(g.get(Calendar.DAY_OF_MONTH))} $gm, ${WD_FULL[jsDow]}" +
            (if (ev != null) " · ${ev.t}" else if (white) " · আইয়ামে বিয (সুন্নাত রোজা)" else "")
        box.contentDescription = tip
        box.setOnClickListener { Toast.makeText(ctx, tip, Toast.LENGTH_SHORT).show() }
        return box
    }

    private fun eventRow(u: Up): View {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        // আর্চ-আকৃতির তারিখ-বক্স
        val date = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6))
            val r = dpf(23f); val s = dpf(6f)
            background = GradientDrawable().apply { setCornerRadii(floatArrayOf(r, r, r, r, s, s, s, s)); setColor(Color.TRANSPARENT); setStroke(dp(1), p.goldLine) }
        }
        date.addView(tv(Bn.digits(u.g.get(Calendar.DAY_OF_MONTH)), 17f, p.gold, true))
        date.addView(tv(Bn.GREG_MONTHS[u.g.get(Calendar.MONTH)], 11f, p.text3).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(date, LinearLayout.LayoutParams(dp(54), -2).apply { rightMargin = dp(12) })

        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(tv(u.title, 15f, p.text, true))
        val jsDow = u.g.get(Calendar.DAY_OF_WEEK) - 1
        mid.addView(tv("${Bn.digits(u.day)} ${MONTHS[u.month]} · ${WD_FULL[jsDow]}" + (if (u.sub != null) " · ${u.sub}" else ""), 12f, p.text3).apply {
            setLineSpacing(0f, 1.25f); setPadding(0, dp(4), 0, 0)
        })
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))

        val soon = u.k <= 7
        val whenTxt = when (u.k) { 0 -> "আজ"; 1 -> "আগামীকাল"; else -> "আর ${Bn.digits(u.k)} দিন" }
        row.addView(tv(whenTxt, 11f, if (soon) p.gold else p.text2, soon).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(if (soon) p.goldSoft else p.surf2) }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        return row
    }
}
