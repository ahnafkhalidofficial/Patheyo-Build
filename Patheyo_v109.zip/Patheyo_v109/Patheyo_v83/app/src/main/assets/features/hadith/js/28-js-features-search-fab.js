/* ===== js/features/search-fab.js ===== */
(function (App) {
  "use strict";

  var fab = null;

  function init() {
    fab = document.getElementById('search-fab');
    if (!fab) return;

    // Scroll event to show/hide FAB
    window.addEventListener('scroll', function() {
      var offset = window.pageYOffset || document.documentElement.scrollTop;
      // Show FAB when scrolled down more than 300px, and only if we are in a book or chapter
      var isReader = (App.state.view === 'book' || App.state.view === 'chapter' || !App.els.chapterPanel.classList.contains('hidden'));
      
      if (isReader && offset > 300) {
        fab.classList.remove('hidden');
      } else {
        fab.classList.add('hidden');
      }
    }, { passive: true });

    // Click event to trigger search
    fab.addEventListener('click', function() {
      // 1. Go back to book view if we are in a chapter
      if (!App.els.bookPanel.classList.contains('hidden') === false) {
         // If chapter panel is visible, close it
         if (!App.els.chapterPanel.classList.contains('hidden')) {
            App.closeChapter();
         }
      }
      
      // 2. Ensure book panel is visible
      App.els.bookPanel.classList.remove('hidden');
      App.els.booksPanel.classList.add('hidden');
      App.els.bookmarksPanel.classList.add('hidden');
      App.els.chapterPanel.classList.add('hidden');
      App.state.view = 'book';
      
      // 3. Focus and show the search input
      var input = document.getElementById('search-input');
      if (input) {
        input.focus();
        // Trigger a small scroll to bring search wrap into view if needed
        document.getElementById('search-wrap').scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      
      fab.classList.add('hidden');
    });
  }

  // Initialize when App is ready
  if (document.readyState === 'complete') {
    init();
  } else {
    window.addEventListener('load', init);
  }

})(window.HadithApp = window.HadithApp || {});
