
(function(){
  var root = document.documentElement, el = document.getElementById('pts');
  if (!el) return;
  var PLAY_MS = 2000;   // স্প্ল্যাশের সব অ্যানিমেশন এর মধ্যে শেষ
  var OUT_MS  = 1000;   // তারপর হোমে ফেরার সময় (মোট ৩ সেকেন্ড)
  var FLY_MS  = 800;    // লোগো ওড়ার সময়
  var started = false, ended = false;
  var tag = document.getElementById('pts-tag-line');

  /* ট্যাগলাইন এক লাইনে ফিট */
  function fitTag(){
    if (!tag) return;
    tag.style.fontSize = '';
    var avail = window.innerWidth - 2 * 19.2 - 4;
    var w = tag.scrollWidth;
    var cur = parseFloat(getComputedStyle(tag).fontSize);
    if (w > avail) tag.style.fontSize = Math.floor(cur * avail / w) + 'px';
  }
  var flyEl = null;
  function land(){
    root.classList.remove('pts-flying');
    if (flyEl && flyEl.parentNode) flyEl.parentNode.removeChild(flyEl);
    flyEl = null;
  }
  function finish(){
    if (ended) return; ended = true;
    land();
    root.classList.remove('pts-reveal');
    window.removeEventListener('resize', fitTag);
    if (el.parentNode) el.parentNode.removeChild(el);
    ['pts-fonts', 'pts-css'].forEach(function(id){ var s = document.getElementById(id); if (s && s.parentNode) s.parentNode.removeChild(s); });
  }
  /* স্প্ল্যাশের লোগো → হেডারের লোগো: একটাই লোগো উড়ে গিয়ে বসে (হেডারের লোগো তখন লুকানো থাকে) */
  function flyLogo(){
    try {
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var src = el.querySelector('.pts-mark svg');
      var dst = document.querySelector('.app-header .brand-mark');
      if (reduce || !src || !dst || !src.animate) return;
      var s = src.getBoundingClientRect(), d = dst.getBoundingClientRect();   // হেডারের চূড়ান্ত জায়গা (ফেড-ইনের আগে মাপা)
      if (!s.width || !d.width) return;
      flyEl = document.createElement('div');
      flyEl.className = 'pts-fly';
      flyEl.setAttribute('aria-hidden', 'true');
      flyEl.style.left = s.left + 'px'; flyEl.style.top = s.top + 'px';
      flyEl.style.width = s.width + 'px'; flyEl.style.height = s.height + 'px';
      flyEl.appendChild(src.cloneNode(true));
      document.body.appendChild(flyEl);
      root.classList.add('pts-flying');
      el.classList.add('pts-flying');          // স্প্ল্যাশের নিজের লোগো + রিং লুকিয়ে যায়, ক্লোনটাই ওড়ে
      var k = d.width / s.width, dx = d.left - s.left, dy = d.top - s.top;
      var a = flyEl.animate([
        { transform: 'translate(0px,0px) scale(1)' },
        { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(' + k + ')' }
      ], { duration: FLY_MS, easing: 'cubic-bezier(.45,.05,.2,1)', fill: 'forwards' });
      a.onfinish = land;
    } catch (e) { land(); }
  }
  function exit(){
    if (ended) return;
    /* অ্যাপের ফন্ট এখনও লোড হচ্ছে (body লুকানো) থাকলে একটু অপেক্ষা — নইলে ফাঁকা পর্দা দেখা যেত */
    if (/(^|\s)fonts-pending(\s|$)/.test(root.className)) { setTimeout(exit, 40); return; }
    flyLogo();                            // আগে মাপ নেওয়া, তারপর হোম ফোটানো
    root.classList.add('pts-reveal');     // হোম একটু একটু করে ফুটে ওঠে
    el.classList.add('pts-out');          // স্প্ল্যাশ ধীরে মিলিয়ে যায়
    setTimeout(finish, OUT_MS + 60);
  }
  function start(){
    if (started) return; started = true;
    fitTag();
    el.classList.add('pts-play');
    setTimeout(exit, PLAY_MS);
  }

  window.addEventListener('resize', fitTag);
  setTimeout(start, 600);                 // ফন্ট দেরি করলেও ০.৬s-এর বেশি অপেক্ষা নয়
  try {
    var f = document.fonts;
    if (f && f.load) {
      var t1 = (el.querySelector('.pts-title') || {}).textContent || '';
      var t2 = (tag || {}).textContent || '';
      Promise.all([
        f.load('700 64px "PtsBenSen"', t1),
        f.load('400 19px "PtsBenSen"', t2),
        f.load('300 15px "PtsJakarta"', 'from')
      ]).then(start, start);
    } else start();
  } catch (e) { start(); }
})();
