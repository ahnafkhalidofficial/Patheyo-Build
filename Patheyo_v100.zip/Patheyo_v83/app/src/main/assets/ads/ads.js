/* ===== Patheyo বিজ্ঞাপন -- হোম স্লাইডার + সব পেজের নিচের ফিক্সড বিজ্ঞাপন =====
   কনফিগ: ads/ads-config.js (window.PT_ADS)। এই ফাইলের কোড বদলানোর দরকার নেই।
   - PTAds.mountFooter(doc): ফিচার পেজের (iframe) একদম নিচে ফিক্সড বিজ্ঞাপন বসায় -- শেল প্রতিটা ফিচারে এটা নিজে ডাকে, তাই নতুন ফিচারেও আপনাআপনি আসে।
   - লিংক সবসময় target="_blank" -- অ্যান্ড্রয়েড অ্যাপ (MainActivity.shouldOverrideUrlLoading) সেটা ফোনের ব্রাউজারে খোলে। */
(function () {
  var C = window.PT_ADS; if (!C) return;
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  function url(p) { try { return new URL(p, document.baseURI).href; } catch (e) { return p; } }
  var ARROW = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>';
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

  /* ---------- হোম স্লাইডার ---------- */
  function initCarousel() {
    var host = document.getElementById('ad-carousel'); if (!host || !C.carousel || !C.carousel.length) return;
    var n = C.carousel.length, cur = 0, timer = 0, paused = false, visible = true, idleT = 0;
    host.innerHTML = '<div class="ad-viewport" id="ad-viewport"><div class="ad-track">' + C.carousel.map(function (s, i) {
      return '<div class="ad-slide' + (i === 0 ? ' is-active' : '') + '"><img src="' + esc(url(s.img)) + '" alt="' + esc(s.alt || '') + '" draggable="false" ' + (i === 0 ? '' : 'loading="lazy" ') + 'width="1200" height="200">' +
        '<a class="ad-go" href="' + esc(s.link || C.site) + '" target="_blank" rel="noopener" aria-label="ওয়েবসাইটে যান" title="ওয়েবসাইটে যান">' + ARROW + '</a></div>';
    }).join('') + '</div></div><div class="ad-dots" role="tablist" aria-label="বিজ্ঞাপন">' + C.carousel.map(function (s, i) {
      return '<button class="ad-dot' + (i === 0 ? ' is-active' : '') + '" type="button" role="tab" aria-label="ছবি ' + (i + 1) + '"></button>';
    }).join('') + '</div>';
    var vp = host.querySelector('#ad-viewport'), slides = host.querySelectorAll('.ad-slide'), dots = host.querySelectorAll('.ad-dot');
    function mark(i) {
      if (i === cur && slides[i].classList.contains('is-active')) return;
      cur = i;
      for (var k = 0; k < n; k++) { slides[k].classList.toggle('is-active', k === i); dots[k].classList.toggle('is-active', k === i); }
    }
    function go(i, smooth) { vp.scrollTo({ left: i * vp.clientWidth, behavior: (smooth && !reduce) ? 'smooth' : 'auto' }); mark(i); }
    var raf = 0;
    vp.addEventListener('scroll', function () {            /* আঙুলে টানলে ডট নিজে বদলায় */
      if (raf) return; raf = requestAnimationFrame(function () { raf = 0; var w = vp.clientWidth || 1; mark(Math.max(0, Math.min(n - 1, Math.round(vp.scrollLeft / w)))); });
    }, { passive: true });
    dots.forEach(function (d, i) { d.addEventListener('click', function () { hold(); go(i, true); }); });
    function hold() { paused = true; clearTimeout(idleT); idleT = setTimeout(function () { paused = false; }, C.intervalMs || 5000); }   /* ইউজার ছুঁলে ৫ সেকেন্ড অটো-বদল থামে */
    ['touchstart', 'pointerdown', 'wheel'].forEach(function (ev) { vp.addEventListener(ev, hold, { passive: true }); });
    function tick() { if (paused || !visible || document.hidden) return; go((cur + 1) % n, true); }
    function start() { clearInterval(timer); timer = setInterval(tick, C.intervalMs || 5000); }
    if ('IntersectionObserver' in window) new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }, { threshold: 0.4 }).observe(host);
    window.addEventListener('resize', function () { vp.scrollLeft = cur * vp.clientWidth; });
    start();
  }

  /* ---------- নিচের ফিক্সড বিজ্ঞাপন ---------- */
  var FOOT_HTML = function () {
    var f = C.footer; if (!f) return '';
    return '<a class="pt-ad-foot" href="' + esc(f.link || C.site) + '" target="_blank" rel="noopener" aria-label="' + esc(f.alt || '') + '"><img src="' + esc(url(f.img)) + '" alt="' + esc(f.alt || '') + '" width="1200" height="200"></a>';
  };
  function initHomeFooter() {
    var h = document.getElementById('ad-footer-home'); if (h) h.innerHTML = FOOT_HTML().replace('class="pt-ad-foot"', 'class="pt-ad-foot in-home"');
  }
  var cssText = null;
  function mountFooter(doc) {
    try {
      if (!doc || !doc.body || doc.getElementById('pt-ad-foot-wrap')) return;
      var go = function () {
        if (cssText === null) return;
        var st = doc.createElement('style'); st.textContent = cssText + '\n#pt-ad-foot-wrap{display:block;width:100%;max-width:480px;margin:0 auto;padding:0 0 4px;box-sizing:border-box}#pt-ad-foot-wrap .pt-ad-foot{margin:22px 0 14px}';
        doc.head.appendChild(st);
        var w = doc.createElement('div'); w.id = 'pt-ad-foot-wrap'; w.innerHTML = FOOT_HTML();
        var root = doc.querySelector('.app') || doc.body;
        var cs = doc.defaultView.getComputedStyle(root);
        if (root === doc.body || (parseFloat(cs.paddingLeft) || 0) < 8) w.style.padding = '0 16px 4px';        /* a container without its own side padding (body, amol's .app) -> 16px, same as the other pages */
        root.appendChild(w);
      };
      if (cssText !== null) go(); else loadCss(go);
    } catch (e) {}
  }
  var cssWait = [];
  function loadCss(cb) {
    cssWait.push(cb); if (cssWait.length > 1) return;
    fetch(url('ads/ads.css')).then(function (r) { return r.text(); }).then(function (t) {
      cssText = t.split('/* নিচের ফিক্সড বিজ্ঞাপন')[1] ? '/* x */' + t.slice(t.indexOf('/* নিচের ফিক্সড বিজ্ঞাপন')) : t;
      cssWait.forEach(function (f) { f(); }); cssWait = [];
    }).catch(function () { cssText = ''; });
  }
  window.PTAds = { mountFooter: mountFooter };
  loadCss(function () {});
  function boot() { initCarousel(); initHomeFooter(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
