import re,sys,os,html
A='/tmp/claude-0/-home-claude/d9c2552f-5d71-5344-9783-aace0d3ed7ed/scratchpad/v83src/Patheyo_v83/app/src/main/assets'
idx=open(A+'/index.html',encoding='utf-8').read().split('\n')
defs=[l for l in idx if l.startswith('<svg width="0" height="0" style="position:absolute"') and 'gjG1_' in l][0]   # gradient defs used by tile icons
logo=re.search(r'<svg class="brand-logo-svg".*?</svg>','\n'.join(idx),re.S).group(0)
tiles=re.findall(r'<span class="module-tile-icon">(<svg.*?</svg>)</span>\s*<span class="module-tile-title[^>]*>([^<]*)</span>',open(A+'/index.html',encoding='utf-8').read(),re.S)
icon={t[1].strip():t[0] for t in tiles}
print(list(icon),file=sys.stderr)
FONT=A+'/fonts/Kothamala-Bold.ttf',A+'/fonts/Kothamala-Regular.ttf'
ICONCSS=open('icon.css',encoding='utf-8').read()
CSS='''
@font-face{font-family:K;src:url("file://%s");font-weight:700}
@font-face{font-family:K;src:url("file://%s");font-weight:400}
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1200px;height:200px;overflow:hidden}
body{font-family:K,"Noto Sans Bengali",sans-serif;color:#00205E;position:relative;
 background:linear-gradient(100deg,#F4F8FF 0%%,#E3EDFD 55%%,#CFE0FB 100%%)}
.pat{position:absolute;inset:0;opacity:.55;background-image:
 radial-gradient(circle at 1px 1px,rgba(35,95,254,.16) 1.2px,transparent 1.6px);background-size:22px 22px;
 -webkit-mask-image:linear-gradient(90deg,transparent 0%%,#000 60%%,#000 100%%);mask-image:linear-gradient(90deg,transparent 0%%,#000 60%%,#000 100%%)}
.orb{position:absolute;border-radius:50%%;filter:blur(2px)}
.o1{width:360px;height:360px;right:-90px;top:-170px;background:radial-gradient(circle,rgba(35,95,254,.28),rgba(35,95,254,0) 70%%)}
.star{position:absolute;right:-60px;top:-40px;width:300px;height:300px;opacity:.14;background:conic-gradient(from 0deg,#235FFE 0 10%%,transparent 10%% 25%%,#235FFE 25%% 35%%,transparent 35%% 50%%,#235FFE 50%% 60%%,transparent 60%% 75%%,#235FFE 75%% 85%%,transparent 85%%);border-radius:50%%;-webkit-mask:radial-gradient(circle,transparent 38%%,#000 39%%,#000 60%%,transparent 61%%);mask:radial-gradient(circle,transparent 38%%,#000 39%%,#000 60%%,transparent 61%%)}
.o2{width:260px;height:260px;left:300px;bottom:-170px;background:radial-gradient(circle,rgba(201,138,43,.22),rgba(201,138,43,0) 70%%)}
.arch{position:absolute;right:210px;top:-6px;width:150px;height:212px;opacity:.9}
.plate{position:absolute;left:34px;top:25px;width:150px;height:150px;border-radius:38px;display:grid;place-items:center;
 background:linear-gradient(150deg,#FFFFFF,#E4EEFF);box-shadow:0 14px 30px -12px rgba(0,32,94,.35),inset 0 0 0 2px rgba(35,95,254,.35)}
.plate svg{width:112px;height:112px;overflow:visible}
.plate.logo{border-radius:50%%;background:#fff}
.plate.logo svg{width:150px;height:150px;border-radius:50%%}
.txt{position:absolute;left:222px;top:0;bottom:0;width:640px;display:flex;flex-direction:column;justify-content:center;gap:8px}
.k{align-self:flex-start;font-size:19px;font-weight:700;color:#8A5A12;background:linear-gradient(135deg,#FFF3CF,#F4DDA0);border:1.5px solid rgba(201,138,43,.55);border-radius:999px;padding:2px 16px 3px}
h1{font-size:50px;line-height:1.12;font-weight:700;color:#00205E}
h1 em{font-style:normal;color:#235FFE}
p{font-size:25px;line-height:1.3;color:#3A4A73}
.chips{position:absolute;left:222px;bottom:20px;display:flex;gap:10px}
.chip{font-size:19px;font-weight:700;color:#00205E;background:rgba(255,255,255,.85);border:1.5px solid rgba(35,95,254,.35);border-radius:999px;padding:3px 16px}
.cta{overflow:hidden;position:absolute;right:48px;top:50%%;transform:translateY(-50%%);display:flex;align-items:center;gap:12px;font-size:27px;font-weight:700;color:#fff;
 background:linear-gradient(135deg,#235FFE,#00205E);border-radius:999px;padding:16px 30px;box-shadow:0 12px 24px -10px rgba(0,32,94,.6)}
.cta svg{width:26px;height:26px}
.sky{position:absolute;right:0;bottom:0;width:430px;height:64px;opacity:.9}
.rchips{position:absolute;right:44px;top:0;bottom:0;padding-bottom:44px;width:372px;display:flex;flex-wrap:wrap;align-content:center;justify-content:flex-end;gap:10px}
.rchip{font-size:21px;font-weight:700;color:#00205E;background:rgba(255,255,255,.9);border:1.5px solid rgba(35,95,254,.4);border-radius:999px;padding:5px 20px 6px;box-shadow:0 8px 16px -10px rgba(0,32,94,.5)}
.rchip.gold{color:#8A5A12;background:linear-gradient(135deg,#FFF3CF,#F4DDA0);border-color:rgba(201,138,43,.6)}
.url{font-size:21px;font-weight:700;color:#235FFE;letter-spacing:.4px}
'''%FONT+ICONCSS
CHEV='<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h13M13 6l6 6-6 6"/></svg>'
ARCH='<svg class="arch" viewBox="0 0 150 212" fill="none"><path d="M8 212V110C8 70 52 56 75 8C98 56 142 70 142 110V212" stroke="#235FFE" stroke-opacity=".25" stroke-width="3"/><path d="M26 212V114C26 82 60 70 75 34C90 70 124 82 124 114V212" stroke="#C98A2B" stroke-opacity=".35" stroke-width="2"/></svg>'
SKY='<svg class="sky" viewBox="0 0 430 64" preserveAspectRatio="none"><g fill="#235FFE" fill-opacity=".22"><path d="M150 64V30C150 8 215 8 215 30V64z"/><rect x="80" y="14" width="9" height="50"/><path d="M80 14L84.5 0L89 14z"/><rect x="341" y="14" width="9" height="50"/><path d="M341 14L345.5 0L350 14z"/><path d="M110 64V44C110 30 134 30 134 44V64z"/><path d="M296 64V44C296 30 320 30 320 44V64z"/></g></svg>'
def page(name,body):
    open(f'{name}.html','w',encoding='utf-8').write(f'<!doctype html><meta charset="utf-8"><style>{CSS}</style><body>{defs}<div class="pat"></div><div class="orb o1"></div><div class="star"></div>{body}</body>')
def std(name,kicker,title,sub,plate,chips=(),cta=None):
    ch=''.join(f'<span class="rchip{" gold" if c.startswith("*") else ""}">{c.lstrip("*")}</span>' for c in chips)
    body=f'<div class="module-tile-icon plate{" logo" if plate.startswith("<svg class=\"brand") else ""}">{plate}</div><div class="txt"><div class="k">{kicker}</div><h1>{title}</h1><p>{sub}</p></div>'
    if ch: body+=f'<div class="rchips">{ch}</div>'
    if cta: body+=f'{ARCH}<div class="cta">{cta}{CHEV}</div>'
    page(name,body)
std('ad1','নতুন অ্যাপ · পাথেয়','পাথেয় <em>বাই গুঞ্জরণ</em>','চিরস্থায়ী সফরের পরম সঙ্গী',logo,['নামাজ','কুরআন','হাদিস','কিবলা','তাসবিহ','উইজেট'])
std('ad2','নামাজের সময়সূচি','প্রতিটি ওয়াক্তের <em>সঠিক সময়</em>','আজানের রিমাইন্ডার ও নিষিদ্ধ সময়ের সতর্কতা সহ',icon['নামাজের সময়'],['ফজর','যোহর','আসর','মাগরিব','ইশা'])
std('ad3','কুরআন শরিফ','১১৪ সূরা, ৩০ পারা — <em>এক অ্যাপে</em>','তরজমা ও মুসহাফ পেজ সহ, যখন খুশি পড়ুন',icon['কুরআন শরিফ'],['সূরা','পারা','তরজমা','মুসহাফ','বুকমার্ক'])
std('ad4','হাদিস শরিফ','সিহাহ সিত্তার <em>৬ কিতাব</em>','কিতাব, অধ্যায় ও বুকমার্ক সহ সহজে পড়ুন',icon['হাদিস শরিফ'],['বুখারী','মুসলিম','তিরমিযী','আবু দাউদ','নাসাঈ','ইবনে মাজাহ'])
# ad5: four feature icons
def mini(n): return f'<div style="width:78px;height:78px;border-radius:22px;background:linear-gradient(150deg,#fff,#E4EEFF);display:grid;place-items:center;box-shadow:0 10px 20px -10px rgba(0,32,94,.4),inset 0 0 0 1.5px rgba(35,95,254,.3)"><div class="module-tile-icon" style="width:58px;height:58px">{icon[n]}</div></div>'
grid='<div style="display:grid;grid-template-columns:78px 78px;gap:12px;">'+''.join(mini(n) for n in ['আমলের রিপোর্ট','ডিজিটাল তাসবিহ','কিবলা কম্পাস','হোম স্ক্রীন উইজেট'])+'</div>'
grid=grid.replace('grid-template-columns:78px 78px;gap:12px;','grid-template-columns:78px 78px 78px 78px;gap:12px;')
std('ad5','আরও অনেক কিছু','আমল, তাসবিহ, কিবলা <em>ও উইজেট</em>','সামনে আসছে দোয়া ও আরও ফিচার, ইনশা আল্লাহ','<span></span>',['*দোয়া — শীঘ্রই আসছে'])
s=open('ad5.html',encoding='utf-8').read()
s=s.replace('<div class="module-tile-icon plate"><span></span></div>','<div style="position:absolute;left:30px;top:50px;width:400px;height:100px">'+grid.replace('grid-template-columns:78px 78px 78px 78px;gap:12px;','grid-template-columns:repeat(4,78px);gap:12px;')+'</div>')
s=s.replace('.txt{','.txt{').replace('class="txt"','class="txt" style="left:400px;width:560px"').replace('<div class="cta">','<div class="cta" style="right:40px">')
s=s.replace('h1{','h1{').replace('<h1>','<h1 style="font-size:44px">')
open('ad5.html','w',encoding='utf-8').write(s)
# footer ad (fixed)
body=f'{SKY}{ARCH}<div class="plate logo">{logo}</div><div class="txt"><div class="k">পাথেয় বাই গুঞ্জরণ</div><h1>আজই <em>ডাউনলোড</em> করুন</h1><p class="url">patheyobygunjoron.github.io</p></div><div class="cta" style="right:44px">অ্যাপ নিন{CHEV}</div>'
page('ad6',body)
