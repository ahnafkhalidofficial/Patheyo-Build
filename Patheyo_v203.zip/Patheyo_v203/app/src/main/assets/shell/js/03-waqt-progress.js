
/* current prayer: how much time is left (uses the same pill times as the strip above) */
(function () {
  var card = document.getElementById('waqt-progress');
  var pills = Array.prototype.slice.call(document.querySelectorAll('.waqt-pill[data-time]'));
  if (!card || pills.length < 5) return;
  var $ = function (id) { return document.getElementById(id); };
  var arch = $('wp-fill'), star = $('wp-star'), len = arch.getTotalLength();
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function toSec(t) { var a = t.split(':'); return (parseInt(a[0], 10) * 60 + parseInt(a[1], 10)) * 60; }
  function fmt(sec) {
    var m = Math.round(((sec % 86400) + 86400) % 86400 / 60) % 1440;
    var h = Math.floor(m / 60), mm = m % 60, ap = h >= 12 ? 'PM' : 'AM', h12 = h % 12 || 12;
    return (h12 < 10 ? '0' : '') + h12 + ':' + (mm < 10 ? '0' : '') + mm + ' ' + ap;
  }
  var names = ['ফজর', 'যোহর', 'আসর', 'মাগরিব', 'ইশা'];

  function leftText(rem) {
    if (rem < 60) return '১ মিনিটেরও কম';
    var total = Math.ceil(rem / 60), h = Math.floor(total / 60), m = total % 60;
    if (h && m) return bn(h) + ' ঘণ্টা ' + bn(m) + ' মিনিট';
    if (h) return bn(h) + ' ঘণ্টা';
    return bn(m) + ' মিনিট';
  }

  function nm(i) { return (i === 1 && window.WAQT && window.WAQT.dow === 5) ? 'জুম’আ' : names[i]; }
  function show(el, on) { if (el) { if (on) el.removeAttribute('hidden'); else el.setAttribute('hidden', ''); } }

  /* light sweep: a soft highlight runs from the very bottom of the arch up to the current tip, only over the part that is already filled */
  var sweep = $('wp-shine'), maskP = $('wp-mask-path'), sweepAnim = null, sweepPct = -1, sweepFirst = true, sweepPaused = false;
  window.__pfSweep = function (p) { sweepPaused = !!p; if (sweepAnim) { try { if (p) sweepAnim.pause(); else sweepAnim.play(); } catch (e) {} } };
  var calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  /* হালকা আলোর সুইপ ("হোম স্ক্রিনে উইজেট যুক্ত করুন" বাটনের শাইনের মতো নরম ব্যান্ড): মেহরাবের শুরু থেকে শুরু হয়ে সোনালি ডটে গিয়ে শেষ -- শুধু যতটুকু ভরা ততটুকুতেই */
  function sweepTo(pct) {
    if (!sweep || !sweep.animate) return;
    if (Math.abs(pct - sweepPct) < 0.25) return;
    sweepPct = pct;
    if (sweepAnim) { try { sweepAnim.cancel(); } catch (e) {} sweepAnim = null; }
    if (maskP) maskP.style.strokeDasharray = pct.toFixed(2) + ' 100';
    if (pct < 1.5 || calm) { sweep.style.opacity = 0; return; }
    var N = 22, frames = [], travel = 1000 + pct * 10, total = Math.max(3600, travel / 0.45), tEnd = travel / total, startAt = 1 - tEnd;
    for (var k = 0; k <= N; k++) {
      var f = k / N, d = len * pct / 100 * f, p0 = arch.getPointAtLength(d), p1 = arch.getPointAtLength(Math.min(len, d + 0.6)), p2 = arch.getPointAtLength(Math.max(0, d - 0.6));
      var ang = Math.atan2(p1.y - p2.y, p1.x - p2.x) * 180 / Math.PI;
      frames.push({ transform: 'translate(' + p0.x.toFixed(2) + 'px,' + p0.y.toFixed(2) + 'px) rotate(' + ang.toFixed(1) + 'deg)',
                    opacity: f < 0.1 ? f / 0.1 : (f > 0.88 ? Math.max(0, (1 - f) / 0.12) : 1),
                    offset: startAt + tEnd * f * 1 });
    }
    frames[0].offset = startAt; frames[N].offset = 1;
    frames.unshift({ transform: frames[0].transform, opacity: 0, offset: 0 });
    sweepAnim = sweep.animate(frames, { duration: total, iterations: Infinity, delay: sweepFirst ? 1300 : 0, easing: 'linear' });
    sweepFirst = false;
    if (sweepPaused) { try { sweepAnim.pause(); } catch (e) {} }
  }

  function update() {
    if (!window.WAQT || !window.WAQT.ready) return;
    var now = window.WAQT.nowSec();
    var st = window.WAQT.at(now);
    var start = st.start, end = st.end, pct = 0, state = 'running', tag = 'চলমান', l1 = 'শুরু', l2 = 'শেষ', cur = st.cur;

    if (st.kind === 'forbidden') {
      /* forbidden time: no prayer, the mihrab stays empty, only the side countdown runs */
      state = 'forbidden'; start = st.win.s; end = st.win.e;
      $('wp-fbtxt').textContent = 'নিষিদ্ধ সময় · ' + st.win.name;
      show($('wp-fbhead'), true);
      show($('wp-el'), true);
      $('wp-elt').textContent = leftText(now - start);
      $('wp-name').textContent = ''; $('wp-tag').textContent = '';
    } else {
      show($('wp-fbhead'), false);
      show($('wp-el'), false);
      if (st.kind === 'gap') {
        /* after the morning forbidden time: "যোহর/জুম’আ আসন্ন", the line stays empty */
        state = 'gap'; tag = 'আসন্ন'; l1 = 'সূর্যোদয়'; l2 = 'শুরু';
      } else {
        pct = Math.max(0, Math.min(100, (now - start) / (end - start) * 100));
      }
      $('wp-name').textContent = nm(cur);
      $('wp-tag').textContent = tag;
    }

    var pt = arch.getPointAtLength(len * pct / 100);
    card.setAttribute('data-state', state);
    $('wp-left').textContent = leftText(end - now);
    arch.style.strokeDasharray = pct.toFixed(2) + ' 100';
    arch.style.opacity = pct < 0.4 ? 0 : 1;
    sweepTo(pct);
    star.style.transform = 'translate(' + pt.x.toFixed(2) + 'px,' + pt.y.toFixed(2) + 'px)';
    $('wp-track').setAttribute('aria-valuenow', Math.round(pct));
    $('wp-l1').textContent = l1; $('wp-t1').textContent = fmt(start);
    $('wp-l2').textContent = l2; $('wp-t2').textContent = fmt(end);
  }
  window.__pfProgressUpdate = update;               /* হোমের ইঞ্জিন namaz-এর ডেটা পেলেই এটা চালায় */
  update();                                         /* v2: ইঞ্জিন আগে থেকেই তৈরি (অফলাইন হিসাব/ক্যাশ) থাকলে সাথে সাথে আঁকা — ১০ সেকেন্ড অপেক্ষা নয় */
  requestAnimationFrame(function () { requestAnimationFrame(function () { card.classList.add('is-ready'); }); });
})();
