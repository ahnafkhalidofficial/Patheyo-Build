
/* centre the logo letter optically inside its box (uses the real glyph bounds) */
(function () {
  function centre() {
    var box = document.querySelector('.brand-mark-letter');
    if (!box) return;
    var g = box.querySelector('.bm-glyph');
    try {
      g.style.transform = '';
      var cs = getComputedStyle(g);
      var c = document.createElement('canvas').getContext('2d');
      c.font = cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
      var m = c.measureText(g.textContent);
      var probe = document.createElement('i');
      probe.style.cssText = 'display:inline-block;width:0;height:0';
      g.appendChild(probe);
      var baseline = probe.getBoundingClientRect().bottom;
      g.removeChild(probe);
      var glyphMid = baseline - (m.actualBoundingBoxAscent - m.actualBoundingBoxDescent) / 2;
      var r = box.getBoundingClientRect();
      var d = (r.top + r.height / 2) - glyphMid;
      if (isFinite(d) && Math.abs(d) < 12) g.style.transform = 'translateY(' + d.toFixed(2) + 'px)';
    } catch (e) {}
  }
  centre();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(centre);
  window.addEventListener('load', centre);
})();
(function () {
  /* হোমের নামাজের সময় / নিষিদ্ধ সময় / আরবি-ইংরেজি-বাংলা তারিখ / ঘড়ি / শুভেচ্ছা — সব "নামাজের সময়" পেজ (namaz frame) থেকে আসে।
     এখানে নিজের কোনো API, তারিখ-এডজাস্টমেন্ট বা সময়ের হিসাব নেই; window.__homeNamazSnap() (কন্ট্রোলার) namaz-এর লাইভ ডেটা দেয়। */
  var pills = Array.prototype.slice.call(document.querySelectorAll('.waqt-pill[data-waqt]'));
  var card = document.getElementById('waqt-progress');
  if (!card || pills.length < 5) return;
  var BN = '০১২৩৪৫৬৭৮৯', DAYS = ['রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','শনিবার'];
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function toSec(t) { var a = String(t || '').split(':'), h = parseInt(a[0], 10), m = parseInt(a[1], 10); return (isNaN(h) || isNaN(m)) ? NaN : (h * 60 + m) * 60; }
  function to12(sec) { var m = Math.round(((sec % 86400) + 86400) % 86400 / 60) % 1440, h = Math.floor(m / 60); return { t: p2(h % 12 || 12) + ':' + p2(m % 60), ap: h >= 12 ? 'PM' : 'AM' }; }

  var snapAt = 0, snapClock = null;
  var W = window.WAQT = {
    ready: false, starts: [], sunrise: 0, wins: [], dow: new Date().getDay(),
    nowSec: function () {                     /* namaz-এর ঘড়ি (না পেলে ফোনের একই ঘড়ি) */
      if (snapClock !== null && Date.now() - snapAt < 3000) return snapClock;
      var d = new Date(); return d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds();
    },
    at: function (now) {
      var starts = W.starts, wins = W.wins, sunrise = W.sunrise, i, last = -1;
      for (i = 0; i < starts.length; i++) if (now >= starts[i]) last = i;
      for (i = 0; i < wins.length; i++) if (now >= wins[i].s && now < wins[i].e) return { kind: 'forbidden', win: wins[i], last: last };
      if (last < 0) return { kind: 'prayer', cur: 4, start: starts[4] - 86400, end: starts[0], last: last, night: true };
      if (last === 0) {
        if (now >= sunrise) return { kind: 'gap', cur: 1, start: sunrise, end: starts[1], last: last };
        return { kind: 'prayer', cur: 0, start: starts[0], end: sunrise, last: last };
      }
      if (last === 4) return { kind: 'prayer', cur: 4, start: starts[4], end: starts[0] + 86400, last: last };
      return { kind: 'prayer', cur: last, start: starts[last], end: starts[last + 1], last: last };
    }
  };

  /* namaz-এর সময় (HH:MM) + নিষিদ্ধ সময়ের মিনিট → ইঞ্জিন */
  function applyTimes(s) {
    var t = s && s.t; if (!t) return false;
    var st = [toSec(t.Fajr), toSec(t.Dhuhr), toSec(t.Asr), toSec(t.Maghrib), toSec(t.Isha)], sr = toSec(t.Sunrise), ss = toSec(t.Sunset || t.Maghrib);
    for (var i = 0; i < st.length; i++) if (isNaN(st[i])) return false;
    if (isNaN(sr) || isNaN(ss)) return false;
    var fb = s.fb || {}, a = (fb.sr == null ? 15 : fb.sr) * 60, b = (fb.noon == null ? 12 : fb.noon) * 60, c = (fb.sset == null ? 15 : fb.sset) * 60;
    W.starts = st; W.sunrise = sr;
    W.wins = [
      { key: 'sunrise', name: 'সূর্যোদয়', s: sr, e: sr + a },
      { key: 'noon', name: 'দুপুর', s: st[1] - b, e: st[1] },
      { key: 'sunset', name: 'সূর্যাস্ত', s: ss - c, e: ss }
    ];
    W.ready = true; return true;
  }

  /* পিলের সময় ও নাম */
  var pillKey = '';
  function paintPills() {
    var key = W.starts.join(',') + '|' + (W.dow === 5 ? 'f' : 'n'); if (key === pillKey) return; pillKey = key;
    pills.forEach(function (p, i) {
      var x = to12(W.starts[i]);
      p.setAttribute('data-time', p2(Math.floor(W.starts[i] / 3600) % 24) + ':' + p2(Math.floor(W.starts[i] / 60) % 60));
      var sp = p.querySelectorAll('.waqt-pill-time > span');
      if (sp[0]) sp[0].textContent = x.t; if (sp[1]) sp[1].textContent = x.ap;
      if (i === 1) { var nm = p.querySelector('.waqt-pill-name'); if (nm) nm.textContent = (W.dow === 5) ? 'জুম’আ' : 'যোহর'; }
    });
  }
  function updatePills() {
    var st = W.at(W.nowSec());
    var cur = st.kind === 'prayer' ? st.cur : -1;      /* নিষিদ্ধ সময় / অপেক্ষার ফাঁক: কোনো নামাজ সিলেক্ট নয় */
    var strip = pills[0].parentNode;
    /* v2: পাঁচটি ওয়াক্ত সমান চওড়া (চলমান ওয়াক্ত রঙে আলাদা) — তাই সময় বদলালে লেআউট নড়ে না */
    pills.forEach(function (p, idx) {
      var past = st.night ? false : (cur >= 0 ? idx < cur : idx <= st.last);
      p.classList.toggle('is-current', idx === cur);
      p.classList.toggle('is-past', past);
      p.classList.toggle('is-future', idx !== cur && !past && !(st.night && idx === 4));
      if (idx === cur) p.setAttribute('aria-current', 'true'); else p.removeAttribute('aria-current');
    });
  }

  /* ঘড়ি + শুভেচ্ছা (namaz-এর লাইভ ঘড়ি; ফ্রেম তৈরি না হওয়া পর্যন্ত ফোনের একই ঘড়ি) */
  var clockEls = Array.prototype.slice.call(document.querySelectorAll('.hero-clock .digit-pair')), merEl = document.querySelector('.hero-clock .meridiem');
  var gT = document.getElementById('hero-greet-time'), gD = document.getElementById('hero-greet-day');
  function setT(el, v) { if (el && el.__v !== v) { el.__v = v; el.textContent = v; } }
  function paintTop(s) {
    var d = new Date(), h = s ? s.h : d.getHours(), m = s ? s.m : d.getMinutes(), sec = s ? s.s : d.getSeconds(), dow = s ? s.dow : d.getDay();
    setT(clockEls[0], p2(h % 12 || 12)); setT(clockEls[1], p2(m)); setT(clockEls[2], p2(sec)); setT(merEl, h >= 12 ? 'PM' : 'AM');
    var g = (h >= 4 && h < 6) ? 'ভোর' : (h >= 6 && h < 12) ? 'সকাল' : (h >= 12 && h < 16) ? 'দুপুর' : (h >= 16 && h < 18) ? 'বিকাল' : (h >= 18 && h < 20) ? 'সন্ধ্যা' : 'রাত';
    setT(gT, 'শুভ ' + g); setT(gD, DAYS[dow]);
  }

  /* তিনটি তারিখ: আরবি (namaz-এর getFinalHijriDisplayString: API + ফায়ারবেস এডজাস্টমেন্ট + মাগরিবে পরের দিন), ইংরেজি, বাংলা */
  var chips = Array.prototype.slice.call(document.querySelectorAll('.chip .chip-value'));
  function fixDate(str) {
    if (!str) return '';
    var p = bn(str).trim().replace(/\s+/g, ' ').split(' ');
    if (p[0] && p[0].length === 1) p[0] = '০' + p[0];
    return p.join(' ');
  }
  function paintDates(s) {
    [s.hijri, s.greg, s.bangla].forEach(function (v, i) {
      var el = chips[i], t = fixDate(v); if (!el || !t || el.__last === t) return;
      el.__last = t; el.textContent = t;                 /* তারিখ-কার্ডের স্ক্রিপ্ট নিজে দিন/মাস/বছর ভাগ করে */
    });
  }

  /* শেষ জানা ডেটা (শুধু একই দিনের) — স্প্ল্যাশের পরে namaz frame তৈরি হওয়ার আগের মুহূর্তের জন্য */
  var CK = 'pf-home-namaz';
  function dayKey() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
  function saveCache(s) { try { localStorage.setItem(CK, JSON.stringify({ d: dayKey(), s: { t: s.t, fb: s.fb, hijri: s.hijri, greg: s.greg, bangla: s.bangla, dow: s.dow } })); } catch (e) {} }
  var firstPaint = false;
  /* v2: সময়ের উৎস — 'live' (নামাজ পেজ), 'cache' (আজকের সেভ করা), 'offline' (ফোনেই হিসাব, shared/prayer-calc.js)।
     হোম কখনো "--" দেখায় না: নামাজ পেজ তৈরি না হলে বা ইন্টারনেট/ক্যাশ না থাকলে নিজেই হিসাব করে নেয়। */
  W.src = '';
  try {
    var c = JSON.parse(localStorage.getItem(CK) || 'null');
    if (c && c.d === dayKey() && c.s && applyTimes(c.s)) { W.dow = c.s.dow; paintDates(c.s); firstPaint = true; W.src = 'cache'; }
  } catch (e) {}
  var offDay = '', offSnap = null;
  function offline(now) {                    /* দিনে একবার হিসাব (মিনিট বদলালে শুধু ঘড়ির অংশ) */
    if (!window.PtPrayer) return null;
    var dk = dayKey() + '|' + (localStorage.getItem('currentMadhab') || '') + (localStorage.getItem('waqtMinuteOffsets') || '') + (localStorage.getItem('prayerMethodId') || '') + (localStorage.getItem('userPrayerMethodId') || '');
    if (dk !== offDay || !offSnap) { try { offSnap = window.PtPrayer.snapshot(now); offDay = dk; } catch (e) { offSnap = null; } }
    if (!offSnap) return null;
    var o = {}; for (var k in offSnap) o[k] = offSnap[k];
    o.h = now.getHours(); o.m = now.getMinutes(); o.s = now.getSeconds(); o.dow = now.getDay();
    return o;
  }

  var lastKey = '', n = 0;
  function tick(force) {
    var s = window.__homeNamazSnap ? window.__homeNamazSnap() : null, changed = firstPaint; firstPaint = false;
    var live = !!(s && s.t);
    if (!live && W.src !== 'cache' && !(W.src === 'live' && W.ready)) {      /* নামাজ পেজের সময় নেই, আজকের ক্যাশও নেই → ফোনেই হিসাব */
      var o = offline(new Date());
      if (o) { if (s) { s.t = o.t; s.fb = s.fb || o.fb; s.hijri = s.hijri || o.hijri; s.greg = s.greg || o.greg; s.bangla = s.bangla || o.bangla; s.offline = true; s.place = o.place; } else s = o; }
    }
    if (s) { snapAt = Date.now(); snapClock = s.h * 3600 + s.m * 60 + s.s; W.dow = s.dow; }
    paintTop(s);
    if (s) {
      paintDates(s);
      if (s.t) {
        var key = JSON.stringify([s.t, s.fb, s.hijri]);
        if (key !== lastKey) { lastKey = key; if (applyTimes(s)) { changed = true; if (!s.offline) saveCache(s); } }
        var src = s.offline ? 'offline' : 'live';
        if (src !== W.src) { W.src = src; W.place = s.place || null; if (window.__homeSrcChanged) window.__homeSrcChanged(); }
      }
    }
    n++;
    if (W.ready && (changed || force === true || n % 10 === 0)) {
      paintPills(); updatePills();
      if (window.__pfProgressUpdate) window.__pfProgressUpdate();
      if (window.__homePillsUpdated) window.__homePillsUpdated();
    }
  }
  tick(true);
  setInterval(function () { if (!document.hidden) tick(); }, 1000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(true); });
})();
