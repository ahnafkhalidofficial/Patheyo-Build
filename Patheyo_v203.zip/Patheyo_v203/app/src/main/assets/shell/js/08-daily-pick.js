/* হোম: "আজকের পাঠ" — প্রতিদিন নতুন একটি আয়াত, হাদিস ও দোয়া।
   বাছাই হয় তারিখ ধরে (দিনের সংখ্যা % তালিকার দৈর্ঘ্য) — তাই ইন্টারনেট/সার্ভার লাগে না, সারা দিন একই থাকে, মাঝরাতে বদলে যায়।
   আয়াত ও হাদিস: shared/daily-picks.js,  দোয়া: features/dua/js/01-data.js (দোয়া ফিচারের নিজের ডেটা — আলাদা করে সাইজ বাড়ে না)।
   "কার্ড বানান ও শেয়ার" shared/share-card.js ব্যবহার করে (দোয়া/হাদিস/কুরআনে যেটা আছে, সেটাই)। */
(function () {
  'use strict';
  var BN = '০১২৩৪৫৬৭৮৯';
  var MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  var WD = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
  var TABS = ['ayah', 'hadith', 'dua'];
  var KEY = 'pt_daily_tab';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  var cur = (function () { var v = lsGet(KEY); return TABS.indexOf(v) > -1 ? v : 'ayah'; })();
  var shownDay = -1, item = null, copyT = 0;

  function dayNo() { var d = new Date(); return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000); }

  function pick(kind) {
    var n = dayNo(), P = window.PT_DAILY || {};
    if (kind === 'ayah') { var a = P.ayah || []; return a.length ? a[n % a.length] : null; }
    if (kind === 'hadith') { var h = P.hadith || []; return h.length ? h[(n + 5) % h.length] : null; }
    var D = (window.DUA_ITEMS || []).filter(function (x) { return x.ar && x.ar.length <= 150; });     /* কার্ডে ধরার মতো ছোট দোয়াগুলো */
    if (!D.length) return null;
    var it = D[(n + 3) % D.length];
    return { ar: it.ar, tr: it.tr, bn: it.bn, ref: it.ref, t: it.t, cat: it.cat };
  }

  function render() {
    var body = $('dp-body'); if (!body) return;
    shownDay = dayNo(); item = pick(cur);
    var d = new Date();
    $('dp-date').textContent = WD[d.getDay()] + ', ' + bn(d.getDate()) + ' ' + MONTHS[d.getMonth()];
    Array.prototype.forEach.call(document.querySelectorAll('#dp-tabs button'), function (b) { b.setAttribute('aria-selected', b.getAttribute('data-k') === cur ? 'true' : 'false'); });
    $('dp-thumb').style.transform = 'translateX(' + (TABS.indexOf(cur) * 100) + '%)';
    var has = !!item;
    $('dp-card').disabled = !has; $('dp-copy').disabled = !has;
    if (!item) { body.innerHTML = '<p class="dp-empty lang-bn">আজকের পাঠ লোড হচ্ছে…</p>'; return; }
    var title = cur === 'hadith' ? 'আজকের হাদিস' : item.t;
    var T = window.PtTopics, tid = T ? T.of({ kind: cur, title: item.t, bn: item.bn, cat: item.cat }) : '';
    body.innerHTML =
      '<div class="dp-panel dp-k-' + cur + '">' +
        (T ? '<div class="dp-tag lang-bn"><span class="dp-ti">' + T.svg(tid) + '</span><span class="dp-tt"><b>' + esc(T.label(tid)) + '</b><small>' + esc(title) + '</small></span></div>'
           : '<div class="dp-tag lang-bn"><i></i>' + esc(title) + '</div>') +
        '<div class="dp-ar" dir="rtl" lang="ar">' + esc(item.ar) + '</div>' +
        '<div class="dp-sep" aria-hidden="true"><b></b></div>' +
        (cur === 'dua' && item.tr ? '<div class="dp-tr lang-bn"><em>উচ্চারণ</em>' + esc(item.tr) + '</div>' : '') +
        '<div class="dp-bn lang-bn">' + esc(item.bn) + '</div>' +
        '<div class="dp-ref lang-bn"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 4h11a1.5 1.5 0 0 1 1.5 1.5V20L12 16.5 5.5 20V5.5A1.5 1.5 0 0 1 6 4z"/></svg><span>' + esc(item.ref) + '</span></div>' +
      '</div>';
    body.classList.remove('dp-in'); void body.offsetWidth; body.classList.add('dp-in');
  }

  function textOf() {
    var s = (cur === 'hadith' ? '' : item.t + '\n\n') + item.ar;
    if (cur === 'dua' && item.tr) s += '\n\nউচ্চারণ: ' + item.tr;
    s += '\n\nঅর্থ: ' + item.bn + '\n\n(' + item.ref + ')\n\n— পাথেয় বাই গুঞ্জরণ\npatheyobygunjoron.github.io';
    return s;
  }
  function doCard() {
    if (!item) return;
    if (!window.PtShareCard) { flash($('dp-card'), 'একটু পরে আবার চাপুন'); return; }
    window.PtShareCard.open({ kind: cur, cat: item.cat, title: cur === 'hadith' ? '' : item.t, ar: item.ar, tr: cur === 'dua' ? item.tr : '', bn: item.bn, ref: item.ref });
  }
  function flash(btn, text) {
    var l = btn.querySelector('.dp-lbl') || btn, old = l.getAttribute('data-l') || l.textContent; l.setAttribute('data-l', old);
    l.textContent = text; clearTimeout(copyT); copyT = setTimeout(function () { l.textContent = old; }, 1600);
  }
  function doCopy() {
    if (!item) return;
    var s = textOf(), btn = $('dp-copy');
    function ok() { flash(btn, 'কপি হয়েছে'); }
    function fb() {
      try { var ta = document.createElement('textarea'); ta.value = s; ta.style.cssText = 'position:fixed;left:-9999px;opacity:0'; document.body.appendChild(ta); ta.select(); var r = document.execCommand('copy'); ta.remove(); r ? ok() : flash(btn, 'কপি করা যায়নি'); } catch (e) { flash(btn, 'কপি করা যায়নি'); }
    }
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(s).then(ok, fb); return; } } catch (e) {}
    fb();
  }

  function init() {
    if (!$('dp-section')) return;
    $('dp-tabs').addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[data-k]') : null; if (!b) return;
      cur = b.getAttribute('data-k'); lsSet(KEY, cur); render();
    });
    $('dp-card').addEventListener('click', doCard);
    $('dp-copy').addEventListener('click', doCopy);
    document.addEventListener('visibilitychange', function () { if (!document.hidden && dayNo() !== shownDay) render(); });   /* রাত পেরিয়ে অ্যাপে ফিরলে নতুন দিনের পাঠ */
    render();
    if (!item) setTimeout(render, 800);        /* ডেটা-স্ক্রিপ্ট দেরিতে এলে আবার চেষ্টা */
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
