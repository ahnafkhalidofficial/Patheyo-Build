
/* popups + footer: one controller. Footer tabs open their page (নামাজ / কুরআন / হাদিস / আরও→সেটিংস), হোম returns home.
   The footer's existing selector follows whichever page is open.
   Motion: the page fades in; the clicked icon (its tilted plate + stroke) rises, straightens and lands on its spot in the page. Closing reverses it. */
(function () {
  var tabs = Array.prototype.slice.call(document.querySelectorAll('.bottom-nav .nav-item'));
  var tiles = Array.prototype.slice.call(document.querySelectorAll('.module-grid .module-tile'));
  var TAB_OF = { f0: 1, f1: 2, f2: 3, f3: 4, f4: 4, f5: 4, f6: 4, f7: 4, settings: 4, zakat: 4 };   /* ধাপ ১১: search — কোনো ট্যাব নয় */      /* page -> footer tab (features without their own tab sit under আরও) */
  var PAGE_OF_TAB = { 1: 'f0', 2: 'f1', 3: 'f2', 4: 'settings' };
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

  var els = { feature: document.getElementById('feature-overlay'), notif: document.getElementById('notif-overlay'), settings: document.getElementById('settings-overlay'), quran: document.getElementById('quran-overlay'), hadith: document.getElementById('hadith-overlay'), namaz: document.getElementById('namaz-overlay'), amol: document.getElementById('amol-overlay'), tasbih: document.getElementById('tasbih-overlay'), widget: document.getElementById('widget-overlay'), qibla: document.getElementById('qibla-overlay'), dua: document.getElementById('dua-overlay'), search: document.getElementById('search-overlay'), zakat: document.getElementById('zakat-overlay') };
  var backs = { feature: document.getElementById('feature-back'), notif: document.getElementById('notif-back'), settings: document.getElementById('settings-back'), search: document.getElementById('search-back'), zakat: document.getElementById('zakat-back') };
  /* ---- কুরআন পেজ: কুরআন অ্যাপ (#quran-src) একটা ফ্রেমে চলে; হোমের কুরআন আইকন উড়ে এসে ফ্রেমের হেডারের আইকনের জায়গায় বসে ---- */
  /* each embedded app (Quran f1, Hadith f2) lives in its own frame; its header .mark is where the home tile icon lands */
  function markDest(fr) {
    return {
      kind: 'mark',
      icon: function () { var s = tiles[fr.tile] && tiles[fr.tile].querySelector('.module-tile-icon svg'); return s ? s.outerHTML : ''; },
      get el() { try { return fr.ready ? fr.frame.contentWindow.document.querySelector('.app-header .mark') : null; } catch (e) { return null; } },
      prepare: function () {                   /* header may be scrolled away: bring it back (no animation) so the icon has a place to land */
        try {
          var w = fr.frame.contentWindow, h = w.document.querySelector('.app-header');
          if (fr.topScroll) { try { w.scrollTo({ top: 0, left: 0, behavior: 'instant' }); } catch (e) {} }
          if (!h || !h.classList.contains('hdr-hidden')) return;
          h.style.transition = 'none';
          if (w[fr.api] && w[fr.api].showHeader) w[fr.api].showHeader(); else h.classList.remove('hdr-hidden');
          void h.offsetWidth; h.style.transition = '';
        } catch (e) {}
      },
      visible: function () {                   /* a reader page may cover the header: then there is nothing to land on */
        try {
          var w = fr.frame.contentWindow, m = w.document.querySelector('.app-header .mark'); if (!m) return false;
          var r = m.getBoundingClientRect(); if (!r.width || !r.height) return false;
          var e = w.document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
          return !!e && m.contains(e);
        } catch (e) { return false; }
      }
    };
  }
  var qr = { key: 'f1', name: 'quran',  api: 'QuranApp',  srcId: 'quran-src',  title: 'কুরআন শরিফ', tile: 1, wait: 6000,  frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
  var hd = { key: 'f2', name: 'hadith', api: 'HadithApp', srcId: 'hadith-src', title: 'হাদিস শরিফ', tile: 2, wait: 15000, frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
  var nz = { key: 'f0', name: 'namaz',  api: '',          srcId: 'namaz-src',  title: 'নামাজের সময়', tile: 0, wait: 8000,  topScroll: true, frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
  var am = { key: 'f3', name: 'amol',   api: '',          srcId: 'amol-src',   title: 'আমলের রিপোর্ট', tile: 3, wait: 6000,  topScroll: true, frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
  qr.dest = markDest(qr); hd.dest = markDest(hd);   var tb = { key: 'f6', name: 'tasbih', api: '',          srcId: 'tasbih-src', title: 'ডিজিটাল তাসবিহ', tile: 6, wait: 6000,  topScroll: true, frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
nz.dest = markDest(nz); am.dest = markDest(am); tb.dest = markDest(tb);

  /* ---- হোম ← নামাজের সময় পেজ: namaz frame-এর লাইভ ডেটা (সময়, তারিখ, ঘড়ি, নিষিদ্ধ সময়ের মিনিট) ---- */
  var HOME_HELPER = '(' + function () {
    window.__homeSnap = function () {
      try {
        var n = new Date(), r = { h: n.getHours(), m: n.getMinutes(), s: n.getSeconds(), dow: n.getDay(), t: null };
        if (typeof globalTimings === 'undefined' || !globalTimings) return r;
        var g = globalTimings;
        r.t = { Fajr: g.Fajr, Sunrise: g.Sunrise, Dhuhr: g.Dhuhr, Asr: g.Asr, Maghrib: g.Maghrib, Isha: g.Isha, Sunset: g.Sunset || g.Maghrib };
        /* নিষিদ্ধ সময়ের মিনিট: namaz-এর processDashboardTimelineUpdates-এর কোড থেকেই পড়া (না পেলে ১৫/১২/১৫) */
        var fb = { sr: 15, noon: 12, sset: 15 };
        try {
          var src = String(processDashboardTimelineUpdates), a;
          if ((a = /tm\['Sunrise'\]\.getTime\(\)\s*\+\s*(\d+)\s*\*\s*60000/.exec(src))) fb.sr = +a[1];
          if ((a = /tm\['Dhuhr'\]\.getTime\(\)\s*-\s*(\d+)\s*\*\s*60000/.exec(src))) fb.noon = +a[1];
          if ((a = /tm\['Sunset'\]\.getTime\(\)\s*-\s*(\d+)\s*\*\s*60000/.exec(src))) fb.sset = +a[1];
        } catch (e1) {}
        r.fb = fb;
        r.hijri = getFinalHijriDisplayString(n);                       /* API + ফায়ারবেস এডজাস্টমেন্ট/ডিরেক্ট-ডেট + মাগরিবে পরের দিন */
        r.greg = n.getDate() + ' ' + gregorianMonthsBN[n.getMonth()] + ' ' + n.getFullYear();
        r.bangla = getBengaliCalendarCalculation(n, false);
        try { if (typeof nzSource !== 'undefined' && nzSource !== 'live') { r.offline = true; r.place = { name: (document.getElementById('top-location') || {}).textContent || '' }; } } catch (e2) {}   /* ধাপ ৩: নামাজ পেজ নিজেই অফলাইন হিসাবে চললে হোমেও সেটা দেখায় */
        return r;
      } catch (e) { return null; }
    };
  }.toString() + ')()';
  window.__homeNamazSnap = function () {
    try {
      var w = nz.frame && nz.frame.contentWindow;
      if (!w || !w.document || !w.document.body) return null;
      if (typeof w.__homeSnap !== 'function') { if (typeof w.processDashboardTimelineUpdates !== 'function') return null; w.eval(HOME_HELPER); }
      return w.__homeSnap();
    } catch (e) { return null; }
  };
  var wg = { key: 'f7', name: 'widget', api: '', srcId: 'widget-src', title: 'হোম স্ক্রীন উইজেট', tile: 7, wait: 10000, topScroll: true, frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
  wg.dest = markDest(wg);
  var qb = { key: 'f5', name: 'qibla', api: '', srcId: 'qibla-src', title: 'কিবলা কম্পাস', tile: 5, wait: 6000, topScroll: true, allow: "geolocation 'self'; accelerometer 'self'; gyroscope 'self'; magnetometer 'self'", frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
  qb.dest = markDest(qb);
  var du = { key: 'f4', name: 'dua', api: '', srcId: 'dua-src', title: 'দোয়া', tile: 4, wait: 6000, topScroll: true, frame: null, ready: false, waiting: [], depth: 0, timer: 0 };
  du.dest = markDest(du);
  var frames = [nz, qr, hd, am, tb, wg, qb, du];

  /* ---- থিম সিঙ্ক: হোম যেটায়, সব পেজ সেটায়; কোনো পেজ নিজে বদলালে শুধু সেটা; হোমে বদলালে সব আবার হোমের সাথে ---- */
  qr.themeKind = 'api'; hd.themeKind = 'api'; am.themeKind = 'state';
  nz.themeKind = 'var'; tb.themeKind = 'var'; wg.themeKind = 'var'; qb.themeKind = 'var'; du.themeKind = 'var';
  function homeTheme() { return document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark'; }
  function syncTheme(fr, t) {
    t = t || homeTheme();
    try {
      var w = fr.frame && fr.frame.contentWindow;
      if (!w || !w.document || !w.document.documentElement) return;
      if (fr.themeKind === 'api') { if (w[fr.api] && w[fr.api].setTheme) w[fr.api].setTheme(t); }
      else {
        try { w.eval((fr.themeKind === 'state' ? 'STATE.theme=' : 'theme=') + JSON.stringify(t) + ';applyTheme()'); }
        catch (e1) {                                     /* থিম ভ্যারিয়েবল ফাংশনের ভেতরে (যেমন তাসবিহ): অ্যাপের নিজের থিম-বাটনই চাপি, তাহলে ভেতরের অবস্থাও মিলে থাকে */
          if (w.document.documentElement.getAttribute('data-theme') !== t) { var b = w.document.getElementById('theme') || w.document.getElementById('themeBtn'); if (b) b.click(); }
        }
      }
      if (w.document.documentElement.getAttribute('data-theme') !== t) w.document.documentElement.setAttribute('data-theme', t);
    } catch (e) {}
  }
  function syncAllThemes(t) { frames.forEach(function (fr) { if (fr.ready) syncTheme(fr, t); }); }
  var lastHome = homeTheme();
  if (window.MutationObserver) {
    new MutationObserver(function () { var t = homeTheme(); if (t !== lastHome) { lastHome = t; syncAllThemes(t); applyNavTheme(); } })
      .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  }
  Array.prototype.forEach.call(document.querySelectorAll('[data-theme-choice]'), function (o) {
    o.addEventListener('click', function () { setTimeout(function () { lastHome = homeTheme(); syncAllThemes(lastHome); }, 0); });   /* হোমে একই থিম আবার চাপলেও সব পেজ হোমের সাথে মেলে */
  });
  function frameOfKey(key) { for (var i = 0; i < frames.length; i++) if (frames[i].key === key) return frames[i]; return null; }
  var dests = {
    feature: { el: document.getElementById('fo-icon'), kind: 'plate' },
    notif: { el: document.getElementById('notif-ico'), kind: 'btn' },
    settings: { el: document.getElementById('settings-ico'), kind: 'btn' },
    search: { el: document.getElementById('search-ico'), kind: 'btn' },        /* ধাপ ১১ */
    zakat: { el: document.getElementById('zakat-ico'), kind: 'btn' },
    quran: qr.dest,
    hadith: hd.dest,
    namaz: nz.dest,
    amol: am.dest,
    tasbih: tb.dest,
    widget: wg.dest,
    qibla: qb.dest,
    dua: du.dest
  };
  var cur = null, z = 50, flight = null;
  /* phone Back button: opening any page adds one history step; Back (popstate) closes the page like the ← button does */
  var pushed = false, skipPop = false;

  function nameOf(key) { return key === 'search' ? 'search' : key === 'zakat' ? 'zakat' : key === 'settings' ? 'settings' : key === 'notif' ? 'notif' : key === 'f1' ? 'quran' : key === 'f2' ? 'hadith' : key === 'f0' ? 'namaz' : key === 'f3' ? 'amol' : key === 'f6' ? 'tasbih' : key === 'f7' ? 'widget' : key === 'f5' ? 'qibla' : key === 'f4' ? 'dua' : 'feature'; }
  function elOf(key) { return els[nameOf(key)]; }
  function setActive(i) { tabs.forEach(function (t, n) { t.classList.toggle('is-active', n === i); }); }

  var FEATURE_SUB = { f4: 'দৈনন্দিন মাসনুন দোয়া' };       /* new placeholder features: add their one-line description here */
  function fillFeature(key) {
    var tile = tiles[parseInt(key.slice(1), 10)];
    var name = ((tile.querySelector('.module-tile-title') || {}).textContent || '').trim();
    var ico = tile.querySelector('.module-tile-icon');
    document.getElementById('feature-title').textContent = name;
    document.getElementById('feature-sub').textContent = FEATURE_SUB[key] || '';   /* one-line description under the title (same slot as .app-header .sub) */
    document.getElementById('fo-icon').innerHTML = ico ? ico.innerHTML : '';
    document.getElementById('fo-mark').innerHTML = ico ? ico.innerHTML : '';
    var note = document.getElementById('fo-note'); note.textContent = '';
    var b = document.createElement('b'); b.textContent = name; note.appendChild(b);
    note.appendChild(document.createTextNode(' শীঘ্রই যুক্ত করা হবে ইনশা আল্লাহ'));
  }

  /* ---- flying icon (Web Animations: transform on a lone element, so it stays smooth) ---- */
  function endFlight() {
    if (!flight) return;
    var f = flight; flight = null;
    try { f.anims.forEach(function (a) { a.cancel(); }); } catch (e) {}
    f.finish();
  }
  function rectOf(el) {               /* viewport rect; an element inside the Quran frame is shifted by the frame's own position */
    var r = el.getBoundingClientRect(), w = el.ownerDocument && el.ownerDocument.defaultView, fe = (w && w !== window) ? w.frameElement : null;
    if (!fe) return r;
    var f = fe.getBoundingClientRect();
    return { left: r.left + f.left, top: r.top + f.top, width: r.width, height: r.height };
  }
  function fly(dest, srcEl, srcKind, dir) {
    var mark = dest.kind === 'mark', hideSrc = srcKind !== 'tab', destEl;
    if (mark) { dest.prepare(); destEl = dest.el; if (!destEl || !dest.visible()) { if (dir === 'out' && hideSrc) srcEl.classList.remove('fly-hide'); return; } }
    else destEl = dest.el;
    var d = rectOf(destEl), s = srcEl.getBoundingClientRect();
    if (reduce || !destEl.animate || !d.width || !s.width) { if (dir === 'out' && hideSrc) srcEl.classList.remove('fly-hide'); return; }

    var tilt = srcKind === 'tile' ? 45 : 0;
    var size = srcKind === 'tile' ? srcEl.offsetWidth : s.width;
    var k = size / d.width;
    var dx = (s.left + s.width / 2) - (d.left + d.width / 2), dy = (s.top + s.height / 2) - (d.top + d.height / 2);
    var lift = (dest.kind === 'plate' || mark) ? Math.min(16, Math.abs(dy) * 0.12) : 0;

    var clone = document.createElement('div');
    clone.className = (dest.kind === 'plate' || mark) ? 'fly fly-plate module-tile-icon' : 'fly icon-btn';
    clone.setAttribute('aria-hidden', 'true');
    var bg = null;
    if (mark) {                                         /* the home icon + the header's own icon box (fades in as the icon lands, so nothing pops) */
      var cs = destEl.ownerDocument.defaultView.getComputedStyle(destEl), dsv = destEl.querySelector('svg'), dsr = dsv ? dsv.getBoundingClientRect() : null;
      bg = document.createElement('i');
      bg.style.cssText = 'position:absolute;left:0;top:0;right:0;bottom:0;z-index:0;box-sizing:border-box;pointer-events:none;opacity:0;'
        + 'border-radius:' + cs.borderRadius + ';background-image:' + cs.backgroundImage + ';background-color:' + cs.backgroundColor + ';'
        + 'border:' + cs.borderTopWidth + ' ' + cs.borderTopStyle + ' ' + cs.borderTopColor + ';box-shadow:' + cs.boxShadow;
      clone.appendChild(bg);
      clone.insertAdjacentHTML('beforeend', dest.icon());
      var csv = clone.querySelector('svg');
      if (csv) csv.style.cssText = 'position:relative;z-index:1;flex:none;width:' + (dsr && dsr.width ? dsr.width : 40) + 'px;height:' + (dsr && dsr.height ? dsr.height : 40) + 'px';
    } else clone.innerHTML = destEl.innerHTML;
    clone.style.left = d.left + 'px'; clone.style.top = d.top + 'px';
    clone.style.width = d.width + 'px'; clone.style.height = d.height + 'px';
    document.body.appendChild(clone);

    destEl.classList.add('fly-hide');
    if (dir === 'in' && hideSrc) srcEl.classList.add('fly-hide');

    function T(x, y, r, sc) { return 'translate(' + x + 'px,' + y + 'px) rotate(' + r + 'deg) scale(' + sc + ')'; }
    var A = { transform: T(dx, dy, tilt, k) };
    var M = { transform: T(dx / 2, dy / 2 - lift, tilt / 2, (1 + k) / 2), offset: 0.5 };
    var Z = { transform: T(0, 0, 0, 1) };
    if (dest.kind === 'plate') {                       /* soften plate -> plate: ring/glow + corner radius */
      var scs = getComputedStyle(srcEl), dcs = getComputedStyle(destEl);
      A.boxShadow = srcKind === 'tab' ? 'none' : scs.boxShadow;
      A.borderRadius = (srcKind === 'tile' ? 22 / k : parseFloat(dcs.borderRadius) || 30) + 'px';
      Z.boxShadow = dcs.boxShadow; Z.borderRadius = dcs.borderRadius;
    }
    var timing = dir === 'in'
      ? { duration: 440, easing: 'cubic-bezier(0.22, 0.8, 0.22, 1)', fill: 'both' }
      : { duration: 320, easing: 'cubic-bezier(0.4, 0, 0.2, 1)', fill: 'both' };
    var frames = dir === 'in' ? [A, M, Z] : [Z, M, A];
    var anims = [clone.animate(frames, timing)];
    var svg = clone.querySelector('svg');
    if (tilt && svg) {                                  /* counter-rotate so the picture itself never tilts */
      /* the picture inside the plate must also match the tile's real picture size at the tile end, otherwise it
         "grows" the moment the real icon takes over (page copy is 84px in a 104px plate, tile copy is 66px in 70px) */
      var sk = 1, realSvg = srcEl.querySelector('svg');
      if (realSvg) {
        var rw = parseFloat(getComputedStyle(realSvg).width), cw = parseFloat(getComputedStyle(svg).width);
        if (rw > 0 && cw > 0 && k > 0) sk = rw / (cw * k);
      }
      var r0 = { transform: 'rotate(' + -tilt + 'deg) scale(' + sk + ')' }, r1 = { transform: 'rotate(0deg) scale(1)' };
      anims.push(svg.animate(dir === 'in' ? [r0, r1] : [r1, r0], timing));
    }
    if (bg) anims.push(bg.animate(dir === 'in' ? [{ opacity: 0 }, { opacity: 0, offset: 0.55 }, { opacity: 1 }] : [{ opacity: 1 }, { opacity: 0, offset: 0.45 }, { opacity: 0 }], timing));
    var over = false;
    function finish() {
      if (over) return; over = true;
      clone.remove(); destEl.classList.remove('fly-hide');
      if (dir === 'out' && hideSrc) srcEl.classList.remove('fly-hide');
    }
    flight = { anims: anims, finish: finish };
    anims[0].onfinish = function () { if (flight && flight.finish === finish) flight = null; finish(); };
  }

  function quietClose(c) {          /* hide an overlay that is already covered, without animating */
    var el = c.el;
    el.classList.add('no-anim'); el.classList.remove('is-open');
    el.setAttribute('aria-hidden', 'true'); el.setAttribute('inert', '');
    if (c.srcKind !== 'tab') c.src.classList.remove('fly-hide');
    requestAnimationFrame(function () { requestAnimationFrame(function () { el.classList.remove('no-anim'); }); });
  }

  function open(key, src, srcKind, focusEl) {
    endFlight();
    noteUse(key);
    try { if (window.PT && PT.sheet && PT.sheet.isOpen()) PT.sheet.close(); } catch (e) {}
    if (cur && cur.key === key) return;
    navShowNow();                                  /* a page (re)opens with its footer in place; the page then decides again (frame.chromeSync below) */
    var el = elOf(key), prev = cur, nm = nameOf(key);
    if (nm === 'feature') fillFeature(key);
    if (key === 'notif' && window.__renderNotif) window.__renderNotif();

    if (prev && prev.el === el) {                  /* feature -> feature: swap content with a soft fade */
      if (prev.srcKind !== 'tab') prev.src.classList.remove('fly-hide');
      el.classList.remove('fo-swap'); void el.offsetWidth; el.classList.add('fo-swap');
      cur = { key: key, el: el, src: src, srcKind: srcKind, focusEl: focusEl, dest: dests[nm] };
    } else {
      el.style.zIndex = ++z;
      el.removeAttribute('inert'); el.setAttribute('aria-hidden', 'false');
      el.classList.add('is-open');
      cur = { key: key, el: el, src: src, srcKind: srcKind, focusEl: focusEl, dest: dests[nm] };
      { var ofr = frameOfKey(key); if (ofr) frFit(ofr); }
      fly(dests[nm], src, srcKind, 'in');
      if (!pushed) { try { history.pushState({ pf: 1 }, ''); pushed = true; } catch (e) {} }
      if (prev) setTimeout(function () { if (cur && cur.el !== prev.el) quietClose(prev); }, 320);
      setTimeout(function () { if (cur && cur.el === el && backs[nm]) backs[nm].focus({ preventScroll: true }); }, 140);
    }
    setActive(TAB_OF[key] === undefined ? -1 : TAB_OF[key]);
    { var sfr = frameOfKey(key); if (sfr && sfr.chromeSync) sfr.chromeSync(); }
    applyNavTheme();
  }

  function home(fromPop) {
    endFlight();
    if (!cur) { setActive(0); return; }
    var c = cur; cur = null;
    navShowNow();                                  /* footer must be in place before the closing icon flies to it */
    applyNavTheme();                               /* ...and in Home's own colours */
    if (pushed) {
      pushed = false;
      if (fromPop !== true) {                      /* closed with ← / footer / Esc: remove our history step too */
        skipPop = true; setTimeout(function () { skipPop = false; }, 700);
        var back = 1; frames.forEach(function (f) { back += f.depth; f.depth = 0; });       /* steps the Quran app added on top of ours go with it */
        try { if (back > 1) history.go(-back); else history.back(); } catch (e) { skipPop = false; }
      }
    }
    c.el.classList.remove('is-open'); c.el.setAttribute('aria-hidden', 'true'); c.el.setAttribute('inert', '');
    setActive(0);
    fly(c.dest, c.src, c.srcKind, 'out');
    setTimeout(function () { if (!cur) z = 50; }, 450);
    try { c.focusEl.focus({ preventScroll: true }); } catch (e) {}
  }

  /* ---- Quran frame: built once (after the splash, or at the first touch), then it just stays there ---- */
  function frFit(fr) {                                  /* v137: the frame is full height (the footer's glass blurs the page under it); the page keeps its content clear of the footer via two CSS variables */
    var nav = document.querySelector('.bottom-nav'), h = nav ? Math.round(nav.getBoundingClientRect().height) : 0;
    if (!h) return;
    var away = nav.classList.contains('nav-away');
    els[fr.name].style.setProperty('--qr-bottom', (away ? 0 : h) + 'px');
    try {
      var de = fr.frame && fr.frame.contentDocument && fr.frame.contentDocument.documentElement;
      if (de) {
        /* --pt-nav-h  = footer height, always (bottom spacer: constant, so the page never jumps when the footer slides away/back)
           --pt-nav-fix = footer height while the footer is visible, 0 while it is away (floating buttons / sheets follow it) */
        if (de.style.getPropertyValue('--pt-nav-h') !== h + 'px') de.style.setProperty('--pt-nav-h', h + 'px');
        var fx = (away ? 0 : h) + 'px';
        if (de.style.getPropertyValue('--pt-nav-fix') !== fx) de.style.setProperty('--pt-nav-fix', fx);
      }
    } catch (e) {}
  }
  window.addEventListener('resize', function () { frames.forEach(function (fr) { if (fr.frame) frFit(fr); }); });

  /* ---- footer away / back (v84) ----
     The footer is part of the shell, the page (Quran / Hadith) is in a frame -- so the page tells the shell when to take the footer away.
     Away  = a reader is open and its header has scrolled away (scroll down), or the Mushaf is full screen.
     Back  = scroll up, or the reader is closed. While the footer is away the frame grows to the screen's bottom edge, so no empty strip is left. */
  function setChromeAway(fr, away) {
    var nav = document.querySelector('.bottom-nav'); if (!nav) return;
    if (away && !(cur && frameOfKey(cur.key) === fr)) away = false;       /* only the page that is on screen may take the footer away */
    fr.away = !!away;
    var any = frames.some(function (f) { return f.away; });
    if (any === nav.classList.contains('nav-away')) return;
    nav.classList.toggle('nav-away', any);
    frames.forEach(function (f) { if (f.frame) frFit(f); });
  }
  function navShowNow() {                               /* instant (no slide): used when a page opens/closes, so icons fly to a footer that is really there */
    var nav = document.querySelector('.bottom-nav'); if (!nav) return;
    frames.forEach(function (f) { f.away = false; });
    if (!nav.classList.contains('nav-away')) return;
    nav.classList.add('nav-snap'); nav.classList.remove('nav-away');
    frames.forEach(function (f) { if (f.frame) frFit(f); });
    void nav.offsetWidth;
    setTimeout(function () { nav.classList.remove('nav-snap'); }, 60);
  }

  /* ---- footer colour follows the OPEN page's theme (v88) ----
     Home's footer styles hang on <html data-theme>. A page may have the other theme (e.g. Home dark, Quran light): then the footer gets
     .nav-as-light / .nav-as-dark + data-theme (see css/10-shell.css) so header and footer are always the same colour. sepia is a page-only theme.
     No page open (Home, Settings, Notifications) -> no class -> the footer is simply Home's. <html data-theme> itself is never touched. */
  /* v139: স্ট্যাটাস বার/নেভিগেশন বারের আইকনের রং — স্ক্রিনের ওপরে এখন যে থিম দেখা যাচ্ছে (খোলা পেজের, না থাকলে হোমের) তার সাথে মেলানো।
     লাইট/সেপিয়া -> গাঢ় আইকন, ডার্ক -> সাদা আইকন। ফোনের সিস্টেম থিম যাই হোক। শুধু বদলালেই নেটিভকে জানানো হয়। */
  var lastBarLight = null;
  function reportSystemBars(theme) {
    var light = theme === 'light' || theme === 'sepia';
    if (light === lastBarLight) return;
    lastBarLight = light;
    try { if (window.PatheyoSystemBars && window.PatheyoSystemBars.setLightTheme) window.PatheyoSystemBars.setLightTheme(light); } catch (e) { lastBarLight = null; }
  }
  function applyNavTheme() {
    var nav = document.querySelector('.bottom-nav'); if (!nav) return;
    var fr = cur ? frameOfKey(cur.key) : null, th = null;
    if (fr && fr.frame) { try { th = fr.frame.contentDocument.documentElement.getAttribute('data-theme'); } catch (e) {} }
    reportSystemBars(fr && fr.frame && (th === 'light' || th === 'dark' || th === 'sepia') ? th : homeTheme());
    var want = th === 'sepia' ? 'nav-as-sepia' : (th === 'light' || th === 'dark') && th !== homeTheme() ? 'nav-as-' + th : '';
    ['nav-as-light', 'nav-as-dark', 'nav-as-sepia'].forEach(function (c) { nav.classList.toggle(c, c === want); });
    /* v2: ডিজাইন-সিস্টেমের টোকেন data-theme দেখে রং দেয় — তাই ফুটারে খোলা পেজের থিম বসালেই হুবহু সেই থিমের ফুটার */
    var navTh = (th === 'light' || th === 'dark') ? th : homeTheme();
    if (nav.getAttribute('data-theme') !== navTh) nav.setAttribute('data-theme', navTh);
    /* The footer is translucent glass and the strip behind it is the page overlay's own background (Home's colour) -- not the page frame.
       Same glass over a different backdrop looks like a different colour, so while a page is open its overlay takes the PAGE's background. */
    var bg = '';
    if (fr && fr.frame && (th === 'dark' || th === 'light' || th === 'sepia')) { try { var d = fr.frame.contentDocument; bg = fr.frame.contentWindow.getComputedStyle(d.body).backgroundColor || ''; } catch (e) {} }
    frames.forEach(function (f) {
      var o = els[f.name]; if (!o) return;
      if (f === fr && bg) { if (f.ovBg !== bg) { o.style.setProperty('background', bg, 'important'); f.ovBg = bg; } }
      else if (f.ovBg) { f.ovBg = ''; setTimeout(function () { if (!(cur && frameOfKey(cur.key) === f)) o.style.removeProperty('background'); }, 450); }   /* after it has faded out */
    });
  }
  function frFlush(fr) { var w = fr.waiting; fr.waiting = []; w.forEach(function (fn) { try { fn(); } catch (e) {} }); }
  /* স্ট্যাটাস বারের উচ্চতা (v93)।
     অনেক ফোনে WebView env(safe-area-inset-top) দেয় না (০ আসে), তখন হেডারের লোগো/নাম ঘড়ি-ব্যাটারি বারে লেগে যায়।
     তাই অ্যাপের নেটিভ অংশ (MainActivity.kt) আসল উচ্চতা window.setNativeSafeTop(px) দিয়ে পাঠায়; আমরা env আর নেটিভ -- দুটোর বড়টা নিই।
     নেটিভ মান ৩ সেকেন্ডেও না এলে (WebView-র ভেতরে কিন্তু বার্তা আসেনি) ২৪px ধরা হয়, যাতে কোনো ফোনেই লেগে না যায়। */
  var nativeTop = -1, safeCache = -1, lateFallback = false;
  setTimeout(function () { lateFallback = true; if (nativeTop < 0) { safeCache = -1; safeTopPx(); } }, 3000);   /* native value never came -> safe default */
  function envTopPx() {
    var p = document.createElement('div');
    p.style.cssText = 'position:fixed;top:0;left:0;height:0;visibility:hidden;padding-top:env(safe-area-inset-top,0px)';
    document.body.appendChild(p);
    var v = parseFloat(getComputedStyle(p).paddingTop) || 0;
    document.body.removeChild(p);
    return v;
  }
  function safeTopPx() {
    if (safeCache >= 0) return safeCache;
    var e = envTopPx(), n = nativeTop;
    if (n < 0) n = !lateFallback ? 0 : /; wv\)|Version\/[\d.]+ Chrome\/[\d.]+ Mobile/.test(navigator.userAgent) ? 24 : 0;
    safeCache = Math.round(Math.max(e, n));
    try { document.documentElement.style.setProperty('--safe-top', safeCache + 'px'); } catch (x) {}
    return safeCache;
  }
  window.setNativeSafeTop = function (px) { nativeTop = Math.max(0, +px || 0); safeCache = -1; safeTopPx(); };
  window.addEventListener('resize', function () { safeCache = -1; safeTopPx(); });
  window.addEventListener('orientationchange', function () { safeCache = -1; });
  setTimeout(safeTopPx, 0);
  reportSystemBars(homeTheme());                       /* v139: শুরুতেই হোমের থিম অনুযায়ী স্ট্যাটাস বারের আইকন */
  /* হেডারের ব্যাকগ্রাউন্ড = ফুটারের রং (v85)।
     হোমে প্রতিটা থিমে হেডার ও ফুটারের গ্লাস হুবহু এক (02-app.css: ".app-header, .bottom-nav { background: rgba(0,24,70,.68) }" আর light-এ সাদা গ্রেডিয়েন্ট)।
     ফিচার পেজে সেটা বসে ফিচারের **নিজের** থিম দেখে -- হোমের বর্তমান থিম দেখে নয়। নইলে হোম ডার্ক + ফিচার লাইট (বা উল্টো) হলে হেডারের রং ও লেখার রং বেমানান হয়।
     sepia (হোমে নেই): ফিচারের নিজের গরম রঙের গ্লাসই থাকে। */
  var GLASS = {                                      /* v2: ডিজাইন সিস্টেমের --pt-glass (tokens.json) — ফুটারের গ্লাসের হুবহু */
    /* ধাপ ১৩: হেডার আরেকটু ঘন (০.৯২) — নিচ দিয়ে সরে যাওয়া লেখা হেডারের ভেতরে পড়ার মতো দেখা যেত (লেখার ওপর লেখা মনে হতো) */
    dark:  { color: 'rgba(26, 35, 51, 0.92)', image: 'none', filter: 'blur(20px) saturate(1.3)' },
    light: { color: 'rgba(255, 255, 255, 0.92)', image: 'none', filter: 'blur(20px) saturate(1.3)' }
  };
  /* হেডারের নিচের আলোর রেখা -- হোমের .app-header::after-এর চূড়ান্ত রূপ (মাঝে উজ্জ্বল, দুই পাশে মিলিয়ে যায়)।
     ফ্রেমের ডিফল্ট থিম light, তাই light = নীল, dark = সাদা, sepia = বাদামি। শুধু কুরআন ও হাদিস পেজে (v84)। */
  var GLOW_LINE = '.app-header{border-bottom-color:transparent !important;}' +      /* v2: আলোর রেখার জায়গায় ডিজাইন সিস্টেমের সরু রেখা (--pt-line) */
      '.app-header::after{content:"";position:absolute;left:0;right:0;bottom:0;height:1px;pointer-events:none;background:rgba(17,24,39,.09);}' +
      'html[data-theme="dark"] .app-header::after{background:rgba(255,255,255,.08);}' +
      'html[data-theme="sepia"] .app-header::after{background:rgba(92,66,30,.14);}';
  /* ===== স্ট্যান্ডার্ড হেডার (v89) =====
     সব ফিচার পেজের (এখনকার ও ভবিষ্যতের) হেডার একই: ডানে-বামে পুরো প্রস্থ, ওপরে স্টিকি, হোমের গ্লাস, নিচে একই আলোর রেখা, একই মাপ।
     ফিচার শুধু নিজের নাম/সাবটাইটেল/আইকন/টুল-বোতাম দেয়; মাপ ও স্টাইল এখান থেকেই বসে। নতুন ফিচারে আলাদা কিছু করতে হয় না --
     শুধু <header class="app-header"> ভেতরে .logo(.mark + h1) ও .tools(.tb) থাকলেই হলো (দেখুন docs/NEW_FEATURE_TEMPLATE.md)। */
  var STD_HEADER = 'html .app-header{position:sticky !important;top:0 !important;z-index:50 !important;box-sizing:border-box !important;' +
      'display:flex !important;align-items:center !important;justify-content:space-between !important;gap:10px !important;' +
      'width:auto !important;max-width:none !important;margin:0 calc(50% - 50vw) 12px !important;' +
      'padding-left:16px !important;padding-right:16px !important;padding-bottom:12px !important;border-radius:0 !important;border-top:0 !important;border-left:0 !important;border-right:0 !important;' +
      'border-bottom:1px solid transparent;box-shadow:none !important;}' +
    'html .app-header .header-top{display:flex !important;align-items:center !important;justify-content:space-between !important;gap:10px !important;width:100% !important;min-width:0 !important;}' +
    'html .app-header .logo{display:flex !important;align-items:flex-end !important;gap:12px !important;min-width:0 !important;height:54px !important;}' +
    'html .app-header .mark{width:54px !important;height:54px !important;flex:0 0 54px !important;}' +
    'html .app-header h1{font-size:20px !important;font-weight:700 !important;line-height:23px !important;margin:0 !important;font-family:var(--pt-ui) !important;letter-spacing:normal !important;}' +
    /* ধাপ ১৩: শিরোনাম কখনো দুই লাইনে ভাঙবে না; ছোট ফোনে (<৩৮০px) লম্বা নামের ঐচ্ছিক অংশ (.h1-long) বাদ — যেমন "ডিজিটাল তাসবিহ" → "তাসবিহ" */
    'html .app-header h1{white-space:nowrap !important;overflow:hidden !important;text-overflow:ellipsis !important;}html .app-header .ttl{min-width:0 !important;}' +
    '@media (max-width:379px){html .app-header .h1-long{display:none !important;}}' +
    'html .app-header h1{color:#111827 !important;}html[data-theme="dark"] .app-header h1{color:#F1F4F9 !important;}html[data-theme="sepia"] .app-header h1{color:#3f331e !important;}' +      /* same title colour on every page */
    'html .app-header .sub{font-size:13px !important;font-weight:400 !important;font-family:var(--pt-ui) !important;letter-spacing:normal !important;line-height:18.2px !important;margin:3px 0 0 !important;opacity:1 !important;white-space:nowrap !important;overflow:hidden !important;text-overflow:ellipsis !important;}' +
    'html .app-header .logo>div:not(.mark){min-width:0 !important;overflow:hidden !important;}' +
    'html .app-header .sub{color:#626C80 !important;}html[data-theme="dark"] .app-header .sub{color:#8A95AD !important;}html[data-theme="sepia"] .app-header .sub{color:#705E3C !important;}' +      /* same subtitle colour on every page */
    'html .app-header .tools{display:flex !important;align-items:center !important;gap:8px !important;flex:0 0 auto !important;}' +
    'html .app-header .tb{width:44px !important;height:44px !important;border-radius:14px !important;}' +
    /* অক্ষরের কিনারা (ন-এর বাঁ, ি/ী-কারের ডান, নিচের ু/ূ) যেন বক্স কেটে না দেয়: বক্স চারদিকে একটু বড়, ভেতরের লেখার জায়গা আগের মতোই (padding = -margin) */
    'html .app-header .logo>div:not(.mark){padding:3px 8px !important;margin:-3px -8px !important;}' +
    'html .app-header .sub{padding:2px 8px 3px !important;margin:1px -8px -3px !important;}';
  /* v137: ফুটারের গ্লাস -- ফ্রেম এখন পুরো স্ক্রিন জুড়ে, ফুটার তার ওপরে; পেজের কনটেন্ট ফুটারের নিচ দিয়ে স্ক্রল করে (তাই ব্লার/গ্লাস দেখা যায়)।
     কিন্তু শেষ কনটেন্ট/বিজ্ঞাপন, ভাসমান বাটন ও বটম-শিট যেন ফুটারের নিচে ঢাকা না পড়ে, তাই এই নিয়মগুলো।
     --pt-nav-h = ফুটারের উচ্চতা (সবসময়), --pt-nav-fix = ফুটার দেখা গেলে উচ্চতা, সরে গেলে ০ (frFit() সেট করে) */
  var NAV_CLEAR =
    '#pt-nav-spacer{display:block;flex:none;width:100%;height:var(--pt-nav-h,0px);pointer-events:none;}' +      /* page end: last content / ad can scroll fully above the footer */
    '.hs-fab{bottom:calc(22px + env(safe-area-inset-bottom) + var(--pt-nav-fix,0px)) !important;}' +             /* floating search button (Quran / Hadith) -- already animates `bottom` */
    '.hs-fab.hs-chapter{bottom:calc(22px + 54px + 20px + env(safe-area-inset-bottom) + var(--pt-nav-fix,0px)) !important;}' +
    '.bm-fab{bottom:calc(22px + env(safe-area-inset-bottom) + var(--pt-nav-fix,0px)) !important;transition:transform .22s ease, background-color .35s ease, color .35s ease, bottom .28s cubic-bezier(.2,.8,.2,1) !important;}' +
    '.snackbar{bottom:calc(20px + env(safe-area-inset-bottom) + var(--pt-nav-fix,0px)) !important;}' +
    '.sheet{padding-bottom:calc(env(safe-area-inset-bottom,0px) + 22px + var(--pt-nav-fix,0px)) !important;}' +   /* Tasbih / Qibla bottom sheets: the sheet itself runs under the footer, its content stays above it */
    '.wm{padding-bottom:var(--pt-nav-fix,0px) !important;box-sizing:border-box;}' +                                /* Namaz settings pop-up */
    '.hs-overlay,.flow-overlay,.sheet-overlay{bottom:var(--pt-nav-fix,0px) !important;}';                         /* full-page overlays (search, Amol flow/sheet) end at the footer's top edge, like before */

  /* v82: ফিচার পেজের হেডার হোম হেডারের মতো -- স্ট্যাটাস বার পর্যন্ত ব্লার, একই রং, নিচে একই আলোর রেখা (v84); শুধু সত্যিকারের পড়ার ভিউতে স্ক্রলে হাইড */
  function frChrome(fr, f) {
    var doc, w;
    try { doc = f.contentDocument; w = f.contentWindow; } catch (e) { return; }
    if (!doc || !w) return;
    try { if (window.__ptApplyReadSizes) window.__ptApplyReadSizes(doc); } catch (e) {}      /* সেটিংসের "পড়ার লেখার সাইজ" (কুরআন/হাদিস) */
    try { if (window.PTAds) window.PTAds.mountFooter(doc); } catch (e) {}      /* every feature page gets the fixed bottom ad (ads/) */
    try {                                                                        /* v137: end-of-page spacer (= footer height) so the last content / the ad can be scrolled fully above the glass footer */
      if (doc.body && !doc.getElementById('pt-nav-spacer')) { var sp = doc.createElement('div'); sp.id = 'pt-nav-spacer'; sp.setAttribute('aria-hidden', 'true'); (doc.querySelector('.app') || doc.body).appendChild(sp); }
    } catch (e) {}
    var hd = doc.querySelector('.app-header');
    if (!hd) return;
    var extra = safeTopPx(), el = hd.parentElement;
    while (el && el !== doc.documentElement) {
      var pt = parseFloat(w.getComputedStyle(el).paddingTop) || 0;
      if (pt) { extra += pt; el.style.setProperty('padding-top', '0px', 'important'); }
      el = el.parentElement;
    }
    hd.style.setProperty('padding-top', (14 + safeTopPx()) + 'px', 'important');   /* standard header: 14px + status bar (see STD_HEADER) */
    /* হেডার-ফুটার আচরণ (v84)
       - কোন ভিউতে স্ক্রলে হেডার লুকাবে সেটা ফিচারের নিজের header-autohide.js ঠিক করে: শুধু সত্যিকারের পড়ার ভিউতে (সূরা, তরজমার আয়াত, ওয়েব পেজ, হাদীসের অধ্যায় পাতা)।
         তালিকা, ডাউনলোড কার্ড, অধ্যায়-তালিকা, মুসহাফ প্রিভিউতে হেডার-ফুটার সবসময় থাকে।
       - হেডার লুকালে ফুটারও যায়, হেডার ফিরলে ফুটারও ফেরে (নিচের chromeSync)।
       - ফুল স্ক্রীন মুসহাফ: হেডার-ফুটার দুটোই লুকানো।
       - হেডারের নিচে হোমের মতো আলোর রেখা (GLOW_LINE): শুধু কুরআন ও হাদিস পেজে। */
    var css = doc.createElement('style');
    css.textContent = '.app-header{transition:transform .28s cubic-bezier(.2,.8,.2,1);will-change:transform;}' +
      '.app-header.hdr-hidden,html.pt-full .app-header{transform:translateY(calc(-100% - 14px)) !important;}' +      /* +14px: the line\'s glow slides out of sight too */
      'html.pt-themeswap *,html.pt-themeswap *::before,html.pt-themeswap *::after{transition:none !important;}' +      /* theme switch = instant (see 04-theme.js) */
      STD_HEADER + GLOW_LINE + NAV_CLEAR;              /* every feature page: the same full-width header + the light line + (v137) content kept clear of the glass footer */
    doc.head.appendChild(css);
    var hp = hd.parentElement;                          /* header wrapped alone in its own box (e.g. widget .hdr-wrap): sticky would have no room to stick -> let the wrapper vanish from layout */
    if (hp && hp !== doc.body && hp.children.length === 1) hp.style.setProperty('display', 'contents', 'important');
    var home = document.querySelector('.app-header');
    function chromeSync() {
      try {
        var full = !!doc.querySelector('#page-fullscreen:not(.hidden)');
        doc.documentElement.classList.toggle('pt-full', full);
        var modal = !!doc.querySelector('.pt-sheet:not([hidden]), .pt-dialog, .qa-sheet.on, .bm-modal-overlay:not(.hidden), .choice-overlay:not(.hidden), .fn-overlay:not(.hidden), .sheet.on, .win.on, .flow-overlay.show, .sheet-overlay.show, .popover-mask.show, .modal-mask.show');      /* ধাপ ৩: পেজের মাঝখানের পপআপ খোলা থাকলে ফুটার সরে যায় — ঝাপসা পর্দা পুরো স্ক্রিন ঢাকে */
        setChromeAway(fr, full || modal || hd.classList.contains('hdr-hidden'));
      } catch (e) {}
    }
    fr.chromeSync = chromeSync;
    window.addEventListener('pt-frame-chrome', function () { if (cur && frameOfKey(cur.key) === fr) chromeSync(); });
    if (w.MutationObserver) {                           /* react at once (not up to 300ms later) when the header slides away / returns or the Mushaf goes full screen */
      var pend = 0, mo = new w.MutationObserver(function () { if (pend) return; pend = setTimeout(function () { pend = 0; chromeSync(); }, 0); });
      [hd, doc.getElementById('page-fullscreen')].forEach(function (n) {
        if (n) mo.observe(n, { attributes: true, attributeFilter: ['class'] });
      });
    }
    var GLASS_PROPS = ['background-color', 'background-image', 'backdrop-filter', '-webkit-backdrop-filter'];
    function paintHeader() {                            /* header background by the page's OWN theme (see GLASS) */
      var th = doc.documentElement.getAttribute('data-theme'), g = GLASS[th], c, i, b;
      if (th === 'sepia') { GLASS_PROPS.forEach(function (k) { hd.style.removeProperty(k); }); return; }     /* page's own warm glass */
      if (g) { c = g.color; i = g.image; b = g.filter; }
      else if (home) { var hs = getComputedStyle(home); c = hs.backgroundColor; i = hs.backgroundImage; b = hs.backdropFilter; }   /* page without a known theme: follow Home */
      else return;
      hd.style.setProperty('background-color', c, 'important');
      hd.style.setProperty('background-image', i, 'important');
      hd.style.setProperty('backdrop-filter', b, 'important');
      hd.style.setProperty('-webkit-backdrop-filter', b, 'important');
    }
    if (w.MutationObserver) {                           /* the page's theme button -> repaint header AND footer at once */
      var swapT = 0, de = doc.documentElement, last = de.getAttribute('data-theme');
      new w.MutationObserver(function () {
        var now = de.getAttribute('data-theme');
        if (now !== last) { last = now; de.classList.add('pt-themeswap'); clearTimeout(swapT); swapT = setTimeout(function () { de.classList.remove('pt-themeswap'); }, 220); }
        paintHeader(); applyNavTheme();
      }).observe(doc.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    }
    function tick() {
      try {
        chromeSync(); paintHeader(); applyNavTheme(); frFit(fr);
        var pt = (14 + safeTopPx()) + 'px';
        if (hd.style.getPropertyValue('padding-top') !== pt) hd.style.setProperty('padding-top', pt, 'important');   /* status-bar height arrived / changed */
      } catch (e) {}
    }
    tick();
    setInterval(tick, 300);
  }
  function frLoad(fr, cb) {
    if (cb) fr.waiting.push(cb);
    if (fr.ready) { frFlush(fr); return; }
    if (fr.frame) return;
    var f = document.createElement('iframe');
    f.className = 'qr-frame'; f.title = fr.title; if (fr.allow) f.setAttribute('allow', fr.allow);
    f.addEventListener('load', function () {
      var doc; try { doc = f.contentDocument; } catch (e) {}
      if (fr.ready || !doc || !doc.querySelector('.app-header .mark')) return;
      fr.ready = true; clearTimeout(fr.timer);
      syncTheme(fr);                                    /* পেজ হোমের থিমে শুরু হয় (কিছু অ্যাপ নিজের সেভ করা অবস্থা দেরিতে লোড করে, তাই আবার মেলানো) */
      [1500, 4500].forEach(function (ms) { setTimeout(function () { if (!cur || cur.key !== fr.key) syncTheme(fr); }, ms); });
      try {                                             /* count the history steps the app adds (reader pages), so \u2190 / footer can remove them too */
        var w = f.contentWindow, hs = w.history, push = hs.pushState;
        hs.pushState = function () { fr.depth++; return push.apply(hs, arguments); };
        w.addEventListener('popstate', function () { if (fr.depth > 0) fr.depth--; });
      } catch (e) {}
      frChrome(fr, f);
      frFit(fr); frFlush(fr);
    });
    fr.frame = f;
    els[fr.name].appendChild(f);
    fr.timer = setTimeout(function () { if (fr.waiting.length) frFlush(fr); }, fr.wait);   /* never leave the person waiting */
    frFetch(fr, f, 0);
  }
  /* ফিচারের HTML আলাদা ফাইল (assets/features/<নাম>/<নাম>.html)। Kotlin (AssetServer) ঠিকানাটা assets থেকে দেয়; আগের মতোই srcdoc-এ বসে,
     তাই ফ্রেম মূল পেজের একই অরিজিনে থাকে (থিম সিঙ্ক, হোম হেডার, লোকাল স্টোরেজ আগের মতো)। */
  function frFetch(fr, f, tries) {
    var x = new XMLHttpRequest();
    x.open('GET', 'https://appassets.patheyo.invalid/features/' + fr.name + '/' + fr.name + '.html', true);
    x.onload = function () {
      if (x.status === 200 && x.responseText) { if (fr.frame === f) f.srcdoc = x.responseText; }
      else retry();
    };
    x.onerror = retry;
    function retry() { if (tries < 3) setTimeout(function () { frFetch(fr, f, tries + 1); }, 400 * (tries + 1)); }
    x.send();
  }
  function frIdle(fr) { if (!fr.frame) frLoad(fr); }
  function frIdleLater(fr, delay, tmo) {
    setTimeout(function () { if (window.requestIdleCallback) requestIdleCallback(function () { frIdle(fr); }, { timeout: tmo }); else setTimeout(function () { frIdle(fr); }, 1500); }, delay);
  }
  /* ধাপ ১২: আগে ৯টা ফিচার-পেজই প্রথম ~১২ সেকেন্ডে নিজে থেকে লোড হতো (ধীর ফোনে ১৭MB পড়া, অনেক মেমরি, হোম স্ক্রল আটকাত)।
     এখন: নামাজ (হোমের সময় এখান থেকে) ও কুরআন সবসময়; বাকিগুলো শুধু এই মানুষটা আগে যেগুলো খুলেছেন (pt_frame_use),
     একটা শেষ হলে তবেই পরেরটা, ফোন ফাঁকা থাকলে; কখনো না খোলা পেজগুলো আরও ১৫ সেকেন্ড পরে। টাইলে আঙুল পড়লেই যেকোনোটা সাথে সাথে শুরু হয় (নিচে pointerdown)। */
  var FRAME_USE_KEY = 'pt_frame_use';
  function frameUse() { try { return JSON.parse(localStorage.getItem(FRAME_USE_KEY) || '{}') || {}; } catch (e) { return {}; } }
  function noteUse(key) { if (!frameOfKey(key)) return; var u = frameUse(); u[key] = Math.min(999, (u[key] || 0) + 1); try { localStorage.setItem(FRAME_USE_KEY, JSON.stringify(u)); } catch (e) {} }
  window.addEventListener('load', function () {
    setTimeout(function () { frLoad(nz); }, 1200);   /* হোমের সময়/তারিখ এই ফ্রেম থেকে আসে, তাই সবার আগে */
    var u = frameUse();
    var rest = [am, du, tb, hd, qb, wg];
    var used = rest.filter(function (f) { return u[f.key] > 0; }).sort(function (a, b) { return (u[b.key] || 0) - (u[a.key] || 0); });
    var later = rest.filter(function (f) { return !(u[f.key] > 0); });
    var queue = [qr].concat(used), LATER_AT = queue.length;
    queue = queue.concat(later);                 /* কখনো না খোলা পেজও শেষে — অনেক পরে (২০+ সেকেন্ড), একটা একটা করে; প্রথমবার চাপলে যেন অপেক্ষা না লাগে */
    function next(i) {
      if (i >= queue.length) return;
      if (i === LATER_AT && i > 0 && !next.waited) { next.waited = true; setTimeout(function () { next(i); }, 15000); return; }
      var go = function () { if (queue[i].frame) { next(i + 1); return; } frLoad(queue[i], function () { setTimeout(function () { next(i + 1); }, 800); }); };
      if (window.requestIdleCallback) requestIdleCallback(go, { timeout: 8000 }); else setTimeout(go, 1500);
    }
    setTimeout(function () { next(0); }, 3500);
  });
  function openPage(key, src, srcKind, focusEl) {       /* a Quran / Hadith page waits (only the very first time, if it is not ready yet) for its frame */
    var fr = frameOfKey(key);
    if (fr && !fr.ready) { frLoad(fr, function () { open(key, src, srcKind, focusEl); }); return; }
    open(key, src, srcKind, focusEl);
  }

  /* entry points */
  tiles.forEach(function (tile, i) {
    tile.addEventListener('click', function () { openPage('f' + i, tile.querySelector('.module-tile-icon') || tile, 'tile', tile); });
  });
  if (tiles[1]) tiles[1].addEventListener('pointerdown', function () { frLoad(qr); }, { passive: true });     /* start the frame as soon as a finger lands */
  if (tiles[2]) tiles[2].addEventListener('pointerdown', function () { frLoad(hd); }, { passive: true });
  if (tiles[0]) tiles[0].addEventListener('pointerdown', function () { frLoad(nz); }, { passive: true });
  if (tiles[3]) tiles[3].addEventListener('pointerdown', function () { frLoad(am); }, { passive: true });
  if (tiles[6]) tiles[6].addEventListener('pointerdown', function () { frLoad(tb); }, { passive: true });
  if (tiles[7]) tiles[7].addEventListener('pointerdown', function () { frLoad(wg); }, { passive: true });
  if (tiles[4]) tiles[4].addEventListener('pointerdown', function () { frLoad(du); }, { passive: true });
  if (tiles[5]) tiles[5].addEventListener('pointerdown', function () { frLoad(qb); }, { passive: true });     /* start the Quran frame as soon as a finger lands */
  if (tabs[2]) tabs[2].addEventListener('pointerdown', function () { frLoad(qr); }, { passive: true });
  if (tabs[3]) tabs[3].addEventListener('pointerdown', function () { frLoad(hd); }, { passive: true });
  if (tabs[1]) tabs[1].addEventListener('pointerdown', function () { frLoad(nz); }, { passive: true });
  var gear = document.getElementById('btn-settings'), bellBtn = document.getElementById('btn-notif');
  gear.addEventListener('click', function () { var ic = gear.querySelector('.module-tile-icon') || gear; open('settings', ic, 'btn', gear); });   /* v2: সেটিংস এখন "সকল ফিচার"-এর ১০ নম্বর — আইকন উড়ে হেডারে বসে */
  bellBtn.addEventListener('click', function () { open('notif', bellBtn, 'btn', bellBtn); });

  /* ধাপ ১১: অন্য শেল-কোডের জন্য (সার্চ, যাকাত, __ptGo) — একই খোলা/বন্ধ লজিক, নিজস্ব কিছু নয় */
  window.__ptPages = {
    open: function (key, srcEl) {
      var tile = /^f\d$/.test(key) ? tiles[+key.slice(1)] : null;
      var src = srcEl || (tile && (tile.querySelector('.module-tile-icon') || tile)) || document.getElementById('btn-search') || document.body;
      var kind = srcEl ? 'btn' : tile ? 'tile' : 'btn';
      openPage(key, src, kind, srcEl || tile || src);
    },
    home: function () { home(); },
    current: function () { return cur ? cur.key : ''; },
    frameWin: function (key) { var f = frameOfKey(key); try { return f && f.ready ? f.frame.contentWindow : null; } catch (e) { return null; } },
    load: function (key) { var f = frameOfKey(key); if (f) frLoad(f); }
  };
  tabs.forEach(function (t, i) {
    t.addEventListener('click', function () {
      if (i === 0) home(); else openPage(PAGE_OF_TAB[i], t.querySelector('svg') || t, 'tab', t);
    });
  });
  Object.keys(backs).forEach(function (k) { backs[k].addEventListener('click', home); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && cur) home(); });
  window.addEventListener('popstate', function () {
    if (skipPop) { skipPop = false; return; }
    if (cur) home(true);
  });

  /* ---- notifications inbox (v151) ----
     ডেটা Kotlin-এ (window.PatheyoInbox): ওয়েবসাইট থেকে পাঠানো সব নোটিফিকেশন + অ্যাপ আপডেটের খবর।
       • ঘণ্টার ডানে-ওপরে লাল ব্যাজ = অপঠিত সংখ্যা (০ হলে লুকানো)
       • পেজ খুললে কিছু পঠিত হয় না; যেটায় ট্যাপ হয় শুধু সেটা পঠিত → ব্যাজ ১ কমে
       • পঠিত নোটিফিকেশন তালিকায় থেকে যায় (ম্লান হয়ে)
     ব্রাউজারে টেস্ট (ব্রিজ নেই): window.APP_UPDATES = [{ id, title, text, date }] থেকে পড়ে, পঠিত-অবস্থা localStorage-এ। */
  var KEY = 'patheyo-read-updates';
  var badge = document.getElementById('bell-badge'), list = document.getElementById('nt-list'), empty = document.getElementById('nt-empty');
  var BN = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  var MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[+d]; }); }
  function when(ts) {
    var d = new Date(Number(ts)); if (!ts || isNaN(d.getTime())) return '';
    var h = d.getHours(), m = d.getMinutes();
    var part = h < 4 ? 'রাত' : h < 6 ? 'ভোর' : h < 12 ? 'সকাল' : h < 15 ? 'দুপুর' : h < 18 ? 'বিকাল' : h < 20 ? 'সন্ধ্যা' : 'রাত';
    var h12 = h % 12 === 0 ? 12 : h % 12;
    return bn(d.getDate()) + ' ' + MONTHS[d.getMonth()] + ' ' + bn(d.getFullYear()) + ' · ' + part + ' ' + bn(h12) + ':' + bn(m < 10 ? '0' + m : m);
  }

  /* তথ্যের উৎস: Kotlin ব্রিজ (আসল অ্যাপ) অথবা ফলব্যাক (ব্রাউজার) */
  function nat() { var b = window.PatheyoInbox; return b && typeof b.getAll === 'function' ? b : null; }
  function readLocal() { try { return JSON.parse(localStorage.getItem(KEY) || '[]') || []; } catch (e) { return []; } }
  function getItems() {
    var b = nat();
    if (b) { try { var a = JSON.parse(b.getAll()); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
    var rd = readLocal();
    return (Array.isArray(window.APP_UPDATES) ? window.APP_UPDATES : []).map(function (i) {
      return { id: String(i.id), title: i.title, text: i.text, dateText: i.date, kind: 'push', link: i.link || '', read: rd.indexOf(String(i.id)) >= 0 };
    });
  }
  function markRead(id) {
    var b = nat();
    if (b) { try { b.markRead(String(id)); } catch (e) {} return; }
    var rd = readLocal(); if (rd.indexOf(String(id)) < 0) rd.push(String(id));
    try { localStorage.setItem(KEY, JSON.stringify(rd)); } catch (e) {}
  }
  function unreadOf(items) { var n = 0; items.forEach(function (i) { if (!i.read) n++; }); return n; }

  function paintBadge(items) {
    if (!badge) return;
    var n = unreadOf(items || getItems());
    badge.hidden = n <= 0;
    badge.textContent = n > 99 ? bn(99) + '+' : bn(n);
    var btn = document.getElementById('btn-notif');
    if (btn) btn.setAttribute('aria-label', n > 0 ? 'নোটিফিকেশন, ' + bn(n) + 'টি নতুন' : 'নোটিফিকেশন');
  }

  function render() {
    var items = getItems();
    list.textContent = '';
    items.forEach(function (i) {
      var d = document.createElement('div');
      d.className = 'nt-item lang-bn' + (i.read ? '' : ' is-new');
      d.setAttribute('role', 'button'); d.tabIndex = 0; d.dataset.id = i.id;
      [['nt-title', i.title], ['nt-text', i.text], ['nt-date', i.dateText || when(i.ts)]].forEach(function (p) {
        if (!p[1]) return; var n = document.createElement('div'); n.className = p[0]; n.textContent = p[1]; d.appendChild(n);
      });
      if (i.link && /^https?:\/\//i.test(i.link)) {
        var a = document.createElement('button'); a.type = 'button'; a.className = 'nt-link lang-bn'; a.textContent = 'লিংক খুলুন';
        a.addEventListener('click', function (e) {
          e.stopPropagation(); settle(d, i);
          var b = nat(); if (b && b.openLink) { try { b.openLink(i.link); } catch (er) {} } else window.open(i.link, '_blank');
        });
        d.appendChild(a);
      }
      /* v154: ছোট অবস্থায় বোল্ড শিরোনাম + মাত্র এক লাইন; ট্যাপ করলে পুরো লেখা খোলে, আবার ট্যাপ করলে গুটিয়ে যায় */
      var long = !!i.text && (String(i.text).indexOf('\n') >= 0 || String(i.text).length > 48);
      if (long) {
        d.classList.add('is-collapsible');
        d.setAttribute('aria-expanded', 'false');
        var chev = document.createElement('span'); chev.className = 'nt-chev'; chev.setAttribute('aria-hidden', 'true'); d.appendChild(chev);
      }
      if (i.kind === 'update') {
        var ub = document.createElement('button'); ub.type = 'button'; ub.className = 'nt-link nt-update-btn lang-bn'; ub.textContent = 'আপডেট করুন';
        ub.addEventListener('click', function (e) {
          e.stopPropagation(); settle(d, i);
          var b = nat(); if (b && b.openUpdate) { try { b.openUpdate(); } catch (er) {} }
        });
        d.appendChild(ub);
      }
      var tap = function () {
        settle(d, i);
        if (long) {
          var open = d.classList.toggle('is-open');
          d.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
      };
      d.addEventListener('click', tap);
      d.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tap(); } });
      list.appendChild(d);
    });
    empty.hidden = items.length > 0;
    paintBadge(items);
  }

  /* একটা নোটিফিকেশন পঠিত: শুধু সেটা ম্লান হয়, ব্যাজ ঠিক ১ কমে (পুরো তালিকা নতুন করে আঁকা হয় না — স্ক্রল ঠিক থাকে) */
  function settle(el, item) {
    if (item.read) return;
    item.read = true;
    markRead(item.id);
    el.classList.remove('is-new');
    paintBadge();
  }

  window.__renderNotif = render;
  /* Kotlin নতুন নোটিফিকেশন পেলে/অ্যাপে ফিরলে এটা ডাকে: পেজ খোলা থাকলে তালিকাও, নইলে শুধু ব্যাজ */
  window.__inboxChanged = function () {
    var ov = document.getElementById('notif-overlay');
    if (ov && ov.classList.contains('is-open')) render(); else paintBadge();
  };
  document.addEventListener('visibilitychange', function () { if (!document.hidden) window.__inboxChanged(); });
  window.addEventListener('focus', function () { window.__inboxChanged(); });
  paintBadge();
})();
