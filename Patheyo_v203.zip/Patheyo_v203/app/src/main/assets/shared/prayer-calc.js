/* পাথেয় — অফলাইন নামাজের সময় ও তারিখ (কোনো ইন্টারনেট লাগে না, ~৪KB)
   সূর্যের অবস্থান থেকে হিসাব (aladhan যে পদ্ধতিতে করে, সেই একই সূত্র) — তাই প্রথমবার খোলা বা নেট না থাকলেও সময় দেখায়।
   ব্যবহার:
     PtPrayer.times(date, {lat, lng, method, school})  → {Fajr, Sunrise, Dhuhr, Asr, Sunset, Maghrib, Isha}  ("HH:MM", ২৪ ঘণ্টা)
     PtPrayer.snapshot(date)  → হোমের ইঞ্জিনের snapshot-এর মতো: {h,m,s,dow,t,fb,hijri,greg,bangla,offline:true, place}
   সেটিংস নামাজ পেজের নিজের localStorage থেকেই পড়ে: currentMadhab ("1" হানাফী / "0" অন্যরা), prayerMethodId, waqtMinuteOffsets,
   hijriAdjustment; লোকেশন: lastKnownPrayerData (নামাজ পেজ শেষ যেটা জেনেছিল) → না থাকলে ঢাকা।
   মাগরিব/সূর্যাস্তে নামাজ পেজের মতোই স্থায়ী +৩ মিনিট। */
(function (W) {
  'use strict';
  var D2R = Math.PI / 180, R2D = 180 / Math.PI;
  function sin(d) { return Math.sin(d * D2R); } function cos(d) { return Math.cos(d * D2R); } function tan(d) { return Math.tan(d * D2R); }
  function asin(x) { return Math.asin(x) * R2D; } function acos(x) { return Math.acos(x) * R2D; } function atan2(y, x) { return Math.atan2(y, x) * R2D; }
  function acot(x) { return Math.atan(1 / x) * R2D; }
  function fixA(a) { a = a - 360 * Math.floor(a / 360); return a < 0 ? a + 360 : a; }
  function fixH(h) { h = h - 24 * Math.floor(h / 24); return h < 0 ? h + 24 : h; }

  /* aladhan-এর method id → ফজর/এশার কোণ (এশা সংখ্যা না হয়ে "90 min" হলে মাগরিবের পর মিনিট) */
  var METHODS = {
    1: { fajr: 18, isha: 18 },            /* করাচি — বাংলাদেশে প্রচলিত (ডিফল্ট) */
    2: { fajr: 15, isha: 15 },            /* ISNA */
    3: { fajr: 18, isha: 17 },            /* মুসলিম ওয়ার্ল্ড লীগ */
    4: { fajr: 18.5, isha: '90 min' },    /* উম্মুল কুরা, মক্কা */
    5: { fajr: 19.5, isha: 17.5 },        /* মিশর */
    8: { fajr: 19.5, isha: '90 min' },    /* উপসাগরীয় অঞ্চল */
    9: { fajr: 18, isha: 17.5 },          /* কুয়েত */
    10: { fajr: 18, isha: '90 min' },     /* কাতার */
    11: { fajr: 20, isha: 18 },           /* সিঙ্গাপুর/মালয়েশিয়া */
    13: { fajr: 18, isha: 17 },           /* তুরস্ক (দিয়ানেত) */
    16: { fajr: 18.2, isha: 18.2 },       /* দুবাই */
    15: { fajr: 18, isha: 18 }            /* মুনসাইটিং কমিটি (কাছাকাছি) */
  };
  var DHAKA = { lat: 23.8103, lng: 90.4125, name: 'ঢাকা' };

  function julian(y, m, d) {
    if (m <= 2) { y -= 1; m += 12; }
    var A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
    return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
  }
  function sunPos(jd) {
    var D = jd - 2451545.0, g = fixA(357.529 + 0.98560028 * D), q = fixA(280.459 + 0.98564736 * D);
    var L = fixA(q + 1.915 * sin(g) + 0.020 * sin(2 * g)), e = 23.439 - 0.00000036 * D;
    var RA = atan2(cos(e) * sin(L), cos(L)) / 15;
    return { decl: asin(sin(e) * sin(L)), eqt: q / 15 - fixH(RA) };
  }

  function times(date, o) {
    o = o || {};
    var lat = +o.lat, lng = +o.lng, m = METHODS[o.method] || METHODS[1], asrF = String(o.school) === '0' ? 1 : 2;
    var jDate = julian(date.getFullYear(), date.getMonth() + 1, date.getDate()) - lng / (15 * 24);
    var tz = -date.getTimezoneOffset() / 60;
    function mid(t) { var p = sunPos(jDate + t); return fixH(12 - p.eqt); }
    function angleTime(angle, t, ccw) {
      var p = sunPos(jDate + t), noon = mid(t);
      var x = (-sin(angle) - sin(p.decl) * sin(lat)) / (cos(p.decl) * cos(lat));
      if (x > 1 || x < -1) return NaN;                       /* মেরু অঞ্চলে সূর্য ওই কোণে পৌঁছায় না */
      var tt = acos(x) / 15;
      return noon + (ccw ? -tt : tt);
    }
    function asrT(f, t) { var p = sunPos(jDate + t); return angleTime(-acot(f + tan(Math.abs(lat - p.decl))), t, false); }
    /* প্রথম অনুমান → একবার শুদ্ধ করা (PrayTimes-এর মতো) */
    var g = { fajr: 5, sunrise: 6, dhuhr: 12, asr: 13, sunset: 18, isha: 18 };
    for (var it = 0; it < 2; it++) {
      var p = {};
      for (var k in g) p[k] = g[k] / 24;
      g = {
        fajr: angleTime(m.fajr, p.fajr, true),
        sunrise: angleTime(0.833, p.sunrise, true),
        dhuhr: mid(p.dhuhr),
        asr: asrT(asrF, p.asr),
        sunset: angleTime(0.833, p.sunset, false),
        isha: typeof m.isha === 'number' ? angleTime(m.isha, p.isha, false) : NaN
      };
    }
    if (typeof m.isha !== 'number') g.isha = g.sunset + parseFloat(m.isha) / 60;
    var adj = tz - lng / 15;
    function hm(h, add) {
      if (!isFinite(h)) return '';
      var mins = Math.round((fixH(h + adj)) * 60) + (add || 0);
      mins = ((mins % 1440) + 1440) % 1440;
      return ('0' + Math.floor(mins / 60)).slice(-2) + ':' + ('0' + mins % 60).slice(-2);
    }
    var off = o.offsets || {};
    return {
      Fajr: hm(g.fajr, off.Fajr), Sunrise: hm(g.sunrise), Dhuhr: hm(g.dhuhr, 1 + (off.Dhuhr || 0)),   /* যোহর: মধ্যাহ্নের ১ মিনিট পর (aladhan-এর মতো) */
      Asr: hm(g.asr, off.Asr), Sunset: hm(g.sunset, 3), Maghrib: hm(g.sunset, 3 + (off.Maghrib || 0)), Isha: hm(g.isha, off.Isha)
    };
  }

  /* ---------- তারিখ ---------- */
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  var GM = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  var HM = ['মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল উলা', 'জমাদিউস সানি', 'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ'];
  var BM = ['বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়', 'শ্রাবণ', 'ভাদ্র', 'আশ্বিন', 'কার্তিক', 'অগ্রহায়ণ', 'পৌষ', 'মাঘ', 'ফাল্গুন', 'চৈত্র'];
  function bangla(date) {                                  /* নামাজ পেজের getBengaliCalendarCalculation-এর হুবহু */
    var yr = date.getFullYear(), lp = (yr % 4 === 0 && yr % 100 !== 0) || (yr % 400 === 0);
    var dim = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, lp ? 30 : 29, 30];
    var by = yr - 593, b0 = new Date(yr, 3, 14);
    var d0 = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    if (d0 < b0) { by -= 1; b0 = new Date(yr - 1, 3, 14); }
    var bd = Math.floor((d0 - b0) / 86400000) + 1, i = 0;
    while (bd > dim[i]) { bd -= dim[i]; i++; }
    return bd + ' ' + BM[i] + ' ' + by;
  }
  /* নামাজ পেজের localGregorianToHijri-এর হুবহু (কুয়েতি/ট্যাবুলার সূত্র) — তাই হোম ও নামাজ পেজ অফলাইনেও একই হিজরি তারিখ দেখায় */
  function hijri(date, adjust) {
    try {
      var y = date.getFullYear(), mo = date.getMonth() + 1, d = date.getDate();
      var a = Math.floor((14 - mo) / 12), y2 = y + 4800 - a, m2 = mo + 12 * a - 3;
      var jdn = d + Math.floor((153 * m2 + 2) / 5) + 365 * y2 + Math.floor(y2 / 4) - Math.floor(y2 / 100) + Math.floor(y2 / 400) - 32045;
      var l = jdn - 1948440 + 10632 + (adjust || 0);
      var n = Math.floor((l - 1) / 10631); l = l - 10631 * n + 354;
      var j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
      l = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
      var m = Math.floor((24 * l) / 709), day = l - Math.floor((709 * m) / 24), yr = 30 * n + j - 30;
      if (!(m >= 1 && m <= 12)) return '';
      return day + ' ' + HM[m - 1] + ' ' + yr;
    } catch (e) { return ''; }
  }
  function ls(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function place() {
    try { var c = JSON.parse(ls('lastKnownPrayerData') || 'null'); if (c && isFinite(+c.lat) && isFinite(+c.lng) && (c.lat || c.lng)) return { lat: +c.lat, lng: +c.lng, name: c.locationName ? String(c.locationName).replace(/<[^>]*>/g, '').trim() : '', known: true }; } catch (e) {}
    return { lat: DHAKA.lat, lng: DHAKA.lng, name: DHAKA.name, known: false };
  }
  function opts() {
    var off = {}; try { off = JSON.parse(ls('waqtMinuteOffsets') || '{}') || {}; } catch (e) {}
    var p = place();
    return { lat: p.lat, lng: p.lng, place: p, method: parseInt(ls('userPrayerMethodId') || '0', 10) || parseInt(ls('prayerMethodId') || '1', 10) || 1,   /* ধাপ ৩: ব্যবহারকারীর বাছাই আগে */ school: ls('currentMadhab') || '1', offsets: off, hijriAdj: parseInt(ls('hijriAdjustment') || '0', 10) || 0 };
  }
  function snapshot(now) {
    now = now || new Date();
    var o = opts(), t = times(now, o);
    /* মাগরিবের পর হিজরি তারিখ পরের দিনে যায় (নামাজ পেজের নিয়মের মতো) */
    var hd = now, mg = t.Maghrib.split(':');
    if (mg.length === 2 && (now.getHours() * 60 + now.getMinutes()) >= (+mg[0] * 60 + +mg[1])) hd = new Date(now.getTime() + 86400000);
    return {
      h: now.getHours(), m: now.getMinutes(), s: now.getSeconds(), dow: now.getDay(), t: t,
      fb: { sr: 15, noon: 12, sset: 15 },
      hijri: hijri(hd, o.hijriAdj), greg: now.getDate() + ' ' + GM[now.getMonth()] + ' ' + now.getFullYear(), bangla: bangla(now),
      offline: true, place: o.place
    };
  }
  W.PtPrayer = { times: times, snapshot: snapshot, hijri: hijri, bangla: bangla, place: place, bn: bn, METHODS: METHODS };
})(window);
