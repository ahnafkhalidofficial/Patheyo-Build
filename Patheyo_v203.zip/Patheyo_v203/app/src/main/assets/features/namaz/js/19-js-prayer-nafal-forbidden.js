/* js/prayer/nafal-forbidden.js */
/* =============================================================================
   নফল ও নিষিদ্ধ (মাকরুহ) সময় — হিসাব ও কার্ড (ধাপ ৩ রিডিজাইন)
   তালিকা শুধু অবস্থা বদলালে নতুন করে আঁকা হয়; প্রতি সেকেন্ডে শুধু কাউন্টডাউন/প্রোগ্রেস।
   ============================================================================= */

function renderNafalAndForbiddenCards(tm, now) {
    const zawalStart = new Date(tm['Dhuhr'].getTime() - 12 * 60000);

    // ইশরাক
    const ishrakStart = new Date(tm['Sunrise'].getTime() + 15 * 60000);
    const ishrakEnd = new Date(zawalStart.getTime() - 5 * 60000);
    // চাশত/দুহা
    const duhaStart = new Date(tm['Sunrise'].getTime() + ((zawalStart.getTime() - tm['Sunrise'].getTime()) / 2));
    const duhaEnd = new Date(zawalStart.getTime() - 15 * 60000);
    // আওয়াবিন
    const awabinStart = new Date(tm['Maghrib'].getTime() + 15 * 60000);
    const awabinEnd = new Date(tm['Isha'].getTime() - 5 * 60000);
    // তাহাজ্জুদ
    const tahajjudEnd = new Date(tm['Fajr'].getTime() - 10 * 60000);

    const DAY = 86400000;
    const p2 = n => String(n).padStart(2, '0');
    const fmt = d => pcTime(p2(d.getHours()) + ':' + p2(d.getMinutes()));

    /* তাহাজ্জুদের অ্যালার্ম: রাতের শেষ তৃতীয়াংশের শুরু (ইশা → ফজর) */
    let nightStart = tm['Isha'], nightEnd = new Date(tm['Fajr'].getTime() + DAY);
    if (now < tm['Fajr']) { nightStart = new Date(tm['Isha'].getTime() - DAY); nightEnd = tm['Fajr']; }
    const lastThird = new Date(nightStart.getTime() + (nightEnd - nightStart) * 2 / 3);

    const nafalItems = [
        { id: 'ishrak',   name: 'ইশরাক',    rk: '২–৪ রাকাত',  ic: 'sunrise', start: ishrakStart, end: ishrakEnd, alarm: ishrakStart },
        { id: 'chasht',   name: 'চাশত',     rk: '২–১২ রাকাত', ic: 'sun',     start: duhaStart,   end: duhaEnd,   alarm: duhaStart },
        { id: 'awabin',   name: 'আওয়াবিন', rk: '৬–২০ রাকাত', ic: 'sunset',  start: awabinStart, end: awabinEnd, alarm: awabinStart },
        { id: 'tahajjud', name: 'তাহাজ্জুদ', rk: '২–১২ রাকাত', ic: 'moon',    start: null,        end: tahajjudEnd, alarm: lastThird }
    ];
    window.__nfLast = [tm, now];
    if (typeof nfAfterCompute === 'function') nfAfterCompute(nafalItems, now);

    /* ---- নফল ---- */
    const nafalContainer = document.getElementById('nafal-prayer-container');
    const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
    const act = nafalItems.map(it => { const sT = it.start || midnight; return now >= sT && now < it.end; });
    const nKey = JSON.stringify([globalTimings, act, window.nafalConfigs]);
    if (nafalContainer.__key !== nKey) {
        nafalContainer.__key = nKey;
        let h = '';
        nafalItems.forEach((item, i) => {
            const cfg = (window.nafalConfigs && nafalConfigs[item.id]) || { active: false };
            const en = fmt(item.end), st = item.start ? fmt(item.start) : null, al = fmt(item.alarm);
            const range = (st ? `<b>${st.n}</b><small>${st.p}</small>` : '<span class="nf-from">রাতের শেষ ভাগ</span>') + `<i>–</i><b>${en.n}</b><small>${en.p}</small>`;
            h += `
            <div class="nf${act[i] ? ' on' : ''}" data-nf="${item.id}" role="button" tabindex="0" onclick="nfOpenSettings('${item.id}')">
                <span class="nf-ic">${nzIc(item.ic)}</span>
                <div class="nf-main">
                    <div class="nf-top"><b>${item.name}</b><span class="nf-rk">${item.rk}</span>${act[i] ? '<span class="fz-chip live"><i></i>চলমান</span>' : ''}</div>
                    <div class="nf-tr">${range}</div>
                    ${act[i] ? '<div class="fz-bar"><span data-live="bar"></span></div><div class="fz-cd"><span data-live="lbl"></span><b data-live="cd"></b></div>' : ''}
                    ${cfg.active ? `<div class="nf-al">${nzIc('alarm')}অ্যালার্ম ${al.n} ${al.p}</div>` : ''}
                </div>
                <button type="button" class="fz-btn fz-bell${cfg.active ? ' on' : ''}" onclick="event.stopPropagation();nfToggle('${item.id}')" aria-label="${item.name}-এর অ্যালার্ম ${cfg.active ? 'চালু' : 'বন্ধ'}" aria-pressed="${cfg.active ? 'true' : 'false'}">${cfg.active ? PC_ICON.bell : PC_ICON.bellOff}</button>
            </div>`;
        });
        nafalContainer.innerHTML = h;
    }
    nafalItems.forEach((item, i) => {
        if (!act[i]) return;
        const row = nafalContainer.querySelector(`[data-nf="${item.id}"]`); if (!row) return;
        const sT = item.start || midnight;
        const pct = Math.max(0, Math.min(100, ((now - sT) / (item.end - sT)) * 100));
        const ph = getWaqtPhaseInfo(sT, item.end, now);
        const bar = row.querySelector('[data-live="bar"]'); if (bar) bar.style.width = pct.toFixed(1) + '%';
        const lbl = row.querySelector('[data-live="lbl"]'); const t = ph.isFirstHalf ? 'অতিবাহিত' : 'শেষ হতে বাকি';
        if (lbl && lbl.textContent !== t) lbl.textContent = t;
        const cd = row.querySelector('[data-live="cd"]'); if (cd) { const x = pcFixed(ph.diffStr); if (cd.__h !== x) { cd.innerHTML = x; cd.__h = x; } }
    });

    /* ---- নিষিদ্ধ সময় ---- */
    const forbiddenContainer = document.getElementById('forbidden-times-container');
    const forbiddenItems = [
        { name: 'সূর্যোদয়', ic: 'sunrise', start: tm['Sunrise'], end: new Date(tm['Sunrise'].getTime() + 15 * 60000) },
        { name: 'মধ্যাহ্ন',  ic: 'sun',     start: zawalStart, end: tm['Dhuhr'] },
        { name: 'সূর্যাস্ত', ic: 'sunset',  start: new Date(tm['Sunset'].getTime() - 15 * 60000), end: tm['Sunset'] }
    ];
    const fAct = forbiddenItems.map(it => now >= it.start && now < it.end);
    const fKey = JSON.stringify([globalTimings, fAct]);
    if (forbiddenContainer.__key !== fKey) {
        forbiddenContainer.__key = fKey;
        let h = '';
        forbiddenItems.forEach((item, i) => {
            const st = fmt(item.start), en = fmt(item.end);
            const mins = Math.max(1, Math.round((item.end - item.start) / 60000));
            h += `
            <div class="mk${fAct[i] ? ' on' : ''}" data-mk="${i}">
                <span class="mk-ic">${nzIc(item.ic)}</span>
                <b class="mk-name">${item.name}</b>
                <span class="mk-time">${st.n}<small>${st.p}</small></span>
                <span class="mk-to">থেকে ${en.n} পর্যন্ত</span>
                <span class="mk-dur">${fAct[i] ? '<b data-live="cd"></b>' : `${pcBn(mins)} মিনিট`}</span>
            </div>`;
        });
        forbiddenContainer.innerHTML = h;
    }
    forbiddenItems.forEach((item, i) => {
        if (!fAct[i]) return;
        const cd = forbiddenContainer.querySelector(`[data-mk="${i}"] [data-live="cd"]`);
        if (cd) { const x = 'বাকি ' + pcFixed(nzHms(item.end - now)); if (cd.__h !== x) { cd.innerHTML = x; cd.__h = x; } }
    });
}
