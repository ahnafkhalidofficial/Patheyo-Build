/* js/core/offline-cache.js */
/* =============================================================================
   অফলাইন ক্যাশ ও রিট্রাই
   সর্বশেষ সফল তথ্য ক্যাশে রাখা, অফলাইন ব্যানার এবং স্বয়ংক্রিয় পুনঃচেষ্টা।
   ============================================================================= */

// ============================================================================
// অফলাইন ক্যাশিং ব্যবস্থা — ইন্টারনেট না থাকলেও অ্যাপ যেন ভাঙাচোরা না দেখায়, বরং সর্বশেষ
// সফলভাবে আনা তথ্য (সময়, তারিখ, লোকেশন, তাপমাত্রা) সুন্দরভাবে দেখাতে থাকে।
// ============================================================================
function cacheLastKnownData(payload) {
    try { localStorage.setItem('lastKnownPrayerData', JSON.stringify(payload)); } catch(e) {}
}
function loadOfflineCacheIntoMemory() {
    try {
        const raw = localStorage.getItem('lastKnownPrayerData');
        if (!raw) return;
        const cached = JSON.parse(raw);
        if (cached.lat) userLat = cached.lat;
        if (cached.lng) userLng = cached.lng;
        if (cached.locationName) nzSetPlace(cached.locationName);
        if (cached.temp) cacheTemperatureStr = cached.temp;
    } catch(e) {}
}
function nzSetPlace(name) {
    name = String(name || '').replace(/<[^>]*>/g, '').trim();
    const t = document.getElementById('top-location'); if (t) t.textContent = name;
    const p = document.getElementById('nz-place-name'); if (p && name) p.textContent = name;
}
/* ধাপ ৩: অফলাইন হিসাব — ফোনেই সূর্যের অবস্থান থেকে আজকের সময় (shared/prayer-calc.js; aladhan-এর একই সূত্র)।
   prayer-calc মাগরিব/সূর্যাস্তে +৩ মিনিট বসিয়ে দেয়; এখানে সেটা বাদ দিয়ে "আসল" সময় ফেরত দেওয়া হয়, কারণ
   applyWaqtMinuteOffsets() নিজেই +৩ ও ব্যবহারকারীর মিনিট সমন্বয় যোগ করে। */
function computeOfflineTimings(now) {
    if (!window.PtPrayer) return null;
    try {
        const t = PtPrayer.times(now, { lat: userLat, lng: userLng, method: nzMethodId(), school: currentMadhab });
        if (!t || !t.Fajr || !t.Isha) return null;
        t.Maghrib = shiftTimeStr(t.Maghrib, -MAGHRIB_FIXED_OFFSET_MIN);
        t.Sunset = shiftTimeStr(t.Sunset, -MAGHRIB_FIXED_OFFSET_MIN);
        return t;
    } catch (e) { return null; }
}
function nzPaintDates(now) {
    document.getElementById('cal-gregorian').innerText = `${pcBn(now.getDate())} ${gregorianMonthsBN[now.getMonth()]} ${pcBn(now.getFullYear())}`;
    document.getElementById('cal-bangla').innerText = pcBn(getBengaliCalendarCalculation(now, false));
    document.getElementById('cal-hijri').innerText = pcBn(getFinalHijriDisplayString(now));
}
function nzPaintSun() {
    if (!globalTimings) return;
    document.getElementById('time-sunrise').innerHTML = nzT(globalTimings.Sunrise);
    document.getElementById('time-sunset').innerHTML = nzT(globalTimings.Sunset);
    const n = parseWaqtStringToDate(globalTimings.Dhuhr); n.setMinutes(n.getMinutes() - 12);   /* মধ্যাহ্ন (জাওয়াল) — নিষিদ্ধ সময়ের শুরু */
    document.getElementById('time-noon').innerHTML = nzD(n);
    document.getElementById('time-sehri').innerText = convert24To12(globalTimings.Fajr);
    document.getElementById('time-iftar').innerText = convert24To12(globalTimings.Maghrib);
}
/* অনলাইনের সময় না থাকলে (বা শুরুতে, এপিআই আসার আগেই) — ফোনের হিসাব দিয়ে পুরো পেজ সাথে সাথে আঁকা */
function nzRenderOffline(now, quiet) {
    if (nzSource === 'live' && lastRawTimings && quiet) {          /* অনলাইনের সময় আছে: শুধু নতুন সমন্বয় বসিয়ে আবার আঁকা */
        globalTimings = applyWaqtMinuteOffsets(lastRawTimings);
    } else {
        let raw = computeOfflineTimings(now), src = 'offline';
        if (!raw) {
            try { const c = JSON.parse(localStorage.getItem('lastKnownPrayerData') || 'null'); if (c && c.timings) { raw = c.timings; src = 'cache'; } } catch (e) {}
        }
        if (!raw) return false;
        lastRawTimings = raw; nzSource = src;
        globalTimings = applyWaqtMinuteOffsets(raw);
    }
    try { isRamadanNow = (getEffectiveHijriMonthIndex(now) === 8); } catch (e) {}
    nzPaintDates(now); nzPaintSun();
    if (typeof nzAfterData === 'function') nzAfterData();
    processDashboardTimelineUpdates(new Date());
    return true;
}
// ইন্টারনেট/ফেচ ব্যর্থ হলে — ফোনের হিসাব দিয়ে পুরো UI
function loadFromOfflineCache(now) {
    const ok = nzRenderOffline(now, false);
    notifyOfflineBannerState(true, !ok);
}

// নেট নেই / সার্ভার সাড়া দিচ্ছে না — এখন ফোনেই নির্ভুল হিসাব হয়, তাই বার্তা ছোট ও শান্ত
function notifyOfflineBannerState(isOffline, noCacheYet) {
    isShowingOfflineData = isOffline;
    const banner = document.getElementById('offline-status-banner');
    if (isOffline) {
        const deviceHasNoNetwork = (nativeNetworkStatus === false) || (nativeNetworkStatus === null && !navigator.onLine);
        if (banner) {
            banner.hidden = false;
            banner.textContent = noCacheYet
                ? 'সময় হিসাব করা যায়নি — একবার ইন্টারনেট চালু করুন'
                : (deviceHasNoNetwork ? 'ইন্টারনেট নেই — ফোনেই হিসাব করা সময় দেখানো হচ্ছে' : 'সার্ভারে সাড়া নেই — ফোনেই হিসাব করা সময় দেখানো হচ্ছে');
        }
        scheduleOfflineDataRetry();
    } else {
        if (banner) banner.hidden = true;
        cancelOfflineDataRetry();
    }
    if (typeof nzAfterData === 'function') nzAfterData();
}

// ডেটা আনতে ব্যর্থ হলে (নেট থাকুক বা না থাকুক) পটভূমিতে বারবার আবার চেষ্টা করার ব্যবস্থা — ব্যবহারকারীকে
// অ্যাপ বন্ধ-খোলা বা রিফ্রেশ করতে হবে না, নেট ফিরে এলে বা সার্ভার ঠিক হলে এমনিতেই সঠিক ডেটা চলে আসবে।
let offlineRetryTimer = null;
let offlineRetryAttempt = 0;
function scheduleOfflineDataRetry() {
    if (offlineRetryTimer) return; // ইতিমধ্যে শিডিউল করা আছে
    offlineRetryAttempt++;
    // এক্সপোনেনশিয়াল ব্যাকঅফ: ১৫সে → ৩০সে → ৬০সে → সর্বোচ্চ ১২০সে পরপর — ব্যাটারি/ডেটা সাশ্রয়ী রেখে দ্রুত রিকভারি
    const delayMs = Math.min(15000 * Math.pow(2, offlineRetryAttempt - 1), 120000);
    offlineRetryTimer = setTimeout(() => {
        offlineRetryTimer = null;
        if (isShowingOfflineData) { fetchCorePrayerData(); }
    }, delayMs);
}
function cancelOfflineDataRetry() {
    if (offlineRetryTimer) { clearTimeout(offlineRetryTimer); offlineRetryTimer = null; }
    offlineRetryAttempt = 0;
}

