/* js/ui/extras.js — ধাপ ৩ (রিডিজাইন)-এর নতুন অংশ
   ১) সময়ের উৎস চিহ্ন (লাইভ / ফোনেই হিসাব / সংরক্ষিত)
   ২) রমজান মোড: সেহরি শেষ ও ইফতারের কাউন্টডাউন (হিজরি মাস রমজান হলে নিজে থেকেই দেখায়)
   ৩) আদায়-চিহ্ন: ওয়াক্তের ✓ → আমলের রিপোর্ট (amol_report_state; হোমের __ptPrayed দিয়ে, যাতে সব জায়গায় এক হিসাব)
   ৪) হিসাবের নিয়ম: পদ্ধতি (userPrayerMethodId), মাযহাব, প্রতি ওয়াক্তে ±মিনিট (waqtMinuteOffsets)
   ৫) হিজরি ক্যালেন্ডার: চলতি মাস + আসন্ন বিশেষ দিন */

/* ---------- ছোট সহায়ক ---------- */
function nzSegSync() { /* দুই-ঘরের সেগমেন্টের চলমান অংশ CSS-এই (data-v / data-mode) */ }
function nzScrollTo(id) { const el = document.getElementById(id); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
function nzPad(n) { return (n < 10 ? '0' : '') + n; }
function nzDkey(d) { return d.getFullYear() + '-' + nzPad(d.getMonth() + 1) + '-' + nzPad(d.getDate()); }
function nzAddDays(d, n) { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); return x; }
function nzEsc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

/* ---------- ১) উৎস ---------- */
const NZ_SRC = { live: 'লাইভ', offline: 'ফোনেই হিসাব', cache: 'সংরক্ষিত' };
function nzAfterData() {
    const src = document.getElementById('nz-src');
    if (src && src.dataset.src !== nzSource) { src.dataset.src = nzSource; document.getElementById('nz-src-label').textContent = NZ_SRC[nzSource] || ''; }
    const note = document.getElementById('nz-src-note');
    if (note) note.textContent = nzSource === 'live'
        ? 'সময়ের উৎস: aladhan.com (অনলাইন)। ইন্টারনেট না থাকলে ফোনেই একই সূত্রে হিসাব হয়।'
        : 'এখন ফোনেই হিসাব করা সময় (aladhan-এর একই সূত্র)। ইন্টারনেট এলে নিজেই মিলিয়ে নেবে।';
    nzPaintMethod(); nzRenderAdj();
    try { nzRenderCal(new Date()); } catch (e) { console.error(e); }
}

/* ---------- ২) রমজান মোড ---------- */
function nzRamadan(S) {
    const box = document.getElementById('nz-ramadan'); if (!box) return;
    if (!isRamadanNow) { if (!box.hidden) box.hidden = true; return; }
    if (box.hidden) box.hidden = false;
    const now = S.now, fajr = S.tm['Fajr'], mag = S.tm['Maghrib'];
    let target, label, which;
    if (now < fajr) { target = fajr; label = 'সেহরি শেষ হতে বাকি'; which = 'sehri'; }
    else if (now < mag) { target = mag; label = 'ইফতারের বাকি'; which = 'iftar'; }
    else { target = new Date(fajr.getTime() + 86400000); label = 'আগামী সেহরি শেষ হতে বাকি'; which = 'sehri'; }
    nzSet('nz-ram-label', label);
    nzSet('nz-ram-cd', pcFixed(nzHms(target - now)));
    nzSet('nz-ram-sehri', `<span>সেহরি শেষ</span><b>${nzT(globalTimings.Fajr)}</b>`);
    nzSet('nz-ram-iftar', `<span>ইফতার</span><b>${nzT(globalTimings.Maghrib)}</b>`);
    box.dataset.next = which;
    let day = '';
    try { const h = getDisplayHijriDate(now, false, true); if (h.month === 8) day = 'রমজান ' + pcBn(h.day); } catch (e) {}
    nzSet('nz-ram-day', day);
}

/* ---------- ৩) আদায়-চিহ্ন ---------- */
const NZ_AMOL_ID = { Fajr: 'fajr', Dhuhr: 'midday', Asr: 'asr', Maghrib: 'maghrib', Isha: 'isha' };
function nzPrayedApi() { try { if (window.parent && window.parent !== window && window.parent.__ptPrayed) return window.parent.__ptPrayed; } catch (e) {} return null; }
function nzAmolLocal() { try { const o = JSON.parse(localStorage.getItem('amol_report_state') || 'null'); if (o && typeof o === 'object') { o.days = o.days || {}; return o; } } catch (e) {} return { days: {} }; }
function nzPrayedKey(id, now, tm) {
    const d = (id === 'Isha' && tm && now < tm['Fajr']) ? new Date(now.getTime() - 86400000) : now;   /* রাতে ফজরের আগে: গতকালের এশা */
    return nzDkey(d);
}
function nzPrayedGet(id, now, tm) {
    const k = nzPrayedKey(id, now, tm), api = nzPrayedApi();
    if (api) { try { return api.get(k, NZ_AMOL_ID[id]) || ''; } catch (e) {} }
    const r = nzAmolLocal().days[k]; return r ? r[NZ_AMOL_ID[id]] || '' : '';
}
function nzPrayedSet(id, v, now, tm) {
    const k = nzPrayedKey(id, now, tm), api = nzPrayedApi();
    if (api) { try { api.set(k, NZ_AMOL_ID[id], v); return; } catch (e) {} }
    const st = nzAmolLocal(); if (!st.days[k]) st.days[k] = {};
    if (v) st.days[k][NZ_AMOL_ID[id]] = v; else delete st.days[k][NZ_AMOL_ID[id]];
    if (typeof st.soundOn !== 'boolean') st.soundOn = true;
    try { localStorage.setItem('amol_report_state', JSON.stringify(st)); } catch (e) {}
}
let nzPrayedCache = { t: 0, v: null };
function nzPrayedMap(now, tm) {
    if (nzPrayedCache.v && Date.now() - nzPrayedCache.t < 1500) return nzPrayedCache.v;
    const m = {}; Object.keys(NZ_AMOL_ID).forEach(id => { const v = nzPrayedGet(id, now, tm); if (v) m[id] = v; });
    nzPrayedCache = { t: Date.now(), v: m };
    return m;
}
let nzPrayedFor = '';
function nzPrayedOpen(id) {
    const S = nzLastState; if (!S) return;
    const m = document.getElementById('nz-prayed-modal'), nm = waqtBnName(id, S.now);
    const k = nzPrayedKey(id, S.now, S.tm), v = nzPrayedGet(id, S.now, S.tm);
    nzPrayedFor = id;
    document.getElementById('nz-prayed-title').textContent = nm;
    document.getElementById('nz-prayed-sub').textContent = (k === nzDkey(S.now) ? 'আজকের ' : 'গতকালের ') + nm + ' কীভাবে আদায় করেছেন?';
    m.querySelectorAll('.pt-option').forEach(o => o.setAttribute('aria-checked', o.getAttribute('data-v') === v ? 'true' : 'false'));
    document.getElementById('nz-prayed-clear').hidden = !v;
    PT.sheet.open(m);
}
(function () {
    const m = document.getElementById('nz-prayed-modal'); if (!m) return;
    m.addEventListener('click', function (e) {
        const b = e.target.closest('[data-v]'); if (!b || !nzPrayedFor || !nzLastState) return;
        const v = b.getAttribute('data-v');
        nzPrayedSet(nzPrayedFor, v, nzLastState.now, nzLastState.tm);
        nzPrayedCache.v = null;
        m.querySelectorAll('.pt-option').forEach(o => o.setAttribute('aria-checked', o === b ? 'true' : 'false'));
        setTimeout(function () { PT.sheet.close(m); }, 160);
        processDashboardTimelineUpdates(new Date());
        const row = document.querySelector(`#main-prayer-cards-container [data-w="${nzPrayedFor}"] .fz-done`); if (row) row.classList.add('pop');
        if (v === 'jamaat' || v === 'alone') PT.toast('আলহামদুলিল্লাহ — আমলের রিপোর্টে যুক্ত হয়েছে', { type: 'success' });
        else if (v === 'qaza') PT.toast('কাজা হিসেবে রাখা হলো', { icon: 'info' });
        else PT.toast('চিহ্ন মুছে ফেলা হয়েছে', { icon: 'undo' });
    });
    window.addEventListener('storage', function (e) { if (e.key === 'amol_report_state') nzPrayedCache.v = null; });
})();
function nzDoneCount(S) {
    const el = document.getElementById('nz-done-count'); if (!el) return;
    const m = nzPrayedMap(S.now, S.tm); let n = 0;
    Object.keys(m).forEach(k => { if (m[k] === 'jamaat' || m[k] === 'alone') n++; });
    const t = pcBn(n) + '/৫ আদায়';
    el.hidden = !n; if (el.textContent !== t) el.textContent = t;
}

/* প্রতি সেকেন্ডে (processDashboardTimelineUpdates-এর শেষে) */
function nzAfterTick(S) { nzRamadan(S); nzDoneCount(S); }

/* ---------- ৪) হিসাবের নিয়ম ---------- */
const NZ_METHODS = [
    { id: 1, name: 'করাচি', sub: 'বাংলাদেশ, পাকিস্তান, ভারতে প্রচলিত · ফজর ও এশা ১৮°' },
    { id: 3, name: 'মুসলিম ওয়ার্ল্ড লীগ', sub: 'ইউরোপ, দূরপ্রাচ্য · ফজর ১৮°, এশা ১৭°' },
    { id: 4, name: 'উম্মুল কুরা, মক্কা', sub: 'সৌদি আরব · এশা মাগরিবের ৯০ মিনিট পর' },
    { id: 2, name: 'উত্তর আমেরিকা (ISNA)', sub: 'যুক্তরাষ্ট্র, কানাডা · ফজর ও এশা ১৫°' },
    { id: 5, name: 'মিশর', sub: 'আফ্রিকা, সিরিয়া, লেবানন · ফজর ১৯.৫°' },
    { id: 8, name: 'উপসাগরীয় অঞ্চল', sub: 'আমিরাত, ওমান, বাহরাইন' },
    { id: 16, name: 'দুবাই', sub: 'সংযুক্ত আরব আমিরাত · ১৮.২°' },
    { id: 10, name: 'কাতার', sub: 'এশা মাগরিবের ৯০ মিনিট পর' },
    { id: 9, name: 'কুয়েত', sub: 'ফজর ১৮°, এশা ১৭.৫°' },
    { id: 11, name: 'সিঙ্গাপুর · মালয়েশিয়া', sub: 'ফজর ২০°, এশা ১৮°' },
    { id: 13, name: 'তুরস্ক (দিয়ানেত)', sub: 'ফজর ১৮°, এশা ১৭°' },
    { id: 15, name: 'মুনসাইটিং কমিটি', sub: 'যুক্তরাজ্য ও পশ্চিমা দেশে প্রচলিত' }
];
function nzMethodName(id) { const m = NZ_METHODS.find(x => x.id === id); return m ? m.name : 'করাচি'; }
function nzPaintMethod() {
    const el = document.getElementById('nz-method-name'); if (!el) return;
    const user = parseInt(localStorage.getItem('userPrayerMethodId') || '0', 10) > 0;
    const t = nzMethodName(nzMethodId()) + (user ? '' : ' · স্বয়ংক্রিয়');
    if (el.textContent !== t) el.textContent = t;
}
function nzOpenMethod() {
    const user = parseInt(localStorage.getItem('userPrayerMethodId') || '0', 10);
    const auto = parseInt(window._nativeMethodId, 10) || 1;
    let h = `<button class="pt-option" type="button" role="radio" aria-checked="${user ? 'false' : 'true'}" data-m="0"><span class="pt-option__radio"></span><div class="pt-grow"><div class="pt-row__title">স্বয়ংক্রিয় (সুপারিশকৃত)</div><div class="pt-row__sub">পাথেয়-এর ঠিক করা পদ্ধতি: ${nzMethodName(auto)}</div></div></button>`;
    NZ_METHODS.forEach(m => {
        h += `<button class="pt-option" type="button" role="radio" aria-checked="${user === m.id ? 'true' : 'false'}" data-m="${m.id}"><span class="pt-option__radio"></span><div class="pt-grow"><div class="pt-row__title">${m.name}</div><div class="pt-row__sub">${m.sub}</div></div></button>`;
    });
    const list = document.getElementById('nz-method-list'); list.innerHTML = h;
    PT.sheet.open(document.getElementById('nz-method-modal'));
}
(function () {
    const list = document.getElementById('nz-method-list'); if (!list) return;
    list.addEventListener('click', function (e) {
        const b = e.target.closest('[data-m]'); if (!b) return;
        const v = parseInt(b.getAttribute('data-m'), 10);
        list.querySelectorAll('[data-m]').forEach(o => o.setAttribute('aria-checked', o === b ? 'true' : 'false'));
        try { if (v > 0) localStorage.setItem('userPrayerMethodId', String(v)); else localStorage.removeItem('userPrayerMethodId'); } catch (err) {}
        setTimeout(function () { PT.sheet.close(document.getElementById('nz-method-modal')); }, 160);
        nzSource = nzSource === 'live' ? 'cache' : nzSource;        /* পুরনো অনলাইন সময় আর এই পদ্ধতির নয় */
        nzRecompute(); nzPaintMethod();
        PT.toast('হিসাবের পদ্ধতি: ' + nzMethodName(nzMethodId()), { type: 'success' });
    });
})();

/* প্রতি ওয়াক্তে ±মিনিট */
const NZ_ADJ_IDS = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
function nzAdjTxt(v) { return v ? (v > 0 ? '+' : '−') + pcBn(Math.abs(v)) : '০'; }
function nzRenderAdj() {
    const box = document.getElementById('nz-adj'); if (!box) return;
    const key = JSON.stringify([waqtMinuteOffsets, new Date().getDay() === 5]);
    if (box.__key === key) return; box.__key = key;
    box.innerHTML = NZ_ADJ_IDS.map(id => {
        const v = parseInt(waqtMinuteOffsets[id], 10) || 0;
        return `<div class="nz-adj__row${v ? ' is-set' : ''}" data-adj="${id}"><span class="nz-adj__name">${waqtBnName(id, new Date())}</span>
            <button type="button" class="wm-round" data-d="-1" aria-label="${waqtBnName(id)} এক মিনিট আগে">${nzIc('minus')}</button>
            <b class="nz-adj__v" aria-live="polite">${nzAdjTxt(v)}<small>মি.</small></b>
            <button type="button" class="wm-round" data-d="1" aria-label="${waqtBnName(id)} এক মিনিট পরে">${nzIc('plus')}</button></div>`;
    }).join('');
    const any = NZ_ADJ_IDS.some(id => parseInt(waqtMinuteOffsets[id], 10));
    const r = document.getElementById('nz-adj-reset'); if (r) r.hidden = !any;
}
let nzAdjT = 0;
function nzAdjCommit() {
    clearTimeout(nzAdjT);
    nzAdjT = setTimeout(function () {
        try { localStorage.setItem('waqtMinuteOffsets', JSON.stringify(waqtMinuteOffsets)); } catch (e) {}
        nzRecompute();
    }, 450);
}
(function () {
    const box = document.getElementById('nz-adj'); if (!box) return;
    box.addEventListener('click', function (e) {
        const b = e.target.closest('[data-d]'); if (!b) return;
        const id = b.closest('[data-adj]').getAttribute('data-adj');
        let v = (parseInt(waqtMinuteOffsets[id], 10) || 0) + parseInt(b.getAttribute('data-d'), 10);
        v = Math.max(-30, Math.min(30, v));
        waqtMinuteOffsets[id] = v;
        PT.haptic('light');
        const row = b.closest('[data-adj]'); row.classList.toggle('is-set', !!v);
        row.querySelector('.nz-adj__v').innerHTML = nzAdjTxt(v) + '<small>মি.</small>';
        box.__key = JSON.stringify([waqtMinuteOffsets, new Date().getDay() === 5]);
        const r = document.getElementById('nz-adj-reset'); if (r) r.hidden = !NZ_ADJ_IDS.some(k => parseInt(waqtMinuteOffsets[k], 10));
        nzAdjCommit();
    });
})();
function nzResetOffsets() {
    NZ_ADJ_IDS.forEach(id => { waqtMinuteOffsets[id] = 0; });
    const box = document.getElementById('nz-adj'); if (box) box.__key = '';
    nzRenderAdj(); nzAdjCommit();
    PT.toast('সব ওয়াক্ত আসল সময়ে ফিরেছে', { icon: 'undo' });
}

/* ---------- ৫) হিজরি ক্যালেন্ডার ও বিশেষ দিন ---------- */
const NZ_EVENTS = [
    { m: 0, d: 1, t: 'হিজরি নববর্ষ' },
    { m: 0, d: 10, t: 'আশুরা', s: '৯ ও ১০ বা ১০ ও ১১ মুহাররম রোজা' },
    { m: 6, d: 26, t: 'শবে মিরাজ', s: '২৬ রজব দিবাগত রাত' },
    { m: 7, d: 14, t: 'শবে বরাত', s: '১৪ শাবান দিবাগত রাত' },
    { m: 8, d: 1, t: 'রমজান শুরু', s: 'প্রথম রোজা (চাঁদ দেখা সাপেক্ষে)' },
    { m: 8, d: 26, t: 'শবে কদর', s: '২৬ রমজান দিবাগত রাত' },
    { m: 9, d: 1, t: 'ঈদুল ফিতর', s: 'আজ রোজা রাখা হারাম' },
    { m: 11, d: 9, t: 'আরাফাহর দিন', s: 'নফল রোজা — দুই বছরের গুনাহ মাফ' },
    { m: 11, d: 10, t: 'ঈদুল আজহা', s: 'কোরবানির দিন' }
];
const NZ_WD = ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র'];
const NZ_WD_FULL = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
/* আজকের হিজরি (দিনের হিসাবে, মাগরিবের আগে) — অ্যাপের হিসাব ও স্থানীয় সূত্রের পার্থক্য (দিন) দিয়ে যেকোনো দিনের হিজরি */
function nzHijriOf(date, delta) { return localGregorianToHijri(nzAddDays(date, delta), true); }
function nzHijriDelta(now, h0) {
    for (let d = -3; d <= 3; d++) { const x = nzHijriOf(now, d); if (x.day === h0.day && x.month === h0.month) return d; }
    return 0;
}
function nzRenderCal(now) {
    const box = document.getElementById('nz-cal'); if (!box || !globalTimings) return;
    const h0 = getDisplayHijriDate(now, false, true);
    const key = nzDkey(now) + '|' + JSON.stringify(h0) + '|' + (window._nativeHijriAdjustment || 0);
    if (box.__key === key) return; box.__key = key;
    const delta = nzHijriDelta(now, h0);
    let len = h0.monthLength;
    if (!len) { const x = nzHijriOf(nzAddDays(now, 30 - h0.day), delta); len = (x.month === h0.month && x.day === 30) ? 30 : 29; }
    const first = nzAddDays(now, 1 - h0.day);
    const lead = (first.getDay() + 1) % 7;                        /* শনিবার থেকে সপ্তাহ */
    const evIn = {}; NZ_EVENTS.forEach(e => { if (e.m === h0.month) evIn[e.d] = e; });
    let cells = NZ_WD.map((w, i) => `<span class="nz-cal__wd${i === 6 ? ' fri' : ''}">${w}</span>`).join('');
    for (let i = 0; i < lead; i++) cells += '<span class="nz-cal__pad"></span>';
    for (let d = 1; d <= len; d++) {
        const g = nzAddDays(first, d - 1), isT = d === h0.day, white = d >= 13 && d <= 15, ev = evIn[d];
        const cls = 'nz-cal__d' + (isT ? ' today' : '') + (d < h0.day ? ' past' : '') + (white ? ' white' : '') + (ev ? ' ev' : '') + (g.getDay() === 5 ? ' fri' : '');
        const tip = `${pcBn(d)} ${hijriMonthsBN[h0.month]} · ${pcBn(g.getDate())} ${gregorianMonthsBN[g.getMonth()]}, ${NZ_WD_FULL[g.getDay()]}` + (ev ? ' · ' + ev.t : white ? ' · আইয়ামে বিয (সুন্নাত রোজা)' : '');
        cells += `<button type="button" class="${cls}" data-tip="${nzEsc(tip)}" aria-label="${nzEsc(tip)}"><b>${pcBn(d)}</b><small>${pcBn(g.getDate())}</small></button>`;
    }
    /* আসন্ন বিশেষ দিন */
    const up = [];
    const seen = {};
    for (let k = 0; k < 400 && up.length < 12; k++) {
        const x = nzHijriOf(now, k + delta), g = nzAddDays(now, k);
        NZ_EVENTS.forEach(e => { if (e.m === x.month && e.d === x.day && !seen[e.t]) { seen[e.t] = 1; up.push({ k, g, e, x }); } });
        if (!seen.white && x.day === 13 && k > 0) { seen.white = 1; up.push({ k, g, e: { t: 'আইয়ামে বিয রোজা', s: '১৩, ১৪ ও ১৫ তারিখ — সুন্নাত রোজা' }, x }); }
    }
    up.sort((a, b) => a.k - b.k);
    const rows = up.slice(0, 4).map(u => {
        const when = u.k === 0 ? 'আজ' : u.k === 1 ? 'আগামীকাল' : 'আর ' + pcBn(u.k) + ' দিন';
        return `<div class="nz-ev${u.k <= 7 ? ' soon' : ''}"><span class="nz-ev__date"><b>${pcBn(u.g.getDate())}</b><small>${gregorianMonthsBN[u.g.getMonth()]}</small></span>
            <span class="pt-grow"><b>${u.e.t}</b><span>${pcBn(u.x.day)} ${hijriMonthsBN[u.x.month]} · ${NZ_WD_FULL[u.g.getDay()]}${u.e.s ? ' · ' + u.e.s : ''}</span></span>
            <span class="nz-ev__when">${when}</span></div>`;
    }).join('');
    box.innerHTML = `
        <div class="nz-cal__head"><div><b class="nz-cal__month">${hijriMonthsBN[h0.month]}</b><span class="nz-cal__year">${pcBn(h0.year)} হিজরি</span></div>
            <span class="nz-cal__legend"><i class="lg-white"></i>আইয়ামে বিয <i class="lg-ev"></i>বিশেষ দিন</span></div>
        <div class="nz-cal__grid">${cells}</div>
        <div class="nz-cal__sub">আসন্ন বিশেষ দিন</div>
        <div class="nz-evs">${rows}</div>
        <p class="nz-cal__note">চাঁদ দেখার ওপর ভিত্তি করে তারিখ এক দিন আগে-পরে হতে পারে।</p>`;
}
(function () {
    const box = document.getElementById('nz-cal'); if (!box) return;
    box.addEventListener('click', function (e) { const b = e.target.closest('[data-tip]'); if (b && window.PT) PT.toast(b.getAttribute('data-tip'), { icon: 'calendar' }); });
})();

/* পপআপ খুললে/বন্ধ হলে হোমের ফুটার সাথে সাথে সরে/ফেরে (কন্ট্রোলারের chromeSync) */
['pt:open', 'pt:close'].forEach(function (ev) {
    document.addEventListener(ev, function () { try { const f = window.frameElement, P = window.parent; if (P && P !== window) setTimeout(function () { P.dispatchEvent(new Event('pt-frame-chrome')); }, 0); } catch (e) {} }, true);
});
