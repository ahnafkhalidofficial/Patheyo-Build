/* js/data/islamic-events.js */
/* =============================================================================
   ইসলামিক দিবস ও নোটিফিকেশন ডেটা
   ISLAMIC_NOTIFIER (বিশেষ দিনের তালিকা), হারাম রোজার দিন, গ্রেগরিয়ান/হিজরি/বাংলা মাসের নাম।
   ============================================================================= */

// --- Islamic Special Events & Notifications Engine ---
const ISLAMIC_NOTIFIER = {
    lastTriggered: "",
    check: function(now, hDate) {
        const timeKey = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
        const dateKey = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}`;
        const triggerId = `${dateKey}-${timeKey}`;
        if (this.lastTriggered === triggerId) return;

        let title = "", message = "", action = null;
        const hDay = hDate.day;
        const hMonth = hDate.month; // 0-indexed (8 = Ramadan, 9 = Shawwal, 11 = Dhul-Hijjah)

        // 1. Weekly Logic
        if (now.getDay() === 5 && timeKey === "11:00") {
            title = "পবিত্র জুম'আ ও সূরা কাহাফ";
            message = "আজ জুম'আর দিন। রাসূলুল্লাহ (সাঃ) বলেছেন, যে ব্যক্তি জুম'আর দিনে সূরা আল-কাহাফ পাঠ করবে, তার জন্য এক জুম'আ থেকে অন্য জুম'আ পর্যন্ত বিশেষ নূর চমকাতে থাকবে। সূরাটি পড়তে ভুলবেন না।";
            action = null;
        }
        if ((now.getDay() === 0 || now.getDay() === 3) && timeKey === "18:30") {
            title = "আগামীকাল সুন্নাত রোজা";
            message = `আগামীকাল ${now.getDay() === 0 ? 'সোমবার' : 'বৃহস্পতিবার'}। এই দুই দিন আল্লাহর কাছে আমল পেশ করা হয়। রাসূলুল্লাহ (সাঃ) এই দিনে রোজা রাখতেন। আপনি কি আগামীকাল রোজা রাখছেন?`;
        }

        // 2. Monthly Logic (12th sunset trigger for 13, 14, 15)
        if (hDay === 12 && timeKey === "18:45") {
            title = "আইয়ামে বিয-এর সুন্নাত রোজা";
            message = "আগামীকাল থেকে হিজরি মাসের ১৩, ১৪ ও ১৫ তারিখ। প্রতি মাসে এই তিন দিন (আইয়ামে বিয) রোজা রাখা পুরো বছর রোজা রাখার সমতুল্য। প্রস্তুতি নিন।";
        }

        // 3. Annual Logic (Specific Hijri Dates)
        const hKey = `${hMonth}-${hDay}`;
        const annuals = {
            "0-1": { t: "হিজরি নববর্ষ", m: "আজ ১লা মুহাররম। নতুন হিজরি বছরের সূচনা। আল্লাহ আমাদের এই নতুন বছরটি বরকতময় ও শান্তিময় করুন।", time: "18:20" },
            "0-8": { t: "পবিত্র আশুরার রোজা", m: "আগামীকাল ও পরশু (৯ ও ১০ই মুহাররম) আশুরার সুন্নাত রোজা। এই রোজার মাধ্যমে বিগত এক বছরের গুনাহ মাফ হয়।", time: "19:00" },
            "6-26": { t: "পবিত্র শবে মিরাজ", m: "আজ ২৬শে রজব দিবাগত রাত, পবিত্র শবে মিরাজ। এই রাতে ৫ ওয়াক্ত নামাজ ফরজ হয়েছিল। বেশি বেশি ইবাদত করুন।", time: "18:30" },
            "7-14": { t: "পবিত্র শবে বরাত", m: "আজ ১৪ই শাবান দিবাগত রাত, মহিমান্বিত শবে বরাত। এটি ইবাদত, ভাগ্য ও ক্ষমার রাত।", time: "18:30" },
            "9-1": { t: "ঈদ মোবারক!", m: "আজ ১লা শাওয়াল, পবিত্র ঈদুল ফিতর। আনন্দের দিন। আজ রোজা রাখা হারাম। আপনাকে ও আপনার পরিবারকে ঈদের শুভেচ্ছা।", time: "07:00" },
            "11-1": { t: "জিলহজ মাসের প্রথম দশক", m: "জিলহজ মাসের প্রথম ১০ দিন আল্লাহর কাছে বছরের সবচেয়ে প্রিয় দিন। এই দিনগুলোতে বেশি বেশি নফল ইবাদত ও জিকির করুন।", time: "18:30" },
            "11-8": { t: "আগামীকাল আরাফাহর রোজা", m: "আগামীকাল ৯ই জিলহজ, পবিত্র আরাফাহর দিন। এই ১টি রোজা বিগত ও আগামী বছরের গুনাহ খাতা মোচন করে।", time: "18:30" },
            "11-10": { t: "পবিত্র ঈদুল আজহা", m: "আজ ১০ই জিলহজ, খুশির ঈদ ও কোরবানির দিন। ত্যাগের মহিমায় উদ্ভাসিত হোক আপনার জীবন। আজ রোজা রাখা সম্পূর্ণ নিষিদ্ধ।", time: "07:00" }
        };

        const event = annuals[hKey];
        if (event && timeKey === (event.time || "08:00")) {   /* আগে time ঘর না থাকায় বার্ষিক দিনের বার্তা কখনো আসত না */
            title = event.t; message = event.m;
        }

        // Ramadan Daily & Lailatul Qadr
        if (hMonth === 8) {
            if (timeKey === "10:30") {
                title = "রমজান মোবারক";
                message = "আজ পবিত্র রমজানের দিন। ইসলামের অন্যতম স্তম্ভ ফরজ রোজা সঠিকভাবে পালন করুন এবং তাকওয়া অর্জন করুন।";
            }
            const qadrNights = [21, 23, 25, 27, 29];
            if (qadrNights.includes(hDay) && timeKey === "18:20") {
                title = "লাইলাতুল কদর তালাশ করুন";
                message = "আজ রমজানের সম্ভাব্য শবে কদরের রাত। এই রাতের ইবাদত হাজার মাসের ইবাদতের চেয়েও উত্তম। অবহেলায় রাতটি পার না করে ইবাদতে কাটান।";
            }
        }

        // Ayyam al-Tashreeq (11, 12, 13 Dhul-Hijjah)
        if (hMonth === 11 && [11, 12, 13].includes(hDay) && timeKey === "08:00") {
            title = "আইয়ামে তাশরিক";
            message = "আজ আইয়ামে তাশরিকের দিন। এই দিনগুলোতে রোজা রাখা কঠোরভাবে নিষিদ্ধ। প্রতি ফরজ নামাজের পর উচ্চস্বরে তাকবীরে তাশরিক পড়তে ভুলবেন না।";
        }

        if (title) {
            this.lastTriggered = triggerId;
            this.show(title, message, action);
        }
    },
    show: function(title, message, action) {
        const toast = document.getElementById('azan-toast-overlay');
        if (!toast) return;
        document.getElementById('toast-title').innerText = title;
        const tp = toast.querySelector('p'); if (!tp.dataset.orig) tp.dataset.orig = tp.innerText; tp.innerText = message;
        toast.classList.remove('hidden');

        if (action) {
            const btn = toast.querySelector('button');
            const originalText = btn.innerText;
            btn.innerText = "ঠিক আছে";
            const oldHandler = btn.onclick;
            btn.onclick = () => {
                action();
                toast.classList.add('hidden');
                btn.innerText = originalText;
                btn.onclick = oldHandler;
            };
        }

        if ('Notification' in window && Notification.permission === 'granted') {
            try { new Notification(title, { body: message, icon: window.__ASSET.logo }); } catch(e) {}
        }
        if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.showAzanNotification === 'function') {
            try { window.AndroidWidgetBridge.showAzanNotification("SpecialEvent", title + ": " + message); } catch(e) {}
        }
    }
};

function getHaramRozaStatus(hDate) {
    const m = hDate.month; const d = hDate.day;
    if (m === 9 && d === 1) return { label: "ঈদ মোবারক", msg: "আজ ঈদের দিন, রোজা রাখা হারাম" };
    if (m === 11 && d === 10) return { label: "ঈদ মোবারক", msg: "আজ কোরবানির ঈদ, রোজা হারাম" };
    if (m === 11 && [11, 12, 13].includes(d)) return { label: "তাশরিক", msg: "আজ আইয়ামে তাশরিক, রোজা হারাম" };
    return null;
}

const gregorianMonthsBN = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
const hijriMonthsBN = ["মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল উলা", "জমাদিউস সানি", "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"];
const banglaMonthsBN = ["বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন", "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"];

