
/*!
 * js/main.js -- Application entry point: parses the Quran data, builds the UI and starts the app
 *
 * Provides : (nothing -- entry point)
 * Needs    : core/dom, core/state, features/events, features/last-read, features/lists (সূরা/পারা/তরজমা তালিকা),
               features/theme, services/pdf-service
 */
(function (App) {
  "use strict";

  function init(){
    try{
      // Fast parse: the data file is a flat, machine-written XML (<sura ...><aya index text [bismillah] /></sura>), so plain
      // regular expressions are several times quicker than DOMParser + DOM walking, with the same result.
      var xmlText = App.quranXml;
      function unesc(t){ return t.indexOf('&') === -1 ? t : t.replace(/&quot;/g,'"').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&apos;/g,"'").replace(/&amp;/g,'&'); }
      var suraRe = /<sura index="(\d+)" name="([^"]*)">([\s\S]*?)<\/sura>/g, sm, totalAyahs = 0;
      var ayaRe = /<aya index="(\d+)" text="([^"]*)"(?: bismillah="([^"]*)")? \/>/g, am;
      while ((sm = suraRe.exec(xmlText))){
        var ayahs = [];
        ayaRe.lastIndex = 0;
        var body = sm[3];
        while ((am = ayaRe.exec(body))){
          ayahs.push({ index: +am[1], text: unesc(am[2]), bismillah: am[3] ? unesc(am[3]) : null });
        }
        totalAyahs += ayahs.length;
        App.quranModel.push({ index: +sm[1], name: unesc(sm[2]), ayahs: ayahs });
      }
      if (App.quranModel.length !== 114 || totalAyahs !== 6236){
        throw new Error('কুরআন ডেটা পার্স করা যায়নি।');
      }
      App.els.loading.classList.add('hidden');
      App.renderSuraList();
      App.renderParaList();
      App.showContinueCard();
      App.els.suraPanel.classList.remove('hidden');
      App.bindEvents();
      // Start loading the Quran font right away (small local file), so the first sura opens without a font swap / re-flow.
      function preloadFont(){ try { if (document.fonts && document.fonts.load) document.fonts.load("25px 'Uthmanic Hafs'", '\u0627\u0644\u0645').catch(function(){}); } catch(e){} }
      if (document.readyState === 'complete') setTimeout(preloadFont, 0); else window.addEventListener('load', function(){ setTimeout(preloadFont, 0); });
      // Background warm-up AFTER the first screen is interactive (never on the critical path):
      //  - the Mushaf PDF (so "আসল মুসহাফে পড়ুন" opens fast) and the downloaded translation file (so তরজমা opens fast)
      setTimeout(function(){
        /* ধাপ ১২: মুসহাফ ডাউনলোড করা থাকলে তবেই (নইলে pdf.js-এর ~১.৩ MB অকারণে পড়া হতো) */
        var dlp = App.pdfDownload, hasPdf = false;
        try { hasPdf = !!(dlp && dlp.isReady && dlp.isReady()); } catch(e){}
        if (hasPdf) App.ensurePdfLoaded().catch(function(){ /* handled lazily when the user opens a Para */ });
        try { if (App.tarjamaDownload && App.tarjamaDownload.hasNative() && App.tarjamaDownload.isReady()) App.tarjamaData.load().catch(function(){}); } catch(e){}
      }, 2500);
    } catch(err){
      App.els.loading.classList.add('hidden');
      App.els.errorBox.classList.remove('hidden');
      App.els.errorBox.textContent = 'দুঃখিত, কুরআন ডেটা লোড করা যায়নি। (' + err.message + ')';
    }
  }

  var savedTheme = 'light';

  try{ savedTheme = localStorage.getItem('quran-theme') || 'light'; } catch(e){}

  App.setTheme(savedTheme);

  // Two animation frames guarantee the browser has actually painted the "কুরআন ডেটা
  // প্রস্তুত হচ্ছে..." loading state before the heavy, synchronous XML parse in init()
  // blocks the main thread. Without this the loading text never gets a chance to render
  // and the app appears to freeze/flash instead of showing a smooth loading state.
  requestAnimationFrame(function(){
    requestAnimationFrame(init);
  });

})(window.QuranApp = window.QuranApp || {});

