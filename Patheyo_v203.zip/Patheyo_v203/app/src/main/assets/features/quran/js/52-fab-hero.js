/* ধাপ ১৩: পড়ার পেজের মাথায় (সূরার নাম, আয়াত/রুকু/অবতীর্ণের কার্ড) থাকা অবস্থায় ভাসমান সার্চ/বুকমার্ক বোতাম লুকিয়ে রাখা —
   ছোট ফোনে বোতাম কার্ডের তৃতীয় তথ্যের ("মক্কী/মাদানী") ওপর বসে যেত। একটু নিচে নামলে (পড়া শুরু হলে) মসৃণভাবে আসে। */
(function (App) {
  'use strict';
  var root = document.documentElement, raf = 0, READ = { 'sura-reader': 1, 'tr-reader': 1, 'para-web': 1, 'web-reader': 1 };
  function sync() {
    raf = 0;
    var v = App.state && App.state.view;
    root.classList.toggle('qr-hero-on', !!READ[v] && (window.pageYOffset || 0) < 240);
  }
  function soon() { if (!raf) raf = requestAnimationFrame(sync); }
  window.addEventListener('scroll', soon, { passive: true });
  window.addEventListener('popstate', soon);
  if (window.MutationObserver) new MutationObserver(soon).observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class'] });
  setInterval(soon, 1500);        /* ভিউ বদলের আরেকটা নিরাপদ পথ (খুব হালকা) */
})(window.QuranApp = window.QuranApp || {});
