/* কুরআন — তিলাওয়াত শোনা (ইন-অ্যাপ প্লেয়ার)।
   অডিও অ্যাপে বান্ডেল নেই (APK-র সাইজ বাড়ে না) — প্রতিটা আয়াতের আলাদা MP3 ইন্টারনেট থেকে চলে (everyayah.com, ফাইল-নাম SSSAAA.mp3)।
   - সূরা-পাঠ ও তরজমা-পাঠ দুই পেজেই চলে; চলতি আয়াত হাইলাইট হয় ও লেখা সাথে সাথে স্ক্রল করে (বন্ধ করা যায়)।
   - মিনি-প্লেয়ার (নিচে) + বড় প্লেয়ার (তিলাওয়াতকারী বাছাই, গতি, রিপিট, ঘুমের টাইমার)।
   - ফাতিহার সংখ্যা-মিল: everyayah-তে ০০১০০১ = বিসমিল্লাহ, ০০১০০২–০০১০০৬ = আয়াত ১–৫, ০০১০০৭ = আয়াত ৬ ও ৭ একসাথে (নিচের buildQueue দেখুন)।
   - তিলাওয়াতের সূত্র: everyayah.com — অ্যাপের ভেতরে ক্রেডিট দেখানো হয়।
   - v168: Android অ্যাপে নেটিভ ব্যাকগ্রাউন্ড প্লেয়ার (window.PatheyoQuranAudio → Kotlin Media3 সার্ভিস): স্ক্রিন বন্ধ/অ্যাপ মিনিমাইজ থাকলেও চলে,
           নোটিফিকেশনে প্লে-পজ-আগের-পরের। রিপিট/গতি/ঘুমের টাইমারও নেটিভে চলে। ব্রাউজারে বা নেটিভ ব্যর্থ হলে আগের HTML অডিও।
   - v168: সূরা অফলাইনে ডাউনলোড (শুধু সূরা অডিও): সূরার হিরো-বোতাম ও বড় প্লেয়ারের "অফলাইন" অংশ থেকে; নেটিভ স্টোরেজে থাকে, প্লেয়ার আগে লোকাল ফাইল খোঁজে। */
(function (App) {
  'use strict';
  var BASE = 'https://everyayah.com/data/';
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function $(id) { return document.getElementById(id); }
  function pad3(n) { return ('00' + n).slice(-3); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* তিলাওয়াতকারী — পূর্ণ নাম (ফোল্ডার-নাম everyayah.com-এর তালিকা থেকে মিলিয়ে নেওয়া) */
  var RECITERS = [
    { id: 'alafasy',   n: 'মিশারি ইবনে রাশিদ আল-আফাসি',        sub: 'কুয়েত',                         f: 'Alafasy_128kbps',                       k: 128 },
    { id: 'abdulbasit',n: 'আব্দুল বাসিত মুহাম্মাদ আব্দুস সামাদ (মুরাত্তাল)', sub: 'মিসর',               f: 'Abdul_Basit_Murattal_192kbps',          k: 192 },
    { id: 'abdulbasitm',n:'আব্দুল বাসিত মুহাম্মাদ আব্দুস সামাদ (মুজাওয়াদ)', sub: 'মিসর',               f: 'Abdul_Basit_Mujawwad_128kbps',          k: 128 },
    { id: 'sudais',    n: 'আব্দুর রহমান ইবনে আব্দুল আযীয আস-সুদাইস', sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Abdurrahmaan_As-Sudais_192kbps',  k: 192 },
    { id: 'shuraim',   n: 'সউদ ইবনে ইবরাহীম আশ-শুরাইম',          sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Saood_ash-Shuraym_128kbps',       k: 128 },
    { id: 'juhany',    n: 'আব্দুল্লাহ আওয়াদ আল-জুহানি',          sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Abdullaah_3awwaad_Al-Juhaynee_128kbps', k: 128 },
    { id: 'maher',     n: 'মাহির ইবনে হামাদ আল-মুআইকিলি',        sub: 'মসজিদুল হারামের (মক্কা) ইমাম', f: 'Maher_AlMuaiqly_64kbps',          k: 64 },
    { id: 'husary',    n: 'মাহমুদ খলিল আল-হুসারি',                sub: 'মিসর',                           f: 'Husary_128kbps',                        k: 128 },
    { id: 'hudhaify',  n: 'আলী ইবনে আব্দুর রহমান আল-হুযাইফি',     sub: 'মসজিদে নববীর (মদিনা) ইমাম',       f: 'Hudhaify_128kbps',                      k: 128 },
    { id: 'ayyoub',    n: 'মুহাম্মাদ আইয়ুব',                      sub: 'মসজিদে নববীর (মদিনা) ইমাম',       f: 'Muhammad_Ayyoub_128kbps',               k: 128 },
    { id: 'minshawi',  n: 'মুহাম্মাদ সিদ্দিক আল-মিনশাবি (মুরাত্তাল)', sub: 'মিসর',                         f: 'Minshawy_Murattal_128kbps',             k: 128 },
    { id: 'shatri',    n: 'আবু বকর আশ-শাত্রি',                    sub: '',                               f: 'Abu_Bakr_Ash-Shaatree_128kbps',         k: 128 },
    { id: 'basfar',    n: 'আব্দুল্লাহ বাসফার',                     sub: '',                               f: 'Abdullah_Basfar_192kbps',               k: 192 },
    { id: 'rifai',     n: 'হানি আর-রিফাঈ',                         sub: '',                               f: 'Hani_Rifai_192kbps',                    k: 192 }
  ];
  function reciterById(id) { for (var i = 0; i < RECITERS.length; i++) if (RECITERS[i].id === id) return RECITERS[i]; return RECITERS[0]; }
  function shortName(r) { var p = r.n.replace(/\s*\(.*\)\s*$/, '').split(' '); return p.slice(-2).join(' '); }

  var REPEATS = [['off', 'বন্ধ'], ['a2', 'আয়াত ২ বার'], ['a3', 'আয়াত ৩ বার'], ['a5', 'আয়াত ৫ বার'], ['ainf', 'আয়াত ∞'], ['sinf', 'পুরো সূরা ∞']];
  var SPEEDS = [0.75, 1, 1.25, 1.5];
  var SLEEPS = [[0, 'বন্ধ'], [15, '১৫ মি.'], [30, '৩০ মি.'], [45, '৪৫ মি.'], [60, '৬০ মি.']];
  var KEY = 'pt_qa_prefs';
  var P = { reciter: 'alafasy', speed: 1, repeat: 'off', follow: true };
  try { var sv = JSON.parse(localStorage.getItem(KEY) || 'null'); if (sv) { if (sv.reciter) P.reciter = sv.reciter; if (SPEEDS.indexOf(sv.speed) > -1) P.speed = sv.speed; if (sv.repeat) P.repeat = sv.repeat; if (typeof sv.follow === 'boolean') P.follow = sv.follow; } } catch (e) {}
  function savePrefs() { try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) {} }

  var S = { sura: 0, queue: [], i: -1, playing: false, rep: 0, err: 0, sleepAt: 0, sleepT: 0, hiddenPause: false };
  var audio = new Audio(); audio.preload = 'auto';
  var pre = new Audio(); pre.preload = 'metadata';          /* পরের আয়াত শুধু শুরুটা আগে ছুঁয়ে রাখি — পুরোটা দুইবার নামে না (ডেটা বাঁচাতে) */
  var UI = null, userScrollUntil = 0;
  /* Android অ্যাপে নেটিভ প্লেয়ার থাকলে সেটাই চালায় (এই ফ্রেম srcdoc, তাই ব্রিজ প্যারেন্ট উইন্ডো থেকেও নেওয়া হয়) */
  var NA = null;
  try { var nb = window.PatheyoQuranAudio || (window.parent && window.parent.PatheyoQuranAudio); if (nb && typeof nb.isAvailable === 'function' && nb.isAvailable()) NA = nb; } catch (e) {}

  /* ---------- কিউ: সূরার প্লে-তালিকা ---------- */
  function buildQueue(sura) {
    var q = [], n = App.quranModel[sura - 1].ayahs.length;
    if (sura !== 9) q.push({ t: 'bis', file: '001001', covers: [] });
    for (var a = 1; a <= n; a++) {
      if (sura === 1) {                       /* হাফস গণনা ↔ everyayah ফাইল: ১–৫ → ০০২–০০৬, ৬+৭ → ০০৭ */
        if (a <= 5) q.push({ t: 'ayah', file: pad3(1) + pad3(a + 1), covers: [a], ayah: a });
        else if (a === 6) q.push({ t: 'ayah', file: '001007', covers: [6, 7], ayah: 6 });
      } else q.push({ t: 'ayah', file: pad3(sura) + pad3(a), covers: [a], ayah: a });
    }
    return q;
  }
  function urlOf(item) { return BASE + reciterById(P.reciter).f + '/' + (item.t === 'bis' ? '001001' : item.file) + '.mp3'; }
  function indexOfAyah(q, a) { for (var i = 0; i < q.length; i++) if (q[i].covers.indexOf(a) > -1) return i; return 0; }

  /* ---------- চালানো ---------- */
  function playFrom(sura, ayah) {
    sura = +sura; ayah = +ayah || 1;
    if (!App.quranModel[sura - 1]) return;
    ensureUI();
    S.sura = sura; S.queue = buildQueue(sura);
    S.i = ayah > 1 ? indexOfAyah(S.queue, ayah) : 0;
    S.rep = 0; S.err = 0; S.hiddenPause = false;
    startItem();
    show(true);
  }
  function playSura(sura) {
    if (S.sura === +sura && S.i > -1 && S.queue.length) { toggle(); return; }
    playFrom(sura, 1);
  }
  function whereOf(it, total) { return it ? (it.t === 'bis' ? 'বিসমিল্লাহ' : 'আয়াত ' + bn(it.covers.length > 1 ? it.covers[0] + '–' + it.covers[1] : it.ayah) + '/' + bn(total)) : ''; }
  /* নেটিভ প্লেয়ারকে পুরো সূরার প্লে-তালিকা দেওয়া (রিপিট/গতি সহ) — এরপর পরের আয়াতে যাওয়া নেটিভই করে, JS ঘুমিয়ে থাকলেও */
  function nativeStart() {
    var r = reciterById(P.reciter), mdl = App.quranModel[S.sura - 1], total = mdl ? mdl.ayahs.length : 0, ttl = 'সূরা ' + (App.SURAH_BN[S.sura - 1] || '');
    var items = S.queue.map(function (it) {
      return { u: urlOf(it), f: r.f, n: it.t === 'bis' ? '001001' : it.file, t: ttl, s: whereOf(it, total), r: it.t === 'ayah' };
    });
    S.playing = true; S.err = 0; refreshUI(); applyHighlight(true);
    try { NA.load(JSON.stringify(items), S.i, P.repeat, P.speed, shortName(r)); }
    catch (e) { NA = null; startItem(); }
  }
  function goNext() { if (NA) { try { NA.next(); } catch (e) {} return; } S.rep = 0; if (S.i + 1 < S.queue.length) { S.i++; startItem(); } }
  function startItem() {
    var it = S.queue[S.i]; if (!it) return;
    if (NA) { nativeStart(); return; }
    audio.src = urlOf(it); audio.playbackRate = P.speed; try { audio.preservesPitch = true; } catch (e) {}
    var pr = audio.play(); S.playing = true;
    if (pr && pr.catch) pr.catch(function () { if (!S.err) { S.err = 1; setTimeout(function () { audio.load(); audio.play().catch(onFail); }, 500); } else onFail(); });
    var nx = S.queue[S.i + 1]; if (nx) pre.src = urlOf(nx);          /* পরেরটা আগে থেকে নামিয়ে রাখি, যাতে মাঝে থামতে না হয় */
    refreshUI(); applyHighlight(true);
  }
  function onFail() {
    S.playing = false; refreshUI(); msg('তিলাওয়াত লোড হয়নি — ইন্টারনেট সংযোগ দেখুন, তারপর আবার চালান');
  }
  function next(auto) {
    var it = S.queue[S.i], rp = P.repeat;
    if (auto && it) {                         /* রিপিটের নিয়ম */
      if (rp === 'ainf') { S.rep++; startItem(); return; }
      if ((rp === 'a2' || rp === 'a3' || rp === 'a5') && it.t === 'ayah') {
        var times = +rp.slice(1);
        if (S.rep + 1 < times) { S.rep++; startItem(); return; }
      }
    }
    S.rep = 0;
    if (S.i + 1 < S.queue.length) { S.i++; startItem(); return; }
    if (P.repeat === 'sinf') { S.i = 0; startItem(); return; }
    S.playing = false; S.i = S.queue.length - 1; refreshUI(); applyHighlight(false); msg('সূরা শেষ হয়েছে');
  }
  function prev() {
    if (NA) { try { NA.prev(); } catch (e) {} return; }
    if (audio.currentTime > 3) { audio.currentTime = 0; return; }
    S.rep = 0; if (S.i > 0) { S.i--; startItem(); } else audio.currentTime = 0;
  }
  function toggle() {
    if (S.i < 0) return;
    if (NA) { try { NA.toggle(); } catch (e) {} return; }
    if (S.playing) { audio.pause(); S.playing = false; } else { var pr = audio.play(); S.playing = true; if (pr && pr.catch) pr.catch(onFail); S.hiddenPause = false; }
    refreshUI();
  }
  function stop() {
    if (NA) { try { NA.stop(); } catch (e) {} }
    audio.pause(); S.playing = false; S.i = -1; S.queue = []; S.sura = 0; clearSleep();
    clearHighlight(); show(false); closeSheet();
  }
  audio.addEventListener('ended', function () { next(true); });
  audio.addEventListener('error', function () { if (!S.playing) return; if (!S.err) { S.err = 1; setTimeout(function () { audio.load(); audio.play().catch(onFail); }, 600); } else onFail(); });
  audio.addEventListener('playing', function () { S.err = 0; S.playing = true; refreshUI(); });
  audio.addEventListener('timeupdate', function () { if (UI && audio.duration) UI.bar.style.width = Math.min(100, audio.currentTime / audio.duration * 100) + '%'; if (UI && UI.open) { var pu = UI.sheet.querySelector('.qa-pg u'), pk = UI.sheet.querySelector('.qa-pg i'), pv = prog(); if (pu) pu.style.width = pv + '%'; if (pk) pk.style.left = pv + '%'; } });

  /* ---------- হাইলাইট ও স্ক্রল ---------- */
  function currentCovers() { var it = S.queue[S.i]; return it && it.t === 'ayah' ? it.covers : []; }
  function clearHighlight() {
    try { if (window.CSS && CSS.highlights) CSS.highlights.delete('pt-qa'); } catch (e) {}
    Array.prototype.forEach.call(document.querySelectorAll('.qa-playing,.qa-num-on'), function (e) { e.classList.remove('qa-playing', 'qa-num-on'); });
  }
  function openSuraNow() {
    if (App.els.readerPanel && !App.els.readerPanel.classList.contains('hidden')) return { k: 'flow', s: App.currentOpenSuraIndex };
    if (App.els.trReaderPanel && !App.els.trReaderPanel.classList.contains('hidden')) {
      var f = App.els.trVerses.querySelector('.tr-ayah'); return f ? { k: 'tr', s: +f.getAttribute('data-sura') } : null;
    }
    return null;
  }
  function applyHighlight(scroll) {
    clearHighlight();
    var cv = currentCovers(), o = openSuraNow();
    if (!cv.length || !o || o.s !== S.sura) return;
    var first = cv[0], last = cv[cv.length - 1], target = null;
    if (o.k === 'tr') {
      cv.forEach(function (a) { var e = $('trayah-' + a); if (e) { e.classList.add('qa-playing'); if (!target) target = e; } });
    } else {
      var endEl = $('ayah-' + S.sura + '-' + last), prevEl = first > 1 ? $('ayah-' + S.sura + '-' + (first - 1)) : null;
      if (endEl) {
        endEl.classList.add('qa-num-on'); target = endEl;
        try {
          if (window.CSS && CSS.highlights && window.Highlight) {
            var r = document.createRange();
            if (prevEl) r.setStartAfter(prevEl);
            else {
              var w = document.createTreeWalker(App.els.verses, NodeFilter.SHOW_TEXT, null), tn;
              while ((tn = w.nextNode())) { if (tn.nodeValue.replace(/\s+/g, '')) break; }
              if (tn) r.setStart(tn, 0); else r.setStartBefore(endEl);
            }
            r.setEndBefore(endEl);
            CSS.highlights.set('pt-qa', new Highlight(r));
          }
        } catch (e) {}
      }
    }
    if (scroll && target && P.follow && Date.now() > userScrollUntil) { try { target.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) {} }
  }
  ['wheel', 'touchmove'].forEach(function (ev) { window.addEventListener(ev, function () { userScrollUntil = Date.now() + 6000; }, { passive: true }); });

  /* ---------- UI ---------- */
  var PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.4-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>';
  var PAUSE = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="5" width="4.2" height="14" rx="1.4"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.4"/></svg>';
  var PREV = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5.5v13M19 6.2v11.6a.8.8 0 0 1-1.25.66L9.6 12.66a.8.8 0 0 1 0-1.32l8.15-5.8A.8.8 0 0 1 19 6.2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var NEXT = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 5.5v13M5 6.2v11.6a.8.8 0 0 0 1.25.66l8.15-5.8a.8.8 0 0 0 0-1.32l-8.15-5.8A.8.8 0 0 0 5 6.2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var X = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>';
  var UP = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 14 6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function ensureUI() {
    if (UI) return;
    var mini = document.createElement('div'); mini.className = 'qa-mini'; mini.hidden = true;
    mini.innerHTML =
      '<i class="qa-bar"><u></u></i>' +
      '<button type="button" class="qa-ex" aria-label="প্লেয়ার বড় করুন">' + UP + '</button>' +
      '<div class="qa-info"><b class="qa-t"></b><small class="qa-s"></small></div>' +
      '<div class="qa-ctl"><button type="button" class="qa-b" data-c="prev" aria-label="আগের">' + PREV + '</button>' +
      '<button type="button" class="qa-b main" data-c="toggle" aria-label="চালান/থামান">' + PLAY + '</button>' +
      '<button type="button" class="qa-b" data-c="next" aria-label="পরের">' + NEXT + '</button>' +
      '<button type="button" class="qa-b x" data-c="stop" aria-label="বন্ধ করুন">' + X + '</button></div>' +
      '<div class="qa-msg" role="status"></div>';
    document.body.appendChild(mini);
    var veil = document.createElement('div'); veil.className = 'qa-veil';
    var sheet = document.createElement('div'); sheet.className = 'qa-sheet'; sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'তিলাওয়াত প্লেয়ার');
    document.body.appendChild(veil); document.body.appendChild(sheet);
    UI = { mini: mini, bar: mini.querySelector('.qa-bar u'), t: mini.querySelector('.qa-t'), s: mini.querySelector('.qa-s'), main: mini.querySelector('.main'), m: mini.querySelector('.qa-msg'), veil: veil, sheet: sheet, open: false };
    mini.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
      if (b.classList.contains('qa-ex')) { openSheet(); return; }
      var c = b.getAttribute('data-c');
      if (c === 'toggle') toggle(); else if (c === 'next') goNext(); else if (c === 'prev') prev(); else if (c === 'stop') stop();
    });
    mini.querySelector('.qa-info').addEventListener('click', openSheet);
    veil.addEventListener('click', closeSheet);
    sheet.addEventListener('click', onSheetClick);
    sheet.addEventListener('change', function (e) { if (e.target.id === 'qa-rec') { P.reciter = e.target.value; savePrefs(); renderSheet(); if (S.i > -1) { var keep = S.i; S.queue = buildQueue(S.sura); S.i = Math.min(keep, S.queue.length - 1); startItem(); } } });
    window.addEventListener('popstate', function () { if (UI && UI.open) hideSheet(); });
    setInterval(function () {                 /* কুরআন পেজ বন্ধ হলে তিলাওয়াত থামিয়ে দিই (ভুলে ব্যাকগ্রাউন্ডে বাজতে না থাকে) */
      if (!S.playing || NA) return;           /* নেটিভ প্লেয়ারে: পেজ বন্ধ করলেও ব্যাকগ্রাউন্ডে চলতে থাকবে (নোটিফিকেশন থেকে বন্ধ হয়) */
      try { var ov = window.frameElement && window.frameElement.parentElement; if (ov && (ov.hasAttribute('inert') || ov.getAttribute('aria-hidden') === 'true')) { audio.pause(); S.playing = false; S.hiddenPause = true; refreshUI(); } } catch (e) {}
    }, 900);
    setInterval(function () { if (S.playing) applyHighlight(false); }, 1500);       /* পড়ার পেজ বদলালে/ধীরে আঁকা শেষ হলে হাইলাইট ঠিক করে নিই */
  }
  function show(on) { ensureUI(); UI.mini.hidden = !on; document.documentElement.classList.toggle('qa-on', !!on); }
  var msgT = 0;
  function msg(t) { ensureUI(); UI.m.textContent = t; UI.m.classList.add('show'); clearTimeout(msgT); msgT = setTimeout(function () { UI.m.classList.remove('show'); }, 3500); }
  function refreshUI() {
    if (!UI) return;
    var it = S.queue[S.i], total = App.quranModel[S.sura - 1] ? App.quranModel[S.sura - 1].ayahs.length : 0, r = reciterById(P.reciter);
    var where = whereOf(it, total);
    UI.t.textContent = 'সূরা ' + (App.SURAH_BN[S.sura - 1] || '');
    UI.s.textContent = where + ' · ' + shortName(r);
    UI.where = where;
    UI.main.innerHTML = S.playing ? PAUSE : PLAY;
    if (UI.open) renderSheet();
  }

  /* ---------- বড় প্লেয়ার (শিট) ---------- */
  function openSheet() {
    ensureUI(); if (UI.open) return;
    UI.open = true; try { history.pushState({ qaSheet: 1 }, ''); } catch (e) {}
    renderSheet(); UI.veil.classList.add('on'); UI.sheet.classList.add('on'); UI.sheet.scrollTop = 0;
  }
  function hideSheet() { if (!UI || !UI.open) return; UI.open = false; UI.veil.classList.remove('on'); UI.sheet.classList.remove('on'); }
  function closeSheet() { if (!UI || !UI.open) return; if (history.state && history.state.qaSheet) history.back(); else hideSheet(); }
  function chips(list, cur, k) { return list.map(function (x) { var v = Array.isArray(x) ? x[0] : x, l = Array.isArray(x) ? x[1] : bn(x) + '×'; return '<button type="button" class="qa-chip' + (String(v) === String(cur) ? ' on' : '') + '" data-k="' + k + '" data-v="' + v + '">' + l + '</button>'; }).join(''); }
  var IC = {
    mic: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/></svg>',
    speed: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 17a8 8 0 1 1 15 0M12 13l4-4"/></svg>',
    rep: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17 3l3 3-3 3M4 11V9a3 3 0 0 1 3-3h13M7 21l-3-3 3-3M20 13v2a3 3 0 0 1-3 3H4"/></svg>',
    moon: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>',
    scroll: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v16M8 8l4-4 4 4M8 16l4 4 4-4"/></svg>'
  };
  function prog() {
    var n = S.queue.length; if (!n || S.i < 0) return 0;
    var f = (audio && audio.duration && isFinite(audio.duration)) ? Math.min(1, audio.currentTime / audio.duration) : 0;
    return Math.min(100, (S.i + f) / n * 100);
  }
  function seg(list, cur, k, fmt) {
    return '<div class="qa-seg" role="group">' + list.map(function (x) {
      var v = Array.isArray(x) ? x[0] : x, l = Array.isArray(x) ? x[1] : fmt(x);
      return '<button type="button" class="qa-sg' + (String(v) === String(cur) ? ' on' : '') + '" data-k="' + k + '" data-v="' + v + '">' + l + '</button>';
    }).join('') + '</div>';
  }
  function row(ic, label, body, extra) { return '<div class="qa-row"><div class="qa-rl">' + IC[ic] + '<span>' + label + '</span>' + (extra || '') + '</div>' + body + '</div>'; }
  function calli(n) {
    var v = App.SURAH_VB && App.SURAH_VB[n]; if (!v) return '';
    return '<svg class="qa-cal" viewBox="' + v.join(' ') + '" aria-hidden="true" focusable="false"><use href="#sn' + n + '"></use></svg>';
  }
  function renderSheet() {
    var r = reciterById(P.reciter), left = S.sleepAt ? Math.max(0, Math.ceil((S.sleepAt - Date.now()) / 60000)) : 0;
    var opts = RECITERS.map(function (x) { return '<option value="' + x.id + '"' + (x.id === P.reciter ? ' selected' : '') + '>' + esc(x.n + (x.sub ? ' — ' + x.sub : '') + (x.k < 128 ? ' (' + bn(x.k) + 'kbps)' : '')) + '</option>'; }).join('');
    var repShort = [['off', 'বন্ধ'], ['a2', '২ বার'], ['a3', '৩ বার'], ['a5', '৫ বার'], ['ainf', 'আয়াত ∞'], ['sinf', 'সূরা ∞']];
    var total = (S.sura && App.quranModel[S.sura - 1]) ? App.quranModel[S.sura - 1].ayahs.length : 0;
    var pg = prog();
    UI.sheet.innerHTML =
      '<div class="qa-grab"></div><div class="qa-hd"><div class="qa-ht">তিলাওয়াত</div><button type="button" class="qa-x" data-act="close" aria-label="বন্ধ করুন">' + X + '</button></div>' +
      (S.sura ? '<div class="qa-hero2"><i class="qa-orb a"></i><i class="qa-orb b"></i>' +
        '<div class="qa-top"><span class="qa-eyebrow">' + (S.playing ? '<i class="qa-eq"><b></b><b></b><b></b></i>এখন চলছে' : 'থামানো আছে') + '</span><span class="qa-no">সূরা ' + bn(S.sura) + '</span></div>' +
        calli(S.sura) +
        '<b class="qa-sn">' + esc(App.SURAH_BN[S.sura - 1] || '') + '</b>' +
        '<span class="qa-rc">' + IC.mic + esc(shortName(r)) + '</span>' +
        '<div class="qa-pg"><u style="width:' + pg + '%"></u><i style="left:' + pg + '%"></i></div>' +
        '<div class="qa-pt"><span>' + esc(UI.where || '') + '</span><span>' + (total ? 'মোট ' + bn(total) + ' আয়াত' : '') + '</span></div></div>' +
      '<div class="qa-big">' +
        '<button type="button" class="qa-bb" data-act="prev" aria-label="আগের">' + PREV + '</button>' +
        '<button type="button" class="qa-bb main" data-act="toggle" aria-label="চালান/থামান">' + (S.playing ? PAUSE : PLAY) + '</button>' +
        '<button type="button" class="qa-bb" data-act="next" aria-label="পরের">' + NEXT + '</button></div>' : '') +
      '<div class="qa-set">' +
        '<div class="qa-rec"><span class="qa-av">' + esc((r.n || 'ক').replace(/^\s+/, '').charAt(0)) + '</span><span class="qa-ri"><small>তিলাওয়াতকারী</small><b>' + esc(shortName(r)) + '</b>' + (r.sub ? '<em>' + esc(r.sub) + '</em>' : '') + '</span>' +
          '<svg class="qa-chev" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>' +
          '<select id="qa-rec" class="qa-sel" aria-label="তিলাওয়াতকারী বদলান">' + opts + '</select></div>' +
        (S.sura ?
          row('speed', 'গতি', seg(SPEEDS, P.speed, 'speed', function (v) { return bn(v) + '×'; })) +
          row('rep', 'রিপিট', seg(repShort, P.repeat, 'repeat')) +
          row('moon', 'ঘুমের টাইমার', seg(SLEEPS, S.sleepMin || 0, 'sleep'), left ? '<em class="qa-left">আর ' + bn(left) + ' মিনিট</em>' : '') +
          '<div class="qa-row qa-tgrow"><div class="qa-rl">' + IC.scroll + '<span>লেখা অনুসরণ<small>তিলাওয়াতের সাথে পড়ার লেখা স্ক্রল হবে</small></span></div>' +
            '<button type="button" class="qa-tg' + (P.follow ? ' on' : '') + '" role="switch" aria-checked="' + (P.follow ? 'true' : 'false') + '" aria-label="লেখা অনুসরণ" data-k="follow" data-v="1"><i></i></button></div>'
        : '') +
      '</div>' +
      (NA ? '<div class="qa-off">' + offlineSheetHtml() + '</div>' : '') +
      '<p class="qa-credit">তিলাওয়াতের সূত্র: <b>everyayah.com</b> — ' + esc(r.n) + '। ' + (NA ? 'অফলাইনে রাখা সূরা ফোনের স্টোরেজে থাকে, বাকিটা ইন্টারনেট থেকে চলে।' : 'অডিও ইন্টারনেট থেকে চলে, ফোনে জমা থাকে না।') + '</p>';
  }
  function setSleep(min) {
    clearSleep(); S.sleepMin = min;
    if (NA) {                                 /* নেটিভে টাইমার চলে — JS ঘুমিয়ে থাকলেও ঠিক সময়ে থামবে */
      try { NA.setSleep(min || 0); } catch (e) {}
      S.sleepMin = min; S.sleepAt = min ? Date.now() + min * 60000 : 0;
      return;
    }
    if (min) { S.sleepAt = Date.now() + min * 60000; S.sleepT = setTimeout(function () { audio.pause(); S.playing = false; S.sleepAt = 0; S.sleepMin = 0; refreshUI(); msg('ঘুমের টাইমার শেষ — তিলাওয়াত থেমেছে'); }, min * 60000); }
  }
  function clearSleep() { clearTimeout(S.sleepT); S.sleepAt = 0; S.sleepMin = 0; }
  function onSheetClick(e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    var a = b.getAttribute('data-act'), k = b.getAttribute('data-k'), v = b.getAttribute('data-v');
    if (a === 'close') closeSheet(); else if (a === 'toggle') toggle(); else if (a === 'prev') prev(); else if (a === 'next') goNext()
    else if (a === 'dl') dlTap(+b.getAttribute('data-sura'))
    else if (a === 'dldel') dlDelTap(b.getAttribute('data-r'), +b.getAttribute('data-s'))
    else if (a === 'dldelall') dlDelAllTap()
    else if (k === 'speed') { P.speed = +v; audio.playbackRate = P.speed; if (NA) { try { NA.setSpeed(P.speed); } catch (e) {} } savePrefs(); renderSheet(); }
    else if (k === 'repeat') { P.repeat = v; S.rep = 0; if (NA) { try { NA.setRepeat(P.repeat); } catch (e) {} } savePrefs(); renderSheet(); }
    else if (k === 'sleep') { setSleep(+v); renderSheet(); }
    else if (k === 'follow') { P.follow = !P.follow; savePrefs(); renderSheet(); if (P.follow) applyHighlight(true); }
  }

  /* ---------- নেটিভ প্লেয়ারের ইভেন্ট (Kotlin → window.__quranAudioEvent → QuranAudio._onNative) ---------- */
  function onNative(ev) {
    if (!ev) return;
    if (ev.k === 'dl') { onDl(ev); return; }
    if (ev.k === 'st') {
      if (ev.has === false) { if (S.i > -1 && S.queue.length) { S.playing = false; refreshUI(); } return; }
      S.playing = !!ev.playing;
      if (typeof ev.qi === 'number' && ev.qi > -1 && ev.qi < S.queue.length && ev.qi !== S.i) { S.i = ev.qi; S.rep = ev.rep || 0; refreshUI(); applyHighlight(true); }
      else { S.rep = ev.rep || 0; refreshUI(); }
      return;
    }
    if (ev.k === 'pos') { if (UI && ev.dur) UI.bar.style.width = Math.min(100, ev.pos / ev.dur * 100) + '%'; return; }
    if (ev.k === 'ended') { S.playing = false; refreshUI(); applyHighlight(false); msg('সূরা শেষ হয়েছে'); return; }
    if (ev.k === 'sleep') { S.sleepAt = 0; S.sleepMin = 0; S.playing = false; refreshUI(); msg('ঘুমের টাইমার শেষ — তিলাওয়াত থেমেছে'); return; }
    if (ev.k === 'error') {
      if (ev.code === 'service') { NA = null; if (S.i > -1) startItem(); return; }     /* নেটিভ সার্ভিস চালু হয়নি → আগের HTML অডিওতে ফিরে যাই */
      onFail();
    }
  }

  /* ---------- অফলাইন সূরা অডিও (শুধু সূরা অডিও: নেটিভ স্টোরেজে, তিলাওয়াতকারী-ভেদে আলাদা) ---------- */
  var DL = { cur: null, q: [], list: [], total: 0, confirm: '', cT: 0 };
  var DLI = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11m0 0-4.2-4.2M12 15l4.2-4.2M5 19.5h14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var CHK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var toastT = 0;
  function toast(t) {
    var e = $('qa-toast');
    if (!e) { e = document.createElement('div'); e.id = 'qa-toast'; e.className = 'qa-toast'; e.setAttribute('role', 'status'); document.body.appendChild(e); }
    e.textContent = t; e.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { e.classList.remove('show'); }, 3200);
  }
  function recF() { return reciterById(P.reciter).f; }
  function dlFiles(sura) { var out = [], seen = {}; buildQueue(sura).forEach(function (it) { var n = it.t === 'bis' ? '001001' : it.file; if (!seen[n]) { seen[n] = 1; out.push(n); } }); return out; }
  function dlEntry(sura, f) { f = f || recF(); for (var i = 0; i < DL.list.length; i++) if (DL.list[i].s === sura && DL.list[i].r === f) return DL.list[i]; return null; }
  function dlState(sura) {
    var f = recF();
    if (dlEntry(sura, f)) return 'done';
    if (DL.cur && DL.cur.phase === 'downloading' && DL.cur.s === sura && DL.cur.r === f) return 'run';
    for (var i = 0; i < DL.q.length; i++) if (DL.q[i][1] === sura && DL.q[i][0] === f) return 'wait';
    return 'none';
  }
  function mb(b) { var m = (b || 0) / 1048576; return bn(m >= 10 ? Math.round(m) : Math.round(m * 10) / 10) + ' MB'; }
  function dlPct() { var c = DL.cur; return c && c.total ? Math.min(100, Math.floor(c.done / c.total * 100)) : 0; }
  function dlLabel(sura) {
    var st = dlState(sura);
    if (st === 'done') return DL.confirm === recF() + ':' + sura ? 'আবার চাপুন — অফলাইন ফাইল মুছে যাবে' : 'অফলাইনে আছে · ' + mb(dlEntry(sura).b) + ' (মুছতে চাপুন)';
    if (st === 'run') return 'নামছে ' + bn(dlPct()) + '% · বাতিল করতে চাপুন';
    if (st === 'wait') return 'সারিতে আছে · বাতিল করতে চাপুন';
    return 'অফলাইনে ডাউনলোড';
  }
  function dlWrapInner(sura) {
    var st = dlState(sura);
    return '<button type="button" class="qa-hero qa-dl ' + st + '" data-qa="dl" data-sura="' + sura + '" style="--p:' + dlPct() + '%">' + (st === 'done' ? CHK : DLI) + '<span>' + esc(dlLabel(sura)) + '</span></button>' +
      (DL.list.length ? '<button type="button" class="qa-dllink" data-qa="dlmanage">ফোনে রাখা সূরা (' + bn(DL.list.length) + ') · ' + mb(DL.total) + '</button>' : '');
  }
  function dlCurHtml() {
    if (!S.sura) return '';
    var st = dlState(S.sura);
    return '<button type="button" class="qa-dlrow ' + st + '" data-act="dl" data-sura="' + S.sura + '">' + (st === 'done' ? CHK : DLI) +
      '<span><b>সূরা ' + esc(App.SURAH_BN[S.sura - 1] || '') + '</b> — ' + esc(dlLabel(S.sura)) + '</span></button>' +
      (st === 'run' ? '<i class="qa-dlbar"><u style="width:' + dlPct() + '%"></u></i>' : '');
  }
  function offlineSheetHtml() {
    var rows = DL.list.map(function (x) {
      var rc = null; for (var i = 0; i < RECITERS.length; i++) if (RECITERS[i].f === x.r) rc = RECITERS[i];
      var sure = DL.confirm === 'row:' + x.r + ':' + x.s;
      return '<div class="qa-dli"><div><b>সূরা ' + esc(App.SURAH_BN[x.s - 1] || bn(x.s)) + '</b><small>' + esc(rc ? shortName(rc) : x.r) + ' · ' + mb(x.b) + '</small></div>' +
        '<button type="button" class="qa-dlx' + (sure ? ' sure' : '') + '" data-act="dldel" data-r="' + esc(x.r) + '" data-s="' + x.s + '">' + (sure ? 'নিশ্চিত?' : 'মুছুন') + '</button></div>';
    }).join('');
    return '<div class="qa-lb">অফলাইন (ইন্টারনেট ছাড়া শোনা)</div><div class="qa-dlcur">' + dlCurHtml() + '</div>' +
      '<div class="qa-lb">ফোনে রাখা সূরা' + (DL.list.length ? ' — মোট ' + mb(DL.total) : '') + '</div>' +
      (rows ? '<div class="qa-dlist">' + rows + '</div><div class="qa-chips" style="margin-top:10px"><button type="button" class="qa-chip" data-act="dldelall">' + (DL.confirm === 'all' ? 'নিশ্চিত — সব মুছে যাবে' : 'সব মুছুন') + '</button></div>'
            : '<p class="qa-credit" style="margin-top:0">এখনো কোনো সূরা অফলাইনে রাখা হয়নি। তিলাওয়াতকারী বদলালে তার জন্য আলাদা করে নামাতে হয়।</p>');
  }
  function dlPaint(full) {
    Array.prototype.forEach.call(document.querySelectorAll('.qa-dlwrap'), function (w) { w.innerHTML = dlWrapInner(+w.getAttribute('data-sura')); });
    if (UI && UI.open) {
      if (full) { var st = UI.sheet.scrollTop; renderSheet(); UI.sheet.scrollTop = st; }
      else { var c = UI.sheet.querySelector('.qa-dlcur'); if (c) c.innerHTML = dlCurHtml(); }
    }
  }
  function dlRefresh() {
    if (!NA) return;
    try {
      var l = JSON.parse(NA.dlList()); DL.list = l.list || []; DL.total = l.total || 0;
      var s = JSON.parse(NA.dlStatus()); DL.cur = s.cur || null; DL.q = s.q || [];
    } catch (e) {}
    dlPaint(true);
  }
  function dlErr(code) {
    return code === 'offline' ? 'ইন্টারনেট নেই — সংযোগ পেলে আবার চাপুন, যতটুকু নেমেছে তার পর থেকে চলবে'
      : code === 'no-space' ? 'ফোনে জায়গা নেই — কিছু ফাইল মুছে আবার চেষ্টা করুন'
      : 'ডাউনলোড থেমে গেছে — আবার চাপলে যেখানে থেমেছিল সেখান থেকে চলবে';
  }
  function onDl(ev) {
    DL.cur = ev.cur || null; DL.q = ev.q || [];
    if (!DL.cur || DL.cur.phase !== 'downloading') dlRefresh(); else dlPaint(false);
    if (ev.cur && ev.cur.phase === 'error') toast(dlErr(ev.cur.error));
  }
  function dlArm(key) { DL.confirm = key; clearTimeout(DL.cT); DL.cT = setTimeout(function () { DL.confirm = ''; dlPaint(true); }, 4000); }
  function dlTap(sura) {
    if (!NA || !App.quranModel[sura - 1]) return;
    var f = recF(), st = dlState(sura);
    try {
      if (st === 'none') { NA.dlStart(f, sura, JSON.stringify(dlFiles(sura))); toast('ডাউনলোড শুরু হচ্ছে…'); }
      else if (st === 'run' || st === 'wait') { NA.dlCancelSura(f, sura); toast('ডাউনলোড বাতিল — নামা অংশ রাখা আছে, আবার চাপলে বাকিটা নামবে'); }
      else if (DL.confirm === f + ':' + sura) { DL.confirm = ''; NA.dlDelete(f, sura); toast('অফলাইন ফাইল মুছে ফেলা হচ্ছে'); setTimeout(dlRefresh, 500); }
      else dlArm(f + ':' + sura);
    } catch (e) {}
    setTimeout(dlRefresh, 200);
    dlPaint(true);
  }
  function dlDelTap(r, s) {
    var key = 'row:' + r + ':' + s;
    if (DL.confirm === key) { DL.confirm = ''; try { NA.dlDelete(r, s); } catch (e) {} setTimeout(dlRefresh, 500); }
    else dlArm(key);
    dlPaint(true);
  }
  function dlDelAllTap() {
    if (DL.confirm === 'all') { DL.confirm = ''; try { NA.dlDeleteAll(); } catch (e) {} setTimeout(dlRefresh, 600); }
    else dlArm('all');
    dlPaint(true);
  }
  if (NA) dlRefresh();

  /* ---------- বাইরের জায়গা থেকে ডাকা ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-qa]') : null; if (!b) return;
    var k = b.getAttribute('data-qa');
    if (k === 'sura') { e.preventDefault(); playSura(b.getAttribute('data-sura')); }
    else if (k === 'dl') { e.preventDefault(); e.stopPropagation(); dlTap(+b.getAttribute('data-sura')); }
    else if (k === 'dlmanage') { e.preventDefault(); e.stopPropagation(); openSheet(); }
    else if (k === 'ayah') {
      e.preventDefault(); e.stopPropagation();
      var card = b.closest('.tr-ayah'); if (card) playFrom(card.getAttribute('data-sura'), card.getAttribute('data-ayah'));
    }
  }, true);
  var origHero = App.heroStatsHtml;
  App.heroStatsHtml = function (sura) {
    return origHero(sura) + '<button type="button" class="qa-hero" data-qa="sura" data-sura="' + sura.index + '">' + PLAY + '<span>তিলাওয়াত শুনুন</span></button>' +
      (NA ? '<div class="qa-dlwrap" data-sura="' + sura.index + '">' + dlWrapInner(+sura.index) + '</div>' : '');
  };
  window.QuranAudio = {
    playFrom: playFrom, playSura: playSura, toggle: toggle, stop: stop, isPlaying: function () { return S.playing; },
    ayahBtnHtml: function () { return '<button type="button" class="qa-abtn" data-qa="ayah" aria-label="এই আয়াত থেকে শুনুন" title="এই আয়াত থেকে শুনুন">' + PLAY + '</button>'; },
    reciters: RECITERS, _state: S, _onNative: onNative, native: !!NA
  };
})(window.QuranApp = window.QuranApp || {});
