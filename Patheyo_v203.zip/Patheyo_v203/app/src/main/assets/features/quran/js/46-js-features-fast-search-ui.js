/* ===== js/features/fast-search-ui.js ===== */
/*!
 * js/features/fast-search-ui.js -- তরজমা পড়ুন: ভাসমান সার্চ আইকন + পুরো কুরআনের লাইভ সার্চ পেজ
 *
 * Provides : App.FsUi { open, close, isOpen }
 * Needs    : services/fast-search, services/tarjama-data, services/tarjama-download, features/tarjama-reader
 *

 *  - তিলাওয়াতেও একই: সূরা/পারা তালিকা ও সূরা পড়ার পেজে। সেখানে ফলে চাপলে আরবি পড়ার পেজ খোলে।
 *    তরজমা ডাউনলোড না থাকলে শুধু আরবি আয়াত ও সূরার নামে খোঁজা যায়।
 *  - তরজমার সূরা-তালিকায় স্ক্রোল করে নিচে নামলে, আর সূরা পড়ার পেজে সব সময় ডান-নিচে সার্চ আইকন দেখা যায়
 *  - সার্চ চলে পুরো কুরআনের তরজমা + উচ্চারণ + ব্যাখ্যা + আরবি আয়াতের ভেতরে; ফল আসে লিখতে লিখতেই
 *  - নম্বর লিখলে: "২:২৫৫" = সূরা বাকারার ২৫৫ নম্বর আয়াত; একা নম্বর = ওই নম্বরের সূরা ও আয়াত
 *  - ফোনের back চাপলে আগে সার্চ পেজ বন্ধ হয়
 */
(function (App) {
  "use strict";

  var SEARCH_SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>';
  var BACK_SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"></path></svg>';
  var X_SVG = '<svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"></path></svg>';

  var PAGE = 25, LIMIT = 300;
  var fab, ov, input, clearBtn, statusEl, listEl, chipsEl, hintEl, scrollEl;
  var opened = false, last = null, shown = 0, raf = 0, ldTimer = 0;
  var pendingNav = null, navTimer = 0, savedQuery = '';
  var scope = 'tarjama';          // সার্চ পেজ খোলার সময়কার মোড: 'tarjama' | 'tilawat'
  var QBOOK = null, QHasTr = false, building = false, buildStarted = false, buildFailed = false;

  function esc(s){ return App.escapeHtml(s); }
  function digits(s){ return String(s).replace(/[০-৯]/g, function(d){ return String(App.BN_DIGITS.indexOf(d)); }); }

  // ---------------------------------------------------------------- কুরআনকে "কিতাব" আকারে সাজানো (ইঞ্জিন এই গঠনই বোঝে)
  // সূরা = অধ্যায়; আয়াত = [নম্বর, আরবি, তরজমা, উচ্চারণ, ব্যাখ্যা]
  function cleanT(t){ return String(t || '').replace(/\[\[\d+\]\]/g, '').trim(); }

  function ayahRow(sura, i, tr, notes){
    var a = sura.ayahs[i], t = tr.a[i] || {};
    var note = '';
    if (notes && t.t){
      var re = /\[\[(\d+)\]\]/g, m;
      while ((m = re.exec(t.t)) !== null){ if (notes[m[1]]) note += (note ? ' ' : '') + notes[m[1]]; }
    }
    return [a.index, a.text || '', cleanT(t.t), t.u || '', note];
  }

  // ৬২৩৬ আয়াত: ছোট ছোট ধাপে (UI আটকায় না) সাজাই, শেষে ইঞ্জিনের ইনডেক্স
  function buildBook(withTr, done){
    var ch = [], chStart = [], total = 0, n = 1;
    function step(){
      var t0 = Date.now();
      try {
        while (n <= 114 && Date.now() - t0 < 9){
          var sura = App.quranModel[n - 1], tr = withTr ? App.tarjamaData.getSura(n) : null;
          var hs = [], cnt = withTr ? Math.min(sura.ayahs.length, tr.a.length) : sura.ayahs.length;
          for (var i = 0; i < cnt; i++) hs.push(withTr ? ayahRow(sura, i, tr, tr.f) : [sura.ayahs[i].index, sura.ayahs[i].text || '', '', '', '']);
          ch.push({ t: (App.SURAH_BN[n - 1] || '') + ' ' + (App.SURAH_EN[n - 1] || ''), s: [{ h: hs }] });
          chStart.push(total); total += hs.length; n++;
        }
      } catch (e){ buildFailed = true; building = false; if (opened) run(); return; }
      if (n <= 114){ setTimeout(step, 0); return; }
      QBOOK = { id: 'quran-tarjama', data: { ch: ch }, chStart: chStart, total: total }; QHasTr = withTr;
      done();
    }
    setTimeout(step, 0);
  }

  function trReady(){ return !!(App.tarjamaDownload && App.tarjamaDownload.isReady()); }

  // তরজমা ডাউনলোড থাকলে আরবি+বাংলা, না থাকলে শুধু আরবি দিয়ে ইনডেক্স
  function ensureIndex(){
    var wantTr = trReady();
    if (QBOOK && (QHasTr || !wantTr)){ App.FastSearch.prepare(QBOOK, onIndexProgress); return; }
    if (building || buildFailed) return;
    buildStarted = building = true;
    var go2 = function(withTr){
      buildBook(withTr, function(){ building = false; App.FastSearch.prepare(QBOOK, onIndexProgress); updatePlaceholder(); if (opened) run(); });
    };
    if (wantTr){
      App.tarjamaData.load().then(function(){ go2(true); }).catch(function(){ go2(false); });
    } else go2(false);
  }

  function updatePlaceholder(){
    if (!input) return;
    input.placeholder = trReady() ? 'তরজমা, আরবি শব্দ বা আয়াত নম্বর লিখুন' : 'আরবি শব্দ বা আয়াত নম্বর লিখুন';
  }

  // ---------------------------------------------------------------- DOM
  function build(){
    fab = document.createElement('button');
    fab.id = 'hs-fab'; fab.type = 'button'; fab.className = 'hs-fab hs-off';
    fab.setAttribute('aria-label', 'কুরআনের তরজমায় খুঁজুন');
    fab.innerHTML = SEARCH_SVG;
    document.body.appendChild(fab);

    ov = document.createElement('div');
    ov.id = 'hs-overlay'; ov.className = 'hs-overlay hidden';
    ov.setAttribute('role', 'dialog');
    ov.innerHTML =
      '<div class="hs-bar">' +
        '<button type="button" class="hs-back" aria-label="ফিরে যান">' + BACK_SVG + '</button>' +
        '<div class="hs-field">' + SEARCH_SVG.replace('class="icon"', 'class="icon icon-sm hs-fi"') +
          '<input id="hs-input" type="search" inputmode="search" enterkeyhint="search" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="তরজমা, আরবি শব্দ বা আয়াত নম্বর লিখুন">' +
          '<button type="button" class="hs-clear" aria-label="মুছুন">' + X_SVG + '</button>' +
        '</div>' +
      '</div>' +
      '<div class="hs-scroll" id="hs-scroll">' +
        '<div class="hs-status" id="hs-status"></div>' +
        '<div class="hs-chips hidden" id="hs-chips"></div>' +
        '<div class="hs-list" id="hs-list"></div>' +
        '<div class="hs-hint" id="hs-hint"></div>' +
      '</div>';
    document.body.appendChild(ov);

    input = ov.querySelector('#hs-input'); clearBtn = ov.querySelector('.hs-clear');
    statusEl = ov.querySelector('#hs-status'); listEl = ov.querySelector('#hs-list');
    chipsEl = ov.querySelector('#hs-chips'); hintEl = ov.querySelector('#hs-hint');
    scrollEl = ov.querySelector('#hs-scroll');

    fab.addEventListener('click', function(){ open(); });
    ov.querySelector('.hs-back').addEventListener('click', requestClose);
    clearBtn.addEventListener('click', function(){ input.value = ''; run(); input.focus(); });
    input.addEventListener('input', schedule);
    input.addEventListener('keydown', function(e){ if (e.key === 'Enter'){ e.preventDefault(); input.blur(); } });
    listEl.addEventListener('click', onListClick);
    chipsEl.addEventListener('click', onListClick);
    scrollEl.addEventListener('scroll', onScroll, { passive: true });
    scrollEl.addEventListener('touchstart', function(){ if (document.activeElement === input) input.blur(); }, { passive: true });
  }

  // ---------------------------------------------------------------- ভাসমান আইকন কখন দেখা যাবে
  function visible(el){ return el && !el.classList.contains('hidden'); }

  function syncFab(){
    if (!fab) return;
    var show = false, v = App.state.view, big = false;
    if (!opened){
      if (App.state.mode === 'tarjama'){
        if (App.tarjamaDownload.isReady()){
          if (v === 'tr-reader') show = visible(App.els.trReaderPanel) && !App.els.trReaderPanel.classList.contains('tr-dl-mode') && visible(App.els.trVerses) && !!App.els.trVerses.querySelector('.tr-ayah');
          else if (v === 'list') show = visible(App.els.trPanel) && window.pageYOffset > 220;
        }
      } else {
        if (v === 'sura-reader'){ show = visible(App.els.readerPanel); big = true; }
        else if (v === 'list' && (App.state.tab === 'sura' || App.state.tab === 'para'))
          show = (visible(App.els.suraPanel) || visible(App.els.paraPanel)) && window.pageYOffset > 220;
      }
    }
    if (App.els.bmModalOverlay && visible(App.els.bmModalOverlay)) show = false;
    fab.classList.toggle('hs-off', !show);
    fab.classList.toggle('hs-chapter', big);          // বুকমার্ক বোতামের ওপরে বসে
    if (show && !buildStarted) setTimeout(function(){ if (!buildStarted) ensureIndex(); }, 700);
  }
  var fabRaf = 0;
  function syncSoon(){ if (fabRaf) return; fabRaf = requestAnimationFrame(function(){ fabRaf = 0; syncFab(); }); }

  // ---------------------------------------------------------------- খোলা / বন্ধ
  function open(q){
    if (typeof q === 'string') savedQuery = q;               /* ধাপ ১১: হোমের গ্লোবাল সার্চ থেকে লেখাসহ খোলা */
    if (opened){ if (typeof q === 'string'){ input.value = q; run(); } return; }
    opened = true;
    scope = App.state.mode === 'tarjama' ? 'tarjama' : 'tilawat';
    try{ history.pushState({ qview: App.state.view, qsearch: 1 }, ''); } catch(e){}
    ov.classList.remove('hidden');
    document.documentElement.classList.add('hs-lock');
    syncFab();
    ensureIndex();
    updatePlaceholder();
    input.value = savedQuery || '';
    run();
    setTimeout(function(){ try{ input.focus(); input.select(); } catch(e){} }, 30);
  }

  function requestClose(){
    if (!opened) return;
    if (history.state && history.state.qsearch) history.back(); else hide();
  }

  function hide(){
    if (!opened) return;
    savedQuery = input.value;
    opened = false;
    ov.classList.add('hidden');
    document.documentElement.classList.remove('hs-lock');
    try{ input.blur(); } catch(e){}
    syncFab();
  }

  // ফোনের back: আমাদের নিজস্ব history এন্ট্রি আগে খরচ হয়; মূল ঘটনা-শ্রোতাকে আর জানাই না
  window.addEventListener('popstate', function(e){
    if (pendingNav){
      var fn = pendingNav; pendingNav = null; clearTimeout(navTimer);
      e.stopImmediatePropagation();
      hide(); fn();
      return;
    }
    if (opened){ e.stopImmediatePropagation(); hide(); return; }
    syncSoon();
  }, true);

  function go(fn){
    if (history.state && history.state.qsearch){
      pendingNav = fn;
      navTimer = setTimeout(function(){ if (pendingNav){ var f = pendingNav; pendingNav = null; hide(); f(); } }, 400);
      history.back();
    } else { hide(); fn(); }
  }

  function openTilawat(sura, ayah){
    if (App.state.view !== 'sura-reader'){
      App.els.paraPanel.classList.add('hidden');
      App.els.bookmarksPanel.classList.add('hidden');
    }
    App.openReader(sura);
    if (ayah) setTimeout(function(){ App.scrollToAyah(sura, ayah); }, 90);
  }
  function gotoAyah(sura, ayah){
    var sc = scope;
    go(function(){ if (sc === 'tilawat') openTilawat(sura, ayah); else App.openTarjamaReader(sura, ayah); });
  }

  function onListClick(e){
    var t = e.target.closest ? e.target.closest('[data-sura]') : null;
    if (!t) return;
    var s = parseInt(t.getAttribute('data-sura'), 10), a = parseInt(t.getAttribute('data-ayah') || '0', 10);
    gotoAyah(s, a);
  }

  // ---------------------------------------------------------------- সার্চ
  function schedule(){
    clearBtn.classList.toggle('show', !!input.value);
    if (raf) return;
    raf = requestAnimationFrame(function(){ raf = 0; run(); });
  }

  function onIndexProgress(p, done){
    if (!opened) return;
    if (done){ run(); return; }
    if (ldTimer) return;
    ldTimer = setTimeout(function(){ ldTimer = 0; if (opened) run(); }, 250);
  }

  function prog(){
    if (!QBOOK) return building ? 0 : 0;
    var st = App.FastSearch.get(QBOOK);
    return st ? Math.round((st.progress || 0) * 100) : 0;
  }

  function hintHtml(){
    var tr = trReady();
    return '<div class="hs-empty"><div class="hs-empty-ic">' + SEARCH_SVG + '</div>' +
      (tr ? '<div class="hs-empty-t">পুরো কুরআনে খুঁজুন</div><div class="hs-empty-s">তরজমা, উচ্চারণ বা ব্যাখ্যার যেকোনো শব্দ, আরবি শব্দ কিংবা আয়াত নম্বর লিখুন — লেখার সাথে সাথেই ফল আসবে।</div>' : '<div class="hs-empty-t">পুরো কুরআনে খুঁজুন</div><div class="hs-empty-s">আরবি শব্দ কিংবা আয়াত নম্বর লিখুন — লেখার সাথে সাথেই ফল আসবে। বাংলায় খুঁজতে তরজমা ডাউনলোড করে নিন।</div>') +
      '<div class="hs-ex"><span>ধৈর্য</span><span>২:২৫৫</span><span>الرحمن</span></div></div>';
  }

  function run(){
    clearBtn.classList.toggle('show', !!input.value);
    var q = input.value;
    chipsEl.innerHTML = ''; chipsEl.classList.add('hidden');
    listEl.innerHTML = ''; hintEl.innerHTML = ''; shown = 0; last = null;
    scrollEl.scrollTop = 0;

    if (buildFailed){
      statusEl.innerHTML = ''; hintEl.innerHTML = '<div class="hs-empty"><div class="hs-empty-t">সার্চ চালু করা যায়নি</div><div class="hs-empty-s">তরজমা ফাইলটি পড়া যায়নি। তরজমা আবার ডাউনলোড করে দেখুন।</div></div>';
      return;
    }
    var st = QBOOK ? App.FastSearch.get(QBOOK) : null;
    var busy = !(st && st.ready);
    var busyTxt = '<span class="hs-spin"></span> <span class="hs-soft">সার্চ প্রস্তুত হচ্ছে' + (QBOOK ? '… ' + App.bn(prog()) + '%' : '…') + '</span>';

    if (!QBOOK){ statusEl.innerHTML = busyTxt; if (!String(q).trim()) hintEl.innerHTML = hintHtml(); return; }

    var raw = digits(q).trim();
    // "২:২৫৫" / "2 255" / "2.255"
    var dm = /^(\d{1,3})\s*[:：.\/\-\s]\s*(\d{1,3})$/.exec(raw);
    if (dm){
      var sN = parseInt(dm[1], 10), aN = parseInt(dm[2], 10);
      if (sN >= 1 && sN <= 114 && aN >= 1 && aN <= (QBOOK.data.ch[sN - 1].s[0].h.length)){
        var hh = QBOOK.data.ch[sN - 1].s[0].h[aN - 1];
        last = { mode: 'direct', terms: [], items: [{ seq: QBOOK.chStart[sN - 1] + aN - 1, c: sN - 1, h: hh, score: 1 }], total: 1, ms: 0 };
        statusEl.innerHTML = '<b>সূরা ' + App.bn(sN) + '</b> · আয়াত ' + App.bn(aN) + (busy ? ' ' + busyTxt : '');
        renderMore();
        return;
      }
    }

    var res = App.FastSearch.search(QBOOK, q, { limit: LIMIT });
    last = res;
    if (res.mode === 'bn' && res.items.length > 1){
      // তরজমা/উচ্চারণে মিললে আগে, শুধু ব্যাখ্যায় মিললে পরে (আগের ক্রম বজায় রেখে)
      var a1 = [], a2 = [];
      res.items.forEach(function(it){
        var hit = (it.h[2] && App.FastSearch.spans(it.h[2], res.terms, 'bn').length) || (it.h[3] && App.FastSearch.spans(it.h[3], res.terms, 'bn').length);
        (hit ? a1 : a2).push(it);
      });
      res.items = a1.concat(a2);
    }

    if (res.mode === 'empty'){
      statusEl.innerHTML = busy ? busyTxt : '';
      hintEl.innerHTML = hintHtml();
      return;
    }

    // সূরা-নম্বর (শুধু নম্বর লিখলে) + সূরার নামে মিল
    var chips = '';
    if (res.mode === 'num'){
      var sn = parseInt(raw.replace(/\D/g, ''), 10);
      if (sn >= 1 && sn <= 114) chips += '<button type="button" class="hs-chip" data-sura="' + sn + '" data-ayah="0">সূরা ' + App.bn(sn) + ' · ' + esc(App.SURAH_BN[sn - 1] || '') + '</button>';
    }
    (res.chapters || []).forEach(function(c){
      chips += '<button type="button" class="hs-chip" data-sura="' + (c + 1) + '" data-ayah="0">সূরা ' + esc(App.SURAH_BN[c] || '') + '</button>';
    });
    if (chips){ chipsEl.innerHTML = '<div class="hs-chips-t">সূরা</div>' + chips; chipsEl.classList.remove('hidden'); }

    var total = res.total || res.items.length, s = '';
    if (res.items.length){
      s = '<b>' + App.bn(total) + '</b> টি আয়াত পাওয়া গেছে';
      if (res.relaxed) s += ' · <span class="hs-soft">কাছাকাছি মিল</span>';
      s += ' <span class="hs-ms">' + App.bn(Math.max(1, Math.round(res.ms))) + ' মি.সে.</span>';
    } else if (!busy) s = chips ? 'সূরা পাওয়া গেছে — চাপ দিয়ে খুলুন' : 'কিছু পাওয়া যায়নি';
    if (busy) s += (s ? ' ' : '') + busyTxt;
    statusEl.innerHTML = s;

    if (!res.items.length && !busy && chips) return;
    if (!res.items.length && !busy && res.mode === 'bn' && !QHasTr){
      hintEl.innerHTML = '<div class="hs-empty"><div class="hs-empty-t">বাংলায় খুঁজতে তরজমা লাগবে</div>' +
        '<div class="hs-empty-s">এখন শুধু আরবি আয়াতে খোঁজা যাচ্ছে। বাংলা শব্দে খুঁজতে “তরজমা পড়ুন” থেকে তরজমা ডাউনলোড করে নিন।</div></div>';
      return;
    }
    if (!res.items.length && !busy){
      hintEl.innerHTML = '<div class="hs-empty"><div class="hs-empty-t">কোনো আয়াত মেলেনি</div>' +
        '<div class="hs-empty-s">অন্য শব্দ দিয়ে বা শব্দের ছোট অংশ লিখে দেখুন।<br>আয়াত নম্বরও লিখতে পারেন (যেমন: ২:২৫৫)।</div></div>';
      return;
    }
    renderMore();
  }

  function onScroll(){
    if (last && shown < last.items.length && scrollEl.scrollHeight - scrollEl.scrollTop - scrollEl.clientHeight < 700) renderMore();
  }

  // ---------------------------------------------------------------- ফল আঁকা
  function mark(text, ranges){
    var out = '', pos = 0;
    for (var i = 0; i < ranges.length; i++){
      var a = ranges[i][0], b = ranges[i][1];
      if (a < pos) continue;
      out += esc(text.slice(pos, a)) + '<mark class="hs-mark">' + esc(text.slice(a, b)) + '</mark>';
      pos = b;
    }
    return out + esc(text.slice(pos));
  }

  function snippet(text, ranges, max){
    if (!text) return '';
    if (!ranges.length || text.length <= max){
      var t = text.length > max ? text.slice(0, max) + '…' : text;
      return mark(t, ranges.filter(function(r){ return r[1] <= t.length; }));
    }
    var first = ranges[0][0], from = Math.max(0, first - Math.floor(max * 0.35));
    if (from > 0){ var sp = text.indexOf(' ', from); if (sp > -1 && sp < first) from = sp + 1; }
    var to = Math.min(text.length, from + max), piece = text.slice(from, to), rr = [];
    ranges.forEach(function(r){ if (r[0] >= from && r[1] <= to) rr.push([r[0] - from, r[1] - from]); });
    return (from > 0 ? '…' : '') + mark(piece, rr) + (to < text.length ? '…' : '');
  }

  function cardHtml(it, res){
    var h = it.h, mode = res.mode, body = '', sub = '';
    var sName = App.SURAH_BN[it.c] || '';
    if (mode === 'ar'){
      body = '<div class="hs-body hs-ar">' + App.wrapWaqf(snippet(h[1], App.FastSearch.spans(h[1], res.terms, 'ar'), 150)) + '</div>';
      if (h[2]) sub = '<div class="hs-sub">' + esc(h[2].length > 140 ? h[2].slice(0, 140) + '…' : h[2]) + '</div>';
    } else if (mode === 'bn'){
      var fields = [[h[2], ''], [h[3], 'উচ্চারণ'], [h[4], 'ব্যাখ্যা']], used = false;
      for (var fi = 0; fi < fields.length && !used; fi++){
        var f = fields[fi], rg = f[0] ? App.FastSearch.spans(f[0], res.terms, 'bn') : [];
        if (!rg.length) continue;
        used = true;
        body = '<div class="hs-body">' + (f[1] ? '<span class="hs-lbl">' + f[1] + '</span>' : '') + snippet(f[0], rg, 210) + '</div>';
      }
      if (!used) body = '<div class="hs-body">' + esc((h[2] || '').slice(0, 210)) + '</div>';
    } else {
      body = '<div class="hs-body">' + esc((h[2] || '').slice(0, 220)) + ((h[2] || '').length > 220 ? '…' : '') + '</div>';
    }
    return '<button type="button" class="hs-card" data-sura="' + (it.c + 1) + '" data-ayah="' + h[0] + '">' +
      '<div class="hs-ctop"><span class="hs-num">' + App.bn(it.c + 1) + ' : ' + App.bn(h[0]) + '</span>' +
      '<span class="hs-ch">সূরা ' + esc(sName) + ' · আয়াত ' + App.bn(h[0]) + '</span></div>' + body + sub + '</button>';
  }

  function renderMore(){
    if (!last) return;
    var end = Math.min(last.items.length, shown + PAGE), html = [];
    for (var i = shown; i < end; i++) html.push(cardHtml(last.items[i], last));
    shown = end;
    listEl.insertAdjacentHTML('beforeend', html.join(''));
    if (shown >= last.items.length && (last.total || 0) > last.items.length){
      hintEl.innerHTML = '<div class="hs-more">প্রথম ' + App.bn(last.items.length) + 'টি দেখানো হয়েছে — আরও নির্দিষ্ট করে লিখুন</div>';
    }
  }

  // ---------------------------------------------------------------- শুরু
  function init(){
    build();
    window.addEventListener('scroll', syncSoon, { passive: true });
    window.addEventListener('resize', syncSoon);
    if (window.MutationObserver){
      var mo = new MutationObserver(syncSoon);
      [App.els.trPanel, App.els.suraPanel, App.els.paraPanel, App.els.readerPanel, App.els.trReaderPanel, App.els.trVerses, App.els.trDlPanel, App.els.bmModalOverlay].forEach(function(el){
        if (el) mo.observe(el, { attributes: true, attributeFilter: ['class'] });
      });
      mo.observe(App.els.trVerses, { childList: true });
    }
    // তরজমা ডাউনলোড শেষ হলে আইকন দেখাতে
    if (App.tarjamaDownload && App.tarjamaDownload.subscribe){ try{ App.tarjamaDownload.subscribe(syncSoon); } catch(e){} }
    syncFab();
  }

  /* ধাপ ১১: হোমের গ্লোবাল সার্চ (shell/js/13-search.js) — একই ইঞ্জিন ও ইনডেক্স, শুধু ফলাফল ফেরত দেয় */
  function query(q, limit){
    limit = limit || 8;
    ensureIndex();
    var st = QBOOK ? App.FastSearch.get(QBOOK) : null;
    var out = { ready: !!(st && st.ready), progress: prog(), hasTr: !!QHasTr, trReady: trReady(), items: [], total: 0, mode: '', terms: [] };
    if (!QBOOK || buildFailed) return out;
    var raw = digits(q).trim(), dm = /^(\d{1,3})\s*[:：.\/\-\s]\s*(\d{1,3})$/.exec(raw);
    if (dm){
      var sN = +dm[1], aN = +dm[2];
      if (sN >= 1 && sN <= 114 && aN >= 1 && aN <= QBOOK.data.ch[sN - 1].s[0].h.length){
        var hh = QBOOK.data.ch[sN - 1].s[0].h[aN - 1];
        out.items = [{ s: sN, a: aN, ar: hh[1], bn: hh[2] || '', name: App.SURAH_BN[sN - 1] || '' }]; out.total = 1; out.mode = 'direct';
        return out;
      }
    }
    if (!String(q).trim()) return out;
    var res = App.FastSearch.search(QBOOK, q, { limit: Math.max(limit, 40) });
    out.mode = res.mode; out.terms = res.terms || []; out.total = res.total || res.items.length;
    out.items = res.items.slice(0, limit).map(function(it){ return { s: it.c + 1, a: it.h[0], ar: it.h[1], bn: it.h[2] || '', name: App.SURAH_BN[it.c] || '' }; });
    return out;
  }

  App.FsUi = { open: open, close: requestClose, isOpen: function(){ return opened; }, query: query };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})(window.QuranApp = window.QuranApp || {});
