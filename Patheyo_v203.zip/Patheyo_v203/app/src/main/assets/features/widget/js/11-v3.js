/* ধাপ ৭ — উইজেট হাব: প্রিভিউ উপরে আটকে গেলে (.is-stuck) ছোট হয়, যাতে ডিজাইন/থিম বাছার সময় চোখের সামনে থাকে */
(function () {
  'use strict';
  var box = document.getElementById('wh-prev');
  if (!box) return;
  var mark = document.createElement('div');
  mark.style.cssText = 'height:1px;margin-top:-1px;pointer-events:none';
  box.parentNode.insertBefore(mark, box);
  var stuck = false, hdTop = 0;
  /* হেডারটা পেজের উপরে আটকে থাকে (কন্ট্রোলারের STD_HEADER) — প্রিভিউ ঠিক তার নিচে আটকাবে */
  function measure() {
    var hd = document.querySelector('.app-header');
    var h = 0; if (hd) { var r = hd.getBoundingClientRect(); h = Math.max(0, Math.round(r.bottom)); }
    if (h !== hdTop) { hdTop = h; box.style.top = h + 'px'; }
  }
  function set(v) { if (v === stuck) return; stuck = v; box.classList.toggle('is-stuck', v); }
  function check() { if (!stuck) measure(); set(mark.getBoundingClientRect().top < hdTop - 24); }
  window.addEventListener('scroll', check, { passive: true });
  window.addEventListener('resize', function () { hdTop = -1; measure(); check(); });
  setTimeout(function () { measure(); check(); }, 400);
  check();
})();
