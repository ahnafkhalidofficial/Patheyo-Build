
/* ===== js/features/chapter-reader.js ===== */
/*!
 * js/features/chapter-reader.js -- Chapter reader: section labels + hadith cards, rendered in chunks while scrolling
 *
 * Provides : App.openChapter, App.closeChapter, App.stopChapterReader, App.getCurrentVisibleHadith,
 *            App.scrollToHadith, App.maybeFillChapter, App.refreshCardMarks, App.currentChapterMeta
 * Needs    : core/dom, core/state, core/utils, services/book-store, services/bookmark-store,
 *            features/bookmark-fab, features/last-read, features/navigation
 */
(function (App) {
  "use strict";

  var CHUNK = 24;           // hadith per rendering step
  var items = [];           // [{k:'s',t} | {k:'h',h,seq}] of the open chapter
  var cursor = 0;           // how many items are already in the DOM
  var marks = {};           // seq -> bookmark id (for the green bookmark icon on cards)

  var BM_SVG = '<svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21 12 16 5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>';

  /* ধাপ ৫: হাদিসের মান — ডেটায় থাকলে (h[3]) সেটাই; সহীহ বুখারী ও সহীহ মুসলিমের সব হাদিস সর্বসম্মতভাবে সহীহ */
  var SAHIH_BOOKS = { bukhari: 1, muslim: 1 };
  function gradeHtml(h){
    var g = (h[3] != null && String(h[3]).trim()) ? String(h[3]).trim() : (App.loadedBook && SAHIH_BOOKS[App.loadedBook.id] ? 'সহীহ' : '');
    if (!g) return '';
    var c = /সহীহ|sahih/i.test(g) ? 'g-sahih' : /হাসান|hasan/i.test(g) ? 'g-hasan' : /জাল|মাওযু|mawdu/i.test(g) ? 'g-mawdu' : /য[ঈই]ফ|দুর্বল|da.?if/i.test(g) ? 'g-daif' : '';
    return '<span class="hd-grade ' + c + '">' + App.escapeHtml(g) + '</span>';
  }
  function cardHtml(it){
    var h = it.h, ar = h[1], bn = h[2];
    var on = marks[it.seq] !== undefined;
    return '<article class="hd-card" id="hd-' + it.seq + '" data-seq="' + it.seq + '" data-num="' + h[0] + '">' +
      '<div class="hd-top"><span class="hd-num">হাদীস ' + App.bn(h[0]) + '</span>' + gradeHtml(h) +
      '<span class="hd-acts">' + (window.PtShareCard ? window.PtShareCard.btnHtml() : '') + '<button class="hd-bm' + (on ? ' on' : '') + '" type="button" aria-label="বুকমার্ক">' + BM_SVG + '</button></span></div>' +
      (ar ? '<div class="hd-ar">' + App.wrapWaqf(App.escapeHtml(ar)) + '</div>' : '') +
      (ar && bn ? '<div class="hd-sep"></div>' : '') +
      (bn ? '<div class="hd-bn">' + App.escapeHtml(bn) + '</div>' : '') +
      '</article>';
  }

  function renderMore(count){
    count = count || CHUNK;
    var html = [], n = 0;
    while (cursor < items.length && n < count){
      var it = items[cursor++];
      if (it.k === 's'){ var secM = /^\s*([0-9\u09E6-\u09EF]+)\s*[\u0964.\-:]\s*([\s\S]+)$/.exec(it.t || '');   // v130: "৩৪৩। শিরোনাম" -> নম্বর ব্যাজ + শিরোনাম
        html.push('<div class="hd-section">' + (secM ? '<span class="hd-sec-no">' + App.escapeHtml(secM[1]) + '</span><span class="hd-sec-t">' + App.escapeHtml(secM[2]) + '</span>' : '<span class="hd-sec-t">' + App.escapeHtml(it.t) + '</span>') + '</div>'); }
      else { html.push(cardHtml(it)); n++; }
    }
    if (html.length) App.els.chapterItems.insertAdjacentHTML('beforeend', html.join(''));
  }

  // keeps the page filled a screen-and-a-half ahead of the reader
  function maybeFillChapter(){
    var guard = 0;
    while (cursor < items.length && guard++ < 12 &&
           App.els.moreSentinel.getBoundingClientRect().top < window.innerHeight + 1800){
      renderMore();
    }
  }
  App.maybeFillChapter = maybeFillChapter;

  function seqIndex(seq){
    for (var i = 0; i < items.length; i++){ if (items[i].k === 'h' && items[i].seq === seq) return i; }
    return -1;
  }

  function scrollToHadith(seq){
    var idx = seqIndex(seq);
    if (idx < 0) return;
    while (cursor <= idx) renderMore();
    var el = document.getElementById('hd-' + seq);
    if (!el) return;
    el.scrollIntoView({ block:'start' });
    el.classList.add('hd-highlight');
    setTimeout(function(){ el.classList.remove('hd-highlight'); }, 1800);
  }
  App.scrollToHadith = scrollToHadith;

  // the hadith currently at the top of the screen (the last card whose top edge passed the header)
  function getCurrentVisibleHadith(){
    var cards = App.els.chapterItems.querySelectorAll('.hd-card');
    if (!cards.length) return null;
    var lo = 0, hi = cards.length - 1, best = 0;
    while (lo <= hi){
      var mid = (lo + hi) >> 1;
      if (cards[mid].getBoundingClientRect().top <= 190){ best = mid; lo = mid + 1; } else { hi = mid - 1; }
    }
    var el = cards[best];
    return { seq: parseInt(el.getAttribute('data-seq'), 10), num: parseInt(el.getAttribute('data-num'), 10) };
  }
  App.getCurrentVisibleHadith = getCurrentVisibleHadith;

  // refresh the green/plain bookmark icons after a bookmark was added / removed / moved
  function refreshCardMarks(){
    if (!App.curBookId) return;
    marks = App.bookmarkedSeqs(App.curBookId);
    App.els.chapterItems.querySelectorAll('.hd-card').forEach(function(card){
      var seq = parseInt(card.getAttribute('data-seq'), 10);
      card.querySelector('.hd-bm').classList.toggle('on', marks[seq] !== undefined);
    });
  }
  App.refreshCardMarks = refreshCardMarks;

  App.currentChapterMeta = function(){
    var book = App.loadedBook;
    if (!book) return null;
    var ch = book.data.ch[App.curChapter];
    return { c: App.curChapter, ct: ch ? (ch.t || '') : '' };
  };

  // ---------------------------------------------------------------- open / close
  function openChapter(c, opts){
    opts = opts || {};
    var book = App.loadedBook;
    if (!book || book.id !== App.curBookId) return;
    var ch = book.data.ch[c];
    if (!ch) return;

    if (App.state.view === 'book') App.state.bookScroll = window.pageYOffset;
    var wasChapter = App.state.view === 'chapter';
    if (!wasChapter) App.state.chapterOrigin = opts.origin || 'book';
    App.curChapter = c;

    var count = 0; ch.s.forEach(function(s){ count += s.h.length; });
    App.els.chapterBadge.textContent = ch.n != null ? 'অধ্যায় ' + App.bn(ch.n) : (c === 0 ? 'শুরুর অধ্যায়' : 'অধ্যায়');
    App.els.chapterArabicName.textContent = ch.a || '';
    App.els.chapterArabicName.classList.toggle('hidden', !ch.a);
    App.els.chapterNameCaption.textContent = ch.t || '';
    App.els.chapterMeta.innerHTML = App.heroStatsHtml([[count, 'হাদীস']]);
    App.els.chapterMeta.setAttribute('aria-label', 'হাদীস সংখ্যা: ' + App.bn(count));

    App.els.chapterItems.innerHTML = '';
    items = App.chapterItems(book, c);
    cursor = 0;
    marks = App.bookmarkedSeqs(book.id);

    App.els.bookPanel.classList.add('hidden');
    App.els.booksPanel.classList.add('hidden');
    App.els.bookmarksPanel.classList.add('hidden');
    App.els.continueCard.classList.add('hidden');
    App.els.chapterPanel.classList.remove('hidden');
    window.scrollTo(0, 0);

    App.activeBookmarkId = null; App.activeBookmarkPos = null;
    renderMore();
    if (!wasChapter) App.pushHistory('chapter');

    var startSeq = (opts.seq != null) ? opts.seq : book.chStart[c];
    var hit = App.hadithAtSeq(book, startSeq);
    if (hit) App.saveLastRead({ book: book.id, ch: c, seq: startSeq, num: hit.h[0],
      label: (App.bookById(book.id).nameBn) + ' — হাদীস ' + App.bn(hit.h[0]) });

    if (opts.bookmarkId){
      App.activeBookmarkId = opts.bookmarkId;
      App.activeBookmarkPos = { book: book.id, seq: startSeq };
    }
    if (opts.seq != null && opts.seq !== book.chStart[c]){
      setTimeout(function(){ scrollToHadith(opts.seq); App.updateBmFabIcon(); }, 60);
    }
    App.updateBmFabIcon();
  }
  App.openChapter = openChapter;

  // free the (big) chapter DOM
  function stopChapterReader(){
    App.els.chapterItems.innerHTML = '';
    items = []; cursor = 0;
    App.els.chapterPanel.classList.add('hidden');
    App.activeBookmarkId = null; App.activeBookmarkPos = null;
  }
  App.stopChapterReader = stopChapterReader;

  function closeChapter(){
    var origin = App.state.chapterOrigin;
    stopChapterReader();
    if (origin === 'book' && App.curBookId){
      App.els.bookPanel.classList.remove('hidden');
      App.state.view = 'book';
      App.updateSearchUi();
      var y = App.state.bookScroll || 0;
      requestAnimationFrame(function(){ window.scrollTo(0, y); });
    } else {
      App.switchTab(App.returnTab);
      var y2 = App.state.listScroll || 0;
      requestAnimationFrame(function(){ window.scrollTo(0, y2); });
    }
  }
  App.closeChapter = closeChapter;

})(window.HadithApp = window.HadithApp || {});

