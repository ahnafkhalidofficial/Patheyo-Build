package com.gunjoron.patheyo.ui

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface

/**
 * ধাপ ৮: হালকা কম্পন (হ্যাপটিক) — JS-এ নাম PatheyoHaptics.
 * ওয়েবের PT.haptic(kind) (shared/ds/ds.js) ও তাসবিহ আগে এটাই খোঁজে; না পেলে navigator.vibrate।
 *  • "tick"    — তাসবিহের প্রতি গণনা: খুব ছোট টোকা
 *  • "light"   — বোতাম/সেগমেন্ট
 *  • "success" — লক্ষ্য পূর্ণ, কাজ সম্পন্ন: দুটো নরম টোকা
 *  • "warn"    — মুছে ফেলা/সতর্কতা: তিনটে টোকা
 * সম্ভব হলে ফোনের নিজস্ব (predefined) কম্পন — অনেক ফোনে মোটরের সাথে মানানসই, অনেক সুন্দর লাগে।
 */
class HapticsBridge(ctx: Context) {
    private val vib: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        else @Suppress("DEPRECATION") (ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)
    } catch (_: Throwable) { null }

    @JavascriptInterface
    fun vibrate(kind: String?) {
        val v = vib ?: return
        try {
            if (!v.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val e = when (kind) {
                    "tick" -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
                    "success" -> VibrationEffect.createWaveform(longArrayOf(0, 14, 60, 22), intArrayOf(0, 140, 0, 220), -1)
                    "warn" -> VibrationEffect.createWaveform(longArrayOf(0, 26, 50, 26, 50, 26), -1)
                    else -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                }
                v.vibrate(e)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val e = when (kind) {
                    "success" -> VibrationEffect.createWaveform(longArrayOf(0, 14, 60, 22), -1)
                    "warn" -> VibrationEffect.createWaveform(longArrayOf(0, 26, 50, 26, 50, 26), -1)
                    "tick" -> VibrationEffect.createOneShot(8, 120)
                    else -> VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE)
                }
                v.vibrate(e)
            } else {
                @Suppress("DEPRECATION")
                when (kind) { "success" -> v.vibrate(longArrayOf(0, 14, 60, 22), -1); "warn" -> v.vibrate(longArrayOf(0, 26, 50, 26, 50, 26), -1); else -> v.vibrate(10) }
            }
        } catch (_: Throwable) {}
    }
}
