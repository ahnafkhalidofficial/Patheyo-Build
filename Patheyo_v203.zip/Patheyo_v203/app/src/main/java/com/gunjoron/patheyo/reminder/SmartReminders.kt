package com.gunjoron.patheyo.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.webkit.JavascriptInterface
import com.gunjoron.patheyo.alarm.AlarmScheduler
import com.gunjoron.patheyo.notification.IslamicNotification
import com.gunjoron.patheyo.notification.ScheduledNotificationScheduler
import org.json.JSONObject

/**
 * ধাপ ১১: স্মার্ট রিমাইন্ডার — প্রতিটি বিষয় আলাদা অন/অফ ("শান্ত" অ্যাপের প্রতিশ্রুতি: যেটা চান শুধু সেটাই আসবে)।
 *
 * আগে থেকেই থাকা ইসলামিক নোটিফিকেশন (assets/notifications_config.json → ScheduledNotificationScheduler) এখন দলে ভাগ:
 *   kahf     — জুমার দিন সূরা কাহফ ও দরুদ          (weekly_jumma_kahf, weekly_friday_durood) → ট্যাপে সূরা কাহফ খোলে
 *   monthu   — সোম-বৃহস্পতির রোজা (আগের রাতে)       (weekly_sunnah_fasting_mon_thu)
 *   ayyam    — আইয়ামে বীযের রোজা (আগের রাতে, রমজান/তাশরিক বাদ) (monthly_ayyam_*)
 *   zikr     — সকাল-সন্ধ্যার জিকির                   (type = daily)               → ট্যাপে সকাল-সন্ধ্যার দোয়া
 *   islamic  — ইসলামিক দিন ও মাস (আশুরা, রমজান, ঈদ, শবে কদর…) (বাকি হিজরি/সাপ্তাহিক)
 *   national — বাংলা মাস ও জাতীয় দিবস               (annual_bengali, annual_gregorian)
 * নতুন:
 *   sleep    — ঘুমের আগের দোয়া ও আমল, ব্যবহারকারীর বাছাই করা সময়ে (ডিফল্ট বন্ধ, ২২:৩০) → ট্যাপে ঘুমের দোয়া
 *
 * JS (shell/js/15-reminders.js): PatheyoReminders.get() → JSON, PatheyoReminders.set(JSON)।
 * নোটিফিকেশনে ট্যাপ → MainActivity "go" extra → window.__ptGo('quran:18' | 'dua:sleep' | 'dua:morning')।
 */
object SmartReminders {
    private const val PREFS = "patheyo_reminders"
    private const val KEY = "smart_json"
    private const val SLEEP_REQ = 9220
    const val KIND_SLEEP = "smart:sleep"

    private val DEFAULTS = JSONObject()
        .put("kahf", true).put("monthu", true).put("ayyam", true).put("zikr", true)
        .put("islamic", true).put("national", true)
        .put("sleep", false).put("sleepTime", "22:30")

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(ctx: Context): JSONObject {
        val saved = try { JSONObject(prefs(ctx).getString(KEY, null) ?: "{}") } catch (_: Throwable) { JSONObject() }
        val out = JSONObject()
        DEFAULTS.keys().forEach { k -> out.put(k, if (saved.has(k)) saved.get(k) else DEFAULTS.get(k)) }
        return out
    }

    fun set(ctx: Context, json: String) {
        val inc = try { JSONObject(json) } catch (_: Throwable) { return }
        val cur = get(ctx)
        DEFAULTS.keys().forEach { k ->
            if (!inc.has(k)) return@forEach
            if (k == "sleepTime") {
                val t = inc.optString(k, "")
                if (Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(t)) cur.put(k, t)
            } else cur.put(k, inc.optBoolean(k, cur.optBoolean(k)))
        }
        prefs(ctx).edit().putString(KEY, cur.toString()).apply()
        schedule(ctx)
        // দল বন্ধ/চালু হলে আজকের শিডিউল সাথে সাথে মিলিয়ে নেওয়া
        try { ScheduledNotificationScheduler.scheduleAllNotifications(ctx.applicationContext) } catch (_: Throwable) {}
    }

    /** কোন দলের নোটিফিকেশন (অজানা নতুন রিমোট আইটেম → তার ধরন দেখে) */
    fun groupOf(item: IslamicNotification): String = groupOf(item.id, item.type)

    fun groupOf(id: String, type: String): String = when {
        id == "weekly_jumma_kahf" || id == "weekly_friday_durood" -> "kahf"
        id == "weekly_sunnah_fasting_mon_thu" -> "monthu"
        id.startsWith("monthly_ayyam") -> "ayyam"
        type == "daily" -> "zikr"
        type == "annual_bengali" || type == "annual_gregorian" -> "national"
        else -> "islamic"
    }

    /** ব্যবহারকারী এই দল বন্ধ রেখেছেন কি না */
    fun allows(ctx: Context, item: IslamicNotification): Boolean =
        try { get(ctx).optBoolean(groupOf(item), true) } catch (_: Throwable) { true }

    /** নোটিফিকেশনে ট্যাপ করলে অ্যাপের কোথায় যাবে (না থাকলে শুধু অ্যাপ খোলে) */
    fun goFor(id: String): String? = when (id) {
        "weekly_jumma_kahf" -> "quran:18"
        "daily_morning_zikr", "daily_evening_zikr" -> "dua:morning"
        else -> null
    }

    // ---------------------------------------------------------------- ঘুমের আগের রিমাইন্ডার

    private fun pi(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(ctx, SLEEP_REQ,
            Intent(ctx, ReminderReceiver::class.java).putExtra(ReminderAlarms.EXTRA_KIND, KIND_SLEEP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val p = pi(app)
        val o = get(app)
        if (!o.optBoolean("sleep", false)) { am.cancel(p); return }
        val at = AlarmScheduler.nextOccurrence(o.optString("sleepTime", "22:30")) ?: return
        try {   // রিমাইন্ডার — এক্সাক্ট না হলেও চলে (খতমের মতো), তাই স্ট্যাটাস বারে অ্যালার্ম-ঘড়ি দেখায় না
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.set(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: Throwable) {}
    }

    fun fire(ctx: Context, kind: String) {
        val app = ctx.applicationContext
        if (kind != KIND_SLEEP) return
        try {
            if (get(app).optBoolean("sleep", false)) {
                ReminderAlarms.post(app, SLEEP_REQ, "ঘুমের আগে কয়েকটি আমল",
                    "আয়াতুল কুরসি, তিন কুল ও ঘুমের দোয়া পড়ে ডান কাতে শুয়ে পড়ুন। ট্যাপ করলে দোয়াগুলো খুলবে।",
                    -1, "dua:sleep")
            }
        } finally { schedule(app) }
    }
}

/** JS ↔ স্মার্ট রিমাইন্ডার (window.PatheyoReminders) */
class RemindersBridge(private val ctx: Context) {
    @JavascriptInterface
    fun get(): String = try { SmartReminders.get(ctx).toString() } catch (_: Throwable) { "{}" }

    @JavascriptInterface
    fun set(json: String) { try { SmartReminders.set(ctx, json) } catch (_: Throwable) {} }
}
