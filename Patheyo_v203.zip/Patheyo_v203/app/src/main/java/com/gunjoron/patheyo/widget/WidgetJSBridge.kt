package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/WidgetJSBridge.kt
//
// এই রাউন্ডে নতুন:
//  - (v135) উইজেট হাবের সব নিয়ন্ত্রণ এখন getHubState()/setHub…()/renderHubPreview() ব্রিজে; পুরনো saveWidgetSettings() বাদ
//  - stopAzan() — JS থেকে আজান বন্ধ করার ব্রিজ
//  - setHijriConfig() — Firebase RC থেকে আসা hijri adjustment ও method ID ধরে রাখা

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt
import com.gunjoron.patheyo.widgethub.data.Prefs
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.widget.WidgetRenderer
import com.gunjoron.patheyo.widgethub.widget.WidgetUpdater
import com.gunjoron.patheyo.widgethub.widget.assets.Fonts
import com.gunjoron.patheyo.widgethub.widget.theme.Look
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.widget.Toast
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.alarm.AlarmScheduler
import com.gunjoron.patheyo.alarm.AzanForegroundService
import com.gunjoron.patheyo.alarm.AzanOverlayActivity

class WidgetJSBridge(private val activity: Activity) {

    @JavascriptInterface
    fun saveTimings(jsonString: String) {
        val prefs = activity.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(PrayerWidgetProvider.KEY_TIMINGS, jsonString)
            .putLong("last_sync_timestamp", System.currentTimeMillis())
            // ✅ FIX #1: এই সময়ের নামাজের সময়সূচি কোন গ্রেগরিয়ান তারিখে আনা হয়েছে সেটা মনে রাখা হচ্ছে
            // (হিজরি তারিখ মধ্যরাতে রিভার্ট হওয়া বাগ ফিক্স করতে দরকার — দেখুন PrayerWidgetProvider)
            .putString("timings_fetched_on", com.gunjoron.patheyo.FirebaseDataManager.todayDateOnlyStr())
            .commit() // দ্রুত রাইট করার জন্য commit
        
        // RTDB থেকে পাওয়া লেটেস্ট এডজাস্টমেন্ট সাথে সাথে অ্যাপ্লাই করা (Race condition সমাধান)
        FirebaseDataManager.refreshWithLastAdjustment(activity)

        val appContext = activity.applicationContext
        HubPreview.invalidate() // নামাজের সময় বদলেছে — হাবের প্রিভিউ নতুন তথ্যে আঁকা হবে
        activity.runOnUiThread { 
            PrayerWidgetProvider.updateWidgetDirectly(appContext) // সরাসরি আপডেট
            // ✅ FIX #4: ব্রডকাস্টও পাঠানো হচ্ছে, যাতে অ্যাপ হাব থেকে করা যেকোনো পরিবর্তন সাথে সাথে
            // হোমস্ক্রিন উইজেটে দেখা যায় — অ্যাপ কেটে/উইজেটে ক্লিক করে আবার ঢোকার দরকার না হয়।
            PrayerWidgetProvider.updateAllWidgets(appContext)
            WidgetRefreshScheduler.scheduleAll(appContext) // নতুন সময় অনুযায়ী শিডিউল রিফ্রেশ
        }
        AlarmScheduler.scheduleAllAlarms(activity)
    }

    // "উইজেট রিফ্রেশ করুন" বাটন — হোমস্ক্রিনের উইজেট জোর করে সাথে সাথে আবার আঁকে, সাথে একটা কনফার্মেশন টোস্ট।
    @JavascriptInterface
    fun refreshWidgetNow() {
        val appContext = activity.applicationContext
        activity.runOnUiThread {
            HubPreview.invalidate()
            PrayerWidgetProvider.updateWidgetDirectly(appContext)
            PrayerWidgetProvider.updateAllWidgets(appContext)
            WidgetRefreshScheduler.scheduleAll(appContext)
            Toast.makeText(activity, "উইজেট রিফ্রেশ করা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    // "হোম স্ক্রিনে উইজেট যুক্ত করুন" — সিস্টেমের পিন-প্রম্পট; যুক্ত হলে কলব্যাকে উইজেট সতেজ করা হয়
    @JavascriptInterface
    fun pinWidgetToHomeScreen() {
        activity.runOnUiThread {
            val mgr = AppWidgetManager.getInstance(activity)
            val provider = ComponentName(activity, PrayerWidgetProvider::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mgr.isRequestPinAppWidgetSupported) {
                val cb = PendingIntent.getBroadcast(
                    activity, 2,
                    Intent(activity, PrayerWidgetProvider::class.java).setAction(WidgetUpdater.ACTION_REFRESH),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                try { mgr.requestPinAppWidget(provider, null, cb) } catch (_: Throwable) {
                    Toast.makeText(activity, "হোমস্ক্রিনে ফাঁকা জায়গায় ধরে রেখে \"উইজেট\" থেকে যুক্ত করুন", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(
                    activity, "আপনার লঞ্চার সরাসরি যুক্ত করা সাপোর্ট করে না — হোম স্ক্রিনে ফাঁকা জায়গায় ধরে রেখে \"উইজেট\" → \"পাথেয়\" বেছে নিন।",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // ============================================================
    // ✅ v135: উইজেট হাব (লাইভ প্রিভিউ, থিম, ডিজাইন নির্বাচন, তারিখ সেটিং)
    // সব সেটিং Prefs-এ (SharedPreferences) সেভ হয়; প্রিভিউ ও থাম্বনেইল ঠিক সেই রেন্ডারারেই আঁকা হয় যা
    // হোমস্ক্রিনের উইজেট আঁকে — তাই প্রিভিউ আর আসল উইজেট সবসময় হুবহু এক।
    // ============================================================

    private val hubHandler = Handler(Looper.getMainLooper())
    private val hubPush = Runnable { try { WidgetUpdater.updateAll(activity.applicationContext) } catch (_: Throwable) {} }

    /** সেটিং বদলালে হোমস্ক্রিনের উইজেট ~১৫০ms পরে (বারবার নয়, একবার) নতুন করে আঁকা হয় */
    private fun hubPushSoon() {
        hubHandler.removeCallbacks(hubPush)
        hubHandler.postDelayed(hubPush, 150)
    }

    private fun hubHex(rgb: Int) = String.format("#%06X", rgb and 0xFFFFFF)

    @JavascriptInterface
    fun getHubState(): String {
        val p = Prefs.get(activity.applicationContext)
        val onHome = try {
            AppWidgetManager.getInstance(activity).getAppWidgetIds(ComponentName(activity, PrayerWidgetProvider::class.java)).isNotEmpty()
        } catch (_: Throwable) { false }
        return org.json.JSONObject().apply {
            put("theme", p.theme); put("nobgMode", p.nobgMode)
            put("design", p.design); put("widgetDesign", p.widgetDesign)
            put("customBg", hubHex(p.customBg)); put("customOpacity", p.customOpacity); put("customTone", p.customTone)
            put("gregFirst", p.gregFirst); put("onHome", onHome)
        }.toString()
    }

    @JavascriptInterface
    fun setHubTheme(theme: String) {
        if (theme !in listOf("glass", "nobg", "light", "custom")) return
        Prefs.get(activity.applicationContext).theme = theme
        hubPushSoon()
    }

    @JavascriptInterface
    fun setHubNobgMode(mode: String) {
        Prefs.get(activity.applicationContext).nobgMode = if (mode == "light") "light" else "dark"
        hubPushSoon()
    }

    /** কার্ডে চাপ — শুধু প্রিভিউয়ে দেখায় (হোম স্ক্রিনের উইজেট বদলায় না) */
    @JavascriptInterface
    fun setHubDesign(n: Int) {
        Prefs.get(activity.applicationContext).design = n.coerceIn(1, 9)
    }

    /** কোণার গোল বাটনে চাপ — এই ডিজাইনটাই হোম-স্ক্রিনের উইজেট। হোম স্ক্রিনে উইজেট থাকলে true */
    @JavascriptInterface
    fun setHubWidgetDesign(n: Int): Boolean {
        val p = Prefs.get(activity.applicationContext)
        p.design = n.coerceIn(1, 9)
        p.widgetDesign = n.coerceIn(1, 9)
        hubPushSoon()
        val onHome = try {
            AppWidgetManager.getInstance(activity).getAppWidgetIds(ComponentName(activity, PrayerWidgetProvider::class.java)).isNotEmpty()
        } catch (_: Throwable) { false }
        // বার্তা শুধু তখনই, যখন সত্যিই হোম স্ক্রিনে উইজেট যুক্ত করা আছে
        if (onHome) activity.runOnUiThread { Toast.makeText(activity, "হোম স্ক্রিন উইজেট হিসেবে সেট হয়েছে", Toast.LENGTH_SHORT).show() }
        return onHome
    }

    @JavascriptInterface
    fun setHubCustom(hex: String, opacity: Int, tone: String) {
        val p = Prefs.get(activity.applicationContext)
        try {
            var h = hex.trim().removePrefix("#")
            if (h.length == 3) h = h.map { "$it$it" }.joinToString("")
            if (h.length == 6) p.customBg = h.toInt(16)
        } catch (_: Throwable) {}
        p.customOpacity = opacity
        p.customTone = if (tone == "dark" || tone == "light") tone else "auto"
        hubPushSoon()
    }

    /** "ইংরেজি তারিখ আগে" ট্রগল */
    @JavascriptInterface
    fun setHubGregFirst(on: Boolean) {
        Prefs.get(activity.applicationContext).gregFirst = on
        HubPreview.invalidate()
        hubPushSoon()
    }

    /** লাইভ প্রিভিউ/থাম্বনেইলের ছবি (PNG data-URL); প্রতি কলে "এখনকার" সময়ে আঁকা (ঘড়ি/কাউন্টারসহ) */
    @JavascriptInterface
    fun renderHubPreview(design: Int, widthPx: Int): String =
        try { HubPreview.render(activity.applicationContext, design.coerceIn(1, 9), widthPx) } catch (_: Throwable) { "" }

    @JavascriptInterface
    fun saveAlarmConfigs(jsonString: String) { AlarmScheduler.saveAlarmConfig(activity, jsonString) }

    /** ধাপ ৮: নফল নামাজের অ্যালার্ম (ইশরাক/চাশত/আওয়াবিন/তাহাজ্জুদ) — অ্যাপ বন্ধ থাকলেও বাজে */
    @JavascriptInterface
    fun saveNafalAlarms(jsonString: String) { try { com.gunjoron.patheyo.reminder.ReminderAlarms.saveNafal(activity, jsonString) } catch (_: Throwable) {} }

    /** ধাপ ৮: কুরআন খতমের দৈনিক রিমাইন্ডার */
    @JavascriptInterface
    fun saveKhatmReminder(jsonString: String) { try { com.gunjoron.patheyo.reminder.ReminderAlarms.saveKhatm(activity, jsonString) } catch (_: Throwable) {} }

    @JavascriptInterface
    fun showAzanNotification(waqtKey: String, waqtName: String) {
        val serviceIntent = Intent(activity, AzanForegroundService::class.java).apply {
            putExtra("waqt", waqtKey)
            putExtra("waqtName", waqtName)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity.startForegroundService(serviceIntent)
        } else {
            activity.startService(serviceIntent)
        }
    }

    @JavascriptInterface
    fun showAzanOverlay(waqtName: String) {
        val overlayIntent = Intent(activity, AzanOverlayActivity::class.java).apply {
            putExtra("waqtName", waqtName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        activity.startActivity(overlayIntent)
    }

    @JavascriptInterface
    fun hasExactAlarmPermission(): Boolean = AlarmScheduler.canScheduleExact(activity)

    @JavascriptInterface
    fun requestExactAlarmPermission() {
        activity.runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                try { activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply { data = Uri.parse("package:${activity.packageName}") }) }
                catch (_: Exception) { Toast.makeText(activity, "সেটিংস → Alarms & reminders থেকে অনুমতি দিন", Toast.LENGTH_LONG).show() }
            } else {
                Toast.makeText(activity, "এই ফোনে আলাদা করে এই অনুমতি লাগে না", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ============================================================
    // ✅ নতুন: "পারমিশন সেন্টার" — সব দরকারি পারমিশন এক জায়গায়,
    // প্রতিটার জন্য এক-ক্লিকে সঠিক সেটিংস স্ক্রিনে নিয়ে যাওয়ার ব্রিজ
    // ============================================================

    // বর্তমানে কোন কোন পারমিশন/অনুমতি চালু আছে তা JSON আকারে JS-কে জানানো, যাতে
    // "পারমিশন" ট্যাবে প্রতিটার পাশে ✅/❌ লাইভ দেখানো যায়
    @JavascriptInterface
    fun checkAllPermissionsStatus(): String {
        val exactAlarm = try { AlarmScheduler.canScheduleExact(activity) } catch (_: Exception) { true }

        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            androidx.core.app.NotificationManagerCompat.from(activity).areNotificationsEnabled()
        }

        val location = androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

        val battery = try {
            val pm = activity.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            pm.isIgnoringBatteryOptimizations(activity.packageName)
        } catch (_: Exception) { true }

        val fullScreen = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                val nm = activity.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                nm.canUseFullScreenIntent()
            } catch (_: Exception) { true }
        } else true

        return org.json.JSONObject().apply {
            put("exactAlarm", exactAlarm)
            put("notification", notif)
            put("location", location)
            put("battery", battery)
            put("fullScreen", fullScreen)
        }.toString()
    }

    // লোকেশন পারমিশন — প্রথমবার হলে সরাসরি অ্যান্ড্রয়েডের নিজস্ব পপ-আপ দেখায়;
    // আগে একবার "Don't ask again" করে দিলে (permanently denied) সরাসরি অ্যাপ সেটিংস পেজে নিয়ে যায়,
    // কারণ Android-এ পার্মানেন্টলি ডিনাই করা পারমিশন কোড দিয়ে আর দ্বিতীয়বার পপ-আপ দেখানো যায় না।
    @JavascriptInterface
    fun requestLocationPermission() {
        activity.runOnUiThread {
            // v47: "সঠিক" বা "আনুমানিক" — যেকোনো একটা দেওয়া থাকলেই চালু ধরা হয় (Android 12+ এ ইউজার আনুমানিক দিতে পারেন)
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted) { Toast.makeText(activity, "লোকেশন পারমিশন আগে থেকেই চালু আছে", Toast.LENGTH_SHORT).show(); return@runOnUiThread }
            val mainAct = activity as? com.gunjoron.patheyo.MainActivity
            if (mainAct != null && androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                mainAct.requestLocationPermissionFromJs()
            } else if (mainAct != null && !hasAskedLocationBefore()) {
                markAskedLocationBefore()
                mainAct.requestLocationPermissionFromJs()
            } else {
                openAppDetailsSettings()
            }
        }
    }

    // নোটিফিকেশন পারমিশন — Android 13+ এ প্রথমবার সরাসরি পপ-আপ, নাহলে অ্যাপ নোটিফিকেশন সেটিংসে
    @JavascriptInterface
    fun requestNotificationPermission() {
        activity.runOnUiThread {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                openAppNotificationSettings(); return@runOnUiThread
            }
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted) { Toast.makeText(activity, "নোটিফিকেশন পারমিশন আগে থেকেই চালু আছে", Toast.LENGTH_SHORT).show(); return@runOnUiThread }
            val mainAct = activity as? com.gunjoron.patheyo.MainActivity
            if (mainAct != null && androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.POST_NOTIFICATIONS)) {
                mainAct.requestNotificationPermissionFromJs()
            } else if (mainAct != null && !hasAskedNotifBefore()) {
                markAskedNotifBefore()
                mainAct.requestNotificationPermissionFromJs()
            } else {
                openAppNotificationSettings()
            }
        }
    }

    private fun hasAskedLocationBefore(): Boolean =
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).getBoolean("asked_location", false)
    private fun markAskedLocationBefore() {
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).edit().putBoolean("asked_location", true).apply()
    }
    private fun hasAskedNotifBefore(): Boolean =
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).getBoolean("asked_notif", false)
    private fun markAskedNotifBefore() {
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).edit().putBoolean("asked_notif", true).apply()
    }

    // ব্যাটারি অপ্টিমাইজেশন বাদ দেওয়ার সরাসরি এক-ক্লিক পপ-আপ (এইটাই সবচেয়ে গুরুত্বপূর্ণ —
    // এটা না দিলে অনেক ফোন ব্যাকগ্রাউন্ডে অ্যাপকে জোর করে ঘুম পাড়িয়ে দেয়, আজান/উইজেট বন্ধ হয়ে যায়)
    @JavascriptInterface
    fun openBatteryOptimizationSettings() {
        activity.runOnUiThread {
            try {
                val pm = activity.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                if (pm.isIgnoringBatteryOptimizations(activity.packageName)) {
                    Toast.makeText(activity, "ব্যাটারি অপ্টিমাইজেশন থেকে অ্যাপ আগে থেকেই বাদ দেওয়া আছে", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                activity.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${activity.packageName}")
                })
            } catch (_: Exception) {
                try {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(activity, "সেটিংস → ব্যাটারি → অ্যাপ থেকে ম্যানুয়ালি অনুমতি দিন", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // অ্যাপের নোটিফিকেশন সেটিংস পেজ (নোটিফিকেশন বন্ধ থাকলে চালু করার জন্য)
    @JavascriptInterface
    fun openAppNotificationSettings() {
        activity.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
                    })
                } else {
                    openAppDetailsSettings()
                }
            } catch (_: Exception) { openAppDetailsSettings() }
        }
    }

    // Android 14+ এ ফুল-স্ক্রিন অ্যালার্ম (লক স্ক্রিনেও আজানের স্ক্রিন দেখানো) অনুমতি
    @JavascriptInterface
    fun openFullScreenIntentSettings() {
        activity.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply {
                        data = Uri.parse("package:${activity.packageName}")
                    })
                } else {
                    Toast.makeText(activity, "এই ফোনে আলাদা করে এই অনুমতি লাগে না", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) { openAppDetailsSettings() }
        }
    }

    // অটো-স্টার্ট / ব্যাকগ্রাউন্ড লক (Xiaomi, Oppo, Vivo, Realme, Huawei, Samsung, Asus, Letv ইত্যাদি
    // কাস্টম Android স্কিনে থাকা নিজস্ব সেটিংস স্ক্রিন) — কোনো স্ট্যান্ডার্ড Android API নেই বলে
    // পরিচিত OEM-ভিত্তিক ইন্টেন্ট একটার পর একটা চেষ্টা করা হয়, না পেলে অ্যাপ ইনফো পেজে পাঠানো হয়।
    @JavascriptInterface
    fun openAutoStartSettings() {
        activity.runOnUiThread {
            // ✅ v44: লজিক এখন alarm/AlarmReliability-তে। আগের কোডে resolveActivity() দিয়ে চেক হতো, যেটা
            // অ্যান্ড্রয়েড ১১+ এ (package visibility) সবসময় null দিত — ফলে Honor/Huawei/Xiaomi সহ কোনো OEM-এর
            // অটো-স্টার্ট স্ক্রিনই খুলত না। এখন সরাসরি চেষ্টা করা হয়, ব্র্যান্ড অনুযায়ী সঠিক স্ক্রিন আগে।
            val opened = com.gunjoron.patheyo.alarm.AlarmReliability.openOemBackgroundSettings(activity)
            if (!opened) {
                Toast.makeText(activity, "এই ফোনের জন্য নির্দিষ্ট অটো-স্টার্ট মেনু পাওয়া যায়নি, অ্যাপ সেটিংসে নিয়ে যাওয়া হচ্ছে", Toast.LENGTH_LONG).show()
                openAppDetailsSettings()
            }
        }
    }

    // সবার জন্য fallback — অ্যাপের নিজস্ব সেটিংস (App Info) পেজ, যেখান থেকে ম্যানুয়ালি
    // যেকোনো পারমিশন চালু/বন্ধ করা যায় — কোনো নির্দিষ্ট শর্টকাট কাজ না করলে এখানে পাঠানো হয়
    @JavascriptInterface
    fun openAppDetailsSettings() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${activity.packageName}")
                })
            } catch (_: Exception) {
                Toast.makeText(activity, "সেটিংস অ্যাপ খোলা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // JS থেকে আজান বন্ধ করার ব্রিজ — অ্যাপের ভিতরে একটা বাটনে ক্লিক করলেই কাজ করবে
    @JavascriptInterface
    fun stopAzan() {
        activity.runOnUiThread {
            val stopIntent = Intent(activity, AzanForegroundService::class.java).apply { action = AzanForegroundService.ACTION_STOP }
            activity.startService(stopIntent)
        }
    }

    // Firebase Remote Config থেকে পাওয়া hijri adjustment ও method ID WebView-এ কাজে লাগানোর জন্য
    // এই ফাংশনটা MainActivity.kt থেকে সরাসরি call করা হয় (JavascriptInterface নয়)
    fun injectHijriConfig(hijriAdjustment: Int, methodId: Int) {
        // MainActivity onPageFinished থেকে evaluateJavascript দিয়ে inject করা হয়
        // এখানে শুধু মান store করা হয়, যাতে page reload হলে আবার inject করা যায়
        activity.getSharedPreferences("ibadat_hijri_prefs", Context.MODE_PRIVATE)
            .edit().putInt("adjustment", hijriAdjustment).putInt("methodId", methodId).apply()
    }

    fun getSavedHijriAdjustment(): Int =
        activity.getSharedPreferences("ibadat_hijri_prefs", Context.MODE_PRIVATE).getInt("adjustment", 0)

    fun getSavedMethodId(): Int =
        activity.getSharedPreferences("ibadat_hijri_prefs", Context.MODE_PRIVATE).getInt("methodId", 1)
}


/** হাবের প্রিভিউ আঁকার সহায়ক — Snapshot ক্যাশ করে (ওয়াক্ত বদলালে বা তথ্য বদলালে নতুন)। */
object HubPreview {
    @Volatile private var snap: Snapshot? = null

    fun invalidate() { snap = null }

    @Synchronized
    fun render(ctx: Context, design: Int, widthPx: Int): String {
        Fonts.init(ctx)
        val now = System.currentTimeMillis()
        var s = snap
        if (s == null || now >= s.nextChangeMs || kotlin.math.abs(now - s.nowMs) > 60 * 60_000L) {
            s = Snapshot.build(ctx, now); snap = s
        }
        val look = Look.from(Prefs.get(ctx), design = design)
        val compact = WidgetRenderer.isCompact(design, s)
        val cw = WidgetRenderer.cardW(design) + 2 * WidgetRenderer.PAD
        val ch = WidgetRenderer.cardH(design, compact) + 2 * WidgetRenderer.PAD
        val w = widthPx.coerceIn(120, 1400)
        val h = (w * ch / cw).roundToInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        WidgetRenderer.draw(ctx, Canvas(bmp), w.toFloat(), h.toFloat(), look, s, true, now)
        val out = ByteArrayOutputStream(w * h / 4)
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
