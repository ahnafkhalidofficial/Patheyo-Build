package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/NativePrayerTimesFetcher.kt
//
// ✅ FIX #NEW (v5): এতদিন নামাজের সময়ের সুনির্দিষ্ট মিনিট-মান (fajr/dhuhr/asr ইত্যাদির hh:mm)
// শুধুমাত্র অ্যাপ (WebView/JS) খোলা অবস্থায় Aladhan API থেকে fetch হতো — অ্যাপ না খুললে widget
// পুরনো ক্যাশড মান দিয়েই চলত, যা মাস-খানেক পর মৌসুমভেদে কয়েক মিনিট এদিক-সেদিক হয়ে যেতে পারত।
//
// এই ফাইলটা ঠিক সেই একই Aladhan API-কে, ঠিক একই প্যারামিটার (lat/lng/method/school) ও ঠিক একই
// পোস্ট-প্রসেসিং (মাগরিব/সূর্যাস্তে +৩ মিনিট স্থায়ী অফসেট, তারপর ব্যবহারকারীর নিজস্ব প্রতি-ওয়াক্ত
// মিনিট-অ্যাডজাস্টমেন্ট) দিয়ে, সম্পূর্ণ নেটিভভাবে (কোনো WebView ছাড়াই) ব্যাকগ্রাউন্ডে কল করে —
// index.html-এর fetchCorePrayerData()/applyWaqtMinuteOffsets() ফাংশনের হুবহু নেটিভ সংস্করণ।
//
// গুরুত্বপূর্ণ: এটা হিজরি তারিখ স্পর্শ করে না — হিজরি তারিখ সম্পূর্ণভাবে FirebaseDataManager-এর
// আলাদা, ইতোমধ্যে স্থিতিশীল দিন-গণনা লজিক দিয়ে চলে (v3/v4 ফিক্স, অক্ষত থাকছে)। এখানে শুধু
// fajr/sunrise/dhuhr/asr/maghrib/isha/sunset ও isRamadan আপডেট হয়।
//
// এই পুরো ফাইলটা try-catch(Throwable) দিয়ে ঘেরা — নেট না থাকলে, API ব্যর্থ হলে, বা অন্য যেকোনো
// কারণে ব্যর্থ হলে চুপচাপ ফিরে আসে এবং আগের ক্যাশড সময়ই বহাল থাকে (v4-এর নীতি অনুসরণ করে: কোনো
// অবস্থাতেই widget-রিফ্রেশ চেইন এতে ভেঙে পড়বে না)।

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

object NativePrayerTimesFetcher {

    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 10_000

    // ডিফল্ট লোকেশন — ঢাকা (index.html-এর userLat/userLng ডিফল্টের সাথে হুবহু মিল রাখা হলো,
    // যাতে অ্যাপ কখনো খোলাই না হলেও একটা যুক্তিসঙ্গত ডিফল্ট দিয়ে কাজ চলে)
    private const val DEFAULT_LAT = 23.8103
    private const val DEFAULT_LNG = 90.4125

    /**
     * প্রয়োজন হলে (আজকের তারিখের জন্য এখনো fetch করা না থাকলে) ব্যাকগ্রাউন্ডে নেটিভভাবে
     * নামাজের সময় re-fetch করে prefs আপডেট করে। এই ফাংশনটা ব্লকিং (synchronous network call) —
     * তাই এটা শুধুমাত্র WorkManager Worker-এর মতো আগে থেকেই ব্যাকগ্রাউন্ড থ্রেডে থাকা জায়গা
     * থেকে কল করতে হবে, মূল (UI) থ্রেড থেকে নয়।
     *
     * @return true হলে নতুন ডেটা সফলভাবে আপডেট হয়েছে, false হলে হয় দরকার ছিল না (আগে থেকেই আজকের
     *         জন্য ফ্রেশ) অথবা fetch ব্যর্থ হয়েছে (দুই ক্ষেত্রেই আগের ক্যাশড ডেটা অক্ষত থাকে)।
     */
    fun fetchIfStale(context: Context): Boolean {
        return try {
            fetchIfStaleInternal(context)
        } catch (t: Throwable) {
            // কোনো অবস্থাতেই এখান থেকে exception propagate করা যাবে না — কলার
            // (WidgetUpdateWorker/PrayerWidgetProvider) যেন নিশ্চিন্তে কল করতে পারে।
            false
        }
    }

    /**
     * ✅ v24: আজকের নামাজের সময় বাসি কি না — নেটওয়ার্ক ছাড়া, মেইন থ্রেডেও নিরাপদ (শুধু SharedPreferences)।
     * "আজকের জন্য ফ্রেশ" = অ্যাপ (JS) আজ সময় সেভ করেছে (timings_fetched_on) অথবা নেটিভ fetch আজ সফল হয়েছে
     * (times_fresh_on)।
     */
    fun isStale(context: Context): Boolean {
        return try {
            val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            val today = com.gunjoron.patheyo.FirebaseDataManager.todayDateOnlyStr()
            val existingJson = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null)
            existingJson == null ||
                (prefs.getString("timings_fetched_on", null) != today && prefs.getString(KEY_FRESH_ON, null) != today)
        } catch (_: Throwable) { false }
    }

    private const val KEY_FRESH_ON = "times_fresh_on"

    private fun fetchIfStaleInternal(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val today = com.gunjoron.patheyo.FirebaseDataManager.todayDateOnlyStr()
        val existingJson = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null)

        // ইতোমধ্যে আজকের জন্য ফ্রেশ ডেটা থাকলে আবার নেটওয়ার্ক কল করার দরকার নেই
        if (!isStale(context)) return false

        // নেট সংযোগ আছে কিনা আগেভাগে যাচাই — না থাকলে অহেতুক টাইমআউট অপেক্ষা এড়ানো
        if (!isNetworkAvailable(context)) return false

        val old = try { if (existingJson != null) JSONObject(existingJson) else null } catch (_: Exception) { null }

        val lat = old?.optDouble("lat", DEFAULT_LAT)?.takeIf { !it.isNaN() } ?: DEFAULT_LAT
        val lng = old?.optDouble("lng", DEFAULT_LNG)?.takeIf { !it.isNaN() } ?: DEFAULT_LNG
        val school = old?.optString("school", "1")?.ifBlank { "1" } ?: "1"

        val hijriPrefs = context.getSharedPreferences("ibadat_hijri_prefs", Context.MODE_PRIVATE)
        // ধাপ ৩: ব্যবহারকারী নামাজ পেজে নিজে হিসাবের পদ্ধতি বেছে নিলে সেটা saveTimings-এর "method" ফিল্ডে আসে — সেটাই আগে
        val methodId = old?.optInt("method", 0)?.takeIf { it > 0 } ?: hijriPrefs.getInt("methodId", 1)

        val cal = Calendar.getInstance()
        val dateStr = String.format(
            Locale.US, "%02d-%02d-%04d",
            cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR)
        )

        val url = "https://api.aladhan.com/v1/timings/$dateStr" +
            "?latitude=$lat&longitude=$lng&method=$methodId&school=$school&adjustment=0"

        val responseText = httpGet(url) ?: return false

        val root = JSONObject(responseText)
        val data = root.optJSONObject("data") ?: return false
        val timings = data.optJSONObject("timings") ?: return false

        // ✅ index.html-এর applyWaqtMinuteOffsets()-এর হুবহু নেটিভ প্রতিরূপ:
        // ১) মাগরিব ও সূর্যাস্তে স্থায়ী +৩ মিনিট
        // ২) তারপর ব্যবহারকারীর নিজস্ব প্রতি-ওয়াক্ত মিনিট-অ্যাডজাস্টমেন্ট (থাকলে)
        val offsets = old?.optJSONObject("waqtMinuteOffsets")

        var fajr = cleanTime(timings.optString("Fajr", ""))
        val sunrise = cleanTime(timings.optString("Sunrise", ""))
        var dhuhr = cleanTime(timings.optString("Dhuhr", ""))
        var asr = cleanTime(timings.optString("Asr", ""))
        var maghrib = cleanTime(timings.optString("Maghrib", ""))
        var isha = cleanTime(timings.optString("Isha", ""))
        var sunset = cleanTime(timings.optString("Sunset", ""))

        maghrib = shiftTimeStr(maghrib, 3)
        sunset = shiftTimeStr(sunset, 3)

        fajr = shiftTimeStr(fajr, offsets?.optInt("Fajr", 0) ?: 0)
        dhuhr = shiftTimeStr(dhuhr, offsets?.optInt("Dhuhr", 0) ?: 0)
        asr = shiftTimeStr(asr, offsets?.optInt("Asr", 0) ?: 0)
        maghrib = shiftTimeStr(maghrib, offsets?.optInt("Maghrib", 0) ?: 0)
        isha = shiftTimeStr(isha, offsets?.optInt("Isha", 0) ?: 0)

        if (fajr.isBlank() || dhuhr.isBlank() || asr.isBlank() || maghrib.isBlank() || isha.isBlank()) {
            // অসম্পূর্ণ/অপ্রত্যাশিত রেসপন্স — নিরাপদে বাদ দেওয়া হলো, পুরনো ক্যাশড ডেটাই থাকবে
            return false
        }

        // ✅ isRamadan এখন FirebaseDataManager-এর ইতোমধ্যে-স্থিতিশীল (v3/v4) দিন-গণনা লজিক দিয়েই
        // বের করা হচ্ছে — হিজরি তারিখের জন্য আলাদা কোনো নতুন হিসাব এখানে যোগ করা হয়নি।
        val isRamadan = try {
            com.gunjoron.patheyo.FirebaseDataManager.getCorrectedTodayHijriDayMonth(context)?.second == 9
        } catch (_: Exception) { old?.optBoolean("isRamadan", false) ?: false }

        val newJson = JSONObject()
        newJson.put("fajr", fajr)
        newJson.put("sunrise", sunrise)
        newJson.put("dhuhr", dhuhr)
        newJson.put("asr", asr)
        newJson.put("maghrib", maghrib)
        newJson.put("isha", isha)
        newJson.put("sunset", sunset.ifBlank { maghrib })
        newJson.put("isRamadan", isRamadan)
        // এই ৩টা ক্ষেত্র (gregorian/hijri/bangla) widget আর প্রদর্শনের জন্য ব্যবহার করে না (দুটোই
        // প্রতিবার সরাসরি ফোনের ক্যালেন্ডার থেকে হিসাব হয়) — শুধু পুরনো মান রেখে দেওয়া হচ্ছে
        // backward-compatibility ও fallback anchor হিসেবে।
        if (old != null) {
            newJson.put("gregorian", old.optString("gregorian", ""))
            newJson.put("hijri", old.optString("hijri", "-- --- ----"))
            newJson.put("bangla", old.optString("bangla", ""))
        }
        // lat/lng/school/waqtMinuteOffsets পরের বারের নেটিভ fetch-এর জন্য সংরক্ষণ করে রাখা হচ্ছে
        newJson.put("lat", lat)
        newJson.put("lng", lng)
        newJson.put("school", school)
        if (offsets != null) newJson.put("waqtMinuteOffsets", offsets)

        prefs.edit()
            .putString(PrayerWidgetProvider.KEY_TIMINGS, newJson.toString())
            // ✅ v24 BUGFIX: আগে এখানে "timings_fetched_on"-ও আজকের তারিখে বসে যেত, কিন্তু "hijri" স্ট্রিংটা পুরনো
            // দিনেরই থেকে যেত। উইজেট/FirebaseDataManager হিজরি তারিখ বের করে "hijri + (আজ − timings_fetched_on)
            // দিন" দিয়ে — তাই নেটিভ fetch হলে হিজরি তারিখ ঐ কয়দিন পিছিয়ে থাকত। এখন সেটা শুধু অ্যাপ/JS-ই বসায়
            // (hijri-র সাথে জোড়ায়); নেটিভ fetch আলাদা key (times_fresh_on) ব্যবহার করে।
            .putString(KEY_FRESH_ON, today)
            .putLong("last_sync_timestamp", System.currentTimeMillis())
            .apply()

        // নতুন (মিনিট-নির্ভুল) সময় অনুযায়ী widget ও ওয়াক্ত-ভিত্তিক অ্যালার্ম চেইন রিফ্রেশ করা
        try { PrayerWidgetProvider.updateWidgetDirectly(context) } catch (_: Throwable) {}
        try { WidgetRefreshScheduler.scheduleAll(context) } catch (_: Throwable) {}

        return true
    }

    // Aladhan API মাঝেমধ্যে "HH:mm (TZ)" ফরম্যাটে সময় দেয় — বন্ধনীর অংশ বাদ দিয়ে শুধু "HH:mm" রাখা হয়
    private fun cleanTime(raw: String): String {
        val trimmed = raw.trim()
        val spaceIdx = trimmed.indexOf(' ')
        return if (spaceIdx != -1) trimmed.substring(0, spaceIdx) else trimmed
    }

    // index.html-এর shiftTimeStr()-এর হুবহু নেটিভ প্রতিরূপ
    private fun shiftTimeStr(hhmm: String, offsetMin: Int): String {
        if (hhmm.isBlank() || offsetMin == 0) return hhmm
        return try {
            val parts = hhmm.split(":")
            val h = parts[0].toInt(); val m = parts[1].toInt()
            var total = (h * 60 + m + offsetMin) % 1440
            if (total < 0) total += 1440
            String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
        } catch (_: Exception) { hhmm }
    }

    private fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return true
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                val network = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(network) ?: return false
                caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Throwable) { true } // অনিশ্চিত হলে চেষ্টা করাই ভালো, HTTP কলের নিজস্ব টাইমআউট আছে
    }

    private fun httpGet(urlStr: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlStr)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Throwable) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }
}
