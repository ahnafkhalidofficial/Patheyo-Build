package com.gunjoron.patheyo.datecard

import android.app.Activity
import android.content.Intent
import android.webkit.JavascriptInterface

/** হোমের "তারিখ-কার্ড" টাইল থেকে নেটিভ স্ক্রিন খোলে — JS-এ নাম: PatheyoDateCard */
class DateCardBridge(private val activity: Activity) {
    @JavascriptInterface
    fun open() {
        activity.runOnUiThread {
            try { activity.startActivity(Intent(activity, DateCardActivity::class.java)) } catch (_: Throwable) {}
        }
    }
}
