package com.gunjoron.patheyo.datecard

import android.graphics.Color

/** তারিখ-কার্ডের ইসলামিক থিম। সব ছবি কোডে আঁকা (Canvas) — অ্যাপের সাইজ বাড়ে না, যেকোনো মাপে ঝকঝকে। */
enum class CardPattern { NONE, STAR, FLOWER, DIAMOND }
enum class CardScene { NONE, MOSQUE, DAWN, DUNES, LANTERNS, KAABA, MOON, ARCH }

class DateCardTheme(
    val id: String,
    val name: String,
    /** উপর থেকে নিচে গ্রেডিয়েন্ট */
    val bg: IntArray,
    val text: Int,
    val accent: Int,
    /** মসজিদ/টিলা ইত্যাদির সিলুয়েটের রং */
    val sil: Int,
    val pattern: CardPattern,
    val scene: CardScene,
    /** আলোকিত (দিনের) থিম — প্যানেল সাদাটে, লেখা গাঢ় */
    val light: Boolean = false,
    /** প্যাটার্নের রং (না দিলে accent) */
    val patternColor: Int = 0
)

object DateCardThemes {
    private fun c(h: String) = Color.parseColor(h)

    val ALL: List<DateCardTheme> = listOf(
        DateCardTheme("noor", "নূরের রাত",
            intArrayOf(c("#071A44"), c("#0F3677"), c("#18508F")), c("#FFFFFF"), c("#E8C468"), c("#050F2B"),
            CardPattern.STAR, CardScene.MOSQUE),
        DateCardTheme("jannat", "জান্নাতি সবুজ",
            intArrayOf(c("#04291F"), c("#0A5A43"), c("#12805F")), c("#F4FFF8"), c("#F2D27A"), c("#03180F"),
            CardPattern.STAR, CardScene.MOSQUE),
        DateCardTheme("gold", "সোনালি কালো",
            intArrayOf(c("#060606"), c("#141008"), c("#251C0A")), c("#F7E9BE"), c("#D9B24A"), c("#000000"),
            CardPattern.FLOWER, CardScene.ARCH),
        DateCardTheme("fajr", "ফজরের ভোর",
            intArrayOf(c("#1B1747"), c("#6A3A8C"), c("#F08A5D")), c("#FFFFFF"), c("#FFE3A3"), c("#1A0F33"),
            CardPattern.NONE, CardScene.DAWN),
        DateCardTheme("moon", "চাঁদের রাত",
            intArrayOf(c("#040919"), c("#0C1B45"), c("#17306B")), c("#FFFFFF"), c("#F7E7A1"), c("#040919"),
            CardPattern.NONE, CardScene.MOON),
        DateCardTheme("desert", "মরুর সোনা",
            intArrayOf(c("#FBEBC4"), c("#F0CB86"), c("#D99E4F")), c("#4A2A0A"), c("#8F4E12"), c("#8A4F1B"),
            CardPattern.NONE, CardScene.DUNES, light = true),
        DateCardTheme("rose", "গোলাপি নূর",
            intArrayOf(c("#FFF3F5"), c("#F9D2DD"), c("#EFA9BF")), c("#4E1530"), c("#A8285C"), c("#B03A66"),
            CardPattern.FLOWER, CardScene.ARCH, light = true, patternColor = c("#C2467A")),
        DateCardTheme("marble", "সাদা মার্বেল",
            intArrayOf(c("#FFFFFF"), c("#E9F1F4"), c("#CFE0E7")), c("#0D3445"), c("#1B7487"), c("#2C6E80"),
            CardPattern.STAR, CardScene.MOSQUE, light = true, patternColor = c("#1B7487")),
        DateCardTheme("kaaba", "কাবার আলো",
            intArrayOf(c("#000000"), c("#0B0B0B"), c("#1C1A14")), c("#FFFFFF"), c("#D9B24A"), c("#000000"),
            CardPattern.DIAMOND, CardScene.KAABA),
        DateCardTheme("turquoise", "ফিরোজা মোজাইক",
            intArrayOf(c("#06505B"), c("#0E8088"), c("#1DB0A8")), c("#FFFFFF"), c("#FFE29A"), c("#04363F"),
            CardPattern.FLOWER, CardScene.MOSQUE),
        DateCardTheme("lantern", "ফানুসের রাত",
            intArrayOf(c("#220B38"), c("#3E1866"), c("#5C2A8A")), c("#FFFFFF"), c("#FFC857"), c("#1A0A2B"),
            CardPattern.NONE, CardScene.LANTERNS),
        DateCardTheme("sky", "নীল আকাশ",
            intArrayOf(c("#6FB6EE"), c("#B6DDF8"), c("#EAF6FF")), c("#0B3358"), c("#1D6DB5"), c("#1B5C98"),
            CardPattern.NONE, CardScene.MOSQUE, light = true)
    )

    fun byId(id: String): DateCardTheme? = ALL.firstOrNull { it.id == id }

    /** "auto": তারিখ ধরে প্রতিদিন আলাদা থিম (বছরের দিন + বছর থেকে হিসাব, তাই একই দিনে সবসময় একই থিম) */
    fun forDay(id: String, dayOfYear: Int, year: Int): DateCardTheme {
        byId(id)?.let { return it }
        return ALL[Math.floorMod(dayOfYear + year * 7, ALL.size)]
    }
}
