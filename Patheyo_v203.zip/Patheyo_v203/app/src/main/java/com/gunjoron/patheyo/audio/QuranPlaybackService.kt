package com.gunjoron.patheyo.audio

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.gunjoron.patheyo.MainActivity
import com.gunjoron.patheyo.R

/**
 * কুরআন তিলাওয়াতের পূর্ণ ব্যাকগ্রাউন্ড প্লেয়ার (Media3)।
 *
 *  • ফোরগ্রাউন্ড সার্ভিস (mediaPlayback) — অ্যাপ মিনিমাইজ বা স্ক্রিন বন্ধ থাকলেও তিলাওয়াত চলে।
 *  • নোটিফিকেশন ও লক-স্ক্রিনে প্লে / পজ / আগের / পরের বাটন (Media3 নিজেই বানায়)।
 *  • ব্লুটুথ/হেডসেটের মিডিয়া-বাটনও কাজ করে (MediaSession)।
 *  • আয়াত-রিপিটে প্লে-লিস্টে একই আয়াত একাধিকবার থাকে (mediaId = "<আয়াত-সূচক>:<বার>"),
 *    তাই "পরের/আগের" চাপলে এক আয়াত থেকে পরের আসল আয়াতে যায় — রিপিটের কপিতে নয় (নিচের [SkipAyahPlayer])।
 *
 * কন্ট্রোল আসে [QuranAudioEngine] → MediaController পথে; ওয়েবভিউ (JS) শুধু [QuranAudioBridge] দিয়ে ইঞ্জিনকে ডাকে।
 */
class QuranPlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_SPEECH)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)          // হেডফোন খুলে গেলে নিজে থেমে যায়
            .setWakeMode(C.WAKE_MODE_NETWORK)           // স্ক্রিন বন্ধেও CPU + ওয়াইফাই জাগ্রত (স্ট্রিমিং চলতে থাকে)
            .build()

        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        session = MediaSession.Builder(this, SkipAyahPlayer(exo))
            .setSessionActivity(open)
            .setCallback(object : MediaSession.Callback {
                // কন্ট্রোলার থেকে আসা আইটেমে URI না থাকলে requestMetadata থেকে বসানো
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>
                ): ListenableFuture<MutableList<MediaItem>> {
                    val fixed = mediaItems.map { item ->
                        if (item.localConfiguration != null) item
                        else item.buildUpon().setUri(item.requestMetadata.mediaUri).build()
                    }.toMutableList()
                    return Futures.immediateFuture(fixed)
                }
            })
            .build()

        // নোটিফিকেশন: বাংলা চ্যানেল-নাম + অ্যাপের নিজস্ব ছোট আইকন
        val provider = DefaultMediaNotificationProvider.Builder(this)
            .setChannelId(CHANNEL_ID)
            .setChannelName(R.string.quran_audio_channel_name)
            .build()
        provider.setSmallIcon(R.drawable.ic_notification)
        setMediaNotificationProvider(provider)

        // প্লে-লিস্ট খালি হয়ে গেলে (ইউজার "বন্ধ" দিলে) সার্ভিসও বন্ধ
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_IDLE && exo.mediaItemCount == 0) stopSelf()
            }
        })
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    // অ্যাপ রিসেন্টস থেকে সরিয়ে দিলে: বাজতে থাকলে চলবে (ব্যাকগ্রাউন্ড প্লেয়ারের কাজই এটা), না বাজলে বন্ধ
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0 || p.playbackState == Player.STATE_ENDED) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        session?.run {
            try { player.release() } catch (_: Throwable) {}
            release()
        }
        session = null
        super.onDestroy()
    }

    /**
     * "পরের/আগের" = পরের/আগের আসল আয়াত (রিপিটের কপি টপকে)।
     * mediaId ফরম্যাট "<qi>:<rep>"।
     */
    private class SkipAyahPlayer(p: Player) : ForwardingPlayer(p) {
        private fun qiOf(index: Int): Int {
            if (index < 0 || index >= mediaItemCount) return -1
            return getMediaItemAt(index).mediaId.substringBefore(':').toIntOrNull() ?: -1
        }

        private fun firstIndexOf(qi: Int): Int {
            for (i in 0 until mediaItemCount) if (qiOf(i) == qi) return i
            return -1
        }

        private fun goNextAyah() {
            val cur = currentMediaItemIndex
            val q = qiOf(cur)
            var i = cur + 1
            while (i < mediaItemCount && qiOf(i) == q) i++
            if (i < mediaItemCount) seekTo(i, 0L)
            else if (repeatMode == Player.REPEAT_MODE_ALL) seekTo(0, 0L)
            else seekTo(cur, 0L)
        }

        private fun goPrevAyah() {
            val q = qiOf(currentMediaItemIndex)
            if (currentPosition > 3000L || q <= 0) { seekTo(0L); return }
            val i = firstIndexOf(q - 1)
            if (i >= 0) seekTo(i, 0L) else seekTo(0L)
        }

        override fun seekToNext() = goNextAyah()
        override fun seekToNextMediaItem() = goNextAyah()
        override fun seekToPrevious() = goPrevAyah()
        override fun seekToPreviousMediaItem() = goPrevAyah()

        // নোটিফিকেশনে আগের/পরের বাটন সবসময় দেখানোর জন্য
        override fun getAvailableCommands(): Player.Commands =
            super.getAvailableCommands().buildUpon()
                .add(Player.COMMAND_SEEK_TO_NEXT)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                .build()

        override fun isCommandAvailable(command: Int): Boolean =
            command == Player.COMMAND_SEEK_TO_NEXT || command == Player.COMMAND_SEEK_TO_PREVIOUS ||
                command == Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM || command == Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM ||
                super.isCommandAvailable(command)
    }

    companion object {
        const val CHANNEL_ID = "quran_playback"
    }
}
