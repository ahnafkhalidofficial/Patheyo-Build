/* হোম স্ক্রিন উইজেটের প্রিভিউ — Kotlin ক্যানভাস-কোডের (widgethub/widget/…) JavaScript-এ হুবহু অনুবাদ।
   ডিজাইন ১ ক্লাসিক · ২ এসেনশিয়াল (ClassicDesign.kt) · ৪ মিনিমাল (MinimalDesign.kt) — সব মাপ ডিজাইন-ইউনিটে, WidgetRenderer-এর মতোই।
   রঙের টেবিল (PALETTES) build.py নিজে Palettes.kt থেকে পড়ে বসায়, তাই রং বদলালে স্ক্রিপ্ট আবার চালালেই মেলে।
   বাকি ডিজাইন (৩, ৫–৯): Kotlin-এ আছে, এখানে এখনো অনুবাদ হয়নি — tools/android-preview/README.md দেখুন।
   ফন্ট: ব্র্যান্ড ফন্ট ১০০০ UPM-এর, ডিজাইন ১১৭০-এর — তাই Fonts.sizeFor()-এর মতো BRAND_SCALE দিয়ে মাপ মেলানো। */
(function () {
  var BASE = '../../app/src/main/res/';
  var K = 1000 / 1170;            // Fonts.BRAND_SCALE
  var PAL = window.__PALETTES__;  // build.py বসায়
  function argb(v) {
    if (!v) return 'rgba(0,0,0,0)';
    var a = ((v >>> 24) & 255) / 255, r = (v >>> 16) & 255, g = (v >>> 8) & 255, b = v & 255;
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a.toFixed(3) + ')';
  }
  function lum(v) { return 0.299 * ((v >> 16) & 255) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255); }
  function pad2(n) { return n < 10 ? '0' + n : '' + n; }
  function hms(ms) { var t = Math.max(0, ms) / 1000 | 0; return pad2(t / 3600 | 0) + ':' + pad2((t / 60 | 0) % 60) + ':' + pad2(t % 60); }

  var TF = { bold: ['700', 'NS', true], regular: ['400', 'NS', true], bebas: ['400', 'Bebas', false], outfit: ['300', 'Outfit', false] };
  var ctx;
  function setFont(tf, size) { var f = TF[tf]; ctx.font = f[0] + ' ' + (f[2] ? size * K : size) + 'px ' + f[1]; }
  function measure(s, tf, size) { setFont(tf, size); return ctx.measureText(s).width; }
  function text(s, x, y, size, color, tf, align) {
    setFont(tf, size); ctx.fillStyle = argb(color); ctx.textAlign = align || 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillText(s, x, y); ctx.textAlign = 'left';
  }
  function fit(s, tf, size, maxW) { var w = measure(s, tf, size); return w > maxW ? size * maxW / w : size; }
  function rrect(l, t, r, b, rx) { ctx.beginPath(); ctx.roundRect(l, t, r - l, b - t, rx); }
  function fillRR(l, t, r, b, rx, color) { rrect(l, t, r, b, rx); ctx.fillStyle = argb(color); ctx.fill(); }
  function tile(l, t, r, b, rx, color, edge) {
    fillRR(l, t, r, b, rx, color);
    if (edge) { rrect(l + .75, t + .75, r - .75, b - .75, rx); ctx.lineWidth = 1.5; ctx.strokeStyle = argb(edge); ctx.stroke(); }
  }
  function bar(x0, x1, y, h, frac, track, fill) {
    fillRR(x0, y, x1, y + h, h / 2, track);
    var fx = x0 + (x1 - x0) * Math.min(1, Math.max(0, frac));
    if (fx - x0 > h) fillRR(x0, y, fx, y + h, h / 2, fill);
  }
  function slimClock(hm, x, base, size, color) {
    setFont('outfit', size);
    var m0 = ctx.measureText('0'), m1 = ctx.measureText(':');
    var dy = ((-m0.actualBoundingBoxAscent + m0.actualBoundingBoxDescent) / 2) - ((-m1.actualBoundingBoxAscent + m1.actualBoundingBoxDescent) / 2);
    var a = hm.substr(0, 2), b = hm.substr(3), aw = measure(a, 'outfit', size), cw = measure(':', 'outfit', size), bw = measure(b, 'outfit', size);
    text(a, x, base, size, color, 'outfit'); text(':', x + aw, base + dy, size, color, 'outfit'); text(b, x + aw + cw, base, size, color, 'outfit');
    return aw + cw + bw;
  }
  function remLine(snap, dr, base, dsz, lsz, dcol, lcol, endMs) {
    text(hms((endMs || snap.periodEndMs) - snap.nowMs), dr, base, dsz, dcol, 'bebas', 'right');
    text('বাকি', dr + 10, base, lsz, lcol, 'regular');
  }
  function logoRing(art, m, cx, cy, lr) {
    ctx.beginPath(); ctx.arc(cx, cy, lr, 0, 6.2832); ctx.fillStyle = argb((m.primary & 0xFFFFFF) | 0x14000000); ctx.fill();
    ctx.lineWidth = lr * 0.111; ctx.strokeStyle = argb(m.primary); ctx.stroke();
    var lg = art.logo(lum(m.primary) > 150), lh = lr * 1.333, lw = lh * lg.width / lg.height;
    ctx.drawImage(lg, cx - lw / 2, cy - lh / 2, lw, lh);
  }

  // ---------------------------------------------------------------- নমুনা Snapshot (Snapshot.kt-এর ক্ষেত্র)
  function snapshot(forbid) {
    var now = Date.UTC(2026, 10, 12, 7, 20, 6);   // ১৩:২০:০৬ ঢাকা
    return {
      nowMs: now, hijriMonthYear: 'জমাদিউল উলা ১৪৪৮', gregDay: '১২', gregMonth: 'নভেম্বর', gregYear: '২০২৬',
      banglaDay: '২৭', banglaMonth: 'কার্তিক', banglaYear: '১৪৩৩', hijriDay: '২৫',
      prayerNames: ['ফজর', 'জুম’আ', 'আসর', 'মাগরিব', 'এশা'], prayerTimes: ['০৪:৫২', '১১:৪৩', '০৩:১৩', '০৫:১৫', '০৬:২০'],
      sehri: '০৪:৪২', iftar: '০৫:১৫', current: 1, currentName: 'জুম’আ', running: true,
      periodStartMs: now - 97 * 60000, periodEndMs: now + 113 * 60000, isPm: true, forbid: forbid,
      forbidStartMs: now - 5 * 60000, forbidEndMs: now + 7 * 60000, gregFirst: false, sunIsSet: true, sunLabel: 'সূর্যাস্ত', sunTime: '০৫:১৫'
    };
  }
  var DATE_SEP = 30, CH12_X = 710, CH12_GAP = 10, PILL_SHIFT = 14;
  var COL_CX = [137.35, 342.5, 542.72, 771.11, 984.43];
  var HL_W = 185.78, HL_H = 145.83, HL_RX = 21.19, HL_NAME_DY = -5.82, HL_TIME_DY = -6.21;
  var SUNRISE_R = [820, 25, 1072, 175], IFTAR_R = [806, 222, 1060, 358], LOGO2_R = [26, 16, 208, 198];
  var D1_TILES = [[63, 222, 191, 350], [204, 222, 332, 350], [344, 281, 412, 349]];

  function cardW(d) { return d === 3 ? 981.41 : (d >= 4 && d <= 9) ? 1000 : 1114.25; }
  function cardH(d, compact) {
    if (compact && d === 2) return 380; if (compact && d === 1) return 540;
    return { 1: 608.16, 2: 445.15, 3: 465.35, 4: 448, 5: 428, 6: 480, 7: 570, 9: 540 }[d] || 500;
  }
  function cardRx(d) { return d === 1 ? 50.17 : d === 2 ? 42.93 : 56; }

  // ---------------------------------------------------------------- ক্লাসিক / এসেনশিয়াল
  function clipOut(rects, W, H) {
    ctx.beginPath(); ctx.rect(-5000, -5000, 10000, 10000);
    rects.forEach(function (r) { ctx.rect(r[0], r[1], r[2] - r[0], r[3] - r[1]); });
    ctx.clip('evenodd');
  }
  function drawArt(art, img, d, cw, chh, soft) {
    ctx.save();
    var holes = [SUNRISE_R, LOGO2_R]; if (d === 1) holes.push(IFTAR_R);
    if (soft) D1_TILES.forEach(function (t) { holes.push([t[0] - 2, t[1] - 2, t[2] + 2, t[3] + 2]); });
    clipOut(holes);
    ctx.drawImage(img, 0, 0, cw, chh);
    ctx.restore();
    if (soft) D1_TILES.forEach(function (t) { fillRR(t[0] - .5, t[1] - .5, t[2] + .5, t[3] + .5, 22, 0x24244866); });
    function piece(r) { ctx.drawImage(img, r[0], r[1], r[2] - r[0], r[3] - r[1], r[0] + PILL_SHIFT, r[1], r[2] - r[0], r[3] - r[1]); }
    piece(SUNRISE_R); if (d === 1) piece(IFTAR_R);
  }
  function classic(art, d, snap, pal) {
    var yOff = d === 1 ? 0 : -160;
    var dayX = 216.32, bigDay = snap.gregFirst ? snap.gregDay : snap.hijriDay;
    var bigMonth = snap.gregFirst ? snap.gregMonth + ' ' + snap.gregYear : snap.hijriMonthYear;
    text(bigDay, dayX, 103.57, 110, pal.day, 'bold');
    var hx = dayX + measure(bigDay, 'bold', 110) + 10.53, hs = 55, hw = measure(bigMonth, 'bold', hs), hAvail = 825 - hx;
    if (hw > hAvail) hs = 55 * hAvail / hw;
    text(bigMonth, hx, 102.29, hs, pal.hijri, 'bold');
    var ds = 52, g1 = snap.gregFirst ? snap.hijriDay + ' ' + snap.hijriMonthYear : snap.gregDay + ' ' + snap.gregMonth + ' ' + snap.gregYear;
    var g2 = snap.banglaDay + ' ' + snap.banglaMonth + ' ' + snap.banglaYear;
    var w1 = measure(g1, 'bold', ds), w2 = measure(g2, 'bold', ds), total = w1 + DATE_SEP + w2, f = total > 612 ? 612 / total : 1;
    if (f < 1) { ds *= f; w1 *= f; w2 *= f; }
    text(g1, dayX, 162.99, ds, pal.date, 'bold');
    var dvx = dayX + w1 + (DATE_SEP - 2.2) / 2 * f;
    ctx.fillStyle = argb((pal.date & 0xFFFFFF) | 0xBF000000); ctx.fillRect(dvx, 123.4, 2.2 * f, 45.19);
    text(g2, dayX + w1 + DATE_SEP * f, 162.99, ds, pal.date, 'bold');
    text(snap.sunLabel, 1006.18 + PILL_SHIFT, 89.51, 52.19, pal.pillLabel, 'bold', 'center');
    text(snap.sunTime, 1005.07 + PILL_SHIFT, 146.66, 63.36, pal.pillTime, 'bold', 'center');
    // নতুন লোগো (স্কুইরকল)
    var ink = pal.date, lx = 116, ly = 107, half = 79, rr = 46;
    fillRR(lx - half, ly - half, lx + half, ly + half, rr, (ink & 0xFFFFFF) | 0x14000000);
    rrect(lx - half, ly - half, lx + half, ly + half, rr); ctx.lineWidth = 6; ctx.strokeStyle = argb(ink); ctx.stroke();
    var lg = art.logo(lum(pal.date) > 150), lh = 104, lw = lh * lg.width / lg.height;
    ctx.drawImage(lg, lx - lw / 2, ly - lh / 2, lw, lh);
    if (d === 1) {
      text('সেহরি', 698.77, 279.37, 52.19, pal.pillLabel, 'bold', 'center'); text(snap.sehri, 703.71, 331.96, 63.36, pal.pillTime, 'bold', 'center');
      text('ইফতার', 995.9 + PILL_SHIFT, 279.37, 52.19, pal.pillLabel, 'bold', 'center'); text(snap.iftar, 992.11 + PILL_SHIFT, 331.96, 63.36, pal.pillTime, 'bold', 'center');
      text(snap.isPm ? 'PM' : 'AM', 424.41, 299.25, 40, pal.pm, 'bebas');
      text('01', 65.32, 332.48, 136.17, pal.clock, 'bebas'); text('20', 218.54, 334.48, 125, pal.clock, 'bebas'); text('06', 353.03, 340.13, 65, pal.clock, 'bebas');
    }
    var nameY = 448.74 + yOff, timeY = 502.65 + yOff, hlY = 381.16 + yOff;
    for (var i = 0; i < 5; i++) {
      var cx = COL_CX[i], hl = snap.current === i && snap.forbid === 0;
      if (hl) fillRR(cx - HL_W / 2, hlY, cx + HL_W / 2, hlY + HL_H, HL_RX, pal.hlFill);
      text(snap.prayerNames[i], cx, nameY + (hl ? HL_NAME_DY : 0), 60, hl ? pal.hlText : pal.name, 'regular', 'center');
      text(snap.prayerTimes[i], cx, timeY + (hl ? HL_TIME_DY : 0), 60, hl ? pal.hlText : pal.time, 'bold', 'center');
    }
    if (snap.forbid === 2) return;
    var nowY = 577.67 + yOff, inF = snap.forbid === 1, warn = lum(pal.name) > 150 ? 0xFFFF8F7A : 0xFFC62828;
    var prefix = inF ? 'নিষিদ্ধ সময় বাকি:' : snap.running ? snap.currentName + ' -এর সময় অতিবাহিত:' : snap.currentName + ' -এর সময় শুরু হতে বাকি:';
    var ps = 50, labelEnd = CH12_X - CH12_GAP, pw = measure(prefix, inF ? 'bold' : 'regular', ps), maxLabel = labelEnd - 40;
    if (pw > maxLabel) { ps *= maxLabel / pw; pw = maxLabel; }
    text(prefix, labelEnd - pw, nowY, ps, inF ? warn : pal.now, inF ? 'bold' : 'regular');
    text(hms(inF ? snap.forbidEndMs - snap.nowMs : snap.running ? snap.nowMs - snap.periodStartMs : snap.periodEndMs - snap.nowMs), CH12_X, nowY, 40, pal.nowTime, 'bebas');
  }

  // ---------------------------------------------------------------- মিনিমাল
  function minimal(art, snap, m) {
    var cw = cardW(4), hm = '01:20', L = 40, R = cw - 40, colW = (R - L) / 5;
    var span = Math.max(1, snap.periodEndMs - snap.periodStartMs), frac = Math.min(1, Math.max(0, (snap.nowMs - snap.periodStartMs) / span));
    var warn = lum(m.primary) > 150 ? 0xFFFF8F7A : 0xFFC62828, f4 = snap.forbid, dsz = 39;
    logoRing(art, m, L + 29, 64, 29);
    text(snap.gregDay + ' ' + snap.gregMonth + ' ' + snap.gregYear, L + 74, 80, dsz, m.secondary, 'bold');
    text(snap.hijriDay + ' ' + snap.hijriMonthYear, R, 80, dsz, m.secondary, 'bold', 'right');
    var clockSize = 172, clockEnd = L - 6 + (measure('00', 'outfit', clockSize) * 2 + measure(':', 'outfit', clockSize));
    var cwNow = measure(hm.substr(0, 2), 'outfit', clockSize) + measure(':', 'outfit', clockSize) + measure(hm.substr(3), 'outfit', clockSize);
    slimClock(hm, clockEnd - cwNow, 250, clockSize, m.primary);
    var sx = clockEnd + 22 + measure('00', 'outfit', 44) / 2;
    text(snap.isPm ? 'PM' : 'AM', sx, 202, 44, m.accent, 'outfit', 'center'); text('06', sx, 250, 44, m.primary, 'outfit', 'center');
    var bx0 = clockEnd + 22 + 90, chipTxt = 'চলমান', chipSz = 26, chipW = measure(chipTxt, 'bold', chipSz) + 32;
    if (f4 === 0) {
      var nsz = fit(snap.currentName, 'bold', 68, R - bx0 - chipW - 16), nw = measure(snap.currentName, 'bold', nsz);
      text(snap.currentName, R - chipW - 16 - nw, 204, nsz, m.accent, 'bold');
      var cx0 = R - chipW; tile(cx0, 156, R, 200, 22, (m.accent & 0xFFFFFF) | 0x2E000000, ((m.accent & 0xFFFFFF) | 0x80000000) >>> 0);
      text(chipTxt, cx0 + chipW / 2, 188, chipSz, m.accent, 'bold', 'center');
      remLine(snap, 898, 254, 44, 38, m.primary, m.primary);
    } else if (f4 === 1) {
      var nz = fit('নিষিদ্ধ সময়', 'bold', 68, R - bx0);
      text('নিষিদ্ধ সময়', R, 204, nz, warn, 'bold', 'right'); remLine(snap, 898, 254, 44, 38, m.primary, m.primary, snap.forbidEndMs);
    } else { text('–', R, 204, 84, m.secondary, 'bold', 'right'); text('–', R, 254, 50, m.secondary, 'bold', 'right'); }
    var barFrac = f4 === 1 ? Math.min(1, Math.max(0, (snap.nowMs - snap.forbidStartMs) / Math.max(1, snap.forbidEndMs - snap.forbidStartMs))) : f4 === 2 ? 0 : frac;
    bar(L, R, 296, 8, barFrac, m.track, f4 === 1 ? warn : m.accent);
    for (var i = 0; i < 5; i++) {
      var cx = L + colW * (i + .5), on = f4 === 0 && snap.current === i;
      text(snap.prayerNames[i], cx, 360, 39, on ? m.accent : m.secondary, 'bold', 'center');
      text(snap.prayerTimes[i], cx, 416, 48, on ? m.accent : m.primary, 'bold', 'center');
    }
  }

  // ---------------------------------------------------------------- রেন্ডার (WidgetRenderer.draw)
  var imgs = {};
  function load(src) { return imgs[src] || (imgs[src] = new Promise(function (ok, no) { var i = new Image(); i.onload = function () { ok(i); }; i.onerror = no; i.src = BASE + src; })); }
  var VKEY = { glass: 'GLASS', light: 'LIGHT', nobg_dark: 'NOBG_DARK', nobg_light: 'NOBG_LIGHT' };

  async function render(canvas, d, variant, forbid, W, H) {
    var dpr = 2, snap = snapshot(forbid), v = VKEY[variant], compact = d <= 2 && forbid === 2;
    var cw = cardW(d), chh = cardH(d, compact), PAD = 23;
    var s = Math.min(W / (cw + 2 * PAD), H / (chh + 2 * PAD)), ox = (W - cw * s) / 2, oy = (H - chh * s) / 2;
    canvas.width = W * dpr; canvas.height = H * dpr; canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx = canvas.getContext('2d'); ctx.setTransform(dpr * s, 0, 0, dpr * s, dpr * ox, dpr * oy);
    var pal = d >= 4 ? PAL['MIN_' + v] : PAL['D' + d + '_' + v];
    var fill = pal.cardFill, stroke = pal.cardStroke;
    if (fill) {
      var rx = cardRx(d), a = Math.round(((fill >>> 24) & 255) * .85);
      fillRR(.5, .5, cw - .5, chh - .5, rx, ((a << 24) | (fill & 0xFFFFFF)) >>> 0);
      if (stroke) { rrect(.5, .5, cw - .5, chh - .5, rx); ctx.lineWidth = 1; ctx.strokeStyle = argb(stroke); ctx.stroke(); }
    }
    var logoLight = await load('drawable-nodpi/logo_path_w.webp'), logoDark = await load('drawable-nodpi/logo_path_d.webp');
    var art = { logo: function (light) { return light ? logoLight : logoDark; } };
    if (d <= 2) {
      var img = await load('drawable-nodpi/art_d' + d + '_' + (variant === 'nobg_dark' ? 'nobg_dark' : variant === 'nobg_light' ? 'nobg_light' : variant) + '.webp');
      drawArt(art, img, d, cw, cardH(d), d === 1 && (v === 'LIGHT' || v === 'NOBG_LIGHT'));
      classic(art, d, snap, pal);
    } else minimal(art, snap, pal);
  }

  window.renderWidgets = async function (root) {
    await Promise.all(['700 20px NS', '400 20px NS', '400 20px Bebas', '300 20px Outfit'].map(function (f) { return document.fonts.load(f, 'অ0'); }));
    root.innerHTML = '';
    var bar0 = document.createElement('div'); bar0.className = 'wbar';
    bar0.innerHTML = '<label><input type="checkbox" id="wf1"> নিষিদ্ধ সময় চলছে</label> <label><input type="checkbox" id="wf2"> মাঝের ফাঁক ("–")</label>';
    root.appendChild(bar0);
    var grid = document.createElement('div'); grid.className = 'wgrid'; root.appendChild(grid);
    var DS = [[1, 'ডিজাইন ১ · ক্লাসিক'], [2, 'ডিজাইন ২ · এসেনশিয়াল'], [4, 'ডিজাইন ৪ · মিনিমাল']];
    var VS = [['glass', 'গ্লাস (ডার্ক)'], ['light', 'লাইট'], ['nobg_dark', 'ট্রান্সপারেন্ট · সাদা লেখা'], ['nobg_light', 'ট্রান্সপারেন্ট · কালো লেখা']];
    var chain = Promise.resolve(), gen = 0;
    function paint() {
      var my = ++gen;
      var fb = document.getElementById('wf1').checked ? 1 : document.getElementById('wf2').checked ? 2 : 0;
      grid.innerHTML = '';
      DS.forEach(function (d) { VS.forEach(function (v) {
        var cell = document.createElement('div'); cell.className = 'wcell ' + (v[0] === 'nobg_light' ? 'wp-light' : 'wp-dark');
        cell.innerHTML = '<small>' + d[1] + ' · ' + v[1] + '</small>'; var cv = document.createElement('canvas'); cell.appendChild(cv); grid.appendChild(cell);
        chain = chain.then(function () { return my === gen ? render(cv, d[0], v[0], fb, 360, d[0] === 4 ? 180 : 220) : 0; }).catch(function (e) { cell.insertAdjacentHTML('beforeend', '<em>' + e + '</em>'); });
      }); });
    }
    document.getElementById('wf1').onchange = function () { if (this.checked) document.getElementById('wf2').checked = false; paint(); };
    document.getElementById('wf2').onchange = function () { if (this.checked) document.getElementById('wf1').checked = false; paint(); };
    paint();
  };
})();
