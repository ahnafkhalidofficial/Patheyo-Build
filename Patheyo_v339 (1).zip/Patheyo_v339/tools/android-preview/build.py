#!/usr/bin/env python3
"""
Android-only স্ক্রিনগুলো ব্রাউজারে দেখার প্রিভিউ বানায় — ফোন বা এমুলেটর লাগে না।

res/layout ও res/layout-v26-এর XML (আজান স্ক্রিন, অ্যালার্ম, ৪টা পপআপ, ৪টা নোটিফিকেশন) পড়ে হুবহু একই মাপ
(dp/sp = CSS px), রং, স্ট্রিং, আকার ও আইকন দিয়ে HTML বানায়; সাথে উইজেটের ডিজাইনগুলো (widgets.js) ও ফন্ট-ডেমো।

চালানো:   python3 tools/android-preview/build.py
ফল:        docs/android-preview/index.html   (ব্রাউজারে খুললেই হয়; অ্যাপের ফাইল থেকে আপেক্ষিক পথে ফন্ট/ছবি নেয়)
কোনো XML বা রং বদলালে আবার চালালেই প্রিভিউ নতুন হয়। কোন স্ক্রিন কোন ফাইল — প্রতিটা কার্ডের নিচে লেখা।
সীমা: Kotlin দিয়ে চলার সময় বসানো লেখা (আজানের আয়াত, নোটের তালিকা) এখানে নমুনা-লেখা (SAMPLES)।
"""
import html
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RES = ROOT / "app/src/main/res"
OUT = ROOT / "docs/android-preview/index.html"
A = "{http://schemas.android.com/apk/res/android}"
APP = "{http://schemas.android.com/apk/res-auto}"
AAPT = "{http://schemas.android.com/aapt}"
REL = "../../app/src/main/res"   # docs/android-preview → res

# ---------------------------------------------------------------- মান (রং, স্ট্রিং)
COLORS, STRINGS = {}, {}


def load_values():
    for d in ("values", "values-night"):      # night পরে বসে → ডার্ক মোডের মান জেতে (অ্যাপ ডিফল্টে ডার্ক)
        for f in sorted((RES / d).glob("*.xml")):
            for e in ET.parse(f).getroot():
                n = e.get("name")
                if e.tag == "color":
                    COLORS[n] = (e.text or "").strip()
                elif e.tag == "string":
                    STRINGS[n] = (e.text or "").strip()


def css_color(v):
    if v is None:
        return None
    v = v.strip()
    if v.startswith("@color/"):
        return css_color(COLORS.get(v[7:], "#FF00FF"))
    m = re.fullmatch(r"#([0-9a-fA-F]{8})", v)
    if m:
        h = m.group(1)
        a = int(h[:2], 16) / 255
        return f"rgba({int(h[2:4], 16)},{int(h[4:6], 16)},{int(h[6:8], 16)},{a:.3f})"
    m = re.fullmatch(r"#([0-9a-fA-F]{6})", v)
    if m:
        return "#" + m.group(1)
    m = re.fullmatch(r"#([0-9a-fA-F]{3})", v)
    if m:
        return "#" + m.group(1)
    return v


def text_of(v):
    if v is None:
        return ""
    if v.startswith("@string/"):
        s = STRINGS.get(v[8:], "‹" + v + "›")
    else:
        s = v
    s = s.replace("\\n", "\n").replace("\\'", "'").replace('\\"', '"').replace("%1$s", "‹নাম›").replace("%s", "‹নাম›")
    return s


def dp(v, default=None):
    if v is None:
        return default
    m = re.fullmatch(r"(-?[0-9.]+)(dp|sp|dip|px)?", v.strip())
    return float(m.group(1)) if m else default


def px(n):
    return ("%g" % n) + "px"


# ---------------------------------------------------------------- ড্রয়েবল
_gid = [0]


def gradient_css(g, rounded=""):
    ang = int(g.get(A + "angle", "0")) % 360
    # Android: 0 = বাঁ→ডান, 90 = নিচ→ওপর, 270 = ওপর→নিচ; CSS: 90deg = বাঁ→ডান, 0deg = নিচ→ওপর
    css = {0: 90, 45: 45, 90: 0, 135: 315, 180: 270, 225: 225, 270: 180, 315: 135}.get(ang, 180)
    stops = [css_color(g.get(A + "startColor")), css_color(g.get(A + "centerColor")), css_color(g.get(A + "endColor"))]
    stops = [s for s in stops if s]
    return f"linear-gradient({css}deg,{','.join(stops)})"


def shape_style(shape):
    """<shape> → CSS (background, border, radius). ফেরত: dict"""
    st = {}
    kind = shape.get(A + "shape", "rectangle")
    if kind == "oval":
        st["border-radius"] = "50%"
    for c in shape:
        if c.tag == "solid":
            st["background"] = css_color(c.get(A + "color"))
        elif c.tag == "gradient":
            st["background"] = gradient_css(c)
        elif c.tag == "corners":
            r = dp(c.get(A + "radius"))
            if r is not None:
                st["border-radius"] = px(r)
        elif c.tag == "stroke":
            st["border"] = f"{px(dp(c.get(A + 'width'), 1))} solid {css_color(c.get(A + 'color'))}"
    return st


def drawable_css(name):
    """@drawable/name → (css dict, extra_html). ছবি/ভেক্টরের জন্য None।"""
    p = RES / "drawable" / (name + ".xml")
    if not p.exists():
        return {}, ""
    root = ET.parse(p).getroot()
    if root.tag == "shape":
        return shape_style(root), ""
    if root.tag == "ripple":
        for it in root:
            if it.tag == "item" and not it.get(A + "id"):
                for s in it:
                    if s.tag == "shape":
                        return shape_style(s), ""
        return {}, ""
    if root.tag == "layer-list":
        layers = []
        base = {}
        for it in root:
            for s in it:
                if s.tag != "shape":
                    continue
                st = shape_style(s)
                bg = st.get("background")
                if not bg:
                    continue
                size = ""
                pos = "0 0"
                h = dp(it.get(A + "height"))
                bt = dp(it.get(A + "bottom"))
                g = it.get(A + "gravity", "")
                if h is not None:
                    size = f"100% {px(h)}"
                    pos = "0 100%" if "bottom" in g else "0 0"
                elif bt is not None:
                    size = f"100% calc(100% - {px(bt)})"
                else:
                    for k in ("border", "border-radius"):
                        if k in st:
                            base[k] = st[k]
                if size:
                    layers.append(f"{bg} {pos}/{size} no-repeat")
                else:
                    layers.append(bg)
        if layers:
            base["background"] = ",".join(reversed(layers))   # layer-list: ... হলো নিচের স্তর; CSS-এ প্রথমটা ওপরে
        return base, ""
    return {}, ""


def vector_svg(name, tint=None, w=None, h=None):
    p = RES / "drawable" / (name + ".xml")
    root = ET.parse(p).getroot()
    vw, vh = float(root.get(A + "viewportWidth")), float(root.get(A + "viewportHeight"))
    w = w or dp(root.get(A + "width"), 24)
    h = h or dp(root.get(A + "height"), 24)
    defs, paths = [], []

    def grad(g):
        _gid[0] += 1
        i = f"g{_gid[0]}"
        stops = "".join(
            f'<stop offset="{it.get(A + "offset")}" stop-color="{css_color(it.get(A + "color"))}"/>' for it in g)
        defs.append(f'<linearGradient id="{i}" gradientUnits="userSpaceOnUse" x1="{g.get(A + "startX")}" y1="{g.get(A + "startY")}" '
                    f'x2="{g.get(A + "endX")}" y2="{g.get(A + "endY")}">{stops}</linearGradient>')
        return f"url(#{i})"

    def walk(e):
        for c in e:
            if c.tag == "group":
                walk(c)
            elif c.tag == "path":
                fill, stroke = c.get(A + "fillColor"), c.get(A + "strokeColor")
                for at in c:
                    if at.tag == AAPT + "attr":
                        g = at[0]
                        val = grad(g)
                        if at.get("name") == "android:fillColor":
                            fill = val
                        else:
                            stroke = val
                attrs = [f'd="{c.get(A + "pathData")}"']
                f = tint or (css_color(fill) if fill and not fill.startswith("url") else fill)
                attrs.append(f'fill="{f or "none"}"')
                if stroke or c.get(A + "strokeWidth"):
                    s = tint or (css_color(stroke) if stroke and not stroke.startswith("url") else stroke)
                    attrs.append(f'stroke="{s or "none"}" stroke-width="{c.get(A + "strokeWidth", "1")}"')
                    if c.get(A + "strokeLineCap"):
                        attrs.append(f'stroke-linecap="{c.get(A + "strokeLineCap")}"')
                    if c.get(A + "strokeLineJoin"):
                        attrs.append(f'stroke-linejoin="{c.get(A + "strokeLineJoin")}"')
                if c.get(A + "fillType") == "evenOdd":
                    attrs.append('fill-rule="evenodd"')
                paths.append("<path " + " ".join(attrs) + "/>")

    walk(root)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {vw:g} {vh:g}" width="{w:g}" height="{h:g}">'
            f'<defs>{"".join(defs)}</defs>{"".join(paths)}</svg>')


# ---------------------------------------------------------------- নমুনা লেখা (Kotlin যা চালু সময়ে বসায়)
SAMPLES = {
    "tvAppName": "পাথেয় বাই গুঞ্জরণ",
    "tvTitle": "ফজরের নামাজের আজান হচ্ছে",
    "tvQuote": "“যে ব্যক্তি ফজরের নামাজ আদায় করে, সে আল্লাহর জিম্মায় থাকে।”",
    "tvQuoteSource": "— সহীহ মুসলিম ৬৫৭",
    "tvHint": "ধীরে বাটন টিপুন — আজান শেষ হলে নিজে থেকেই বন্ধ হবে",
    "tvNotes": "• নতুন ফন্ট Noto Serif by Gunjoron\n• জুম’আ বানান সব জায়গায়\n• ছোট লেখা আরও স্পষ্ট\n• ছোটখাটো ত্রুটি ঠিক",
    "notif_custom_title": "জুম’আ মোবারক",
    "notif_custom_text": "আজ জুম’আর দিন। সূরা কাহফ তিলাওয়াত ও বেশি করে দরুদ পড়ুন।",
}
# Kotlin যে স্ট্রিং-রিসোর্স বসায় — ফাইল অনুযায়ী (আসল লেখাই দেখানো হয়)
STRING_SOURCES = {
    "dialog_location_permission": {"tvTitle": "loc_perm_title", "tvSubtitle": "loc_perm_subtitle", "tvNotes": "loc_perm_benefits", "tvWarning": "loc_perm_warning"},
    "dialog_notification_permission": {"tvTitle": "notif_perm_title", "tvSubtitle": "notif_perm_subtitle", "tvNotes": "notif_perm_benefits", "tvWarning": "notif_perm_warning"},
    "dialog_alarm_permission": {"tvTitle": "alarm_perm_exact_title", "tvSubtitle": "alarm_perm_exact_subtitle", "tvNotes": "alarm_perm_exact_benefits", "tvWarning": "alarm_perm_exact_warning"},
}
SAMPLES_BY_FILE = {}

# ---------------------------------------------------------------- লেআউট → HTML
def flags(v):
    return set((v or "").split("|"))


def box_style(e, parent_tag, parent_orient, idx):
    s = {}
    w, h = e.get(A + "layout_width", "wrap_content"), e.get(A + "layout_height", "wrap_content")
    wt = e.get(A + "layout_weight")
    lg = flags(e.get(A + "layout_gravity"))

    def sized(v):
        if v == "match_parent" or v == "fill_parent":
            return "match"
        if v == "wrap_content":
            return "wrap"
        return dp(v, 0)

    sw, sh = sized(w), sized(h)
    horiz = parent_tag == "LinearLayout" and parent_orient == "horizontal"
    vert = parent_tag == "LinearLayout" and parent_orient != "horizontal"
    frame = parent_tag in ("FrameLayout", "ScrollView", "FadingEdgeLayout", "ViewGroupRoot")
    rel = parent_tag == "RelativeLayout"

    if isinstance(sw, float):
        s["width"] = px(sw) if sw else "auto"
        s["flex-shrink"] = "0" if sw else "1"
    if isinstance(sh, float):
        s["height"] = px(sh) if sh else "auto"
    if e.get(A + "minWidth"):
        s["min-width"] = px(dp(e.get(A + "minWidth")))
    if horiz:
        if wt:
            s["flex"] = f"{wt} 1 0"
            s["min-width"] = "0"
        elif sw == "match":
            s["flex"] = "1 1 0"
            s["min-width"] = "0"
        if sh == "match":
            s["align-self"] = "stretch"
    elif vert:
        if wt:
            s["flex"] = f"{wt} 1 0"
        elif sh == "match":
            s["flex"] = "1 1 0"
        if sw == "match":
            s["align-self"] = "stretch"
        elif "center_horizontal" in lg or "center" in lg:
            s["align-self"] = "center"
    elif frame:
        s["grid-area"] = "1/1"
        s["justify-self"] = "stretch" if sw == "match" else "start"
        s["align-self"] = "stretch" if sh == "match" else "start"
        if "center" in lg or "center_horizontal" in lg:
            s["justify-self"] = "center"
        if "center" in lg or "center_vertical" in lg:
            s["align-self"] = "center"
        if "end" in lg or "right" in lg:
            s["justify-self"] = "end"
        if "bottom" in lg:
            s["align-self"] = "end"
    elif rel:
        s["position"] = "absolute"
        if e.get(A + "layout_alignParentBottom") == "true":
            s["bottom"] = "0"
        if e.get(A + "layout_centerHorizontal") == "true" and sw != "match":
            s["left"] = "50%"
            s["transform"] = "translateX(-50%)"
            s["width"] = s.get("width", "max-content")
        if e.get(A + "layout_centerInParent") == "true":
            s["left"] = "50%"; s["top"] = "50%"; s["transform"] = "translate(-50%,-50%)"
        if sw == "match":
            s["left"] = "0"; s["right"] = "0"
    # margin / padding
    for pre, tgt in (("layout_margin", "margin"), ("padding", "padding")):
        base = dp(e.get(A + pre))
        sides = {"Top": base, "Bottom": base, "Start": base, "End": base}
        hz, vt = dp(e.get(A + pre + "Horizontal")), dp(e.get(A + pre + "Vertical"))
        if hz is not None:
            sides["Start"] = sides["End"] = hz
        if vt is not None:
            sides["Top"] = sides["Bottom"] = vt
        for k, v in list(sides.items()):
            o = dp(e.get(A + pre + k))
            if o is None and k in ("Start", "End"):
                o = dp(e.get(A + pre + {"Start": "Left", "End": "Right"}[k]))
            if o is not None:
                sides[k] = o
        for k, css in (("Top", "top"), ("Bottom", "bottom"), ("Start", "left"), ("End", "right")):
            if sides[k]:
                s[f"{tgt}-{css}"] = px(sides[k])
    return s


def orient_flex(e, style):
    o = e.get(A + "orientation", "horizontal")
    g = flags(e.get(A + "gravity"))
    style["display"] = "flex"
    style["flex-direction"] = "column" if o == "vertical" else "row"
    main_c = {"center", "center_vertical"} if o == "vertical" else {"center", "center_horizontal"}
    cross_c = {"center", "center_horizontal"} if o == "vertical" else {"center", "center_vertical"}
    if g & main_c:
        style["justify-content"] = "center"
    if g & cross_c:
        style["align-items"] = "center"
    elif g & {"end", "right"} and o == "vertical":
        style["align-items"] = "flex-end"
    elif g & {"bottom"} and o != "vertical":
        style["align-items"] = "flex-end"
    elif g & {"bottom"} and o == "vertical":
        style["justify-content"] = "flex-end"


def background_of(e, style):
    bg = e.get(A + "background")
    if not bg:
        return
    if bg.startswith("@drawable/"):
        name = bg[10:]
        css, _ = drawable_css(name)
        if css:
            style.update(css)
        elif not (RES / "drawable" / (name + ".xml")).exists():
            for ext in ("webp", "png"):
                for d in RES.glob(f"drawable*/{name}.{ext}"):
                    style["background"] = f"url({REL}/{d.parent.name}/{d.name}) center/cover"
                    return
    else:
        style["background"] = css_color(bg)


def style_str(d):
    return ";".join(f"{k}:{v}" for k, v in d.items() if v not in (None, ""))


def render(e, parent_tag="ViewGroupRoot", parent_orient="vertical", idx=0, fname="", depth=0):
    tag = e.tag.split(".")[-1]
    ident = (e.get(A + "id") or "").split("/")[-1]
    st = box_style(e, parent_tag, parent_orient, idx)
    st["box-sizing"] = "border-box"
    background_of(e, st)
    cls = "v"
    if tag in ("LinearLayout",):
        orient_flex(e, st)
        st["min-height"] = "0"
    elif tag in ("FrameLayout", "FadingEdgeLayout", "ScrollView", "RelativeLayout"):
        if tag == "RelativeLayout":
            st["position"] = "relative"
            if "width" not in st:
                st["width"] = "100%"
        else:
            st["display"] = "grid"
        if tag == "ScrollView":
            st["overflow"] = "hidden"
            st["min-height"] = "0"
    if e.get(A + "alpha"):
        st["opacity"] = e.get(A + "alpha")
    kids_html = ""
    if tag in ("TextView", "Button", "Chronometer", "TextClock"):
        cls = "t"
        ts = dp(e.get(A + "textSize"), 14)
        st["font-size"] = px(ts)
        col = css_color(e.get(A + "textColor"))
        st["color"] = col or "#FFFFFF"
        bold = "bold" in (e.get(A + "textStyle") or "")
        st["font-weight"] = "700" if bold else "400"
        lse, lsm = dp(e.get(A + "lineSpacingExtra"), 0), float(e.get(A + "lineSpacingMultiplier", "1"))
        # Android-এ লাইনের উচ্চতা ≈ ফন্টের ascent+descent (≈1.4em নোটো সেরিফ) + extra
        st["line-height"] = px(round(ts * 1.4 * lsm + lse, 2))
        g = flags(e.get(A + "gravity"))
        if g & {"center", "center_horizontal"}:
            st["text-align"] = "center"
        elif g & {"end", "right"}:
            st["text-align"] = "right"
        if e.get(A + "maxLines") == "1" or e.get(A + "singleLine") == "true":
            st.update({"white-space": "nowrap", "overflow": "hidden", "text-overflow": "ellipsis"})
        else:
            st["white-space"] = "pre-wrap"
        if tag == "Button":
            st.setdefault("display", "flex")
            st["align-items"] = "center"; st["justify-content"] = "center"
            st["font-weight"] = "700" if bold else "500"
            btn_bg = css_color(e.get(APP + "backgroundTint"))
            if btn_bg:
                st["background"] = btn_bg
            cr = dp(e.get(APP + "cornerRadius"))
            if cr is not None:
                st["border-radius"] = px(cr)
            sc = e.get(APP + "strokeColor")
            if sc:
                st["border"] = f"{px(dp(e.get(APP + 'strokeWidth'), 1))} solid {css_color(sc)}"
            st["padding-left"] = st["padding-right"] = "16px"
        txt = text_of(e.get(A + "text"))
        if not txt:
            ref = STRING_SOURCES.get(fname, {}).get(ident)
            if ref and ref in STRINGS:
                txt = text_of(STRINGS[ref])
        if not txt:
            txt = SAMPLES_BY_FILE.get(fname, {}).get(ident) or SAMPLES.get(ident, f"‹{ident or 'text'}›")
        kids_html = html.escape(txt)
    elif tag == "ImageView":
        cls = "i"
        src = e.get(A + "src", "")
        tint = css_color(e.get(A + "tint") or e.get(APP + "tint"))
        w = dp(e.get(A + "layout_width"))
        h = dp(e.get(A + "layout_height"))
        if src.startswith("@drawable/"):
            n = src[10:]
            if (RES / "drawable" / (n + ".xml")).exists():
                kids_html = vector_svg(n, tint, w, h)
            else:
                for d in RES.glob(f"drawable*/{n}.*"):
                    kids_html = f'<img src="{REL}/{d.parent.name}/{d.name}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">'
                    break
                if n == "home_logo_circle":
                    st["border-radius"] = "50%"
                    st["overflow"] = "hidden"
        st["display"] = "block"
    elif tag == "View":
        pass
    else:
        sub_orient = e.get(A + "orientation", "vertical")
        kids = []
        for i, c in enumerate(e):
            if isinstance(c.tag, str) and not c.tag.startswith("{"):
                kids.append(render(c, tag, sub_orient, i, fname, depth + 1))
        kids_html = "".join(kids)
    title = f' title="{html.escape(tag + (" #" + ident if ident else ""))}"'
    return f'<div class="{cls}"{title} style="{style_str(st)}">{kids_html}</div>'


# ---------------------------------------------------------------- পেজ
SCREENS = [
    # (ফাইল, শিরোনাম, ধরন)
    ("layout/activity_azan_overlay.xml", "আজান স্ক্রিন (পুরো পর্দা)", "screen"),
    ("layout/activity_alarm.xml", "অ্যালার্ম স্ক্রিন", "screen"),
    ("layout/dialog_update.xml", "আপডেট পপআপ", "dialog"),
    ("layout/dialog_location_permission.xml", "লোকেশন পারমিশন পপআপ", "dialog"),
    ("layout/dialog_notification_permission.xml", "নোটিফিকেশন পারমিশন পপআপ", "dialog"),
    ("layout/dialog_alarm_permission.xml", "অ্যালার্ম পারমিশন পপআপ", "dialog"),
    ("layout-v26/notification_azan_headsup.xml", "আজান নোটিফিকেশন (হেডস-আপ)", "notif"),
    ("layout-v26/notification_alarm.xml", "অ্যালার্ম নোটিফিকেশন", "notif"),
    ("layout-v26/notification_custom_collapsed.xml", "সাধারণ নোটিফিকেশন (ছোট)", "notif"),
    ("layout-v26/notification_custom_expanded.xml", "সাধারণ নোটিফিকেশন (বড়)", "notif"),
]

CSS = """
@font-face{font-family:NS;src:url(../../app/src/main/assets/fonts/NotoSerifByGunjoron-Regular.ttf);font-weight:400}
@font-face{font-family:NS;src:url(../../app/src/main/assets/fonts/NotoSerifByGunjoron-Medium.ttf);font-weight:500}
@font-face{font-family:NS;src:url(../../app/src/main/assets/fonts/NotoSerifByGunjoron-Bold.ttf);font-weight:700}
@font-face{font-family:Bebas;src:url(../../app/src/main/res/font/bebas_neue.ttf)}
@font-face{font-family:Outfit;src:url(../../app/src/main/res/font/outfit_light.ttf);font-weight:300}
.wbar{margin:0 0 14px;font-size:13px;display:flex;gap:18px}.wgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:18px}.wcell small{display:block;color:#a8b3ca;margin-bottom:6px;font-size:12px}.wp-light canvas{background:#c9c4b8}.wp-dark canvas{background:#2b3a55}
:root{color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:#0b1020;color:#e8edf6;font:15px/1.5 NS,serif;padding:24px 16px 64px}
h1{font-size:22px;margin:0 0 4px}.sub{color:#a8b3ca;margin:0 0 20px;font-size:14px;max-width:760px}
nav{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px}
nav a{color:#7a97f0;text-decoration:none;border:1px solid #2a364c;padding:6px 12px;border-radius:999px;font-size:14px}
.grid{display:flex;flex-wrap:wrap;gap:28px;align-items:flex-start}
.card{width:fit-content;max-width:100%}
.card h3{margin:0 0 2px;font-size:16px}.card small{display:block;color:#8a95ad;font:12px/1.4 ui-monospace,monospace;margin:0 0 8px}
.t,.v,.i{font-family:NS,serif}.t{margin:0}
.phone{width:360px;height:740px;position:relative;overflow:hidden;border-radius:28px;outline:1px solid #2a364c;background:#111827}
.phone>.v{height:100%!important;width:100%!important}
.scrim{width:360px;padding:40px 24px;background:#05080f;border-radius:28px;outline:1px solid #2a364c}
.dlg{width:312px;border-radius:28px;background:rgba(26,35,51,.92);border:1px solid rgba(255,255,255,.08);box-shadow:0 24px 60px rgba(0,0,0,.5);overflow:hidden}
.shade{width:360px;padding:14px;background:#1c1f26;border-radius:20px;outline:1px solid #2a364c}
.shade .n{border-radius:16px;overflow:hidden}
.fade{-webkit-mask-image:linear-gradient(#000 80%,transparent);mask-image:linear-gradient(#000 80%,transparent)}
h2{font-size:18px;margin:40px 0 14px;border-bottom:1px solid #2a364c;padding-bottom:6px}
canvas{max-width:100%;height:auto;border-radius:16px;outline:1px solid #2a364c;background:#111827}
"""


def build():
    load_values()
    cards = []
    for path, title, kind in SCREENS:
        root = ET.parse(RES / path).getroot()
        fname = Path(path).stem
        inner = render(root, fname=fname)
        if kind == "screen":
            body = f'<div class="phone">{inner}</div>'
        elif kind == "dialog":
            body = f'<div class="scrim"><div class="dlg">{inner}</div></div>'
        else:
            body = f'<div class="shade"><div class="n">{inner}</div></div>'
        cards.append(f'<div class="card" id="{fname}"><h3>{html.escape(title)}</h3><small>res/{path}</small>{body}</div>')
    nav = "".join(f'<a href="#{Path(p).stem}">{html.escape(t)}</a>' for p, t, k in SCREENS) + '<a href="#widgets">উইজেট</a>'
    kt = (ROOT / "app/src/main/java/com/gunjoron/patheyo/widgethub/widget/theme/Palettes.kt").read_text(encoding="utf-8")
    pal = {}
    MINK = ["cardFill", "cardStroke", "primary", "secondary", "accent", "track"]
    for m in re.finditer(r"val (D[12]|MIN)_(GLASS|LIGHT|NOBG_DARK|NOBG_LIGHT) = Palette\w+\((.*?)\)\s*$", kt, re.M):
        vals = [int(v, 16) if v.startswith("0x") else 0 for v in re.findall(r"=?\s*(0x[0-9A-Fa-f]+|\b0\b)(?=\.toInt\(\)|,|$)", m.group(3))]
        if m.group(1) == "MIN":
            d = dict(zip(MINK, vals))
        else:
            d = {k: int(v, 16) if v.startswith("0x") else 0 for k, v in re.findall(r"(\w+)=(0x[0-9A-Fa-f]+|0)(?=\.toInt|,|$)", m.group(3))}
        pal[m.group(1) + "_" + m.group(2)] = d
    widgets_js = "window.__PALETTES__=" + json.dumps(pal) + ";\n" + (Path(__file__).parent / "widgets.js").read_text(encoding="utf-8") if (Path(__file__).parent / "widgets.js").exists() else ""
    page = (
        '<!doctype html><html lang="bn"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        "<title>পাথেয় — Android প্রিভিউ</title>"
        f"<style>{CSS}</style><body>"
        "<h1>Android-only স্ক্রিনের প্রিভিউ</h1>"
        '<p class="sub">এটা <code>tools/android-preview/build.py</code> দিয়ে অ্যাপের আসল XML থেকে বানানো (মাপ dp/sp = px, ডার্ক মোড, ফন্ট Noto Serif by Gunjoron)। '
        "ফোন ছাড়াই এখানে দেখে লেখা, মাপ, রং ঠিক করা যায়; ঠিক করে স্ক্রিপ্ট আবার চালালে প্রিভিউ নতুন হয়। "
        "Kotlin-এ চালু সময়ে বসানো লেখা এখানে নমুনা।</p>"
        f"<nav>{nav}</nav>"
        f'<div class="grid">{"".join(cards)}</div>'
        '<h2 id="widgets">হোম স্ক্রিন উইজেট</h2><div id="wroot"></div>'
        f"<script>{widgets_js}</script><script>renderWidgets(document.getElementById('wroot'))</script></body></html>"
    )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(page, encoding="utf-8")
    print(f"✅ {OUT.relative_to(ROOT)} ({len(page.encode()) // 1024} KB, {len(SCREENS)} স্ক্রিন)")


if __name__ == "__main__":
    build()
