# Android প্রিভিউ (ফোন ছাড়াই)

`python3 tools/android-preview/build.py` → `docs/android-preview/index.html` (ব্রাউজারে খুলুন)।

- **নেটিভ স্ক্রিন** (স্প্ল্যাশ নয়): `res/layout*/*.xml` থেকে সরাসরি বানানো — মাপ dp/sp = px, ডার্ক মোড, ফন্ট Noto Serif by Gunjoron। Kotlin-এ চালু সময়ে বসানো লেখা নমুনা (`SAMPLES`)।
- **হোম স্ক্রিন উইজেট** (`widgets.js`): Kotlin ক্যানভাস-কোডের JavaScript অনুবাদ। রঙ `Palettes.kt` থেকে স্বয়ংক্রিয়, ছবি `res/drawable-nodpi/` থেকে।
  - অনুবাদ করা: ডিজাইন ১ ক্লাসিক, ২ এসেনশিয়াল (ClassicDesign.kt), ৪ মিনিমাল (MinimalDesign.kt) — ৪ রূপ (গ্লাস/লাইট/ট্রান্সপারেন্ট ×২) ও নিষিদ্ধ সময়ের অবস্থা।
  - এখনো নয়: ডিজাইন ৩, ৫–৯ (Kotlin-এ আছে)। বদলালে `widgets.js` ও Kotlin দুটোই মেলান।
- ফন্টের মাপ-সমন্বয় (১০০০/১১৭০) Kotlin-এর `Fonts.BRAND_SCALE` ও `AppFonts.uiSize()`-এর মতোই।
