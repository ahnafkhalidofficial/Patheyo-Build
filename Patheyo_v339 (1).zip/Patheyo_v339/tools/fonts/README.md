# ব্র্যান্ড ফন্ট — Noto Serif by Gunjoron

গুঞ্জরণের নিজস্ব ব্র্যান্ড ফন্ট। পাথেয়-র **সব বাংলা লেখা, বাংলা সংখ্যা (০-৯) ও ইংরেজি সংখ্যা (0-9)** এই একটা ফন্টেই।
মূল ফন্ট-প্যাকেজ (৯টা ওজন, `OFL.txt`, `FONTLOG.txt`, `README.md`) হুবহু রাখা আছে: `Noto Serif by Gunjoron/`।
ক্রিয়েটর: মুস্তাফিজুর রহমান জুনায়েদ · প্রকাশক: গুঞ্জরণ · লাইসেন্স: SIL Open Font License 1.1 · সংস্করণ 3.100

## অ্যাপে কোথায় কোন ফাইল
| জায়গা | ফাইল / নাম |
|---|---|
| WebView (সব পেজ) | `app/src/main/assets/fonts/NotoSerifByGunjoron-*.ttf` (৯টা ওজন, Thin 100 … Black 900) |
| CSS পরিবার | `"NotoSerifByGunjoron"` (লেখা) · `"NotoSerifByGunjoronDigits"` (শুধু ০-৯ ও 0-9) — `shared/ds/fonts.css` |
| নেটিভ পপআপ / আজান / অ্যালার্ম | `AppFonts.BN_REGULAR`, `AppFonts.BN_BOLD` (assets/fonts থেকে) |
| উইজেট / ডেট-কার্ড / ক্যাল-নোট | `res/font/noto_serif_by_gunjoron_regular.ttf`, `..._bold.ttf` |
| নোটিফিকেশন (Android 8+) | `res/font/noto_serif_by_gunjoron.xml` (`@font/noto_serif_by_gunjoron`) |
| লাইসেন্স | `app/src/main/assets/fonts/OFL-NotoSerifByGunjoron.txt` |

## মাপ মেলানো
ফন্টটা ১০০০ UPM-এ আঁকা, আর অ্যাপের সব মাপ ১১৭০ UPM-এর লেখায় সাজানো। তাই ফাইল হুবহু রেখে:
* CSS-এ `size-adjust: 85.47%` + `ascent-override: 97.2%` + `descent-override: 35%` + `line-gap-override: 0%` — লেখা ও লাইন-উচ্চতা ডিজাইন করা মাপেই থাকে।
* উইজেট ও ডেট-কার্ডের ক্যানভাসে `Fonts.sizeFor(tf, size)` (গুণক `Fonts.BRAND_SCALE = 1000/1170`)।

## ফন্ট বদলাতে / হালনাগাদ করতে
নতুন সংস্করণ এলে `Noto Serif by Gunjoron/` ফোল্ডারে আর `app/src/main/assets/fonts/`-এ একই নামে `.ttf` বদলে দিন;
`res/font/noto_serif_by_gunjoron_regular.ttf` ও `_bold.ttf`-এ Regular ও Bold কপি করুন। কোনো কোড বদলাতে হবে না।
