# Noto Serif by Gunjoron

**গুঞ্জরণের ব্র্যান্ড ফন্ট, সবার জন্য ফ্রি।**
সংস্করণ 3.100 · হালনাগাদ: ১২ নভেম্বর ২০২৬
ক্রিয়েটর: মুস্তাফিজুর রহমান জুনায়েদ · প্রকাশক: গুঞ্জরণ
ওয়েবসাইট: https://patheyobygunjoron.github.io/

![সব ওজনের নমুনা](preview-all-weights.png)

---

## বাংলা

### ফন্ট পরিচিতি
Noto Serif by Gunjoron গুঞ্জরণের নিজস্ব ব্র্যান্ড ফন্ট। এর ভিত্তি গুগলের জনপ্রিয় Noto Serif Bengali। বাংলা অক্ষর, যুক্তাক্ষর আর কার-ফলা Noto Serif Bengali-র মতোই রাখা হয়েছে, তাই লেখা পরিষ্কার আর পড়তে আরাম লাগে।

এর বিশেষত্ব হলো বাংলা সংখ্যা। ০ থেকে ৯ পর্যন্ত দশটা সংখ্যাই মুস্তাফিজুর রহমান জুনায়েদ গুঞ্জরণের জন্য নতুন করে এঁকেছেন। প্রতিটা ওজনের অক্ষরের সঙ্গে মানিয়ে সংখ্যাগুলোর মাপ, অবস্থান আর ফাঁক মেলানো হয়েছে।

### ওজন (৯টি)
Thin · ExtraLight · Light · Regular · Medium · SemiBold · Bold · ExtraBold · Black

### আপনি যা করতে পারবেন, সম্পূর্ণ ফ্রিতে
- ব্যক্তিগত ও বাণিজ্যিক যেকোনো কাজে ব্যবহার করতে পারবেন: বই, পত্রিকা, পোস্টার, লোগো, ভিডিও, সোশ্যাল মিডিয়া, প্যাকেজিং ইত্যাদি।
- ওয়েবসাইট, অ্যাপ বা পিডিএফে এমবেড করতে পারবেন।
- বন্ধু বা সহকর্মীদের সঙ্গে শেয়ার করতে পারবেন।
- নিজের মতো পরিবর্তনও করতে পারবেন।
- এই ফন্ট দিয়ে বানানো ডিজাইন, ছবি বা লেখা পুরোপুরি আপনার। সেগুলোর ওপর কোনো শর্ত নেই।

### শুধু কয়েকটা শর্ত (SIL Open Font License 1.1)
- ফন্ট ফাইলটা আলাদা করে বিক্রি করা যাবে না।
- কোথাও শেয়ার বা বিতরণ করলে সঙ্গে `OFL.txt` লাইসেন্স ফাইলটা রাখতে হবে।
- ফন্ট পরিবর্তন করে বিতরণ করলে সেটাও একই OFL লাইসেন্সে দিতে হবে।

### ইনস্টল করার নিয়ম
- **Windows:** `.ttf` ফাইলে রাইট-ক্লিক করে **Install** অথবা **Install for all users** বেছে নিন।
- **macOS:** ফাইলে ডাবল-ক্লিক করুন, তারপর **Install Font** চাপুন।
- **Android / iOS:** যে অ্যাপে কাস্টম ফন্ট দেওয়া যায়, সেখান থেকে ফাইলটা যুক্ত করুন।
- ইনস্টলের পর ফন্ট তালিকায় **Noto Serif by Gunjoron** নামে খুঁজুন।

### ওয়েবসাইটে ব্যবহার
```css
@font-face {
  font-family: "Noto Serif by Gunjoron";
  src: url("NotoSerifByGunjoron-Regular.ttf") format("truetype");
  font-weight: 400;
  font-display: swap;
}
body { font-family: "Noto Serif by Gunjoron", serif; }
```
অন্য ওজনের জন্য একই নিয়মে আরেকটা `@font-face` যোগ করুন, আর `font-weight` বদলে দিন।
ওজনগুলোর মান: Thin 100, ExtraLight 200, Light 300, Regular 400, Medium 500, SemiBold 600, Bold 700, ExtraBold 800, Black 900।

---

## English

### About
Noto Serif by Gunjoron is the brand typeface of **Gunjoron | গুঞ্জরণ**. It is built on Google's Noto Serif Bengali, and all Bengali letters, conjuncts and shaping are kept exactly as in Noto. The ten Bengali digits (০–৯) were newly drawn for Gunjoron by **Mustafizur Rahman Junayed**. In every weight, their size, position and spacing are fitted to the surrounding text.

### Weights
Thin, ExtraLight, Light, Regular, Medium, SemiBold, Bold, ExtraBold, Black

### License: free to use
This font is released under the **SIL Open Font License 1.1** (see `OFL.txt`).

You may:
- use it for personal and commercial work;
- embed it in websites, apps and documents;
- share it with others;
- modify it.

Conditions:
- The font files may not be sold on their own.
- Keep `OFL.txt` with any copy you share.
- Modified versions must stay under the OFL.

Anything you create with the font is entirely yours.

### Credits
- Bengali digits and modifications: Mustafizur Rahman Junayed, Gunjoron | গুঞ্জরণ (2026)
- Noto Serif Bengali: Juan Bruce, Universal Thirst, Indian Type Foundry and the Monotype Design Team. Copyright 2025 The Noto Project Authors.

Noto is a trademark of Google Inc. Gunjoron is a registered trademark.
