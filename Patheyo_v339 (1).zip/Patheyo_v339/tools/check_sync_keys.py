#!/usr/bin/env python3
"""
v247 — ইউজারের কোনো ডেটা ভুলে ক্লাউড-সিঙ্কের বাইরে থেকে যাচ্ছে কি না ধরার পরীক্ষক।

assets-এর সব JS/HTML-এ localStorage-এর যত চাবি পাওয়া যায়, প্রতিটা তিন ভাগের একটায় পড়তে হবে:
  ১) সিঙ্কে যায়   — shell/js/07-backup-settings.js-এর KEYS তালিকায়, বা নাম "ptu_" দিয়ে শুরু
  ২) ডিভাইসের নিজস্ব — নিচের DEVICE_ONLY-তে কারণসহ (ক্যাশ, ডাউনলোডের অবস্থা, অস্থায়ী ফ্ল্যাগ…)
  ৩) বাকি সব = অচেনা → এই স্ক্রিপ্ট ব্যর্থ হয়; ঠিক করুন (ইউজারের ডেটা হলে ptu_ নাম বা KEYS-এ, নইলে DEVICE_ONLY-তে)
চালান:  python3 tools/check_sync_keys.py
"""
import os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app', 'src', 'main', 'assets')

# ডিভাইসের নিজস্ব — ক্লাউডে যাওয়া উচিত নয় (কারণ পাশে)। শেষে "_" থাকলে প্রিফিক্স ধরা হয়।
DEVICE_ONLY = {
    'lastKnownPrayerData': 'নামাজের সময়ের অফলাইন ক্যাশ',
    'pf-home-namaz': 'হোমের নামাজ-কার্ডের ক্যাশ',
    'hadith-dl-flags-v': 'হাদিসের বই এই ফোনে নামানো আছে কি না',
    'tarjama-json': 'কুরআনের তরজমা ক্যাশ',
    'patheyo-read-updates': 'অ্যাপ-আপডেট বার্তা পড়া হয়েছে কি না (ব্রাউজার-টেস্ট)',
    'pt_ad_pop_': 'বিজ্ঞাপন-পপআপ দেখানোর অবস্থা',
    'pt_ads_booted': 'বিজ্ঞাপন চালুর ফ্ল্যাগ',
    'pt_backup_undo': 'রিস্টোর বাতিলের অস্থায়ী কপি',
    'pt_last_backup': 'শেষ ফাইল-ব্যাকআপের তারিখ (এই ফোনের)',
    'pt_cloud': 'এই ফোনের সিঙ্ক-অবস্থা',
    'pt_avatar_up': 'প্রোফাইল ছবি আপলোডের অবস্থা',
    'pt_avatar_dirty': 'প্রোফাইল ছবি আপলোড বাকি',
    'pt_avatar_want': 'ক্লাউড-রিস্টোরের পর Storage থেকে ছবি নামানো বাকি (v272)',
    'pt_google_mode': 'এই ফোনে Google সাইন-ইনের পথ',
    'pt_frame_use': 'ফিচার খোলার গণনা (এই ফোনের সাজানোর জন্য)',
    'pt_onboarded': 'এই ফোনের অনবোর্ডিং শেষ',
    'pt_pdf_used': 'মুসহাফ PDF এই ফোনে নামানো',
    'pt_pw_last': 'প্রিমিয়াম-প্রম্পট শেষ কবে দেখানো',
    'pt_sleep_amol': 'ঘুমের আগের আমলের আজকের টিক (দিন-ভিত্তিক, ডিভাইসের)',
    'pt_reminders': 'শুধু ব্রাউজার-টেস্টের রিমাইন্ডার (অ্যাপে নেটিভ — NativeSync-এ যায়)',
    'pt_restore_pending': 'রিস্টোরের অস্থায়ী চিহ্ন',
    'pt_restored_flag': 'রিস্টোরের অস্থায়ী চিহ্ন',
    'qb_loc': 'কিবলার সর্বশেষ GPS অবস্থান (ডিভাইসের)',
    'nfFired_': 'নফল নামাজের "বেজেছে" চিহ্ন (দিন-ভিত্তিক, ডিভাইসের)',
    'pt_native_v1': 'নেটিভ ডেটার ক্লাউড-চাবি (localStorage-এ জমে না)',
}

def synced_keys():
    t = open(os.path.join(ROOT, 'shell', 'js', '07-backup-settings.js'), encoding='utf-8').read()
    m = re.search(r'var KEYS = \[(.*?)\];', t, re.S)
    return set(re.findall(r"'([^']+)'", re.sub(r'/\*.*?\*/', '', m.group(1), flags=re.S)))

PATS = [
    re.compile(r"""\b(?:getItem|setItem|removeItem)\(\s*(['"`])([^'"`]+)\1"""),
    re.compile(r"""\b(?:ld|sv|sv0|ls|lsGet|lsSet|jget|jset)\(\s*(['"])([^'"]+)\1"""),
    re.compile(r"""\b(?:[A-Z_]*KEY[A-Z_0-9]*|FLAG_KEY|RK|LK|CK)\s*=\s*(['"])([^'"]+)\1"""),
]

def used_keys():
    out = {}
    for r, _, fs in os.walk(ROOT):
        if 'vendor' in r:
            continue
        for f in fs:
            if not f.endswith(('.js', '.html')):
                continue
            p = os.path.join(r, f)
            try:
                t = open(p, encoding='utf-8').read()
            except Exception:
                continue
            for pt in PATS:
                for m in pt.finditer(t):
                    out.setdefault(m.group(2), set()).add(os.path.relpath(p, ROOT))
    return out

def main():
    synced = synced_keys()
    unknown = []
    for k, files in sorted(used_keys().items()):
        if k in synced or k.startswith('ptu_'):
            continue
        if any(k == d or (d.endswith('_') and k.startswith(d)) or (d.endswith('-v') and k.startswith(d)) for d in DEVICE_ONLY):
            continue
        unknown.append((k, sorted(files)[:3]))
    if unknown:
        print('অচেনা localStorage চাবি (সিঙ্কেও নেই, ডিভাইস-তালিকাতেও নেই):')
        for k, f in unknown:
            print('  ✘', k, '←', ', '.join(f))
        print('\nইউজারের ডেটা হলে চাবির নাম "ptu_…" করুন (বা 07-backup-settings.js-এর KEYS-এ দিন); ডিভাইসের নিজস্ব হলে DEVICE_ONLY-তে কারণসহ যোগ করুন।')
        return 1
    print('সব localStorage চাবি চেনা: %d সিঙ্কে, বাকি ডিভাইসের নিজস্ব।' % len(synced))
    return 0

if __name__ == '__main__':
    sys.exit(main())
