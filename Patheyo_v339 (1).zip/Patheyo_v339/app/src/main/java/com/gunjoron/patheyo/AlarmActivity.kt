package com.gunjoron.patheyo

// রাখতে হবে: app/src/main/java/com/gunjoron/Patheyo/AlarmActivity.kt

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.alarm.AzanForegroundService

class AlarmActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ১. ফোন লক থাকলেও যেন অ্যালার্মের স্ক্রিনটি লক স্ক্রিনের উপরে ভেসে ওঠে তার সেটিংস
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                        or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        // ২. ডিজাইন ফাইল যুক্ত করা
        setContentView(R.layout.activity_alarm)
        com.gunjoron.patheyo.ui.AppFonts.applyBanglaFontToTree(this, window.decorView)

        // ৩. কোন ওয়াক্তের আজান তা ইনটেন্ট থেকে নিয়ে বাংলায় কনভার্ট করা
        val waqt = intent.getStringExtra("waqt") ?: ""
        val tvAlarmLabel = findViewById<TextView>(R.id.tvAlarmLabel)

        // ওয়াক্ত অনুযায়ী লেখা ডায়নামিক করা
        val formattedLabel = when (waqt.lowercase()) {
            "fajr", "ফজর" -> "ফজরের নামাজের আজান"
            "dhuhr", "যোহর", "জোহর" -> "যোহরের নামাজের আজান"
            "asr", "আসর" -> "আসরের নামাজের আজান"
            "maghrib", "মাগরিব" -> "মাগরিবের নামাজের আজান"
            "isha", "এশা", "ইশা" -> "এশার নামাজের আজান"
            "জুমা", "জুম'আ", "জুম’আ" -> "জুম’আর নামাজের আজান"
            else -> "নামাজের আজান" // কোনো কারণে ওয়াক্ত না পেলে ডিফল্ট লেখা
        }

        tvAlarmLabel.text = formattedLabel

        // ৪. অ্যালার্ম বন্ধ করার প্রধান বাটনের কাজ
        val btnDismiss = findViewById<Button>(R.id.btnDismiss)
        btnDismiss.setOnClickListener {
            stopAzanService()
            finish()
        }

        // ৫. Snooze বাটনের কাজ
        val btnSnooze = findViewById<Button>(R.id.btnSnooze)
        btnSnooze.setOnClickListener {
            stopAzanService()
            finish()
        }
    }

    private fun stopAzanService() {
        startService(Intent(this, AzanForegroundService::class.java).apply {
            action = AzanForegroundService.ACTION_STOP
        })
    }
}