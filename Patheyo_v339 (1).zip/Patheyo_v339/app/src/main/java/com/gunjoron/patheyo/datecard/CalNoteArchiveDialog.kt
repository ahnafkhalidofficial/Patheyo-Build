package com.gunjoron.patheyo.datecard

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.gunjoron.patheyo.calnote.CalNoteCloud
import com.gunjoron.patheyo.calnote.CalNotes
import com.gunjoron.patheyo.widgethub.data.calendar.Bn

/**
 * v245: নোট আর্কাইভ — তারিখ/সময় শেষ হওয়া নোট এখানে নিজে জমা হয়।
 * সাইন-ইন থাকলে অ্যাকাউন্টে সেভ (সাথে ফোনেও), না থাকলে শুধু ফোনে — আর তখন লগইনের ছোট সতর্কতা দেখায়।
 */
class CalNoteArchiveDialog(private val ctx: Context, private val p: HijriCalendarCard.Pal) {

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * ctx.resources.displayMetrics.density
    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text; textSize = com.gunjoron.patheyo.ui.AppFonts.uiSize(size); setTextColor(color); typeface = if (bold) p.bold else p.reg
    }
    private fun rounded(r: Float, fill: Int, stroke: Int = 0) = GradientDrawable().apply {
        cornerRadius = dpf(r); setColor(fill); if (stroke != 0) setStroke(dp(1), stroke)
    }

    fun show(host: HijriCalendarCard.Host?, onClosed: () -> Unit) {
        val dialog = Dialog(ctx)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surfHi, p.surf)).apply {
                cornerRadius = dpf(24f); setStroke(dp(1), p.line)
            }
        }
        val title = tv("নোট আর্কাইভ", 19f, p.text, true)
        root.addView(title)
        root.addView(tv("তারিখ বা সময় পেরিয়ে যাওয়া নোট স্বয়ংক্রিয়ভাবে এখানে জমা হয়।", 12.5f, p.text3).apply { setPadding(0, dp(3), 0, dp(12)) })

        val banner = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(banner, LinearLayout.LayoutParams(-1, -2))

        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(ctx).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) })

        fun renderBanner() {
            banner.removeAllViews()
            if (CalNoteCloud.isLoggedIn()) {
                banner.addView(tv("✓ সাইন-ইন করা আছে — নোট ও আর্কাইভ আপনার অ্যাকাউন্টে সেভ থাকছে (ফোনেও আছে)।", 12f, p.okText, true).apply {
                    setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(12f, p.okSoft); setLineSpacing(0f, 1.2f)
                })
            } else {
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = rounded(12f, p.goldSoft, p.goldLine)
                }
                box.addView(tv("আপনি সাইন-ইন করেননি। নোট ও আর্কাইভ এখন শুধু এই ফোনের স্টোরেজে সেভ আছে — অ্যাপ মুছলে বা ফোন বদলালে হারিয়ে যেতে পারে। সাইন-ইন করলে আপনার অ্যাকাউন্টে সেভ থাকবে।",
                    12f, p.text, false).apply { setLineSpacing(0f, 1.25f) })
                if (host != null) box.addView(tv("সাইন-ইন করুন  ›", 13f, p.gold, true).apply {
                    setPadding(0, dp(8), 0, 0)
                    setOnClickListener { dialog.dismiss(); host.openLogin() }
                })
                banner.addView(box)
            }
        }

        fun renderList() {
            list.removeAllViews()
            val items = CalNotes.archived(ctx)
            title.text = if (items.isEmpty()) "নোট আর্কাইভ" else "নোট আর্কাইভ · ${Bn.digits(items.size)}টি"
            if (items.isEmpty()) {
                list.addView(tv("আর্কাইভে এখনো কিছু নেই।", 13f, p.text3).apply { setPadding(dp(2), dp(14), 0, dp(14)) })
                return
            }
            for (a in items) {
                val n = a.note
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), dp(11), dp(8), dp(11)); background = rounded(14f, p.surf2, p.line)
                }
                val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                col.addView(tv(n.text, 14f, p.text, true).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END; setLineSpacing(0f, 1.2f) })
                val meta = CalNotes.dateLine(n) + " · " + CalNotes.modeLabel(n.mode)
                col.addView(tv(meta, 11.5f, p.text3).apply { setPadding(0, dp(4), 0, 0) })
                row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(tv("মুছুন", 12f, Color.parseColor("#E5594F"), true).apply {
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    setOnClickListener {
                        // v283: মোছার আগে নিশ্চিতকরণ
                        android.app.AlertDialog.Builder(ctx).setTitle("নোট মুছবেন?").setMessage(n.text)
                            .setPositiveButton("মুছুন") { _, _ ->
                                CalNotes.deleteArchived(ctx, a.key)
                                CalNoteCloud.push(ctx)
                                renderList()
                            }
                            .setNegativeButton("না", null).show()
                    }
                })
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
        }

        root.addView(tv("বন্ধ করুন", 15f, p.text, true).apply {
            gravity = Gravity.CENTER; minHeight = dp(46)
            background = rounded(12f, Color.TRANSPARENT, p.goldLine)
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        renderBanner(); renderList()

        val frame = android.widget.FrameLayout(ctx).apply { setPadding(dp(14), dp(14), dp(14), dp(14)); addView(root) }
        dialog.setContentView(frame)
        dialog.setOnDismissListener { onClosed() }
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, (ctx.resources.displayMetrics.heightPixels * 0.82f).toInt())
            setDimAmount(0.6f)
        }
        dialog.show()
    }
}
