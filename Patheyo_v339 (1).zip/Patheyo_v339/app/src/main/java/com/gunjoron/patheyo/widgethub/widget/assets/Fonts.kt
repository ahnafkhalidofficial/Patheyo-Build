package com.gunjoron.patheyo.widgethub.widget.assets

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.gunjoron.patheyo.R

/** ফন্ট একবারই লোড হয় (static TTF — ভেরিয়েবল ফন্ট নয়, তাই পুরনো ফোনেও উইজেট ভাঙে না)। */
object Fonts {
    @Volatile private var ready = false
    lateinit var regular: Typeface; private set   // ব্র্যান্ড ফন্ট Noto Serif by Gunjoron রেগুলার (বাংলা লেখা ও সংখ্যা)
    lateinit var bold: Typeface; private set      // ব্র্যান্ড ফন্ট Noto Serif by Gunjoron বোল্ড (বাংলা লেখা ও সংখ্যা)
    lateinit var bebas: Typeface; private set     // ডিজিটাল সংখ্যা
    lateinit var clockBold: Typeface; private set // ডিজাইন ৩-এর বড় ঘড়ি (EB Garamond Bold)
    lateinit var clockReg: Typeface; private set  // AM/PM ও সেকেন্ড (EB Garamond Regular)
    lateinit var outfit: Typeface; private set    // ডিজাইন ৪/৫-এর পাতলা আধুনিক ঘড়ি (Outfit Light)

    /**
     * ব্র্যান্ড ফন্ট (Noto Serif by Gunjoron) ১০০০ UPM-এ আঁকা; উইজেট ও ডেট-কার্ডের সব মাপ (px) ১১৭০ UPM-এর লেখায় সাজানো।
     * তাই ক্যানভাসে আঁকার সময় এই গুণক দিলে লেখা হুবহু আগের চোখের মাপে বসে — কিছু কাটে না, সরে না।
     * (ওয়েবভিউতে একই কাজ CSS-এর size-adjust: 85.47% করে।)
     */
    const val BRAND_SCALE = 1000f / 1170f

    /** [tf] ব্র্যান্ড ফন্ট হলে [size]-কে [BRAND_SCALE] দিয়ে মেলায়; অন্য ফন্টে (Bebas, Garamond, Outfit) মাপ অপরিবর্তিত। */
    fun sizeFor(tf: Typeface, size: Float): Float =
        if (ready && (tf === regular || tf === bold)) size * BRAND_SCALE else size

    private fun font(ctx: Context, id: Int, fallback: Typeface): Typeface =
        try { ResourcesCompat.getFont(ctx, id) ?: fallback } catch (_: Throwable) { fallback }

    fun init(ctx: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            val c = ctx.applicationContext
            regular = font(c, R.font.noto_serif_by_gunjoron_regular, Typeface.DEFAULT)
            bold = font(c, R.font.noto_serif_by_gunjoron_bold, Typeface.DEFAULT_BOLD)
            bebas = font(c, R.font.bebas_neue, Typeface.DEFAULT_BOLD)
            clockBold = font(c, R.font.ebgaramond_bold, Typeface.DEFAULT_BOLD)
            clockReg = font(c, R.font.ebgaramond_regular, Typeface.DEFAULT)
            outfit = font(c, R.font.outfit_light, Typeface.DEFAULT)
            ready = true
        }
    }
}
