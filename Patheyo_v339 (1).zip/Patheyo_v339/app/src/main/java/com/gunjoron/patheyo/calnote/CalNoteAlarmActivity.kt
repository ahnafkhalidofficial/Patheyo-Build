package com.gunjoron.patheyo.calnote

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import java.util.Calendar

/**
 * v244: নোটের এলার্ম-স্ক্রিন — লক-স্ক্রিনের ওপরেও ভেসে ওঠে। বড় করে সময়, তারিখ ও নোটের লেখা;
 * "বন্ধ করুন" ও "৫ মিনিট পরে" বাটন। সার্ভিসের রিংটোন থামলে (বন্ধ/সময়সীমা) স্ক্রিন নিজেই বন্ধ হয়।
 */
class CalNoteAlarmActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private var noteId = -1
    private val born = android.os.SystemClock.elapsedRealtime()
    private lateinit var timeTv: TextView
    private lateinit var dateTv: TextView
    private lateinit var noteTv: TextView
    private var bold: Typeface = Typeface.DEFAULT_BOLD
    private var reg: Typeface = Typeface.DEFAULT

    private val watch = object : Runnable {
        override fun run() {
            // সার্ভিস চালু হতে একটু সময় লাগতে পারে — প্রথম ৪ সেকেন্ড অপেক্ষা
            if (!CalNoteAlarmService.isRunning && android.os.SystemClock.elapsedRealtime() - born > 4000L) { finish(); return }
            // অন্য একটা নোটের এলার্ম এলে স্ক্রিনও নতুনটার তথ্য দেখায়
            val cur = CalNoteAlarmService.currentId
            if (cur >= 0 && cur != noteId) { noteId = cur; fill() }
            ui.postDelayed(this, 700L)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { ResourcesCompat.getFont(this, R.font.noto_serif_by_gunjoron_bold)?.let { bold = it } } catch (_: Throwable) {}
        try { ResourcesCompat.getFont(this, R.font.noto_serif_by_gunjoron_regular)?.let { reg = it } } catch (_: Throwable) {}

        noteId = intent?.getIntExtra(CalNotes.EXTRA_ID, -1) ?: -1
        if (CalNotes.get(this, noteId) == null) { finish(); return }
        setContentView(buildUi())
        fill()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val id = intent.getIntExtra(CalNotes.EXTRA_ID, -1)
        if (id >= 0) { noteId = id; fill() }
    }

    override fun onResume() { super.onResume(); ui.removeCallbacks(watch); ui.postDelayed(watch, 700L) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(watch) }

    private fun tv(size: Float, color: Int, b: Boolean) = TextView(this).apply {
        textSize = com.gunjoron.patheyo.ui.AppFonts.uiSize(size); setTextColor(color); typeface = if (b) bold else reg; gravity = Gravity.CENTER
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#0B1220"), Color.parseColor("#17233A")))
            setPadding(dp(24), dp(56), dp(24), dp(32))
        }
        val gold = Color.parseColor("#D4A24C")
        // ঘণ্টার আইকন — সোনালি গোল ব্যাজে
        val badge = ImageView(this).apply {
            setImageResource(R.drawable.ic_bell)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#29D4A24C")); setStroke(dp(1), Color.parseColor("#6BD4A24C")) }
        }
        root.addView(badge, LinearLayout.LayoutParams(dp(84), dp(84)))
        root.addView(tv(14f, gold, true).apply { text = "ক্যালেন্ডার নোট"; setPadding(0, dp(14), 0, 0) })
        timeTv = tv(44f, Color.WHITE, true).apply { setPadding(0, dp(10), 0, 0) }
        root.addView(timeTv)
        dateTv = tv(14f, Color.parseColor("#9FB0CC"), false).apply { setPadding(0, dp(4), 0, dp(24)) }
        root.addView(dateTv)

        noteTv = tv(22f, Color.WHITE, true).apply { setLineSpacing(0f, 1.25f); setPadding(dp(20), dp(20), dp(20), dp(20)) }
        val card = ScrollView(this).apply {
            isFillViewport = true
            background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(Color.parseColor("#1F2C44")); setStroke(dp(1), Color.parseColor("#33FFFFFF")) }
            addView(noteTv, android.view.ViewGroup.LayoutParams(-1, -1))      // লেখা কার্ডের ঠিক মাঝখানে (বড় হলে স্ক্রল)
        }
        root.addView(card, LinearLayout.LayoutParams(-1, 0, 1f))

        fun btn(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
            this.text = text; textSize = com.gunjoron.patheyo.ui.AppFonts.uiSize(17f); typeface = bold; gravity = Gravity.CENTER
            setTextColor(if (filled) Color.WHITE else Color.parseColor("#E6ECF7"))
            background = if (filled) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#4169E1"), Color.parseColor("#3457D5"))).apply { cornerRadius = dp(16).toFloat() }
                         else GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(1), Color.parseColor("#6BD4A24C")) }
            minHeight = dp(56)
            setOnClickListener { onClick() }
        }
        root.addView(btn("বন্ধ করুন", true) {
            CalNoteAlarmService.dismiss(this, noteId, false); finish()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })
        root.addView(btn("${Bn.digits(CalNotes.SNOOZE_MIN)} মিনিট পরে মনে করান", false) {
            CalNoteAlarmService.dismiss(this, noteId, true); finish()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        return root
    }

    private fun fill() {
        val n = CalNotes.get(this, noteId) ?: return
        val wd = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")
        val dow = Calendar.getInstance().apply { clear(); set(n.y, n.m, n.d) }.get(Calendar.DAY_OF_WEEK) - 1
        timeTv.text = if (n.hasTime) CalNotes.fmtTime(n.minutes) else "আজ"
        dateTv.text = "${wd[dow]} · ${Bn.digits(n.d)} ${Bn.GREG_MONTHS[n.m]} ${Bn.digits(n.y)}"
        noteTv.text = n.text
    }
}
