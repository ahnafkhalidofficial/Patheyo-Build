package com.gunjoron.patheyo

// app/src/main/java/com/gunjoron/Patheyo/PatheyoApp.kt
//
// Firebase Realtime Database-এর offline persistence এখানে একবার চালু করা হয়।
// এটি Application class-এ রাখা বাধ্যতামূলক — অন্যত্র রাখলে crash হতে পারে।

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.database.FirebaseDatabase
import com.gunjoron.patheyo.notification.IslamicNotificationWorker
import com.gunjoron.patheyo.update.NotificationHelper
import com.gunjoron.patheyo.update.UpdateWorker
import com.gunjoron.patheyo.widget.WidgetRefreshScheduler
import com.gunjoron.patheyo.widget.WidgetUpdateWorker
import java.util.concurrent.TimeUnit

class PatheyoApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // ✅ FIX #NEW (v4 — widget সম্পূর্ণ ফ্রিজ হয়ে যাওয়ার আরেকটা সম্ভাব্য কারণ ঠিক করা হলো):
        // আগে এখানে Firebase/RTDB init সবার আগে চলত, তারপর widget-scheduling। Firebase init
        // (নেটওয়ার্ক না থাকা অবস্থায় কোনো OEM-এ, বা persistence দুইবার চালু করার চেষ্টায়)
        // ব্যর্থ/exception হলে এর নিচের widget-scheduling কোডই আর চলত না — অর্থাৎ অ্যাপ প্রসেস
        // যতবারই ব্যাকগ্রাউন্ডে জাগুক না কেন, widget-এর AlarmManager চেইন কখনো পুনরায়
        // প্রতিষ্ঠিত হতো না। এখন widget-এর জন্য সবচেয়ে গুরুত্বপূর্ণ দুইটা কাজ — AlarmManager
        // চেইন ও WorkManager ব্যাকআপ — সবার আগে, স্বাধীনভাবে try-catch(Throwable) দিয়ে চলে;
        // Firebase/নোটিফিকেশন init ব্যর্থ হলেও widget রিফ্রেশ থেমে থাকবে না।
        try {
            WidgetRefreshScheduler.scheduleAll(this)
        } catch (t: Throwable) { /* পরের ব্যাকগ্রাউন্ড wake-এ আবার চেষ্টা হবে */ }

        try {
            // ✅ v24: ৮০-মিনিটের WorkManager ব্যাকআপ (WidgetRefreshScheduler-এ কেন্দ্রীভূত)
            WidgetRefreshScheduler.ensureBackupWork(this)
        } catch (t: Throwable) { /* পরের ব্যাকগ্রাউন্ড wake-এ আবার চেষ্টা হবে */ }

        // ✅ v30: Firebase Console থেকে পাঠানো সাধারণ ঘোষণার জন্য আলাদা চ্যানেল।
        // আগে ডিফল্ট চ্যানেল ছিল "azan_alarm_channel" — ওই চ্যানেলে আজানের সাউন্ড সেট থাকায়
        // ঘোষণার নোটিফিকেশনেও আজান বাজার ঝুঁকি ছিল। এখন সাধারণ সাউন্ডের নিজস্ব চ্যানেল।
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(FCM_CHANNEL_ID) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(FCM_CHANNEL_ID, "ঘোষণা ও বার্তা", NotificationManager.IMPORTANCE_HIGH).apply {
                            description = "পাথেয় থেকে পাঠানো ঘোষণা ও গুরুত্বপূর্ণ বার্তা"
                        }
                    )
                }
            }
        } catch (t: Throwable) {}

        // ১২+ ঘন্টা নেট বন্ধ থাকলেও RTDB ক্যাশ থেকে আরবি তারিখ দেখাবে
        // FirebaseDataManager যে custom URL ব্যবহার করে, persistence সেখানেই চালু করতে হবে
        try {
            FirebaseDatabase.getInstance(FirebaseDataManager.RTDB_URL).setPersistenceEnabled(true)
        } catch (t: Throwable) { /* ইতোমধ্যে চালু থাকলে বা ব্যর্থ হলেও বাকি সব কাজ চলবে */ }

        // অ্যাপ বা ব্যাকগ্রাউন্ড সার্ভিস যেভাবেই চালু হোক, RTDB লিসেনার সচল রাখা হবে
        try {
            FirebaseDataManager.startRtdbListener(this)
        } catch (t: Throwable) { /* নেট/Firebase সমস্যা হলেও widget স্থানীয় হিসাব দিয়ে চলবে */ }

        // ✅ FIX #NEW (নোটিফিকেশন/উইজেট আপডেট বন্ধ হয়ে যাওয়ার মূল কারণ ঠিক করা হলো):
        // আগে WorkManager-এর periodic কাজ ("ibadat_widget_refresh", "ibadat_notif_check")
        // শুধুমাত্র MainActivity.onCreate() থেকে enqueue হতো — অর্থাৎ ইউজার অ্যাপটি নিজে
        // না খুললে এই দুটো কাজ কখনোই আবার চালু হতো না, যদি Android (Doze/App-Standby/OEM
        // ব্যাটারি সেভার) কোনো কারণে সেগুলো বাতিল/বন্ধ করে দিত। এখন Application.onCreate()
        // (যা অ্যাপ প্রসেস চালু হওয়া মাত্রই চলে — বুট রিসিভার, উইজেট আপডেট, FCM পুশ, যেকোনো
        // কারণেই হোক) থেকেও এই একই কাজ দুটো enqueue করা হচ্ছে। ExistingPeriodicWorkPolicy.KEEP
        // থাকায় এটি সম্পূর্ণ নিরাপদ — আগে থেকেই চলমান থাকলে কিছু বদলাবে না, বন্ধ/হারিয়ে
        // গিয়ে থাকলে নিজে থেকেই আবার চালু হয়ে যাবে (self-healing)।
        try {
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "ibadat_notif_check",
                ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<IslamicNotificationWorker>(1, TimeUnit.HOURS).build()
            )
        } catch (t: Throwable) {}

        // জুম’আ ও অন্যান্য ইসলামিক নোটিফিকেশন — প্রথমে যা আছে (বান্ডেল/আগের ক্যাশ) তা দিয়েই
        // সাথে সাথে শিডিউল, নেটওয়ার্কের জন্য অপেক্ষা না করে
        try {
            com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleHeartbeat(this)
            com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(this)
        } catch (t: Throwable) {}

        // এরপর Firebase Remote Config-এ নতুন কনফিগ থাকলে fetch করে আনা, থাকলে আবার রিশিডিউল
        // (এভাবেই রিবিল্ড ছাড়া নোটিফিকেশন বদলানো/যোগ করা সম্ভব হয়)
        try {
            com.gunjoron.patheyo.notification.NotificationRemoteConfigSync.fetchAndApply(this) { updated ->
                if (updated) {
                    try {
                        com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(this)
                    } catch (t: Throwable) {}
                }
            }
        } catch (t: Throwable) {}

        // ✅ ইন-অ্যাপ আপডেট (GitHub): নোটিফিকেশন চ্যানেল তৈরি + ব্যাকগ্রাউন্ড আপডেট চেক চালু
        // (আগের কোডের কোনো কাজ যেন না থামে, তাই আলাদা try-catch-এ রাখা হলো)
        try {
            NotificationHelper.createChannels(this)   // নোটিফিকেশন চ্যানেল তৈরি
            UpdateWorker.schedule(this)               // ব্যাকগ্রাউন্ড চেক চালু
        } catch (t: Throwable) {}

        // ✅ v168: প্রতিদিনের তারিখ-কার্ড — রাত ১২টার অ্যালার্ম (প্রসেস চালু হলেই আবার বসে, তাই নিজে নিজে সেরে ওঠে)
        try {
            com.gunjoron.patheyo.datecard.DateCardScheduler.schedule(this)
        } catch (t: Throwable) {}

        // ✅ v49: অ্যাডমিন প্যানেলের জন্য ব্যবহারকারী/ভার্সন গণনা (ব্যাকগ্রাউন্ডে ১২ ঘণ্টায় একবার) —
        // আলাদা try-catch, তাই এতে সমস্যা হলেও অ্যাপের আর কিছু থামে না
        try {
            com.gunjoron.patheyo.stats.AppHeartbeat.scheduleBackground(this)
        } catch (t: Throwable) {}
    }

    companion object {
        /** AndroidManifest-এর default_notification_channel_id-এর সাথে মিল থাকতে হবে */
        const val FCM_CHANNEL_ID = "fcm_default"
    }
}
