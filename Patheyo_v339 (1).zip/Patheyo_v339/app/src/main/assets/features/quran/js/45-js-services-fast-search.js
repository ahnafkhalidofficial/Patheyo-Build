/* ===== js/services/fast-search.js ===== */
/*!
 * js/services/fast-search.js -- কিতাবের ভেতরের "লাইভ" সার্চ ইঞ্জিন (পুরোপুরি অফলাইন, ফ্রি, কয়েক মিলিসেকেন্ডে ফল)
 *
 * Provides : App.FastSearch  { prepare(book,onProgress), get(book), search(book,q,opts), spans(text,terms,mode), looseBn, looseAr }
 * Needs    : core/utils (App.toEnglishDigits, App.normAr)  -- কিতাব খোলার পর সার্চ নিজে ব্যাকগ্রাউন্ডে ইনডেক্স বানায়
 *
 * কীভাবে এত দ্রুত:
 *  1) কিতাব খোলার পর একবারই ছোট ছোট ধাপে (ফোন আটকায় না) "উল্টো সূচি" (inverted index) বানানো হয়:
 *     প্রতিটি শব্দ -> কোন কোন হাদিসে আছে। বাংলা ও আরবি আলাদা সূচি; হাদিস-নম্বরের আলাদা তালিকা।
 *  2) সার্চের সময় হাদিসের পুরো লেখা আর পড়তে হয় না -- শুধু শব্দ-তালিকা (কয়েক হাজার) ও তাদের সূচি মেলানো হয়।
 *  3) সহজ বানান-সহনশীলতা: হাদিস/হাদিস, সহীহ/সহিহ, শ/ষ/স, ণ/ন, ু/ূ, ড়/ড, য়/য, ঁ, ঃ, ZWNJ সব সমান ধরা হয়।
 *     শব্দের অংশ লিখলেও মেলে (যেমন "নিয়ত" -> "নিয়তের")। একাধিক শব্দ লিখলে সবগুলো থাকতে হবে।
 *  4) র‍্যাঙ্কিং: পুরো শব্দ মিল > শব্দের শুরুর মিল > অংশের মিল; পরপর লেখা বাক্যাংশ আরও আগে।
 */
(function (App) {
  "use strict";

  var now = (typeof performance !== 'undefined' && performance.now) ? function(){ return performance.now(); } : function(){ return Date.now(); };

  // ------------------------------------------------------------------ নরমালাইজেশন
  var BN_SPLIT = /[^ঀ-৿‌‍0-9A-Za-z]+/;
  var BN_DIGIT = '০১২৩৪৫৬৭৮৯';
  var bnCache = new Map(), arCache = new Map();

  // বাংলা শব্দ -> "ঢিলেঢালা" কী (বানানের ছোটখাটো ভিন্নতা সমান)
  function looseBn(w){
    var k = bnCache.get(w);
    if (k !== undefined) return k;
    var s = w;
    try { s = s.normalize('NFD'); } catch (e) {}
    s = s.replace(/[‌‍়্ঁঃৗ]/g, '')       // ZWNJ ZWJ নুক্তা হসন্ত চন্দ্রবিন্দু ঃ ঔ-কার-চিহ্ন
         .replace(/[ী]/g, 'ি').replace(/[ূ]/g, 'ু')       // ী->ি ূ->ু
         .replace(/য/g, 'জ')                                         // য/য় -> জ (নামায = নামাজ)
         .replace(/ণ/g, 'ন')                                         // ণ->ন
         .replace(/[শষ]/g, 'স')                                 // শ ষ -> স
         .replace(/ৎ/g, 'ত')                                         // ৎ->ত
         .replace(/ঈ/g, 'ই').replace(/ঊ/g, 'উ')            // ঈ->ই ঊ->উ
         .replace(/[০-৯]/g, function(d){ return String(d.charCodeAt(0) - 0x09e6); })
         .toLowerCase();
    if (bnCache.size > 150000) bnCache.clear();
    bnCache.set(w, s);
    return s;
  }

  var AR_MARKS = /[ؐ-ًؚ-ٰٟۖ-ۭـ]/g;
  function looseAr(w){
    var k = arCache.get(w);
    if (k !== undefined) return k;
    var s = w.replace(AR_MARKS, '')
      .replace(/[آأإٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ء/g, '');
    if (arCache.size > 150000) arCache.clear();
    arCache.set(w, s);
    return s;
  }
  var AR_SPLIT = /[^ء-يٱؐ-ًؚ-ٰٟۖ-ۭـ]+/;
  function hasAr(s){ return /[ء-يٱ-ۓ]/.test(s); }

  function toAsciiDigits(s){ return String(s).replace(/[০-৯]/g, function(d){ return String(BN_DIGIT.indexOf(d)); }); }

  // ------------------------------------------------------------------ ইনডেক্স তৈরি (সময়-ভাগ করে)
  var cache = null;     // { bookId, book, st }

  function newState(book){
    return { book: book, total: book.total, H: new Array(book.total), C: new Uint16Array(book.total),
             nums: [], numToSeq: new Map(),
             bn: null, ar: null, bnReady: false, arReady: false, ready: false, failed: false, progress: 0,
             chKeys: [], cancelled: false, listeners: [], t0: now(), ms: 0 };
  }

  function addPosting(map, key, seq){
    var a = map.get(key);
    if (a === undefined) map.set(key, [seq]);
    else if (a[a.length - 1] !== seq) a.push(seq);
  }

  function finalize(map){
    var keys = new Array(map.size), posts = new Array(map.size), i = 0;
    map.forEach(function(v, k){ keys[i] = k; posts[i] = v; i++; });
    return { keys: keys, posts: posts };
  }

  function prepare(book, onProgress){
    if (!book) return null;
    if (cache && cache.book === book){
      if (onProgress) { if (cache.st.ready) onProgress(1, true); else cache.st.listeners.push(onProgress); }
      return cache.st;
    }
    if (cache) cache.st.cancelled = true;
    var st = newState(book);
    cache = { bookId: book.id, book: book, st: st };
    if (onProgress) st.listeners.push(onProgress);
    bnCache.clear(); arCache.clear();
    var data = book.data, chs = data.ch, pass = 0;       // pass 0: বাংলা + নম্বর, pass 1: আরবি
    var c = 0, s = 0, i = 0, seq = 0, bnMap = new Map(), arMap = new Map();

    // অধ্যায়ের নামের কী
    for (var q = 0; q < chs.length; q++){
      var tw = String(chs[q].t || '').split(BN_SPLIT).filter(Boolean).map(looseBn);
      st.chKeys.push(tw.join(' '));
    }

    function notify(done){
      st.progress = done ? 1 : Math.min(0.99, (pass * st.total + seq) / (2 * st.total));
      var ls = st.listeners.slice();
      if (done) st.listeners = [];
      for (var k = 0; k < ls.length; k++){ try { ls[k](st.progress, done); } catch (e) {} }
    }

    function step(){
      if (st.cancelled) return;
      var t = now(), limit = 9;
      try {
        while (c < chs.length){
          var secs = chs[c].s;
          if (s >= secs.length){ c++; s = 0; i = 0; continue; }
          var hs = secs[s].h;
          if (i >= hs.length){ s++; i = 0; continue; }
          var h = hs[i];
          if (pass === 0){
            st.H[seq] = h; st.C[seq] = c;
            var num = h[0];
            st.nums.push(num); if (!st.numToSeq.has(num)) st.numToSeq.set(num, seq);
            var bn = (h[2] || '') + ' ' + (h[3] || '') + ' ' + (h[4] || '');
            if (bn.length > 2){
              var ws = bn.split(BN_SPLIT);
              for (var w = 0; w < ws.length; w++){ if (ws[w]) { var kk = looseBn(ws[w]); if (kk) addPosting(bnMap, kk, seq); } }
            }
          } else {
            var ar = h[1];
            if (ar){
              var wa = ar.split(AR_SPLIT);
              for (var x = 0; x < wa.length; x++){ if (wa[x]) { var ka = looseAr(wa[x]); if (ka) addPosting(arMap, ka, seq); } }
            }
          }
          i++; seq++;
          if ((seq & 31) === 0 && now() - t > limit){ notify(false); setTimeout(step, 0); return; }
        }
        if (pass === 0){
          st.bn = finalize(bnMap); bnMap = null; st.bnReady = true;
          pass = 1; c = 0; s = 0; i = 0; seq = 0;
          notify(false); setTimeout(step, 0); return;
        }
        st.ar = finalize(arMap); arMap = null; st.arReady = true;
        st.ready = true; st.ms = now() - st.t0; bnCache.clear(); arCache.clear();
        notify(true);
      } catch (e) {
        st.failed = true; notify(true);
      }
    }
    setTimeout(step, 0);
    return st;
  }

  function get(book){ return (cache && cache.book === book) ? cache.st : null; }


  // ------------------------------------------------------------------ ভুল বানানেও মেলা (fuzzy)
  // আগে সবসময় সরাসরি/অংশের মিল। কোনো শব্দ কোথাও না মিললে তবেই কাছাকাছি বানানের শব্দ (১-২ অক্ষর ভুল/বাদ/বাড়তি/উল্টো) খোঁজা হয়।
  // সূচির শব্দ-তালিকা ছোট (কয়েক হাজার) আর দৈর্ঘ্য মিলিয়ে ছাঁটা, তাই টাইপ করতে করতেই (রিয়েলটাইম) চলে।
  var FZ = {};          // শব্দ -> { সূচির-কী: 1 } — শেষ ফাজি মিল; spans() এ হাইলাইটের জন্য
  var FZ_N = 0;

  function fzKey(s, mode){
    if (mode === 'ar'){
      return s.replace(/[صث]/g, 'س').replace(/ض/g, 'د').replace(/[طت]/g, 'ت').replace(/ظ/g, 'ذ')
              .replace(/ح/g, 'ه').replace(/ع/g, 'ا').replace(/(.)\1+/g, '$1');
    }
    try { s = s.normalize('NFC'); } catch (e) {}                        // ো/ৌ আবার এক অক্ষর (ো ↔ ু ইত্যাদি ১ ভুল গোনা হয়)
    s = s.replace(/ং/g, 'ঙ').replace(/ট/g, 'ত').replace(/ঠ/g, 'থ').replace(/ড/g, 'দ').replace(/ঢ/g, 'ধ')
         .replace(/(.)\1+/g, '$1');
    if (s.length > 3) s = s.replace(/হ$/, '');
    return s;
  }

  // সীমিত এডিট-দূরত্ব (বদল, বাদ, বাড়তি, পাশাপাশি উল্টো = ১)
  function lev(a, b, max){
    var la = a.length, lb = b.length;
    if (Math.abs(la - lb) > max) return max + 1;
    var p2 = new Array(lb + 1), p1 = new Array(lb + 1), cu = new Array(lb + 1), i, j;
    for (j = 0; j <= lb; j++) p1[j] = j;
    for (i = 1; i <= la; i++){
      cu[0] = i; var mn = i, ca = a.charCodeAt(i - 1);
      for (j = 1; j <= lb; j++){
        var cb = b.charCodeAt(j - 1), v = p1[j - 1] + (ca === cb ? 0 : 1), t = p1[j] + 1, u = cu[j - 1] + 1;
        if (t < v) v = t; if (u < v) v = u;
        if (i > 1 && j > 1 && ca === b.charCodeAt(j - 2) && a.charCodeAt(i - 2) === cb){ t = p2[j - 2] + 1; if (t < v) v = t; }
        cu[j] = v; if (v < mn) mn = v;
      }
      if (mn > max) return max + 1;
      var tmp = p2; p2 = p1; p1 = cu; cu = tmp;
    }
    return p1[lb];
  }

  // term-এর কাছাকাছি সূচির শব্দগুলো: [[সূচি-নম্বর, দূরত্ব], ...] (কাছেরটা আগে)
  function fuzzyKeys(idx, term, mode){
    var ft = fzKey(term, mode), tl = ft.length;
    if (term.length < 4 || tl < 3 || /^[0-9]+$/.test(term)) return [];
    var max = term.length >= 7 ? 2 : 1;
    var fk = idx.fk;
    if (!fk){ fk = idx.fk = new Array(idx.keys.length); for (var x = 0; x < fk.length; x++) fk[x] = fzKey(idx.keys[x], mode); }
    var guard = tl <= 5, out = [], first = ft.charAt(0);
    for (var i = 0; i < fk.length; i++){
      var k = fk[i], kl = k.length;
      if (kl + max < tl) continue;
      if (guard && k.charAt(0) !== first) continue;
      var d = lev(ft, k, max);
      if (d > max && kl > tl + 1 && tl >= 5){          // টাইপ চলছে: শব্দের শুরুর অংশের সাথে মিলিয়ে দেখি
        var pd = lev(ft, k.slice(0, tl), max - 1);
        if (pd <= max - 1) d = pd + 1;
      }
      if (d <= max) out.push([i, d]);
    }
    out.sort(function(a, b){ return a[1] - b[1] || a[0] - b[0]; });
    return out.length > 90 ? out.slice(0, 90) : out;
  }

  // ------------------------------------------------------------------ সার্চ
  var DEFAULT_LIMIT = 60;

  // কোয়েরি -> { mode:'num'|'bn'|'ar', terms:[...], digits }
  function parse(q){
    q = String(q || '').trim();
    if (!q) return { mode: 'empty', terms: [] };
    var d = toAsciiDigits(q).replace(/[\s,،]+/g, '');
    if (/^[0-9]+$/.test(d)) return { mode: 'num', terms: [], digits: d };
    if (hasAr(q)){
      var ta = q.split(AR_SPLIT).filter(Boolean).map(looseAr).filter(Boolean);
      return { mode: 'ar', terms: dedupe(ta) };
    }
    var tb = q.split(BN_SPLIT).filter(Boolean).map(looseBn).filter(Boolean);
    return { mode: 'bn', terms: dedupe(tb) };
  }
  function dedupe(a){ var o = [], seen = {}; for (var i = 0; i < a.length; i++){ if (!seen[a[i]]){ seen[a[i]] = 1; o.push(a[i]); } } return o; }

  function search(book, q, opts){
    var t0 = now();
    opts = opts || {};
    var limit = opts.limit || DEFAULT_LIMIT;
    var st = get(book);
    var p = parse(q);
    var out = { mode: p.mode, terms: p.terms, items: [], chapters: [], total: 0, ms: 0, ready: !!(st && st.ready), partial: false, query: q };
    if (!st || p.mode === 'empty'){ out.ms = now() - t0; return out; }

    if (p.mode === 'num'){
      var n = parseInt(p.digits, 10), list = [], seen = {};
      if (st.numToSeq.has(n)){ var sq = st.numToSeq.get(n); list.push({ seq: sq, score: 1000 }); seen[sq] = 1; }
      if (p.digits.length <= 5){
        var pre = p.digits, extra = [];
        for (var i = 0; i < st.nums.length; i++){
          var nm = st.nums[i];
          if (nm !== n && String(nm).indexOf(pre) === 0) extra.push(i);
        }
        out.total = list.length + extra.length;
        for (var e = 0; e < extra.length && list.length < limit; e++) list.push({ seq: extra[e], score: 500 - e * 0.001 });
      } else out.total = list.length;
      out.items = list.map(function(r){ return mk(st, r.seq, r.score); });
      out.ms = now() - t0; return out;
    }

    var idx = (p.mode === 'ar') ? (st.arReady ? st.ar : null) : (st.bnReady ? st.bn : null);
    if (!idx){ out.partial = true; out.ms = now() - t0; return out; }
    out.partial = !st.ready;
    var terms = p.terms, total = st.total;

    // অধ্যায়ের নামে মিল (বাংলা)
    if (p.mode === 'bn'){
      for (var c = 0; c < st.chKeys.length && out.chapters.length < 5; c++){
        var ck = st.chKeys[c]; if (!ck) continue;
        var okc = true; for (var t = 0; t < terms.length; t++){ if (ck.indexOf(terms[t]) < 0){ okc = false; break; } }
        if (okc) out.chapters.push(c);
      }
    }

    var cnt = new Uint8Array(total), score = new Uint16Array(total), best = new Uint8Array(total), touched = [];
    var any = new Uint8Array(total), anyScore = new Uint16Array(total);   // 'যেকোনো শব্দ' (সবগুলো না মিললে বিকল্প ফল)
    var keys = idx.keys, posts = idx.posts, nk = keys.length;
    for (var ti = 0; ti < terms.length; ti++){
      var term = terms[ti];
      best.fill(0);
      var tl = term.length, hitAny = false;
      for (var k = 0; k < nk; k++){
        var key = keys[k];
        var at = key.indexOf(term);
        if (at < 0) continue;
        hitAny = true;
        var wgt = (at === 0) ? (key.length === tl ? 4 : 3) : 1;
        var pl = posts[k];
        for (var j = 0; j < pl.length; j++){ var sx = pl[j]; if (best[sx] < wgt) best[sx] = wgt; }
      }
      if (!hitAny){                                   // কোথাও মেলেনি -> ভুল বানান ধরে কাছাকাছি শব্দ
        var fzl = fuzzyKeys(idx, term, p.mode);
        if (fzl.length){
          out.fuzzy = true;
          var fset = {};
          for (var fi = 0; fi < fzl.length; fi++){
            var fx = fzl[fi][0], fw = fzl[fi][1] <= 1 ? 2 : 1, fp = posts[fx];
            fset[keys[fx]] = 1;
            for (var fj = 0; fj < fp.length; fj++){ var fs = fp[fj]; if (best[fs] < fw) best[fs] = fw; }
          }
          if (++FZ_N > 300){ FZ = {}; FZ_N = 0; }
          FZ[term] = fset;
        }
      }
      if (terms.length > 1){ for (var sa = 0; sa < total; sa++){ if (best[sa]){ any[sa]++; anyScore[sa] += best[sa]; } } }
      if (ti === 0){
        for (var s0 = 0; s0 < total; s0++){ var b0 = best[s0]; if (b0){ cnt[s0] = 1; score[s0] = b0; touched.push(s0); } }
      } else {
        var nt = [];
        for (var u = 0; u < touched.length; u++){
          var sy = touched[u];
          if (cnt[sy] === ti && best[sy]){ cnt[sy] = ti + 1; score[sy] += best[sy]; nt.push(sy); }
        }
        touched = nt;
      }
      if (!touched.length && terms.length < 2) break;
    }
    var cands = [];
    for (var z = 0; z < touched.length; z++){ if (cnt[touched[z]] === terms.length) cands.push(touched[z]); }
    if (!cands.length && terms.length > 1){
      // সবগুলো শব্দ একসাথে কোথাও নেই: যেগুলোতে সবচেয়ে বেশি শব্দ মিলেছে সেগুলো দেখাই
      var mx = 0; for (var q1 = 0; q1 < total; q1++){ if (any[q1] > mx) mx = any[q1]; }
      if (mx >= 1){ for (var q2 = 0; q2 < total; q2++){ if (any[q2] === mx){ cands.push(q2); score[q2] = anyScore[q2]; } } out.relaxed = mx; }
    }
    out.total = cands.length;

    cands.sort(function(a, b){ return (score[b] - score[a]) || (a - b); });
    var top = cands.slice(0, 300);
    // বাক্যাংশ বোনাস: শব্দগুলো পরপর (এই ক্রমে) থাকলে আরও আগে
    if (terms.length > 1){
      var phrase = terms.join(' ');
      for (var m = 0; m < top.length; m++){
        var h = st.H[top[m]], txt = (p.mode === 'ar') ? h[1] : h[2];
        if (!txt) continue;
        var ws = txt.split(p.mode === 'ar' ? AR_SPLIT : BN_SPLIT), keyed = [];
        for (var wi = 0; wi < ws.length; wi++){ if (ws[wi]) { var lk = (p.mode === 'ar') ? looseAr(ws[wi]) : looseBn(ws[wi]); if (lk) keyed.push(lk); } }
        if ((' ' + keyed.join(' ') + ' ').indexOf(' ' + phrase) >= 0) score[top[m]] += 40;
      }
      top.sort(function(a, b){ return (score[b] - score[a]) || (a - b); });
    }
    out.items = top.slice(0, limit).map(function(sq){ return mk(st, sq, score[sq]); });
    out.ms = now() - t0;
    return out;
  }

  function mk(st, seq, score){ return { seq: seq, c: st.C[seq], h: st.H[seq], score: score }; }

  // ------------------------------------------------------------------ হাইলাইটের জন্য: লেখার কোন কোন অংশ মিলেছে
  // text-এর শব্দগুলো ঘুরে যেগুলোতে কোনো term আছে, তাদের [শুরু, শেষ) ফেরত দেয়
  function spans(text, terms, mode){
    var out = [];
    if (!text || !terms || !terms.length) return out;
    var re = (mode === 'ar') ? /[ء-يٱؐ-ًؚ-ٰٟۖ-ۭـ]+/g : /[ঀ-৿‌‍0-9A-Za-z]+/g;
    var m;
    while ((m = re.exec(text)) !== null){
      var k = (mode === 'ar') ? looseAr(m[0]) : looseBn(m[0]);
      if (!k) continue;
      for (var i = 0; i < terms.length; i++){ if (k.indexOf(terms[i]) >= 0 || (FZ[terms[i]] && FZ[terms[i]][k])){ out.push([m.index, m.index + m[0].length]); break; } }
    }
    return out;
  }

  App.FastSearch = { prepare: prepare, get: get, search: search, spans: spans, parse: parse, looseBn: looseBn, looseAr: looseAr };

})(typeof window !== 'undefined' ? (window.QuranApp = window.QuranApp || {}) : (globalThis.QuranApp = globalThis.QuranApp || {}));
