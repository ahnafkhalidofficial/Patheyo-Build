/*!
 * js/features/khatm.js — খতম পরিকল্পনা (ধাপ ৪)
 * "৩০ দিনে খতম" ইত্যাদি বাছলে: প্রতিদিন কত পৃষ্ঠা, আজ কোন পৃষ্ঠা পর্যন্ত, অগ্রগতির রিং, পিছিয়ে থাকলে কত বাকি।
 * অগ্রগতি নিজে থেকে গোনা হয়: কুরআনের যেকোনো পড়ার জায়গা (সূরা, ওয়েব পেজ, মুসহাফ) "শেষ যেখানে পড়েছিলেন" সেভ করলেই
 *   (App.saveLastRead) সেই আয়াত/পৃষ্ঠাকে মুসহাফের পৃষ্ঠা-নম্বরে (৬১০ পৃষ্ঠা, App.PAGE_DATA) বদলে নেওয়া হয়;
 *   আগের সর্বোচ্চ পৃষ্ঠার পর ধারাবাহিকভাবে (১৫ পৃষ্ঠার মধ্যে) এগোলে অগ্রগতি বাড়ে — এদিক-ওদিক খুললে নয়।
 * ছাপা মুসহাফে পড়লে "আজকের অংশ পড়েছি" চাপলেই হয়।
 * সংরক্ষণ: localStorage 'quran-khatm' = { days, start:'YYYY-MM-DD', best, log:{date:page}, done:[{days,end}] }
 * হোম ("পড়া চালিয়ে যান") window.parent থেকে এই একই জিনিস পড়ে।
 */
(function (App) {
  'use strict';
  var KEY = 'quran-khatm', SKIP = 15;
  var D = document;
  function $(id) { return D.getElementById(id); }
  function bn(n) { return App.bn ? App.bn(n) : String(n); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dkey(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseKey(k) { var a = String(k).split('-'); return new Date(+a[0], +a[1] - 1, +a[2]); }
  function total() { return (App.PAGE_DATA && App.PAGE_DATA.length) || 610; }
  function load() { try { var o = JSON.parse(localStorage.getItem(KEY) || 'null'); return o && o.days ? o : null; } catch (e) { return null; } }
  function save(o) { try { if (o) localStorage.setItem(KEY, JSON.stringify(o)); else localStorage.removeItem(KEY); } catch (e) {} syncNative(o); }
  /* ধাপ ৮: দৈনিক রিমাইন্ডার নেটিভে (reminder/ReminderAlarms.kt) — আজকের অংশ বাকি থাকলে নির্দিষ্ট সময়ে নোটিফিকেশন */
  var lastSync = '';
  function syncNative(o) {
    var br = window.AndroidWidgetBridge; if (!br || typeof br.saveKhatmReminder !== 'function') return;
    var r = o && o.remind;
    var js = JSON.stringify(o && r && r.on ? { on: true, time: r.time || '21:00', days: o.days, start: o.start, best: o.best || 0, total: total(), finished: !!o.finished } : { on: false });
    if (js === lastSync) return; lastSync = js;
    try { br.saveKhatmReminder(js); } catch (e) {}
  }

  /* আয়াত → মুসহাফ পৃষ্ঠা */
  function pageOf(sura, ayah) {
    var P = App.PAGE_DATA || [], lo = 0, hi = P.length - 1, key = sura * 1000 + ayah;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1, r = P[mid], a = r[0] * 1000 + r[1], b = r[2] * 1000 + r[3];
      if (key < a) hi = mid - 1; else if (key > b) lo = mid + 1; else return mid + 1;
    }
    return Math.max(1, Math.min(P.length, lo + 1));
  }
  App.pageOfAyah = pageOf;

  /* আজকের হিসাব */
  function calc(o, now) {
    now = now || new Date();
    var T = total(), day = Math.floor((parseKey(dkey(now)) - parseKey(o.start)) / 86400000);
    day = Math.max(0, day);
    var perDay = T / o.days;
    var target = Math.min(T, Math.ceil(perDay * (day + 1)));
    var best = Math.min(T, o.best || 0);
    var prevTarget = Math.min(T, Math.ceil(perDay * day));
    return { T: T, day: day, perDay: Math.ceil(perDay), target: target, best: best, left: Math.max(0, target - best),
      behind: Math.max(0, prevTarget - best), pct: Math.round(best / T * 100), over: day >= o.days, done: best >= T,
      from: Math.min(T, best + 1) };
  }
  try { syncNative(load()); } catch (e) {}   /* পেজ খুললেই নেটিভ পরিকল্পনা হালনাগাদ (অগ্রগতি সহ) */
  App.khatmState = function () { var o = load(); return o ? Object.assign({ plan: o }, calc(o)) : null; };

  /* পড়ার জায়গা সেভ হলেই অগ্রগতি */
  function track(data) {
    var o = load(); if (!o || !data) return;
    var p = 0;
    if (data.pageNum) p = +data.pageNum;
    else if (data.type === 'sura' && data.idx) p = pageOf(+data.idx, +data.ayahIndex || 1);
    if (!p) return;
    var best = o.best || 0;
    if (p > best && p <= best + SKIP) {
      o.best = p; o.log = o.log || {}; o.log[dkey(new Date())] = p;
      var c = calc(o);
      if (c.done && !o.finished) { o.finished = dkey(new Date()); }
      save(o); paint();
      if (c.done && window.PT) PT.toast('খতম সম্পন্ন — আলহামদুলিল্লাহ!', { type: 'success', ms: 4000 });
    }
  }
  function trackSaved() { try { track(JSON.parse(localStorage.getItem('quran-last-read') || 'null')); } catch (e) {} }
  ['saveLastRead', 'updateLastReadSura', 'updateLastReadWeb', 'updateLastReadMushaf'].forEach(function (fn) {
    var orig = App[fn]; if (typeof orig !== 'function') return;
    App[fn] = function () { var r = orig.apply(this, arguments); trackSaved(); return r; };
  });

  /* ---------- কার্ড ---------- */
  var RING = 2 * Math.PI * 26;
  function paint() {
    var card = $('khatm-card'); if (!card) return;
    var show = App.state && App.state.view === 'list' && App.state.mode !== 'tarjama' && App.state.tab !== 'bookmarks';
    card.classList.toggle('hidden', !show);
    if (!show) return;
    var o = load();
    if (!o) {
      card.setAttribute('data-state', 'empty');
      card.innerHTML =
        '<span class="kh-medal pt-medal"><i data-ic="target"></i></span>' +
        '<div class="kh-txt"><b>খতমের পরিকল্পনা করুন</b><span>৩০ দিনে খতম মানে দিনে মাত্র ২১ পৃষ্ঠা — অ্যাপ নিজেই হিসাব রাখবে</span></div>' +
        '<button type="button" class="pt-btn pt-btn--sm kh-go" data-kh="setup">শুরু করুন</button>';
    } else {
      var c = calc(o);
      var status = c.done ? 'খতম সম্পন্ন — আলহামদুলিল্লাহ'
        : c.left === 0 ? 'আজকের অংশ শেষ — মাশাআল্লাহ'
        : (c.behind > 0 ? 'আজ বাকি ' + bn(c.left) + ' পৃষ্ঠা · ' + bn(c.behind) + ' পৃষ্ঠা পিছিয়ে' : 'আজ বাকি ' + bn(c.left) + ' পৃষ্ঠা');
      var range = c.done ? 'নতুন করে আবার শুরু করতে পারেন' : (c.left ? 'পৃষ্ঠা ' + bn(c.from) + ' থেকে ' + bn(c.target) + ' (পারা ' + bn(App.paraForPage(c.from)) + ')' : 'আগামীকাল পৃষ্ঠা ' + bn(Math.min(c.T, c.best + 1)) + ' থেকে');
      card.setAttribute('data-state', c.done ? 'done' : c.left === 0 ? 'ok' : c.behind > 0 ? 'behind' : 'on');
      card.innerHTML =
        '<div class="kh-ring" role="img" aria-label="খতমের ' + bn(c.pct) + '% সম্পন্ন">' +
          '<svg viewBox="0 0 60 60"><circle class="kh-tr" cx="30" cy="30" r="26"/><circle class="kh-fl" cx="30" cy="30" r="26" stroke-dasharray="' + (RING * c.pct / 100).toFixed(1) + ' ' + RING.toFixed(1) + '"/></svg>' +
          '<b>' + bn(c.pct) + '<small>%</small></b></div>' +
        '<div class="kh-txt"><span class="kh-k">' + bn(o.days) + ' দিনে খতম · দিন ' + bn(Math.min(o.days, c.day + 1)) + '/' + bn(o.days) + '</span>' +
          '<b>' + status + '</b><span>' + range + '</span></div>' +
        '<div class="kh-act">' +
          (c.done ? '<button type="button" class="pt-btn pt-btn--sm" data-kh="setup">আবার শুরু</button>'
            : (c.left ? '<button type="button" class="pt-btn pt-btn--sm kh-go" data-kh="read">পড়ুন</button>' : '')) +
          '<button type="button" class="kh-more" data-kh="menu" aria-label="খতমের অপশন"><i data-ic="more-v"></i></button></div>';
    }
    if (window.PT && PT.hydrateIcons) PT.hydrateIcons(card);
  }
  App.paintKhatm = paint;
  var origCont = App.showContinueCard;
  if (origCont) App.showContinueCard = function () { origCont.apply(this, arguments); try { paint(); } catch (e) {} };

  /* ---------- পড়ার পদ্ধতি: আসল মুসহাফ / ওয়েব পেজ ----------
   * "পড়ুন" বা "শুরু করুন" চাপলে প্রতিবার দুটি অপশন আসে। নিচের টিক দিলে সেই পছন্দ 'quran-khatm-mode'-এ সেভ হয়,
   * পরের বার আর জিজ্ঞেস না করে সরাসরি সেটাতেই খোলে। খতমের মেনু থেকে পছন্দ মুছে আবার জিজ্ঞেসের অবস্থায় ফেরা যায়। */
  var MODE_KEY = 'quran-khatm-mode';
  function getMode() { try { var m = localStorage.getItem(MODE_KEY); return m === 'mushaf' || m === 'web' ? m : ''; } catch (e) { return ''; } }
  function setMode(m) { try { if (m) localStorage.setItem(MODE_KEY, m); else localStorage.removeItem(MODE_KEY); } catch (e) {} }

  function openIn(mode, page) {
    var para = App.paraForPage(page);
    if (mode === 'mushaf') {
      App.openParaPages(para);
      App.showPreviewPage(page);
      App.openFullscreenPage(page);
    } else {
      App.openParaWebPage(para);
      if (page <= App.PARA_PAGE_RANGE[para - 1][0]) return;   /* পারার প্রথম পৃষ্ঠা — স্ক্রল ছাড়াই ওপরে থাকুক, হেডার/ব্যাক বাটন দেখা যাবে */
      var go = function () { try { App.scrollToWebPage(page); } catch (e) {} };
      setTimeout(go, 120);
      if (D.fonts && D.fonts.status === 'loading') D.fonts.ready.then(function () { setTimeout(go, 60); });
    }
  }
  function choiceEl() { return $('kh-choice-overlay'); }
  function closeChoice() { var el = choiceEl(); if (el) el.classList.add('hidden'); }
  function askMode(page) {
    var el = choiceEl(); if (!el) { openIn('web', page); return; }
    if (D.activeElement && D.activeElement.blur) D.activeElement.blur();
    $('kh-choice-title').textContent = 'পৃষ্ঠা ' + bn(page) + ' থেকে — কীভাবে পড়তে চান?';
    $('kh-choice-keep').checked = false;
    el.setAttribute('data-page', page);
    el.classList.remove('hidden');
  }
  function pick(mode) {
    var el = choiceEl(), page = +el.getAttribute('data-page') || 1;
    if ($('kh-choice-keep').checked) setMode(mode);
    closeChoice();
    openIn(mode, page);
  }
  /* পড়া শুরু: পছন্দ সেভ থাকলে সরাসরি, না থাকলে জিজ্ঞেস */
  function openAt(page) {
    var m = getMode();
    if (m) openIn(m, page); else askMode(page);
  }
  (function bindChoice() {
    var el = choiceEl(); if (!el) return;
    $('kh-choice-mushaf').addEventListener('click', function () { pick('mushaf'); });
    $('kh-choice-web').addEventListener('click', function () { pick('web'); });
    $('kh-choice-cancel').addEventListener('click', closeChoice);
    el.addEventListener('click', function (e) { if (e.target === el) closeChoice(); });
  })();

  /* ---------- পরিকল্পনার পপআপ ---------- */
  var PLANS = [[7, 'এক সপ্তাহে'], [15, 'পনেরো দিনে'], [30, 'এক মাসে', 'প্রতিদিন প্রায় এক পারা — রমজানের জন্য আদর্শ'], [40, 'চল্লিশ দিনে'], [60, 'দুই মাসে'], [90, 'তিন মাসে']];
  function openSetup() {
    var m = $('khatm-modal'), list = $('kh-plans'), o = load(), cur = o ? o.days : 30;
    list.innerHTML = PLANS.map(function (p) {
      var per = Math.ceil(total() / p[0]);
      return '<button class="pt-option" type="button" role="radio" aria-checked="' + (p[0] === cur ? 'true' : 'false') + '" data-days="' + p[0] + '"><span class="pt-option__radio"></span>' +
        '<div class="pt-grow"><div class="pt-row__title">' + bn(p[0]) + ' দিনে · ' + p[1] + '</div><div class="pt-row__sub">' + (p[2] || ('দিনে ' + bn(per) + ' পৃষ্ঠা')) + '</div></div>' +
        '<span class="kh-per">' + bn(per) + '<small>পৃ./দিন</small></span></button>';
    }).join('');
    var lr = null; try { lr = JSON.parse(localStorage.getItem('quran-last-read') || 'null'); } catch (e) {}
    var here = lr ? (lr.pageNum ? +lr.pageNum : (lr.type === 'sura' ? pageOf(+lr.idx, +lr.ayahIndex || 1) : 0)) : 0;
    $('kh-from').hidden = !(here > 1);
    $('kh-from-here').textContent = here > 1 ? 'যেখানে পড়ছেন সেখান থেকে (পৃষ্ঠা ' + bn(here) + ')' : '';
    $('kh-from-here').setAttribute('data-page', here);
    m.querySelectorAll('[data-from]').forEach(function (b) { b.setAttribute('aria-checked', b.getAttribute('data-from') === 'start' ? 'true' : 'false'); });
    $('kh-stop').hidden = !o;
    var r = (o && o.remind) || { on: !o, time: '21:00' };   /* নতুন পরিকল্পনায় রিমাইন্ডার চালু থাকে; পুরনোতে আগের মতো */
    $('kh-rem-on').checked = !!r.on; $('kh-rem-time').value = r.time || '21:00';
    PT.sheet.open(m);
  }
  function start() {
    var m = $('khatm-modal'), sel = m.querySelector('[data-days][aria-checked="true"]');
    var days = sel ? +sel.getAttribute('data-days') : 30;
    var fromHere = m.querySelector('[data-from="here"][aria-checked="true"]');
    var startPage = fromHere ? Math.max(0, (+$('kh-from-here').getAttribute('data-page') || 1) - 1) : 0;
    var old = load();
    var o = { days: days, start: dkey(new Date()), best: startPage, log: {}, done: (old && old.done) || [],
      remind: { on: !!$('kh-rem-on').checked, time: $('kh-rem-time').value || '21:00' } };
    if (old && old.finished) o.done.push({ days: old.days, end: old.finished });
    save(o); PT.sheet.close(m); paint();
    PT.toast(bn(days) + ' দিনের খতম শুরু হলো — বিসমিল্লাহ', { type: 'success' });
    setTimeout(function () { var c = calc(o); if (!c.done) openAt(c.from); }, 350);   /* শুরু করুন চাপার পরই পড়ার পদ্ধতির দুটি অপশন */
  }
  function markToday() {
    var o = load(); if (!o) return; var c = calc(o);
    o.best = Math.max(o.best || 0, c.target); o.log = o.log || {}; o.log[dkey(new Date())] = o.best;
    if (o.best >= c.T && !o.finished) o.finished = dkey(new Date());
    save(o); paint(); PT.toast('আজকের অংশ পড়া হয়েছে — মাশাআল্লাহ', { type: 'success' });
  }

  D.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-kh]'); if (!b) return;
    var a = b.getAttribute('data-kh'), o = load();
    if (a === 'setup') openSetup();
    else if (a === 'read' && o) openAt(calc(o).from);
    else if (a === 'menu' && o && window.PT) {
      var c = calc(o);
      PT.menu(b, [
        !c.done && c.left ? { icon: 'check-circle', label: 'আজকের অংশ পড়েছি (ছাপা মুসহাফে)', onClick: markToday } : null,
        { icon: 'edit', label: 'পরিকল্পনা বদলান', onClick: openSetup },
        getMode() ? { icon: 'book', label: 'পড়ার পদ্ধতি বদলান (এখন: ' + (getMode() === 'mushaf' ? 'আসল মুসহাফ' : 'ওয়েব পেজ') + ')', onClick: function () { setMode(''); PT.toast('এবার থেকে প্রতিবার জিজ্ঞেস করা হবে', { icon: 'undo' }); } } : null,
        '-',
        { icon: 'trash', label: 'খতম বাদ দিন', onClick: function () {
          PT.dialog({ title: 'খতমের পরিকল্পনা বাদ দেবেন?', body: 'এ পর্যন্ত ' + bn(c.best) + ' পৃষ্ঠার অগ্রগতি মুছে যাবে।', ok: 'বাদ দিন', danger: true, icon: 'trash' })
            .then(function (ok) { if (ok) { save(null); paint(); } });
        } }
      ].filter(Boolean));
    }
  });
  (function bindModal() {
    var m = $('khatm-modal'); if (!m) return;
    m.addEventListener('click', function (e) {
      var d = e.target.closest('[data-days]'), f = e.target.closest('[data-from]');
      if (d) m.querySelectorAll('[data-days]').forEach(function (x) { x.setAttribute('aria-checked', x === d ? 'true' : 'false'); });
      if (f) m.querySelectorAll('[data-from]').forEach(function (x) { x.setAttribute('aria-checked', x === f ? 'true' : 'false'); });
      if (e.target.closest('[data-kh-start]')) start();
      if (e.target.closest('[data-kh-close]')) PT.sheet.close(m);
      if (e.target.closest('#kh-stop')) { PT.sheet.close(m); save(null); paint(); PT.toast('খতমের পরিকল্পনা বাদ দেওয়া হলো', { icon: 'undo' }); }
    });
  })();

  /* Android ব্যাক: আগে এই পেজের পপআপগুলো বন্ধ (হোম 06-native-bridge.js জিজ্ঞেস করে) */
  window.__ptFrameBack = function () {
    try { if (window.PT && PT.handleBack && PT.handleBack()) return true; } catch (e) {}
    var vis = function (id) { var el = $(id); return el && !el.classList.contains('hidden'); };
    if (vis('bm-delete-overlay')) { $('bm-delete-cancel-btn').click(); return true; }
    if (vis('bm-modal-overlay')) { $('bm-cancel-btn').click(); return true; }
    if (vis('para-choice-overlay')) { $('choice-cancel-btn').click(); return true; }
    if (vis('kh-choice-overlay')) { closeChoice(); return true; }
    return false;
  };

  /* মোড/ট্যাব বদলালে কার্ড দেখানো/লুকানো */
  D.addEventListener('click', function (e) { setTimeout(paint, 0); setTimeout(paint, 160); });
  window.addEventListener('popstate', function () { setTimeout(paint, 30); });
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', paint); else setTimeout(paint, 0);
})(window.QuranApp = window.QuranApp || {});
