
/*!
 * js/services/pdf-service.js -- PDF loading (downloaded file in app storage -> embedded base64 -> XHR -> IndexedDB cache -> manual pick) and page rendering to <canvas>
 *
 * Provides : App.clearCanvas, App.ensurePdfLoaded, App.loadPdfFromBuffer, App.loadPdfFromPickedFile, App.renderPageToCanvas
 * Needs    : services/pdf-download (optional -- the Android app's downloaded copy of the Mushaf PDF)
 */
(function (App) {
  "use strict";

  // ---- PDF.js loading and page rendering ("Hafezi-Quran.pdf" placed next to this HTML file) ----
  // We read the sibling PDF's bytes ourselves via XMLHttpRequest (responseType "arraybuffer")
  // instead of handing pdf.js a bare { url: ... } to fetch internally. pdf.js's own url-loader
  // prefers window.fetch() when it is available, and Chromium's fetch() implementation refuses
  // the file:// scheme outright (it always rejects with "Failed to fetch") -- this is exactly
  // the engine Android's WebView uses to render a packaged app's local index.html, which is why
  // the PDF loaded fine the first time in a normal desktop/mobile browser (some of those either
  // support fetch() for file:// or fall back to XHR) but silently failed to display inside the
  // built Android app. Plain XHR has always been allowed to read local file:// resources (it's
  // the same mechanism browsers have used for local development for years) and Android WebView
  // allows it too by default, so loading bytes this way works identically everywhere: opened
  // directly by double-clicking, served over http(s), or bundled next to index.html inside an
  // Android app. Note that a successful file:// XHR reports status 0 (there is no HTTP layer),
  // so we must treat status 0 as success too -- checking only for status 200 is a common trap
  // that makes this kind of loader appear to fail specifically under file://.
  //
  // We still cache the bytes in IndexedDB and keep the manual "pick the PDF" file input as a
  // last-resort fallback, in case some unusual embedding disables local file reads entirely.
  var PDF_URL = 'Hafezi-Quran.pdf';

  var PDF_DB_NAME = 'quran-pdf-cache';

  var PDF_STORE = 'files';

  var pdfDoc = null;

  var pdfLoadPromise = null;

  function waitForPdfjs(){
    if (window.__loadPdfjs) window.__loadPdfjs();      // PDF.js is injected lazily (see index.html)
    if (window.__pdfjsReady) return Promise.resolve();  // library AND its worker are set up (pdfjs-bootstrap.js)
    return new Promise(function(resolve){
      if (window.__pdfjsReady){ resolve(); return; }
      window.addEventListener('pdfjs-ready', function once(){
        window.removeEventListener('pdfjs-ready', once);
        resolve();
      });
    });
  }

  function openPdfCacheDb(){
    return new Promise(function(resolve, reject){
      if (!window.indexedDB){ reject(new Error('no indexedDB')); return; }
      var req = indexedDB.open(PDF_DB_NAME, 1);
      req.onupgradeneeded = function(){ req.result.createObjectStore(PDF_STORE); };
      req.onsuccess = function(){ resolve(req.result); };
      req.onerror = function(){ reject(req.error); };
    });
  }

  function cachePdfBytes(buf){
    return openPdfCacheDb().then(function(db){
      return new Promise(function(resolve, reject){
        var tx = db.transaction(PDF_STORE, 'readwrite');
        tx.objectStore(PDF_STORE).put(buf, 'pdf');
        tx.oncomplete = function(){ resolve(); };
        tx.onerror = function(){ reject(tx.error); };
      });
    }).catch(function(){ /* caching is best-effort */ });
  }

  function getCachedPdfBytes(){
    return openPdfCacheDb().then(function(db){
      return new Promise(function(resolve, reject){
        var tx = db.transaction(PDF_STORE, 'readonly');
        var req = tx.objectStore(PDF_STORE).get('pdf');
        req.onsuccess = function(){ resolve(req.result || null); };
        req.onerror = function(){ reject(req.error); };
      });
    });
  }

  function fetchPdfBytesViaXhr(url){
    return new Promise(function(resolve, reject){
      try {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.responseType = 'arraybuffer';
        xhr.onload = function(){
          // status is 0 for successful file:// requests (no HTTP layer involved), so accept
          // 0 and 200-299 as success; anything else (e.g. a real 404 from an http server) fails.
          var ok = xhr.status === 0 || (xhr.status >= 200 && xhr.status < 300);
          if (ok && xhr.response && xhr.response.byteLength > 0){
            resolve(xhr.response);
          } else {
            reject(new Error('pdf-xhr-status-' + xhr.status));
          }
        };
        xhr.onerror = function(){ reject(new Error('pdf-xhr-network-error')); };
        xhr.send();
      } catch(e){
        reject(e);
      }
    });
  }

  function base64ToUint8Array(b64){
    var binary = atob(b64);
    var len = binary.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function ensurePdfLoaded(){
    if (pdfDoc) return Promise.resolve(pdfDoc);
    if (pdfLoadPromise) return pdfLoadPromise;
    pdfLoadPromise = waitForPdfjs().then(function(){
      // Android অ্যাপ: ডাউনলোড করা PDF অ্যাপের স্টোরেজে থাকে (Kotlin ব্রিজ) — সেখান থেকে পড়া হয়; ব্রাউজার/টেস্টে IndexedDB থেকে
      var dl = App.pdfDownload;
      var isNative = !!(dl && dl.hasNative && dl.hasNative());
      var bytesP = isNative
        ? (dl.isReady() ? dl.readNativeBytes() : Promise.reject(new Error('pdf-not-available')))
        : getCachedPdfBytes().then(function(cached){
            if (!cached) throw new Error('pdf-not-available');
            return new Uint8Array(cached);
          });
      return bytesP.then(function(bytes){
        return window.pdfjsLib.getDocument({ data: bytes }).promise;
      }).catch(function(err){
        if (err && (err.name === 'InvalidPDFException' || err.name === 'MissingPDFException')){
          if (isNative) dl.discardNative(); else deleteCachedPdf();
        }
        throw err;
      });
    }).then(function(doc){
      pdfDoc = doc;
      return doc;
    }).catch(function(err){
      pdfLoadPromise = null;
      throw err;
    });
    return pdfLoadPromise;
  }
  function deleteCachedPdf(){
    openPdfCacheDb().then(function(db){
      var tx = db.transaction(PDF_STORE, 'readwrite'); tx.objectStore(PDF_STORE).delete('pdf');
    }).catch(function(){});
  }
  App.ensurePdfLoaded = ensurePdfLoaded;

  function loadPdfFromBuffer(buf){
    // PDF.js transfers this buffer to its worker (detaching it) once passed to getDocument,
    // so keep an independent copy first for caching.
    var cacheCopy = buf.slice(0);
    return waitForPdfjs().then(function(){
      return window.pdfjsLib.getDocument({ data: new Uint8Array(buf) }).promise;
    }).then(function(doc){
      pdfDoc = doc;
      pdfLoadPromise = Promise.resolve(doc);
      cachePdfBytes(cacheCopy);
      return doc;
    });
  }
  App.loadPdfFromBuffer = loadPdfFromBuffer;

  function loadPdfFromPickedFile(file){
    return file.arrayBuffer().then(loadPdfFromBuffer);
  }
  App.loadPdfFromPickedFile = loadPdfFromPickedFile;

  function renderPageToCanvas(n, canvasEl, targetWidthPx, postFn){
    if (canvasEl.__renderTask){ try{ canvasEl.__renderTask.cancel(); }catch(e){} }
    // v289: দ্রুত সোয়াইপে পুরনো রিকোয়েস্ট যেন নতুনটার উপর আঁকতে না পারে — প্রতি ক্যানভাসে একটি টোকেন
    var rid = canvasEl.__rid = (canvasEl.__rid || 0) + 1;
    return ensurePdfLoaded().then(function(doc){
      if (canvasEl.__rid !== rid) return null;
      return doc.getPage(n);
    }).then(function(page){
      if (!page || canvasEl.__rid !== rid) return;
      var native = page.getViewport({ scale: 1 });
      var scale = targetWidthPx / native.width;
      var viewport = page.getViewport({ scale: scale });
      canvasEl.width = viewport.width;
      canvasEl.height = viewport.height;
      var ctx = canvasEl.getContext('2d');
      var task = page.render({ canvasContext: ctx, viewport: viewport });
      canvasEl.__renderTask = task;
      return task.promise.then(function(){
        canvasEl.__renderTask = null;
        // v289: লাইট/ডার্ক/সেপিয়া রঙ সরাসরি পিক্সেলে বসে যায় (CSS filter নয়) — তাই জুম/সোয়াইপে GPU-র উপর বাড়তি চাপ নেই
        if (typeof postFn === 'function'){ try{ postFn(ctx, canvasEl.width, canvasEl.height); }catch(e){} }
      }, function(err){
        canvasEl.__renderTask = null;
        if (err && err.name === 'RenderingCancelledException') return;
        throw err;
      });
    });
  }
  App.renderPageToCanvas = renderPageToCanvas;

  function clearCanvas(c){
    if (c.__renderTask){ try{ c.__renderTask.cancel(); }catch(e){} c.__renderTask = null; }
    c.width = 0; c.height = 0;
  }
  App.clearCanvas = clearCanvas;

})(window.QuranApp = window.QuranApp || {});

