
/* ===== js/features/events.js ===== */
/*!
 * js/features/events.js -- Wires up every DOM event listener
 *
 * Provides : App.bindEvents
 * Needs    : core/dom, core/state, features/bookmark-fab, features/bookmark-modal, features/feedback,
 *            features/last-read, features/navigation, features/book-view, features/chapter-reader,
 *            features/search, features/download-ui, features/theme
 */
(function (App) {
  "use strict";

  function bindEvents(){
    App.els.tabs.forEach(function(btn){
      btn.addEventListener('click', function(){
        var tab = btn.getAttribute('data-tab');
        if (App.state.view !== 'list') App.resetToList(tab); else App.switchTab(tab);
      });
    });
        var hsHdr = document.getElementById('hs-hdr');      /* হেডারের সার্চ বাটন: ভাসমান সার্চ বাটনের কাজটাই করে */
    if (hsHdr) hsHdr.addEventListener('click', function(){ var f = document.getElementById('hs-fab'); if (f) f.click(); });
    App.els.themeBtns.forEach(function(btn){
      btn.addEventListener('click', function(){
        var n = btn.getAttribute('data-theme-btn');
        if (n === 'toggle'){ var cur = document.documentElement.getAttribute('data-theme'); n = cur === 'light' ? 'dark' : (cur === 'dark' ? 'sepia' : 'light'); }   /* এক বাটনে তিন ক্লিকে তিন মোড: লাইট -> ডার্ক -> আই-কেয়ার (সেপিয়া) -> লাইট */
        App.setTheme(n);
      });
    });
    App.els.bookBackBtn.addEventListener('click', App.goBackOneLevel);
    App.els.chapterBackBtn.addEventListener('click', App.goBackOneLevel);
    App.bindDownloadUi();

    // ---- শেয়ার কার্ড: হাদিসের ছবি বানিয়ে WhatsApp/Facebook-এ শেয়ার (shared/share-card.js) ----
    App.els.chapterItems.addEventListener('click', function(e){
      var sb = e.target.closest ? e.target.closest('[data-pt-share]') : null;
      if (!sb || !window.PtShareCard) return;
      var card = sb.closest('.hd-card'); if (!card) return;
      var num = parseInt(card.getAttribute('data-num'), 10);
      var arEl = card.querySelector('.hd-ar'), bnEl = card.querySelector('.hd-bn');
      var book = App.bookById(App.curBookId) || {}, meta = App.currentChapterMeta() || {};
      window.PtShareCard.open({
        kind: 'hadith',
        title: meta.ct || '',
        ar: arEl ? arEl.textContent.trim() : '',
        bn: bnEl ? bnEl.textContent.trim() : '',
        ref: (book.nameBn || 'হাদিস') + ' · হাদিস ' + App.bn(num)
      });
    });

    // ---- bookmark icon on a hadith card: add (with note) / remove (with undo) ----
    App.els.chapterItems.addEventListener('click', function(e){
      var btn = e.target.closest ? e.target.closest('.hd-bm') : null;
      if (!btn) return;
      var card = btn.closest('.hd-card');
      if (!card) return;
      var seq = parseInt(card.getAttribute('data-seq'), 10);
      var num = parseInt(card.getAttribute('data-num'), 10);
      var existing = App.findBookmark(App.curBookId, seq);
      if (existing){ App.removeBookmarkWithUndo(existing.id); return; }
      var meta = App.currentChapterMeta() || { c: 0, ct: '' };
      App.openBookmarkModal({ book: App.curBookId, seq: seq, num: num, ch: meta.c, ct: meta.ct });
    });

    App.els.bmCancelBtn.addEventListener('click', App.closeBookmarkModal);
    App.els.bmModalOverlay.addEventListener('click', function(e){
      if (e.target === App.els.bmModalOverlay) App.closeBookmarkModal();
    });
    App.els.bmSaveBtn.addEventListener('click', App.saveBookmarkFromModal);
    App.els.bmNoteInput.addEventListener('keydown', function(e){
      if (e.key === 'Enter'){ e.preventDefault(); App.saveBookmarkFromModal(); }
    });

    // ---- remove a downloaded book from the phone ----
    App.els.bookRemoveBtn.addEventListener('click', function(){
      var b = App.bookById(App.curBookId);
      if (!b) return;
      App.els.bookRemoveContext.innerHTML = '<strong style="color:var(--text)">' + App.escapeHtml(b.nameBn) + '</strong><br>ফোন থেকে মুছে ফেললেও বুকমার্ক থাকবে; আবার ডাউনলোড করে পড়তে পারবেন।';
      App.els.bookRemoveOverlay.classList.remove('hidden');
    });
    function closeRemove(){ App.els.bookRemoveOverlay.classList.add('hidden'); }
    App.els.bookRemoveCancelBtn.addEventListener('click', closeRemove);
    App.els.bookRemoveOverlay.addEventListener('click', function(e){ if (e.target === App.els.bookRemoveOverlay) closeRemove(); });
    App.els.bookRemoveConfirmBtn.addEventListener('click', function(){
      var id = App.curBookId; closeRemove();
      if (!id) return;
      if (App.loadedBook && App.loadedBook.id === id) App.loadedBook = null;
      App.bookDl.remove(id);
      App.showSnackbar('কিতাবটি ফোন থেকে মুছে ফেলা হয়েছে');
      App.els.chapterList.innerHTML = '';
      App.enterBook(id);     // shows the download card again
    });

    if (window.visualViewport){
      window.visualViewport.addEventListener('resize', function(){
        if (!App.els.bmModalOverlay.classList.contains('hidden')) App.syncModalToViewport();
      });
      window.visualViewport.addEventListener('scroll', function(){
        if (!App.els.bmModalOverlay.classList.contains('hidden')) App.syncModalToViewport();
      });
    }

    window.addEventListener('popstate', App.onPopState);

    // ---- search box (header) ----
    var searchTimer = null;
    App.els.searchInput.addEventListener('input', function(){
      var v = App.els.searchInput.value;
      if (App.state.view === 'book'){
        clearTimeout(searchTimer);
        searchTimer = setTimeout(function(){ App.runBookSearch(v); }, 220);
        App.els.searchClear.classList.toggle('show', !!v.trim());
      } else {
        App.filterBooks(v);
      }
    });
    App.els.searchClear.addEventListener('click', function(){
      App.els.searchInput.value = '';
      if (App.state.view === 'book') App.runBookSearch(''); else App.filterBooks('');
      App.els.searchInput.focus();
    });

    // Keep the chapter filled ahead of the reader, remember the last-read hadith, and recompute the
    // bookmark button's synced/drifted colour as the reader scrolls.
    var ticking = false;
    window.addEventListener('scroll', function(){
      if (App.state.view !== 'chapter') return;
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function(){
        App.maybeFillChapter();
        App.updateLastReadChapter();
        if (App.activeBookmarkId) App.updateBmFabIcon();
        ticking = false;
      });
    }, { passive: true });
  }
  App.bindEvents = bindEvents;

})(window.HadithApp = window.HadithApp || {});

