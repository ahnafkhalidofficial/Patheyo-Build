/* js/ui/extras.js — ধাপ ৩ (রিডিজাইন)-এর নতুন অংশ
   ১) সময়ের উৎস চিহ্ন (লাইভ / ফোনেই হিসাব / সংরক্ষিত)
   ২) রমজান মোড: সেহরি শেষ ও ইফতারের কাউন্টডাউন (হিজরি মাস রমজান হলে নিজে থেকেই দেখায়)
   ৩) আদায়-চিহ্ন: ওয়াক্তের ✓ → আমলের রিপোর্ট (amol_report_state; হোমের __ptPrayed দিয়ে, যাতে সব জায়গায় এক হিসাব)
   ৪) হিসাবের নিয়ম: পদ্ধতি (userPrayerMethodId), মাযহাব
   ৫) হিজরি ক্যালেন্ডার: চলতি মাস + আসন্ন বিশেষ দিন */

/* ---------- ছোট সহায়ক ---------- */
function nzSegSync() { /* দুই-ঘরের সেগমেন্টের চলমান অংশ CSS-এই (data-v / data-mode) */ }
function nzScrollTo(id) { const el = document.getElementById(id); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
function nzPad(n) { return (n < 10 ? '0' : '') + n; }
function nzDkey(d) { return d.getFullYear() + '-' + nzPad(d.getMonth() + 1) + '-' + nzPad(d.getDate()); }
function nzAddDays(d, n) { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); return x; }
function nzEsc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

/* ---------- ১) উৎস ---------- */
const NZ_SRC = { live: 'লাইভ', offline: 'ফোনেই হিসাব', cache: 'সংরক্ষিত', ifbd: 'ইসলামিক ফাউন্ডেশন' };
function nzAfterData() {
    const src = document.getElementById('nz-src');
    if (src && src.dataset.src !== nzSource) { src.dataset.src = nzSource; document.getElementById('nz-src-label').textContent = NZ_SRC[nzSource] || ''; }
    nzPaintMethod();
}

/* ---------- ২) রমজান মোড ---------- */
function nzRamadan(S) {
    const box = document.getElementById('nz-ramadan'); if (!box) return;
    if (!isRamadanNow) { if (!box.hidden) box.hidden = true; return; }
    if (box.hidden) box.hidden = false;
    const now = S.now, fajr = S.tm['Fajr'], mag = S.tm['Maghrib'];
    let target, label, which;
    if (now < fajr) { target = fajr; label = 'সেহরি শেষ হতে বাকি'; which = 'sehri'; }
    else if (now < mag) { target = mag; label = 'ইফতারের বাকি'; which = 'iftar'; }
    else { target = new Date(fajr.getTime() + 86400000); label = 'আগামী সেহরি শেষ হতে বাকি'; which = 'sehri'; }
    nzSet('nz-ram-label', label);
    nzSet('nz-ram-cd', pcFixed(nzHms(target - now)));
    nzSet('nz-ram-sehri', `<span>সেহরি শেষ</span><b>${nzT(globalTimings.Fajr)}</b>`);
    nzSet('nz-ram-iftar', `<span>ইফতার</span><b>${nzT(globalTimings.Maghrib)}</b>`);
    box.dataset.next = which;
    let day = '';
    try { const h = getDisplayHijriDate(now, false, true); if (h.month === 8) day = 'রমজান ' + pcBn(h.day); } catch (e) {}
    nzSet('nz-ram-day', day);
}

/* ---------- ৩) আদায়-চিহ্ন ---------- */
const NZ_AMOL_ID = { Fajr: 'fajr', Dhuhr: 'midday', Asr: 'asr', Maghrib: 'maghrib', Isha: 'isha' };
function nzPrayedApi() { try { if (window.parent && window.parent !== window && window.parent.__ptPrayed) return window.parent.__ptPrayed; } catch (e) {} return null; }
function nzAmolLocal() { try { const o = JSON.parse(localStorage.getItem('amol_report_state') || 'null'); if (o && typeof o === 'object') { o.days = o.days || {}; return o; } } catch (e) {} return { days: {} }; }
function nzPrayedKey(id, now, tm) {
    const d = (id === 'Isha' && tm && now < tm['Fajr']) ? new Date(now.getTime() - 86400000) : now;   /* রাতে ফজরের আগে: গতকালের এশা */
    return nzDkey(d);
}
function nzPrayedGet(id, now, tm) {
    const k = nzPrayedKey(id, now, tm), api = nzPrayedApi();
    if (api) { try { return api.get(k, NZ_AMOL_ID[id]) || ''; } catch (e) {} }
    const r = nzAmolLocal().days[k]; return r ? r[NZ_AMOL_ID[id]] || '' : '';
}
function nzPrayedSet(id, v, now, tm) {
    const k = nzPrayedKey(id, now, tm), api = nzPrayedApi();
    if (api) { try { api.set(k, NZ_AMOL_ID[id], v); return; } catch (e) {} }
    const st = nzAmolLocal(); if (!st.days[k]) st.days[k] = {};
    if (v) st.days[k][NZ_AMOL_ID[id]] = v; else delete st.days[k][NZ_AMOL_ID[id]];
    if (typeof st.soundOn !== 'boolean') st.soundOn = true;
    try { localStorage.setItem('amol_report_state', JSON.stringify(st)); } catch (e) {}
}
let nzPrayedCache = { t: 0, v: null };
function nzPrayedMap(now, tm) {
    if (nzPrayedCache.v && Date.now() - nzPrayedCache.t < 1500) return nzPrayedCache.v;
    const m = {}; Object.keys(NZ_AMOL_ID).forEach(id => { const v = nzPrayedGet(id, now, tm); if (v) m[id] = v; });
    nzPrayedCache = { t: Date.now(), v: m };
    return m;
}
let nzPrayedFor = '';
function nzPrayedOpen(id) {
    const S = nzLastState; if (!S) return;
    const m = document.getElementById('nz-prayed-modal'), nm = waqtBnName(id, S.now);
    const k = nzPrayedKey(id, S.now, S.tm), v = nzPrayedGet(id, S.now, S.tm);
    nzPrayedFor = id;
    document.getElementById('nz-prayed-title').textContent = nm;
    document.getElementById('nz-prayed-sub').textContent = (k === nzDkey(S.now) ? 'আজকের ' : 'গতকালের ') + nm + ' কীভাবে আদায় করেছেন?';
    m.querySelectorAll('.pt-option').forEach(o => o.setAttribute('aria-checked', o.getAttribute('data-v') === v ? 'true' : 'false'));
    document.getElementById('nz-prayed-clear').hidden = !v;
    PT.sheet.open(m);
}
(function () {
    const m = document.getElementById('nz-prayed-modal'); if (!m) return;
    m.addEventListener('click', function (e) {
        const b = e.target.closest('[data-v]'); if (!b || !nzPrayedFor || !nzLastState) return;
        const v = b.getAttribute('data-v');
        const apply = function () {
            nzPrayedSet(nzPrayedFor, v, nzLastState.now, nzLastState.tm);
            nzPrayedCache.v = null;
            m.querySelectorAll('.pt-option').forEach(o => o.setAttribute('aria-checked', o === b ? 'true' : 'false'));
            setTimeout(function () { PT.sheet.close(m); }, 160);
            processDashboardTimelineUpdates(new Date());
            const row = document.querySelector(`#main-prayer-cards-container [data-w="${nzPrayedFor}"] .fz-done`); if (row) row.classList.add('pop');
            if (v === 'jamaat' || v === 'alone') PT.toast('আলহামদুলিল্লাহ — আমলের রিপোর্টে যুক্ত হয়েছে', { type: 'success' });
            else if (v === 'qaza') PT.toast('কাজা হিসেবে রাখা হলো', { icon: 'info' });
            else PT.toast('চিহ্ন মুছে ফেলা হয়েছে', { icon: 'undo' });
        };
        /* v283: চিহ্ন মোছার আগে নিশ্চিতকরণ */
        if (!v) { PT.dialog({ icon: 'trash', title: 'চিহ্ন মুছে ফেলবেন?', body: 'এই ওয়াক্তের আদায়ের চিহ্ন ও আমলের রিপোর্টের এন্ট্রি মুছে যাবে।', ok: 'মুছে ফেলুন', cancel: 'থাক', danger: true }).then(function (y) { if (y) apply(); }); return; }
        apply();
    });
    window.addEventListener('storage', function (e) { if (e.key === 'amol_report_state') nzPrayedCache.v = null; });
})();
function nzDoneCount(S) {
    const el = document.getElementById('nz-done-count'); if (!el) return;
    const m = nzPrayedMap(S.now, S.tm); let n = 0;
    Object.keys(m).forEach(k => { if (m[k] === 'jamaat' || m[k] === 'alone') n++; });
    const t = pcBn(n) + '/৫ আদায়';
    el.hidden = !n; if (el.textContent !== t) el.textContent = t;
}

/* প্রতি সেকেন্ডে (processDashboardTimelineUpdates-এর শেষে) */
function nzAfterTick(S) { nzRamadan(S); nzDoneCount(S); }

/* ---------- ৪) হিসাবের নিয়ম ---------- */
const NZ_METHODS = [
    { id: 100, name: 'ইসলামিক ফাউন্ডেশন বাংলাদেশ', sub: 'বাংলাদেশের স্থায়ী সময়সূচি · ইন্টারনেট ছাড়াই, জেলাভিত্তিক' },
    { id: 1, name: 'করাচি', sub: 'বাংলাদেশ, পাকিস্তান, ভারতে প্রচলিত · ফজর ও এশা ১৮°' },
    { id: 3, name: 'মুসলিম ওয়ার্ল্ড লিগ', sub: 'ইউরোপ, দূরপ্রাচ্য · ফজর ১৮°, এশা ১৭°' },
    { id: 4, name: 'উম্মুল কুরা, মক্কা', sub: 'সৌদি আরব · এশা মাগরিবের ৯০ মিনিট পর' },
    { id: 2, name: 'উত্তর আমেরিকা (ISNA)', sub: 'যুক্তরাষ্ট্র, কানাডা · ফজর ও এশা ১৫°' },
    { id: 5, name: 'মিশর', sub: 'আফ্রিকা, সিরিয়া, লেবানন · ফজর ১৯.৫°' },
    { id: 8, name: 'উপসাগরীয় অঞ্চল', sub: 'আমিরাত, ওমান, বাহরাইন' },
    { id: 16, name: 'দুবাই', sub: 'সংযুক্ত আরব আমিরাত · ১৮.২°' },
    { id: 10, name: 'কাতার', sub: 'এশা মাগরিবের ৯০ মিনিট পর' },
    { id: 9, name: 'কুয়েত', sub: 'ফজর ১৮°, এশা ১৭.৫°' },
    { id: 11, name: 'সিঙ্গাপুর · মালয়েশিয়া', sub: 'ফজর ২০°, এশা ১৮°' },
    { id: 13, name: 'তুরস্ক (দিয়ানেত)', sub: 'ফজর ১৮°, এশা ১৭°' },
    { id: 15, name: 'মুনসাইটিং কমিটি', sub: 'যুক্তরাজ্য ও পশ্চিমা দেশে প্রচলিত' }
];
function nzMethodName(id) { const m = NZ_METHODS.find(x => x.id === id); return m ? m.name : 'করাচি'; }
function nzPaintMethod() {
    const el = document.getElementById('nz-method-name'); if (!el) return;
    const user = parseInt(localStorage.getItem('userPrayerMethodId') || '0', 10) > 0;
    const t = nzMethodName(nzMethodId());
    if (el.textContent !== t) el.textContent = t;
    const tag = document.getElementById('nz-method-auto'); if (tag && tag.hidden !== user) tag.hidden = user;   /* "স্বয়ংক্রিয়" চিহ্ন শুধু নিজে না বাছলে */
}
function nzOpenMethod() {
    const user = parseInt(localStorage.getItem('userPrayerMethodId') || '0', 10);
    const adm = parseInt(window._nativeMethodId, 10) || 1;
    const auto = (window.PtPrayer && PtPrayer.effectiveMethod) ? PtPrayer.effectiveMethod(0, adm, userLat, userLng) : adm;   /* বাংলাদেশে = ইসলামিক ফাউন্ডেশন */
    let h = `<button class="pt-option" type="button" role="radio" aria-checked="${user ? 'false' : 'true'}" data-m="0"><span class="pt-option__radio"></span><div class="pt-grow"><div class="pt-row__title">স্বয়ংক্রিয় (সুপারিশকৃত)</div><div class="pt-row__sub">পাথেয়-এর ঠিক করা পদ্ধতি: ${nzMethodName(auto)}</div></div></button>`;
    NZ_METHODS.forEach(m => {
        h += `<button class="pt-option" type="button" role="radio" aria-checked="${user === m.id ? 'true' : 'false'}" data-m="${m.id}"><span class="pt-option__radio"></span><div class="pt-grow"><div class="pt-row__title">${m.name}</div><div class="pt-row__sub">${m.sub}</div></div></button>`;
    });
    const list = document.getElementById('nz-method-list'); list.innerHTML = h;
    PT.sheet.open(document.getElementById('nz-method-modal'));
}
(function () {
    const list = document.getElementById('nz-method-list'); if (!list) return;
    list.addEventListener('click', function (e) {
        const b = e.target.closest('[data-m]'); if (!b) return;
        const v = parseInt(b.getAttribute('data-m'), 10);
        list.querySelectorAll('[data-m]').forEach(o => o.setAttribute('aria-checked', o === b ? 'true' : 'false'));
        try { if (v > 0) localStorage.setItem('userPrayerMethodId', String(v)); else localStorage.removeItem('userPrayerMethodId'); } catch (err) {}
        setTimeout(function () { PT.sheet.close(document.getElementById('nz-method-modal')); }, 160);
        nzSource = (nzSource === 'live' || nzSource === 'ifbd') ? 'cache' : nzSource;        /* পুরনো অনলাইন সময় আর এই পদ্ধতির নয় */
        nzRecompute(); nzPaintMethod();
        PT.toast('হিসাবের পদ্ধতি: ' + nzMethodName(nzMethodId()), { type: 'success' });
    });
})();

/* ---------- ৫) হিজরি ক্যালেন্ডার ও বিশেষ দিন — v211 থেকে তারিখ-কার্ড ফিচারে (datecard/HijriCalendarCard.kt) ---------- */

/* পপআপ খুললে/বন্ধ হলে হোমের ফুটার সাথে সাথে সরে/ফেরে (কন্ট্রোলারের chromeSync) */
['pt:open', 'pt:close'].forEach(function (ev) {
    document.addEventListener(ev, function () { try { const f = window.frameElement, P = window.parent; if (P && P !== window) setTimeout(function () { P.dispatchEvent(new Event('pt-frame-chrome')); }, 0); } catch (e) {} }, true);
});
