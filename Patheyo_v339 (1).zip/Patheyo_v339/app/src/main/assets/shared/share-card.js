/* পাথেয় — শেয়ার কার্ড (আয়াত / হাদিস / দোয়া)।
   দোয়া, হাদিস ও কুরআন — তিন ফিচারই এই একটি ফাইল ব্যবহার করে:
     <script src="https://appassets.patheyo.invalid/shared/share-card.js"></script>
     PtShareCard.open({ kind:'dua'|'ayah'|'hadith', title, ar, tr, bn, ref });
   - 1080×1350 (৪:৫) PNG ছবি আঁকে (WhatsApp / Facebook / Instagram-এ সুন্দর দেখায়)।
   - নিচে পপআপে: প্রিভিউ (সবসময় ওপরে) + ৪টি টুল (রঙ · ছবি · লেখা · নিচের অংশ — চাপলে তবেই প্যানেল খোলে) + স্থির শেয়ার / সেভ / লেখা কপি।
   - নেটিভ ব্রিজ PatheyoShare (Kotlin) থাকলে সেটা দিয়ে শেয়ার; না থাকলে (ব্রাউজারে) ডাউনলোড/Web Share। */
(function () {
  'use strict';
  if (window.PtShareCard) return;


  /* ---------- বিষয়ভিত্তিক আইকন সিস্টেম ----------
     প্রতিটা আয়াত/হাদিস/দোয়ার লেখা (ও দোয়ার ক্যাটাগরি) দেখে বিষয় ঠিক হয় → সেই বিষয়ের আইকন ও নাম হোম কার্ড আর শেয়ার কার্ডে আসে।
     নতুন বিষয় যোগ করতে: TOPICS-এ আইকন+নাম, RULES-এ শব্দগুলো বসান। (উপরের দিকের নিয়ম আগে মিলে — তাই নির্দিষ্টগুলো উপরে রাখুন।) */
  var TOPICS = {
    sabr:     { n: 'ধৈর্য',        d: 'M3 19l6.2-10.5 3.6 6 2.2-3.2L21 19zM9.2 8.5l1.6 2.6' },
    salah:    { n: 'নামাজ',       d: 'M5 20v-6c0-3.9 3.1-7 7-7s7 3.1 7 7v6M3 20h18M12 7V3M10 4.5h4' },
    zikr:     { n: 'আল্লাহর স্মরণ', d: 'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9zM18.5 16.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z' },
    tawakkul: { n: 'ভরসা',        d: 'M12 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM12 7v14M5 12H3a9 9 0 0 0 18 0h-2M8.5 11h7' },
    tawhid:   { n: 'তাওহিদ',      d: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z' },
    brother:  { n: 'ভ্রাতৃত্ব',     d: 'M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 20c0-3.3 2.7-6 6-6s6 2.7 6 6M16.5 11a2.5 2.5 0 1 0 0-5M17 14.2c2.7.4 4.5 2.7 4.5 5.8' },
    mercy:    { n: 'দয়া ও কল্যাণ', d: 'M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z' },
    knowledge:{ n: 'ইলম',         d: 'M12 6.5C10 5 7.2 4.6 4 5v13c3.2-.4 6 0 8 1.5 2-1.5 4.8-1.9 8-1.5V5c-3.2-.4-6 0-8 1.5zM12 6.5v13' },
    niyyah:   { n: 'নিয়ত',        d: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zM12 11.4v1.2' },
    hope:     { n: 'আশা ও স্বস্তি', d: 'M3 18h18M7 18a5 5 0 0 1 10 0M12 5v3M5.6 9.6l1.8 1.8M18.4 9.6l-1.8 1.8' },
    blessing: { n: 'নিয়ামত',      d: 'M4 11h16v9H4zM3 8h18v3H3zM12 8v12M12 8C10 4.8 7 4.8 7 6.6S10 8 12 8zM12 8c2-3.2 5-3.2 5-1.4S14 8 12 8z' },
    taqwa:    { n: 'তাকওয়া',      d: 'M12 3l7.5 3v5.5c0 4.6-3.2 8.3-7.5 9.5-4.3-1.2-7.5-4.9-7.5-9.5V6zM8.8 12l2.2 2.2 4.2-4.4' },
    purity:   { n: 'পবিত্রতা',     d: 'M12 3s6 6.3 6 11a6 6 0 0 1-12 0c0-4.7 6-11 6-11zM9.5 14.5a2.6 2.6 0 0 0 2.5 2.5' },
    speech:   { n: 'ভালো কথা',    d: 'M4 5h16v11H9.5L4 20zM8 9.5h8M8 12.5h5' },
    sadaqah:  { n: 'সদকা',        d: 'M4 7c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 7v4.5c0 1.7 3.6 3 8 3s8-1.3 8-3V7M4 11.5V16c0 1.7 3.6 3 8 3s8-1.3 8-3v-4.5' },
    deeds:    { n: 'নেক আমল',     d: 'M12 21v-9M12 12C12 8 9 6 5 6c0 4 2 6 7 6zM12 14.5c0-3 2.5-5 6-5 0 3-2 5-6 5z' },
    anger:    { n: 'ক্রোধ দমন',    d: 'M12 3c1 3.4 5.5 5.4 5.5 10.2A5.5 5.5 0 0 1 12 19a5.5 5.5 0 0 1-5.5-5.8c0-2.2 1.2-3.7 2.4-4.8.1 1.9 1 3 2.2 3 .2-3-1-4.8.9-8.4z' },
    akhlaq:   { n: 'উত্তম চরিত্র',  d: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8.4 14c1 1.6 2.3 2.3 3.6 2.3s2.6-.7 3.6-2.3M9 9.6h.01M15 9.6h.01' },
    istighfar:{ n: 'ক্ষমা প্রার্থনা', d: 'M20 12a8 8 0 1 1-2.4-5.7M20 4v5h-5M12 8v4.5l3 1.5' },
    trouble:  { n: 'বিপদ-আপদ',    d: 'M7 17a4 4 0 0 1-.4-8A5.5 5.5 0 0 1 17 7.8 4.6 4.6 0 0 1 17 17zM9 20l1-2M13 20l1-2' },
    morning:  { n: 'সকাল-সন্ধ্যা',   d: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1' },
    sleep:    { n: 'ঘুম',          d: 'M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5zM16 4v3M14.5 5.5h3' },
    food:     { n: 'খাওয়া-দাওয়া',  d: 'M4 11h16a8 8 0 0 1-16 0zM8 7.5c0-1.2 1-1.8 1-3.2M12 7.5c0-1.2 1-1.8 1-3.2M16 7.5c0-1.2 1-1.8 1-3.2' },
    home:     { n: 'ঘর ও পোশাক',   d: 'M4 11l8-7 8 7v9H4zM10 20v-6h4v6' },
    travel:   { n: 'সফর',          d: 'M12 21s7-6 7-11a7 7 0 1 0-14 0c0 5 7 11 7 11zM12 7.5a2.8 2.8 0 1 0 0 5.6 2.8 2.8 0 0 0 0-5.6z' },
    family:   { n: 'পরিবার',       d: 'M12 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6.5 20c0-3 2.5-5.5 5.5-5.5s5.5 2.5 5.5 5.5M5 12.5a2 2 0 1 0 0-4M19 12.5a2 2 0 1 0 0-4' },
    dua:      { n: 'দোয়া',        d: 'M3 10c1 5 4 8 9 8s8-3 9-8M3 10c3 0 6 1 9 4 3-3 6-4 9-4M12 3v3.5M10.2 4.7h3.6' },
    quran:    { n: 'কুরআন',        d: 'M5 5.5A1.5 1.5 0 0 1 6.5 4H19v13H6.5A1.5 1.5 0 0 0 5 18.5zM5 18.5A1.5 1.5 0 0 0 6.5 20H19v-3M12 7.2l1 1.6 1.8.3-1.3 1.3.3 1.8-1.8-.9-1.8.9.3-1.8-1.3-1.3 1.8-.3z' },
    hadith:   { n: 'হাদিস',        d: 'M7 4h10a2 2 0 0 1 2 2v14l-3-2-2 2-2-2-2 2-2-2-3 2V6a2 2 0 0 1 2-2zM9 9h6M9 12.5h4' }
  };
  var CATMAP = { morning: 'morning', sleep: 'sleep', food: 'food', home: 'home', salah: 'salah', travel: 'travel', istigfar: 'istighfar', trouble: 'trouble', family: 'family' };
  var RULES = [
    ['hope',      ['স্বস্তি', 'ত্যাগ করেননি', 'অচিরেই', 'নিরাশ', 'আশা করো']],
    ['anger',     ['রাগ']],
    ['sabr',      ['ধৈর্য', 'সবর', 'বিপদে পড়', 'দুর্বল হয়ো না', 'দুঃখ করো না', 'পরীক্ষা']],
    ['taqwa',     ['ভয় করো', 'তাকওয়া']],
    ['salah',     ['নামাজ', 'নামায', 'সালাত', 'ওযু', 'সিজদা', 'রুকু']],
    ['knowledge', ['ইলম', 'শেখ', 'শিক্ষা', 'জ্ঞান', 'পৌঁছে দাও', 'হিদায়াত']],
    ['niyyah',    ['নিয়ত']],
    ['purity',    ['পবিত্রতা', 'পরিচ্ছন্ন', 'তাওবাকারী']],
    ['tawakkul',  ['ভরসা', 'তাওয়াক্কুল', 'যথেষ্ট', 'লিখে রেখেছেন', 'কর্মবিধায়ক']],
    ['istighfar', ['ক্ষমা', 'ইস্তিগফার', 'তাওবা', 'গুনাহ']],
    ['zikr',      ['স্মরণ', 'জিকির', 'যিকির', 'তাসবিহ', 'সুবহান', 'প্রশংসা', 'শুকরিয়া']],
    ['akhlaq',    ['হাসিমুখে']],
    ['brother',   ['ভাই ভাই', 'ভাইয়ের', 'পরস্পর', 'মুসলিমরা', 'প্রতিবেশী']],
    ['mercy',     ['দয়া', 'রহমত', 'দয়ালু', 'কল্যাণকামিতা', 'হিতোপদেশ', 'ক্ষমাশীল']],
    ['akhlaq',    ['চরিত্র', 'আখলাক', 'হাসিমুখে', 'বিনয়', 'নম্র', 'সত্য']],
    ['speech',    ['ভালো কথা', 'জিহ্বা', 'চুপ থাক']],
    ['blessing',  ['নিয়ামত', 'কাউছার', 'অনুগ্রহ']],
    ['sadaqah',   ['সদকা', 'দান করো', 'খরচ']],
    ['deeds',     ['ভালো কাজ', 'সওয়াব', 'নেক', 'আমল']],
    ['dua',       ['দোয়া', 'প্রার্থনা']],
    ['tawhid',    ['ইবাদত', 'এক-অদ্বিতীয়', 'অদ্বিতীয়', 'ইলাহ', 'তাওহিদ', 'শিরক']],
    ['family',    ['সন্তান', 'পিতা-মাতা', 'মাতা-পিতা', 'স্ত্রী', 'পরিবার']]
  ];
  function topicOf(it) {
    it = it || {};
    if (it.topic && TOPICS[it.topic]) return it.topic;
    if (it.cat && CATMAP[it.cat]) return CATMAP[it.cat];
    var txt = (it.title || it.t || '') + ' ' + (it.bn || '');
    for (var i = 0; i < RULES.length; i++) for (var j = 0; j < RULES[i][1].length; j++) if (txt.indexOf(RULES[i][1][j]) > -1) return RULES[i][0];
    return it.kind === 'dua' ? 'dua' : (it.kind === 'hadith' ? 'hadith' : 'quran');
  }
  function topicSvg(id) { var t = TOPICS[id] || TOPICS.quran; return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' + t.d + '"/></svg>'; }
  window.PtTopics = { of: topicOf, label: function (id) { return (TOPICS[id] || TOPICS.quran).n; }, svg: topicSvg, path: function (id) { return (TOPICS[id] || TOPICS.quran).d; }, all: TOPICS };

  var BASE = 'https://appassets.patheyo.invalid/';
  var W = 1080, H = 1350;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }

  /* ---------- থিম ---------- */
  var THEMES = [
    { id: 'night',  n: 'নীল রাত',  bg: ['#0A1F4D', '#123A7A'], glow: 'rgba(120,170,255,.22)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.78)', gold: '#F5C95A', pat: 'rgba(255,255,255,.055)', dot: '#1B4FA3' },
    { id: 'emerald',n: 'পান্না সবুজ', bg: ['#06382B', '#0E6B4E'], glow: 'rgba(120,255,200,.20)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.80)', gold: '#F5D56E', pat: 'rgba(255,255,255,.055)', dot: '#0E8A63' },
    { id: 'sand',   n: 'মরুর বালি',  bg: ['#F7EBD0', '#EBD5A6'], glow: 'rgba(255,255,255,.55)', ink: '#3A2A10', mut: '#6B5530', gold: '#B4690E', pat: 'rgba(120,80,20,.07)', dot: '#C9983A' },
    { id: 'dusk',   n: 'গোধূলি',    bg: ['#2B1650', '#7A2F6B'], glow: 'rgba(255,170,220,.20)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.80)', gold: '#FFD27A', pat: 'rgba(255,255,255,.05)', dot: '#8E3D86' },
    { id: 'pearl',  n: 'মুক্তা সাদা', bg: ['#FFFFFF', '#EEF3FA'], glow: 'rgba(255,255,255,0)', ink: '#0C1B33', mut: '#4F6280', gold: '#0E7BB8', pat: 'rgba(14,60,120,.06)', dot: '#9DB4D6' },
    { id: 'ink',    n: 'গাঢ় কালো',  bg: ['#0B0B10', '#1C1C26'], glow: 'rgba(255,215,120,.12)', ink: '#FFFFFF', mut: 'rgba(255,255,255,.75)', gold: '#E8B84A', pat: 'rgba(255,255,255,.04)', dot: '#3A3A4A' }
  ];
  var KIND = { dua: 'দোয়া', ayah: 'কুরআনের আয়াত', hadith: 'হাদিস' };

  /* ---------- ফন্ট (কার্ডের ছবিতে নিজের ফন্ট লাগে — ফিচারের CSS-এর উপর ভরসা না করে নিজেই লোড করি) ---------- */
  var fontsP = null;
  function loadFonts() {
    if (fontsP) return fontsP;
    function face(name, file, weight) {
      try { var f = new FontFace(name, 'url(' + BASE + file + ')', { weight: weight || '400' }); document.fonts.add(f); return f.load(); }
      catch (e) { return Promise.resolve(); }
    }
    fontsP = Promise.all([
      face('PtCardAr', 'fonts/web/uthmanic-hafs-4baeb996.woff2'),
      face('PtCardBn', 'fonts/NotoSerifByGunjoron-Regular.ttf', '400'),   // ব্র্যান্ড ফন্ট Noto Serif by Gunjoron: বাংলা লেখা ও সংখ্যা
      face('PtCardBn', 'fonts/NotoSerifByGunjoron-Bold.ttf', '700'),
      face('PtCardLat', 'fonts/web/inter-260c81a4.woff2', '100 900')
    ]).catch(function () {});
    return fontsP;
  }

  /* ---------- আঁকার সহায়ক ---------- */
  function wrapLines(ctx, text, maxW) {
    var words = String(text || '').replace(/\s+/g, ' ').trim().split(' '), lines = [], cur = '';
    words.forEach(function (w) {
      var t = cur ? cur + ' ' + w : w;
      if (cur && ctx.measureText(t).width > maxW) { lines.push(cur); cur = w; } else cur = t;
    });
    if (cur) lines.push(cur);
    return lines;
  }
  /* maxH-এর মধ্যে ধরানোর জন্য ফন্ট ছোট করে (max → min) */
  function fit(ctx, text, fontFn, maxW, maxH, lhMul, max, min) {
    for (var s = max; s >= min; s -= 2) {
      ctx.font = fontFn(s);
      var lines = wrapLines(ctx, text, maxW);
      if (lines.length * s * lhMul <= maxH) return { size: s, lines: lines, h: lines.length * s * lhMul };
    }
    ctx.font = fontFn(min);
    var ls = wrapLines(ctx, text, maxW), maxLines = Math.max(1, Math.floor(maxH / (min * lhMul)));
    var cut = false;
    if (ls.length > maxLines) { cut = true; ls = ls.slice(0, maxLines); ls[maxLines - 1] = ls[maxLines - 1].replace(/\s*\S*$/, '') + ' …'; }
    return { size: min, lines: ls, h: ls.length * min * lhMul, cut: cut };
  }
  function star8(ctx, cx, cy, r, fill) {
    ctx.save(); ctx.translate(cx, cy); ctx.fillStyle = fill;
    for (var k = 0; k < 2; k++) { ctx.rotate(k * Math.PI / 4); roundRect(ctx, -r, -r, r * 2, r * 2, r * 0.14); ctx.fill(); }
    ctx.restore();
  }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function pattern(ctx, th) {
    ctx.save(); ctx.strokeStyle = th.pat; ctx.lineWidth = 2;
    var step = 150;
    for (var y = -step; y < H + step; y += step) for (var x = -step; x < W + step; x += step) {
      var cx = x + ((Math.round(y / step) % 2) ? step / 2 : 0);
      ctx.save(); ctx.translate(cx, y); 
      for (var k = 0; k < 2; k++) { ctx.rotate(k * Math.PI / 4); ctx.strokeRect(-34, -34, 68, 68); }
      ctx.restore();
    }
    ctx.restore();
  }
  function divider(ctx, th, y) {
    ctx.save();
    var g = ctx.createLinearGradient(W / 2 - 360, 0, W / 2 + 360, 0);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(.5, th.gold); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(W / 2 - 360, y - 1.5, 720, 3);
    star8(ctx, W / 2, y, 15, th.gold);
    ctx.fillStyle = th.bg[0]; ctx.beginPath(); ctx.arc(W / 2, y, 4.5, 0, 7); ctx.fill();
    ctx.restore();
  }

  /* ---------- ব্র্যান্ড লোগো (অ্যাপের হেডারের লোগোই) ---------- */
  /* অ্যাপের লোগো (হেডারের সেটাই) ইনলাইন — তাই নেটওয়ার্ক লাগে না, আর ক্যানভাস "tainted" হয় না */
  var LOGO_URI = 'data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxuczpjMnBhPSJodHRwOi8vYzJwYS5vcmcvbWFuaWZlc3QiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMTE1OC40IDExNTguNCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMTE1OC40IDExNTguNDsiIHhtbDpzcGFjZT0icHJlc2VydmUiPiA8c3R5bGUgdHlwZT0idGV4dC9jc3MiPiAuc3Qwe2ZpbGw6dXJsKCNTVkdJRF8xXyk7fSAuc3Qxe2NsaXAtcGF0aDp1cmwoI1NWR0lEXzNfKTt9IC5zdDJ7ZmlsbDp1cmwoI1NWR0lEXzRfKTt9IC5zdDN7ZmlsbDp1cmwoI1NWR0lEXzVfKTt9IC5zdDR7ZmlsbDp1cmwoI1NWR0lEXzZfKTt9IC5zdDV7b3BhY2l0eTowLjUxO2ZpbGw6bm9uZTtzdHJva2U6IzlEOUQ5QztzdHJva2Utd2lkdGg6NTt9IDwvc3R5bGU+IDxnPiA8cmFkaWFsR3JhZGllbnQgaWQ9IlNWR0lEXzFfIiBjeD0iNTc5LjE5NSIgY3k9IjU3OS4xOCIgcj0iNzczLjcyMzYiIGZ4PSIzNzEuMzE5OSIgZnk9IjEzNS4zMDYzIiBncmFkaWVudFRyYW5zZm9ybT0ibWF0cml4KDEgMCAwIDAuOTg2NCAwIDcuODkwOSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4gPHN0b3Agb2Zmc2V0PSIwIiBzdHlsZT0ic3RvcC1jb2xvcjojNEY4NkZGIi8+IDxzdG9wIG9mZnNldD0iMC4yMDMxIiBzdHlsZT0ic3RvcC1jb2xvcjojNDM3Q0ZGIi8+IDxzdG9wIG9mZnNldD0iMC41NjU0IiBzdHlsZT0ic3RvcC1jb2xvcjojMjU2MEZFIi8+IDxzdG9wIG9mZnNldD0iMC41ODI5IiBzdHlsZT0ic3RvcC1jb2xvcjojMjM1RkZFIi8+IDxzdG9wIG9mZnNldD0iMC42NTYxIiBzdHlsZT0ic3RvcC1jb2xvcjojMjE1QkY3Ii8+IDxzdG9wIG9mZnNldD0iMC43NjM0IiBzdHlsZT0ic3RvcC1jb2xvcjojMUI0RkUzIi8+IDxzdG9wIG9mZnNldD0iMC44OTExIiBzdHlsZT0ic3RvcC1jb2xvcjojMTIzQ0MzIi8+IDxzdG9wIG9mZnNldD0iMC45ODgyIiBzdHlsZT0ic3RvcC1jb2xvcjojMEEyQUE2Ii8+IDwvcmFkaWFsR3JhZGllbnQ+IDxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMTU4LjQsNTc5LjJjMCw4MC0xNi4yLDE1Ni4yLTQ1LjUsMjI1LjVjLTU4LjQsMTM4LTE2OC44LDI0OC43LTMwNi42LDMwNy41Yy0xMy45LDUuOS0yOC4xLDExLjMtNDIuNSwxNi4yIGMtNTgsMTkuNS0xMjAsMzAtMTg0LjYsMzBoMEMyNTkuMywxMTU4LjQsMCw4OTkuMSwwLDU3OS4yYzAtODAsMTYuMi0xNTYuMSw0NS41LTIyNS41QzEzMy40LDE0NS44LDMzOS4zLDAsNTc5LjIsMGgwIGM2OS41LDAsMTM2LjEsMTIuMiwxOTcuOSwzNC43YzE4LDYuNSwzNS41LDEzLjksNTIuNiwyMi4xQzEwMjQuMiwxNTAuMiwxMTU4LjQsMzQ5LDExNTguNCw1NzkuMnoiLz4gPGc+IDxkZWZzPiA8Y2lyY2xlIGlkPSJTVkdJRF8yXyIgY3g9IjU3OS4yIiBjeT0iNTc5LjIiIHI9IjU3OCIvPiA8L2RlZnM+IDxjbGlwUGF0aCBpZD0iU1ZHSURfM18iPiA8dXNlIHhsaW5rOmhyZWY9IiNTVkdJRF8yXyIgc3R5bGU9Im92ZXJmbG93OnZpc2libGU7Ii8+IDwvY2xpcFBhdGg+IDxnIGNsYXNzPSJzdDEiPiA8bGluZWFyR3JhZGllbnQgaWQ9IlNWR0lEXzRfIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9Ii0xOS40ODE1IiB5MT0iMTE3OS45Njc4IiB4Mj0iLTE5LjQ4MTUiIHkyPSIxMTc4Ljk2NzgiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMTA4MCAwIDAgLTYyMCAyMTYxOS4xOTkyIDczMTQyMCkiPiA8c3RvcCBvZmZzZXQ9IjAiIHN0eWxlPSJzdG9wLWNvbG9yOiNGRkZGRkY7c3RvcC1vcGFjaXR5OjAuNDIiLz4gPHN0b3Agb2Zmc2V0PSIxIiBzdHlsZT0ic3RvcC1jb2xvcjojRkZGRkZGO3N0b3Atb3BhY2l0eTowIi8+IDwvbGluZWFyR3JhZGllbnQ+IDxlbGxpcHNlIGNsYXNzPSJzdDIiIGN4PSI1NzkuMiIgY3k9IjE1MCIgcng9IjU0MCIgcnk9IjMxMCIvPiA8L2c+IDwvZz4gPGxpbmVhckdyYWRpZW50IGlkPSJTVkdJRF81XyIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiIHgxPSIzMTMuOTkxOCIgeTE9IjU3OS4yNzUiIHgyPSI5NDYuNzciIHkyPSI1NzkuMjc1Ij4gPHN0b3Agb2Zmc2V0PSIwIiBzdHlsZT0ic3RvcC1jb2xvcjojRkZGRkZGIi8+IDxzdG9wIG9mZnNldD0iMSIgc3R5bGU9InN0b3AtY29sb3I6I0RDRTZGRiIvPiA8L2xpbmVhckdyYWRpZW50PiA8cGF0aCBjbGFzcz0ic3QzIiBkPSJNOTQ2LjgsMzU3LjZsLTYuNyw1LjhjLTMuNSwzLTcsNi4xLTEwLjQsOS4yYy02LjgsNS45LTEzLjQsMTItMTkuNiwxNy43Yy05LjgsOS4xLTE5LjcsMTguNS0yOS4yLDI3LjkgYy0yLjksMi44LTUuOCw1LjgtOC42LDguNmwtMC45LDAuOWMtMy41LDMuNS02LjYsNi42LTkuNSw5LjZjLTMuMSwzLjItNi4zLDYuNC05LjQsOS43Yy0yLjgsMi45LTUuNSw1LjgtOC4zLDguN2wtMC4xLDAuMSBjLTAuNSwwLjUtMC45LDAuOS0xLjMsMS40bC0wLjIsMC4yYy0yLjksMy01LjcsNi4xLTguNSw5LjJjLTMsMy4yLTUuOSw2LjQtOSw5LjlsLTAuMSwwLjFjLTIuMSwyLjItNC4xLDQuNS02LDYuNyBjLTEuNiwxLjgtMy4xLDMuNS00LjcsNS4yYy0yLjMsMi43LTQuNyw1LjMtNyw4bC0wLjMsMC4zbC0wLjIsMC4yYy0yLjUsMi45LTUuMSw1LjktNy42LDguOEw3OTksNTA2Yy0wLjUsMC41LTEsMS4xLTEuNSwxLjggbC0wLjEsMC4xYy0yLjQsMi44LTQuOSw1LjgtNy40LDguN2wtMC4zLDAuNGMtMS43LDIuMS0zLjUsNC4xLTUuMiw2LjJsLTQuMSw1bDEuNCw2LjNjMS43LDcuNy0xLjEsMTcuNi05LjcsMjEuOSBjLTMsMS41LTYuNCwyLjMtOS43LDIuM2wtNi4zLDAuMWMwLDAtNC4zLDUuNy00LjYsNmMtMC4zLDAuNC0wLjYsMC44LTEsMS4yYy03LjMsOS42LTE0LjUsMTkuMy0yMS4zLDI4LjljLTEsMS4zLTEuOSwyLjYtMi44LDMuOSBsLTAuNiwwLjljLTYuMiw4LjgtMTIuNCwxNy42LTE4LjMsMjYuM2MtMzUuMiw1Mi4xLTY3LDEwNy4xLTk0LjYsMTYzLjVjLTcuOSwxNi4zLTE1LjIsMzMuOS0yMS42LDQ5LjUgYy0xNC45LDM2LjItMzAuNCw3My43LTU1LDEwMi40bC0yLjMsMi43bC0zLjUtMC43Yy01LjgtMS4yLTEzLjgtNC41LTIwLjItNy4zbC0wLjItMC4xYy0xLjQtMC42LTIuNC0xLTMuNC0xLjUgYy0xLTAuNC0yLjItMC45LTMuNi0xLjRjLTEwLjUtNC4xLTE3LTcuMi0yMC41LTkuOGwtMi4xLTEuNmwtMC4yLTIuNmMtMTAuOC0xMTAuOS0yOS4xLTIyMi4yLTU0LjMtMzMwLjhsLTguNi0zN2wxNiwyLjJsMC4yLDAgYzYsMS4yLDExLjksMi45LDE3LjYsNS4xYzIuMiwwLjgsNC4zLDEuNyw2LjQsMi43bDIuNiwxLjJsMC43LDIuOGMxMC43LDQxLjYsMjAuNCw4NC4xLDI4LjksMTI2LjJjOC44LDQzLjIsMTYuNSw4Ny4xLDIzLDEzMC43IGw3LDQ2LjhsMjEuOC01Mi43YzcuMS0xNy4xLDEzLjctMzMuMiwyMS4zLTQ4LjdjMjYuNy01NC40LDU3LjUtMTA3LjQsOTEuNC0xNTcuNmMxOC4xLTI2LjgsMzcuNy01My42LDU4LjMtNzkuNWw2LjItNy45TDU0MS42LDI4MiBsLTEwLDE3LjZDNDkwLDM3Mi40LDQ1My41LDQ0OSw0MjMsNTI3bC0yMi4yLDYwLjJjLTEyLjksMzctMjQuNSw3NC42LTM0LjYsMTExLjZjLTIuNiw5LjYtOS4yLDE0LjUtMTkuOCwxNC41IGMtMTAuNywwLTIyLTUuNC0yOC4xLTEzLjRjLTQuMS01LjMtNS4zLTExLjItMy42LTE3LjRjNDMuOS0xNjEuNiwxMTAuNS0zMTUuOSwxOTguMS00NTguN2M0LTYuNSw5LjctOS43LDE3LjItOS43IGMxMC4zLDAsMjIuMiw2LjIsMjguNywxNS4yTDc0OC43LDQ4N2wxMC44LTEyLjJjMy4yLTMuNiw2LjctNy42LDEwLjItMTEuNGMxLTEuMSwyLTIuMiwzLTMuM2MzLjItMy41LDYuMy02LjksOS41LTEwLjNsMC4zLTAuMyBjMC4zLTAuMywwLjYtMC42LDAuOS0wLjljNC40LTQuOCw5LTkuNiwxMy41LTE0LjJjMS4yLTEuMywyLjUtMi42LDMuOC0zLjljMC44LTAuOSwxLjctMS43LDIuNS0yLjZjMTEuNy0xMiwyMy44LTI0LDM1LjktMzUuNSBjMS44LTEuNywzLjctMy41LDUuNS01LjJsMS4zLTEuMmM3LjItNi44LDE0LjUtMTMuNSwyMS44LTIwYzEuOS0xLjcsMy45LTMuNSw1LjgtNS4ybDEuNS0xLjNjMi41LTIuMiw0LjktNC40LDcuNC02LjUgYzUuNS00LjgsMTAuMy05LDE0LjktMTIuOGwyLjEtMS43bDIuNywwLjRjNS44LDAuOSwxNC4yLDQuMywyMSw3LjNjMS42LDAuNywyLjksMS4zLDQsMS43YzMuMywxLjQsOSw0LjMsMTIuMSw1LjlMOTQ2LjgsMzU3LjZ6Ii8+IDxsaW5lYXJHcmFkaWVudCBpZD0iU1ZHSURfNl8iIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiB4MT0iNzg0LjQyODEiIHkxPSIzNC42ODAxIiB4Mj0iNzg0LjQyODEiIHkyPSIxMTI4LjMzIj4gPHN0b3Agb2Zmc2V0PSIwIiBzdHlsZT0ic3RvcC1jb2xvcjojRkZGRkZGIi8+IDxzdG9wIG9mZnNldD0iMSIgc3R5bGU9InN0b3AtY29sb3I6I0RDRTZGRiIvPiA8L2xpbmVhckdyYWRpZW50PiA8cGF0aCBjbGFzcz0ic3Q0IiBkPSJNNzkxLjEsNTE1LjRjLTYuOCwxODgtMi42LDM3OC4yLDEyLjYsNTY2YzAuOCwxMC4zLDEuNywyMC41LDIuNiwzMC44Yy0xMy45LDUuOS0yOC4xLDExLjMtNDIuNSwxNi4ybC0wLjEtMS40IGMtMS05LjUtMS45LTE4LjktMi44LTI4LjVjLTUuNC01Ni45LTkuOC0xMTQuMi0xMy4yLTE3MWMtNi44LTExNC43LTkuNi0yMzEuMS04LjEtMzQ2LjV2MGMwLjEtNi4xLDAuMi0xMi4zLDAuMy0xOC40IGMwLjMtMjIuNCwwLjktNDUuMSwxLjYtNjcuNWMwLjItNS44LDAuNC0xMS41LDAuNS0xNy4zYzQuNy0xMzcuNywxNS4yLTI3Ni41LDMxLjUtNDEzLjJ2MGMxLjEtOS41LDIuMy0xOC45LDMuNS0yOC40bDAuMi0xLjQgYzE4LDYuNSwzNS41LDEzLjksNTIuNiwyMi4xYy0xLjQsMTAuMi0yLjcsMjAuNC00LDMwLjZjLTE0LjYsMTE1LjMtMjUsMjMyLjUtMzEuMiwzNDkuMnYwYy0wLjMsNS40LTAuNiwxMC44LTAuOCwxNi4yIGMtMSwyMC4xLTEuOSw0MC40LTIuNiw2MC41djEuMUM3OTEuMSw1MTQuOCw3OTEuMSw1MTUuMSw3OTEuMSw1MTUuNEw3OTEuMSw1MTUuNHoiLz4gPHBhdGggY2xhc3M9InN0NSIgZD0iTTU3OS4yLDExMjkuMkw1NzkuMiwxMTI5LjJjLTMwMy43LDAtNTUwLTI0Ni4yLTU1MC01NTB2MGMwLTMwMy43LDI0Ni4yLTU1MCw1NTAtNTUwaDAgYzMwMy43LDAsNTUwLDI0Ni4yLDU1MCw1NTB2MEMxMTI5LjIsODgyLjksODgyLjksMTEyOS4yLDU3OS4yLDExMjkuMnoiLz4gPC9nPiA8L3N2Zz4g';
  var logoP = null;
  function loadLogo() {
    if (logoP) return logoP;
    logoP = new Promise(function (res) {
      try { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = LOGO_URI; }
      catch (e) { res(null); }
    });
    return logoP;
  }
  /* পাতলা বিভাজক: দুই পাশে মিলিয়ে যাওয়া রেখা, মাঝে ছোট হীরা */
  function rule(ctx, th, y, half) {
    ctx.save();
    [[-1, 0], [1, 1]].forEach(function (d) {
      var x0 = W / 2 + d[0] * 26, x1 = W / 2 + d[0] * (half || 300);
      var g = ctx.createLinearGradient(x0, 0, x1, 0); g.addColorStop(0, th.gold); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.globalAlpha = .75; ctx.strokeStyle = g; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
    });
    ctx.globalAlpha = 1; ctx.fillStyle = th.gold; ctx.translate(W / 2, y); ctx.rotate(Math.PI / 4); ctx.fillRect(-7, -7, 14, 14);
    ctx.restore();
  }

  /* ---------- কার্ড আঁকা ---------- */

  /* ---------- v295: ব্যাকগ্রাউন্ড ছবি (গ্যালারি থেকে) — উজ্জ্বলতা, ঝাপসা, জুম ও অবস্থান ঠিক করা যায় ---------- */
  var BG_DEF = { v: -45, b: 0, z: 100, x: 0, y: 0 };   /* v: উজ্জ্বলতা −১০০…১০০ (ঋণাত্মক = আরও অন্ধকার), b: ঝাপসা (px), z: জুম %, x/y: অবস্থান */
  var bgCache = { src: null, img: null };
  function bgImage(src) {
    if (!src) return Promise.resolve(null);
    if (bgCache.src === src && bgCache.img) return Promise.resolve(bgCache.img);
    return loadImg(src).then(function (im) { if (im) { bgCache.src = src; bgCache.img = im; } return im; });
  }
  function drawBg(ctx, im, o) {
    var iw = im.naturalWidth || im.width, ih = im.naturalHeight || im.height;
    var blur = Math.max(0, o.blur || 0), z = Math.max(1, o.zoom || 1);
    var sc = Math.max(W / iw, H / ih) * z * (1 + blur / 90);      /* ঝাপসায় কিনারা ফাঁকা না হতে একটু বড় করে আঁকা */
    var dw = iw * sc, dh = ih * sc, ow = Math.max(0, dw - W), oh = Math.max(0, dh - H);
    var dx = -ow / 2 - (o.x || 0) / 100 * ow / 2, dy = -oh / 2 - (o.y || 0) / 100 * oh / 2;
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 0, W, H); ctx.clip();
    if (blur > 0 && 'filter' in ctx) { ctx.filter = 'blur(' + blur + 'px)'; ctx.drawImage(im, dx, dy, dw, dh); ctx.filter = 'none'; }
    else if (blur > 0) {                                           /* ফিল্টার না থাকলে ছোট করে আবার বড় করে ঝাপসা */
      var k = Math.max(1, blur / 2), t = document.createElement('canvas'); t.width = Math.ceil(W / k); t.height = Math.ceil(H / k);
      var tc = t.getContext('2d'); tc.imageSmoothingQuality = 'high'; tc.drawImage(im, dx / k, dy / k, dw / k, dh / k);
      ctx.imageSmoothingQuality = 'high'; ctx.drawImage(t, 0, 0, W, H);
    } else ctx.drawImage(im, dx, dy, dw, dh);
    ctx.restore();
    var v = o.v || 0;                                              /* উজ্জ্বলতা: কালো পর্দা বা সাদা আভা */
    ctx.fillStyle = v < 0 ? 'rgba(0,0,0,' + (-v * .9) + ')' : 'rgba(255,255,255,' + (v * .85) + ')';
    ctx.fillRect(0, 0, W, H);
  }
  /* ছবির উপরে লেখা যেন পড়া যায়: অন্ধকার/মাঝারি ছবিতে সাদা লেখা, খুব উজ্জ্বল করলে গাঢ় লেখা */
  function themeOverPhoto(th, v) {
    var o = {}; for (var k in th) o[k] = th[k];
    if (v > .35) { o.ink = '#0C1B33'; o.mut = '#3F5270'; o.gold = '#0E5E8F'; }
    else { o.ink = '#FFFFFF'; o.mut = 'rgba(255,255,255,.84)'; if (th.ink !== '#FFFFFF') o.gold = '#F5C95A'; }
    return o;
  }
  function bgLoad() { try { var d = localStorage.getItem('pt_share_bg'); return d && d.indexOf('data:image') === 0 ? d : ''; } catch (e) { return ''; } }
  function bgSave(d) { try { if (d) localStorage.setItem('pt_share_bg', d); else localStorage.removeItem('pt_share_bg'); } catch (e) {} }
  /* গ্যালারির ছবি → সর্বোচ্চ ১৬০০px, JPEG */
  function bgFromFile(f) {
    return new Promise(function (res) {
      var rd = new FileReader();
      rd.onerror = function () { res(''); };
      rd.onload = function () {
        var im = new Image();
        im.onerror = function () { res(''); };
        im.onload = function () {
          try {
            var w = im.naturalWidth || im.width, h = im.naturalHeight || im.height, k = Math.min(1, 1600 / Math.max(w, h));
            var c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
            c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
            res(c.toDataURL('image/jpeg', .86));
          } catch (e) { res(''); }
        };
        im.src = rd.result;
      };
      rd.readAsDataURL(f);
    });
  }

  var SERIF = 'PtCardBn, sans-serif';   /* হোমের হেডারের ফন্টই (Noto Serif by Gunjoron) */

  /* ---------- v291: কিউআর কোড (ওয়েবসাইটের লিংক) — নিজস্ব ছোট জেনারেটর, নেটওয়ার্ক/লাইব্রেরি লাগে না ----------
     বাইট মোড, ইসিসি লেভেল M, ভার্সন ১–৫ (লিংক ছোট, তাই ২৯×২৯ ঘরেই হয়)। */
  var SITE_URL = 'https://patheyobygunjoron.github.io';
  var QR_ECC_M = [10, 16, 26, 18, 24], QR_BLOCKS_M = [1, 1, 1, 2, 2], QR_ALIGN = [[], [6, 18], [6, 22], [6, 26], [6, 30]];
  function qrRaw(v) { var n = (16 * v + 128) * v + 64; if (v >= 2) { var na = Math.floor(v / 7) + 2; n -= (25 * na - 10) * na - 55; } return n; }
  function gfMul(x, y) { var z = 0; for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z & 255; }
  function rsDivisor(deg) { var r = [], i, j, root = 1; for (i = 0; i < deg - 1; i++) r.push(0); r.push(1); for (i = 0; i < deg; i++) { for (j = 0; j < deg; j++) { r[j] = gfMul(r[j], root); if (j + 1 < deg) r[j] ^= r[j + 1]; } root = gfMul(root, 2); } return r; }
  function rsRemainder(data, div) { var r = div.map(function () { return 0; }); data.forEach(function (b) { var f = b ^ r.shift(); r.push(0); div.forEach(function (c, i) { r[i] ^= gfMul(c, f); }); }); return r; }
  function qrMake(text) {
    var bytes = []; var u = unescape(encodeURIComponent(text)); for (var q = 0; q < u.length; q++) bytes.push(u.charCodeAt(q));
    var ver = 0, i, j;
    for (i = 1; i <= 5; i++) { var cap = Math.floor(qrRaw(i) / 8) - QR_ECC_M[i - 1] * QR_BLOCKS_M[i - 1]; if (bytes.length <= cap - 2) { ver = i; break; } }
    if (!ver) return null;
    var bits = []; function put(val, n) { for (var k = n - 1; k >= 0; k--) bits.push((val >>> k) & 1); }
    put(4, 4); put(bytes.length, 8); bytes.forEach(function (b) { put(b, 8); });
    var dataCw = Math.floor(qrRaw(ver) / 8) - QR_ECC_M[ver - 1] * QR_BLOCKS_M[ver - 1];
    put(0, Math.min(4, dataCw * 8 - bits.length)); while (bits.length % 8) bits.push(0);
    var cw = []; for (i = 0; i < bits.length; i += 8) { var by = 0; for (j = 0; j < 8; j++) by = (by << 1) | bits[i + j]; cw.push(by); }
    for (var pad = 0xEC; cw.length < dataCw; pad ^= 0xEC ^ 0x11) cw.push(pad);
    /* ইসিসি + ইন্টারলিভ */
    var nb = QR_BLOCKS_M[ver - 1], eccLen = QR_ECC_M[ver - 1], raw = Math.floor(qrRaw(ver) / 8), nShort = nb - raw % nb, shortLen = Math.floor(raw / nb);
    var blocks = [], div = rsDivisor(eccLen), k = 0;
    for (i = 0; i < nb; i++) { var dl = shortLen - eccLen + (i < nShort ? 0 : 1); var dat = cw.slice(k, k + dl); k += dl; var ecc = rsRemainder(dat, div); if (i < nShort) dat.push(0); blocks.push(dat.concat(ecc)); }
    var all = [];
    for (i = 0; i < blocks[0].length; i++) for (j = 0; j < nb; j++) if (i !== shortLen - eccLen || j >= nShort) all.push(blocks[j][i]);
    /* ম্যাট্রিক্স */
    var n = ver * 4 + 17, m = [], fn = [];
    for (i = 0; i < n; i++) { m.push(new Array(n).fill(false)); fn.push(new Array(n).fill(false)); }
    function setF(x, y, d) { m[y][x] = d; fn[y][x] = true; }
    for (i = 0; i < n; i++) { setF(6, i, i % 2 === 0); setF(i, 6, i % 2 === 0); }
    function finder(cx, cy) { for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) { var d = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy; if (xx >= 0 && xx < n && yy >= 0 && yy < n) setF(xx, yy, d !== 2 && d !== 4); } }
    finder(3, 3); finder(n - 4, 3); finder(3, n - 4);
    var al = QR_ALIGN[ver - 1];
    for (i = 0; i < al.length; i++) for (j = 0; j < al.length; j++) { if ((i === 0 && j === 0) || (i === 0 && j === al.length - 1) || (i === al.length - 1 && j === 0)) continue; for (var ay = -2; ay <= 2; ay++) for (var ax = -2; ax <= 2; ax++) setF(al[i] + ax, al[j] + ay, Math.max(Math.abs(ax), Math.abs(ay)) !== 1); }
    function fmt(mask) {
      var data = (0 << 3) | mask, rem = data; for (var r = 0; r < 10; r++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      var b = ((data << 10) | rem) ^ 0x5412; function bit(x) { return ((b >>> x) & 1) !== 0; }
      for (var a = 0; a <= 5; a++) setF(8, a, bit(a)); setF(8, 7, bit(6)); setF(8, 8, bit(7)); setF(7, 8, bit(8));
      for (a = 9; a < 15; a++) setF(14 - a, 8, bit(a));
      for (a = 0; a < 8; a++) setF(n - 1 - a, 8, bit(a)); for (a = 8; a < 15; a++) setF(8, n - 15 + a, bit(a));
      setF(8, n - 8, true);
    }
    fmt(0);
    var idx = 0;
    for (var right = n - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < n; vert++) for (j = 0; j < 2; j++) {
        var x = right - j, up = ((right + 1) & 2) === 0, y = up ? n - 1 - vert : vert;
        if (!fn[y][x] && idx < all.length * 8) { m[y][x] = ((all[idx >>> 3] >>> (7 - (idx & 7))) & 1) !== 0; idx++; }
      }
    }
    for (var yy = 0; yy < n; yy++) for (var xx = 0; xx < n; xx++) if (!fn[yy][xx] && (xx + yy) % 2 === 0) m[yy][xx] = !m[yy][xx];   /* মাস্ক ০ */
    fmt(0);
    return m;
  }
  window.PtQR = qrMake;

  /* কিউআর: কোনো প্লেট/শেপ/বর্ডার নেই — শুধু ঘরগুলো থিমের লেখার রঙে (গাঢ় থিমে সাদা) */
  function drawQr(ctx, th, x, y, size, r) {
    var m = null; try { m = qrMake(SITE_URL); } catch (e) {}
    ctx.save();
    if (m) {
      var n = m.length, cell = Math.max(2, Math.floor((size - 56) / n))   /* v293: বর্ডার নেই, কিউআর সামান্য ছোট (জায়গা/কেন্দ্র আগের মতোই) */, qs = cell * n, ox = x + Math.round((size - qs) / 2), oy = y + Math.round((size - qs) / 2);
      ctx.fillStyle = th.ink;
      /* v294: গোল ঘর — ডেটার প্রতিটি ঘর ছোট গোল ফোঁটা; তিন কোণার চৌকো মার্কার গোল-কোনা বর্গের রিং + ভেতরে গোল-কোনা বর্গ */
      function inFinder(x, y) { return (x < 7 && y < 7) || (x >= n - 7 && y < 7) || (x < 7 && y >= n - 7); }
      var rad = cell * 0.5;
      ctx.beginPath();
      for (var yy = 0; yy < n; yy++) for (var xx = 0; xx < n; xx++) if (m[yy][xx] && !inFinder(xx, yy)) {
        var cx = ox + xx * cell + cell / 2, cy = oy + yy * cell + cell / 2;
        ctx.moveTo(cx + rad, cy); ctx.arc(cx, cy, rad, 0, Math.PI * 2);
      }
      ctx.fill();
      [[0, 0], [n - 7, 0], [0, n - 7]].forEach(function (f) {
        var fx = ox + f[0] * cell, fy = oy + f[1] * cell;
        function sub(x, y, w, h, r) { ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
        ctx.beginPath();
        sub(fx, fy, 7 * cell, 7 * cell, 2.4 * cell);                           /* বাইরের রিং */
        sub(fx + cell, fy + cell, 5 * cell, 5 * cell, 1.5 * cell);            /* ভেতরের ফাঁকা */
        ctx.fill('evenodd');
        ctx.beginPath(); roundRect(ctx, fx + 2 * cell, fy + 2 * cell, 3 * cell, 3 * cell, 1.1 * cell); ctx.fill();   /* মাঝের বিন্দু */
      });
    }
    ctx.restore();
  }

  /* ---------- v291: অ্যাপ-ব্যবহারকারী (অ্যাকাউন্ট খোলা থাকলে) — নাম ও প্রোফাইল ছবি ---------- */
  function userInfo() {
    try {
      var a = window.PatheyoAuth || (window.parent && window.parent !== window && window.parent.PatheyoAuth) || null, stt = null;
      if (a && a.state) stt = JSON.parse(a.state());
      if (!stt || !stt.signedIn) return null;
      var p = null; try { p = JSON.parse(localStorage.getItem('pt_profile') || 'null'); } catch (e) {}
      var name = String((p && p.name) || stt.name || '').replace(/\s+/g, ' ').trim();
      var photo = (p && p.photo && String(p.photo).indexOf('data:') === 0) ? p.photo : '';   /* শুধু ফোনে থাকা ছবি (data:) — ক্যানভাস "tainted" হয় না */
      return { name: name, photo: photo };
    } catch (e) { return null; }
  }
  function loadImg(src) {
    return new Promise(function (res) {
      if (!src) { res(null); return; }
      try { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = src; } catch (e) { res(null); }
    });
  }
  /* ছবি না থাকলে: নামের প্রথম অক্ষর, রঙিন গোল-কোনা বর্গে */
  function drawAvatar(ctx, th, img, name, x, y, size, r) {
    ctx.save(); roundRect(ctx, x, y, size, size, r); ctx.clip();
    if (img) {
      var sw = img.naturalWidth || img.width, sh = img.naturalHeight || img.height, s0 = Math.min(sw, sh);
      ctx.drawImage(img, (sw - s0) / 2, (sh - s0) / 2, s0, s0, x, y, size, size);
    } else {
      var g = ctx.createLinearGradient(x, y, x + size, y + size); g.addColorStop(0, '#235FFE'); g.addColorStop(1, '#0E4FD0');
      ctx.fillStyle = g; ctx.fillRect(x, y, size, size);
      var ch = (Array.from(name || 'প')[0] || 'প');
      ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '700 ' + Math.round(size * .5) + 'px ' + SERIF; ctx.fillText(ch, x + size / 2, y + size / 2 + 2);
      ctx.textBaseline = 'alphabetic';
    }
    ctx.restore();
    ctx.save(); ctx.globalAlpha = .55; ctx.strokeStyle = th.gold; ctx.lineWidth = 2.5; roundRect(ctx, x, y, size, size, r); ctx.stroke(); ctx.restore();
  }
  function ellipsize(ctx, text, maxW) {
    if (ctx.measureText(text).width <= maxW) return text;
    var a = Array.from(text); while (a.length > 1 && ctx.measureText(a.join('') + '…').width > maxW) a.pop();
    return a.join('') + '…';
  }
  function drawIcon(ctx, id, cx, cy, size, color, lw) {
    try {
      ctx.save(); ctx.translate(cx - size / 2, cy - size / 2); var k = size / 24; ctx.scale(k, k);
      ctx.lineWidth = lw; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = color; ctx.stroke(new Path2D(window.PtTopics.path(id)));
      ctx.restore();
    } catch (e) { try { ctx.restore(); } catch (e2) {} }
  }
  function spaced(ctx, px) { try { ctx.letterSpacing = px + 'px'; } catch (e) {} }
  /* দুই পাশে ছোট রেখা দিয়ে বসানো ছোট লেখা (আইব্রো) */
  function flank(ctx, th, text, y, font, gap, len) {
    ctx.font = font; var w = ctx.measureText(text).width;
    ctx.textAlign = 'center'; ctx.fillStyle = th.gold; ctx.fillText(text, W / 2, y);
    ctx.save(); ctx.globalAlpha = .6; ctx.fillStyle = th.gold;
    ctx.fillRect(W / 2 - w / 2 - gap - len, y - 11, len, 2.5); ctx.fillRect(W / 2 + w / 2 + gap, y - 11, len, 2.5);
    ctx.restore();
  }
  function render(data, opt) {
    /* v293: নিচের লাইন — 'both' = ছবি+নাম, 'name' = শুধু নাম, 'none' = আগের মতো ওয়েবসাইটের লিংক। নাম না থাকলে লিংকই। */
    var who = opt.who || 'both', usr = who === 'none' ? null : userInfo();
    if (usr && !usr.name) usr = null;
    return Promise.all([loadFonts(), loadLogo(), (usr && who === 'both') ? loadImg(usr.photo) : null, opt.bg ? bgImage(opt.bg.data) : null]).then(function (rs) {
      var logo = rs[1], uimg = rs[2], bgim = rs[3];
      var th = THEMES.filter(function (t) { return t.id === opt.theme; })[0] || THEMES[0];
      var c = document.createElement('canvas'); c.width = W; c.height = H;
      var ctx = c.getContext('2d');
      var M = 88;
      /* পটভূমি — পরিষ্কার গ্রেডিয়েন্ট + নরম আলো */
      var g = ctx.createLinearGradient(0, 0, W * 0.5, H); g.addColorStop(0, th.bg[0]); g.addColorStop(1, th.bg[1]);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      var rg = ctx.createRadialGradient(W * 0.85, H * 0.06, 20, W * 0.85, H * 0.06, 860); rg.addColorStop(0, th.glow); rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
      if (bgim) { drawBg(ctx, bgim, opt.bg); th = themeOverPhoto(th, opt.bg.v); }   /* v295: গ্যালারির ব্যাকগ্রাউন্ড */
      ctx.strokeStyle = th.gold; ctx.globalAlpha = .34; ctx.lineWidth = 2.5; roundRect(ctx, 40, 40, W - 80, H - 80, 40); ctx.stroke(); ctx.globalAlpha = 1;
      var tid = window.PtTopics.of(data);
      /* বিষয়ের বড় ঝাপসা জলছাপ (খুব হালকা) */
      ctx.save(); roundRect(ctx, 40, 40, W - 80, H - 80, 40); ctx.clip(); ctx.globalAlpha = .055;
      drawIcon(ctx, tid, W - 250, H - 470, 620, th.gold, .55); ctx.restore();
      ctx.textBaseline = 'alphabetic'; ctx.direction = 'ltr';

      /* ── হেডার: হোমের মতোই — লোগো, "পাথেয় বাই গুঞ্জরণ", নিচে স্লোগান ── */
      var LS = 112, ly = 92;
      if (logo) { try { ctx.save(); ctx.shadowColor = 'rgba(0,16,60,.35)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 8; ctx.drawImage(logo, M, ly, LS, LS); ctx.restore(); } catch (e) {} }
      /* v292: কিউআরের বর্ডার-বক্স উপরের ফ্রেম-লাইন (y=40) থেকে নিচের বিভাজক-লাইন পর্যন্ত; ডানে ফ্রেম থেকে ততটুকু ফাঁকা যতটুকু লোগোর বাঁয়ে (M−40) */
      var qTop = 40, qBot = ly + LS + 44, qSz = qBot - qTop;
      drawQr(ctx, th, W - M - qSz, qTop, qSz, 22);
      var tx = logo ? M + LS + 28 : M;
      ctx.textAlign = 'left'; spaced(ctx, 0);
      ctx.fillStyle = th.ink; ctx.font = '700 52px ' + SERIF; ctx.fillText('পাথেয়', tx, ly + 54);
      var nw = ctx.measureText('পাথেয় ').width;
      ctx.globalAlpha = .82; ctx.font = '400 52px ' + SERIF; ctx.fillText('বাই গুঞ্জরণ', tx + nw, ly + 54); ctx.globalAlpha = 1;
      ctx.fillStyle = th.mut; ctx.font = '300 30px ' + SERIF; spaced(ctx, 0); ctx.fillText('চিরস্থায়ী সফরের পরম সঙ্গী', tx, ly + 100);
      spaced(ctx, 0);
      ctx.globalAlpha = .14; ctx.fillStyle = th.ink; ctx.fillRect(M, ly + LS + 44, W - M * 2, 2); ctx.globalAlpha = 1;

      /* ── বিষয়ের আইকন-ব্যাজ + আইব্রো (বিষয় · ধরন) + হেডলাইন ── */
      var kind = KIND[data.kind] || 'দোয়া', bcy = ly + LS + 44 + 74, br = 40;
      ctx.save(); ctx.fillStyle = th.gold; ctx.globalAlpha = .14; ctx.beginPath(); ctx.arc(W / 2, bcy, br, 0, 7); ctx.fill();
      ctx.globalAlpha = .75; ctx.strokeStyle = th.gold; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(W / 2, bcy, br, 0, 7); ctx.stroke(); ctx.restore();
      drawIcon(ctx, tid, W / 2, bcy, 44, th.gold, 1.7);
      var y0 = bcy + br + 54;
      spaced(ctx, 0); flank(ctx, th, window.PtTopics.label(tid) + '  ·  ' + kind, y0, '700 28px ' + SERIF, 24, 56); spaced(ctx, 0);
      var top = y0 + 36, hasHead = data.title && !(data.ref && String(data.ref).indexOf(data.title) === 0);
      ctx.textAlign = 'center';
      if (hasHead) {
        var tl = fit(ctx, data.title, function (s) { return '700 ' + s + 'px ' + SERIF; }, 860, 64, 1.2, 52, 30);
        ctx.font = '700 ' + tl.size + 'px ' + SERIF; ctx.fillStyle = th.ink; ctx.fillText(tl.lines[0], W / 2, top + 58);
        top += 96;
      }

      /* ── মূল অংশ ── */
      top += 14; var bottom = H - 262, avail = bottom - top;
      var showAr = opt.ar !== false, showTr = opt.tr && data.tr, showBn = opt.bn && data.bn, cut = {};
      var rest = (showTr ? 1 : 0) + (showBn ? 1 : 0);
      var hAr = !showAr ? 0 : (rest ? avail * (showBn && showTr ? 0.46 : 0.52) : avail * 0.86);
      var hTr = showTr ? avail * (showBn ? 0.17 : 0.28) : 0;
      var hBn = showBn ? (showAr ? avail - hAr - hTr - 64 : avail - hTr - 30) : 0;
      var y = top;
      if (showAr) {
        ctx.direction = 'rtl'; ctx.textAlign = 'center';
        var ar = fit(ctx, data.ar, function (s) { return s + 'px PtCardAr, serif'; }, 880, hAr - 24, 1.95, rest ? 96 : 132, 30);
        cut.ar = ar.cut;
        ctx.font = ar.size + 'px PtCardAr, serif'; ctx.fillStyle = th.ink; ctx.strokeStyle = th.ink; ctx.lineWidth = Math.max(.7, ar.size / 60);
        var yy = y + (hAr - ar.h) / 2 + ar.size * 1.25;
        ar.lines.forEach(function (ln, i) { var ly2 = yy + i * ar.size * 1.95; ctx.fillText(ln, W / 2, ly2); ctx.strokeText(ln, W / 2, ly2); });
        y += hAr; ctx.direction = 'ltr'; ctx.lineWidth = 1;
        if (rest) { rule(ctx, th, y + 20, 250); y += 64; }
      }
      ctx.direction = 'ltr'; ctx.textAlign = 'center';
      if (showTr) {
        var tr = fit(ctx, data.tr, function (s) { return 'italic 400 ' + s + 'px PtCardBn, sans-serif'; }, 860, hTr, 1.5, 38, 22);
        cut.tr = tr.cut;
        ctx.font = 'italic 400 ' + tr.size + 'px PtCardBn, sans-serif'; ctx.fillStyle = th.gold;
        tr.lines.forEach(function (ln, i) { ctx.fillText(ln, W / 2, y + tr.size * 1.1 + i * tr.size * 1.5); });
        y += hTr;
      }
      if (showBn) {
        var bt = fit(ctx, data.bn, function (s) { return '400 ' + s + 'px PtCardBn, sans-serif'; }, 840, hBn, 1.62, 44, 24);
        cut.bn = bt.cut;
        ctx.font = '400 ' + bt.size + 'px PtCardBn, sans-serif'; ctx.fillStyle = th.ink;
        var by = y + (hBn - bt.h) / 2 + bt.size * 1.1;
        bt.lines.forEach(function (ln, i) { ctx.fillText(ln, W / 2, by + i * bt.size * 1.62); });
      }
      c._cut = !!(cut.ar || cut.tr || cut.bn);

      /* ── ফুটার ── */
      ctx.textAlign = 'center';
      function refLine(cx, baseY, maxW) {
        if (!data.ref) return;
        var rf = fit(ctx, data.ref, function (s) { return '700 ' + s + 'px ' + SERIF; }, maxW, 44, 1.2, 34, 24);
        ctx.font = '700 ' + rf.size + 'px ' + SERIF; var rw = ctx.measureText(rf.lines[0]).width;
        ctx.textAlign = 'center'; ctx.fillStyle = th.gold; ctx.fillText(rf.lines[0], cx, baseY);
        ctx.save(); ctx.translate(cx - rw / 2 - 30, baseY - 11); ctx.rotate(Math.PI / 4); ctx.fillRect(-5, -5, 10, 10); ctx.restore();
        ctx.save(); ctx.translate(cx + rw / 2 + 30, baseY - 11); ctx.rotate(Math.PI / 4); ctx.fillRect(-5, -5, 10, 10); ctx.restore();
      }
      refLine(W / 2, H - 196, 820);
      ctx.globalAlpha = .14; ctx.fillStyle = th.ink; ctx.fillRect(M, H - 144, W - M * 2, 2); ctx.globalAlpha = 1;
      if (usr) {
        /* v292: আগে যে লাইনে URL ছিল সেই লাইনেই — মাঝখানে: বাঁয়ে ছোট গোল-কোনা ছবি, তার ডানে নাম */
        var showPhoto = (who === 'both'), PS = showPhoto ? 56 : 0, gap = showPhoto ? 18 : 0;
        ctx.font = '500 28px PtCardBn, PtCardLat, Inter, sans-serif'; spaced(ctx, 0);
        var nm = ellipsize(ctx, usr.name, 640);
        var nwid = ctx.measureText(nm).width, tot = PS + gap + nwid, sx = Math.round(W / 2 - tot / 2), cy = H - 98;
        if (showPhoto) drawAvatar(ctx, th, uimg, usr.name, sx, cy - PS / 2, PS, 15);
        ctx.fillStyle = th.mut; ctx.textAlign = 'left'; ctx.fillText(nm, sx + PS + gap, H - 88);
        spaced(ctx, 0); ctx.textAlign = 'center';
      } else {
        ctx.fillStyle = th.mut; ctx.font = '500 28px PtCardLat, Inter, sans-serif'; spaced(ctx, 0);
        ctx.fillText('patheyobygunjoron.github.io', W / 2, H - 88); spaced(ctx, 0);
      }
      return c;
    });
  }

  /* ---------- UI ---------- */
  /* v296: নতুন ডিজাইন — প্রিভিউ সবসময় ওপরে, শেয়ার/সেভ সবসময় নিচে (স্ক্রল ছাড়াই), মাঝখানে ৪টি টুল (রঙ · ছবি · লেখা · নিচের অংশ)।
     সেটিংগুলো শুরুতে লুকানো; টুলে চাপলে সেটার প্যানেল নিচে খোলে (এক সময়ে একটি), আবার চাপলে বন্ধ হয়। */
  var css = ''
    + '.pcs-veil{position:fixed;inset:0;background:rgba(5,8,15,.62);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);opacity:0;pointer-events:none;transition:opacity .3s;z-index:1990}'
    + '.pcs-veil.on{opacity:1;pointer-events:auto}'
    + '.pcs-sheet{position:fixed;left:50%;top:50%;bottom:auto;width:min(calc(100% - 24px),460px);max-height:calc(100svh - 40px - env(safe-area-inset-top,0px) - env(safe-area-inset-bottom,0px));display:flex;flex-direction:column;overflow:hidden;opacity:0;pointer-events:none;transform:translate(-50%,-46%) scale(.95);transition:transform .36s cubic-bezier(.34,1.56,.64,1),opacity .24s ease;z-index:2000;box-shadow:0 24px 60px -20px rgba(0,0,0,.45);'
    + 'background:#FFFFFF;color:#111827;border-radius:28px;padding:0;border:1px solid rgba(17,24,39,.09);font-family:\"NotoSerifByGunjoron\",Inter,sans-serif;box-sizing:border-box}'
    + '[data-theme=\"dark\"] .pcs-sheet{background:#1A2333;color:#F1F4F9;border-color:rgba(255,255,255,.08)}'
    + '[data-theme=\"sepia\"] .pcs-sheet{background:#F6EDD9;color:#3F331E;border-color:rgba(92,66,30,.2)}'
    + '.pcs-sheet.on{transform:translate(-50%,-50%) scale(1);opacity:1;pointer-events:auto}'
    + '.pcs-sheet [hidden]{display:none!important}'
    + '.pcs-sheet button{-webkit-tap-highlight-color:transparent}'
    + '.pcs-sheet button:focus-visible,.pcs-sheet input:focus-visible{outline:2px solid #0E7BB8;outline-offset:2px}'
    /* হেডার */
    + '.pcs-hd{flex:none;display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px 20px}'
    + '.pcs-t{font-size:19px;font-weight:700}'
    + '.pcs-x{width:36px;height:36px;border:0;border-radius:50%;background:rgba(127,140,170,.2);color:inherit;display:grid;place-items:center;cursor:pointer;padding:0}'
    + '.pcs-x svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round}'
    /* প্রিভিউ (সবসময় দেখা যায়; প্যানেল খুললে একটু ছোট হয়ে জায়গা দেয়) */
    + '.pcs-prev{flex:none;display:grid;place-items:center;background:rgba(127,140,170,.12);border-radius:22px;padding:12px;margin:0 16px;min-height:120px}'
    + '.pcs-prev canvas{display:block;width:auto;height:auto;max-width:100%;max-height:max(110px,min(44svh,calc(100svh - 350px)));border-radius:14px;box-shadow:0 18px 34px -16px rgba(0,0,0,.6);transition:max-height .34s cubic-bezier(.2,.8,.2,1)}'
    + '.pcs-open .pcs-prev canvas{max-height:max(100px,min(24svh,calc(100svh - 520px)))}'
    /* মাঝের অংশ (শুধু এটাই স্ক্রল হয়) */
    + '.pcs-ctl{flex:1 1 auto;min-height:0;overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding:0 16px 8px}'
    + '.pcs-hint{display:flex;gap:8px;align-items:flex-start;font-size:13.5px;line-height:1.5;background:rgba(224,160,40,.16);border-radius:12px;padding:9px 11px;margin:10px 0 0}'
    + '.pcs-hint svg{flex:none;width:17px;height:17px;margin-top:2px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;opacity:.8}'
    + '.pcs-sec{display:flex;align-items:baseline;justify-content:space-between;margin:14px 4px 8px;font-size:14px;font-weight:700}'
    + '.pcs-sec span{opacity:.78}.pcs-sec small{font-size:12.5px;font-weight:500;opacity:.55}'
    /* টুল-টাইল */
    + '.pcs-tools{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:8px}'
    + '.pcs-tool{font-family:inherit;color:inherit;display:flex;flex-direction:column;align-items:center;gap:3px;padding:10px 4px 9px;border-radius:16px;border:1.5px solid transparent;background:rgba(127,140,170,.14);cursor:pointer;min-width:0;transition:background-color .2s,border-color .2s,transform .15s}'
    + '.pcs-tool:active{transform:scale(.96)}'
    + '.pcs-tool i{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:rgba(127,140,170,.22);margin-bottom:3px;transition:background-color .2s,color .2s}'
    + '.pcs-tool i svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}'
    + '.pcs-tool b{font-size:14px;font-weight:700;line-height:1.2;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
    + '.pcs-tool small{font-size:11.5px;opacity:.66;line-height:1.25;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
    + '.pcs-tool.on{background:rgba(14,123,184,.14);border-color:#0E7BB8}'
    /* প্যানেল খোলা থাকলে টাইলগুলো ছোট হয়ে জায়গা ছাড়ে, যাতে সব সেটিং এক নজরে ধরে */
    + '.pcs-open .pcs-sec{display:none}.pcs-open .pcs-tools{margin-top:12px}'
    + '.pcs-open .pcs-tool{padding:8px 4px 7px;gap:2px}.pcs-open .pcs-tool small{display:none}'
    + '.pcs-open .pcs-tool i{width:28px;height:28px;margin-bottom:0;border-radius:9px}.pcs-open .pcs-tool i svg{width:17px;height:17px}'
    + '.pcs-tool,.pcs-tool i{transition:background-color .2s,color .2s,padding .3s,width .3s,height .3s}'
    + '.pcs-tool.on i{background:#0E7BB8;color:#fff}'
    /* খোলা-বন্ধ হওয়া প্যানেল */
    + '.pcs-pn{display:grid;grid-template-rows:0fr;visibility:hidden;transition:grid-template-rows .34s cubic-bezier(.2,.8,.2,1),visibility 0s .34s}'
    + '.pcs-pn.on{grid-template-rows:1fr;visibility:visible;transition:grid-template-rows .34s cubic-bezier(.2,.8,.2,1),visibility 0s}'
    + '.pcs-pn>div{overflow:hidden;min-height:0}'
    + '.pcs-pc{margin-top:10px;padding:12px 14px 14px;border-radius:18px;background:rgba(127,140,170,.1)}'
    + '.pcs-ph{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}'
    + '.pcs-ph b{font-size:14px;font-weight:700}'
    + '.pcs-pcl{width:30px;height:30px;border:0;border-radius:50%;background:rgba(127,140,170,.2);color:inherit;display:grid;place-items:center;cursor:pointer;padding:0}'
    + '.pcs-pcl svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}'
    /* রঙের থিম: ৩×২ গ্রিড — সবকটা একসাথে দেখা যায় */
    + '.pcs-th{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px 10px}'
    + '.pcs-th button{font-family:inherit;color:inherit;background:none;border:0;padding:0;display:flex;flex-direction:column;align-items:center;gap:7px;cursor:pointer;font-size:13.5px;font-weight:600;opacity:.82;min-width:0}'
    + '.pcs-th i{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;width:100%;height:56px;border-radius:15px;border:2px solid transparent;box-shadow:0 0 0 1px rgba(127,140,170,.4) inset;font-style:normal;transition:box-shadow .2s,border-color .2s}'
    + '.pcs-th i em{font-style:normal;font-size:21px;font-weight:700;line-height:1}'
    + '.pcs-th i s{display:block;width:20px;height:3px;border-radius:3px}'
    + '.pcs-th button.on{opacity:1;font-weight:700}'
    + '.pcs-th button.on i{border-color:#0E7BB8;box-shadow:0 0 0 3px rgba(14,123,184,.28)}'
    + '.pcs-th button.on i::after{content:\"\";position:absolute;top:-7px;right:-7px;width:19px;height:19px;border-radius:50%;background:#0E7BB8 url(\"data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23fff%27 stroke-width=%273.4%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27%3E%3Cpath d=%27M5 12.5l4.5 4.5L19 7.5%27/%3E%3C/svg%3E\") center/12px no-repeat}'
    /* ব্যাকগ্রাউন্ড ছবি */
    + '.pcs-drop{width:100%;font-family:inherit;color:inherit;display:flex;flex-direction:column;align-items:center;gap:4px;padding:18px 12px;border-radius:16px;border:1.5px dashed rgba(14,123,184,.7);background:rgba(14,123,184,.07);cursor:pointer}'
    + '.pcs-drop svg{width:28px;height:28px;fill:none;stroke:#0E7BB8;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;margin-bottom:2px}'
    + '.pcs-drop b{font-size:14.5px;font-weight:700}.pcs-drop small{font-size:12.5px;opacity:.65;line-height:1.4;text-align:center}'
    + '.pcs-cur{display:flex;align-items:center;gap:12px}'
    + '.pcs-thumb{flex:none;width:52px;height:52px;border-radius:13px;object-fit:cover;box-shadow:0 0 0 1px rgba(127,140,170,.4)}'
    + '.pcs-cur>span{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.pcs-cur b{font-size:14px;font-weight:700}.pcs-cur small{font-size:12.5px;opacity:.65}'
    + '.pcs-cb{flex:none;display:flex;gap:6px}'
    + '.pcs-cb button{font-family:inherit;font-size:14px;font-weight:700;color:inherit;background:rgba(127,140,170,.24);border:0;border-radius:999px;padding:8px 13px;cursor:pointer}'
    + '.pcs-cb button.pcs-rm{background:rgba(220,60,60,.14);color:#C93232}'
    + '[data-theme=\"dark\"] .pcs-cb button.pcs-rm{color:#FF8A8A}'
    + '.pcs-sl{display:grid;grid-template-columns:76px minmax(0,1fr) 40px;align-items:center;gap:2px 8px;margin-top:10px;padding-top:6px;border-top:1px solid rgba(127,140,170,.2);font-size:14px;font-weight:600}'
    + '.pcs-sl label{opacity:.82}.pcs-sl output{text-align:right;font-size:13px;font-weight:700;opacity:.7;font-variant-numeric:tabular-nums}'
    + '.pcs-sl input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:30px;margin:0;background:transparent;--f1:0%;--f2:50%}'
    + '.pcs-sl input[type=range]::-webkit-slider-runnable-track{height:6px;border-radius:99px;background:linear-gradient(to right,rgba(127,140,170,.38) var(--f1),#0E7BB8 var(--f1),#0E7BB8 var(--f2),rgba(127,140,170,.38) var(--f2))}'
    + '.pcs-sl input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:22px;height:22px;border-radius:50%;background:#fff;border:2px solid #0E7BB8;margin-top:-8px;box-shadow:0 2px 6px rgba(0,0,0,.28)}'
    + '.pcs-sl input[type=range]::-moz-range-track{height:6px;border-radius:99px;background:linear-gradient(to right,rgba(127,140,170,.38) var(--f1),#0E7BB8 var(--f1),#0E7BB8 var(--f2),rgba(127,140,170,.38) var(--f2))}'
    + '.pcs-sl input[type=range]::-moz-range-thumb{width:18px;height:18px;border-radius:50%;background:#fff;border:2px solid #0E7BB8;box-shadow:0 2px 6px rgba(0,0,0,.28)}'
    + '.pcs-rs{grid-column:1/-1;justify-self:start;display:flex;align-items:center;gap:6px;font-family:inherit;font-size:14px;font-weight:600;color:inherit;background:none;border:0;opacity:.75;cursor:pointer;padding:6px 2px 0}'
    + '.pcs-rs svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}'
    /* কার্ডে যা থাকবে: অন/অফ সুইচ */
    + '.pcs-row{width:100%;font-family:inherit;color:inherit;background:none;border:0;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 2px;text-align:left;cursor:pointer}'
    + '.pcs-row+.pcs-row{border-top:1px solid rgba(127,140,170,.2)}'
    + '.pcs-row span{display:flex;flex-direction:column;gap:1px}.pcs-row b{font-size:15px;font-weight:700}.pcs-row small{font-size:12.5px;opacity:.62}'
    + '.pcs-sw{flex:none;position:relative;width:46px;height:28px;border-radius:999px;background:rgba(127,140,170,.5);transition:background-color .2s}'
    + '.pcs-sw::after{content:\"\";position:absolute;top:3px;left:3px;width:22px;height:22px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:transform .22s cubic-bezier(.34,1.4,.64,1)}'
    + '.pcs-row[aria-checked=true] .pcs-sw{background:#0E7BB8}.pcs-row[aria-checked=true] .pcs-sw::after{transform:translateX(18px)}'
    /* কার্ডের নিচে: রেডিও-কার্ড */
    + '.pcs-opt{width:100%;font-family:inherit;color:inherit;display:flex;align-items:center;gap:12px;text-align:left;background:rgba(127,140,170,.12);border:1.5px solid transparent;border-radius:14px;padding:11px 12px;cursor:pointer;transition:background-color .2s,border-color .2s}'
    + '.pcs-opt+.pcs-opt{margin-top:8px}'
    + '.pcs-opt .rd{flex:none;position:relative;width:20px;height:20px;border-radius:50%;border:2px solid rgba(127,140,170,.75);box-sizing:border-box;transition:border-color .2s}'
    + '.pcs-opt .rd::after{content:\"\";position:absolute;inset:3px;border-radius:50%;background:#0E7BB8;transform:scale(0);transition:transform .2s cubic-bezier(.34,1.5,.64,1)}'
    + '.pcs-opt span:not(.rd){display:flex;flex-direction:column;gap:1px;min-width:0}.pcs-opt b{font-size:14.5px;font-weight:700}.pcs-opt small{font-size:12.5px;opacity:.64;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
    + '.pcs-opt.on{background:rgba(14,123,184,.13);border-color:#0E7BB8}.pcs-opt.on .rd{border-color:#0E7BB8}.pcs-opt.on .rd::after{transform:scale(1)}'
    /* নিচের স্থির অংশ: শেয়ার / সেভ / কপি */
    + '.pcs-ft{flex:none;padding:12px 16px 10px;border-top:1px solid rgba(127,140,170,.2)}'
    + '.pcs-ac{display:grid;grid-template-columns:1.6fr 1fr;gap:10px}'
    + '.pcs-ac button{font-family:inherit;font-size:16px;font-weight:700;border-radius:999px;padding:14px 10px;cursor:pointer;border:0;display:flex;align-items:center;justify-content:center;gap:8px}'
    + '.pcs-ac svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}'
    + '.pcs-go{background:linear-gradient(150deg,#235FFE,#0E4FD0);color:#fff;box-shadow:0 14px 24px -14px #235FFE}.pcs-sv{background:rgba(127,140,170,.22);color:inherit}'
    + '.pcs-ac button[disabled]{opacity:.55}'
    + '.pcs-cp{display:flex;align-items:center;justify-content:center;gap:6px;margin:6px auto 0;font-family:inherit;font-size:14.5px;font-weight:600;background:none;border:0;color:inherit;opacity:.72;cursor:pointer;padding:6px 10px}'
    + '.pcs-cp svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}'
    + '.pcs-msg{position:fixed;left:50%;top:calc(env(safe-area-inset-top,0px) + 72px);bottom:auto;transform:translate(-50%,-14px);opacity:0;pointer-events:none;z-index:2100;background:#0A1C46;color:#fff;font-family:\"NotoSerifByGunjoron\",Inter,sans-serif;font-size:14px;font-weight:600;padding:11px 18px;border-radius:14px;transition:opacity .22s,transform .22s;max-width:calc(100% - 40px);text-align:center}'
    + '.pcs-msg.show{opacity:1;transform:translate(-50%,0)}'
    + 'html.pcs-lock,html.pcs-lock body{overflow:hidden}'
    + '@media (prefers-reduced-motion:reduce){.pcs-sheet,.pcs-veil,.pcs-msg,.pcs-pn,.pcs-prev canvas,.pcs-sw,.pcs-sw::after,.pcs-tool{transition:none}}';

  var UI = null, cur = null, st = { theme: 'night', ar: true, tr: false, bn: true, who: 'both', bg: { v: BG_DEF.v, b: BG_DEF.b, z: BG_DEF.z, x: BG_DEF.x, y: BG_DEF.y } }, bgData = bgLoad(), opened = false, renderTick = 0, lastCanvas = null;
  try { var sv = JSON.parse(localStorage.getItem('pt_share_card') || 'null'); if (sv) { if (THEMES.some(function (t) { return t.id === sv.theme; })) st.theme = sv.theme; if (typeof sv.ar === 'boolean') st.ar = sv.ar; if (typeof sv.tr === 'boolean') st.tr = sv.tr; if (typeof sv.bn === 'boolean') st.bn = sv.bn; if (sv.who === 'both' || sv.who === 'name' || sv.who === 'none') st.who = sv.who; if (sv.bg && typeof sv.bg === 'object') ['v', 'b', 'z', 'x', 'y'].forEach(function (k) { if (typeof sv.bg[k] === 'number' && isFinite(sv.bg[k])) st.bg[k] = sv.bg[k]; }); } } catch (e) {}
  function persist() { try { localStorage.setItem('pt_share_card', JSON.stringify(st)); } catch (e) {} }

  function bridge() { return window.PatheyoShare || (window.parent && window.parent !== window && window.parent.PatheyoShare) || null; }

  var msgT = 0;
  function msg(t) { var m = UI.msg; m.textContent = t; m.classList.add('show'); clearTimeout(msgT); msgT = setTimeout(function () { m.classList.remove('show'); }, 2200); }

  /* ---------- v296: আইকন ও টুল-প্যানেল ---------- */
  function ic(d) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + d + '</svg>'; }
  var IC = {
    theme: ic('<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.3 0 2-.9 2-1.9 0-.6-.3-1-.5-1.4-.3-.4-.5-.8-.5-1.3 0-.9.7-1.6 1.6-1.6H17a3.5 3.5 0 0 0 3.5-3.5c0-4.1-3.8-7.3-8.5-7.3zM7.6 11.3h.01M10.4 7.5h.01M15 7.8h.01"/>'),
    bg: ic('<rect x="3.5" y="4.5" width="17" height="15" rx="3.2"/><path d="M3.5 16l4.8-4.6 3.6 3.4 3-2.8 5.6 4.9M15.8 9.2h.01"/>'),
    text: ic('<path d="M4 6.5h16M4 12h10M4 17.5h13"/>'),
    foot: ic('<rect x="3.5" y="4" width="17" height="16" rx="3.2"/><path d="M3.5 15h17M7 17.5h4"/>'),
    up: ic('<path d="M6 14.5l6-6 6 6"/>'),
    info: ic('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.8h.01"/>'),
    add: ic('<rect x="3.5" y="4.5" width="17" height="15" rx="3.2"/><path d="M3.5 16l4.8-4.6 3.6 3.4 2-1.9M17 7.5v5M14.5 10h5"/>'),
    reset: ic('<path d="M20 12a8 8 0 1 1-2.4-5.7M20 4v5h-5"/>'),
    copy: ic('<rect x="8.5" y="8.5" width="11" height="11" rx="2.6"/><path d="M15.5 8.5v-2a2.6 2.6 0 0 0-2.6-2.6H6.6A2.6 2.6 0 0 0 4 6.5v6.3a2.6 2.6 0 0 0 2.6 2.6h1.9"/>')
  };
  var PANEL_T = { theme: 'রঙের থিম', bg: 'ব্যাকগ্রাউন্ড ছবি', text: 'কার্ডে যা থাকবে', foot: 'কার্ডের নিচে' };
  var tool = '';   /* এখন কোন প্যানেল খোলা ('' = সব বন্ধ) */
  function setTool(k, instant) {
    if (!UI) return;
    if (!instant && k && k === tool) k = '';                      /* একই টুলে আবার চাপলে বন্ধ */
    tool = k || '';
    Array.prototype.forEach.call(UI.tools.children, function (b) { var on = b.getAttribute('data-tool') === tool; b.classList.toggle('on', on); b.setAttribute('aria-expanded', on ? 'true' : 'false'); });
    if (tool) {                                                    /* বন্ধ হওয়ার সময় আগের প্যানেলই থাকে, তাই বন্ধের অ্যানিমেশন খালি দেখায় না */
      Array.prototype.forEach.call(UI.pn.querySelectorAll('.pcs-p'), function (p) { p.hidden = p.getAttribute('data-p') !== tool; });
      UI.pt.textContent = PANEL_T[tool];
    }
    UI.pn.classList.toggle('on', !!tool);
    UI.sheet.classList.toggle('pcs-open', !!tool);
    if (tool && !instant) setTimeout(function () { try { UI.pn.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} }, 360);
  }
  function slFmt(k, v) {
    if (k === 'z') return bn(v) + '%';
    if (k === 'b') return bn(v);
    return (v < 0 ? '−' : '') + bn(Math.abs(v));
  }
  function slPaint(r) {                                            /* স্লাইডারের রঙিন অংশ (−/+ হলে মাঝ থেকে) */
    var mn = +r.min, mx = +r.max, p = (r.value - mn) / (mx - mn) * 100, bi = mn < 0;
    r.style.setProperty('--f1', (bi ? Math.min(p, 50) : 0) + '%'); r.style.setProperty('--f2', (bi ? Math.max(p, 50) : p) + '%');
    var k = r.getAttribute('data-sl'), o = r.parentNode.querySelector('output[data-o="' + k + '"]'); if (o) o.textContent = slFmt(k, +r.value);
  }

  function build() {
    var style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);
    var veil = document.createElement('div'); veil.className = 'pcs-veil';
    var sheet = document.createElement('div'); sheet.className = 'pcs-sheet'; sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'শেয়ার কার্ড');
    var m = document.createElement('div'); m.className = 'pcs-msg'; m.setAttribute('role', 'status');
    function tile(id, label) { return '<button type="button" class="pcs-tool" data-tool="' + id + '" aria-expanded="false"><i>' + IC[id] + '</i><b>' + label + '</b><small data-sum></small></button>'; }
    sheet.innerHTML =
      '<div class="pcs-hd"><div class="pcs-t">শেয়ার কার্ড</div><button type="button" class="pcs-x" aria-label="বন্ধ করুন"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>' +
      '<div class="pcs-prev"></div>' +
      '<div class="pcs-ctl">' +
        '<div class="pcs-hint" style="display:none">' + IC.info + '<span>লেখা বড় হওয়ায় কার্ডে সংক্ষেপে দেখানো হয়েছে। পুরো লেখা লাগলে নিচের “শুধু লেখা কপি করুন” চাপুন, অথবা আরবি বা অর্থের যেকোনো একটি বন্ধ করে দিন।</span></div>' +
        '<div class="pcs-sec"><span>কার্ড সাজান</span><small>চাপলে খুলবে</small></div>' +
        '<div class="pcs-tools">' + tile('theme', 'রঙ') + tile('bg', 'ছবি') + tile('text', 'লেখা') + tile('foot', 'নিচের অংশ') + '</div>' +
        '<div class="pcs-pn"><div><div class="pcs-pc">' +
          '<div class="pcs-ph"><b class="pcs-pt"></b><button type="button" class="pcs-pcl" aria-label="লুকান">' + IC.up + '</button></div>' +
          '<div class="pcs-p" data-p="theme" hidden><div class="pcs-th"></div></div>' +
          '<div class="pcs-p" data-p="bg" hidden>' +
            '<button type="button" class="pcs-drop" data-bg="pick">' + IC.add + '<b>গ্যালারি থেকে ছবি বেছে নিন</b><small>ছবি একটু অন্ধকার হয়ে বসবে, যাতে লেখা পরিষ্কার পড়া যায়</small></button>' +
            '<div class="pcs-cur" hidden><img class="pcs-thumb" alt=""><span><b>ছবি যোগ করা হয়েছে</b><small>নিচে থেকে ঠিক করে নিন</small></span><div class="pcs-cb"><button type="button" data-bg="pick">বদলান</button><button type="button" class="pcs-rm" data-bg="clear">সরান</button></div></div>' +
            '<div class="pcs-sl" hidden>' +
              '<label>উজ্জ্বলতা</label><input type="range" data-sl="v" min="-100" max="100" step="1"><output data-o="v"></output>' +
              '<label>ঝাপসা</label><input type="range" data-sl="b" min="0" max="40" step="1"><output data-o="b"></output>' +
              '<label>জুম</label><input type="range" data-sl="z" min="100" max="300" step="1"><output data-o="z"></output>' +
              '<label>বামে-ডানে</label><input type="range" data-sl="x" min="-100" max="100" step="1"><output data-o="x"></output>' +
              '<label>উপরে-নিচে</label><input type="range" data-sl="y" min="-100" max="100" step="1"><output data-o="y"></output>' +
              '<button type="button" class="pcs-rs" data-bg="reset">' + IC.reset + '<span>সব ঠিক করুন</span></button>' +
            '</div><input type="file" class="pcs-file" accept="image/*" hidden>' +
          '</div>' +
          '<div class="pcs-p pcs-tg" data-p="text" hidden></div>' +
          '<div class="pcs-p pcs-wh" data-p="foot" hidden></div>' +
        '</div></div></div>' +
      '</div>' +
      '<div class="pcs-ft"><div class="pcs-ac"><button type="button" class="pcs-go"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6.5" cy="12" r="2.3"/><circle cx="17.5" cy="6.5" r="2.3"/><circle cx="17.5" cy="17.5" r="2.3"/><path d="M8.5 10.9l7-3.3M8.5 13.1l7 3.3"/></svg><span>শেয়ার করুন</span></button>' +
      '<button type="button" class="pcs-sv"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19h14"/></svg><span>সেভ</span></button></div>' +
      '<button type="button" class="pcs-cp">' + IC.copy + '<span>শুধু লেখা কপি করুন</span></button></div>';
    document.body.appendChild(veil); document.body.appendChild(sheet); document.body.appendChild(m);
    UI = { veil: veil, sheet: sheet, msg: m, prev: sheet.querySelector('.pcs-prev'), hint: sheet.querySelector('.pcs-hint'),
           tools: sheet.querySelector('.pcs-tools'), pn: sheet.querySelector('.pcs-pn'), pt: sheet.querySelector('.pcs-pt'),
           th: sheet.querySelector('.pcs-th'), tg: sheet.querySelector('.pcs-tg'), wh: sheet.querySelector('.pcs-wh'),
           drop: sheet.querySelector('.pcs-drop'), curbg: sheet.querySelector('.pcs-cur'), thumb: sheet.querySelector('.pcs-thumb'),
           sl: sheet.querySelector('.pcs-sl'), file: sheet.querySelector('.pcs-file'), ac: sheet.querySelector('.pcs-ac'),
           go: sheet.querySelector('.pcs-go'), sv: sheet.querySelector('.pcs-sv'), cp: sheet.querySelector('.pcs-cp') };
    UI.th.innerHTML = THEMES.map(function (t) {
      return '<button type="button" data-th="' + t.id + '"><i style="background:linear-gradient(135deg,' + t.bg[0] + ',' + t.bg[1] + ');color:' + t.ink + '"><em>আ</em><s style="background:' + t.gold + '"></s></i><span>' + t.n + '</span></button>';
    }).join('');
    veil.addEventListener('click', requestClose);
    sheet.querySelector('.pcs-x').addEventListener('click', requestClose);
    UI.tools.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-tool]') : null; if (b) setTool(b.getAttribute('data-tool')); });
    sheet.querySelector('.pcs-pcl').addEventListener('click', function () { setTool(''); });
    UI.th.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-th]') : null; if (!b) return; st.theme = b.getAttribute('data-th'); persist(); sync(); redraw(); });
    UI.tg.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-tg]') : null; if (!b) return; var k = b.getAttribute('data-tg'); var nx = !st[k]; var left = [k === 'ar' ? nx : st.ar, k === 'tr' ? nx : (st.tr && cur.tr), k === 'bn' ? nx : (st.bn && cur.bn)].some(Boolean); if (!left) { msg('অন্তত একটি অংশ রাখতে হবে'); return; } st[k] = nx; persist(); sync(); redraw(); });
    UI.wh.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-wh]') : null; if (!b) return; st.who = b.getAttribute('data-wh'); persist(); sync(); redraw(); });
    var redrawT = 0;
    function redrawSoon() { if (redrawT) return; redrawT = requestAnimationFrame(function () { redrawT = 0; redraw(); }); }
    function bgReset() { st.bg = { v: BG_DEF.v, b: BG_DEF.b, z: BG_DEF.z, x: BG_DEF.x, y: BG_DEF.y }; }
    UI.pn.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-bg]') : null; if (!b) return;
      var a = b.getAttribute('data-bg');
      if (a === 'pick') UI.file.click();
      else if (a === 'clear') { bgData = ''; bgCache = { src: null, img: null }; bgSave(''); sync(); redraw(); }
      else if (a === 'reset') { bgReset(); persist(); sync(); redraw(); }
    });
    UI.sl.addEventListener('input', function (e) { var k = e.target.getAttribute && e.target.getAttribute('data-sl'); if (!k) return; st.bg[k] = +e.target.value; slPaint(e.target); redrawSoon(); });
    UI.sl.addEventListener('change', persist);
    UI.file.addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
      msg('ছবি তৈরি হচ্ছে…');
      bgFromFile(f).then(function (d) {
        if (!d) { msg('ছবিটি খোলা যায়নি — অন্য ছবি দিন'); return; }
        bgData = d; bgCache = { src: null, img: null }; bgSave(d);
        bgReset(); persist(); sync(); redraw();
      });
    });
    UI.go.addEventListener('click', doShare);
    UI.sv.addEventListener('click', doSave);
    UI.cp.addEventListener('click', doCopy);
    window.addEventListener('popstate', function () { if (opened) hide(); });
  }

  function sum(id, t) { var s = UI.tools.querySelector('[data-tool="' + id + '"] [data-sum]'); if (s) s.textContent = t; }
  function sync() {
    var u = userInfo(), hasU = !!(u && u.name), hasTxt = !!(cur.tr || cur.bn);
    /* "লেখা" টুল শুধু তখনই, যখন উচ্চারণ/অর্থ আছে; "নিচের অংশ" শুধু তখনই, যখন অ্যাকাউন্ট খোলা ও নাম আছে */
    UI.tools.querySelector('[data-tool="text"]').style.display = hasTxt ? '' : 'none';
    UI.tools.querySelector('[data-tool="foot"]').style.display = hasU ? '' : 'none';
    if ((tool === 'text' && !hasTxt) || (tool === 'foot' && !hasU)) setTool('', true);
    /* রঙ */
    Array.prototype.forEach.call(UI.th.children, function (b) { b.classList.toggle('on', b.getAttribute('data-th') === st.theme); });
    var tn = ''; THEMES.forEach(function (t) { if (t.id === st.theme) tn = t.n; }); sum('theme', tn);
    /* ব্যাকগ্রাউন্ড ছবি */
    UI.drop.hidden = !!bgData; UI.curbg.hidden = UI.sl.hidden = !bgData;
    if (bgData && UI._tb !== bgData) { UI.thumb.src = bgData; UI._tb = bgData; }
    Array.prototype.forEach.call(UI.sl.querySelectorAll('[data-sl]'), function (r) { r.value = st.bg[r.getAttribute('data-sl')]; slPaint(r); });
    sum('bg', bgData ? 'যোগ করা' : 'নেই');
    /* কার্ডে যা থাকবে */
    var rows = [['ar', 'আরবি', 'মূল আরবি লেখা']];
    if (cur.tr) rows.push(['tr', 'উচ্চারণ', 'বাংলায় আরবির উচ্চারণ']);
    if (cur.bn) rows.push(['bn', 'অর্থ', 'বাংলা অনুবাদ']);
    UI.tg.innerHTML = rows.map(function (r) {
      return '<button type="button" class="pcs-row" role="switch" aria-checked="' + (st[r[0]] ? 'true' : 'false') + '" data-tg="' + r[0] + '"><span><b>' + r[1] + '</b><small>' + r[2] + '</small></span><i class="pcs-sw"></i></button>';
    }).join('');
    var parts = []; if (st.ar) parts.push('আরবি'); if (st.tr && cur.tr) parts.push('উচ্চারণ'); if (st.bn && cur.bn) parts.push('অর্থ');
    sum('text', parts.length > 2 ? 'সব কিছু' : parts.join(' + '));
    /* কার্ডের নিচে */
    if (hasU) {
      var WO = [['both', 'ছবি ও নাম', 'প্রোফাইল ছবি ও আপনার নাম', 'ছবি ও নাম'], ['name', 'শুধু নাম', 'শুধু আপনার নাম', 'শুধু নাম'], ['none', 'ওয়েবসাইটের লিংক', 'patheyobygunjoron.github.io', 'লিংক']];
      UI.wh.innerHTML = WO.map(function (o) {
        return '<button type="button" class="pcs-opt' + (st.who === o[0] ? ' on' : '') + '" role="radio" aria-checked="' + (st.who === o[0] ? 'true' : 'false') + '" data-wh="' + o[0] + '"><span class="rd"></span><span><b>' + o[1] + '</b><small>' + o[2] + '</small></span></button>';
      }).join('');
      WO.forEach(function (o) { if (o[0] === st.who) sum('foot', o[3]); });
    }
    var b = bridge(), noSave = !!(b && typeof b.canSave === 'function' && !b.canSave());
    UI.sv.style.display = noSave ? 'none' : ''; UI.ac.style.gridTemplateColumns = noSave ? '1fr' : '';
  }

  function redraw() {
    var my = ++renderTick;
    render(cur, { theme: st.theme, ar: st.ar, tr: st.tr, bn: st.bn, who: st.who, bg: bgData ? { data: bgData, v: st.bg.v / 100, blur: st.bg.b, zoom: st.bg.z / 100, x: st.bg.x, y: st.bg.y } : null }).then(function (c) {
      if (my !== renderTick) return;
      lastCanvas = c; UI.prev.innerHTML = ''; UI.prev.appendChild(c);
      UI.hint.style.display = c._cut ? '' : 'none';
    });
  }

  function pngB64() { return lastCanvas ? lastCanvas.toDataURL('image/png') : null; }
  function textOf() {
    var s = (cur.title ? cur.title + '\n\n' : '') + cur.ar;
    if (!st.ar) s = (cur.title ? cur.title + '\n\n' : '') + (st.bn && cur.bn ? '' : cur.ar);
    if (st.tr && cur.tr) s += '\n\nউচ্চারণ: ' + cur.tr;
    if (st.bn && cur.bn) s += '\n\nঅর্থ: ' + cur.bn;
    if (cur.ref) s += '\n\n(' + cur.ref + ')';
    return s + '\n\n— পাথেয় বাই গুঞ্জরণ\npatheyobygunjoron.github.io';
  }
  function fname() { return 'patheyo_' + (cur.kind || 'card') + '_' + Date.now(); }
  function dataUrlToBlob(u) { var p = u.split(','), mime = /:(.*?);/.exec(p[0])[1], bin = atob(p[1]), n = bin.length, a = new Uint8Array(n); while (n--) a[n] = bin.charCodeAt(n); return new Blob([a], { type: mime }); }

  function doShare() {
    var u = pngB64(); if (!u) return;
    var b = bridge(), caption = (cur.ref ? cur.ref + ' — ' : '') + 'পাথেয় বাই গুঞ্জরণ';
    if (b && typeof b.shareImage === 'function') { var ok = false; try { ok = b.shareImage(u, caption); } catch (e) {} if (!ok) msg('শেয়ার করা যায়নি'); return; }
    /* ব্রাউজার/অন্য পরিবেশ: Web Share (ফাইলসহ) → না হলে ডাউনলোড */
    try {
      var f = new File([dataUrlToBlob(u)], fname() + '.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) { navigator.share({ files: [f], text: caption }).catch(function () {}); return; }
    } catch (e) {}
    download(u);
  }
  function download(u) { var a = document.createElement('a'); a.href = u; a.download = fname() + '.png'; document.body.appendChild(a); a.click(); a.remove(); msg('ছবি ডাউনলোড হচ্ছে'); }
  function doSave() {
    var u = pngB64(); if (!u) return;
    var b = bridge();
    if (b && typeof b.saveImage === 'function') { var ok = false; try { ok = b.saveImage(u, fname()); } catch (e) {} msg(ok ? 'গ্যালারিতে সেভ হয়েছে (Pictures/Patheyo)' : 'সেভ করা যায়নি'); return; }
    download(u);
  }
  function doCopy() {
    var s = textOf(), b = bridge();
    function fb() { try { var ta = document.createElement('textarea'); ta.value = s; ta.style.cssText = 'position:fixed;left:-9999px;opacity:0'; document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); ta.remove(); msg(ok ? 'লেখা কপি হয়েছে' : 'কপি করা যায়নি'); } catch (e) { msg('কপি করা যায়নি'); } }
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(s).then(function () { msg('লেখা কপি হয়েছে'); }, fb); return; } } catch (e) {}
    fb();
  }

  function open(data) {
    if (!data || !data.ar) return;
    if (!UI) build();
    cur = { kind: data.kind || 'dua', cat: data.cat || '', topic: data.topic || '', title: data.title || '', ar: data.ar, tr: data.tr || '', bn: data.bn || '', ref: data.ref || '' };
    if (!cur.bn) st.bn = false; else if (!cur.tr) st.tr = false;
    setTool('', true); sync(); UI.prev.innerHTML = '<span style="opacity:.6;font-size:14px">কার্ড তৈরি হচ্ছে…</span>';
    if (!opened) {
      opened = true;
      try { history.pushState({ pcs: 1 }, ''); } catch (e) {}
      UI.veil.classList.add('on'); UI.sheet.classList.add('on'); UI.sheet.scrollTop = 0;
      document.documentElement.classList.add('pcs-lock');
    }
    redraw();
  }
  function hide() { if (!opened) return; opened = false; UI.veil.classList.remove('on'); UI.sheet.classList.remove('on'); document.documentElement.classList.remove('pcs-lock'); }
  function requestClose() { if (!opened) return; if (history.state && history.state.pcs) history.back(); else hide(); }

  /* ---------- হাদিস/কুরআনের কার্ডে বসানোর ছোট "শেয়ার কার্ড" বোতাম (ফিচারের নিজের রঙের টোকেন নেয়) ---------- */
  var SHARE_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="4.5" width="17" height="15" rx="3.2"/><path d="M3.5 15.5l4.6-4.4 3.6 3.4 3-2.8 5.8 5.2M16.6 9.2h.01"/></svg>';
  var BTN_CSS = '.pt-sc-btn{width:38px;height:38px;border-radius:50%;border:0;display:grid;place-items:center;cursor:pointer;background:var(--accent-soft,rgba(14,123,184,.12));color:var(--accent,#0E7BB8);flex:none;padding:0;transition:transform .15s,background-color .25s}'
    + '.pt-sc-btn:active{transform:scale(.9)}'
    + '.pt-sc-btn svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;display:block}'
    + '.hd-acts{display:flex;align-items:center;gap:8px}'
    + '.tr-ayah{position:relative}.tr-ayah>.pt-sc-btn{position:absolute;top:14px;right:0;z-index:1}'
    + '.bm-share{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin:2px 0 14px;padding:11px 12px;border-radius:12px;border:1.5px dashed var(--accent,#0E7BB8);background:var(--accent-soft,rgba(14,123,184,.1));color:var(--accent,#0E7BB8);font-family:inherit;font-size:15px;font-weight:600;cursor:pointer}'
    + '.bm-share.hidden{display:none}.bm-share svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}';
  (function () { var st = document.createElement('style'); st.setAttribute('data-pt-sc', '1'); st.textContent = BTN_CSS; (document.head || document.documentElement).appendChild(st); })();
  function btnHtml() { return '<button type="button" class="pt-sc-btn" data-pt-share aria-label="শেয়ার কার্ড তৈরি করুন" title="শেয়ার কার্ড">' + SHARE_ICON + '</button>'; }

  window.PtShareCard = { open: open, close: requestClose, themes: THEMES, btnHtml: btnHtml, _render: render };
})();
