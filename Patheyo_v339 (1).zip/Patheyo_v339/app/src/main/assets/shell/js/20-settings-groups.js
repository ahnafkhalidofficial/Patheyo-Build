/* v308: সেটিংস — প্রতিটি বিভাগ গুটানো; হেডারে চাপলে ভেতরের সব দেখা যায় (একবারে একটি বিভাগ খোলা থাকে, তাই পেজ লম্বা হয় না) */
(function () {
  'use strict';
  var body = document.querySelector('#settings-overlay .st-body');
  if (!body) return;
  var groups = Array.prototype.slice.call(body.querySelectorAll('.sg'));
  function setOpen(g, on) {
    g.classList.toggle('is-open', on);
    var h = g.querySelector('.sg-h'); if (h) h.setAttribute('aria-expanded', on ? 'true' : 'false');
  }
  function open(g) {
    groups.forEach(function (o) { if (o !== g) setOpen(o, false); });
    setOpen(g, true);
    setTimeout(function () { try { g.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} }, 320);
  }
  groups.forEach(function (g) {
    var h = g.querySelector('.sg-h'); if (!h) return;
    h.addEventListener('click', function () { if (g.classList.contains('is-open')) setOpen(g, false); else open(g); });
  });
  /* সার্চ ইত্যাদি থেকে কোনো সেকশনে সরাসরি গেলে তার বিভাগটি নিজে খুলে যায় */
  window.__ptSettingsOpen = function (id) {
    var el = document.getElementById(id), g = el && el.closest ? el.closest('.sg') : null;
    if (g && !g.classList.contains('is-open')) { open(g); return true; }
    return !!g;
  };
})();
