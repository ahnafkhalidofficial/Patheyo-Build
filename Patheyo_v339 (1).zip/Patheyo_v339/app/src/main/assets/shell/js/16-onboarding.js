/* =============================================================================
   ধাপ ১১: প্রথমবার খোলার গাইড (অনবোর্ডিং) — ৩টি স্ক্রিন, ৩০ সেকেন্ডে অ্যাপ প্রস্তুত
     ১) স্বাগতম — পাথেয় কেন (শান্ত · অফলাইন · ধর্মীয় সব ফ্রি)
     ২) আপনার নামাজের সময় — লোকেশন (ফোনের GPS বা শহর বাছাই) + মাযহাব, সাথে সাথে আজকের ৫ ওয়াক্ত দেখায়
     ৩) সময়মতো মনে করিয়ে দেব — নোটিফিকেশনের অনুমতি + প্রধান রিমাইন্ডারগুলোর সুইচ
   কখন দেখায়: নেটিভ PatheyoOnboard.pending() (শুধু নতুন ইনস্টলে; আপডেট করা পুরনো ব্যবহারকারী দেখেন না)।
   ব্রাউজারে পরীক্ষা: window.__ptForceOnb = true অথবা ?onboarding।
   শেষে: localStorage 'pt_onboarded', PatheyoOnboard.done() → নেটিভ বাকি আজান-নির্ভরযোগ্যতার অনুমতিগুলো চায়।
   লোকেশন/মাযহাব যায় নামাজ পেজের নিজের জায়গায়: lastKnownPrayerData (lat/lng/নাম) ও currentMadhab।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window, $ = function (id) { return D.getElementById(id); };
  var root = $('onb'); if (!root) return;
  var N = W.PatheyoOnboard;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  function ic(n, c) { return W.PT ? PT.icon(n, c || '') : ''; }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }

  var want = false;
  try { want = N && typeof N.pending === 'function' ? !!N.pending() : (!!W.__ptForceOnb || /onboarding/.test(location.search)); } catch (e) { want = false; }
  if (!want || ls('pt_onboarded') === '1' && !W.__ptForceOnb) return;

  var CITIES = [['ঢাকা', 23.8103, 90.4125], ['চট্টগ্রাম', 22.3569, 91.7832], ['সিলেট', 24.8949, 91.8687], ['রাজশাহী', 24.3745, 88.6042],
    ['খুলনা', 22.8456, 89.5403], ['বরিশাল', 22.701, 90.3535], ['রংপুর', 25.7439, 89.2752], ['ময়মনসিংহ', 24.7471, 90.4203],
    ['কুমিল্লা', 23.4607, 91.1809], ['গাজীপুর', 23.9999, 90.4203], ['নারায়ণগঞ্জ', 23.6238, 90.5], ['বগুড়া', 24.8465, 89.3776],
    ['যশোর', 23.1664, 89.2081], ['কক্সবাজার', 21.4272, 92.0058]];
  var PICK = [0, 1, 2, 3, 4, 5, 6, 7];   /* চিপে দেখানো শহর (বিভাগীয়) */

  var cached = {}; try { cached = JSON.parse(ls('lastKnownPrayerData') || '{}') || {}; } catch (e) { cached = {}; }
  var st = { step: 0, lat: cached.lat || 23.8103, lng: cached.lng || 90.4125, place: cached.locationName || 'ঢাকা', gps: false, madhab: ls('currentMadhab') || '1', notif: false };

  /* ---------- কাছের শহরের নাম (অফলাইন) ---------- */
  function km(a, b, c, d) { var R = 6371, r = Math.PI / 180, x = (c - a) * r, y = (d - b) * r, h = Math.sin(x / 2) * Math.sin(x / 2) + Math.cos(a * r) * Math.cos(c * r) * Math.sin(y / 2) * Math.sin(y / 2); return 2 * R * Math.asin(Math.sqrt(h)); }
  function nearName(lat, lng) {
    var best = null, bd = 1e9;
    CITIES.forEach(function (c) { var d = km(lat, lng, c[1], c[2]); if (d < bd) { bd = d; best = c; } });
    if (best && bd < 25) return best[0];
    if (best && bd < 90) return best[0] + '-এর কাছে';
    return 'আপনার এলাকা';
  }

  /* ---------- আজকের ৫ ওয়াক্ত (ফোনেই হিসাব — shared/prayer-calc.js) ---------- */
  function fmt(hm) { if (!hm) return '--:--'; var p = hm.split(':'), h = +p[0]; return bn((h % 12 || 12) + ':' + p[1]); }
  function times() {
    if (!W.PtPrayer) return null;
    var m = PtPrayer.effectiveMethod ? PtPrayer.effectiveMethod(ls('userPrayerMethodId'), ls('prayerMethodId'), st.lat, st.lng) : (parseInt(ls('userPrayerMethodId') || ls('prayerMethodId') || '1', 10) || 1);
    try { return PtPrayer.times(new Date(), { lat: st.lat, lng: st.lng, method: m, school: st.madhab }); } catch (e) { return null; }
  }

  /* ---------- স্ক্রিন ---------- */
  function logo() { var l = D.querySelector('.brand-logo-svg'); return l ? l.outerHTML : ic('crescent'); }
  function dots() { return '<div class="onb-dots" aria-hidden="true">' + [0, 1, 2].map(function (i) { return '<i class="' + (i === st.step ? 'on' : i < st.step ? 'done' : '') + '"></i>'; }).join('') + '</div>'; }

  function s1() {
    return '<div class="onb-arch"><span class="onb-logo">' + logo() + '</span></div>' +
      '<div class="onb-kicker">পাথেয়-তে স্বাগতম</div>' +
      '<h1 class="onb-h">আসসালামু আলাইকুম</h1>' +
      '<p class="onb-p">নামাজ, কুরআন, হাদিস ও দোয়া — আপনার প্রতিদিনের ইবাদতের নির্ভরযোগ্য সঙ্গী।</p>' +
      '<ul class="onb-why">' +
        '<li><span class="pt-medal">' + ic('no-ad') + '</span><span><b>শান্ত ও নির্বিঘ্ন</b>নামাজ, কুরআন ও হাদিস পাঠের সময় কোনো বিজ্ঞাপন নেই</span></li>' +
        '<li><span class="pt-medal">' + ic('cloud-check') + '</span><span><b>ইন্টারনেট ছাড়াও সচল</b>নামাজের সময়, কুরআন ও দোয়া — সবই অফলাইনে</span></li>' +
        '<li><span class="pt-medal">' + ic('heart') + '</span><span><b>ধর্মীয় কনটেন্ট চিরকাল বিনামূল্যে</b>কুরআন, হাদিস, নামাজ ও দোয়ার জন্য কখনো অর্থ দিতে হবে না</span></li>' +
      '</ul>';
  }
  function s2() {
    var t = times() || {};
    var W5 = [['ফজর', t.Fajr], ['যোহর', t.Dhuhr], ['আসর', t.Asr], ['মাগরিব', t.Maghrib], ['এশা', t.Isha]];
    return '<div class="onb-top"><span class="pt-medal onb-medal">' + ic('mosque', 'pt-ic--lg') + '</span>' +
      '<h2 class="onb-h2">আপনার এলাকার নামাজের সময়</h2><p class="onb-p">লোকেশন দিলেই পাবেন আপনার এলাকার নির্ভুল ওয়াক্ত — ইন্টারনেট ছাড়াও।</p></div>' +
      '<div class="onb-sec"><div class="onb-lbl">আপনার অবস্থান</div>' +
        '<button type="button" class="pt-btn pt-btn--block onb-gps' + (st.gps ? ' is-done' : '') + '" id="onb-gps">' + ic(st.gps ? 'check-circle' : 'gps', 'pt-ic--sm') +
          '<span>' + (st.gps ? 'লোকেশন নির্ধারিত হয়েছে' : 'বর্তমান লোকেশন ব্যবহার করুন') + '</span></button>' +
        '<div class="onb-or"><span>অথবা নিজে শহর বেছে নিন</span></div>' +
        '<div class="onb-cities">' + PICK.map(function (i) { var c = CITIES[i]; return '<button type="button" class="pt-chip' + (!st.gps && st.place === c[0] ? ' is-on' : '') + '" data-city="' + i + '">' + c[0] + '</button>'; }).join('') + '</div>' +
      '</div>' +
      '<div class="onb-sec"><div class="onb-lbl">মাযহাব <em>শুধু আসরের ওয়াক্তে পার্থক্য হয়</em></div>' +
        '<div class="pt-seg onb-seg" role="tablist" id="onb-mz"><button class="pt-seg__btn" type="button" role="tab" data-mz="1" aria-selected="' + (st.madhab === '1') + '">হানাফি</button>' +
        '<button class="pt-seg__btn" type="button" role="tab" data-mz="0" aria-selected="' + (st.madhab !== '1') + '">শাফেয়ি · মালিকি · হাম্বলি</button></div></div>' +
      '<div class="onb-prev"><div class="onb-place">' + ic('location', 'pt-ic--sm') + '<span>' + st.place + ' · আজ</span></div>' +
        '<div class="onb-waqt">' + W5.map(function (w) { return '<span><em>' + w[0] + '</em><b>' + fmt(w[1]) + '</b></span>'; }).join('') + '</div>' +
        '<div class="onb-hint">প্রয়োজনে পরে নামাজ পেজ থেকে মসজিদের সাথে মিলিয়ে প্রতিটি ওয়াক্ত ± মিনিট সমন্বয় করা যাবে।</div></div>';
  }
  function s3() {
    var R = W.__ptReminders, o = R ? R.load() : {};
    var show = ['kahf', 'monthu', 'ayyam', 'sleep'];
    var items = R ? R.ITEMS.filter(function (it) { return show.indexOf(it[0]) > -1; }) : [];
    return '<div class="onb-top"><span class="pt-medal onb-medal">' + ic('bell', 'pt-ic--lg') + '</span>' +
      '<h2 class="onb-h2">সময়মতো মনে করিয়ে দেব</h2><p class="onb-p">আজান ও রিমাইন্ডার পেতে নোটিফিকেশনের অনুমতি প্রয়োজন। শুধু আপনার বেছে নেওয়া রিমাইন্ডারগুলোই আসবে — বাড়তি কিছু নয়।</p></div>' +
      '<button type="button" class="pt-btn pt-btn--block onb-notif' + (st.notif ? ' is-done' : '') + '" id="onb-notif">' + ic(st.notif ? 'check-circle' : 'bell', 'pt-ic--sm') +
        '<span>' + (st.notif ? 'নোটিফিকেশন চালু আছে' : 'নোটিফিকেশন চালু করুন') + '</span></button>' +
      '<div class="onb-rm">' + items.map(function (it) {
        return '<label class="onb-rmr"><span class="onb-rmt"><b>' + it[1] + '</b><span>' + (it[0] === 'sleep' ? 'প্রতিদিন রাত ১০:৩০ · সময় পরে বদলানো যাবে' : it[2]) + '</span></span>' +
          '<span class="pt-switch"><input type="checkbox" data-rm="' + it[0] + '"' + (o[it[0]] ? ' checked' : '') + '><span class="pt-switch__track"></span></span></label>';
      }).join('') + '</div>' +
      '<p class="onb-fine">' + ic('info', 'pt-ic--sm') + '<span>ঠিক ওয়াক্তে আজান বাজাতে এরপর ফোন আরও দু-একটি অনুমতি চাইতে পারে (অ্যালার্ম, ব্যাটারি)। সব পছন্দ সেটিংস → রিমাইন্ডার থেকে যেকোনো সময় বদলানো যাবে।</span></p>';
  }
  var SCREENS = [s1, s2, s3];
  var CTA = ['শুরু করুন', 'পরবর্তী ধাপ', 'পাথেয় শুরু করুন'];

  function paint(dir) {
    var card = root.querySelector('.onb-body');
    card.innerHTML = SCREENS[st.step]();
    card.classList.remove('onb-in', 'onb-back'); void card.offsetWidth; card.classList.add(dir < 0 ? 'onb-back' : 'onb-in');
    card.scrollTop = 0;
    root.querySelector('.onb-dots-wrap').innerHTML = dots();
    $('onb-next').textContent = CTA[st.step];
    $('onb-prev').hidden = st.step === 0;
    $('onb-skip').hidden = st.step === 2;
    root.querySelectorAll('.pt-seg').forEach(function (s) { if (W.PT && PT.seg) PT.seg(s); });
  }

  /* ---------- কাজ ---------- */
  function applyLocation() {
    var o = {}; try { o = JSON.parse(ls('lastKnownPrayerData') || '{}') || {}; } catch (e) { o = {}; }
    o.lat = st.lat; o.lng = st.lng; o.locationName = st.place.replace(/-এর কাছে$/, '');
    ls('lastKnownPrayerData', JSON.stringify(o));
    ls('currentMadhab', st.madhab);
    /* নামাজ পেজ আগে থেকেই খোলা থাকলে সাথে সাথে নতুন হিসাব */
    try {
      var w = W.__ptPages && W.__ptPages.frameWin('f0');
      if (w && w.eval) w.eval('try{userLat=' + (+st.lat) + ';userLng=' + (+st.lng) + ';currentMadhab=' + JSON.stringify(st.madhab) +
        ';var _m=document.getElementById("setting-madhab");if(_m){_m.value=currentMadhab;if(typeof syncMadhabUI==="function")syncMadhabUI();}' +
        'if(typeof nzSetPlace==="function")nzSetPlace(' + JSON.stringify(o.locationName) + ');if(typeof nzRecompute==="function")nzRecompute();}catch(e){}');
    } catch (e) {}
  }
  function useGeo() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(function (p) {
      st.lat = Math.round(p.coords.latitude * 1e4) / 1e4; st.lng = Math.round(p.coords.longitude * 1e4) / 1e4;
      st.place = nearName(st.lat, st.lng); st.gps = true;
      if (st.step === 1) paint(0);
      if (W.PT) PT.toast('লোকেশন নির্ধারিত হয়েছে — ' + st.place, { type: 'success' });
    }, function () {
      if (W.PT) PT.toast('লোকেশন পাওয়া যায়নি — তালিকা থেকে শহর বেছে নিন', { type: 'danger' });
    }, { timeout: 8000, maximumAge: 600000 });
  }
  W.__ptOnbCb = function (kind, ok) {
    if (kind === 'loc') { if (ok) useGeo(); else if (W.PT) PT.toast('লোকেশনের অনুমতি দেওয়া হয়নি — নিচ থেকে শহর বেছে নিন'); }
    if (kind === 'notif') { st.notif = !!ok; if (st.step === 2) paint(0); if (!ok && W.PT) PT.toast('চাইলে পরে ফোনের সেটিংস → অ্যাপ → অনুমতি থেকে চালু করতে পারবেন'); }
  };

  function finish() {
    applyLocation();
    ls('pt_onboarded', '1');
    root.classList.add('onb-out');
    setTimeout(function () { root.hidden = true; root.classList.remove('onb-out', 'is-on'); D.documentElement.classList.remove('onb-lock'); }, 420);
    try { if (N && N.done) N.done(); } catch (e) {}
    if (W.PT) setTimeout(function () { PT.toast('সব প্রস্তুত — আল্লাহ আপনার পথচলা সহজ ও বরকতময় করুন', { type: 'success' }); }, 500);
  }
  function next() {
    if (st.step === 1) applyLocation();
    if (st.step < 2) { st.step++; paint(1); if (W.PT && PT.haptic) PT.haptic('light'); return; }
    finish();
  }
  function prev() { if (st.step > 0) { st.step--; paint(-1); } }
  W.__ptOnbBack = function () { if (root.hidden) return false; if (st.step > 0) prev(); return true; };   /* ফোনের ব্যাক বাটন: আগের ধাপ (গাইড বন্ধ নয়) */

  root.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    if (b.id === 'onb-next') return next();
    if (b.id === 'onb-prev') return prev();
    if (b.id === 'onb-skip') { st.step = 2; paint(1); return; }
    if (b.id === 'onb-gps') {
      if (st.gps) return;
      try { if (N && N.requestLocation) { N.requestLocation(); return; } } catch (er) {}
      useGeo(); return;
    }
    if (b.id === 'onb-notif') {
      if (st.notif) return;
      try { if (N && N.requestNotification) { N.requestNotification(); return; } } catch (er) {}
      try { if (W.Notification && Notification.requestPermission) Notification.requestPermission().then(function (p) { W.__ptOnbCb('notif', p === 'granted'); }); } catch (er) {}
      return;
    }
    if (b.hasAttribute('data-city')) { var c = CITIES[+b.getAttribute('data-city')]; st.lat = c[1]; st.lng = c[2]; st.place = c[0]; st.gps = false; paint(0); return; }
    if (b.hasAttribute('data-mz')) { st.madhab = b.getAttribute('data-mz'); paint(0); return; }
  });
  root.addEventListener('change', function (e) {
    var k = e.target.getAttribute && e.target.getAttribute('data-rm'); if (!k || !W.__ptReminders) return;
    var o = W.__ptReminders.load(); o[k] = !!e.target.checked; W.__ptReminders.save(o);
  });

  /* ---------- দেখানো: স্প্ল্যাশ মিলিয়ে যাওয়ার পর ---------- */
  root.innerHTML = '<div class="onb-glow" aria-hidden="true"></div>' +
    '<div class="onb-bar"><button type="button" class="pt-iconbtn pt-iconbtn--ghost" id="onb-prev" aria-label="আগের ধাপ" hidden>' + ic('back') + '</button>' +
      '<span class="onb-dots-wrap"></span><button type="button" class="onb-skip" id="onb-skip">বাদ দিন</button></div>' +
    '<div class="onb-body" role="document"></div>' +
    '<div class="onb-foot"><button type="button" class="pt-btn pt-btn--block pt-btn--lg onb-next" id="onb-next"></button></div>';
  try { st.notif = N && N.hasNotification ? !!N.hasNotification() : (W.Notification && Notification.permission === 'granted'); } catch (e) {}
  try { if (N && N.hasLocation && N.hasLocation()) { st.gps = false; } } catch (e) {}
  function show() {
    root.hidden = false; D.documentElement.classList.add('onb-lock');
    paint(1);
    requestAnimationFrame(function () { root.classList.add('is-on'); });
  }
  var t0 = Date.now();
  (function waitSplash() {
    var sp = $('pts');
    if (!sp || sp.classList.contains('pts-out') || Date.now() - t0 > 4000) { setTimeout(show, sp ? 500 : 0); return; }
    setTimeout(waitSplash, 120);
  })();
})();
