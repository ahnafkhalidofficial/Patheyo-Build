// বিজ্ঞাপনের ছবি বানানো: node shot.js  → ad1..ad6.png (তারপর webp করে assets/ads/img-এ রাখুন)
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--allow-file-access-from-files'] });
  const p = await (await b.newContext({ viewport: { width: 1200, height: 350 }, deviceScaleFactor: 1 })).newPage();
  for (let i = 1; i <= 6; i++) {
    const h = i === 6 ? 450 : 350;
    await p.setViewportSize({ width: 1200, height: h });
    await p.goto('file://' + __dirname + `/ad${i}.html`); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(400);
    await p.screenshot({ path: __dirname + `/ad${i}.png`, clip: { x: 0, y: 0, width: 1200, height: h } });
  }
  await b.close();
})();
