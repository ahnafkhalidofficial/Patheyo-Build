# Patheyo — ফ্রন্টএন্ড (WebView) ফাইল কাঠামো

আগে `app/src/main/assets/index.html` একটাই বিশাল ফাইল ছিল (৩,৩৫৪ লাইন)।
এখন সেটা ভাগ করা হয়েছে — **ডিজাইন ও ফাংশনিং হুবহু আগের মতোই**, শুধু ফাইল আলাদা।
আগের আসল ফাইল `_backup_before_split/index.html.v33-original`-এ রাখা আছে।

```
assets/
├─ index.html            ← শুধু কাঠামো (HTML) + কোন ফাইল কোন ক্রমে লোড হবে তার তালিকা
├─ css/                  ← ডিজাইন (ক্রম গুরুত্বপূর্ণ: পরেরটা আগেরটাকে ওভাররাইড করে)
│   base · quran-themes · widget-themes · controls · widget-hub
│   color-picker · transitions · mobile-overrides
├─ js/                   ← অ্যাপের কাজ
│   config/        tailwind-config.js
│   core/          state · network · app-init · offline-cache · date-utils · native-callbacks
│   data/          islamic-events
│   prayer/        hijri-calendar · waqt-offsets · prayer-data · nafal-forbidden
│   ui/            dashboard · layout-mode · navigation
│   widget/        widget-ui · widget-preview · color-picker · widget-settings
│   features/      pwa-install · quran · azan-alarm · permissions · tasbih · qibla
│   integrations/  hijri-sync
└─ (fonts, azan.mp3, ছবি, json … আগের মতোই)
```

## নতুন ফিচার যোগ করার নিয়ম (মাত্র ২ ধাপ)
1. `assets/js/features/` ফোল্ডারে নতুন ফাইল বানান, যেমন `ramadan-calendar.js` — ফিচারের সব কোড ওখানে।
2. `index.html`-এর স্ক্রিপ্ট তালিকায় `native-callbacks.js`-এর **ঠিক আগে** একটা লাইন যোগ করুন:
   `<script src="js/features/ramadan-calendar.js" charset="UTF-8"></script>`

নতুন ফিচারের আলাদা ডিজাইন লাগলে `assets/css/` এ নতুন `.css` বানিয়ে
`mobile-overrides.css`-এর **আগে** `<link>` দিন।
Android Studio `assets` ফোল্ডারের সব ফাইল নিজেই APK-তে ঢুকিয়ে নেয়; Kotlin-এ হাত দিতে হয় না।

## ⚠️ যে নিয়মগুলো ভাঙবেন না
- **লোড-ক্রম বদলাবেন না।** `state.js` সবার আগে। ফাইলগুলো একটা আরেকটার ফাংশন সরাসরি ব্যবহার করে।
- **শেষ দুটো ফাইল সবসময় শেষে থাকবে:** `core/native-callbacks.js`, তারপর `integrations/hijri-sync.js`।
  কারণ Kotlin (`MainActivity`) এগুলোর ফাংশন (`setNativeNetworkStatus`, `onAzanStopped`,
  `handleNativeBackPress`, `setNativeHijriConfig`) যেকোনো সময় কল করতে পারে — এমনকি পেজ লোড চলাকালেও।
  এগুলো শেষে থাকলে ফাংশনটা "আছে" হওয়ার সময় তার সব নির্ভরতাও তৈরি থাকে।
  লোড হওয়ার সাথে সাথে নেটওয়ার্ক কাজ শুরু করে এমন কোড (যেমন Firebase) সবসময় শেষ ফাইলে।
- **ES module (`import`/`export`, `type="module"`) ব্যবহার করবেন না** — `file:///android_asset/` থেকে ব্লক হয়।
  সাধারণ ফাংশন/ভ্যারিয়েবল লিখুন; HTML-এর `onclick="..."` সরাসরি সেগুলো ডাকতে পারবে।
- CSS-এ ফাইলের পাথ দিলে `../` দিয়ে শুরু করুন (যেমন `url('../fonts/Kothamala.ttf')`),
  কারণ CSS এখন `css/` ফোল্ডারের ভেতরে।
- নতুন গ্লোবাল নাম (`let`/`const`/`function`) অন্য ফাইলের নামের সাথে মিলবে না — মিললে ত্রুটি হবে।
