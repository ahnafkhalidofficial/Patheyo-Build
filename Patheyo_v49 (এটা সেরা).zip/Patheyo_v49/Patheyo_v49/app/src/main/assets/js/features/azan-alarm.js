/* =============================================================================
   আজান ও অ্যালার্ম
   ওয়াক্তভিত্তিক অ্যালার্ম সেটিং, আজান টোস্ট/বন্ধ, অডিও টেস্ট, মাযহাব সেভ।
   ============================================================================= */

function checkAndTriggerConfiguredAlarms(now) {
    // Android native AlarmManager ইতিমধ্যে আজান হ্যান্ডেল করে — JS টাইমার দিয়ে ডুপ্লিকেট এড়ানো
    if (window.AndroidWidgetBridge) return;

    const minKey = `${now.getHours()}:${now.getMinutes()}`;
    if(firedAlarmsCacheKey === minKey) return;

    for(let w in waqtConfigs) {
        const c = waqtConfigs[w]; if(!c.active) continue;

        let tarH = 0; let tarM = 0;
        if(c.isCustom) {
            tarM = parseInt(c.minute); let h24 = parseInt(c.hour);
            if(c.ampm === "PM" && h24 < 12) h24 += 12;
            if(c.ampm === "AM" && h24 === 12) h24 = 0;
            tarH = h24;
        } else {
            const [apiH, apiM] = globalTimings[w].split(':').map(Number);
            tarH = apiH; tarM = apiM;
        }

        if(now.getHours() === tarH && now.getMinutes() === tarM) {
            firedAlarmsCacheKey = minKey; fireAzanNotificationToast(w); break;
        }
    }
}

function fireAzanNotificationToast(wKey) {
    const lbl = { 'Fajr': 'ফজর', 'Dhuhr': "যোহর/জুম'আ", 'Asr': 'আসর', 'Maghrib': 'মাগরিব', 'Isha': 'ইশা' };
    const waqtName = lbl[wKey] || wKey;
    document.getElementById('toast-title').innerText = `${waqtName} ওয়াক্তের আজান শুরু হচ্ছে`;
    document.getElementById('azan-toast-overlay').classList.remove('hidden');
    const stopBanner = document.getElementById('stop-azan-btn');
    if (stopBanner) stopBanner.classList.remove('hidden');
    azanAudioEngine.currentTime = 0; azanAudioEngine.play().catch(e => console.log(e));
    if (window.AndroidWidgetBridge) {
        if (typeof window.AndroidWidgetBridge.showAzanNotification === 'function') {
            try { window.AndroidWidgetBridge.showAzanNotification(wKey, waqtName); } catch(e) {}
        }
        if (typeof window.AndroidWidgetBridge.showAzanOverlay === 'function') {
            try { window.AndroidWidgetBridge.showAzanOverlay(waqtName); } catch(e) {}
        }
    }
    if ('Notification' in window && Notification.permission === 'granted') {
        try { new Notification(`🕌 ${waqtName} ওয়াক্তের আজান`, { body: `${waqtName} নামাজের সময় হয়েছে।`, icon: 'logoA.gif', tag: 'azan-' + wKey }); } catch(e) {}
    }
}

function stopAzanRinging() {
    azanAudioEngine.pause();
    document.getElementById('azan-toast-overlay').classList.add('hidden');
    const stopBanner = document.getElementById('stop-azan-btn');
    if (stopBanner) stopBanner.classList.add('hidden');
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.stopAzan === 'function') {
        try { window.AndroidWidgetBridge.stopAzan(); } catch(e) {}
    }
}

let isTestingAudio = false;
function toggleAudioTest() {
    const btn = document.getElementById('btn-audio-test');
    if(!isTestingAudio) {
        azanAudioEngine.currentTime = 0; azanAudioEngine.play();
        btn.innerHTML = `<i class="fa-solid fa-stop mr-1"></i> স্টপ করুন`; isTestingAudio = true;
    } else {
        azanAudioEngine.pause(); btn.innerHTML = `<i class="fa-solid fa-play mr-1"></i> টেস্ট আজান`; isTestingAudio = false;
    }
}

function openWaqtConfigModal(wKey) {
    targetedActiveWaqtKey = wKey; const cnf = waqtConfigs[wKey];
    document.getElementById('modal-waqt-title-label').innerText = `${wKey} ওয়াক্তের অ্যালার্ম সেটিংস`;
    setAlarmCustomTimeMode(cnf.isCustom);
    document.getElementById('custom-hour').value = cnf.hour;
    document.getElementById('custom-minute').value = cnf.minute;
    document.getElementById('custom-ampm').value = cnf.ampm;
    const offsetInput = document.getElementById('custom-minute-offset');
    if (offsetInput) offsetInput.value = waqtMinuteOffsets[wKey] || 0;
    document.getElementById('waqt-setup-modal').style.display = 'flex';
}
function closeWaqtModal() { document.getElementById('waqt-setup-modal').style.display = 'none'; }
function setAlarmCustomTimeMode(isCustom) {
    document.getElementById('custom-time-pickers-row').style.display = isCustom ? 'block' : 'none';
    document.getElementById('amode-custom').className = isCustom ? 'image-button text-white p-2.5 rounded-xl font-bold text-center text-xs' : 'bg-slate-900 text-slate-400 p-2.5 rounded-xl border border-slate-800 text-center text-xs';
    document.getElementById('amode-api').className = !isCustom ? 'image-button text-white p-2.5 rounded-xl font-bold text-center text-xs' : 'bg-slate-900 text-slate-400 p-2.5 rounded-xl border border-slate-800 text-center text-xs';
    document.getElementById('amode-custom').setAttribute('data-state', isCustom);
}
function saveWaqtSpecificAlarmSettings() {
    const isCustom = document.getElementById('amode-custom').getAttribute('data-state') === 'true';
    waqtConfigs[targetedActiveWaqtKey].isCustom = isCustom;
    waqtConfigs[targetedActiveWaqtKey].hour = String(document.getElementById('custom-hour').value).padStart(2,'0');
    waqtConfigs[targetedActiveWaqtKey].minute = String(document.getElementById('custom-minute').value).padStart(2,'0');
    waqtConfigs[targetedActiveWaqtKey].ampm = document.getElementById('custom-ampm').value;
    localStorage.setItem('waqtConfigs', JSON.stringify(waqtConfigs));
    const offsetInput = document.getElementById('custom-minute-offset');
    if (offsetInput) saveWaqtMinuteOffset(targetedActiveWaqtKey, offsetInput.value);
    closeWaqtModal(); processDashboardTimelineUpdates(new Date());
    syncAlarmConfigsToNativeBridge();
}

function saveMadhabAndRecomputeAll() { 
    currentMadhab = document.getElementById('setting-madhab').value; 
    localStorage.setItem('currentMadhab', currentMadhab); fetchCorePrayerData(); 
}

function toggleAlarmActiveState(wKey) {
    waqtConfigs[wKey].active = !waqtConfigs[wKey].active;
    localStorage.setItem('waqtConfigs', JSON.stringify(waqtConfigs));
    processDashboardTimelineUpdates(new Date());
    syncAlarmConfigsToNativeBridge();
}
