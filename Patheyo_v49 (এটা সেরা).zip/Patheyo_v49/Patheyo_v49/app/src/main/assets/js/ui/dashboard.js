/* =============================================================================
   মূল ড্যাশবোর্ড
   ওয়াক্তের ফেজ হিসাব, টাইমলাইন আপডেট ও ড্যাশবোর্ড কার্ড রেন্ডার।
   ============================================================================= */

// একটা ওয়াক্তের সময়সীমার মাঝে আমরা কোথায় আছি (প্রথমার্ধ না দ্বিতীয়ার্ধ) সেটা বের করে
// উপযুক্ত লেখা+সময় ফেরত দেয় — প্রথমার্ধে "চলছে, এত সময় ধরে" (এলাপসড গণনা),
// দ্বিতীয়ার্ধে "শেষ হতে বাকি, এত সময়" (রিমেইনিং গণনা) — দুটো জায়গায় (ড্যাশবোর্ড কার্ড ও উইজেট) একই নিয়মে ব্যবহার হয়।
function getWaqtPhaseInfo(start, end, now) {
    let elapsedMs = now - start;
    let remainingMs = end - now;

    // নেগেটিভ টাইম বা মাইনাস চিহ্ন রোধ করার জন্য সুরক্ষা
    if (elapsedMs < 0) elapsedMs = 0;
    if (remainingMs < 0) remainingMs = 0;

    const isFirstHalf = elapsedMs < remainingMs;
    const diffMs = isFirstHalf ? elapsedMs : remainingMs;
    const h = Math.floor(diffMs/3600000); const m = Math.floor((diffMs%3600000)/60000); const s = Math.floor((diffMs%60000)/1000);
    const diffStr = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    return { isFirstHalf, diffStr, isOver: (now >= end) };
}

function processDashboardTimelineUpdates(now) {
    if (!globalTimings) return; // ডেটা এখনো লোড না হলে (যেমন অ্যাপ চালু হওয়ার একদম শুরুতে) কিছু করার নেই, ক্র্যাশ এড়ানোর জন্য
    const tm = {
        'Fajr': parseWaqtStringToDate(globalTimings.Fajr),
        'Sunrise': parseWaqtStringToDate(globalTimings.Sunrise),
        'Dhuhr': parseWaqtStringToDate(globalTimings.Dhuhr),
        'Asr': parseWaqtStringToDate(globalTimings.Asr),
        'Maghrib': parseWaqtStringToDate(globalTimings.Maghrib),
        'Isha': parseWaqtStringToDate(globalTimings.Isha),
        'Sunset': parseWaqtStringToDate(globalTimings.Sunset || globalTimings.Maghrib)
    };

    // নামাজের ৩টা নিষিদ্ধ সময়ের প্রতিটার সঠিক শুরু ও শেষ — পরে এলাপসড/রিমেইনিং বের করার জন্য লাগবে
    const forbiddenWindows = [
        { start: tm['Sunrise'], end: new Date(tm['Sunrise'].getTime() + 15*60000) },
        { start: new Date(tm['Dhuhr'].getTime() - 12*60000), end: tm['Dhuhr'] },
        { start: new Date(tm['Sunset'].getTime() - 15*60000), end: tm['Sunset'] }
    ];
    let isForbidden = false; let activeForbiddenWindow = null;
    for (const w of forbiddenWindows) {
        if (now >= w.start && now < w.end) { isForbidden = true; activeForbiddenWindow = w; break; }
    }
    document.getElementById('forbidden-time-banner').style.display = isForbidden ? 'flex' : 'none';

    // নামাজের সঠিক ওয়াক্ত হিসাব: ফজরের ওয়াক্ত সূর্যোদয়েই শেষ হয়ে যায়, এরপর যোহর শুরু না হওয়া পর্যন্ত কোনো ফরজ ওয়াক্ত "চলমান" থাকে না (isGap)।
    let act = null; let start = null; let end = null; let isGap = false;
    if(now >= tm['Fajr'] && now < tm['Sunrise']) { act = 'Fajr'; start = tm['Fajr']; end = tm['Sunrise']; }
    else if(now >= tm['Sunrise'] && now < tm['Dhuhr']) { isGap = true; start = tm['Sunrise']; end = tm['Dhuhr']; }
    else if(now >= tm['Dhuhr'] && now < tm['Asr']) { act = 'Dhuhr'; start = tm['Dhuhr']; end = tm['Asr']; }
    else if(now >= tm['Asr'] && now < tm['Maghrib']) { act = 'Asr'; start = tm['Asr']; end = tm['Maghrib']; }
    else if(now >= tm['Maghrib'] && now < tm['Isha']) { act = 'Maghrib'; start = tm['Maghrib']; end = tm['Isha']; }
    else {
        act = 'Isha';
        if(now >= tm['Isha']) { start = tm['Isha']; end = new Date(tm['Fajr'].getTime() + 24*60*60000); }
        else { end = tm['Fajr']; start = new Date(tm['Isha'].getTime() - 24*60*60000); }
    }

    // উইজেট সেলস্টিয়াল/সাহরি-ইফতার পিল লজিক:
    // রমজান মাস হলে — সূর্যোদয়/সূর্যাস্তের বদলে সাহরি শেষ ও ইফতারের সময় দেখাবে (একই জায়গায়, ডিজাইন অপরিবর্তিত)
    const celTitle = document.getElementById('wd-celestial-title');
    const celTime = document.getElementById('wd-celestial-time');
    const celIcon = document.getElementById('wd-celestial-icon');

    const hDate = getDisplayHijriDate(now);
    const haramInfo = getHaramRozaStatus(hDate);

    if (isRamadanNow && !haramInfo) {
        if (now < tm['Maghrib']) {
            celTitle.innerText = "ইফতার"; celTime.innerText = convert24To12Compact(globalTimings.Maghrib);
            if(celIcon) celIcon.className = "fa-solid fa-utensils text-amber-200 text-[11px] md:text-xs";
        } else {
            celTitle.innerText = "সাহরি শেষ"; celTime.innerText = convert24To12Compact(globalTimings.Fajr);
            if(celIcon) celIcon.className = "fa-solid fa-moon text-amber-200 text-[11px] md:text-xs";
        }
    } else if(now >= tm['Sunrise'] && now < tm['Sunset']) { 
        celTitle.innerText = "সূর্যাস্ত"; 
        celTime.innerText = convert24To12Compact(globalTimings.Sunset || globalTimings.Maghrib);
        if(celIcon) celIcon.className = "fa-solid fa-cloud-moon text-amber-200 text-[11px] md:text-xs";
    } else { 
        celTitle.innerText = "সূর্যোদয়"; 
        celTime.innerText = convert24To12Compact(globalTimings.Sunrise);
        if(celIcon) celIcon.className = "fa-solid fa-cloud-sun text-amber-200 text-[11px] md:text-xs";
    }

    // উইজেট আবহাওয়া তথ্য প্রদর্শন প্যানেল টগল নিয়ন্ত্রণ
    const wdWeatherPanel = document.getElementById('wd-live-weather-panel');
    const wdSehriPanel = document.getElementById('wd-sehri-panel');
    const wdIftarPanel = document.getElementById('wd-iftar-panel');
    const wdClockPanel = document.getElementById('wd-live-clock-panel');
    const sehriIftarOn = document.getElementById('toggle-wd-sehri-iftar')?.checked || false;
    const weatherOn = (document.getElementById('toggle-wd-weather')?.checked || false) && !(sehriIftarOn && (document.getElementById('toggle-wd-clock')?.checked || false));
    const clockOn = document.getElementById('toggle-wd-clock')?.checked || false;

    // আবহাওয়া প্যানেল
    if(weatherOn) {
        wdWeatherPanel.style.display = 'flex';
        document.getElementById('wd-widget-temp-val').innerText = cacheTemperatureStr;
    } else {
        wdWeatherPanel.style.display = 'none';
    }
    // সাহরী/ইফতার প্যানেল — clock-এর পাশে এক লাইনে দেখানো হবে
    if(sehriIftarOn && globalTimings) {
        if(wdSehriPanel) {
            wdSehriPanel.style.display = 'flex';
            const sehriEl = document.getElementById('wd-sehri-preview');
            if(sehriEl) {
                if (haramInfo) {
                    sehriEl.innerText = "--:--";
                    sehriEl.previousElementSibling.innerText = "নিষিদ্ধ";
                } else {
                    sehriEl.innerText = convert24To12Compact(globalTimings.Fajr);
                    sehriEl.previousElementSibling.innerText = "সাহরী";
                }
            }
        }
        if(wdIftarPanel) {
            wdIftarPanel.style.display = 'flex';
            const iftarEl = document.getElementById('wd-iftar-preview');
            if(iftarEl) {
                if (haramInfo) {
                    iftarEl.innerText = "--:--";
                    iftarEl.previousElementSibling.innerText = "নিষিদ্ধ";
                } else {
                    iftarEl.innerText = convert24To12Compact(globalTimings.Maghrib);
                    iftarEl.previousElementSibling.innerText = "ইফতার";
                }
            }
        }
    } else {
        if(wdSehriPanel) wdSehriPanel.style.display = 'none';
        if(wdIftarPanel) wdIftarPanel.style.display = 'none';
    }

    // Layout 2 (Compact UI): Clock disabled - hide middle section entirely
    if (!clockOn) {
        if(wdClockPanel) wdClockPanel.style.display = 'none';
    }

    renderMainDashboardCards(tm, act, start, end, now, isGap, isForbidden, activeForbiddenWindow);
    renderNafalAndForbiddenCards(tm, now);
    updateWidgetUI(act, start, end, now, isGap, isForbidden, activeForbiddenWindow);

    // নেটিভ হোমস্ক্রিন উইজেটকে বর্তমান active ওয়াক্ত জানানো (gap-এ null/'' পাঠানো হবে)
    // ফলে native widget ফজর শেষ হলে যোহর আগে থেকে select করবে না
    // ✅ FIX v34: এই ফাংশন প্রতি সেকেন্ডে চলে। আগে এই কলটা (haramInfo বাগের কারণে) আসলে কখনো পৌঁছাতোই না;
    // বাগ ঠিক করার পর প্রতি সেকেন্ডে কল হলে নেটিভে প্রতিবার ডিস্ক-commit + সব উইজেট রিফ্রেশ হতো (ব্যাটারি/ল্যাগ)।
    // তাই এখন শুধু ওয়াক্ত বদলালে পাঠানো হয়, আর অন্তত প্রতি ৩০ মিনিটে একবার রিফ্রেশ করা হয়
    // (নেটিভে ১ ঘণ্টার বেশি পুরনো মান stale ধরা হয়, তাই সেই সীমার ভেতরেই থাকে)।
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.setActiveWaqt === 'function') {
        const activeWaqtKey = act || '';
        const nowMs = Date.now();
        if (activeWaqtKey !== lastSentActiveWaqt || (nowMs - lastSentActiveWaqtAt) > ACTIVE_WAQT_RESEND_MS) {
            try {
                window.AndroidWidgetBridge.setActiveWaqt(activeWaqtKey);
                lastSentActiveWaqt = activeWaqtKey;
                lastSentActiveWaqtAt = nowMs;
            } catch(e) {}
        }
    }
}

function buildForbiddenStatusHTML(activeForbiddenWindow, now, compact) {
    const phase = getWaqtPhaseInfo(activeForbiddenWindow.start, activeForbiddenWindow.end, now);
    const phaseLabel = phase.isFirstHalf ? 'চলছে' : 'বাকি আছে';
    if (compact) {
        return `⚠️ সাবধান! নিষিদ্ধ সময় ${phaseLabel}: ${phase.diffStr}`;
    }
    return `<p class="text-[13px] md:text-xs font-bold mt-1 flex items-center gap-1.5" style="color:#FACC15">
                        <span>⚠️ সাবধান! এখন নামাজ পড়া ও সিজদা আদায় করা থেকে বিরত থাকুন — নিষিদ্ধ সময় ${phaseLabel}: <span class="mono-font">${phase.diffStr}</span></span>
                    </p>`;
}

function renderMainDashboardCards(tm, act, start, end, now, isGap, isForbidden, activeForbiddenWindow) {
    const container = document.getElementById('main-prayer-cards-container');
    const list = [
        { id: 'Fajr', name: 'ফজর (Fajr)' },
        { id: 'Dhuhr', name: (now.getDay()===5?"জুম'আ (Jummah)":"যোহর (Dhuhr)") },
        { id: 'Asr', name: 'আসর (Asr)' },
        { id: 'Maghrib', name: 'মাগরিব (Maghrib)' },
        { id: 'Isha', name: 'ইশা (Isha)' }
    ];

    let html = '';
    list.forEach(item => {
        const isCurrent = item.id === act;
        const cnf = waqtConfigs[item.id];
        let statText = '';
        let badgeHTML = '';

        if(isCurrent && isForbidden) {
            statText = buildForbiddenStatusHTML(activeForbiddenWindow, now, false);
            badgeHTML = '<span class="text-[10px] md:text-[11px] font-bold px-1.5 py-0.5 rounded-full uppercase" style="background:#7f1d1d;color:#FACC15">নিষিদ্ধ সময়</span>';
        } else if(isCurrent) {
            const phase = getWaqtPhaseInfo(start, end, now);
            if (phase.isOver || phase.diffStr.startsWith("-")) {
                statText = '';
            } else {
                const waqtNameShort = item.name.split(' ')[0];
                const label = phase.isFirstHalf ? `${waqtNameShort}-এর সময় অতিবাহিত:` : `${waqtNameShort}-এর সময় শেষ হতে বাকি:`;
                statText = `<p class="text-[13px] md:text-xs text-blue-400 font-medium mt-1 flex items-center gap-1.5"><i class="fa-solid fa-hourglass-half animate-spin text-[12px]"></i><span>${label}</span><span class="mono-font font-bold">${phase.diffStr}</span></p>`;
            }
            badgeHTML = '<span class="bg-blue-600 text-white text-[10px] md:text-[11px] font-bold px-1.5 py-0.5 rounded-full uppercase">চলমান</span>';
        } else if(isGap && item.id === 'Dhuhr' && isForbidden) {
            statText = buildForbiddenStatusHTML(activeForbiddenWindow, now, false);
            badgeHTML = '<span class="text-[10px] md:text-[11px] font-bold px-1.5 py-0.5 rounded-full uppercase" style="background:#7f1d1d;color:#FACC15">নিষিদ্ধ সময়</span>';
        }
        // ফজরের পর থেকে যোহরের আগ পর্যন্ত গ্যাপ পিরিয়ডে (নিষিদ্ধ সময় ছাড়া) কোনো লেখা/ব্যাজ দেখানো হবে না — ইচ্ছাকৃতভাবে ফাঁকা রাখা হলো
        let configBadge = cnf.isCustom ? `<span class="bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[11px] md:text-[12px] px-1.5 py-0.5 rounded font-mono">কাস্টম: ${cnf.hour}:${cnf.minute} ${cnf.ampm}</span>` : '';

        const cardTone = (isCurrent && isForbidden) ? 'bg-gradient-to-r from-rose-950/40 via-slate-900/40 to-slate-900/20 border-2 border-rose-500 shadow-2xl'
                        : isCurrent ? 'bg-gradient-to-r from-blue-950/40 via-slate-900/40 to-slate-900/20 border-2 border-blue-500 shadow-2xl'
                        : (isGap && item.id === 'Dhuhr' && isForbidden) ? 'bg-gradient-to-r from-rose-950/30 via-slate-900/30 to-slate-900/20 border border-rose-500/50'
                        : 'image-card';
        const iconBoxTone = (isCurrent && isForbidden) ? 'bg-rose-600 text-white'
                        : isCurrent ? 'image-button text-white'
                        : (isGap && item.id === 'Dhuhr' && isForbidden) ? 'bg-rose-500/15 text-rose-400'
                        : 'bg-slate-800 text-slate-400';
        const iconClass = (isCurrent && isForbidden) ? 'fa-ban' : isCurrent ? 'fa-circle-dot' : 'fa-stopwatch';
        const nameTone = isCurrent ? 'text-white' : 'text-slate-300';

        html += `
                <div class="transition-all rounded-2xl p-2.5 md:p-4 flex items-center justify-between gap-2 md:gap-4 ${cardTone}">
                    <div class="flex items-center gap-2 md:gap-4 min-w-0">
                        <div class="p-2 md:p-3 rounded-xl shrink-0 ${iconBoxTone}">
                            <i class="fa-solid ${iconClass} text-xs md:text-sm"></i>
                        </div>
                        <div class="min-w-0">
                            <div class="flex items-center flex-wrap gap-1">
                                <span class="font-bold text-xs md:text-sm whitespace-nowrap ${nameTone}">${item.name}</span>
                                ${badgeHTML}
                                ${configBadge}
                            </div>
                            ${statText}
                        </div>
                    </div>
                    <div class="flex items-center gap-1.5 md:gap-3 shrink-0">
                        <span class="text-xs md:text-base font-bold mono-font text-slate-200 whitespace-nowrap">${convert24To12(globalTimings[item.id])}</span>
                        <button onclick="toggleAlarmActiveState('${item.id}')" class="px-1.5 md:px-2.5 py-1.5 rounded-lg text-[13px] md:text-xs font-semibold border transition-all ${cnf.active ? 'bg-blue-600/10 text-blue-400 border-blue-500/30' : 'bg-slate-800 text-slate-500 border-slate-700'}">
                            <i class="fa-solid ${cnf.active ? 'fa-bell' : 'fa-bell-slash'}"></i><span class="hidden sm:inline ml-1">${cnf.active ? 'অন' : 'অফ'}</span>
                        </button>
                        <button onclick="openWaqtConfigModal('${item.id}')" class="bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-blue-400 p-1.5 md:p-2 rounded-lg border border-slate-700 transition">
                            <i class="fa-solid fa-gear text-[13px]"></i>
                        </button>
                    </div>
                </div>`;
    });
    container.innerHTML = html;
}
