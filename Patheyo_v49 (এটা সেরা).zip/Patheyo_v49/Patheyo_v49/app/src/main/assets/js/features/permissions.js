/* =============================================================================
   পারমিশন ট্যাব
   নেটিভ ব্রিজের পারমিশন কল-হেল্পার ও লাইভ স্ট্যাটাস দেখানো।
   ============================================================================= */

// ============================================================
// ✅ নতুন: "পারমিশন" ট্যাব — bridge কল-হেল্পার ও লাইভ স্ট্যাটাস দেখানো
// ============================================================

// পারমিশন ট্যাবের যেকোনো বাটনে ক্লিক করলে এই একটা হেল্পার দিয়েই নেটিভ ব্রিজের
// নির্দিষ্ট মেথড কল হয় — ব্রিজ না থাকলে (ব্রাউজারে টেস্ট মোডে) বিভ্রান্তিকরভাবে
// চুপ করে না থেকে ইউজারকে পরিষ্কার জানিয়ে দেওয়া হয়
function callPermissionBridge(methodName) {
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge[methodName] === 'function') {
        try {
            window.AndroidWidgetBridge[methodName]();
            // সেটিংস থেকে ফিরে আসার পর অবস্থা যেন সাথে সাথে আপডেট দেখা যায়
            setTimeout(refreshPermissionStatuses, 800);
        } catch (e) {
            console.error('permission bridge call failed:', methodName, e);
        }
    } else {
        alert('এই বাটনটা শুধু অ্যাপের ভিতরে কাজ করবে — এখন ব্রাউজারে টেস্ট মোডে আছেন।');
    }
}

// প্রতিটা পারমিশনের পাশে ✅ চালু আছে / ❌ বন্ধ আছে ব্যাজ দেখানো — নেটিভ ব্রিজ থেকে লাইভ ডেটা এনে
function refreshPermissionStatuses() {
    const setBadge = (key, isOn) => {
        const el = document.getElementById(`perm-badge-${key}`);
        if (!el) return;
        if (isOn) {
            el.textContent = 'চালু আছে';
            el.className = 'text-[11px] font-bold px-2 py-1 rounded-full bg-emerald-500/15 text-emerald-400 whitespace-nowrap';
        } else {
            el.textContent = 'বন্ধ আছে ✗';
            el.className = 'text-[11px] font-bold px-2 py-1 rounded-full bg-rose-500/15 text-rose-400 whitespace-nowrap';
        }
    };

    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.checkAllPermissionsStatus === 'function') {
        try {
            const status = JSON.parse(window.AndroidWidgetBridge.checkAllPermissionsStatus());
            setBadge('exactAlarm', !!status.exactAlarm);
            setBadge('notification', !!status.notification);
            setBadge('location', !!status.location);
            setBadge('battery', !!status.battery);
            setBadge('fullScreen', !!status.fullScreen);
        } catch (e) {
            console.error('permission status check failed:', e);
        }
    } else {
        ['exactAlarm', 'notification', 'location', 'battery', 'fullScreen'].forEach(key => {
            const el = document.getElementById(`perm-badge-${key}`);
            if (el) {
                el.textContent = 'শুধু অ্যাপে';
                el.className = 'text-[11px] font-bold px-2 py-1 rounded-full bg-slate-800 text-slate-500 whitespace-nowrap';
            }
        });
    }
}
