/* =============================================================================
   ডিজিটাল তাসবীহ
   ফরজ/নফল/কাস্টম মোড, কাউন্টার, কাস্টম জিকির সংরক্ষণ।
   ============================================================================= */

// --- TASBIH MODULE LOGIC ---
function initTasbihModule() {
    renderTasbihUI();
    if(tasbihMode === 'custom') renderCustomZikrList();
}

function switchTasbihMode(mode) {
    tasbihMode = mode;
    ['farz', 'nafal', 'custom'].forEach(m => {
        const btn = document.getElementById(`tbtn-${m}`);
        btn.className = (m === mode) ? "flex-1 image-button text-white py-2 text-xs rounded-lg font-bold" : "flex-1 text-slate-400 py-2 text-xs rounded-lg font-medium";
    });

    if(mode === 'custom') {
        document.getElementById('tasbih-main-container').classList.add('hidden');
        document.getElementById('tasbih-custom-form').classList.remove('hidden');
        renderCustomZikrList();
    } else {
        document.getElementById('tasbih-main-container').classList.remove('hidden');
        document.getElementById('tasbih-custom-form').classList.add('hidden');
        currentTasbihIndex = 0;
        tasbihCount = 0;
        updateCurrentTasbihFromList();
        renderTasbihUI();
    }
}

function updateCurrentTasbihFromList() {
    const list = (tasbihMode === 'farz') ? farzTasbihList : nafalTasbihList;
    if(tasbihMode === 'custom') return; // Handled separately

    const item = list[currentTasbihIndex];
    tasbihTitle = item.title;
    tasbihTarget = item.target;
}

function handleTasbihClick() {
    tasbihCount++;
    if(tasbihCount >= tasbihTarget) {
        // লক্ষ্যমাত্রা পূরণ হলে প্রোগ্রেস বার ১০০% হবে, তারপর ট্রানজিশন হবে
        renderTasbihUI();

        setTimeout(() => {
            if(tasbihMode === 'farz' && currentTasbihIndex < farzTasbihList.length - 1) {
                currentTasbihIndex++;
                tasbihCount = 0;
                updateCurrentTasbihFromList();
            } else if(tasbihMode === 'nafal') {
                currentTasbihIndex = (currentTasbihIndex + 1) % nafalTasbihList.length;
                tasbihCount = 0;
                updateCurrentTasbihFromList();
            } else {
                // কাস্টম বা শেষ জিকির হলে লক্ষ্যেই আটকে থাকবে রিসেট না হওয়া পর্যন্ত
                tasbihCount = tasbihTarget;
            }
            renderTasbihUI();
        }, 300); // ৩০০ মিলিসেকেন্ড ডিলে যাতে ইউজার পুর্ন বিত্ত দেখতে পায়
        return;
    }
    renderTasbihUI();
}

function resetCurrentTasbih() {
    tasbihCount = 0;
    renderTasbihUI();
}

function renderTasbihUI() {
    document.getElementById('tasbih-title').innerText = tasbihTitle;
    document.getElementById('tasbih-count').innerText = String(tasbihCount).padStart(2, '0');
    document.getElementById('tasbih-target').innerText = `লক্ষ্য: ${tasbihTarget}`;

    const offset = 283 - (tasbihCount / tasbihTarget) * 283;
    document.getElementById('tasbih-progress-ring').style.strokeDashoffset = offset;
}

function saveCustomZikr() {
    const name = document.getElementById('custom-zikr-name').value.trim();
    const target = parseInt(document.getElementById('custom-zikr-target').value);
    if(!name || isNaN(target)) return;

    customTasbihList.push({ title: name, target: target });
    localStorage.setItem('customTasbihList', JSON.stringify(customTasbihList));
    document.getElementById('custom-zikr-name').value = '';
    document.getElementById('custom-zikr-target').value = '';
    renderCustomZikrList();
}

function deleteCustomZikr(index) {
    customTasbihList.splice(index, 1);
    localStorage.setItem('customTasbihList', JSON.stringify(customTasbihList));
    renderCustomZikrList();
}

function startCustomZikr(index) {
    const item = customTasbihList[index];
    tasbihTitle = item.title;
    tasbihTarget = item.target;
    tasbihCount = 0;
    document.getElementById('tasbih-main-container').classList.remove('hidden');
    document.getElementById('tasbih-custom-form').classList.add('hidden');
    renderTasbihUI();
}

function renderCustomZikrList() {
    const listEl = document.getElementById('custom-zikr-list');
    let html = '';
    customTasbihList.forEach((item, index) => {
        html += `
                <div class="flex items-center justify-between bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div class="flex flex-col">
                        <span class="text-xs font-bold text-slate-200">${item.title}</span>
                        <span class="text-[12px] text-slate-500">লক্ষ্য: ${item.target}</span>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="startCustomZikr(${index})" class="bg-blue-600/20 text-blue-400 p-2 rounded-lg"><i class="fa-solid fa-play text-[12px]"></i></button>
                        <button onclick="deleteCustomZikr(${index})" class="bg-rose-600/20 text-rose-400 p-2 rounded-lg"><i class="fa-solid fa-trash text-[12px]"></i></button>
                    </div>
                </div>`;
    });
    listEl.innerHTML = html || '<p class="text-[12px] text-slate-500 text-center py-4">কোনো কাস্টম জিকির নেই</p>';
}
