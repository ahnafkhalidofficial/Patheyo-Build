/* =============================================================================
   PWA ইনস্টল ও এক-ক্লিক উইজেট
   হোমস্ক্রিনে ইনস্টল প্রম্পট এবং এক ক্লিকে উইজেট মোড চালু করার ফাংশন।
   ============================================================================= */

// PWA Installer Trigger Capture System
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    // Show shortcut button on header and widget control panel
    document.getElementById('btn-install-pwa').classList.remove('hidden');
    document.getElementById('btn-install-pwa-widget').classList.remove('hidden');
});

function installAppToHomeScreen() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                document.getElementById('btn-install-pwa').classList.add('hidden');
                document.getElementById('btn-install-pwa-widget').classList.add('hidden');
            }
            deferredPrompt = null;
        });
    } else {
        alert('আপনার ব্রাউজার বা ডিভাইসে শর্টকাট তৈরির সুবিধাটি এখন রেডি আছে। আপনি ব্রাউজারের থ্রি-ডট (Menu) অপশনে ক্লিক করে "Add to Home Screen" বা "Install App" এ ট্যাপ করে সরাসরি ইনস্টল করতে পারেন!');
    }
}

// এক ক্লিকে উইজেট চালু করার ফাংশন — মোবাইল বা পিসি, যেখানেই ব্যবহার করা হোক
// অ্যাপ ইনস্টল করা না থাকলে প্রথমে ইনস্টল প্রম্পট দেখাবে, তারপর সরাসরি উইজেট মোডে নিয়ে যাবে।
// ইনস্টল করা থাকলে (বা ইনস্টলেবল না হলে) পিসিতে আলাদা একটা ছোট উইজেট উইন্ডো খুলে দেবে, মোবাইলে সরাসরি উইজেট ভিউ চালু হবে।
function oneClickMakeWidget() {
    // যদি এই পেজটা তোমার অ্যান্ড্রয়েড স্টুডিও অ্যাপের WebView এর ভিতরে চলে এবং নেটিভ ব্রিজ যুক্ত করা থাকে,
    // তাহলে সরাসরি নেটিভ অ্যান্ড্রয়েড "হোমস্ক্রিনে উইজেট পিন করুন" সিস্টেম প্রম্পট চালু হবে — ঠিক "মুসলিম বাংলা" অ্যাপের মতো।
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.pinWidgetToHomeScreen === 'function') {
        window.AndroidWidgetBridge.pinWidgetToHomeScreen();
        return;
    }

    const isStandaloneApp = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    const isMobileDevice = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || window.innerWidth <= 768;

    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then(() => {
            deferredPrompt = null;
            document.getElementById('btn-install-pwa').classList.add('hidden');
            document.getElementById('btn-install-pwa-widget').classList.add('hidden');
            setTimeout(() => { toggleWidgetOnlyLayoutMode(true); }, 600);
        });
        return;
    }

    if (isStandaloneApp || isMobileDevice) {
        toggleWidgetOnlyLayoutMode(true);
    } else {
        const widgetWin = window.open(window.location.pathname + '?mode=widget', 'PrayerTimeWidget', 'width=640,height=480,resizable=yes,toolbar=no,menubar=no,location=no,status=no');
        if (!widgetWin) { toggleWidgetOnlyLayoutMode(true); }
    }
}
