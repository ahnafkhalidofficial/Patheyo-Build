/* =============================================================================
   উইজেট UI আপডেট
   লাইভ উইজেট প্রিভিউয়ের ভেতরের কার্ড/ঘড়ি/ওয়াক্ত আপডেট।
   ============================================================================= */

function updateWidgetUI(act, start, end, now, isGap, isForbidden, activeForbiddenWindow) {
    const waqts = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    const lbl = { 'Fajr': 'ফজর', 'Dhuhr': (now.getDay()===5?"জুম'আ":"যোহর"), 'Asr': 'আসর', 'Maghrib': 'মাগরিব', 'Isha': 'ইশা' };
    const isLight = (activeWidgetTheme === 'light');

    const logoWrapper = document.getElementById('wd-logo-wrapper');
    const fallbackIcon = document.getElementById('wd-fallback-icon');

    // ✅ FIX #11/#12: wd-celestial-title/time/box আর থিম অনুযায়ী বদলায় না — নেটিভ উইজেটেও
    // এই পিলটা সবসময় গাঢ় থাকে (widget_pill_background থিম-নির্বিশেষে একই), তাই .wd-pill/
    // .wd-pill-label ক্লাস (HTML-এ স্থায়ীভাবে বসানো) দিয়েই এটা হ্যান্ডেল হয়, এখানে আর হাত
    // দেওয়ার দরকার নেই — কোড সরল ও maintainable থাকে।
    // wd-date-arabic/wd-date-others-এ .wd-subtle ক্লাস (CSS) ডার্ক/নো-ব্যাকগ্রাউন্ডে
    // উজ্জ্বল সাদা আর লাইট থিমে গাঢ় ধূসর — সাইজ একটু বড় করা হয়েছে (হাল্কা বড় রিকোয়েস্ট)।
    if (isLight) {
        document.getElementById('wd-date-arabic').className = "wd-subtle text-[21px] md:text-[27px] font-bold text-[#070d19] tracking-wide truncate";
        document.getElementById('wd-date-others').className = "wd-subtle text-[14px] md:text-[16px] text-slate-600 mt-0.5 font-medium tracking-normal truncate";

        if (logoWrapper) logoWrapper.className = "w-12 h-12 md:w-14 md:h-14 bg-[#070d19] border border-slate-400 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md p-1";
        if (fallbackIcon) fallbackIcon.className = "fa-solid fa-mosque text-xl md:text-2xl text-blue-400 hidden";
    } else {
        document.getElementById('wd-date-arabic').className = "wd-subtle text-[21px] md:text-[27px] font-bold text-slate-100 tracking-wide truncate";
        document.getElementById('wd-date-others').className = "wd-subtle text-[14px] md:text-[16px] text-slate-400 mt-0.5 font-medium tracking-normal truncate";

        if (logoWrapper) logoWrapper.className = "w-12 h-12 md:w-14 md:h-14 bg-[#070d19] border border-slate-500 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md p-1";
        if (fallbackIcon) fallbackIcon.className = "fa-solid fa-mosque text-xl md:text-2xl text-white hidden";
    }

    waqts.forEach(w => {
        const card = document.getElementById(`wd-card-${w}`);
        if(card) {
            if(isLight) {
                card.className = "p-1.5 sm:p-3 rounded-xl flex flex-col items-center justify-center text-[#070d19] aspect-square sm:aspect-auto";
                card.innerHTML = `<span class="bengali-text wd-subtle text-[14px] md:text-[15px] font-semibold text-slate-600">${lbl[w]}</span>
                                          <span class="font-bold font-mono mt-0.5 text-sm sm:text-base text-[#070d19]">${convert24To12Compact(globalTimings[w])}</span>`;
            } else {
                card.className = "p-1.5 sm:p-3 rounded-xl flex flex-col items-center justify-center text-slate-300 aspect-square sm:aspect-auto";
                card.innerHTML = `<span class="bengali-text wd-subtle text-[14px] md:text-[15px] text-slate-400">${lbl[w]}</span>
                                          <span class="font-bold font-mono mt-0.5 text-sm sm:text-base text-slate-200">${convert24To12Compact(globalTimings[w])}</span>`;
            }
        }
    });

    // সক্রিয় ওয়াক্তের কার্ডটা কেবল রঙে আলাদা হবে — সাইজ/স্কেল কখনোই বদলাবে না, ৫টা কার্ডই সবসময় সমান মাপের থাকবে
    const actCard = act ? document.getElementById(`wd-card-${act}`) : null;
    if(actCard) {
        if (isForbidden) {
            actCard.className = "bg-rose-600 text-white p-1.5 sm:p-3 rounded-xl transition-all flex flex-col items-center justify-center aspect-square sm:aspect-auto";
            actCard.innerHTML = `<span class="text-sm md:text-base font-bold"><i class="fa-solid fa-ban mr-0.5"></i> ${lbl[act]}</span>
                                         <span class="font-bold font-mono mt-0.5 text-sm sm:text-base font-black">${convert24To12Compact(globalTimings[act])}</span>`;
        } else if(isLight) {
            actCard.className = "bg-[#f8fafc] text-[#070d19] p-1.5 sm:p-3 rounded-xl transition-all flex flex-col items-center justify-center aspect-square sm:aspect-auto border-2 border-slate-300";
            actCard.innerHTML = `<span class="bengali-text text-[14px] md:text-[15px] font-bold text-[#070d19]">${lbl[act]}</span>
                                         <span class="font-bold font-mono mt-0.5 text-sm sm:text-base font-black text-[#070d19]">${convert24To12Compact(globalTimings[act])}</span>`;
        } else {
            actCard.className = "bg-slate-200 text-slate-950 p-1.5 sm:p-3 rounded-xl transition-all flex flex-col items-center justify-center aspect-square sm:aspect-auto border-2 border-slate-400";
            actCard.innerHTML = `<span class="bengali-text text-[14px] md:text-[15px] font-bold text-slate-700">${lbl[act]}</span>
                                         <span class="font-bold font-mono mt-0.5 text-sm sm:text-base text-slate-950 font-black">${convert24To12Compact(globalTimings[act])}</span>`;
        }
    }

    const countdownWrapper = document.getElementById('wd-countdown-wrapper');

    // ✅ FIX v34: haramInfo আগে শুধু processDashboardTimelineUpdates()-এর লোকাল const ছিল, অথচ নিচে এই
    // আলাদা ফাংশনে ব্যবহৃত হতো → প্রতিবার "haramInfo is not defined" ReferenceError হয়ে ফাংশন থেমে যেত
    // (প্রতি সেকেন্ডের ঘড়ি-টাইমারেও)। ফলে এর পরের সব কাজ বাদ পড়ত। এখানে একই সূত্রে (একই `now` থেকে)
    // মানটা নিজেই বের করা হলো — ক্যালার ফাংশনের মানের সাথে হুবহু এক।
    const haramInfo = getHaramRozaStatus(getDisplayHijriDate(now));

    if (haramInfo) {
        countdownWrapper.className = "text-center text-xs sm:text-sm font-bold tracking-wide border-t border-rose-500/30 pt-2.5";
        countdownWrapper.innerHTML = `<span class="text-rose-400"><i class="fa-solid fa-circle-info mr-1"></i>${haramInfo.msg}</span>`;
    } else if (isForbidden) {
        countdownWrapper.className = "text-center text-xs sm:text-sm font-bold tracking-wide border-t border-rose-500/30 pt-2.5";
        const forbiddenHtml = buildForbiddenStatusHTML(activeForbiddenWindow, now, true);
        if (isLight) {
            countdownWrapper.innerHTML = `<span style="color:#ffffff;background:#e11d48;padding:4px 10px;border-radius:8px;display:inline-block">${forbiddenHtml}</span>`;
        } else {
            countdownWrapper.innerHTML = `<span style="color:#FACC15;background:#7f1d1d;padding:4px 10px;border-radius:8px;display:inline-block">${forbiddenHtml}</span>`;
        }
    } else if (isGap) {
        // গ্যাপ পিরিয়ডে (ফজরের পর থেকে যোহরের আগ পর্যন্ত, নিষিদ্ধ সময় ছাড়া) উইজেটে কোনো লেখা দেখানো হবে না — ইচ্ছাকৃতভাবে ফাঁকা
        countdownWrapper.className = "text-center text-xs sm:text-sm font-semibold tracking-wide border-t border-slate-800/40 pt-2.5";
        countdownWrapper.innerHTML = '';
    } else {
        const phase = getWaqtPhaseInfo(start, end, now);

        // যদি সময় শেষ হয়ে যায় তবে নেগেটিভ ভ্যালু দেখানোর বদলে টাইমার হাইড করা হবে
        if (phase.isOver || phase.diffStr.startsWith("-")) {
            countdownWrapper.innerHTML = '';
            return;
        }

        const waqtNameShort = lbl[act].split(' ')[0];
        const label = phase.isFirstHalf ? `${waqtNameShort}-এর সময় অতিবাহিত` : `${waqtNameShort}-এর সময় শেষ হতে বাকি`;
        if (isLight) {
            countdownWrapper.className = "text-center text-xs sm:text-sm font-bold tracking-wide border-t border-slate-300 pt-2.5 text-[#070d19]";
            countdownWrapper.innerHTML = `<span>${label} <span class="font-mono">${phase.diffStr}</span></span>`;
        } else {
            countdownWrapper.className = "text-center text-xs sm:text-sm font-semibold tracking-wide border-t border-slate-800/40 pt-2.5";
            countdownWrapper.innerHTML = `<span class="text-amber-400 font-bold">${label} ${phase.diffStr}</span>`;
        }
    }
}
