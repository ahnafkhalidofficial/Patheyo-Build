/* =============================================================================
   হিজরি ক্যালেন্ডার
   অফলাইন-সহনশীল হিজরি তারিখ গণনা (Tabular Islamic Calendar) ও প্রদর্শন।
   ============================================================================= */

// ============================================================================
// অফলাইন-সহনশীল হিজরি তারিখ ব্যবস্থা
// ইন্টারনেট থাকলে API থেকে আসা হিজরি তারিখটাই বিশ্বস্ত উৎস হিসেবে ব্যবহার হয়।
// ইন্টারনেট না থাকলে (বা পুরোনো একাধিক দিনের ক্যাশ হলে) নিচের ক্যালেন্ডার সূত্র (Tabular
// Islamic Calendar) দিয়ে সরাসরি ফোনের লোকাল তারিখ থেকেই হিজরি তারিখ বের করে ফেলা হয় —
// এর জন্য কোনো নেট লাগে না, তাই প্রতিদিন এমনিতেই ঠিকভাবে এগিয়ে যাবে।
// দুই ক্ষেত্রেই: রাত ১২টার বদলে মাগরিবের সাথে সাথে পরের দিনে চলে যায়।
// ============================================================================
function gregorianToJDN(y, m, d) {
    const a = Math.floor((14 - m) / 12);
    const y2 = y + 4800 - a;
    const m2 = m + 12 * a - 3;
    return d + Math.floor((153 * m2 + 2) / 5) + 365 * y2 + Math.floor(y2 / 4) - Math.floor(y2 / 100) + Math.floor(y2 / 400) - 32045;
}
function localGregorianToHijri(date, ignoreAdjustment = false) {
    const jdn = gregorianToJDN(date.getFullYear(), date.getMonth() + 1, date.getDate());
    const ISLAMIC_EPOCH = 1948440;
    let l = jdn - ISLAMIC_EPOCH + 10632;

    // ✅ Firebase থেকে আসা অ্যাডজাস্টমেন্ট এখানে যোগ করা হলো
    if (!ignoreAdjustment) {
        const adj = (window._nativeHijriAdjustment !== undefined) ? parseInt(window._nativeHijriAdjustment) : 0;
        l += adj;
    }

    let n = Math.floor((l - 1) / 10631);
    l = l - 10631 * n + 354;
    let j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
    l = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
    const month = Math.floor((24 * l) / 709);
    const day = l - Math.floor((709 * month) / 24);
    const year = 30 * n + j - 30;
    return { day, month: month - 1, year, monthLength: null };
}
function addHijriDays(anchor, n) {
    if (n === 0) return anchor;
    let { day, month, year } = anchor;
    const len = anchor.monthLength || 30;
    day += n;
    if (day > len) {
        day -= len; month += 1; if (month > 11) { month = 0; year += 1; }
    } else if (day < 1) {
        month -= 1; if (month < 0) { month = 11; year -= 1; }
        day += 30;
    }
    return { day, month, year, monthLength: anchor.monthLength };
}
function toDateOnlyStr(d) { return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`; }

// আজকে কী হিজরি তারিখ দেখানো হবে — মাগরিব পার হয়েছে কিনা সেটা বিবেচনা করে
function getDisplayHijriDate(now, ignoreAdjustment = false, ignoreMaghrib = false) {
    const todayStr = toDateOnlyStr(now);
    const maghribTodayStr = globalTimings && globalTimings.Maghrib ? globalTimings.Maghrib : null;
    const maghribPassed = !ignoreMaghrib && !!(maghribTodayStr && now >= parseWaqtStringToDate(maghribTodayStr));

    if (hijriApiAnchor && hijriApiAnchor.fetchedForDateStr === todayStr) {
        let h = Object.assign({}, hijriApiAnchor);
        if (maghribPassed) h = addHijriDays(h, 1);
        if (!ignoreAdjustment) {
            const adj = (window._nativeHijriAdjustment !== undefined) ? parseInt(window._nativeHijriAdjustment) : 0;
            if (adj !== 0) h = addHijriDays(h, adj);
        }
        return h;
    }
    const targetDate = maghribPassed ? new Date(now.getTime() + 24 * 60 * 60000) : now;
    return localGregorianToHijri(targetDate, ignoreAdjustment);
}
function formatHijriDate(h) { return `${h.day} ${hijriMonthsBN[h.month]} ${h.year}`; }

// হিজরি তারিখের চূড়ান্ত স্ট্রিং বের করা (Firebase ডিরেক্ট ডেট থাকলে সেটিই প্রাধান্য পাবে)
function getFinalHijriDisplayString(now, ignoreAdjustment = false, ignoreMaghrib = false) {
    if (window._nativeDirectHijriDate && !ignoreAdjustment) return window._nativeDirectHijriDate;
    return formatHijriDate(getDisplayHijriDate(now, ignoreAdjustment, ignoreMaghrib));
}
