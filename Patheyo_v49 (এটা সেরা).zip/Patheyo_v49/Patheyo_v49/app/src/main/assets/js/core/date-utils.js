/* =============================================================================
   তারিখ/সময় ইউটিলিটি
   বাংলা সন গণনা, ওয়াক্ত স্ট্রিং → Date, ২৪→১২ ঘণ্টা রূপান্তর।
   ============================================================================= */

function getBengaliCalendarCalculation(date, includeSuffix) {
    let yr = date.getFullYear(); let isLp = (yr % 4 === 0 && yr % 100 !== 0) || (yr % 400 === 0);
    const daysInMonths = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, isLp ? 30 : 29, 30];
    let bYear = yr - 593; let boishakhMap = new Date(yr, 3, 14);
    if (date < boishakhMap) { bYear -= 1; boishakhMap = new Date(yr - 1, 3, 14); }
    let diff = Math.floor((date - boishakhMap) / 86400000);
    let idx = 0; let bDay = diff + 1;
    while (bDay > daysInMonths[idx]) { bDay -= daysInMonths[idx]; idx++; }
    return includeSuffix ? `${bDay} ${banglaMonthsBN[idx]} ${bYear} বঙ্গাব্দ` : `${bDay} ${banglaMonthsBN[idx]} ${bYear}`;
}
function parseWaqtStringToDate(str) { const now = new Date(); const [h, m] = str.split(':').map(Number); return new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m, 0); }
function convert24To12(s24) { if(!s24) return "--:-- --"; let [h, m] = s24.split(':'); h = parseInt(h); const suf = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return `${String(h).padStart(2,'0')}:${m} ${suf}`; }
function convert24To12Compact(s24) { if(!s24) return "--:--"; let [h, m] = s24.split(':'); h = parseInt(h); h = h % 12 || 12; return `${String(h).padStart(2,'0')}:${m}`; }
