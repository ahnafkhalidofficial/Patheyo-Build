/* =============================================================================
   ট্যাব নেভিগেশন
   switchTab, মোবাইল ভিউপোর্ট চেক, স্ক্রল-হেডার আচরণ।
   ============================================================================= */

function switchTab(tId) {
    if (tId !== 'qibla') { stopQiblaCompass(); }

    const mainContent = document.querySelector('main');
    if (mainContent) {
        mainContent.classList.add('tab-transitioning');
    }

    setTimeout(() => {
        // ব্রাউজারের ব্যাক বাটন কাজ করানোর জন্য history এন্ট্রি যোগ করা হচ্ছে
        // ওয়েবসাইটে ব্রাউজার ব্যাক, অ্যাপে Android ব্যাক — দুটোই কাজ করবে
        if (typeof history !== 'undefined' && history.pushState) {
            history.pushState({ tab: tId }, '', '#' + tId);
        }
        ['dashboard', 'qibla', 'widgets', 'tasbih', 'quran', 'permission'].forEach(t => {
            document.getElementById(`view-${t}`)?.classList.add('hidden');
            document.getElementById(`tab-${t}`)?.setAttribute('class', "px-3 py-1 md:px-4 md:py-1.5 rounded-lg text-xs font-medium transition text-slate-400 hover:text-white whitespace-nowrap");
        });
        document.getElementById(`view-${tId}`)?.classList.remove('hidden');
        document.getElementById(`tab-${tId}`)?.setAttribute('class', "px-3 py-1 md:px-4 md:py-1.5 rounded-lg text-xs font-semibold transition image-button text-white whitespace-nowrap");

        if(tId === 'qibla') { startQiblaCompass(); }
        if(tId === 'widgets') { updateWidgetPreviewImage(); }
        if(tId === 'tasbih') { initTasbihModule(); }
        if(tId === 'quran') { loadQuranIndexDropdown(); }
        if(tId === 'permission') { refreshPermissionStatuses(); }

        if (mainContent) {
            mainContent.classList.remove('tab-transitioning');
        }
    }, 150);
}

// মোবাইলে কুরআন রিডিং স্ক্রল করার সময় উপরের হেডার ও কন্ট্রোল প্যানেল হাইড করে শুধু আয়াত দেখানোর ফিচার
function isMobileViewportNow() { return window.innerWidth <= 768; }

function restoreQuranHeaderView() {
    document.getElementById('main-app-header').classList.remove('quran-scrolled-hide');
    const qc = document.getElementById('quran-controls-row');
    if (qc) qc.classList.remove('quran-scrolled-hide');
    document.getElementById('quran-restore-header-btn').style.display = 'none';
}

window.addEventListener('scroll', () => {
    if (!isMobileViewportNow()) return;
    const quranTabActive = !document.getElementById('view-quran').classList.contains('hidden');
    if (!quranTabActive) return;

    const header = document.getElementById('main-app-header');
    const qc = document.getElementById('quran-controls-row');
    const restoreBtn = document.getElementById('quran-restore-header-btn');

    if (window.scrollY > 70) {
        header.classList.add('quran-scrolled-hide');
        if (qc) qc.classList.add('quran-scrolled-hide');
        restoreBtn.style.display = 'flex';
    } else if (window.scrollY < 10) {
        restoreQuranHeaderView();
    }
}, { passive: true });
