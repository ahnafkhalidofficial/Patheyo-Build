/* =============================================================================
   কুরআন
   সূরা/পারা তালিকা লোড, আয়াত রেন্ডার, থিম ও ভিউ মোড বদল।
   ============================================================================= */

async function loadQuranIndexDropdown() {
    const select = document.getElementById('quran-selector-dropdown');
    if (!isActuallyOnline()) {
        select.innerHTML = '<option>ইন্টারনেট সংযোগ নেই</option>';
        document.getElementById('quran-display-box').innerHTML = '<p class="text-amber-400 text-xs text-center p-8"><i class="fa-solid fa-wifi mr-1.5"></i>কুরআন শরিফ পড়ার জন্য দয়া করে ইন্টারনেট সংযোগ চালু করুন।</p>';
        return;
    }
    select.innerHTML = '<option>লোড হচ্ছে...</option>';
    try {
        if(quranViewMode === 'surah') {
            const res = await fetch("https://api.alquran.cloud/v1/surah"); 
            const d = await res.json();
            let h = ''; 
            d.data.forEach(s => { 
                h += `<option value="${s.number}">সূরা ${s.number}: ${s.name} (${s.englishName})</option>`; 
            });
            select.innerHTML = h;
        } else {
            let h = ''; 
            for(let i=1; i<=30; i++) { h += `<option value="${i}">পারা (Juz) ${i}</option>`; }
            select.innerHTML = h;
        }
        loadQuranContent();
    } catch(e) { select.innerHTML = '<option>ত্রুটি ঘটেছে</option>'; }
}

// প্রিন্টেড কুরআনের মত সূরার নাম ও বিসমিল্লাহ আলাদা সুন্দর হেডার তৈরি করার ফাংশন
// সূরা ১ (আল-ফাতিহা) এ বিসমিল্লাহ নিজেই প্রথম আয়াত, এবং সূরা ৯ (আত-তাওবা) এ বিসমিল্লাহ থাকে না — তাই এই দুই সূরায় আলাদা বিসমিল্লাহ লাইন দেখানো হবে না
function buildPrintedSurahHeaderHTML(surahNumber, surahNameArabic) {
    let h = `
            <div class="text-center py-2 mb-3 md:mb-4">
                <div class="inline-block px-6 sm:px-8 py-2 mb-3 bg-gradient-to-r from-transparent via-blue-500/10 to-transparent border-y border-blue-500/30">
                    <span class="quran-font text-xl sm:text-2xl md:text-3xl text-blue-300 font-bold" dir="rtl">${surahNameArabic}</span>
                </div>`;
    if (surahNumber !== 1 && surahNumber !== 9) {
        h += `<div class="quran-font text-xl sm:text-2xl md:text-3xl text-slate-100 font-normal" dir="rtl">بِسْمِ اللَّهِ الرَّحْمٰنِ الرَّحِيمِ</div>`;
    }
    h += `</div>`;
    return h;
}

async function loadQuranContent() {
    const box = document.getElementById('quran-display-box');
    const val = document.getElementById('quran-selector-dropdown').value || 1;

    if (!isActuallyOnline()) {
        box.innerHTML = '<p class="text-amber-400 text-xs text-center p-8"><i class="fa-solid fa-wifi mr-1.5"></i>কুরআন শরিফ পড়ার জন্য দয়া করে ইন্টারনেট সংযোগ চালু করুন।</p>';
        return;
    }
    box.innerHTML = '<div class="text-center py-12 text-slate-400 font-mono"><i class="fa-solid fa-spinner animate-spin text-blue-500 mb-2"></i><p>পবিত্র কুরআনের আয়াতসমূহ লোড হচ্ছে...</p></div>';

    try {
        const targetType = quranViewMode === 'surah' ? 'surah' : 'juz';
        const isParaMode = quranViewMode === 'para';

        let arData = null, bnData = null;

        if (isParaMode) {
            const arRes = await fetch(`https://api.alquran.cloud/v1/${targetType}/${val}/quran-uthmani`);
            arData = await arRes.json();
        } else {
            const [arRes, bnRes] = await Promise.all([
                fetch(`https://api.alquran.cloud/v1/${targetType}/${val}/quran-uthmani`),
                fetch(`https://api.alquran.cloud/v1/${targetType}/${val}/bn.bengali`)
            ]);
            arData = await arRes.json();
            bnData = await bnRes.json();
        }

        const arAyahs = arData.data.ayahs;

        if (isParaMode) {
            let html = '<div class="p-2 md:p-6 bg-slate-900/20 rounded-2xl border border-slate-800/60 text-right leading-loose" dir="rtl">';
            let currentSurahNum = -1;

            for(let i = 0; i < arAyahs.length; i++) {
                const ar = arAyahs[i];

                if (ar.surah.number !== currentSurahNum) {
                    if (currentSurahNum !== -1) { html += `</p></div>`; }
                    currentSurahNum = ar.surah.number;
                    html += buildPrintedSurahHeaderHTML(ar.surah.number, ar.surah.name);
                    html += `
                            <div class="p-1.5 md:p-4 bg-slate-950/20 rounded-xl border border-slate-800/30 tracking-wide text-right" dir="rtl">
                                <p class="quran-font text-xl sm:text-2xl md:text-3xl font-normal drop-shadow-sm inline" style="line-height:3.6 !important">`;
                }
                html += `${ar.text} <span class="ayah-marker text-blue-500 font-sans text-sm md:text-xl mx-1 select-none" dir="ltr">﴿${ar.numberInSurah}﴾</span> `;
            }
            if (currentSurahNum !== -1) { html += `</p></div>`; }
            html += '</div>';
            box.innerHTML = html;
        } else {
            const bnAyahs = bnData.data.ayahs;
            let html = '<div class="space-y-4 md:space-y-6 p-0.5">';
            html += buildPrintedSurahHeaderHTML(arData.data.number, arData.data.name);
            for(let i = 0; i < arAyahs.length; i++) {
                const ar = arAyahs[i]; const bn = bnAyahs[i];
                html += `
                        <div class="p-2.5 md:p-5 bg-slate-900/30 rounded-2xl border border-slate-800/60 space-y-3 md:space-y-4 hover:border-blue-500/20 transition-all shadow-sm">
                            <div class="flex justify-between items-center text-[12px] md:text-[13px] text-slate-400 font-mono border-b border-slate-800/40 pb-2">
                                <span class="bg-slate-900/80 px-2 py-0.5 rounded-lg text-blue-400 font-bold">আয়াত: ${ar.numberInSurah}</span>
                                <span class="text-slate-500">পবিত্র কুরআন</span>
                            </div>
                            <p class="quran-font text-xl sm:text-2xl md:text-3xl text-right tracking-wide text-slate-100 font-normal select-all drop-shadow-sm py-1" dir="rtl" style="line-height:3.6 !important">
                                ${ar.text} <span class="ayah-marker text-blue-500/80 font-sans text-base md:text-xl mr-1 select-none">﴿${ar.numberInSurah}﴾</span>
                            </p>
                            <p class="text-xs md:text-sm text-slate-300 leading-relaxed font-normal pt-2.5 border-t border-slate-800/40 text-left">
                                <span class="text-blue-500 font-semibold mr-1">তর্জমা:</span> ${bn.text}
                            </p>
                        </div>`;
            }
            html += '</div>';
            box.innerHTML = html;
        }
        box.scrollTop = 0;
    } catch(e) {
        console.error(e);
        if (!isActuallyOnline()) {
            box.innerHTML = '<p class="text-amber-400 text-xs text-center p-8"><i class="fa-solid fa-wifi mr-1.5"></i>কুরআন শরিফ পড়ার জন্য দয়া করে ইন্টারনেট সংযোগ চালু করুন।</p>';
        } else {
            box.innerHTML = '<p class="text-rose-400 text-xs text-center p-6"><i class="fa-solid fa-triangle-exclamation mr-1"></i>ডাটা লোড করা যায়নি। আবার চেষ্টা করুন।</p>'; 
        }
    }
}

function changeQuranTheme(themeKey) {
    const box = document.getElementById('quran-display-box');
    box.className = "space-y-4 p-2 md:p-4 rounded-xl min-h-[50vh] max-h-[65vh] overflow-y-auto antialiased ";
    if(themeKey === 'white') box.classList.add('quran-theme-white');
    if(themeKey === 'sepia') box.classList.add('quran-theme-sepia');
    if(themeKey === 'dark') box.classList.add('quran-theme-dark');
}

function switchQuranViewMode(mode) {
    quranViewMode = mode;
    ['surah', 'para'].forEach(m => {
        document.getElementById(`qbtn-${m}`).className = "text-slate-400 px-2 py-1 text-[13px] md:px-3 md:py-1.5 md:text-xs rounded-lg font-medium whitespace-nowrap";
    });
    document.getElementById(`qbtn-${mode}`).className = "image-button text-white px-2 py-1 text-[13px] md:px-3 md:py-1.5 md:text-xs rounded-lg font-bold whitespace-nowrap";
    loadQuranIndexDropdown();
}
