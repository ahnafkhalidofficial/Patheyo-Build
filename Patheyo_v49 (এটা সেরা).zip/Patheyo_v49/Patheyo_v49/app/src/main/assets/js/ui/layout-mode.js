/* =============================================================================
   শুধু-উইজেট লেআউট মোড
   হেডার/ফুটার লুকিয়ে শুধু উইজেট ভিউ দেখানো ও আগের অবস্থায় ফেরা।
   ============================================================================= */

function toggleWidgetOnlyLayoutMode(enable) {
    const header = document.getElementById('main-app-header');
    const footer = document.getElementById('main-app-footer');
    const dashboard = document.getElementById('view-dashboard');
    const quran = document.getElementById('view-quran');
    const tasbih = document.getElementById('view-tasbih');
    const exitBtn = document.getElementById('exit-widget-view-btn');

    if(enable) {
        header.classList.add('hidden'); footer.classList.add('hidden');
        dashboard.classList.add('hidden'); quran.classList.add('hidden'); tasbih.classList.add('hidden');
        switchTab('widgets'); exitBtn.classList.remove('hidden');
        document.body.style.backgroundColor = "transparent";
    } else {
        header.classList.remove('hidden'); footer.classList.remove('hidden'); exitBtn.classList.add('hidden');
        document.body.style.backgroundColor = "#070d19"; switchTab('dashboard');
    }
}
