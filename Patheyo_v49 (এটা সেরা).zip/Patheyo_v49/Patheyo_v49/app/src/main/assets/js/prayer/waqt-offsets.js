/* =============================================================================
   ওয়াক্তের মিনিট এডজাস্টমেন্ট
   লোকাল মসজিদের সময়সূচির সাথে মেলাতে প্রতিটা ওয়াক্তে মিনিট কম/বেশি করা।
   ============================================================================= */

// প্রতিটা ওয়াক্তের সময়ে ম্যানুয়াল মিনিট এডজাস্টমেন্ট প্রয়োগ করা (লোকাল মসজিদের সময়সূচির সাথে মেলানোর জন্য)
function shiftTimeStr(hhmm, offsetMin) {
    if (!hhmm || !offsetMin) return hhmm;
    const [h, m] = hhmm.split(':').map(Number);
    let total = h * 60 + m + offsetMin;
    total = ((total % 1440) + 1440) % 1440;
    return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
}
// ✅ FIX #5: আলাদিন এপিআই যে মাগরিব/সূর্যাস্তের সময় দেয়, তার সাথে স্থায়ীভাবে +৩ মিনিট যোগ করে
// সেটাই "প্রকৃত" মাগরিব/সূর্যাস্তের সময় হিসেবে ব্যবহার করা হয় — অ্যাপ, উইজেট, আজানের অ্যালার্ম,
// নোটিফিকেশন সব জায়গায় (কারণ সব জায়গাতেই এই একই globalTimings/saveTimings ব্যবহার হয়)।
// এটা শুধুই মাগরিব/সূর্যাস্তের জন্য — অন্য কোনো ওয়াক্তে এই +৩ মিনিট প্রযোজ্য নয়।
const MAGHRIB_FIXED_OFFSET_MIN = 3;
function applyWaqtMinuteOffsets(timings) {
    const out = Object.assign({}, timings);
    if (out.Maghrib) out.Maghrib = shiftTimeStr(out.Maghrib, MAGHRIB_FIXED_OFFSET_MIN);
    if (out.Sunset) out.Sunset = shiftTimeStr(out.Sunset, MAGHRIB_FIXED_OFFSET_MIN);
    ['Fajr','Dhuhr','Asr','Maghrib','Isha'].forEach(w => {
        if (waqtMinuteOffsets[w]) out[w] = shiftTimeStr(out[w], waqtMinuteOffsets[w]);
    });
    return out;
}
function saveWaqtMinuteOffset(wKey, minutes) {
    waqtMinuteOffsets[wKey] = parseInt(minutes) || 0;
    localStorage.setItem('waqtMinuteOffsets', JSON.stringify(waqtMinuteOffsets));
    fetchCorePrayerData(); // পুনরায় হিসাব করে সব জায়গায় (ড্যাশবোর্ড, উইজেট, নেটিভ) আপডেট করা হবে
}
