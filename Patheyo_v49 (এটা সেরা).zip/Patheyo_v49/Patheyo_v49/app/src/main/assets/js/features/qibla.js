/* =============================================================================
   কিবলা কম্পাস
   ডিভাইস অরিয়েন্টেশন ও লোকেশন থেকে কিবলার দিক গণনা।
   ============================================================================= */

// --- QIBLA COMPASS LOGIC ---
function startQiblaCompass() {
    isCompassRunning = true;
    calculateQibla();
    if (window.DeviceOrientationEvent) {
        window.addEventListener('deviceorientationabsolute', handleOrientation, true);
        window.addEventListener('deviceorientation', handleOrientation, true);
    }
}

function stopQiblaCompass() {
    isCompassRunning = false;
    window.removeEventListener('deviceorientationabsolute', handleOrientation);
    window.removeEventListener('deviceorientation', handleOrientation);
}

function handleOrientation(event) {
    if (!isCompassRunning) return;
    let heading = event.webkitCompassHeading || event.alpha;
    if (event.absolute !== true && event.webkitCompassHeading === undefined) {
        // Not absolute heading, might be inaccurate
    }
    if (heading === undefined) return;

    compassHeading = heading;
    const compassEl = document.getElementById('compass-outer');
    const pointerEl = document.getElementById('qibla-pointer-container');

    // Rotate the compass ring opposite to heading
    compassEl.style.transform = `rotate(${-heading}deg)`;
    // Rotate the pointer container towards Qibla
    pointerEl.style.transform = `rotate(${qiblaDirection - heading}deg)`;
}

function calculateQibla() {
    // Standard Qibla formula based on Lat/Lng
    const kaabaLat = 21.4225; const kaabaLng = 39.8262;
    const lat1 = userLat * Math.PI / 180; const lng1 = userLng * Math.PI / 180;
    const lat2 = kaabaLat * Math.PI / 180; const lng2 = kaabaLng * Math.PI / 180;

    const y = Math.sin(lng2 - lng1);
    const x = Math.cos(lat1) * Math.tan(lat2) - Math.sin(lat1) * Math.cos(lng2 - lng1);
    let qiblaRad = Math.atan2(y, x);
    qiblaDirection = (qiblaRad * 180 / Math.PI + 360) % 360;

    document.getElementById('qibla-angle').innerText = `${Math.round(qiblaDirection)}°`;
    document.getElementById('qibla-location').innerText = `${userLat.toFixed(2)}, ${userLng.toFixed(2)}`;
}
