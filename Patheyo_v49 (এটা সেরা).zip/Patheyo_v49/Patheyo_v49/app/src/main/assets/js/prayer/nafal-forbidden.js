/* =============================================================================
   নফল ও মাকরুহ সময়
   নফল নামাজের সময় ও নিষিদ্ধ (মাকরুহ) সময়ের গণনা ও কার্ড রেন্ডার।
   ============================================================================= */

// --- NAFAL & FORBIDDEN CALCULATIONS ---
function renderNafalAndForbiddenCards(tm, now) {
    const zawalStart = new Date(tm['Dhuhr'].getTime() - 12 * 60000);

    // 1. Ishrak
    const ishrakStart = new Date(tm['Sunrise'].getTime() + 15 * 60000);
    const ishrakEnd = new Date(zawalStart.getTime() - 5 * 60000);

    // 2. Chasht/Duha
    const duhaStart = new Date(tm['Sunrise'].getTime() + ((zawalStart.getTime() - tm['Sunrise'].getTime()) / 2));
    const duhaEnd = new Date(zawalStart.getTime() - 15 * 60000);

    // 3. Awabin
    const awabinStart = new Date(tm['Maghrib'].getTime() + 15 * 60000);
    const awabinEnd = new Date(tm['Isha'].getTime() - 5 * 60000);

    // 4. Tahajjud
    const tahajjudEnd = new Date(tm['Fajr'].getTime() - 10 * 60000);

    const nafalContainer = document.getElementById('nafal-prayer-container');
    const nafalItems = [
        { name: 'ইশরাক (Ishrak)', start: ishrakStart, end: ishrakEnd },
        { name: 'চাশত (Chasht/Duha)', start: duhaStart, end: duhaEnd },
        { name: 'আওয়াবিন (Awabin)', start: awabinStart, end: awabinEnd },
        { name: 'তাহাজ্জুদ (Tahajjud)', start: null, end: tahajjudEnd }
    ];

    let nafalHtml = '';
    nafalItems.forEach(item => {
        const startStr = item.start ? convert24To12Compact(`${item.start.getHours()}:${item.start.getMinutes()}`) : "--:--";
        const endStr = convert24To12Compact(`${item.end.getHours()}:${item.end.getMinutes()}`);
        const isActive = item.start ? (now >= item.start && now < item.end) : (now < item.end || now > tm['Isha']);

        nafalHtml += `
                <div class="p-3 rounded-xl flex flex-col items-center text-center transition-all ${isActive ? 'bg-blue-600/10 border border-blue-500/30' : 'bg-slate-900/40 border border-slate-800'}">
                    <span class="text-[12px] md:text-[13px] text-slate-400 font-medium">${item.name}</span>
                    <span class="text-xs md:text-sm font-bold text-slate-200 mt-1 font-mono">${startStr} - ${endStr}</span>
                    ${isActive ? '<span class="text-[10px] bg-blue-600 text-white px-1.5 py-0.5 rounded-full mt-1.5 uppercase font-bold">চলমান</span>' : ''}
                </div>`;
    });
    nafalContainer.innerHTML = nafalHtml;

    const forbiddenContainer = document.getElementById('forbidden-times-container');
    const forbiddenItems = [
        { name: 'সূর্যোদয় (Sunrise)', start: tm['Sunrise'], end: new Date(tm['Sunrise'].getTime() + 15 * 60000) },
        { name: 'দুপুর (Noon/Zawal)', start: zawalStart, end: tm['Dhuhr'] },
        { name: 'সূর্যাস্ত (Sunset)', start: new Date(tm['Sunset'].getTime() - 15 * 60000), end: tm['Sunset'] }
    ];

    let forbiddenHtml = '';
    forbiddenItems.forEach(item => {
        const startStr = convert24To12Compact(`${item.start.getHours()}:${item.start.getMinutes()}`);
        const endStr = convert24To12Compact(`${item.end.getHours()}:${item.end.getMinutes()}`);
        const isActive = (now >= item.start && now < item.end);

        forbiddenHtml += `
                <div class="p-3 rounded-xl flex justify-between items-center transition-all ${isActive ? 'bg-rose-600/10 border-2 border-rose-500/50' : 'bg-slate-900/40 border border-slate-800'}">
                    <div class="flex flex-col">
                        <span class="text-[12px] md:text-[13px] text-slate-400 font-medium">${item.name}</span>
                        <span class="text-xs md:text-sm font-bold text-slate-200 font-mono">${startStr} - ${endStr}</span>
                    </div>
                    ${isActive ? '<span class="text-[10px] bg-rose-600 text-white px-1.5 py-0.5 rounded-full uppercase font-bold animate-pulse">নিষিদ্ধ</span>' : ''}
                </div>`;
    });
    forbiddenContainer.innerHTML = forbiddenHtml;
}
