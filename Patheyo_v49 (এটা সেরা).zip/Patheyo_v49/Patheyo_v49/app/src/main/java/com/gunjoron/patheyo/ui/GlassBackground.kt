package com.gunjoron.patheyo.ui

import android.app.Activity
import android.graphics.*
import android.graphics.drawable.Drawable

/**
 * v36 (v40-এ রঙ ঠিক করা): Android 12-এর আসল window-blur না থাকলে (পুরনো ফোন / ব্লার বন্ধ) —
 * অ্যাপের বর্তমান স্ক্রিন ছোট করে ঝাপসা বানিয়ে পপআপের পেছনে বসানো হয়, যাতে একই "ফ্রস্টেড গ্লাস" দেখা যায়।
 * কোনো ধাপে সমস্যা হলে null ফেরত দেয়, তখন সলিড গ্লাস-ই দেখায় (কখনো ক্র্যাশ করে না)।
 */
internal object GlassBackground {

    fun captureFrosted(activity: Activity): Bitmap? = try {
        val decor = activity.window.decorView
        val w = decor.width; val h = decor.height
        if (w <= 0 || h <= 0) null else {
            val sw = (w / 14).coerceAtLeast(8); val sh = (h / 14).coerceAtLeast(8)
            val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.drawColor(0xFF070D19.toInt())
            c.scale(sw.toFloat() / w, sh.toFloat() / h)
            decor.draw(c)
            boxBlur(bmp, radius = 2, passes = 3)
            bmp
        }
    } catch (_: Throwable) { null }

    private fun boxBlur(bmp: Bitmap, radius: Int, passes: Int) {
        val w = bmp.width; val h = bmp.height
        val a = IntArray(w * h); bmp.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h)
        repeat(passes) { blurLine(a, b, w, h, radius, true); blurLine(b, a, w, h, radius, false) }
        bmp.setPixels(a, 0, w, 0, 0, w, h)
    }

    private fun blurLine(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        for (y in 0 until h) for (x in 0 until w) {
            var ra = 0; var rr = 0; var rg = 0; var rb = 0; var n = 0
            for (d in -r..r) {
                val xx = if (horizontal) (x + d).coerceIn(0, w - 1) else x
                val yy = if (horizontal) y else (y + d).coerceIn(0, h - 1)
                val p = src[yy * w + xx]
                ra += p ushr 24; rr += (p shr 16) and 255; rg += (p shr 8) and 255; rb += p and 255; n++
            }
            dst[y * w + x] = ((ra / n) shl 24) or ((rr / n) shl 16) or ((rg / n) shl 8) or (rb / n)
        }
    }

    // পিক্সেলের উজ্জ্বলতা (luminance) হিসাবের ওজন
    private const val LR = 0.2126f
    private const val LG = 0.7152f
    private const val LB = 0.0722f

    /** ঝাপসা স্ক্রিনের নির্দিষ্ট অংশ + গ্লাস টিন্ট + উপরে হালকা আলোর ঝিলিক + পাতলা বর্ডার */
    class GlassDrawable(
        private val bmp: Bitmap, private val src: Rect, private val radius: Float,
        private val tintTop: Int, private val tintBottom: Int, strokeColor: Int, private val density: Float
    ) : Drawable() {
        // v40: ধরা স্ক্রিন-ছবি যত উজ্জ্বলই হোক (কিছু ফোনে WebView ধরা পড়ে না → সাদা ছবি আসে),
        // সেটাকে ডার্ক-ব্লু রেঞ্জে বসিয়ে দেওয়া হয় — তাই গ্লাস কখনো ধূসর/ধুয়াসা দেখায় না।
        private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                0.06f * LR, 0.06f * LG, 0.06f * LB, 0f, 6f,
                0.11f * LR, 0.11f * LG, 0.11f * LB, 0f, 12f,
                0.22f * LR, 0.22f * LG, 0.22f * LB, 0f, 26f,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = density; color = strokeColor
        }
        private val path = Path()
        private val inset = RectF()

        override fun onBoundsChange(b: Rect) {
            path.reset()
            path.addRoundRect(RectF(b), radius, radius, Path.Direction.CW)
            val t = b.top.toFloat(); val bt = b.bottom.toFloat()
            tintPaint.shader = LinearGradient(0f, t, 0f, bt, tintTop, tintBottom, Shader.TileMode.CLAMP)
            sheenPaint.shader = LinearGradient(0f, t, 0f, t + (bt - t) * 0.4f, 0x1A60A5FA, 0x0060A5FA, Shader.TileMode.CLAMP)
            inset.set(b.left + density / 2, b.top + density / 2, b.right - density / 2, b.bottom - density / 2)
        }

        override fun draw(c: Canvas) {
            c.save(); c.clipPath(path)
            c.drawBitmap(bmp, src, bounds, bmpPaint)
            c.drawPath(path, tintPaint)
            c.drawPath(path, sheenPaint)
            c.restore()
            c.drawRoundRect(inset, radius, radius, strokePaint)
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(cf: ColorFilter?) {}
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}
