package com.gunjoron.patheyo.alarm

// v48: আজান পপআপের (ফুল-স্ক্রীন + নোটিফিকেশন) লোগো — সব জায়গায় একই গোল ভিত্তির ভেতরে।
// লোগোর স্বচ্ছ-ব্যাকগ্রাউন্ড PNG (res/drawable/widget_logo.png — চারপাশের ফাঁকা অংশ কেটে) ব্র্যান্ডের নেভি-ব্লু গোল ভিত্তির
// ওপর বসানো হয়, যাতে পুরো গোলটাই লোগোর নিজের ভিত্তি মনে হয় — লোগোর আলাদা চৌকো/সাদা ব্যাকগ্রাউন্ড থাকে না।
// Bitmap কোডে আঁকা, তাই RemoteViews (clipToOutline কাজ করে না), অ্যান্ড্রয়েড ১২+ এর বড় আইকন ও ফুল-স্ক্রীন — সবখানে হুবহু গোল।

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.gunjoron.patheyo.R

object AzanLogo {

    // গোল ভিত্তির রঙ — অ্যাপের গ্লাস থিমের নেভি-ব্লু (update_colors.xml এর #002657 পরিবারের)
    private const val BASE_TOP_LEFT = 0xFF0A3A80.toInt()
    private const val BASE_BOTTOM_RIGHT = 0xFF002657.toInt()

    // widget_logo.png (৫১২×৫১২) এর ভেতরে লোগোর আসল অংশ (বাকিটা স্বচ্ছ ফাঁকা) + সামান্য ধার
    private val LOGO_SRC = Rect(33, 155, 479, 379)

    /** লোগোর প্রস্থ গোলের ব্যাসের কত অংশ (আয়তাকার লোগো গোলের ভেতরে আরামে ধরে) */
    private const val LOGO_FRACTION = 0.80f

    @Volatile private var cache: Pair<Int, Bitmap>? = null
    @Volatile private var source: Bitmap? = null

    private fun logoSource(ctx: Context): Bitmap? {
        source?.let { if (!it.isRecycled) return it }
        return try {
            val o = BitmapFactory.Options().apply { inScaled = false }
            BitmapFactory.decodeResource(ctx.applicationContext.resources, R.drawable.widget_logo, o)?.also { source = it }
        } catch (_: Throwable) { null }
    }

    /** [sizePx] × [sizePx] মাপের গোল লোগো। ব্যর্থ হলে null (কলার লেআউটের আগের ইমেজেই থাকবে)। */
    fun circle(ctx: Context, sizePx: Int): Bitmap? {
        val size = sizePx.coerceIn(48, 768)
        cache?.let { if (it.first == size && !it.second.isRecycled) return it.second }
        return try {
            val logo = logoSource(ctx) ?: return null
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val s = size.toFloat()

            // ১. গোল ভিত্তি (নেভি-ব্লু গ্রেডিয়েন্ট)
            val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, 0f, s, s, BASE_TOP_LEFT, BASE_BOTTOM_RIGHT, Shader.TileMode.CLAMP)
            }
            c.drawCircle(s / 2f, s / 2f, s / 2f, base)

            // ২. স্বচ্ছ-ব্যাকগ্রাউন্ড লোগো ঠিক মাঝখানে
            val w = s * LOGO_FRACTION
            val h = w * LOGO_SRC.height() / LOGO_SRC.width()
            val dst = RectF((s - w) / 2f, (s - h) / 2f, (s + w) / 2f, (s + h) / 2f)
            val lp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            c.drawBitmap(logo, LOGO_SRC, dst, lp)

            // ৩. খুব হালকা আলোর বর্ডার — গাঢ় ব্যাকগ্রাউন্ডেও গোলের কিনারা স্পষ্ট দেখায়
            val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = (s * 0.014f).coerceAtLeast(1.5f)
                color = 0x40FFFFFF
            }
            c.drawCircle(s / 2f, s / 2f, s / 2f - ring.strokeWidth / 2f, ring)

            cache = size to out
            out
        } catch (_: Throwable) { null }
    }
}
