package com.gunjoron.patheyo.notification

import java.util.Calendar

// ⚠️ এই ফাইলের হার্ডকোড করা তালিকাটি এখন শুধু "ফলব্যাক" — অ্যাপ সাধারণত
// assets/notifications_config.json থেকেই নোটিফিকেশন লোড করে (দেখুন
// NotificationConfigLoader.kt)। JSON ফাইল পড়তে কোনো সমস্যা হলেই কেবল এই তালিকা
// ব্যবহৃত হবে, যাতে অ্যাপ কখনো নোটিফিকেশনবিহীন অবস্থায় না পড়ে।
// IslamicNotification ডেটা ক্লাসটি এখন NotificationConfigLoader.kt-তে সংজ্ঞায়িত (link ও image ফিল্ডসহ)।

object NotificationDataset {
    val items = listOf(

        // ===================== সাপ্তাহিক (বার ভিত্তিক) =====================
        IslamicNotification(
            id = "weekly_jumma_kahf",
            type = "weekly",
            daysOfWeek = listOf(Calendar.FRIDAY),
            timeRef = "fixed", fixedHour = 11, fixedMinute = 0,
            title = "জুমু'আ মোবারক",
            message = "আজ জুমু'আর দিন। রাসূল সাঃ বলেছেন, যে ব্যক্তি জুমু'আর দিন সূরা কাহফ পাঠ করবে, তার জন্য দুই জুমু'আর মধ্যবর্তী সময় আলোকিত হয়ে থাকবে। (হাকিম, বায়হাকি)"
        ),
        IslamicNotification(
            // ট্রিগার রবি/বুধ সন্ধ্যায়, কারণ পরদিনই (সোম/বৃহস্পতি) রোজার প্রস্তুতি হিসেবে সন্ধ্যায় রিমাইন্ডার পাঠানো হয়
            id = "weekly_sunnah_fasting_mon_thu",
            type = "weekly",
            daysOfWeek = listOf(Calendar.SUNDAY, Calendar.WEDNESDAY),
            timeRef = "maghrib",
            title = "সোম/বৃহস্পতিবারের রোজা",
            message = "রাসূল সাঃ সোম ও বৃহস্পতিবার রোজা রাখতেন এবং বলতেন, এই দুই দিন বান্দাদের আমলনামা আল্লাহর কাছে পেশ করা হয়। (তিরমিজি, নাসাঈ)"
        ),
        IslamicNotification(
            id = "weekly_friday_durood",
            type = "weekly",
            daysOfWeek = listOf(Calendar.FRIDAY),
            timeRef = "fixed", fixedHour = 9, fixedMinute = 0,
            title = "শুক্রবারে বেশি দরুদ পড়ুন",
            message = "রাসূল সাঃ বলেছেন, জুমু'আর দিন ও রাতে আমার প্রতি বেশি বেশি দরুদ পাঠ করো। (বায়হাকি)"
        ),
        IslamicNotification(
            id = "weekly_saturday_solo_fasting_caution",
            type = "weekly",
            daysOfWeek = listOf(Calendar.SATURDAY),
            timeRef = "fajr",
            title = "শনিবার একা রোজা রাখার সতর্কতা",
            message = "রাসূল সাঃ শুধু শনিবারকে নির্দিষ্ট করে নফল রোজা রাখতে নিষেধ করেছেন, ফরজ রোজা ব্যতীত। (তিরমিজি, আবু দাউদ)"
        ),
        IslamicNotification(
            id = "weekly_friday_solo_fasting_caution",
            type = "weekly",
            daysOfWeek = listOf(Calendar.FRIDAY),
            timeRef = "fajr",
            title = "জুমু'আর দিন একা রোজা না রাখার বিধান",
            message = "রাসূল সাঃ বলেছেন, তোমরা জুমু'আর দিনকে অন্য দিন থেকে আলাদা করে রোজার জন্য নির্দিষ্ট কোরো না, তবে আগে-পরে একদিন রোজা রাখলে ভিন্ন কথা। (বুখারি, মুসলিম)"
        ),

        // ===================== দৈনিক =====================
        IslamicNotification(
            id = "daily_morning_zikr",
            type = "daily",
            timeRef = "fajr",
            title = "সকালের জিকির",
            message = "আল্লাহ বলেন, তোমরা সকাল-সন্ধ্যায় আল্লাহকে অধিক স্মরণ করো এবং তাঁর পবিত্রতা ঘোষণা করো। (সূরা আল-আহযাব ৩৩:৪১-৪২)"
        ),
        IslamicNotification(
            id = "daily_evening_zikr",
            type = "daily",
            timeRef = "maghrib",
            title = "সন্ধ্যার জিকির",
            message = "আল্লাহ বলেন, তোমরা সকাল-সন্ধ্যায় আল্লাহকে অধিক স্মরণ করো এবং তাঁর পবিত্রতা ঘোষণা করো। (সূরা আল-আহযাব ৩৩:৪১-৪২)"
        ),

        // ===================== মাসিক (আইয়ামে বিয — ৯ দিন, ৩ সেট) =====================
        IslamicNotification(
            id = "monthly_ayyam_biadh_start",
            type = "monthly_hijri",
            days = listOf(1, 2, 3),
            timeRef = "fajr",
            title = "আইয়ামে বিয রোজা (মাসের শুরু)",
            message = "রাসূল সাঃ প্রতি মাসে তিন দিন রোজা রাখতেন এবং বলেছেন, এটি সারা জীবন রোজা রাখার সমতুল্য। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "monthly_ayyam_biadh_mid",
            type = "monthly_hijri",
            days = listOf(13, 14, 15),
            timeRef = "fajr",
            title = "আইয়ামে বিয রোজা",
            message = "রাসূল সাঃ প্রতি মাসে তিন দিন রোজা রাখতেন এবং বলেছেন, এটি সারা জীবন রোজা রাখার সমতুল্য। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "monthly_ayyam_biadh_end",
            type = "monthly_hijri_last3",
            timeRef = "fajr",
            title = "আইয়ামে বিয রোজা (মাসের শেষ)",
            message = "রাসূল সাঃ প্রতি মাসে তিন দিন রোজা রাখতেন এবং বলেছেন, এটি সারা জীবন রোজা রাখার সমতুল্য। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "monthly_new_hijri_month",
            type = "monthly_hijri",
            days = listOf(1),
            timeRef = "fajr",
            title = "নতুন হিজরি মাস শুরু",
            message = "রাসূল সাঃ নতুন চাঁদ দেখে দোয়া পড়তেন, হে আল্লাহ, এই চাঁদ আমাদের ওপর নিরাপত্তা ও ঈমান সহকারে উদিত করো। (তিরমিজি)"
        ),

        // ===================== মহররম =====================
        IslamicNotification(
            id = "annual_hijri_new_year",
            type = "annual_hijri", month = 1, days = listOf(1),
            timeRef = "fajr",
            title = "হিজরি নববর্ষ মোবারক",
            message = "নবীজির সাঃ মক্কা থেকে মদিনায় হিজরতের স্মরণে হিজরি বর্ষ গণনা শুরু হয়েছিল। নতুন বছরে তাওবা ও নেক আমলের সংকল্প করুন।"
        ),
        IslamicNotification(
            id = "annual_muharram_haram_month",
            type = "annual_hijri", month = 1, days = listOf(1),
            timeRef = "maghrib",
            title = "হারাম মাস — মহররম",
            message = "আল্লাহ বলেন, আসমান-জমিন সৃষ্টির দিন থেকে আল্লাহর কাছে মাসের সংখ্যা বারোটি, তার মধ্যে চারটি সম্মানিত। এই মাসগুলোতে নিজের ওপর জুলুম কোরো না। (সূরা আত-তাওবা ৯:৩৬)"
        ),
        IslamicNotification(
            id = "annual_ashura_fasting_prep",
            type = "annual_hijri", month = 1, days = listOf(8),
            timeRef = "maghrib",
            title = "আশুরার রোজার প্রস্তুতি",
            message = "রাসূল সাঃ বলেছেন, আগামী বছর বেঁচে থাকলে ৯ তারিখেও রোজা রাখব, যাতে (রোজার ক্ষেত্রে) ইহুদিদের থেকে ভিন্নতা থাকে। (সহীহ মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_tasua_fasting",
            type = "annual_hijri", month = 1, days = listOf(9),
            timeRef = "fajr",
            title = "আজ তাসূয়ার রোজা",
            message = "রাসূল সাঃ আশুরার সাথে ৯ মহররমও রোজা রাখার ইচ্ছা প্রকাশ করেছিলেন, যাতে ইহুদিদের রোজা থেকে ভিন্নতা থাকে। (সহীহ মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_ashura_fasting",
            type = "annual_hijri", month = 1, days = listOf(10),
            timeRef = "fajr",
            title = "আজ আশুরার রোজা",
            message = "রাসূল সাঃ বলেছেন, আশুরার দিনের রোজা বিগত এক বছরের গুনাহ মোচন করে দেয়। (সহীহ মুসলিম)"
        ),

        // ===================== রবিউল আউয়াল =====================
        IslamicNotification(
            // মতভেদপূর্ণ তারিখ — ২, ৮ ও ১২ রবিউল আউয়াল তিন দিনই আসবে, বিষয়বস্তুতে ৮ তারিখকে প্রাধান্য দেওয়া হয়েছে
            id = "annual_rabiul_awwal_remembrance",
            type = "annual_hijri", month = 3, days = listOf(2, 8, 12),
            timeRef = "maghrib",
            title = "রবিউল আউয়াল — নবীজির স্মরণ",
            message = "ইতিহাসবিদদের মধ্যে নবীজি সাঃ-এর ওফাতের তারিখ নিয়ে ২, ৮ ও ১২ রবিউল আউয়াল — এই তিনটি মত প্রসিদ্ধ, যার মধ্যে অনেক গবেষক ৮ তারিখকে অগ্রাধিকার দিয়েছেন। আজ বেশি বেশি দরুদ পাঠ করুন। (ফাতহুল বারী; সিরাতুল মুস্তফা)"
        ),

        // ===================== রজব =====================
        IslamicNotification(
            id = "annual_rajab_start",
            type = "annual_hijri", month = 7, days = listOf(1),
            timeRef = "fajr",
            title = "রজব মাস শুরু (হারাম মাস)",
            message = "আল্লাহ বলেন, চারটি সম্মানিত মাসের একটি রজব। এসব মাসে নিজের ওপর জুলুম কোরো না। (সূরা আত-তাওবা ৯:৩৬)"
        ),
        IslamicNotification(
            id = "annual_shabe_meraj",
            type = "annual_hijri", month = 7, days = listOf(26),
            timeRef = "maghrib",
            title = "শবে মিরাজ",
            message = "এই রাতে রাসূল সাঃ-কে মক্কা থেকে জেরুজালেম এবং পরে ঊর্ধ্বাকাশে ভ্রমণ করানো হয়, যেখানে পাঁচ ওয়াক্ত নামাজ ফরজ করা হয়। (সূরা আল-ইসরা ১৭:১; বুখারি, মুসলিম)"
        ),

        // ===================== শাবান =====================
        IslamicNotification(
            id = "annual_shaban_start",
            type = "annual_hijri", month = 8, days = listOf(1),
            timeRef = "fajr",
            title = "শাবান মাস শুরু, রমজানের প্রস্তুতি",
            message = "আয়েশা রাঃ বলেন, রাসূল সাঃ শাবান মাসে সবচেয়ে বেশি নফল রোজা রাখতেন। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_shabe_barat",
            type = "annual_hijri", month = 8, days = listOf(14),
            timeRef = "maghrib",
            title = "শবে বরাত",
            message = "রাসূল সাঃ বলেছেন, আল্লাহ শাবানের মধ্যরাতে বান্দাদের প্রতি রহমতের দৃষ্টি দেন এবং ক্ষমাপ্রার্থীদের ক্ষমা করে দেন, শিরককারী ও বিদ্বেষী ব্যতীত। (ইবনে মাজাহ)"
        ),
        IslamicNotification(
            id = "annual_shaban_15_fasting",
            type = "annual_hijri", month = 8, days = listOf(15),
            timeRef = "fajr",
            title = "শবে বরাতের পরদিন নফল রোজা",
            message = "শাবান মাসে নবীজির সাঃ অধিক রোজা রাখার সুন্নত অনুসরণে আজ নফল রোজা রাখা যেতে পারে। (বুখারি, মুসলিম — শাবানের রোজা সংক্রান্ত)"
        ),
        IslamicNotification(
            id = "annual_ramadan_moon_watch",
            type = "annual_hijri", month = 8, days = listOf(29),
            timeRef = "maghrib",
            title = "রমজানের চাঁদ অনুসন্ধান",
            message = "রাসূল সাঃ বলেছেন, চাঁদ দেখে রোজা রাখো, চাঁদ দেখে ঈদ করো। (বুখারি, মুসলিম)"
        ),

        // ===================== রমজান =====================
        IslamicNotification(
            id = "annual_ramadan_mubarak",
            type = "annual_hijri", month = 9, days = listOf(1),
            timeRef = "fajr",
            title = "রমজান মোবারক",
            message = "রাসূল সাঃ বলেছেন, যে ব্যক্তি ঈমান ও সওয়াবের আশায় রমজানের রোজা রাখবে, তার আগের সব গুনাহ মাফ করে দেওয়া হবে। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_itikaf_start",
            type = "annual_hijri", month = 9, days = listOf(20),
            timeRef = "maghrib",
            title = "ইতিকাফ শুরু",
            message = "আয়েশা রাঃ বলেন, রাসূল সাঃ রমজানের শেষ দশকে ইতিকাফ করতেন, তাঁর ওফাত পর্যন্ত এই আমল অব্যাহত ছিল। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_laylatul_qadr",
            type = "annual_hijri", month = 9, days = listOf(21, 23, 25, 27, 29),
            timeRef = "maghrib",
            title = "লাইলাতুল কদরের সম্ভাব্য রাত",
            message = "রাসূল সাঃ বলেছেন, তোমরা লাইলাতুল কদর রমজানের শেষ দশকের বেজোড় রাতগুলোতে তালাশ করো। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_sadaqatul_fitr",
            type = "annual_hijri", month = 9, days = listOf(25, 26, 27, 28, 29),
            timeRef = "fajr",
            title = "সদকাতুল ফিতর আদায় করুন",
            message = "ইবনে ওমর রাঃ বলেন, রাসূল সাঃ ঈদের নামাজের আগে সদকাতুল ফিতর আদায়ের নির্দেশ দিয়েছেন। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_eid_fitr_moon_watch",
            type = "annual_hijri", month = 9, days = listOf(29),
            timeRef = "maghrib",
            title = "ঈদের চাঁদ অনুসন্ধান",
            message = "রাসূল সাঃ বলেছেন, চাঁদ দেখে রোজা রাখো ও চাঁদ দেখে ঈদ করো, আকাশ মেঘাচ্ছন্ন থাকলে ৩০ দিন পূর্ণ করো। (বুখারি, মুসলিম)"
        ),

        // ===================== শাওয়াল =====================
        IslamicNotification(
            id = "annual_eid_ul_fitr",
            type = "annual_hijri", month = 10, days = listOf(1),
            timeRef = "fajr",
            title = "ঈদ মোবারক",
            message = "আজ ঈদুল ফিতর। রাসূল সাঃ বলেছেন, রোজাদারের জন্য দুটি আনন্দ — একটি ইফতারের সময়, অন্যটি তার রবের সাক্ষাতের সময়। (বুখারি, মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_eid_fitr_greetings",
            type = "annual_hijri", month = 10, days = listOf(2, 3),
            timeRef = "fajr",
            title = "ঈদের শুভেচ্ছা",
            message = "ঈদ মোবারক। আত্মীয়-স্বজনের সাথে সম্পর্ক দৃঢ় করার এই দিনগুলোতে সদাচরণ বজায় রাখুন।"
        ),
        IslamicNotification(
            // মাসজুড়ে যেকোনো ৬ দিন রাখা যায় বলে দৈনিক স্প্যাম এড়াতে মাসে একবারই রিমাইন্ডার
            id = "annual_shawwal_six_fasts",
            type = "annual_hijri", month = 10, days = listOf(3),
            timeRef = "fajr",
            title = "শাওয়ালের ৬ নফল রোজা",
            message = "রাসূল সাঃ বলেছেন, যে রমজানের রোজা রেখে শাওয়ালের ছয়টি রোজা রাখল, সে যেন সারা বছর রোজা রাখল। (সহীহ মুসলিম)"
        ),

        // ===================== জিলকদ =====================
        IslamicNotification(
            id = "annual_dhul_qadah_start",
            type = "annual_hijri", month = 11, days = listOf(1),
            timeRef = "fajr",
            title = "জিলকদ মাস শুরু (হারাম মাস)",
            message = "চারটি সম্মানিত মাসের একটি জিলকদ। এই মাস থেকেই হজ্জ্বের প্রস্তুতি শুরু হয়। (সূরা আত-তাওবা ৯:৩৬)"
        ),

        // ===================== জিলহজ =====================
        IslamicNotification(
            id = "annual_dhul_hijjah_first_ten",
            type = "annual_hijri", month = 12, days = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9),
            timeRef = "fajr",
            title = "জিলহজের প্রথম দশক",
            message = "রাসূল সাঃ বলেছেন, এই দশ দিনের নেক আমল আল্লাহর কাছে অন্য কোনো দিনের আমল থেকে অধিক প্রিয়, জান-মাল দিয়ে জিহাদকারী ব্যতীত। (সহীহ বুখারি)"
        ),
        IslamicNotification(
            id = "annual_dhul_hijjah_hair_nail_caution",
            type = "annual_hijri", month = 12, days = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9),
            timeRef = "maghrib",
            title = "কুরবানিদাতার জন্য সতর্কতা",
            message = "রাসূল সাঃ বলেছেন, জিলহজ মাস শুরু হলে এবং কুরবানির ইচ্ছা থাকলে, কুরবানির আগ পর্যন্ত চুল ও নখ না কাটার নির্দেশ দিয়েছেন। (সহীহ মুসলিম)"
        ),
        IslamicNotification(
            // পূর্বে day=9 এ ছিল কিন্তু মেসেজে "আগামীকাল" লেখা ছিল — তাই ৮ তারিখ সন্ধ্যায় (এক দিন আগে) ঠিক করা হলো
            id = "annual_arafah_fasting_prep",
            type = "annual_hijri", month = 12, days = listOf(8),
            timeRef = "maghrib",
            title = "আগামীকাল আরাফাহর রোজা",
            message = "আগামীকাল ৯ই জিলহজ, পবিত্র আরাফাহর দিন। রাসূল সাঃ বলেছেন, এই দিনের রোজা বিগত ও আগামী এক বছরের গুনাহ মোচন করে দেয় (হাজি ব্যতীত)। (সহীহ মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_eid_ul_adha",
            type = "annual_hijri", month = 12, days = listOf(10),
            timeRef = "fajr",
            title = "ঈদুল আজহা মোবারক",
            message = "আজ ঈদুল আজহা, কুরবানির দিন। ইবরাহিম আঃ-এর আত্মত্যাগের স্মরণে আল্লাহর সন্তুষ্টির জন্য কুরবানি করুন। (সূরা আস-সাফফাত ৩৭:১০২-১০৭ অবলম্বনে)"
        ),
        IslamicNotification(
            id = "annual_ayyam_e_tashreq",
            type = "annual_hijri", month = 12, days = listOf(11, 12, 13),
            timeRef = "fajr",
            title = "আইয়ামে তাশরিক",
            message = "রাসূল সাঃ বলেছেন, আইয়ামে তাশরিকের দিনগুলো পানাহার ও আল্লাহর জিকিরের দিন — এই তিন দিন রোজা রাখা নিষিদ্ধ। (সহীহ মুসলিম)"
        ),
        IslamicNotification(
            id = "annual_dhul_hijjah_haram_month",
            type = "annual_hijri", month = 12, days = listOf(1),
            timeRef = "fajr",
            title = "হারাম মাস — জিলহজ",
            message = "চারটি সম্মানিত মাসের শেষটি জিলহজ, হজ্জ্ব ও কুরবানির মাস। (সূরা আত-তাওবা ৯:৩৬)"
        )
    )
}
