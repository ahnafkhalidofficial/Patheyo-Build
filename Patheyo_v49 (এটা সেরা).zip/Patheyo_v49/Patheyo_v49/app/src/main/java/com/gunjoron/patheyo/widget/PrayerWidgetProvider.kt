package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/PrayerWidgetProvider.kt
//
// ✅ v17 (এই রাউন্ড):
//  - থিম: glass | nobg (ট্রান্সপারেন্ট-ডার্ক) | nobg_light (ট্রান্সপারেন্ট-লাইট) | light। nobg_light ব্যাকগ্রাউন্ড
//    ছাড়া, কিন্তু লেখা/আইকন/বৃত্তের রঙ লাইট থিমের কনফিগ থেকে আসে (isLightTheme)।
//  - ডিফল্ট সেটিংস (অ্যাপ না খুলেই উইজেট যোগ করলে): লাইভ ঘড়ি ON + সাহরী/ইফতার ON, আবহাওয়া OFF।
//  - ঘড়ি চালু থাকলে আবহাওয়া ও সাহরী/ইফতার একটা চালু হলে আরেকটা বন্ধ; ঘড়ি বন্ধ থাকলে দুটোই একসাথে চলে।
//  - আইকনের গোল বৃত্ত JSON (icon_circles) থেকে রঙ/অপাসিটিতে আঁকা; ভেতরের আইকন থিম অনুযায়ী ডার্ক/লাইট ফাইল।
//  - সূর্যোদয়/সূর্যাস্ত আলাদা আইকন (টাইটেলের সাথে মিল রেখে)।
//  - তারিখের মাঝের দাগ নিজে আঁকা (WidgetFontRenderer.renderDateLine)।
//  - চারদিকে সমান ফাঁকা + সব ভ্যারিয়েন্টে একই উচ্চতা + ছোট সাইজে রিসাইজে কাটা না পড়ার নিরাপত্তা
//    (updateWidget-এর শেষ অংশ, onAppWidgetOptionsChanged)।
//
// ফিক্স করা সমস্যাগুলো:
//  - #2: jsActiveWaqt কখনো computed waqtState.active কে override করবে না।
//        JS-এর মান শুধু gap-এ (active==null) ব্যবহার হবে।
//  - #3: (v13-এ পরিবর্তিত — নিচে দেখুন FIX #27) forbidden+gap এর ক্ষেত্রে upcoming waqt
//        (যেমন Dhuhr) নির্ধারণ করার লজিকটা এখনও আছে, কিন্তু এখন সেই রো-তে আর হাইলাইট বসে না।
//  - #4: প্রতিটি waqt-এর শেষে exact alarm schedule হবে যাতে negative countdown না দেখায়।

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.FirebaseDataManager
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class PrayerWidgetProvider : AppWidgetProvider() {

    companion object {
        const val PREFS_NAME = "ibadat_widget_prefs"
        const val KEY_TIMINGS = "timings_json"
        const val KEY_SETTINGS = "settings_json"
        const val KEY_TEMP = "cached_temp"

        private const val COLOR_TEXT_DARK = 0xFF1F2937.toInt()
        private const val COLOR_AMBER = 0xFFFBBF24.toInt()
        private const val COLOR_RED = 0xFFE11D48.toInt()
        private const val COLOR_WHITE = 0xFFFFFFFF.toInt()

        fun updateAllWidgets(context: Context) {
            val appContext = context.applicationContext
            val mgr = AppWidgetManager.getInstance(appContext)
            val cn = ComponentName(appContext, PrayerWidgetProvider::class.java)
            val ids = mgr.getAppWidgetIds(cn)

            if (ids.isNotEmpty()) {
                // ✅ ACTION_APPWIDGET_UPDATE ব্রডকাস্ট পাঠানো হচ্ছে যাতে সিস্টেম সাথে সাথে উইজেট রিফ্রেশ করে
                val intent = Intent(appContext, PrayerWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                appContext.sendBroadcast(intent)
            }
        }

        // সরাসরি উইজেট আপডেট করার জন্য অপ্টিমাইজড মেথড
        // ✅ FIX #NEW (v5): এখানেও প্রতিটি widget id আলাদা try-catch(Throwable) দিয়ে সুরক্ষিত —
        // onUpdate()-এর মতোই, যাতে এই পথ (NativePrayerTimesFetcher, WidgetJSBridge.refreshWidgetNow
        // ইত্যাদি থেকে কল হয়) দিয়েও কখনো ক্র্যাশ propagate না করে।
        fun updateWidgetDirectly(context: Context) {
            val appContext = context.applicationContext
            val mgr = AppWidgetManager.getInstance(appContext)
            val cn = ComponentName(appContext, PrayerWidgetProvider::class.java)
            val ids = mgr.getAppWidgetIds(cn)

            if (ids.isNotEmpty()) {
                ids.forEach { id ->
                    try {
                        updateWidget(appContext, mgr, id)
                    } catch (t: Throwable) { /* একটা instance ব্যর্থ হলেও বাকিগুলো চলবে */ }
                }
            }
        }

        // ✅ v16 ("Problem loading widget" ফিক্স): RemoteViews.setFloat() দিয়ে View-এর যেসব মেথড
        // ডাকা হয় সেগুলোর @RemotableViewMethod অনুমোদন Android ১২ (API 31)-এর আগে নেই। পুরনো
        // ফোনে (Android ৭–১১) এগুলো পাঠালে লঞ্চার উইজেট আঁকার সময় ActionException ছুঁড়ে →
        // "Problem loading widget" দেখায় (try/catch এখানে ধরতে পারে না, কারণ ব্যর্থতাটা লঞ্চারের
        // প্রসেসে ঘটে)। তাই এই মেথডগুলো শুধু API 31+ এ পাঠানো হয়; পুরনো ফোনে একই লুক আসে
        // res/layout/widget_prayer_times.xml-এ বসানো মান থেকে। setLetterSpacing সব ভার্সনেই অনুমোদিত।
        private val NEEDS_API_31 = setOf(
            "setTranslationX", "setTranslationY", "setScaleX", "setScaleY", "setAlpha", "setElevation"
        )
        private const val ROOT_PAD_DP = 12f      // মূল কার্ডের বাম/উপর/ডান padding (XML-এর সাথে মেলানো)
        private const val CELL_PAD_DP = 5f       // প্রতিটা নামাজের ঘরের ভেতরের padding (XML-এর সাথে মেলানো)
        private const val TIME_MARGIN_TOP_DP = 2f // নাম ও সময়ের মাঝের margin (XML-এর সাথে মেলানো)
        // ✅ হাইলাইট বক্স কতগুণ বড় হবে (১.০ = আগের সাইজ)। শুধু এই একটা মান বদলালেই বক্স ছোট-বড় হবে
        private const val HL_SCALE = 1.25f
        // ঘড়ির scaleY (১.৩) মেইন সময়ের বেসলাইন দৃশ্যত যতটা নামায়, সেকেন্ড/AM-PM ততটাই নামানো (dp) — XML-এর translationY-এর সমান
        private const val CLOCK_BASELINE_FIX_DP = 2f

        // ✅ v20: রেসপন্সিভ স্কেলিং — লঞ্চার উইজেটকে যত dp জায়গা দিচ্ছে (প্রস্থ ও উচ্চতা) তার সাথে লেখার
        // সাইজ সমানুপাতে বাড়ে-কমে। REF_* = যে মাপে ডিজাইনের স্বাভাবিক (১.০×) সাইজ আসে। ছোট স্ক্রিনে
        // সর্বনিম্ন UI_SCALE_MIN, বড় স্ক্রিনে সর্বোচ্চ UI_SCALE_MAX — তাই কোথাও অতি-বড় বা অতি-ছোট হয় না।
        private const val REF_WIDTH_DP = 260f
        private const val REF_HEIGHT_DP = 180f
        private const val UI_SCALE_MIN = 0.8f
        // ✅ v21: উচ্চতায় না ধরলে লেখা এর নিচে নামবে না (তার আগে প্যাডিং কমে, শেষে কাউন্টডাউন লুকায়)
        private const val UI_SCALE_FLOOR_FIT = 0.72f
        private const val UI_SCALE_MAX = 1.2f
        // হাইলাইট বক্স ও পাশের ঘরের মাঝে অন্তত এতটুকু ফাঁকা থাকবে (ঢুকে পড়া রোধ)
        private const val HL_WIDTH_MARGIN_DP = 3f

        // প্রতিটা থ্রেডের নিজস্ব স্কেল (একসাথে একাধিক উইজেট/থ্রেড আপডেট হলেও মিশে যায় না)
        private val uiScaleHolder = object : ThreadLocal<Float>() {
            override fun initialValue(): Float = 1f
        }
        private var uiScale: Float
            get() = uiScaleHolder.get() ?: 1f
            set(v) { uiScaleHolder.set(v) }

        // ✅ v22: মোবাইলের স্ক্রিন-ক্লাস (smallestScreenWidthDp — ঘোরালেও বদলায় না) অনুযায়ী লেখা-আইকনের
        // সর্বোচ্চ স্কেল। বাজারের ফোনের প্রস্থ: ৩২০–৩৫৯dp (ছোট/পুরনো), ৩৬০–৩৯৯dp (সবচেয়ে প্রচলিত: ৩৬০/৩৮৪/৩৯২),
        // ৪০০–৫৯৯dp (বড়: ৪১১/৪১২/৪৩০/৪৪৮), ≥৬০০dp (ট্যাবলেট/ফোল্ডেবল — Android window size class "medium+")।
        // এর বেশি বড় করলে বড় স্ক্রিনে লেখা অস্বাভাবিক বড় দেখাবে, তাই সীমা; কম জায়গা হলে নিচে নামে (fit)।
        private fun classScaleCap(smallestWidthDp: Int): Float = when {
            smallestWidthDp < 360 -> 1.00f
            smallestWidthDp < 400 -> 1.08f
            smallestWidthDp < 600 -> 1.16f
            else -> 1.28f
        }

        // ✅ v20: কাস্টম ব্যাকগ্রাউন্ডের উপর লেখা/আইকন কোন টোনের হবে (অটো মোডে) — রঙটা হালকা হলে গাঢ় লেখা
        private fun isLightColor(color: Int): Boolean {
            val r = android.graphics.Color.red(color)
            val g = android.graphics.Color.green(color)
            val b = android.graphics.Color.blue(color)
            return (0.299f * r + 0.587f * g + 0.114f * b) / 255f > 0.6f
        }

        @Volatile private var activeTheme: String = "glass"
        // প্রতিটা বিটম্যাপ-ImageView-এর সর্বশেষ আঁকা উচ্চতা (px) — ১:১ হাইলাইট বক্সের মাপ বের করতে লাগে
        private val bmpHeightPx = ConcurrentHashMap<Int, Int>()
        // ✅ v22: আঁকা বিটম্যাপের প্রস্থ (px) — সাইজ-মডেল "কনটেন্ট কত চওড়া লাগবে" হিসাব করতে
        private val bmpWidthPx = ConcurrentHashMap<Int, Int>()

        private fun safeSetFloat(views: RemoteViews, viewId: Int, methodName: String, value: Float) {
            if (Build.VERSION.SDK_INT < 31 && methodName in NEEDS_API_31) return
            try { views.setFloat(viewId, methodName, value) } catch (_: Throwable) {}
        }
        private fun safeSetInt(views: RemoteViews, viewId: Int, methodName: String, value: Int) {
            try { views.setInt(viewId, methodName, value) } catch (_: Throwable) {}
        }
        private fun safeSetTextViewTextSize(views: RemoteViews, viewId: Int, units: Int, size: Float) {
            try { views.setTextViewTextSize(viewId, units, size) } catch (_: Throwable) {}
        }
        private fun safeSetTextColor(views: RemoteViews, viewId: Int, color: Int) {
            try { views.setTextColor(viewId, color) } catch (_: Throwable) {}
        }
        private fun safeSetViewPadding(views: RemoteViews, viewId: Int, left: Int, top: Int, right: Int, bottom: Int) {
            try { views.setViewPadding(viewId, left, top, right, bottom) } catch (_: Throwable) {}
        }

        // ✅ v14: JSON-এ দেওয়া "#RRGGBB"/"#AARRGGBB" রঙ নিরাপদে পার্স করে — ভুল/অবৈধ ফরম্যাট
        // হলে (বা null হলে) fallback রঙ ব্যবহার হয়, widget কখনো ক্র্যাশ করে না।
        private fun resolveColor(hex: String?, fallback: Int): Int {
            if (hex.isNullOrBlank()) return fallback
            return try { android.graphics.Color.parseColor(hex) } catch (_: Exception) { fallback }
        }

        // ✅ FIX #10: বাংলা কনটেন্ট + রঙ একসাথে সেট করার শর্টকাট — Kalpurush ফন্টে বিটম্যাপ এঁকে
        // সংশ্লিষ্ট ImageView-তে বসিয়ে দেয়।
        private fun setBn(context: Context, views: RemoteViews, viewId: Int, text: String, sizeSp: Float, colorInt: Int, bold: Boolean = false) {
            try {
                val bmp = WidgetFontRenderer.render(context, text, sizeSp * uiScale, colorInt, bold)
                bmpHeightPx[viewId] = bmp.height; bmpWidthPx[viewId] = bmp.width
                views.setImageViewBitmap(viewId, bmp)
            } catch (_: Throwable) {}
        }

        // ✅ v16: থিম অনুযায়ী রঙ বাছাই (color = ডার্ক/গ্লাস/নো-ব্যাকগ্রাউন্ড, color_light_theme = লাইট থিম)
        private fun styleColor(style: WidgetStyleConfig.TextStyle, fallback: Int): Int {
            val hex = if (activeTheme == "light") (style.colorLightHex ?: style.colorHex) else style.colorHex
            return resolveColor(hex, fallback)
        }

        // কাউন্টডাউনের রঙ: নিষিদ্ধ সময় → color_forbidden, লাইট থিম → color_light_theme, নাহলে color
        private fun countdownStyleColor(style: WidgetStyleConfig.TextStyle, forbidden: Boolean, fallback: Int): Int {
            val hex = when {
                forbidden -> style.colorForbiddenHex
                activeTheme == "light" -> style.colorLightHex ?: style.colorHex
                else -> style.colorHex
            }
            return resolveColor(hex, fallback)
        }

        private fun plainColor(style: WidgetStyleConfig.TextStyle) =
            style.copy(colorHex = null, colorLightHex = null, colorForbiddenHex = null)

        // ✅ v14: টেক্সট এলিমেন্টের config (visible/size/color/bold) বিদ্যমান ডিফল্টের সাথে মিলিয়ে
        // চূড়ান্তভাবে রেন্ডার করার শর্টকাট — visible:false হলে ImageView পুরোপুরি GONE করে দেয়,
        // নাহলে config-এর sizeSp/colorHex/bold (থাকলে) দিয়ে, না থাকলে দেওয়া ডিফল্ট দিয়ে আঁকে।
        private fun setBnStyled(
            context: Context, views: RemoteViews, viewId: Int, text: String,
            style: WidgetStyleConfig.TextStyle, defaultSizeSp: Float, defaultColor: Int, defaultBold: Boolean = false
        ) {
            if (!style.visible) {
                views.setViewVisibility(viewId, View.GONE)
                bmpHeightPx[viewId] = 0; bmpWidthPx[viewId] = 0
                return
            }
            views.setViewVisibility(viewId, View.VISIBLE)
            val size = style.sizeSp ?: defaultSizeSp
            val color = styleColor(style, defaultColor)
            val bold = style.bold ?: defaultBold
            // ✅ v15: এই একটা লেখার জন্যই আলাদা অক্ষর-ফাঁকা চাইলে (letter_spacing_em), সাময়িকভাবে
            // গ্লোবাল মান বদলে রেন্ডার করে সাথে সাথে আগেরটা ফিরিয়ে দেওয়া হয় (একই থ্রেডে, নিরাপদ)।
            val prevSpacing = WidgetFontRenderer.letterSpacingEm
            style.letterSpacingEm?.let { WidgetFontRenderer.letterSpacingEm = it }
            setBn(context, views, viewId, text, size, color, bold)
            WidgetFontRenderer.letterSpacingEm = prevSpacing
            // শুধু এই লেখাটাকে আড়াআড়ি/লম্বালম্বি টানা-লম্বা/চেপ্টা করা (বক্সের বাকি সবকিছু অক্ষত)
            if (style.scaleX != 1f) safeSetFloat(views, viewId, "setScaleX", style.scaleX)
            if (style.scaleY != 1f) safeSetFloat(views, viewId, "setScaleY", style.scaleY)
        }

        // ✅ FIX #NEW (v6, প্রয়োজনীয়তা #৩ ও #৪ একসাথে): হিজরি তারিখ লাইন সেট করার শর্টকাট —
        // প্রথমে যেকোনো ইংরেজি সংখ্যাকে বাংলায় রূপান্তর করে, তারপর প্রথম স্পেস দিয়ে "দিন" ও
        // "মাস+সাল" আলাদা করে WidgetFontRenderer.renderHijriDate() দিয়ে একই লাইনে মিশ্র-সাইজে
        // (দিন বড়-বোল্ড, মাস+সাল ছোট) আঁকে। স্পেস না পাওয়া গেলে (অপ্রত্যাশিত ফরম্যাট) পুরো
        // স্ট্রিংটাই বড় সাইজে দেখানো হয় — নিরাপদ ফলব্যাক, কখনো ফাঁকা দেখাবে না।
        // ✅ v14: দিনের সংখ্যা ও মাস+সাল এখন আলাদা আলাদা TextStyle (visible/size/color/bold)।
        // একটা বিটম্যাপে দুটো অংশ থাকে, তাই একটা লুকালে শুধু সেই অংশের লেখা বাদ পড়ে; দুটোই
        // লুকালে পুরো ImageView GONE হয়।
        private fun setHijriDateBn(
            context: Context, views: RemoteViews, viewId: Int, hijriRaw: String, defaultColor: Int,
            dayStyle: WidgetStyleConfig.TextStyle, monthStyle: WidgetStyleConfig.TextStyle,
            defaultBigSizeSp: Float = 24f, defaultSmallSizeSp: Float = 16f
        ) {
            if (!dayStyle.visible && !monthStyle.visible) {
                views.setViewVisibility(viewId, View.GONE)
                bmpHeightPx[viewId] = 0; bmpWidthPx[viewId] = 0
                return
            }
            views.setViewVisibility(viewId, View.VISIBLE)
            val bn = FirebaseDataManager.convertEnglishToBengali(hijriRaw)
            val spaceIdx = bn.indexOf(' ')
            val dayPart = if (spaceIdx > 0) bn.substring(0, spaceIdx) else bn
            val restPart = if (spaceIdx > 0) bn.substring(spaceIdx + 1) else ""
            val bmp = WidgetFontRenderer.renderHijriDate(
                context,
                if (dayStyle.visible) dayPart else "",
                if (monthStyle.visible) restPart else "",
                (dayStyle.sizeSp ?: defaultBigSizeSp) * uiScale,
                (monthStyle.sizeSp ?: defaultSmallSizeSp) * uiScale,
                styleColor(dayStyle, defaultColor),
                styleColor(monthStyle, defaultColor),
                dayStyle.bold ?: true,
                monthStyle.bold ?: false
            )
            bmpHeightPx[viewId] = bmp.height; bmpWidthPx[viewId] = bmp.width
            views.setImageViewBitmap(viewId, bmp)
        }

        // ✅ v17: লাইট-ধরনের থিম কি না (লাইট ও ট্রান্সপারেন্ট-লাইট — দুটোতেই লেখা/আইকন লাইট কনফিগ থেকে আসে)
        private fun isLightTheme(theme: String) = theme == "light" || theme == "nobg_light"

        private fun withAlpha(color: Int, alpha: Float): Int {
            val a = (alpha.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
            return (color and 0x00FFFFFF) or (a shl 24)
        }

        // ✅ v17: আইকনের গোল ব্যাকগ্রাউন্ড (ভরাট + কিনারা) — JSON-এর রঙ/অপাসিটি অনুযায়ী এঁকে বিটম্যাপ
        private fun buildCircleBitmap(sizePx: Int, color: Int, fillAlpha: Float, borderAlpha: Float, strokePx: Int): Bitmap? {
            return try {
                val s = sizePx.coerceAtLeast(8)
                val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL; this.color = withAlpha(color, fillAlpha)
                }
                val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = strokePx.toFloat().coerceAtLeast(1f)
                    this.color = withAlpha(color, borderAlpha)
                }
                val half = border.strokeWidth / 2f
                val r = s / 2f
                c.drawCircle(r, r, r - half, fill)
                c.drawCircle(r, r, r - half, border)
                bmp
            } catch (_: Throwable) { null }
        }

        // ✅ v17: "ইংরেজি তারিখ | বাংলা তারিখ" লাইন (মাঝের দাগ নিজে আঁকা) — setBnStyled()-এর মতোই
        // visible/size/color/bold/letter_spacing মানে, শুধু দুই অংশ আলাদা করে পাঠাতে হয়।
        private fun setDateLineBn(
            context: Context, views: RemoteViews, viewId: Int, left: String, right: String,
            style: WidgetStyleConfig.TextStyle, sep: WidgetStyleConfig.DateSeparator,
            defaultSizeSp: Float, defaultColor: Int
        ) {
            if (!style.visible) {
                views.setViewVisibility(viewId, View.GONE)
                bmpHeightPx[viewId] = 0; bmpWidthPx[viewId] = 0
                return
            }
            views.setViewVisibility(viewId, View.VISIBLE)
            val size = (style.sizeSp ?: defaultSizeSp) * uiScale
            val color = styleColor(style, defaultColor)
            val bold = style.bold ?: false
            val sepHex = if (activeTheme == "light") sep.colorLightHex else sep.colorHex
            val sepColor = resolveColor(sepHex, withAlpha(color, 0.65f))
            val prevSpacing = WidgetFontRenderer.letterSpacingEm
            style.letterSpacingEm?.let { WidgetFontRenderer.letterSpacingEm = it }
            try {
                val bmp = WidgetFontRenderer.renderDateLine(
                    context, left, right, size, color, bold,
                    sep.visible, sep.heightEm, sep.widthDp, sep.gapEm, sepColor
                )
                bmpHeightPx[viewId] = bmp.height; bmpWidthPx[viewId] = bmp.width
                views.setImageViewBitmap(viewId, bmp)
            } catch (_: Throwable) {
            } finally {
                WidgetFontRenderer.letterSpacingEm = prevSpacing
            }
            if (style.scaleX != 1f) safeSetFloat(views, viewId, "setScaleX", style.scaleX)
            if (style.scaleY != 1f) safeSetFloat(views, viewId, "setScaleY", style.scaleY)
        }

        // ✅ v21: দুই-ধাপের আপডেট। ধাপ ১ স্বাভাবিক স্কেলে আঁকে; আঁকা বিটম্যাপের আসল উচ্চতা মেপে যদি দেখা যায়
        // লঞ্চারের দেওয়া জায়গায় কনটেন্ট ধরবে না (প্যাডিং কমিয়েও), তাহলে আপডেট না পাঠিয়ে নতুন ছোট স্কেল
        // ফেরত দেয় — ধাপ ২ সেই স্কেলে আবার এঁকে পাঠায়। ফলে ডিফল্ট ছোট জায়গাতেও লেখা "ভেঙে"/চাপা পড়ে না,
        // পুরো কনটেন্ট সমানুপাতে ছোট হয়ে ঠিক ঐ জায়গায় বসে।
        // ✅ v24: রেন্ডার-লক। অ্যালার্ম-থ্রেড, onUpdate (মেইন থ্রেড), WorkManager একসাথে আপডেট চালালে
        // শেয়ার্ড মাপ-ম্যাপ (bmpHeightPx/bmpWidthPx) ও activeTheme মিশে যেত — এখন একবারে একটাই রেন্ডার চলে।
        private val RENDER_LOCK = Any()

        fun updateWidget(context: Context, mgr: AppWidgetManager, widgetId: Int) {
            synchronized(RENDER_LOCK) {
                val retryScale = updateWidgetPass(context, mgr, widgetId, null, true)
                if (retryScale != null) updateWidgetPass(context, mgr, widgetId, retryScale, false)
            }
        }

        private fun updateWidgetPass(
            context: Context, mgr: AppWidgetManager, widgetId: Int,
            scaleOverride: Float?, allowRetry: Boolean
        ): Float? {
            val views = RemoteViews(context.packageName, R.layout.widget_prayer_times)
            try {
                val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

                // ✅ v10-v14: ইউজারের ম্যানুয়ালি-এডিটযোগ্য কনফিগ (widget_style_config.json) — প্রতিটা
                // টেক্সট/আইকন/বক্সের সাইজ, রঙ, বোল্ড, দৃশ্যমানতা, পজিশন, স্বচ্ছতা, ছায়া, লেখা পাল্টানো
                // সব এখান থেকেই আসে। বিস্তারিত: WIDGET_CUSTOMIZATION_GUIDE.md এবং WidgetStyleConfig.kt।
                WidgetStyleConfig.ensureExternalCopyExists(context)
                val cfg = WidgetStyleConfig.load(context)
                val tx = cfg.texts
                val ic = cfg.icons
                val lbl = cfg.labels
                WidgetFontRenderer.letterSpacingEm = cfg.letterSpacingEm
                val lineGapExtraPx = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, cfg.lineGapExtraDp, context.resources.displayMetrics
                ).toInt()
                fun applyExtraLineGap(viewId: Int) {
                    if (lineGapExtraPx > 0) safeSetViewPadding(views, viewId, 0, lineGapExtraPx, 0, 0)
                }

                // ✅ v12-v14: প্রতিটা বক্সের পজিশন/সাইজ/স্বচ্ছতা/ছায়া/দৃশ্যমানতা/ব্যাকগ্রাউন্ড-দৃশ্যমানতা।
                val density = context.resources.displayMetrics.density
                fun dpPx(dp: Float): Int = (dp * density + 0.5f).toInt()

                // ✅ v16: নিচের কাউন্টডাউন সারি দেখা যাচ্ছে কি না ট্র্যাক করা হয় — না দেখা গেলে মূল
                // কার্ডের নিচের ফাঁকা সামান্য কমানো হয় (হাইলাইট বক্সের কিনারা থেকে সমান দূরত্বের জন্য)।
                var countdownShown = true
                // ✅ v17: পাঁচ ওয়াক্তের ঘরের একই উচ্চতা (px) এবং লেখার নিচ থেকে ঘরের নিচ পর্যন্ত ফাঁকা —
                // নিচের ফাঁকা সমান করতে শেষে কাজে লাগে
                var prayerSidePx = 0
                var prayerBottomInsetPx = 0
                var highlightShown = false
                fun setCountdownRow(visible: Boolean) {
                    countdownShown = visible
                    views.setViewVisibility(R.id.row_countdown, if (visible) View.VISIBLE else View.GONE)
                }

                // ✅ v17: লঞ্চার এখন উইজেটকে কত dp জায়গা দিচ্ছে (রিসাইজ করলে বদলায়) — এটা দিয়েই নিচে
                // "ছোট করলে কাউন্টডাউন/লেখা কাটা পড়বে কি না" হিসাব করা হয়। পোর্ট্রেটে প্রস্থ = MIN_WIDTH,
                // উচ্চতা = MAX_HEIGHT; ল্যান্ডস্কেপে উল্টো (Android-এর নিজস্ব নিয়ম)।
                val widgetOpts: Bundle? = try { mgr.getAppWidgetOptions(widgetId) } catch (_: Throwable) { null }
                val isLandscape = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                val availWidthDp: Int = widgetOpts?.getInt(
                    if (isLandscape) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0
                ) ?: 0
                val availHeightDp: Int = widgetOpts?.getInt(
                    if (isLandscape) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0
                ) ?: 0
                val edgeDp = cfg.layout.edgePaddingDp
                val innerWidthPx = if (availWidthDp > 0) dpPx(availWidthDp - 2 * edgeDp) else 0
                // ✅ v20: এই উইজেট-ইনস্ট্যান্সের জায়গার মাপ অনুযায়ী লেখার স্কেল (এরপর আঁকা সব বিটম্যাপ/নেটিভ লেখায় প্রযোজ্য)
                // ধাপ ১ সবসময় রেফারেন্স স্কেল ১.০-এ আঁকে (মাপ নেওয়ার জন্য); ধাপ ২ মডেলের হিসাব-করা স্কেলে
                uiScale = scaleOverride ?: 1f

                // ✅ v17: কাউন্টডাউন লাইনের বাংলা লেখা — জায়গা কম হলে (ছোট উইজেট) অক্ষর সমানুপাতে ছোট হয়ে
                // একই লাইনে ধরে যায় (কখনো ভেঙে/কেটে যায় না)। সাধারণ সাইজে আগের মতোই ১৩sp।
                fun setCountdownLabelFit(text: String, style: WidgetStyleConfig.TextStyle, color: Int, reserveDp: Float) {
                    val id = R.id.widget_countdown_label
                    if (!style.visible) { views.setViewVisibility(id, View.GONE); bmpHeightPx[id] = 0; bmpWidthPx[id] = 0; return }
                    views.setViewVisibility(id, View.VISIBLE)
                    var size = (style.sizeSp ?: 13f) * uiScale
                    val bold = style.bold ?: true
                    val prevSpacing = WidgetFontRenderer.letterSpacingEm
                    style.letterSpacingEm?.let { WidgetFontRenderer.letterSpacingEm = it }
                    try {
                        var bmp = WidgetFontRenderer.render(context, text, size, color, bold)
                        val allowed = innerWidthPx - dpPx(reserveDp)
                        if (innerWidthPx > 0 && allowed > 0 && bmp.width > allowed) {
                            size = (size * allowed / bmp.width).coerceAtLeast(9f)
                            bmp = WidgetFontRenderer.render(context, text, size, color, bold)
                        }
                        bmpHeightPx[id] = bmp.height; bmpWidthPx[id] = bmp.width
                        views.setImageViewBitmap(id, bmp)
                    } catch (_: Throwable) {
                    } finally {
                        WidgetFontRenderer.letterSpacingEm = prevSpacing
                    }
                    if (style.scaleX != 1f) safeSetFloat(views, id, "setScaleX", style.scaleX)
                    if (style.scaleY != 1f) safeSetFloat(views, id, "setScaleY", style.scaleY)
                }

                // ✅ v16: scale এখন গুণফল (scale × scale_x / scale × scale_y) — null আর লাগে না।
                // absolute=true হলে (যেসব মান XML-এও বসানো আছে: মূল কার্ডের ছায়া, AM/PM বক্সের সরানো)
                // JSON-এর মানই চূড়ান্ত হিসেবে প্রতিবার প্রয়োগ হয় (Android ১২+ এ)।
                fun applyBoxTransform(viewId: Int, t: WidgetStyleConfig.BoxTransform, absolute: Boolean = false) {
                    if (absolute || t.translateXDp != 0f) safeSetFloat(views, viewId, "setTranslationX", t.translateXDp * density)
                    if (absolute || t.translateYDp != 0f) safeSetFloat(views, viewId, "setTranslationY", t.translateYDp * density)
                    val sx = t.scale * (t.scaleX ?: 1f)
                    val sy = t.scale * (t.scaleY ?: 1f)
                    if (absolute || sx != 1f) safeSetFloat(views, viewId, "setScaleX", sx)
                    if (absolute || sy != 1f) safeSetFloat(views, viewId, "setScaleY", sy)
                    if (absolute || t.alpha != 1f) safeSetFloat(views, viewId, "setAlpha", t.alpha.coerceIn(0f, 1f))
                    if (absolute || t.elevationDp != 0f) safeSetFloat(views, viewId, "setElevation", t.elevationDp * density)
                }
                // ✅ v14: শুধু ব্যাকগ্রাউন্ড শেপ/রঙটা লুকানোর জন্য — কনটেন্ট/আইকন/লেখা যথাস্থানে থেকে যায়
                fun applyBackgroundVisible(viewId: Int, backgroundVisible: Boolean, defaultDrawableRes: Int) {
                    if (!backgroundVisible) {
                        safeSetInt(views, viewId, "setBackgroundResource", android.R.color.transparent)
                    }
                }
                // ✅ v14: আইকন (গোল ব্যাজ + ভেতরের glyph, একসাথে) — visible/scale
                fun applyIconStyle(viewId: Int, style: WidgetStyleConfig.IconStyle, absolute: Boolean = false) {
                    if (!style.visible) {
                        views.setViewVisibility(viewId, View.GONE)
                        return
                    }
                    if (absolute || style.scale != 1f) {
                        safeSetFloat(views, viewId, "setScaleX", style.scale)
                        safeSetFloat(views, viewId, "setScaleY", style.scale)
                    }
                }

                applyBoxTransform(R.id.widget_root, cfg.boxes.mainCard, absolute = true)
                applyBoxTransform(R.id.logo_frame, cfg.boxes.logoFrame)
                applyBoxTransform(R.id.clock_pill, cfg.boxes.clockPill)
                applyBoxTransform(R.id.celestial_pill, cfg.boxes.celestialPill)
                applyBoxTransform(R.id.sehri_pill, cfg.boxes.sehriPill)
                applyBoxTransform(R.id.iftar_pill, cfg.boxes.iftarPill)
                applyBoxTransform(R.id.weather_pill, cfg.boxes.weatherPill)
                applyBackgroundVisible(R.id.logo_frame, cfg.boxes.logoFrame.backgroundVisible, R.drawable.widget_logo_frame)
                applyBackgroundVisible(R.id.clock_pill, cfg.boxes.clockPill.backgroundVisible, R.drawable.widget_pill_background)
                applyBackgroundVisible(R.id.celestial_pill, cfg.boxes.celestialPill.backgroundVisible, R.drawable.widget_pill_background)
                applyBackgroundVisible(R.id.sehri_pill, cfg.boxes.sehriPill.backgroundVisible, R.drawable.widget_pill_background)
                applyBackgroundVisible(R.id.iftar_pill, cfg.boxes.iftarPill.backgroundVisible, R.drawable.widget_pill_background)
                applyBackgroundVisible(R.id.weather_pill, cfg.boxes.weatherPill.backgroundVisible, R.drawable.widget_pill_background)
                applyIconStyle(R.id.widget_logo, ic.logo)
                applyIconStyle(R.id.celestial_icon_circle, ic.celestialIcon)
                applyIconStyle(R.id.clock_icon_circle, ic.clockIcon, absolute = true)
                applyIconStyle(R.id.sehri_icon_circle, ic.sehriIcon)
                applyIconStyle(R.id.iftar_icon_circle, ic.iftarIcon)
                applyIconStyle(R.id.weather_icon_circle, ic.weatherIcon)
                // ✅ v15: AM/PM-এর নিচের গোল ব্যাকগ্রাউন্ড বৃত্ত — আলাদাভাবে সরানো/ছোট-বড়/স্বচ্ছতা/
                // ছায়া/লুকানো, প্লাস শুধু ব্যাকগ্রাউন্ড-বৃত্তটা লুকানো (ভেতরের AM/PM লেখা রেখে)।
                // ✅ v23: AM/PM-এর translationX/Y আগে JSON থেকে (-8dp) শুধু Android ১২+ এ প্রয়োগ হতো (পুরনো ভার্সনে
                // সেটা চলত না) — তাই এক ফোনে ঠিক, আরেক ফোনে AM/PM সেকেন্ডের উপর উঠে যেত। এখন বাঁয়ে সরানো (ঋণাত্মক X)
                // উপেক্ষা করা হয় (পুরনো কনফিগ কপি থাকলেও নিরাপদ) এবং বেসলাইন-সমন্বয় (২dp) XML-এর সাথে একই রাখা হয়।
                applyBoxTransform(
                    R.id.widget_live_clock_ampm_container,
                    cfg.boxes.clockAmpmBox.copy(
                        translateXDp = maxOf(0f, cfg.boxes.clockAmpmBox.translateXDp),
                        translateYDp = cfg.boxes.clockAmpmBox.translateYDp + CLOCK_BASELINE_FIX_DP
                    ),
                    absolute = true
                )
                // v17: AM/PM-এর গোল বৃত্ত এখন আলাদা ImageView (ampm_circle_bg) — শুধু সেটাই লুকানো হয়
                if (!cfg.boxes.clockAmpmBox.backgroundVisible) views.setViewVisibility(R.id.ampm_circle_bg, View.GONE)
                if (!cfg.boxes.clockAmpmBox.visible) views.setViewVisibility(R.id.widget_live_clock_ampm_container, View.GONE)

                // ✅ v15: ৪টা মূল সারি (লাইন) আলাদাভাবে সরানো/ছোট-বড়/স্বচ্ছতা/ছায়া/লুকানো — পুরো
                // লাইনটাই (তার ভেতরের সব বক্স/লেখাসহ) একসাথে নড়ে।
                applyBoxTransform(R.id.row_top, cfg.rows.topRow)
                applyBoxTransform(R.id.row_clock_weather, cfg.rows.clockWeatherRow)
                applyBoxTransform(R.id.row_prayers, cfg.rows.prayersRow)
                applyBoxTransform(R.id.row_countdown, cfg.rows.countdownRow)
                if (!cfg.rows.topRow.visible) views.setViewVisibility(R.id.row_top, View.GONE)
                if (!cfg.rows.clockWeatherRow.visible) views.setViewVisibility(R.id.row_clock_weather, View.GONE)
                if (!cfg.rows.prayersRow.visible) views.setViewVisibility(R.id.row_prayers, View.GONE)
                if (!cfg.rows.countdownRow.visible) setCountdownRow(false)

                // ✅ v15: ঘড়ির সময়/সেকেন্ড আলাদাভাবে লম্বা/চেপ্টা (stretch_x/stretch_y) ও নিজস্ব
                // অক্ষর-ফাঁকা (letter_spacing_em) — TextView.setLetterSpacing() সরাসরি Android-এর
                // নিজস্ব ফাংশন, RemoteViews.setFloat() দিয়ে নিরাপদে প্রয়োগ করা যায়।
                fun applyClockStretch(viewId: Int, style: WidgetStyleConfig.TextStyle) {
                    // ✅ v16: scaleY XML-এও বসানো (মেইন ঘড়ি ১.৩, সেকেন্ড ১.১), তাই Android ১২+ এ
                    // JSON-এর মানই সবসময় প্রয়োগ হয়; পুরনো ফোনে XML-এর মান কাজ করে।
                    safeSetFloat(views, viewId, "setScaleX", style.scaleX)
                    safeSetFloat(views, viewId, "setScaleY", style.scaleY)
                    style.letterSpacingEm?.let { safeSetFloat(views, viewId, "setLetterSpacing", it) }
                }
                applyClockStretch(R.id.widget_live_clock_main, tx.clockTime)
                applyClockStretch(R.id.widget_live_clock_seconds, tx.clockSeconds)

                // মূল কার্ড/লোগো/ঘড়ি/সূর্যোদয়-সূর্যাস্ত — এগুলোর visibility অন্য কোনো শর্তের উপর
                // নির্ভর করে না, তাই এখনই সরাসরি প্রয়োগ করা নিরাপদ।
                if (!cfg.boxes.mainCard.visible) views.setViewVisibility(R.id.widget_root, View.GONE)
                if (!cfg.boxes.logoFrame.visible) views.setViewVisibility(R.id.logo_frame, View.GONE)
                if (!cfg.boxes.clockPill.visible) views.setViewVisibility(R.id.clock_pill, View.GONE)
                if (!cfg.boxes.celestialPill.visible) views.setViewVisibility(R.id.celestial_pill, View.GONE)
                // sehri_pill/iftar_pill/weather_pill-এর visibility নিচে ফাংশনের একদম শেষে (বিদ্যমান
                // showSehriIftar/showWeather লজিকের পরে) প্রয়োগ করা হয় — যাতে config "visible: false"
                // থাকলে সেটাই শেষ কথা হয়, আর "visible: true" (ডিফল্ট) থাকলে বিদ্যমান লজিক অক্ষত থাকে।
                // ✅ প্রতিটা নামাজের রো আলাদাভাবে দেখানো/লুকানো
                if (!cfg.prayerRows.fajr) views.setViewVisibility(R.id.row_fajr, View.GONE)
                if (!cfg.prayerRows.dhuhr) views.setViewVisibility(R.id.row_dhuhr, View.GONE)
                if (!cfg.prayerRows.asr) views.setViewVisibility(R.id.row_asr, View.GONE)
                if (!cfg.prayerRows.maghrib) views.setViewVisibility(R.id.row_maghrib, View.GONE)
                if (!cfg.prayerRows.isha) views.setViewVisibility(R.id.row_isha, View.GONE)

                // ✅ v17: ডিফল্ট (ইউজার অ্যাপ না খুলে সরাসরি উইজেট যোগ করলে) = লাইভ ঘড়ি ON + সাহরী/ইফতার ON,
                // আবহাওয়া OFF। পরে অ্যাপের উইজেট হাব থেকে বদলালে সেই সেটিংসই প্রযোজ্য।
                var theme = "glass"
                var showClock = true
                var showWeather = false
                var showSehriIftar = true
                // ✅ v20: কাস্টম থিম — ইউজারের বাছা ব্যাকগ্রাউন্ড রঙ (#RRGGBB), স্বচ্ছতা (১০–১০০%) এবং
                // লেখা/আইকনের টোন ("auto" | "dark" = সাদা লেখা | "light" = গাঢ় লেখা)
                var customBgColor = 0xFF1E293B.toInt()
                var customOpacityPct = 90
                var customTone = "auto"
                prefs.getString(KEY_SETTINGS, null)?.let {
                    try {
                        val s = JSONObject(it)
                        theme = s.optString("theme", "glass")
                        showClock = s.optBoolean("showClock", true)
                        showWeather = s.optBoolean("showWeather", false)
                        showSehriIftar = s.optBoolean("showSehriIftar", true)
                        customBgColor = resolveColor(s.optString("customBg", ""), customBgColor)
                        customOpacityPct = s.optInt("customOpacity", 90).coerceIn(10, 100)
                        customTone = s.optString("customTone", "auto")
                    } catch (_: Exception) {}
                }
                // রঙ সবসময় অপাক (alpha=FF) ধরা হয়; স্বচ্ছতা আলাদা স্লাইডার থেকে
                customBgColor = customBgColor or 0xFF000000.toInt()
                // ✅ v17: ঘড়ি চালু থাকলে আবহাওয়া ও সাহরী/ইফতার একসাথে চলে না (একটা অপরটাকে বন্ধ করে —
                // হাব-এর সেটিংসে এটা আগেই ঠিক হয়ে আসে; এখানে নিরাপত্তা-জাল হিসেবে সাহরী/ইফতারকে অগ্রাধিকার)।
                // ঘড়ি বন্ধ থাকলে দুটোই একসাথে দেখানো যায়।
                if (showClock && showSehriIftar && showWeather) showWeather = false

                val lightUi = if (theme == "custom") {
                    when (customTone) {
                        "light" -> true
                        "dark" -> false
                        else -> isLightColor(customBgColor)
                    }
                } else isLightTheme(theme)
                activeTheme = if (lightUi) "light" else "dark"

                // ✅ FIX #10: বাংলা লেবেল/টেক্সটগুলো এখন Kalpurush ফন্টে Bitmap হিসেবে আঁকা হয় (দেখুন
                // WidgetFontRenderer.kt) — তাই রঙ নির্ধারণ আগেভাগেই করে নেওয়া হচ্ছে, যাতে কনটেন্ট ও
                // রঙ একসাথে setBn() দিয়ে সেট করা যায়।
                val isJumma = todayIsFriday()
                val lightText = !lightUi
                val mainColor = if (lightText) 0xFFF1F5F9.toInt() else 0xFF070D19.toInt()
                // ✅ FIX #11: "উজ্জ্বল সাদা" রিকোয়েস্ট — ডার্ক (glass) ও নো-ব্যাকগ্রাউন্ড (nobg) থিমে
                // এই টেক্সটগুলো (তারিখ লাইন, নামাজের নাম) এখন pure white; লাইট থিমে আগের মতোই মিউটেড
                // ধূসর/গাঢ় রঙ থাকবে, যাতে সাদা ব্যাকগ্রাউন্ডে পড়তে সমস্যা না হয়।
                val mutedColor = if (lightUi) 0xFF475569.toInt() else 0xFFFFFFFF.toInt()
                // সূর্যোদয়/সূর্যাস্ত, সাহরী, ইফতার, আবহাওয়া লেবেলগুলো সবসময় নিজস্ব ডার্ক পিলের (widget_pill_background,
                // যেটা থিম-নির্বিশেষে সবসময় গাঢ় #0F1729) উপর বসে — তাই এগুলো সব থিমেই উজ্জ্বল সাদা রাখা নিরাপদ।
                val celestialTitleColor = 0xFFFFFFFF.toInt()

                // ✅ v17: আইকনের গোল ব্যাকগ্রাউন্ড বৃত্ত (JSON icon_circles — ডার্ক/লাইট আলাদা রঙ + অপাসিটি)
                // এবং ভেতরের আইকন (থিম অনুযায়ী ডার্ক/লাইট ফাইল) — রঙ বদলাতে রিবিল্ডও লাগে না।
                val strokePx = dpPx(1f).coerceAtLeast(1)
                fun applyCircle(viewId: Int, sizeDp: Float, c: WidgetStyleConfig.CircleStyle) {
                    val hex = if (lightUi) c.colorLightHex else c.colorHex
                    val fillA = if (lightUi) c.opacityLight else c.opacity
                    val borderA = if (lightUi) c.borderOpacityLight else c.borderOpacity
                    val bmp = buildCircleBitmap(dpPx(sizeDp) * 2, resolveColor(hex, 0xFF888888.toInt()), fillA, borderA, strokePx * 2)
                    if (bmp != null) { try { views.setImageViewBitmap(viewId, bmp) } catch (_: Throwable) {} }
                }
                fun setGlyph(viewId: Int, darkRes: Int, lightRes: Int) {
                    try { views.setImageViewResource(viewId, if (lightUi) lightRes else darkRes) } catch (_: Throwable) {}
                }
                applyCircle(R.id.celestial_circle_bg, 24f, cfg.iconCircles.celestial)
                applyCircle(R.id.clock_circle_bg, 28f, cfg.iconCircles.clock)
                applyCircle(R.id.sehri_circle_bg, 24f, cfg.iconCircles.sehri)
                applyCircle(R.id.iftar_circle_bg, 24f, cfg.iconCircles.iftar)
                applyCircle(R.id.weather_circle_bg, 28f, cfg.iconCircles.weather)
                applyCircle(R.id.ampm_circle_bg, 16f, cfg.iconCircles.ampm)
                setGlyph(R.id.clock_icon_glyph, R.drawable.ic_widget_clock, R.drawable.ic_widget_clock_light)
                setGlyph(R.id.sehri_icon_glyph, R.drawable.ic_widget_sehri, R.drawable.ic_widget_sehri_light)
                setGlyph(R.id.iftar_icon_glyph, R.drawable.ic_widget_iftar, R.drawable.ic_widget_iftar_light)
                setGlyph(R.id.weather_icon_glyph, R.drawable.ic_widget_thermometer, R.drawable.ic_widget_thermometer_light)
                // সূর্যোদয়/সূর্যাস্ত: টাইটেলের সাথে মিল রেখে — সূর্য ওঠার পর থেকে ডোবা পর্যন্ত "সূর্যাস্ত"
                // (নিচে নামার আইকন), ডোবার পর থেকে ওঠা পর্যন্ত "সূর্যোদয়" (উপরে ওঠার আইকন)।
                fun setCelestialGlyph(sunsetNext: Boolean) {
                    if (sunsetNext) setGlyph(R.id.celestial_icon, R.drawable.ic_widget_sunset, R.drawable.ic_widget_sunset_light)
                    else setGlyph(R.id.celestial_icon, R.drawable.ic_widget_sunrise, R.drawable.ic_widget_sunrise_light)
                }
                setCelestialGlyph(true)

                // ডিফল্ট/ফলব্যাক কনটেন্ট আগে থেকেই এঁকে রাখা হচ্ছে (আগে TextView-এর XML android:text
                // ডিফল্ট এই কাজটা করত — ImageView-তে সেটা সম্ভব না, তাই কোডে ম্যানুয়ালি করা হলো), যাতে
                // ডেটা লোড না হওয়া পর্যন্ত বা কোনো এক্সেপশন হলেও widget-টা কখনো ফাঁকা না দেখায়।
                // ✅ FIX #24 (v9), configurable in v10: ছোট লেবেল/সাব-টেক্সটগুলোর ফন্ট সাইজ সব এখন
                // WidgetStyleConfig (widget_style_config.json) থেকে আসে — ডিফল্ট মান v9-এর সমান।
                // যেহেতু এই সবগুলো টেক্সট আলাদা আলাদা wrap_content ImageView-বিটম্যাপ (কোনো একটাও
                // সরাসরি ফিক্সড-প্রস্থ রিয়েল multi-line TextView না), তাই সাইজ বাড়লেও কখনো "দুই
                // লাইনে ভেঙে" যাবে না — সবচেয়ে ছোট রিসাইজেও ImageView নিজে থেকে ছবিটাকে
                // সমানুপাতিকভাবে ছোট করে বক্সের ভেতরেই রাখবে (adjustViewBounds + fitCenter/fitStart)।
                // ✅ v14: প্রতিটা লেখা এখন নিজস্ব TextStyle (visible/size/color/bold) + labels (শব্দ
                // পাল্টানো) অনুযায়ী আঁকা হয় — null/না-দেওয়া মানের জন্য আগের (v13) ডিফল্ট ব্যবহার হয়।
                setHijriDateBn(context, views, R.id.widget_date_arabic, "-- --- ----", mainColor, tx.hijriDayNumber, tx.hijriMonthYear)
                setDateLineBn(context, views, R.id.widget_date_others, "-- --- ----", "-- --- ----", tx.dateOthers, cfg.dateSeparator, 13f, mutedColor)
                applyExtraLineGap(R.id.widget_date_others)
                setBnStyled(context, views, R.id.celestial_title, lbl.sunset, tx.celestialTitle, 12.5f, celestialTitleColor)

                // নামাজের নাম লেবেল ও অন্যান্য স্থায়ী বাংলা লেবেল (থিম/জুমা অনুযায়ী রঙ/কনটেন্ট)
                setBnStyled(context, views, R.id.label_fajr, lbl.fajr, tx.prayerNames, 13.5f, mutedColor)
                setBnStyled(context, views, R.id.label_dhuhr, if (isJumma) (lbl.jumma) else (lbl.dhuhr), tx.prayerNames, 13.5f, mutedColor)
                setBnStyled(context, views, R.id.label_asr, lbl.asr, tx.prayerNames, 13.5f, mutedColor)
                setBnStyled(context, views, R.id.label_maghrib, lbl.maghrib, tx.prayerNames, 13.5f, mutedColor)
                setBnStyled(context, views, R.id.label_isha, lbl.isha, tx.prayerNames, 13.5f, mutedColor)
                // ✅ FIX #11: এই তিনটাও এখন সবসময় উজ্জ্বল সাদা (দেখুন celestialTitleColor-এর কমেন্ট)
                setBnStyled(context, views, R.id.label_weather_title, lbl.weather, tx.weatherTitle, 12.5f, celestialTitleColor)
                setBnStyled(context, views, R.id.label_sehri_title, lbl.sehri, tx.sehriTitle, 12.5f, celestialTitleColor)
                setBnStyled(context, views, R.id.label_iftar_title, lbl.iftar, tx.iftarTitle, 12.5f, celestialTitleColor)

                applyTheme(views, theme)
                // ✅ v20: কাস্টম ব্যাকগ্রাউন্ড লেয়ার (অন্য থিমে লুকানো)
                applyCustomBackground(
                    views,
                    theme == "custom" && cfg.boxes.mainCard.backgroundVisible,
                    customBgColor, customOpacityPct
                )
                // ✅ v14: মূল কার্ডের শুধু ব্যাকগ্রাউন্ড শেপ লুকানো (কনটেন্ট থাকবে) — applyTheme() যে
                // ব্যাকগ্রাউন্ড বসায় তার পরে প্রয়োগ করতে হয়, নাহলে সেটা আবার ফিরে আসত।
                if (!cfg.boxes.mainCard.backgroundVisible) {
                    safeSetInt(views, R.id.widget_root, "setBackgroundResource", android.R.color.transparent)
                }
                views.setViewVisibility(R.id.clock_pill, if (showClock) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.row_clock_weather, if (showClock || showWeather || showSehriIftar) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.weather_pill, if (showWeather) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.sehri_iftar_column, if (showSehriIftar) View.VISIBLE else View.GONE)

                // ✅ FIX #3: ফোন যদি ২৪-ঘণ্টা টাইম ফরম্যাটে সেট থাকে (যেমন 13:45), তাহলে AM/PM বৃত্তটা
                // অর্থহীন হয়ে যায় (TextClock তখন format24Hour ব্যবহার করে, কোনো AM/PM থাকে না) —
                // তাই সেই ক্ষেত্রে বৃত্তটা লুকিয়ে দেওয়া হচ্ছে, যাতে ডিজাইন না ভাঙে।
                val is24Hour = DateFormat.is24HourFormat(context)
                views.setViewVisibility(R.id.widget_live_clock_ampm_container, if (is24Hour) View.GONE else View.VISIBLE)

                val json = prefs.getString(KEY_TIMINGS, null)
                if (json == null) {
                    stopCountdown(views)
                    val hijriFirebase = prefs.getString("hijri_date_firebase", null)
                    // ✅ FIX #NEW (v6, প্রয়োজনীয়তা #৪): এখন উল্টো — হিজরি তারিখের সংখ্যা সবসময়
                    // বাংলা সংখ্যায় দেখানো হয় (আগে v5-এ ইচ্ছাকৃতভাবে ইংরেজিতে রূপান্তর করা হতো,
                    // এখন ইউজারের নতুন রিকোয়েস্ট অনুযায়ী পুরো উইজেটের বাকি সব সংখ্যার সাথে মিলিয়ে
                    // এটাও বাংলায় দেখানো হচ্ছে) — দেখুন setHijriDateBn()।
                    setHijriDateBn(context, views, R.id.widget_date_arabic, hijriFirebase ?: "-- --- ----", mainColor, tx.hijriDayNumber, tx.hijriMonthYear)
                    setBnStyled(context, views, R.id.widget_countdown_label, "অ্যাপ খুলে একবার সময় লোড করুন", plainColor(tx.countdownLabel), 13f, COLOR_AMBER, true)
                    views.setViewVisibility(R.id.countdown_warning_icon, View.GONE)
                    // ✅ FIX #21 (v8): এখানে দেখানোর মতো টেক্সট আছে, তাই পুরো সারিটা দৃশ্যমান রাখা হলো
                    setCountdownRow(true)
                } else {
                    try {
                        val data = JSONObject(json)
                        val fajr = data.optString("fajr", "--:--")
                        val sunrise = data.optString("sunrise", "--:--")
                        val dhuhr = data.optString("dhuhr", "--:--")
                        val asr = data.optString("asr", "--:--")
                        val maghrib = data.optString("maghrib", "--:--")
                        val isha = data.optString("isha", "--:--")
                        val sunset = data.optString("sunset", maghrib)

                        // ✅ FIX #1: আরবি তারিখ নির্ধারণ (বেজ তারিখ + দিন-ভিত্তিক এগিয়ে যাওয়া + আজকের মাগরিব শিফট)
                        // আগে শুধু "এখনকার সময় বনাম আজকের মাগরিবের সময়" তুলনা করা হতো — যেটা রাত ১২টার
                        // পর ভেঙে যেত (নতুন দিনের ঘড়ি ছোট মান নিয়ে শুরু হয়, তাই তুলনা মিথ্যা হয়ে যেত)।
                        // এখন আগে পূর্ণ ক্যালেন্ডার-দিন গুনে বেজ তারিখ এগিয়ে নেওয়া হয়, তারপর শুধু আজকের
                        // আংশিক দিনের জন্য মাগরিব-শিফট যোগ হয় — ফলে মধ্যরাতে আর রিভার্ট হয় না।
                        val baseHijri = data.optString("hijri", "-- --- ----")
                        val hijriFirebase = prefs.getString("hijri_date_firebase", null)
                        val adjustment = prefs.getInt("last_rtdb_adjustment", 0)
                        val today = FirebaseDataManager.todayDateOnlyStr()

                        var dateToShift = if (!hijriFirebase.isNullOrBlank()) {
                            val setOn = prefs.getString("hijri_date_firebase_set_on", today) ?: today
                            val daysElapsed = FirebaseDataManager.daysBetweenDateStr(setOn, today)
                            FirebaseDataManager.adjustHijriDate(hijriFirebase, daysElapsed)
                        } else if (baseHijri != "-- --- ----") {
                            val fetchedOn = prefs.getString("timings_fetched_on", today) ?: today
                            val daysElapsed = FirebaseDataManager.daysBetweenDateStr(fetchedOn, today)
                            FirebaseDataManager.adjustHijriDate(baseHijri, adjustment + daysElapsed)
                        } else {
                            baseHijri
                        }

                        if (dateToShift != "-- --- ----") {
                            val nowMin = nowMinutesLocal()
                            val mMin = parseToMinutes(maghrib)
                            // আজকের মাগরিব পার হয়ে থাকলে শুধু আজকের আংশিক দিনটার জন্য ১ দিন এগিয়ে দেওয়া
                            // (আগের দিনগুলোর শিফট ইতোমধ্যে daysElapsed গণনায় ধরা পড়ে গেছে)
                            if (mMin != -1 && nowMin >= mMin) {
                                dateToShift = FirebaseDataManager.adjustHijriDate(dateToShift, 1)
                            }
                        }
                        // ✅ FIX #NEW (v6, প্রয়োজনীয়তা #৩ ও #৪): হিজরি তারিখ এখন বাংলা সংখ্যায় এবং
                        // "দিন" অংশটা বড়-বোল্ড, "মাস + সাল" অংশটা ছোট সাইজে (ইংরেজি তারিখ লাইনের
                        // মতোই) — একই লাইনে। দেখুন setHijriDateBn() ও WidgetFontRenderer.renderHijriDate()।
                        setHijriDateBn(context, views, R.id.widget_date_arabic, dateToShift, mainColor, tx.hijriDayNumber, tx.hijriMonthYear)

                        // ✅ হাররাম রোজা চেক (Spec অনুযায়ী)
                        val haramInfo = checkHaramRoza(dateToShift)
                        val haramActive = haramInfo != null

                        // v6 NEW: prayer times now rendered as Bengali-digit Kothamala
                        // bitmaps (time_fajr..time_isha are ImageView now, see layout XML).
                        // These 5 vars are reused later for active-row highlight re-render too.
                        val fajrDisp = FirebaseDataManager.convertEnglishToBengali(to12HourCompact(fajr))
                        val dhuhrDisp = FirebaseDataManager.convertEnglishToBengali(to12HourCompact(dhuhr))
                        val asrDisp = FirebaseDataManager.convertEnglishToBengali(to12HourCompact(asr))
                        val maghribDisp = FirebaseDataManager.convertEnglishToBengali(to12HourCompact(maghrib))
                        val ishaDisp = FirebaseDataManager.convertEnglishToBengali(to12HourCompact(isha))
                        val haramLabelBn = "\u09a8\u09bf\u09b7\u09bf\u09a6\u09cd\u09a7" // "নিষিদ্ধ"

                        if (haramActive) {
                            listOf(R.id.time_fajr, R.id.time_dhuhr, R.id.time_asr, R.id.time_maghrib, R.id.time_isha).forEach {
                                setBnStyled(context, views, it, haramLabelBn, tx.prayerTimes, 17f, mainColor, true)
                                applyExtraLineGap(it)
                            }
                            views.setViewVisibility(R.id.countdown_warning_icon, View.VISIBLE)
                            setCountdownLabelFit(haramInfo ?: "", plainColor(tx.countdownLabel), countdownStyleColor(tx.countdownLabel, true, COLOR_RED), 24f)
                            views.setViewVisibility(R.id.widget_countdown_chrono, View.GONE)
                            // ✅ FIX #21 (v8): হাররাম রোজার তথ্য টেক্সট আছে, তাই সারিটা দৃশ্যমান রাখা হলো
                            // (নিচের waqtState-ভিত্তিক ব্লকে যদি এটা আবার আপডেট হয়, সেটাও যথাযথভাবে
                            // সারির visibility ঠিক করে দেবে — তাই এখানে ও ওখানে দুই জায়গাতেই সেট করা নিরাপদ)
                            setCountdownRow(true)
                        } else {
                            setBnStyled(context, views, R.id.time_fajr, fajrDisp, tx.prayerTimes, 17f, mainColor, true)
                            setBnStyled(context, views, R.id.time_dhuhr, dhuhrDisp, tx.prayerTimes, 17f, mainColor, true)
                            setBnStyled(context, views, R.id.time_asr, asrDisp, tx.prayerTimes, 17f, mainColor, true)
                            setBnStyled(context, views, R.id.time_maghrib, maghribDisp, tx.prayerTimes, 17f, mainColor, true)
                            setBnStyled(context, views, R.id.time_isha, ishaDisp, tx.prayerTimes, 17f, mainColor, true)
                            listOf(R.id.time_fajr, R.id.time_dhuhr, R.id.time_asr, R.id.time_maghrib, R.id.time_isha).forEach { applyExtraLineGap(it) }
                        }

                        // ✅ FIX #12 (তারিখ আটকে থাকার সমস্যা — ইংরেজি/বাংলা ক্যালেন্ডার অংশ):
                        // আগে এখানে নেটওয়ার্ক থেকে শেষবার fetch করা ক্যাশড "gregorian"/"bangla"
                        // স্ট্রিং সরাসরি দেখানো হতো — যেটা শুধু অ্যাপ খুললে (নতুন fetch হলে) আপডেট
                        // হতো, তাই কয়েকদিন অ্যাপ না খুললে এই দুটো পুরনো তারিখেই আটকে থাকত (হিজরির
                        // মতো এগুলোর কোনো day-elapsed স্বয়ংক্রিয় হিসাব ছিল না)। এখন প্রতিবার
                        // updateWidget() চলার সময় ফোনের বর্তমান তারিখ থেকে সরাসরি হিসাব করে বের
                        // করা হচ্ছে, তাই অ্যাপ না খুললেও প্রতিদিন ঠিক সময়ে (মধ্যরাতের পরের রিফ্রেশ
                        // সাইকেলে) স্বয়ংক্রিয়ভাবে সঠিক তারিখ দেখাবে।
                        // ✅ FIX #NEW (v6, প্রয়োজনীয়তা #৪): ইংরেজি/বাংলা ক্যালেন্ডার লাইনের সংখ্যাও
                        // এখন বাংলা সংখ্যায় দেখানো হচ্ছে (আগে এই লাইনটা ইংরেজি ডিজিটেই থেকে যাচ্ছিল)
                        setDateLineBn(context, views, R.id.widget_date_others,
                            FirebaseDataManager.convertEnglishToBengali(computeTodayGregorianStr()),
                            FirebaseDataManager.convertEnglishToBengali(computeTodayBanglaStr()),
                            tx.dateOthers, cfg.dateSeparator, 13f, mutedColor)
                        applyExtraLineGap(R.id.widget_date_others)

                        // v6 NEW: sehri/iftar time now Bengali-digit bitmap (was plain TextView).
                        // Always white text (fixed dark pill background regardless of theme).
                        if (showSehriIftar) {
                            setBnStyled(context, views, R.id.widget_sehri_time, FirebaseDataManager.convertEnglishToBengali(to12HourCompact(fajr)), tx.sehriTime, 13.5f, COLOR_WHITE, true)
                            setBnStyled(context, views, R.id.widget_iftar_time, FirebaseDataManager.convertEnglishToBengali(to12HourCompact(maghrib)), tx.iftarTime, 13.5f, COLOR_WHITE, true)
                            applyExtraLineGap(R.id.widget_sehri_time)
                            applyExtraLineGap(R.id.widget_iftar_time)
                        }

                        // v6 NEW: weather temperature now Bengali-digit bitmap (was plain TextView).
                        if (showWeather) {
                            val temp = prefs.getString(KEY_TEMP, null) ?: "--°C"
                            setBnStyled(context, views, R.id.widget_temp_value, FirebaseDataManager.convertEnglishToBengali(temp), tx.weatherValue, 14.5f, COLOR_WHITE, true)
                            applyExtraLineGap(R.id.widget_temp_value)
                        }

                        val nowMin = nowMinutesLocal()
                        val srMin = parseToMinutes(sunrise)
                        val ssMin = parseToMinutes(sunset)

                        // ✅ রমজান লজিক রিমুভ করা হলো (Spec অনুযায়ী) — সবসময় সূর্যোদয়/সূর্যাস্ত দেখাবে
                        if (srMin != -1 && ssMin != -1 && nowMin in srMin until ssMin) {
                            setBnStyled(context, views, R.id.celestial_title, lbl.sunset, tx.celestialTitle, 12.5f, celestialTitleColor)
                            setBnStyled(context, views, R.id.celestial_time, FirebaseDataManager.convertEnglishToBengali(to12HourCompact(sunset)), tx.celestialTime, 13.5f, COLOR_WHITE, true)
                            setCelestialGlyph(true)
                        } else {
                            setBnStyled(context, views, R.id.celestial_title, lbl.sunrise, tx.celestialTitle, 12.5f, celestialTitleColor)
                            setBnStyled(context, views, R.id.celestial_time, FirebaseDataManager.convertEnglishToBengali(to12HourCompact(sunrise)), tx.celestialTime, 13.5f, COLOR_WHITE, true)
                            setCelestialGlyph(false)
                        }
                        applyExtraLineGap(R.id.celestial_time)

                        val waqtState = computeWaqtState(fajr, sunrise, dhuhr, asr, maghrib, isha, sunset)

                        // ✅ FIX #4: phase শেষে exact alarm schedule করো — negative countdown এড়াতে
                        WidgetRefreshScheduler.schedulePhaseEnd(context, waqtState.phaseEndMillis)

                        resetHighlights(views)
                        listOf(R.id.row_fajr, R.id.row_dhuhr, R.id.row_asr, R.id.row_maghrib, R.id.row_isha).forEach { r ->
                            safeSetViewPadding(views, labelIdFor(r), 0, 0, 0, 0)
                            safeSetViewPadding(views, timeIdFor(r), 0, lineGapExtraPx, 0, 0)
                        }

                        // ✅ v17: পাঁচটা ঘরই সবসময় একই উচ্চতার (হাইলাইট থাকুক বা না থাকুক) — তাই নিষিদ্ধ সময়
                        // বা গ্যাপে হাইলাইট না থাকলেও উইজেটের উচ্চতা লাফায় না, আর লেখা প্রতিটা ঘরের উপর-নিচে
                        // ঠিক মাঝখানে বসে। হাইলাইট স্কয়ারের বাহু = এই উচ্চতা (১:১ থাকে)।
                        run {
                            val cellIds = listOf(R.id.row_fajr, R.id.row_dhuhr, R.id.row_asr, R.id.row_maghrib, R.id.row_isha)
                            var maxLabelH = 0
                            var maxTimeH = 0
                            cellIds.forEach { r ->
                                maxLabelH = maxOf(maxLabelH, bmpHeightPx[labelIdFor(r)] ?: 0)
                                maxTimeH = maxOf(maxTimeH, bmpHeightPx[timeIdFor(r)] ?: 0)
                            }
                            fun colHeight(lh: Int, th: Int) = dpPx(CELL_PAD_DP) * 2 + lh +
                                (if (th > 0) dpPx(TIME_MARGIN_TOP_DP) + lineGapExtraPx + th else 0)
                            val colMax = colHeight(maxLabelH, maxTimeH)
                            val baseSide = (colMax + dpPx(cfg.highlight.sizeAdjustDp)).coerceAtLeast(dpPx(8f))
                            // ✅ HL_SCALE দিয়ে বক্স বড় করা: চারপাশ সমানভাবে বাড়ে, তাই ১:১ ঠিক থাকে
                            val side = (baseSide * HL_SCALE).toInt().coerceAtLeast(dpPx(8f))
                            prayerSidePx = side
                            var minInset = Int.MAX_VALUE
                            cellIds.forEach { r ->
                                val lh = bmpHeightPx[labelIdFor(r)] ?: 0
                                val th = bmpHeightPx[timeIdFor(r)] ?: 0
                                val extraH = (side - colHeight(lh, th)).coerceAtLeast(0)
                                val padTop = extraH / 2
                                val padBottom = extraH - padTop
                                when {
                                    lh > 0 && th > 0 -> {
                                        safeSetViewPadding(views, labelIdFor(r), 0, padTop, 0, 0)
                                        safeSetViewPadding(views, timeIdFor(r), 0, lineGapExtraPx, 0, padBottom)
                                    }
                                    lh > 0 -> safeSetViewPadding(views, labelIdFor(r), 0, padTop, 0, padBottom)
                                    th > 0 -> safeSetViewPadding(views, timeIdFor(r), 0, lineGapExtraPx + padTop, 0, padBottom)
                                }
                                if (lh > 0 || th > 0) minInset = minOf(minInset, dpPx(CELL_PAD_DP) + padBottom)
                            }
                            prayerBottomInsetPx = if (minInset == Int.MAX_VALUE) 0 else minInset
                        }

                        // ✅ FIX #2: computed waqtState.active সর্বদা প্রাধান্য পাবে।
                        // jsActiveWaqt শুধুমাত্র gap (active==null) এর সময় ব্যবহার হবে।
                        val jsActiveWaqt = prefs.getString("active_waqt_key", null)
                        val lastSync = prefs.getLong("last_sync_timestamp", 0L)
                        val isStale = (System.currentTimeMillis() - lastSync) > 60 * 60 * 1000

                        val activeWaqt: String? = when {
                            waqtState.active != null -> waqtState.active  // computed সবসময় জেতে
                            jsActiveWaqt != null && !isStale && jsActiveWaqt.isNotEmpty() -> jsActiveWaqt
                            else -> null
                        }

                        // ✅ FIX #3: forbidden+gap এর সময় (যেমন দুপুরের নিষিদ্ধ সময়)
                        // upcoming Dhuhr row হাইলাইট করো
                        val effectiveWaqt: String? = if (waqtState.isForbidden && activeWaqt == null) {
                            "Dhuhr"  // gap+forbidden মানে sunrise-to-dhuhr এর মধ্যে → Dhuhr upcoming
                        } else {
                            activeWaqt
                        }

                        val rowId = when (effectiveWaqt) {
                            "Fajr" -> R.id.row_fajr
                            "Dhuhr" -> R.id.row_dhuhr
                            "Asr" -> R.id.row_asr
                            "Maghrib" -> R.id.row_maghrib
                            "Isha" -> R.id.row_isha
                            else -> -1
                        }

                        // ✅ FIX #27 (v13): নিষিদ্ধ সময়ে (isForbidden) এখন আর কোনো ওয়াক্তের রো-তে লাল
                        // হাইলাইট বসানো হয় না — শুধু নিচের লাল কাউন্টডাউন টেক্সট/আইকনই (নিচে অপরিবর্তিত
                        // রাখা হয়েছে) দেখাবে। রো-গুলো তাদের ডিফল্ট (আগে থেকেই সেট করা, non-highlighted)
                        // অবস্থাতেই থেকে যাবে। নিষিদ্ধ সময় শেষ হয়ে গেলে waqtState.isForbidden false
                        // হয়ে যাবে, তখন স্বাভাবিকভাবেই effectiveWaqt-এর রো আবার হাইলাইট হবে।
                        if (rowId != -1 && !waqtState.isForbidden) {
                            // v6 NEW: figure out which Bengali-digit time text this row should show
                            // (or the Haram-Roza label) so the highlight re-render uses the same text.
                            val rowTimeText = if (haramActive) haramLabelBn else when (rowId) {
                                R.id.row_fajr -> fajrDisp
                                R.id.row_dhuhr -> dhuhrDisp
                                R.id.row_asr -> asrDisp
                                R.id.row_maghrib -> maghribDisp
                                R.id.row_isha -> ishaDisp
                                else -> ""
                            }

                            // light theme হলেও হাইলাইট বক্সে সাদা টেক্সট
                            if (lightUi) {
                                setRowTextWhite(context, views, rowId, isJumma, rowTimeText, tx.prayerTimes.sizeSp ?: 17f, tx.prayerNames.sizeSp ?: 13.5f, tx.prayerTimes.bold ?: true, lbl)
                            } else {
                                setRowTextDark(context, views, rowId, isJumma, rowTimeText, tx.prayerTimes.sizeSp ?: 17f, tx.prayerNames.sizeSp ?: 13.5f, tx.prayerTimes.bold ?: true, lbl)
                            }
                            // ✅ v16: হাইলাইট = লেখার পেছনে আলাদা ১:১ রাউন্ডেড-স্কয়ার বিটম্যাপ। বাহুর মাপ =
                            // ঘরের (লেখাসহ) উচ্চতা, তাই ডান-বাম থেকে চেপে স্কয়ার হয়; লেখা একচুলও নড়ে না।
                            val h = cfg.highlight
                            val hlId = hlIdFor(rowId)
                            val side = prayerSidePx.coerceAtLeast(dpPx(8f))
                            // ✅ v20: উচ্চতা অপরিবর্তিত (= side), শুধু প্রস্থ সামান্য বাড়ে — তবে এক ঘরের প্রস্থ
                            // (কার্ডের ভেতরের প্রস্থ ÷ দৃশ্যমান ঘর) বিয়োগ সামান্য ফাঁকার বেশি নয়, যাতে পাশের ঘরে না ঢোকে
                            val visibleCells = listOf(cfg.prayerRows.fajr, cfg.prayerRows.dhuhr, cfg.prayerRows.asr,
                                cfg.prayerRows.maghrib, cfg.prayerRows.isha).count { it }.coerceAtLeast(1)
                            val cellMaxW = if (innerWidthPx > 0) innerWidthPx / visibleCells - dpPx(HL_WIDTH_MARGIN_DP) else Int.MAX_VALUE
                            val wantedW = (side * h.widthScale.coerceIn(1f, 1.6f)).toInt()
                            val hlWidth = wantedW.coerceAtMost(maxOf(cellMaxW, side)).coerceAtLeast(side)
                            val hlBmp = buildHighlightBox(
                                hlWidth, side, dpPx(h.cornerRadiusDp).toFloat(),
                                resolveColor(
                                    if (lightUi) h.colorLightHex else h.colorHex,
                                    context.getColor(if (lightUi) R.color.widget_highlight_light else R.color.widget_highlight_dark)
                                )
                            )
                            if (hlId != -1 && hlBmp != null) {
                                highlightShown = true
                                views.setImageViewBitmap(hlId, hlBmp)
                                views.setViewVisibility(hlId, View.VISIBLE)
                                // (শুধু বক্সের ব্যাকগ্রাউন্ডেই প্রভাব — Android ১২+ এ; লেখা অক্ষত)
                                if (h.translateXDp != 0f) safeSetFloat(views, hlId, "setTranslationX", h.translateXDp * density)
                                if (h.translateYDp != 0f) safeSetFloat(views, hlId, "setTranslationY", h.translateYDp * density)
                                val hsx = h.scale * (h.scaleX ?: 1f)
                                val hsy = h.scale * (h.scaleY ?: 1f)
                                if (hsx != 1f) safeSetFloat(views, hlId, "setScaleX", hsx)
                                if (hsy != 1f) safeSetFloat(views, hlId, "setScaleY", hsy)
                                if (h.elevationDp != 0f) safeSetFloat(views, hlId, "setElevation", h.elevationDp * density)
                            }
                        }

                        views.setViewVisibility(R.id.countdown_warning_icon, if (waqtState.isForbidden) View.VISIBLE else View.GONE)
                        val countdownBaseColor = when {
                            waqtState.isForbidden -> COLOR_RED
                            lightUi -> 0xFF070D19.toInt()
                            else -> COLOR_AMBER
                        }
                        // ✅ v16: JSON-এ color / color_light_theme / color_forbidden — তিনটাই বাস্তব রঙ
                        val countdownColor = countdownStyleColor(tx.countdownLabel, waqtState.isForbidden, countdownBaseColor)
                        val cdLabelStyle = plainColor(tx.countdownLabel)
                        // ✅ v14: চলমান কাউন্টডাউন সংখ্যার (Chronometer) রঙ — config-এ colorHex দিলে সেটাই,
                        // না দিলে আগের মতো থিম/অবস্থা-নির্ভর রঙ। (size/visible নিচে ফাংশনের শেষে প্রয়োগ হয়)
                        safeSetTextColor(views, R.id.widget_countdown_chrono, countdownStyleColor(tx.countdownChrono, waqtState.isForbidden, countdownBaseColor))

                        val firstHalf = waqtState.now < (waqtState.phaseStartMillis + waqtState.phaseEndMillis) / 2
                        // ✅ FIX #21 (v8): নিচে যে চারটা ব্রাঞ্চ আছে তার মধ্যে শুধু "isGap" আর "else"-এ
                        // দেখানোর মতো কোনো টেক্সট থাকে না (উদাহরণ: সূর্যোদয়ের পর থেকে দুপুরের নিষিদ্ধ
                        // সময় শুরুর আগে পর্যন্ত) — তখন পুরো row_countdown সারিটাই GONE করে দেওয়া হয়
                        // (শুধু চাইল্ড ভিউ খালি রাখলে সারির মার্জিন/গ্র্যাভিটির কারণে ফাঁকা জায়গা থেকেই
                        // যেত)। বাকি দুই ব্রাঞ্চে (isForbidden, active!=null) আসল টেক্সট থাকে, তাই
                        // সারিটা আবার স্বয়ংক্রিয়ভাবে VISIBLE করে দেওয়া হয় — আগের মতোই স্বাভাবিক সাইজে।
                        when {
                            waqtState.isForbidden -> {
                                setCountdownRow(true)
                                setCountdownLabelFit(
                                    if (firstHalf) "নিষিদ্ধ সময় চলছে:" else "নিষিদ্ধ সময় শেষ হতে বাকি:", cdLabelStyle, countdownColor, 78f)
                                startCountdown(views, waqtState.phaseStartMillis, waqtState.phaseEndMillis, waqtState.now)
                            }
                            waqtState.isGap -> {
                                stopCountdown(views)
                                setBn(context, views, R.id.widget_countdown_label, "", tx.countdownLabel.sizeSp ?: 13f, countdownColor, true)
                                setCountdownRow(false)
                            }
                            waqtState.active != null -> {
                                setCountdownRow(true)
                                val waqtName = waqtLabel(waqtState.active, isJumma, lbl)
                                setCountdownLabelFit(
                                    if (firstHalf) "$waqtName-এর সময় অতিবাহিত:" else "$waqtName শেষ হতে বাকি:", cdLabelStyle, countdownColor, 62f)
                                startCountdown(views, waqtState.phaseStartMillis, waqtState.phaseEndMillis, waqtState.now)
                            }
                            else -> {
                                stopCountdown(views)
                                setBn(context, views, R.id.widget_countdown_label, "", tx.countdownLabel.sizeSp ?: 13f, countdownColor, true)
                                setCountdownRow(false)
                            }
                        }
                    } catch (_: Exception) {
                        stopCountdown(views)
                        setBnStyled(context, views, R.id.widget_countdown_label, "ডেটা লোড করতে সমস্যা হয়েছে", plainColor(tx.countdownLabel), 13f, COLOR_AMBER, true)
                        views.setViewVisibility(R.id.countdown_warning_icon, View.GONE)
                        // ✅ FIX #21 (v8): ত্রুটির বার্তাও আসল টেক্সট, তাই সারিটা দৃশ্যমান রাখা হলো
                        setCountdownRow(true)
                    }
                }

                val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                if (launchIntent != null) {
                    val pi = PendingIntent.getActivity(context, 0, launchIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    views.setOnClickPendingIntent(R.id.widget_root, pi)
                }

                // ✅ v12: sehri_pill/iftar_pill/weather_pill-এর জন্য config-এর "visible: false"
                // সবার শেষে প্রয়োগ করা হয় — উপরের showSehriIftar/showWeather-এর সব লজিক চলে যাওয়ার
                // পর, যাতে ইউজার এই বক্সগুলো ইচ্ছা করলে সম্পূর্ণ হাইড করতে পারেন (config "visible:
                // true", অর্থাৎ ডিফল্ট, দিলে বিদ্যমান লজিক অক্ষত/অপরিবর্তিত থাকে)।
                // ঘড়ি-পিলের visibility উপরে showClock সেটিং দিয়ে আবার সেট হয়ে যায় — তাই এই চারটা
                // বক্সের "visible: false"-ও এখানে শেষবার প্রয়োগ করা হচ্ছে, যাতে কনফিগই শেষ কথা হয়।
                if (!cfg.boxes.mainCard.visible) views.setViewVisibility(R.id.widget_root, View.GONE)
                if (!cfg.boxes.logoFrame.visible) views.setViewVisibility(R.id.logo_frame, View.GONE)
                if (!cfg.boxes.clockPill.visible) views.setViewVisibility(R.id.clock_pill, View.GONE)
                if (!cfg.boxes.celestialPill.visible) views.setViewVisibility(R.id.celestial_pill, View.GONE)
                if (!cfg.boxes.sehriPill.visible) views.setViewVisibility(R.id.sehri_pill, View.GONE)
                if (!cfg.boxes.iftarPill.visible) views.setViewVisibility(R.id.iftar_pill, View.GONE)
                if (!cfg.boxes.weatherPill.visible) views.setViewVisibility(R.id.weather_pill, View.GONE)

                // ✅ v14: নেটিভ (বিটম্যাপ নয়) এলিমেন্টগুলোর কনফিগ — ঘড়ির সময়/সেকেন্ড/AM-PM, চলমান
                // কাউন্টডাউন সংখ্যা, সতর্কতা আইকন। এগুলো RemoteViews-এর সাধারণ setter দিয়ে প্রয়োগ হয়।
                // (বোল্ড এখানে কনফিগযোগ্য না — RemoteViews-এ নেটিভ TextView-র টাইপফেস পাল্টানোর সহজ
                // API নেই, তাই এগুলোর বোল্ড XML-এর মতোই স্থির থাকে।)
                fun applyNativeText(viewId: Int, style: WidgetStyleConfig.TextStyle) {
                    if (!style.visible) { views.setViewVisibility(viewId, View.GONE); return }
                    style.sizeSp?.let { safeSetTextViewTextSize(views, viewId, TypedValue.COMPLEX_UNIT_SP, it * uiScale) }
                    if (style.colorHex != null) {
                        val c = styleColor(style, 0)
                        if (c != 0) safeSetTextColor(views, viewId, c)
                    }
                    style.letterSpacingEm?.let { safeSetFloat(views, viewId, "setLetterSpacing", it) }
                }
                applyNativeText(R.id.widget_live_clock_main, tx.clockTime)
                applyNativeText(R.id.widget_live_clock_seconds, tx.clockSeconds)
                applyNativeText(R.id.widget_live_clock_ampm, tx.clockAmPm)
                if (!tx.countdownChrono.visible) views.setViewVisibility(R.id.widget_countdown_chrono, View.GONE)
                else {
                    safeSetTextViewTextSize(views, R.id.widget_countdown_chrono, TypedValue.COMPLEX_UNIT_SP, (tx.countdownChrono.sizeSp ?: 12f) * uiScale)
                    tx.countdownChrono.letterSpacingEm?.let { safeSetFloat(views, R.id.widget_countdown_chrono, "setLetterSpacing", it) }
                }
                if (!ic.countdownWarningIcon.visible) views.setViewVisibility(R.id.countdown_warning_icon, View.GONE)
                else if (ic.countdownWarningIcon.scale != 1f) {
                    safeSetFloat(views, R.id.countdown_warning_icon, "setScaleX", ic.countdownWarningIcon.scale)
                    safeSetFloat(views, R.id.countdown_warning_icon, "setScaleY", ic.countdownWarningIcon.scale)
                }

                // ✅ v16: কনফিগে countdown_row.visible=false থাকলে সেটাই শেষ কথা
                if (!cfg.rows.countdownRow.visible) setCountdownRow(false)

                // ✅ v17: চারদিকে সমান ফাঁকা + ছোট সাইজে রিসাইজ করলে কনটেন্ট কাটা পড়া রোধ।
                //  ১) উপর/ডান/বাম = edge_padding_dp (ডিফল্ট ১২dp)। নিচের ফাঁকা ভ্যারিয়েন্ট অনুযায়ী হিসাব হয় যাতে
                //     দৃশ্যমান লেখা/বক্সের নিচ থেকে কার্ডের কিনারা ঠিক উপরের ফাঁকার সমান দেখায়।
                //  ২) লঞ্চার যে উচ্চতা দিচ্ছে (availHeightDp) তাতে কনটেন্ট না ধরলে: আগে উপর-নিচের ফাঁকা সমানভাবে
                //     কমানো হয় (min_edge_padding_dp পর্যন্ত); তাতেও না ধরলে শুধু কাউন্টডাউন সারি লুকানো হয় —
                //     কোনো লেখা কখনো অর্ধেক কেটে বা ভেঙে দেখানো হয় না।
                val density2 = density
                val sideDp = if (prayerSidePx > 0) prayerSidePx / density2 else 46f
                // ✅ v20: আগে এখানে স্থির ধরে নেওয়া মাপ (৪৬/৪০/২১dp) ছিল। এখন আসলে আঁকা বিটম্যাপের উচ্চতা
                // থেকে প্রতিটা সারির প্রকৃত উচ্চতা হিসাব হয় (সারির মাঝের নতুন ফাঁকাসহ) — তাই লেখা বড়-ছোট হলেও
                // (স্কেল / ফোনের ফন্ট সাইজ) "জায়গা হবে কি না" হিসাব নির্ভুল থাকে এবং অকারণে কাউন্টডাউন লুকায় না।
                fun hDp(id: Int): Float = (bmpHeightPx[id] ?: 0) / density2
                val gapDp = lineGapExtraPx / density2
                val topTextDp = hDp(R.id.widget_date_arabic) + hDp(R.id.widget_date_others) + 1f +
                    (if (hDp(R.id.widget_date_others) > 0f) gapDp else 0f)
                val topPillDp = 8f + maxOf(24f, hDp(R.id.celestial_title) + hDp(R.id.celestial_time) + gapDp)
                val topBlockDp = if (cfg.rows.topRow.visible) maxOf(42f, topTextDp, topPillDp) + 6f else 0f
                val midShown = cfg.rows.clockWeatherRow.visible && (showClock || showWeather || showSehriIftar)
                val sehriTextDp = if (showSehriIftar) hDp(R.id.label_sehri_title) + hDp(R.id.widget_sehri_time) + gapDp else 0f
                val weatherTextDp = if (showWeather) hDp(R.id.label_weather_title) + hDp(R.id.widget_temp_value) + gapDp else 0f
                val clockTextDp = if (showClock) (tx.clockTime.sizeSp ?: 22f) * uiScale * 1.2f else 0f
                val midBlockDp = if (midShown) 8f + maxOf(maxOf(28f, sehriTextDp), maxOf(weatherTextDp, clockTextDp)) + 7f else 0f
                val prayersBlockDp = if (cfg.rows.prayersRow.visible) sideDp else 0f
                val countdownBlockDp = (if (hDp(R.id.widget_countdown_label) > 0f) maxOf(hDp(R.id.widget_countdown_label), 16f) else 16f) + 6f
                val fixedDp = topBlockDp + midBlockDp + prayersBlockDp
                // =====================================================================================
                // ✅ v22: সাইজ-মডেল — অন-করা অপশন (ঘড়ি / সাহরী-ইফতার / আবহাওয়া / কাউন্টডাউন / ওয়াক্ত) অনুযায়ী
                // কনটেন্ট কতটা চওড়া ও উঁচু লাগবে তা আঁকা বিটম্যাপের আসল মাপ থেকে হিসাব হয় (স্কেল s-এর ফাংশন)।
                // তারপর সবচেয়ে বড় s বের করা হয় যাতে (ক) লঞ্চারের দেওয়া প্রস্থে ও উচ্চতায় পুরোটা ধরে এবং
                // (খ) স্ক্রিন-ক্লাসের সীমা (classScaleCap) পেরোয় না। ফলে ছোট স্ক্রিনে হিজিবিজি আর বড় স্ক্রিনে
                // ফাঁকা — কোনোটাই হয় না, সব ফোনে একই ডিজাইন সমানুপাতে বসে।
                // =====================================================================================
                fun wDp(id: Int): Float = (bmpWidthPx[id] ?: 0) / density2
                val curScale = uiScale
                fun base(id: Int): Float = wDp(id) / curScale
                val hijriBase = maxOf(base(R.id.widget_date_arabic), base(R.id.widget_date_others))
                val celBase = maxOf(base(R.id.celestial_title), base(R.id.celestial_time))
                val sehriBase = maxOf(base(R.id.label_sehri_title), base(R.id.widget_sehri_time))
                val iftarBase = maxOf(base(R.id.label_iftar_title), base(R.id.widget_iftar_time))
                val weatherBase = maxOf(base(R.id.label_weather_title), base(R.id.widget_temp_value))
                val cdBase = base(R.id.widget_countdown_label)
                val sideBaseDp = sideDp / curScale
                val prayerRowIds = listOf(
                    cfg.prayerRows.fajr to R.id.row_fajr, cfg.prayerRows.dhuhr to R.id.row_dhuhr,
                    cfg.prayerRows.asr to R.id.row_asr, cfg.prayerRows.maghrib to R.id.row_maghrib,
                    cfg.prayerRows.isha to R.id.row_isha
                ).filter { it.first }.map { it.second }
                var maxCellBase = 0f
                for (r in prayerRowIds) maxCellBase = maxOf(maxCellBase, base(labelIdFor(r)), base(timeIdFor(r)))
                val is24 = android.text.format.DateFormat.is24HourFormat(context)
                val clkSp = tx.clockTime.sizeSp ?: 22f
                val secSp = tx.clockSeconds.sizeSp ?: 12f
                val apSp = tx.clockAmPm.sizeSp ?: 7f

                fun reqWidth(sc: Float): Float {
                    val top = if (cfg.rows.topRow.visible) 42f + 10f + hijriBase * sc + 10f + 36f + celBase * sc else 0f
                    var mid = 0f
                    var items = 0
                    if (showClock) {
                        // ঘড়ির তিন অংশ: XML-এর minWidth (৫৬/২২/১৮dp) বা স্কেল-করা লেখার আনুমানিক চওড়া — যেটা বেশি
                        mid += 12f + 28f + 3f + maxOf(56f, 2.3f * clkSp * sc) + maxOf(22f, 1.15f * secSp * sc) +
                            (if (is24) 0f else maxOf(18f, 1.6f * apSp * sc) + 2f)
                        items++
                    }
                    if (showSehriIftar) { mid += (36f + sehriBase * sc) + 6f + (36f + iftarBase * sc); items++ }
                    if (showWeather) { mid += 42f + weatherBase * sc; items++ }
                    if (items > 1) mid += 6f * (items - 1)
                    if (!midShown) mid = 0f
                    val pr = if (prayerRowIds.isNotEmpty() && cfg.rows.prayersRow.visible)
                        prayerRowIds.size * maxOf(maxCellBase * sc + 10f, sideBaseDp * sc * cfg.highlight.widthScale + 3f) else 0f
                    val cd = if (countdownShown) cdBase * sc + 70f else 0f
                    return 2f * edgeDp + maxOf(maxOf(top, mid), maxOf(pr, cd))
                }
                fun reqHeight(sc: Float): Float {
                    val k = sc / curScale
                    val top = if (cfg.rows.topRow.visible)
                        maxOf(42f, topTextDp * k, 8f + maxOf(24f, (hDp(R.id.celestial_title) + hDp(R.id.celestial_time)) * k + gapDp)) + 6f else 0f
                    val mid = if (midShown)
                        8f + maxOf(maxOf(28f, sehriTextDp * k), maxOf(weatherTextDp * k, clkSp * sc * 1.2f)) + 7f else 0f
                    val pr = prayersBlockDp * k
                    val cd = if (countdownShown) countdownBlockDp * k else 0f
                    return 2f * edgeDp + top + mid + pr + cd
                }

                if (availWidthDp > 0 && allowRetry) {
                    val sw = context.resources.configuration.smallestScreenWidthDp.let { if (it <= 0) 360 else it }
                    var target = classScaleCap(sw)
                    while (target > UI_SCALE_FLOOR_FIT &&
                        (reqWidth(target) > availWidthDp - 1f || (availHeightDp > 0 && reqHeight(target) > availHeightDp.toFloat()))
                    ) target -= 0.01f
                    target = target.coerceAtLeast(UI_SCALE_FLOOR_FIT)
                    // রেফারেন্স স্কেলের (১.০) সাথে প্রায় একই হলে আবার আঁকার দরকার নেই — এই ধাপের ফলই পাঠানো হবে
                    if (kotlin.math.abs(target - curScale) > 0.02f) return target
                }

                // কার্ডের প্রস্থ: লঞ্চারের ফ্রেম কনটেন্টের চেয়ে অনেক বেশি চওড়া হলে (ট্যাবলেট/বড় ফোল্ডেবল/স্কেল-সীমা)
                // কার্ড কনটেন্টের মাপে সরু হয়ে মাঝখানে বসে — যাতে ব্যাকগ্রাউন্ডে অযথা ফাঁকা না থাকে।
                var framePadPx = 0
                if (availWidthDp > 0) {
                    val cardW = reqWidth(uiScale) * 1.10f
                    if (availWidthDp > cardW * 1.15f && availWidthDp > cardW + 24f) framePadPx = dpPx((availWidthDp - cardW) / 2f)
                }
                safeSetViewPadding(views, R.id.widget_frame, framePadPx, 0, framePadPx, 0)

                var edgeUsedDp = edgeDp
                if (availHeightDp > 0) {
                    fun needDp(e: Float, cd: Float) = 2f * e + fixedDp + cd
                    val cdNow = if (countdownShown) countdownBlockDp else 0f
                    if (needDp(edgeDp, cdNow) > availHeightDp) {
                        val shrunk = (edgeDp - (needDp(edgeDp, cdNow) - availHeightDp) / 2f).coerceAtLeast(cfg.layout.minEdgePaddingDp)
                        edgeUsedDp = shrunk
                        if (needDp(shrunk, cdNow) > availHeightDp + 0.5f && countdownShown) {
                            setCountdownRow(false)
                            val over = needDp(edgeDp, 0f) - availHeightDp
                            edgeUsedDp = if (over > 0f) (edgeDp - over / 2f).coerceAtLeast(cfg.layout.minEdgePaddingDp) else edgeDp
                        }
                    }
                }
                val edgePx = dpPx(edgeUsedDp)
                val sidePadPx = dpPx(edgeDp)
                val lastIsPrayers = !countdownShown && prayersBlockDp > 0f
                val bottomBasePx = if (lastIsPrayers && !highlightShown) (edgePx - prayerBottomInsetPx).coerceAtLeast(0) else edgePx
                val bottomPx = (bottomBasePx + dpPx(cfg.layout.bottomExtraDp)).coerceAtLeast(0)
                safeSetViewPadding(views, R.id.widget_root, sidePadPx, edgePx, sidePadPx, bottomPx)

                mgr.updateAppWidget(widgetId, views)
                return null
            } catch (t: Throwable) {
                // ✅ Device-specific RemoteViews reflection or inflation failure fallback:
                // Ensures widget NEVER shows "Problem loading widget" on any mobile device.
                try {
                    val fallbackViews = RemoteViews(context.packageName, R.layout.widget_prayer_times)
                    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                    if (launchIntent != null) {
                        val pi = PendingIntent.getActivity(context, 0, launchIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                        fallbackViews.setOnClickPendingIntent(R.id.widget_root, pi)
                    }
                    mgr.updateAppWidget(widgetId, fallbackViews)
                } catch (_: Throwable) {}
            }
            return null
        }

        // ✅ FIX #4: phase end-এ countdown negative হওয়া বন্ধ করা।
        // phaseEndMillis পেরিয়ে গেলে বা ইতোমধ্যে পেরিয়ে গেলে stopCountdown।
        private fun startCountdown(views: RemoteViews, phaseStartMillis: Long, phaseEndMillis: Long, nowMillis: Long) {
            val midpoint = (phaseStartMillis + phaseEndMillis) / 2
            val isFirstHalf = nowMillis < midpoint
            val wallTarget = if (isFirstHalf) phaseStartMillis else phaseEndMillis

            // ফেজ শেষ হয়ে গেলে countdown দেখাবো না (মাইনাস এড়াতে)
            if (!isFirstHalf && nowMillis >= wallTarget) {
                stopCountdown(views)
                return
            }

            // প্রথমার্ধে যদি phase start ইতোমধ্যে অতীতে (counting up), valid check
            val elapsedBase = SystemClock.elapsedRealtime() + (wallTarget - System.currentTimeMillis())
            views.setChronometerCountDown(R.id.widget_countdown_chrono, !isFirstHalf)
            views.setChronometer(R.id.widget_countdown_chrono, elapsedBase, null, true)
            views.setViewVisibility(R.id.widget_countdown_chrono, View.VISIBLE)
        }

        private fun stopCountdown(views: RemoteViews) {
            views.setChronometer(R.id.widget_countdown_chrono, SystemClock.elapsedRealtime(), null, false)
            views.setViewVisibility(R.id.widget_countdown_chrono, View.GONE)
        }

        // ✅ v20: কাস্টম থিমের ব্যাকগ্রাউন্ড — সাদা রাউন্ডেড শেপে রঙ (setColorFilter) ও স্বচ্ছতা (setImageAlpha)।
        // দুটোই RemoteViews-এ সব Android ভার্সনে অনুমোদিত (ImageView-র @RemotableViewMethod)।
        private fun applyCustomBackground(views: RemoteViews, show: Boolean, color: Int, opacityPct: Int) {
            try {
                if (show) {
                    views.setViewVisibility(R.id.widget_bg_custom, View.VISIBLE)
                    safeSetInt(views, R.id.widget_bg_custom, "setColorFilter", color)
                    safeSetInt(views, R.id.widget_bg_custom, "setImageAlpha", (opacityPct.coerceIn(0, 100) * 255 + 50) / 100)
                } else {
                    views.setViewVisibility(R.id.widget_bg_custom, View.GONE)
                }
            } catch (_: Throwable) {}
        }

        private fun applyTheme(views: RemoteViews, theme: String) {
            when (theme) {
                // custom = ব্যাকগ্রাউন্ড আলাদা লেয়ারে (applyCustomBackground), তাই মূল কার্ড স্বচ্ছ; টেক্সট টোন lightUi থেকে আসে
                "custom" -> { views.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.widget_background_nobg); setTextTone(views, true) }
                // nobg = ট্রান্সপারেন্ট-ডার্ক (সাদা লেখা), nobg_light = ট্রান্সপারেন্ট-লাইট (গাঢ় লেখা) — দুটোতেই ব্যাকগ্রাউন্ড নেই
                "nobg" -> { views.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.widget_background_nobg); setTextTone(views, true) }
                "nobg_light" -> { views.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.widget_background_nobg); setTextTone(views, false) }
                "light" -> { views.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.widget_background_light); setTextTone(views, false) }
                else -> { views.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.widget_background_glass); setTextTone(views, true) }
            }
        }

        private fun setTextTone(views: RemoteViews, lightText: Boolean) {
            // v6 NEW: celestial_time, widget_sehri_time, widget_iftar_time, widget_temp_value,
            // time_fajr..isha are all ImageView bitmaps now (Bengali-digit Kothamala) —
            // their color is baked into the bitmap directly at content-set time inside
            // updateWidget() (see setBn() calls there), so setTextColor() no longer applies
            // to any of them and has been removed from this function.
        }

        // ✅ FIX #10 + v6 NEW: label_fajr..isha AND time_fajr..isha are both ImageView bitmaps
        // now (Bengali-digit Kothamala for the times) — highlighting a row means
        // re-rendering BOTH bitmaps in the new color, not just calling setTextColor().
        private fun setRowTextDark(
            context: Context, views: RemoteViews, rowId: Int, isJumma: Boolean,
            timeDisplayText: String, timeSizeSp: Float = 16f, nameSizeSp: Float = 13.5f, timeBold: Boolean = true,
            labels: WidgetStyleConfig.Labels = WidgetStyleConfig.Labels()
        ) {
            setRowLabelBitmap(context, views, rowId, isJumma, COLOR_TEXT_DARK, nameSizeSp, labels)
            timeIdFor(rowId).takeIf { it != -1 }?.let { setBn(context, views, it, timeDisplayText, timeSizeSp, COLOR_TEXT_DARK, bold = timeBold) }
        }

        private fun setRowTextWhite(
            context: Context, views: RemoteViews, rowId: Int, isJumma: Boolean,
            timeDisplayText: String, timeSizeSp: Float = 16f, nameSizeSp: Float = 13.5f, timeBold: Boolean = true,
            labels: WidgetStyleConfig.Labels = WidgetStyleConfig.Labels()
        ) {
            setRowLabelBitmap(context, views, rowId, isJumma, COLOR_WHITE, nameSizeSp, labels)
            timeIdFor(rowId).takeIf { it != -1 }?.let { setBn(context, views, it, timeDisplayText, timeSizeSp, COLOR_WHITE, bold = timeBold) }
        }

        private fun setRowLabelBitmap(
            context: Context, views: RemoteViews, rowId: Int, isJumma: Boolean, colorInt: Int,
            nameSizeSp: Float = 13.5f, labels: WidgetStyleConfig.Labels = WidgetStyleConfig.Labels()
        ) {
            val (labelId, text) = when (rowId) {
                R.id.row_fajr -> R.id.label_fajr to (labels.fajr)
                R.id.row_dhuhr -> R.id.label_dhuhr to (if (isJumma) (labels.jumma) else (labels.dhuhr))
                R.id.row_asr -> R.id.label_asr to (labels.asr)
                R.id.row_maghrib -> R.id.label_maghrib to (labels.maghrib)
                R.id.row_isha -> R.id.label_isha to (labels.isha)
                else -> return
            }
            // ✅ FIX: ডিফল্ট (non-active) লেবেলের সাইজের সাথে মিলিয়ে রাখা হলো (config থেকে আসে),
            // নাহলে ওয়াক্ত active হওয়ার সময় লেবেলের সাইজ হঠাৎ বদলে যেত।
            setBn(context, views, labelId, text, nameSizeSp, colorInt)
        }

        private fun timeIdFor(rowId: Int) = when (rowId) {
            R.id.row_fajr -> R.id.time_fajr
            R.id.row_dhuhr -> R.id.time_dhuhr
            R.id.row_asr -> R.id.time_asr
            R.id.row_maghrib -> R.id.time_maghrib
            R.id.row_isha -> R.id.time_isha
            else -> -1
        }

        private fun resetHighlights(views: RemoteViews) {
            listOf(R.id.hl_fajr, R.id.hl_dhuhr, R.id.hl_asr, R.id.hl_maghrib, R.id.hl_isha).forEach {
                views.setViewVisibility(it, View.GONE)
            }
        }

        private fun hlIdFor(rowId: Int) = when (rowId) {
            R.id.row_fajr -> R.id.hl_fajr
            R.id.row_dhuhr -> R.id.hl_dhuhr
            R.id.row_asr -> R.id.hl_asr
            R.id.row_maghrib -> R.id.hl_maghrib
            R.id.row_isha -> R.id.hl_isha
            else -> -1
        }

        private fun labelIdFor(rowId: Int) = when (rowId) {
            R.id.row_fajr -> R.id.label_fajr
            R.id.row_dhuhr -> R.id.label_dhuhr
            R.id.row_asr -> R.id.label_asr
            R.id.row_maghrib -> R.id.label_maghrib
            R.id.row_isha -> R.id.label_isha
            else -> -1
        }

        // ✅ v16: side × side পিক্সেলের রাউন্ডেড-স্কয়ার (১:১) — শুধু ব্যাকগ্রাউন্ড শেপ, কোনো লেখা নেই
        // ✅ v20: widthPx ≥ heightPx — উচ্চতা আগের মতোই (ঘরের উচ্চতা), প্রস্থ সামান্য বেশি (width_scale)
        private fun buildHighlightBox(widthPx: Int, heightPx: Int, cornerPx: Float, color: Int): Bitmap? {
            return try {
                val bmp = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
                val r = cornerPx.coerceIn(0f, minOf(widthPx, heightPx) / 2f)
                Canvas(bmp).drawRoundRect(RectF(0f, 0f, widthPx.toFloat(), heightPx.toFloat()), r, r, paint)
                bmp
            } catch (_: Throwable) { null }
        }

        private fun waqtLabel(key: String, isJumma: Boolean, l: WidgetStyleConfig.Labels) = when (key) {
            "Fajr" -> l.fajr
            "Dhuhr" -> if (isJumma) (l.jumma) else (l.dhuhr)
            "Asr" -> l.asr
            "Maghrib" -> l.maghrib
            "Isha" -> l.isha
            else -> ""
        }

        private fun checkHaramRoza(hijriStr: String): String? {
            try {
                val parts = hijriStr.trim().split(" ")
                if (parts.size < 2) return null
                
                val day = FirebaseDataManager.convertBengaliToEnglish(parts[0]).toIntOrNull() ?: return null
                val monthName = parts[1]
                
                // ১ শাওয়াল (ঈদুল ফিতর)
                if (monthName.contains("শাওয়াল") && day == 1) return "আজ ঈদের দিন, রোজা রাখা হারাম"
                
                // জিলহজ মাসের ১০, ১১, ১২, ১৩ তারিখ
                if (monthName.contains("জিলহজ্জ") || monthName.contains("যিলহজ")) {
                    if (day == 10) return "আজ কোরবানির ঈদ, রোজা হারাম"
                    if (day in 11..13) return "আইয়ামে তাশরিক, রোজা হারাম"
                }
            } catch (_: Exception) {}
            return null
        }

        // ✅ FIX #12: ইংরেজি (গ্রেগরিয়ান) ও বাংলা মাসের নাম — index.html-এর
        // gregorianMonthsBN/banglaMonthsBN অ্যারের সাথে হুবহু মিলিয়ে রাখা হলো
        private val GREGORIAN_MONTHS_BN = arrayOf(
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        )
        private val BANGLA_MONTHS_BN = arrayOf(
            "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
            "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
        )

        /** আজকের গ্রেগরিয়ান তারিখ সরাসরি ডিভাইসের ক্যালেন্ডার থেকে হিসাব করে বাংলা মাসের নামসহ */
        private fun computeTodayGregorianStr(): String {
            val c = Calendar.getInstance()
            return "${c.get(Calendar.DAY_OF_MONTH)} ${GREGORIAN_MONTHS_BN[c.get(Calendar.MONTH)]} ${c.get(Calendar.YEAR)}"
        }

        /**
         * আজকের বাংলা (বঙ্গাব্দ) তারিখ সরাসরি ডিভাইসের ক্যালেন্ডার থেকে হিসাব করে — এটা
         * index.html-এর getBengaliCalendarCalculation() জাভাস্ক্রিপ্ট ফাংশনের হুবহু কোটলিন
         * সংস্করণ (পহেলা বৈশাখ = ১৪ এপ্রিল ধরে হিসাব করা হয়)
         */
        private fun computeTodayBanglaStr(): String {
            val now = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val gYear = now.get(Calendar.YEAR)
            val isLeap = (gYear % 4 == 0 && gYear % 100 != 0) || (gYear % 400 == 0)
            val daysInMonths = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (isLeap) 30 else 29, 30)

            var bYear = gYear - 593
            var poyla = Calendar.getInstance().apply {
                set(gYear, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }
            if (now.timeInMillis < poyla.timeInMillis) {
                bYear -= 1
                poyla = Calendar.getInstance().apply {
                    set(gYear - 1, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0)
                }
            }

            val diffDays = ((now.timeInMillis - poyla.timeInMillis) / 86400000L).toInt()
            var monthIdx = 0
            var bDay = diffDays + 1
            while (monthIdx < daysInMonths.size && bDay > daysInMonths[monthIdx]) {
                bDay -= daysInMonths[monthIdx]
                monthIdx++
            }
            if (monthIdx >= BANGLA_MONTHS_BN.size) monthIdx = BANGLA_MONTHS_BN.size - 1
            return "$bDay ${BANGLA_MONTHS_BN[monthIdx]} $bYear"
        }

        private fun todayIsFriday() = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
        private fun nowMinutesLocal(): Int { val c = Calendar.getInstance(); return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) }

        private fun parseToMinutes(hhmm: String): Int {
            return try { val p = hhmm.trim().split(" ")[0].split(":"); p[0].toInt() * 60 + p[1].toInt() } catch (_: Exception) { -1 }
        }

        private fun toTodayMillis(hhmm: String): Long {
            return try {
                val p = hhmm.trim().split(" ")[0].split(":")
                val c = Calendar.getInstance()
                c.set(Calendar.HOUR_OF_DAY, p[0].toInt()); c.set(Calendar.MINUTE, p[1].toInt())
                c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); c.timeInMillis
            } catch (_: Exception) { System.currentTimeMillis() }
        }

        private fun to12HourCompact(hhmm: String): String {
            return try {
                val p = hhmm.trim().split(" ")[0].split(":")
                var h = p[0].toInt(); val m = p[1]
                h = if (h % 12 == 0) 12 else h % 12
                String.format(Locale.ENGLISH, "%02d:%s", h, m)
            } catch (_: Exception) { hhmm }
        }

        data class WaqtState(val active: String?, val isGap: Boolean, val isForbidden: Boolean,
            val phaseStartMillis: Long, val phaseEndMillis: Long, val now: Long)

        private fun computeWaqtState(fajr: String, sunrise: String, dhuhr: String, asr: String, maghrib: String, isha: String, sunset: String): WaqtState {
            val now = System.currentTimeMillis(); val dayMs = 86400000L
            val f = toTodayMillis(fajr); val sr = toTodayMillis(sunrise); val d = toTodayMillis(dhuhr)
            val a = toTodayMillis(asr); val m = toTodayMillis(maghrib); val i = toTodayMillis(isha); val ss = toTodayMillis(sunset)

            // নিষিদ্ধ সময়: সূর্যোদয়+১৫ মিনিট, দুপুরের আগে ১২ মিনিট, সূর্যাস্তের আগে ১৫ মিনিট
            val forbiddenWindows = listOf(
                Triple(sr, sr + 900000L, "sunrise"),
                Triple(d - 720000L, d, "dhuhr"),
                Triple(ss - 900000L, ss, "sunset")
            )
            var isForbidden = false; var fStart = 0L; var fEnd = 0L
            for ((ws, we, _) in forbiddenWindows) {
                if (now in ws until we) { isForbidden = true; fStart = ws; fEnd = we; break }
            }

            var active: String? = null; var isGap = false; var pStart: Long; var pEnd: Long
            when {
                now in f until sr -> { active = "Fajr"; pStart = f; pEnd = sr }
                now in sr until d -> { isGap = true; pStart = sr; pEnd = d; active = null }
                now in d until a -> { active = "Dhuhr"; pStart = d; pEnd = a }
                now in a until m -> { active = "Asr"; pStart = a; pEnd = m }
                now in m until i -> { active = "Maghrib"; pStart = m; pEnd = i }
                else -> {
                    active = "Isha"
                    if (now >= i) { pStart = i; pEnd = f + dayMs } else { pStart = i - dayMs; pEnd = f }
                }
            }
            return if (isForbidden) WaqtState(active, isGap, true, fStart, fEnd, now)
            else WaqtState(active, isGap, false, pStart, pEnd, now)
        }
    }

    // ✅ v24: অ্যালার্ম (৮০-মিনিট / ওয়াক্ত / মাগরিব / মধ্যরাত / ফেজ-শেষ) ফায়ার হলে "হার্ড রিসেট"।
    // Android নিয়ম: onReceive মেইন থ্রেডে ও ~১০ সেকেন্ডের মধ্যে শেষ হতে হয়। তাই goAsync() + ব্যাকগ্রাউন্ড থ্রেড
    // (রেন্ডারে বিটম্যাপ-ফন্ট লাগে), কাজ শেষে finish()। নেটওয়ার্ক কল এখানে নয় — বাসি ডেটা হলে
    // WorkManager (CONNECTED শর্তে) পাঠানো হয় (দেখুন WidgetRefreshScheduler.hardReset)।
    // সবার আগে scheduleAll() (hardReset-এর প্রথম ধাপ) ⇒ রেন্ডার ব্যর্থ হলেও পরের অ্যালার্ম সেট থাকে।
    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)
        if (intent?.action == WidgetRefreshScheduler.REFRESH_ACTION) {
            val ctx = context?.applicationContext ?: return
            val pending = try { goAsync() } catch (_: Throwable) { null }
            val job = Runnable {
                try {
                    WidgetRefreshScheduler.hardReset(ctx)
                    try {
                        // নোটিফিকেশন সিস্টেমের স্বাধীন অতিরিক্ত নিরাপত্তা-স্তর (আগের মতোই)
                        com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(ctx)
                    } catch (_: Throwable) { /* উইজেট চেইনের সাথে সম্পর্কহীন */ }
                } catch (_: Throwable) {
                    // কোনো অবস্থাতেই এখান থেকে ক্র্যাশ নয়
                } finally {
                    try { pending?.finish() } catch (_: Throwable) {}
                }
            }
            if (pending != null) {
                try { Thread(job, "patheyo-widget-reset").start() } catch (_: Throwable) { job.run() }
            } else job.run()
        }
    }

    // ✅ FIX #NEW (v4): scheduleAll() এখন সবার আগে চলে (উপরের কমেন্ট দেখুন), এবং প্রতিটি
    // widget id-র updateWidget() আলাদাভাবে try-catch(Throwable) দিয়ে সুরক্ষিত — একটা
    // widget instance-এ সমস্যা হলে অন্য widget instance বা পরের রিফ্রেশ-সাইকেল নষ্ট হবে না।
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        try {
            // প্রথমবার বা নিয়মিত আপডেটে শিডিউল নিশ্চিত করা — সবার আগে, যাতে নিচের লুপে কিছু
            // ভুল হলেও পরবর্তী রিফ্রেশ অ্যালার্ম ইতোমধ্যে সেট হয়ে গেছে থাকে।
            WidgetRefreshScheduler.scheduleAll(context)
        } catch (t: Throwable) { /* পরের রেগুলার সাইকেলে ঠিক হয়ে যাবে */ }

        for (id in appWidgetIds) {
            try {
                updateWidget(context, appWidgetManager, id)
            } catch (t: Throwable) {
                // ✅ একটা widget instance রেন্ডার করতে ব্যর্থ হলেও (OOM, কর্প্ট ডেটা, ইত্যাদি)
                // বাকি widget instance ও পরবর্তী রিফ্রেশ-সাইকেল প্রভাবিত হবে না।
            }
        }
    }

    // ✅ v17: ইউজার উইজেট ছোট/বড় করলে সাথে সাথে নতুন সাইজ অনুযায়ী আবার সাজানো হয় (কাউন্টডাউন কাটা
    // পড়া রোধের জন্য — দেখুন updateWidget-এর শেষের অংশ)
    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        try {
            updateWidget(context, appWidgetManager, appWidgetId)
        } catch (_: Throwable) { /* পরের নিয়মিত রিফ্রেশে ঠিক হয়ে যাবে */ }
    }

    // ✅ v24: শেষ উইজেটটা সরালে অ্যালার্মও বাতিল (অকারণ ওয়েকআপ নয়)
    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        try { WidgetRefreshScheduler.cancelAll(context) } catch (_: Throwable) {}
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        // উইজেট প্রথমবার যোগ হলে সব schedule সেট করো
        try {
            WidgetRefreshScheduler.scheduleAll(context)
        } catch (t: Throwable) { /* নিরাপদ ফলব্যাক: পরের নিয়মিত সাইকেলে ঠিক হয়ে যাবে */ }
    }
}
