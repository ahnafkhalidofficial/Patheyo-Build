# v48 — আজান পপআপ: নির্ভরযোগ্যতা, সাউন্ড বন্ধ, গোল লোগো, নতুন বাটন

নতুন ফাইল: alarm/AzanLogo.kt, alarm/AzanChannel.kt, alarm/AzanActionReceiver.kt
বদলানো: AzanForegroundService, AzanOverlayActivity, AlarmReliability, ui/AlarmPermissionDialog, AndroidManifest,
        res/values (azan_popup_colors, alarm_permission_strings), res/layout (activity_azan_overlay, notification_alarm, notification_azan_headsup),
        res/drawable (bg_azan_btn_stop/snooze, bg_azan_notif_btn_red/gray)

- বাটন (বন্ধ/স্নুজ) চাপলে সাউন্ড সাথে সাথে বন্ধ; নোটিফিকেশনের বাটন এখন BroadcastReceiver দিয়ে।
- ভলিউম বাটন চাপলে শুধু সাউন্ড বন্ধ, পপআপ ও রিপিট থাকে (৫ মিনিট পর সার্ভিস নিজে থামে)।
- অ্যান্ড্রয়েড ১১-: কাস্টম পপআপ; ১২+: সিস্টেম ডিফল্ট (গোল লোগো + দুই বাটন)।
- লোগো সব জায়গায় নেভি-ব্লু গোল ভিত্তির ভেতরে, স্বচ্ছ-ব্যাকগ্রাউন্ড PNG (widget_logo.png) দিয়ে — লোগোর চৌকো ব্যাকগ্রাউন্ড নেই (কোডে আঁকা Bitmap)।
- নতুন চ্যানেল azan_alarm_channel_v2 (পুরনোটা মোছে)।
- নতুন পারমিশন-পপআপ ধাপ: NOTIF_POPUP, OEM_POPUP (লক স্ক্রিনে দেখানো / ব্যাকগ্রাউন্ড পপআপ)।
- নোটিফিকেশন (অ্যান্ড্রয়েড ১১-) নতুন প্রিমিয়াম ডিজাইন: গভীর নেভি কার্ড (কোণা ছাড়া — সাদা ফালি বেরোত), প্রধান রোজ বাটন + গৌণ সোনালি-টোনাল স্নুজ বাটন, চিকন লোগো-রিং।
