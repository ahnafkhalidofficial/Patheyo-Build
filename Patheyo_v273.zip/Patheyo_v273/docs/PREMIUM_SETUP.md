# পাথেয় প্রিমিয়াম — চালু করার নির্দেশনা (ধাপ ১০)

প্রিমিয়ামের ডিজাইন, অ্যাপের কোড আর পেমেন্ট-যাচাইয়ের সার্ভার সব তৈরি আছে।

**এখন অ্যাপে যা দেখায়:** পেওয়ালে "শীঘ্রই চালু হচ্ছে"। কাউকে টাকা দিতে হয় না, আর অ্যাপের কিছু ভাঙে না।

**চালু করতে যা লাগবে:**
1. গেটওয়ের মার্চেন্ট অ্যাকাউন্ট
2. সার্ভার চালানো
3. অ্যাপে একটা লাইন বদলানো

---

## দাম ও প্ল্যান
| প্ল্যান | দাম | মেয়াদ |
|---|---|---|
| মাসিক | ৳৪৯ | ৩০ দিন |
| বার্ষিক | ৳৩৯৯ | ৩৬৫ দিন (মাসে প্রায় ৳৩৩, ৩২% সাশ্রয়) |
| আজীবন | ৳৯৯৯ | সারাজীবন |

দাম তিন জায়গায় লেখা আছে। কখনো বদলালে তিন জায়গাতেই একসাথে বদলাতে হবে:
- `server/payments/plans.js` (আসল দাম এখান থেকেই নেওয়া হয়)
- `index.html`-এর পেওয়াল
- `PremiumBridge.config()`

- মেয়াদ থাকতে নবায়ন করলে বাকি দিনগুলো নতুন মেয়াদের সাথে যোগ হয়।
- গেটওয়ে নিজে থেকে টাকা কাটে না। মেয়াদ শেষের ৫ দিন আগে থেকে অ্যাপ দিনে একবার মনে করিয়ে দেয়।

**প্রিমিয়ামে যা পাওয়া যায়:**
- **এখন চালু:** বিজ্ঞাপন একদম বন্ধ (হোমের স্লাইডার, ব্যানার আর পপআপ), আর "সদকায়ে জারিয়ার অংশীদার" হওয়া।
- **শীঘ্রই আসবে:** প্রিমিয়াম থিম, আরও ক্বারি ও আজানের কণ্ঠ, আমলের বার্ষিক রিপোর্ট। পেওয়ালে এগুলোর পাশে সৎভাবে "শীঘ্রই" লেখা আছে।
- **সবসময় ফ্রি:** কুরআন, হাদিস, নামাজ, দোয়া, তাসবিহ, কিবলা, আমল আর ক্লাউড ব্যাকআপ। এগুলো কখনো প্রিমিয়ামের পেছনে যাবে না।

---

## ⭐ এখনকার পথ: SSLCommerz স্যান্ডবক্স + Vercel (সম্পূর্ণ ফ্রি, কার্ড লাগে না)
মালিকের স্যান্ডবক্স স্টোর: **Store ID `pathe6aed944cb9c76`** (স্টোর-পাসওয়ার্ড শুধু Vercel-এর গোপন সেটিংসে থাকবে, কোডে নয়)।
আমাদের SSLCommerz কোড আসল স্যান্ডবক্স API-তে পরীক্ষা করা হয়েছে (সেশন তৈরি ✓, ভুয়া val_id বাতিল ✓)।

| কাজ | কোথায় | খরচ |
|---|---|---|
| সাইন-ইন + প্রিমিয়ামের তথ্য | Firebase (Spark — এখন যেটা আছে) | ফ্রি |
| পেমেন্ট যাচাইয়ের সার্ভার | **Vercel** (Hobby) | ফ্রি, কার্ড লাগে না |
| পেমেন্ট | SSLCommerz স্যান্ডবক্স | ফ্রি (নকল টাকা) |

**ধাপ ক — Firebase থেকে সার্ভারের চাবি:** Firebase Console → ⚙️ Project settings → **Service accounts** → **Generate new private key** → একটা `.json` ফাইল নামবে। (গোপন — কাউকে দেবেন না, GitHub-এ দেবেন না।)

**ধাপ খ — Vercel-এ সার্ভার:**
1. vercel.com → **Sign Up → Continue with GitHub** (Hobby/ফ্রি)।
2. **Add New → Project** → আপনার পাথেয়-র GitHub রিপো → **Import**।
3. **Root Directory** = `server/payments` (Edit চেপে বেছে নিন)। Framework = Other।
4. **Environment Variables**-এ এগুলো যোগ করুন:
   | Name | Value |
   |---|---|
   | `GATEWAY` | `sslcommerz` |
   | `SANDBOX` | `true` |
   | `SSLC_STORE_ID` | `pathe6aed944cb9c76` |
   | `SSLC_STORE_PASSWD` | SSLCommerz ড্যাশবোর্ডের স্টোর পাসওয়ার্ড (ইমেইলে এসেছে / "regenerate") |
   | `RTDB_URL` | `https://hijri-tarikh-default-rtdb.firebaseio.com` |
   | `APP_PACKAGE` | `com.gunjoron.patheyo` |
   | `FIREBASE_SERVICE_ACCOUNT` | ধাপ ক-এর `.json` ফাইল নোটপ্যাডে খুলে **পুরো লেখা** পেস্ট |
   | `PUBLIC_URL` | এখন ফাঁকা রাখুন (৬ নম্বরে বসাবেন) |
5. **Deploy** → শেষে একটা ঠিকানা পাবেন, যেমন `https://patheyo-pay.vercel.app`। ব্রাউজারে খুললে লেখা আসবে *Patheyo payments — sslcommerz (sandbox)*।
6. **Settings → Environment Variables** → `PUBLIC_URL` = সেই ঠিকানা (শেষে `/` ছাড়া) → **Deployments → Redeploy**।

**ধাপ গ — SSLCommerz-এ IPN:** স্যান্ডবক্স ড্যাশবোর্ড → Stores → Settings → **IPN URL** = `https://<আপনার-ঠিকানা>.vercel.app/ipn` (অপশন না থাকলে বাদ — সার্ভার নিজেই IPN ঠিকানা পাঠায়)।

**ধাপ ঘ — অ্যাপে ঠিকানা:** `app/build.gradle.kts`-এ
`buildConfigField("String", "PAY_API_URL", "\"https://<আপনার-ঠিকানা>.vercel.app\"")` → বিল্ড → ফোনে ইনস্টল।

**ধাপ ঙ — পরীক্ষা:** সাইন-ইন → সেটিংস → পাথেয় প্রিমিয়াম → প্ল্যান → কেনার বোতাম → SSLCommerz-এর পরীক্ষার পেজে যেকোনো মাধ্যম (যেমন টেস্ট কার্ড/মোবাইল ব্যাংকিং — পেজেই পরীক্ষার তথ্য লেখা থাকে) → "পাথেয় অ্যাপে ফিরুন" → অ্যাপে "প্রিমিয়াম চালু হয়েছে", বিজ্ঞাপন উধাও। Firebase → Realtime Database → `users/<uid>/premium` ও `orders`-এ দেখা যাবে।

> Supabase লাগবে না: অ্যাকাউন্ট ও ডেটা Firebase-এর ফ্রি প্ল্যানেই থাকে; শুধু ছোট সার্ভারটা Vercel-এ (ফ্রি)। Firebase Functions-এর জন্যই কার্ড লাগত — সেটা আর দরকার নেই।

---

## ১) গেটওয়ে বাছাই (যেকোনো একটা)
| গেটওয়ে | কী কী দিয়ে পেমেন্ট | কী লাগে |
|---|---|---|
| **SSLCommerz** (প্রস্তাবিত) | bKash, Nagad, রকেট, কার্ড, ইন্টারনেট ব্যাংকিং | ট্রেড লাইসেন্স, ব্যাংক অ্যাকাউন্ট। স্যান্ডবক্স অ্যাকাউন্ট সাথে সাথে পাওয়া যায় (developer.sslcommerz.com) |
| **bKash PGW** | শুধু bKash | bKash মার্চেন্ট অ্যাকাউন্ট + PGW অনুমোদন |
| **ShurjoPay** | bKash, Nagad, রকেট, কার্ড | ট্রেড লাইসেন্স, ব্যাংক অ্যাকাউন্ট |

- এক জায়গায় সব পেমেন্ট মাধ্যম চাইলে SSLCommerz বা ShurjoPay সবচেয়ে সহজ।
- স্যান্ডবক্সের (পরীক্ষার) চাবি পেলেই পুরো পথ পরীক্ষা করা যায়।

## ২) সার্ভার চালানো (`server/payments/`)
সার্ভারের কাজগুলো:
- পেমেন্ট শুরু করা।
- গেটওয়ের কাছে যাচাই করা যে টাকা সত্যিই এসেছে আর পরিমাণ ঠিক আছে।
- অ্যাকাউন্টে প্রিমিয়াম চালু করা (`users/{uid}/premium`)।

চালানোর দুটো উপায়, যেকোনো একটা বেছে নিন:

**ক) Firebase Cloud Functions**
- Firebase প্রজেক্টকে **Blaze** প্ল্যানে নিতে হয়। এতে কার্ড লাগে, তবে মাসে ২০ লাখ অনুরোধ পর্যন্ত ফ্রি।
- কমান্ডগুলো:
```
npm install -g firebase-tools
firebase login
cd server/payments && npm install
firebase init functions      (existing project → hijri-tarikh, ফোল্ডার = server/payments)
cp .env.example .env         (তারপর .env-এ চাবি বসান)
firebase deploy --only functions
```
- ঠিকানা হবে `https://asia-south1-hijri-tarikh.cloudfunctions.net/pay`।

**খ) যেকোনো Node হোস্ট (Render, Railway, নিজের VPS)**
- কার্ড ছাড়াও সম্ভব।
- কমান্ড: `npm install`, তারপর `node --env-file=.env server.js`।
- Firebase Console থেকে একটা ফাইল নামাতে হবে: **Project settings → Service accounts → Generate new private key**। সেই ফাইলের পথ `GOOGLE_APPLICATION_CREDENTIALS`-এ দিন।

**`.env`-এ যা দিতে হবে** (`.env.example` কপি করে বানান):
- `GATEWAY`
- `SANDBOX=true` (পরীক্ষা শেষ হলে `false`)
- `PUBLIC_URL` (উপরের সার্ভারের ঠিকানা)
- গেটওয়ের চাবিগুলো

⚠️ `.env` আর সার্ভিস অ্যাকাউন্টের ফাইল কখনো GitHub-এ দেবেন না। `server/payments/.gitignore` এগুলো আটকে রাখে।

**গেটওয়ের প্যানেলে যা বসাবেন:**
- SSLCommerz: success, fail ও cancel URL এই সার্ভার নিজেই পাঠায়, প্যানেলে বসাতে হয় না। শুধু **IPN URL** = `PUBLIC_URL/ipn` বসান।
- bKash আর ShurjoPay: ফেরার ঠিকানা সার্ভার নিজেই পাঠায়, আলাদা কিছু বসাতে হয় না।

## ৩) ডাটাবেস নিয়ম
`docs/ACCOUNT_SETUP.md`-এর নিয়মে `premium/.write = false` আগেই আছে। এর মানে অ্যাপ নিজে প্রিমিয়াম লিখতে পারে না।

সার্ভার যে তিনটা জায়গা ব্যবহার করে:
- `orders`
- `order_refs`
- `play_tokens`

এগুলোর জন্য কোনো নিয়ম দেবেন না। তাহলে অ্যাপ থেকে এগুলো পড়া বা লেখা যাবে না, শুধু সার্ভার পারবে। সার্ভার Admin হিসেবে চলে, তাই নিয়ম তাকে আটকায় না।

**সতর্কতা:** রুটে (একদম উপরের স্তরে) কখনো `".read": true` বা `".write": true` দেবেন না।

## ৪) অ্যাপে চালু করা
`app/build.gradle.kts`-এ একটা লাইন বদলাতে হবে:
```
buildConfigField("String", "PAY_API_URL", "\"https://asia-south1-hijri-tarikh.cloudfunctions.net/pay\"")
```
এরপর নতুন বিল্ড দিলেই পেওয়ালে কেনার বোতাম চালু হবে। পেমেন্ট শেষে ব্রাউজার থেকে অ্যাপে ফেরে এই ঠিকানা দিয়ে: `patheyo://pay?status=…`।

## ৫) পরীক্ষা (স্যান্ডবক্স)
1. অ্যাপে সাইন-ইন করুন। তারপর সেটিংস থেকে প্রিমিয়ামে যান, প্ল্যান বাছুন, আর কেনার বোতাম চাপুন।
2. ব্রাউজারে গেটওয়ের পরীক্ষার পেজ খুলবে। গেটওয়ের দেওয়া টেস্ট নম্বর বা কার্ড দিয়ে পেমেন্ট করুন।
3. "পাথেয় অ্যাপে ফিরুন" পেজ আসবে। অ্যাপে ফিরে "আলহামদুলিল্লাহ! প্রিমিয়াম চালু হয়েছে" লেখা দেখাবে, আর বিজ্ঞাপন সরে যাবে।
4. Firebase Console-এ যান: **Realtime Database → users → {uid} → premium**। এখানে plan আর until দেখা যাবে। আর `orders`-এ অর্ডারটার status `paid` হবে।

## ৬) Play Store সংস্করণ (পরে)
- **অ্যাপে:** `build.gradle.kts`-এ `DISTRIBUTION` বদলে `"play"` করুন।
- **Play Console-এ যা বানাতে হবে:**
  - সাবস্ক্রিপশন `patheyo_premium`, তার দুটো বেস-প্ল্যান `monthly` আর `yearly`।
  - এককালীন প্রোডাক্ট `patheyo_lifetime`।
- **সার্ভারে:**
  - Play Console-এর **API access** থেকে একটা সার্ভিস অ্যাকাউন্ট নিন, তাকে আর্থিক তথ্য দেখার অনুমতি দিন।
  - তার JSON ফাইলের পথ `PLAY_SERVICE_ACCOUNT_JSON`-এ দিন।
  - সার্ভারের `/play/verify` কেনাটা যাচাই করে প্রিমিয়াম চালু করে।
- **Firebase-এ:** Play App Signing-এর SHA যোগ করুন।

## কোড কোথায়
| কাজ | ফাইল |
|---|---|
| পেওয়াল, প্রিমিয়াম অবস্থা, বিজ্ঞাপন বন্ধ, নবায়নের কথা মনে করানো | `assets/shell/js/11-premium.js`, `index.html` (`#pw-sheet`, `#st-prem-row`), `shell/css/10-shell.css` |
| নেটিভ পেমেন্ট লেয়ার | `premium/PremiumBridge.kt` (JS-এ `PatheyoPremium`), `premium/PlayBilling.kt` |
| পেমেন্ট শেষে অ্যাপে ফেরা | `AndroidManifest.xml` (`patheyo://pay`), `MainActivity.handleUpdateLink` |
| সার্ভার | `server/payments/app.js`, `gateways/{sslcommerz,bkash,shurjopay,play}.js`, `plans.js` |

অন্য কোডে প্রিমিয়াম আছে কি না জানতে তিনটা উপায়:
- `window.ptIsPremium()`
- `html.is-premium` ক্লাস
- `pt:premium` ইভেন্ট

পেওয়াল খুলতে: `window.ptOpenPremium('কোথা থেকে')`। কোনো ফিচারে জোর করে পেওয়াল দেখানো যাবে না।
