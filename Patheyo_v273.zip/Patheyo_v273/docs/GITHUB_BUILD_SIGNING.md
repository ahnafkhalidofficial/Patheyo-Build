# GitHub ও Android Studio — একই কী, একই SHA-1 (v195)

**সমস্যা:** GitHub-এর কম্পিউটারে আপনার `patheyo-key.jks` ছিল না, তাই APK অন্য কী দিয়ে সাইন হতো → SHA-1 Firebase-এ নেই → Google সাইন-ইন হতো না।
**সমাধান:** দুই জায়গাতেই একই `patheyo-key.jks` ব্যবহার। আপনার SHA-1 `02:F9:60:21:…:B5:55` Firebase-এ আগেই আছে, নতুন কিছু যোগ করতে হবে না।

## ১) Android Studio / নিজের কম্পিউটার
প্রজেক্টের রুটে `keystore.properties` রাখুন (`keystore.properties.example` কপি করে):
```
storeFile=C:/Keys/patheyo-key.jks
storePassword=...
keyAlias=patheyo
keyPassword=...
```
এখন **debug ও release দুটোই** এই কী দিয়ে সাইন হয় (`app/build.gradle.kts`)। ফাইলটা GitHub-এ তুলবেন না (`.gitignore`-এ আছে)।

## ২) GitHub Actions — একবার সেটআপ
1. কম্পিউটারে কী-ফাইলকে base64 করুন:
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("C:\Keys\patheyo-key.jks")) | Set-Clipboard`
   - Mac/Linux: `base64 -w0 patheyo-key.jks`
2. GitHub রিপো → **Settings → Secrets and variables → Actions → New repository secret** — চারটা:
   | নাম | মান |
   |---|---|
   | `KEYSTORE_BASE64` | উপরের base64 লেখা |
   | `KEYSTORE_PASSWORD` | কিস্টোর পাসওয়ার্ড |
   | `KEY_ALIAS` | `patheyo` |
   | `KEY_PASSWORD` | কী পাসওয়ার্ড |
3. রিপোতে `.github/workflows/build.yml` (এই জিপে আছে) তুলুন। **Actions → Build APK → Run workflow**।
4. বিল্ড শেষে লগে "SHA-1" লাইন দেখাবে — `02:F9:60:21:…` হলে ঠিক আছে। APK নামান **Artifacts → Patheyo-release-apk** থেকে।

⚠️ পাসওয়ার্ড বা `.jks` কখনো কোডে/চ্যাটে দেবেন না — শুধু Secrets-এ।
