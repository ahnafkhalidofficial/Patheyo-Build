-- =====================================================================
-- পাথেয় v185 — ক্লাউড ব্যাকআপ এখন Supabase-এ (একবারই চালাতে হবে)
-- Supabase Dashboard → SQL Editor → New query → পুরোটা পেস্ট → Run
-- দুবার চালালেও সমস্যা নেই।
--
-- অ্যাকাউন্ট (সাইন-ইন) থাকে Firebase-এ। প্রতিটি ইউজারের পুরো ব্যাকআপ (সেটিংস, বুকমার্ক, প্রিয়, আমল, তাসবিহ…)
-- এই টেবিলে এক সারিতে থাকে; সারির চাবি = Firebase uid।
--
-- নিরাপত্তা: RLS চালু, কিন্তু কোনো policy নেই এবং anon/authenticated থেকে সব অনুমতি তুলে নেওয়া —
-- অর্থাৎ অ্যাপের anon কী দিয়ে এই টেবিলে কেউ সরাসরি কিছু পড়তে/লিখতে পারবে না।
-- একমাত্র পথ: Edge Function "cloud-sync" — সে Firebase-এর টোকেন যাচাই করে শুধু ওই ইউজারের সারিটাই ছোঁয়।
-- =====================================================================

create table if not exists public.user_backups (
  uid         text primary key,
  data        text not null check (char_length(data) <= 4000000),
  device      text,
  updated_at  timestamptz not null default now()
);

alter table public.user_backups enable row level security;

revoke all on table public.user_backups from anon, authenticated;
