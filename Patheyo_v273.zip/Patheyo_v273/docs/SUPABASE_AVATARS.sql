-- =====================================================================
-- পাথেয় — প্রোফাইল ছবির জন্য Supabase সেটআপ (একবারই চালাতে হবে)
-- Supabase Dashboard → SQL Editor → New query → পুরোটা পেস্ট → Run
-- দুবার চালালেও সমস্যা নেই।
-- =====================================================================

-- ১) বাকেট "avatars": সবাই ছবি দেখতে পায়, কিন্তু ফাইল সর্বোচ্চ ১০০KB ও শুধু JPEG
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 102400, array['image/jpeg'])
on conflict (id) do update
  set public = true,
      file_size_limit = 102400,
      allowed_mime_types = array['image/jpeg'];

-- ২) অ্যাপ (anon কী) এই বাকেটে ছবি রাখতে/বদলাতে/মুছতে পারবে — শুধু "{uid}.jpg" নামের ফাইল
drop policy if exists "avatars_select" on storage.objects;
drop policy if exists "avatars_insert" on storage.objects;
drop policy if exists "avatars_update" on storage.objects;
drop policy if exists "avatars_delete" on storage.objects;

create policy "avatars_select" on storage.objects for select to anon, authenticated
  using (bucket_id = 'avatars');

create policy "avatars_insert" on storage.objects for insert to anon, authenticated
  with check (bucket_id = 'avatars' and name ~ '^[A-Za-z0-9]{10,64}\.jpg$');

create policy "avatars_update" on storage.objects for update to anon, authenticated
  using (bucket_id = 'avatars' and name ~ '^[A-Za-z0-9]{10,64}\.jpg$')
  with check (bucket_id = 'avatars' and name ~ '^[A-Za-z0-9]{10,64}\.jpg$');

create policy "avatars_delete" on storage.objects for delete to anon, authenticated
  using (bucket_id = 'avatars' and name ~ '^[A-Za-z0-9]{10,64}\.jpg$');
