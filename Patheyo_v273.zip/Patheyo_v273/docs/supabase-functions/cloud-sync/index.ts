// Supabase Edge Function: cloud-sync  (পাথেয় v185, v200: meta)
// কাজ: Firebase-এ সাইন-ইন করা ইউজারের ব্যাকআপ Supabase-এর user_backups টেবিলে রাখা / আনা / মোছা।
// নিরাপত্তা: অ্যাপ পাঠায় Firebase ID টোকেন (x-firebase-token হেডারে)। এখানে Google-এর পাবলিক কী দিয়ে সেটা যাচাই
// করে uid নেওয়া হয় — তাই কেউ অন্যের uid দিয়ে অন্যের ডেটা পড়তে/লিখতে পারে না।
// service_role কী Supabase নিজেই এই ফাংশনে বসিয়ে দেয় (SUPABASE_SERVICE_ROLE_KEY); অ্যাপে কখনো যায় না।
import { createClient } from "npm:@supabase/supabase-js@2";
import { createRemoteJWKSet, jwtVerify } from "npm:jose@5";

const PROJECT_ID = Deno.env.get("FIREBASE_PROJECT_ID") ?? "hijri-tarikh";
const JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"),
);
const db = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } },
);
const MAX = 4_000_000;
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-firebase-token",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...CORS, "Content-Type": "application/json" } });

async function uidFrom(req: Request): Promise<string | null> {
  const tok = req.headers.get("x-firebase-token");
  if (!tok) return null;
  try {
    const { payload } = await jwtVerify(tok, JWKS, {
      issuer: `https://securetoken.google.com/${PROJECT_ID}`,
      audience: PROJECT_ID,
    });
    return typeof payload.sub === "string" && payload.sub.length > 0 ? payload.sub : null;
  } catch (_) {
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ ok: false, msg: "POST দিন" }, 405);

  const uid = await uidFrom(req);
  if (!uid) return json({ ok: false, msg: "সাইন-ইন যাচাই হয়নি" }, 401);

  let body: { action?: string; data?: unknown; device?: unknown };
  try { body = await req.json(); } catch (_) { return json({ ok: false, msg: "ভুল অনুরোধ" }, 400); }

  if (body.action === "load") {
    const { data, error } = await db.from("user_backups")
      .select("data, device, updated_at").eq("uid", uid).maybeSingle();
    if (error) return json({ ok: false, msg: error.message }, 500);
    if (!data) return json({ ok: true, empty: true });
    return json({ ok: true, empty: false, data: data.data, device: data.device ?? "", at: Date.parse(data.updated_at) });
  }

  // v200: রিয়েল-টাইম পরীক্ষার হালকা কল — ডেটা ছাড়া শুধু শেষ বদলের সময়
  if (body.action === "meta") {
    const { data, error } = await db.from("user_backups")
      .select("device, updated_at").eq("uid", uid).maybeSingle();
    if (error) return json({ ok: false, msg: error.message }, 500);
    if (!data) return json({ ok: true, empty: true });
    return json({ ok: true, empty: false, device: data.device ?? "", at: Date.parse(data.updated_at) });
  }

  if (body.action === "save") {
    if (typeof body.data !== "string" || body.data.length === 0) return json({ ok: false, msg: "ডেটা নেই" }, 400);
    if (body.data.length > MAX) return json({ ok: false, msg: "ডেটা অনেক বড়" }, 413);
    const now = new Date();
    const { error } = await db.from("user_backups").upsert({
      uid,
      data: body.data,
      device: typeof body.device === "string" ? body.device.slice(0, 80) : "",
      updated_at: now.toISOString(),
    });
    if (error) return json({ ok: false, msg: error.message }, 500);
    return json({ ok: true, at: now.getTime() });
  }

  if (body.action === "delete") {
    const { error } = await db.from("user_backups").delete().eq("uid", uid);
    if (error) return json({ ok: false, msg: error.message }, 500);
    return json({ ok: true });
  }

  return json({ ok: false, msg: "অজানা কাজ" }, 400);
});
