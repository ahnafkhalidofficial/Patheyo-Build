/* =============================================================================
   পাথেয় প্রিমিয়াম — পেমেন্ট সার্ভার (Express)
   অ্যাপ (premium/PremiumBridge.kt) → POST /create {plan}  (হেডারে Firebase ID টোকেন)
     → অর্ডার তৈরি (orders/{id}) → গেটওয়েতে পেমেন্ট সেশন → {url}
   গ্রাহক ব্রাউজারে পেমেন্ট করে → গেটওয়ে  /return  (এবং SSLCommerz-এর IPN /ipn) এ পাঠায়
     → গেটওয়ের কাছে যাচাই (টাকা সত্যিই এসেছে? পরিমাণ ঠিক?) → users/{uid}/premium লেখা
     → অ্যাপে ফেরত: patheyo://pay?status=…&order=…
   Play: POST /play/verify {productId, purchaseToken} → Google-এর কাছে যাচাই → premium লেখা

   নিরাপত্তা:
   • premium শুধু এখানেই লেখা হয় (ডাটাবেস রুলসে অ্যাপের জন্য premium/.write = false)।
   • একই অর্ডার দুবার গোনা হয় না (orders/{id}/status = 'paid' — ট্রানজেকশন)।
   • দাম সার্ভারে ঠিক করা (plans.js) — অ্যাপ থেকে আসা টাকার অঙ্ক বিশ্বাস করা হয় না।
   ============================================================================= */
/* Vercel-এ মান বসানোর সময় আগে-পিছে ফাঁকা জায়গা/উদ্ধৃতিচিহ্ন চলে এলে নিজেই বাদ দিই */
for (const k of ['GATEWAY', 'SANDBOX', 'SSLC_STORE_ID', 'SSLC_STORE_PASSWD', 'RTDB_URL', 'PUBLIC_URL', 'APP_PACKAGE']) {
  if (process.env[k] != null) process.env[k] = String(process.env[k]).trim().replace(/^["']|["']$/g, '').trim();
}
const express = require('express');
const admin = require('firebase-admin');
const PLANS = require('./plans');

/* Firebase-এর বাইরে (Vercel/Render) চালালে সার্ভিস অ্যাকাউন্টের JSON পুরোটা FIREBASE_SERVICE_ACCOUNT-এ রাখুন;
   Firebase Functions-এ লাগে না (নিজে থেকেই পায়) */
if (!admin.apps.length) {
  const opts = { databaseURL: process.env.RTDB_URL || 'https://hijri-tarikh-default-rtdb.firebaseio.com' };
  if (process.env.FIREBASE_SERVICE_ACCOUNT) {
    const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    if (sa.private_key) sa.private_key = sa.private_key.replace(/\\n/g, '\n');
    opts.credential = admin.credential.cert(sa);
  }
  admin.initializeApp(opts);
}
const db = () => admin.database();
const GW = () => require('./gateways/' + (process.env.GATEWAY || 'sslcommerz'));
const PUBLIC = () => (process.env.PUBLIC_URL || '').replace(/\/$/, '');

const app = express();
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: false, limit: '50kb' }));

async function authUser(req) {
  const h = req.get('Authorization') || '';
  const tok = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!tok) return null;
  try { return await admin.auth().verifyIdToken(tok); } catch (e) { return null; }
}

/** প্রিমিয়াম দেওয়া — মেয়াদ থাকা অবস্থায় নবায়ন করলে বাকি দিনের সাথে যোগ হয় */
async function grant(uid, plan, source, orderId, untilOverride) {
  const ref = db().ref('users/' + uid + '/premium');
  await ref.transaction((cur) => {
    const now = Date.now();
    if (plan === 'lifetime' || (cur && cur.plan === 'lifetime')) return { plan: 'lifetime', until: 0, since: (cur && cur.since) || now, source, order: orderId, at: now };
    const from = cur && cur.until > now ? cur.until : now;
    const until = untilOverride || from + PLANS[plan].days * 86400000;
    return { plan, until, since: (cur && cur.since) || now, source, order: orderId, at: now };
  });
}

/* ---------------------------------------------------------------- ১) পেমেন্ট শুরু */
app.post('/create', async (req, res) => {
  try {
    const user = await authUser(req);
    if (!user) return res.status(401).json({ ok: false, msg: 'আগে সাইন-ইন করুন।' });
    const plan = String((req.body && req.body.plan) || '');
    if (!PLANS[plan]) return res.status(400).json({ ok: false, msg: 'প্ল্যান সঠিক নয়।' });
    const id = 'PTY' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
    const order = { id, uid: user.uid, plan, amount: PLANS[plan].amount, title: PLANS[plan].title, gateway: process.env.GATEWAY || 'sslcommerz', status: 'pending', at: Date.now() };
    const urls = { ret: PUBLIC() + '/return', ipn: PUBLIC() + '/ipn' };
    const s = await GW().create(order, urls, { name: user.name, email: user.email, ip: req.ip });
    order.ref = s.ref || '';
    await db().ref('orders/' + id).set(order);
    if (order.ref) await db().ref('order_refs/' + String(order.ref).replace(/[.#$[\]/]/g, '_')).set(id);
    res.json({ ok: true, url: s.url, order: id });
  } catch (e) {
    console.error('create', e);
    /* স্যান্ডবক্সে আসল কারণও দেখাই (পরীক্ষার সময় খুঁজে পেতে সুবিধা); লাইভে নয় */
    const why = process.env.SANDBOX === 'false' ? '' : ' [' + String((e && e.message) || e).slice(0, 120) + ']';
    res.status(500).json({ ok: false, msg: 'পেমেন্ট শুরু করা গেল না। একটু পরে চেষ্টা করুন।' + why });
  }
});

/* ---------------------------------------------------------------- ২) যাচাই (ফেরত ও IPN একই কাজ) */
async function settle(params) {
  const gw = GW();
  let orderId = gw.orderIdFrom(params);
  if (!orderId && gw.refFrom) { const ref = gw.refFrom(params); if (ref) orderId = (await db().ref('order_refs/' + ref.replace(/[.#$[\]/]/g, '_')).get()).val() || ''; }
  if (!orderId) return { status: 'failed', order: '' };
  const oref = db().ref('orders/' + orderId);
  const order = (await oref.get()).val();
  if (!order) return { status: 'failed', order: orderId };
  if (order.status === 'paid') return { status: 'success', order: orderId };          /* আগেই গোনা */
  const v = await gw.verify(params, order);
  if (!v.ok) { if (v.status === 'cancelled') await oref.update({ status: 'cancelled' }); return { status: v.status, order: orderId }; }
  /* একবারই premium — দুই অনুরোধ একসাথে এলেও */
  const t = await oref.child('status').transaction((s) => (s === 'paid' ? undefined : 'paid'));
  if (t.committed) {
    await oref.update({ txn: v.txn || '', method: v.method || '', paidAt: Date.now() });
    await grant(order.uid, order.plan, order.gateway, orderId);
  }
  return { status: 'success', order: orderId };
}

/** গেটওয়ে থেকে ব্রাউজার এখানে আসে → যাচাই → অ্যাপে ফেরার ছোট পাতা */
async function onReturn(req, res) {
  let r = { status: 'failed', order: '' };
  try { r = await settle(Object.assign({}, req.query, req.body)); } catch (e) { console.error('return', e); }
  const pkg = process.env.APP_PACKAGE || 'com.gunjoron.patheyo';
  const q = 'status=' + encodeURIComponent(r.status) + '&order=' + encodeURIComponent(r.order);
  const intent = 'intent://pay?' + q + '#Intent;scheme=patheyo;package=' + pkg + ';end';
  const msg = r.status === 'success' ? 'পেমেন্ট সম্পন্ন — আলহামদুলিল্লাহ!' : r.status === 'cancelled' ? 'পেমেন্ট বাতিল করা হয়েছে' : 'পেমেন্ট সম্পন্ন হয়নি';
  res.set('Content-Type', 'text/html; charset=utf-8').send(`<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>পাথেয়</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#111827;color:#F1F4F9;font-family:system-ui,sans-serif;text-align:center}
.c{padding:32px 24px}h1{font-size:22px;margin:16px 0 8px}p{color:#A3AEC2;margin:0 0 24px}a{display:inline-block;padding:14px 28px;border-radius:12px;background:#4169E1;color:#fff;text-decoration:none;font-weight:700}
.s{width:56px;height:56px;margin:auto;background:#D4A24C;clip-path:polygon(50% 0,64% 15%,85% 15%,85% 36%,100% 50%,85% 64%,85% 85%,64% 85%,50% 100%,36% 85%,15% 85%,15% 64%,0 50%,15% 36%,15% 15%,36% 15%)}</style></head>
<body><div class="c"><div class="s"></div><h1>${msg}</h1><p>অ্যাপে ফিরে যান — প্রিমিয়াম নিজে থেকেই দেখাবে।</p><a id="go" href="${intent}">পাথেয় অ্যাপে ফিরুন</a></div>
<script>setTimeout(function(){location.href=${JSON.stringify(intent)}},700)</script></body></html>`);
}
app.get('/return', onReturn);
app.post('/return', onReturn);

/** SSLCommerz IPN — গ্রাহক অ্যাপে না ফিরলেও (ব্রাউজার বন্ধ করে দিলেও) প্রিমিয়াম চালু হয় */
app.post('/ipn', async (req, res) => {
  try { await settle(Object.assign({}, req.body)); } catch (e) { console.error('ipn', e); }
  res.send('OK');
});

/* ---------------------------------------------------------------- ৩) Google Play (শুধু Play সংস্করণ) */
app.post('/play/verify', async (req, res) => {
  try {
    const user = await authUser(req);
    if (!user) return res.status(401).json({ ok: false });
    const { productId, purchaseToken } = req.body || {};
    if (!productId || !purchaseToken) return res.status(400).json({ ok: false });
    const v = await require('./gateways/play').verify(productId, purchaseToken);
    if (!v.ok) return res.json({ ok: false });
    /* একই কেনা অন্য অ্যাকাউন্টে বসানো আটকাতে টোকেন → uid বাঁধা */
    const key = 'play_tokens/' + Buffer.from(purchaseToken).toString('base64').replace(/[^A-Za-z0-9]/g, '').slice(0, 200);
    const owner = (await db().ref(key).get()).val();
    if (owner && owner !== user.uid) return res.json({ ok: false, msg: 'এই কেনা অন্য অ্যাকাউন্টের।' });
    await db().ref(key).set(user.uid);
    await grant(user.uid, v.plan, 'play', v.txn, v.until || undefined);
    res.json({ ok: true });
  } catch (e) { console.error('play', e); res.status(500).json({ ok: false }); }
});

app.get('/', (req, res) => res.send('Patheyo payments — ' + (process.env.GATEWAY || 'sslcommerz') + (process.env.SANDBOX === 'false' ? ' (live)' : ' (sandbox)')));

/* ---------------------------------------------------------------- সেটআপ যাচাই: ব্রাউজারে /check খুলুন
   কোনো গোপন তথ্য দেখায় না — শুধু কোনটা ঠিক আছে/নেই */
app.get('/check', async (req, res) => {
  const out = {};
  const has = (k) => (process.env[k] ? 'আছে ✔' : 'নেই ✘');
  out['১. GATEWAY'] = process.env.GATEWAY || 'sslcommerz (ডিফল্ট)';
  out['২. SANDBOX'] = process.env.SANDBOX === 'false' ? 'false (লাইভ)' : 'true (পরীক্ষা)';
  out['৩. SSLC_STORE_ID'] = process.env.SSLC_STORE_ID ? process.env.SSLC_STORE_ID + ' ✔' : 'নেই ✘';
  { const pw = process.env.SSLC_STORE_PASSWD || '', id = process.env.SSLC_STORE_ID || '';
    out['৪. SSLC_STORE_PASSWD'] = !pw ? 'নেই ✘' : (pw === id + '@ssl' ? 'আছে ✔ (ইমেইলের ধরনের সাথে মিলেছে)' :
      'আছে, কিন্তু ইমেইলের Store Password-এর সাথে মিলছে না ✘ (' + pw.length + ' অক্ষর, হওয়া উচিত ' + (id.length + 4) + ' অক্ষর; শুরু "' + pw.slice(0, 3) + '…")'); }
  out['৫. RTDB_URL'] = process.env.RTDB_URL || 'নেই (ডিফল্ট ব্যবহার হচ্ছে)';
  out['৬. PUBLIC_URL'] = process.env.PUBLIC_URL ? process.env.PUBLIC_URL + ' ✔' : 'নেই ✘ — বসাতে হবে';
  try { const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || '{}'); out['৭. FIREBASE_SERVICE_ACCOUNT'] = sa.project_id ? 'আছে ✔ (' + sa.project_id + ')' : 'নেই ✘'; }
  catch (e) { out['৭. FIREBASE_SERVICE_ACCOUNT'] = 'ভুল ✘ — JSON ঠিকমতো কপি হয়নি'; }
  try {
    await db().ref('_health').set({ at: Date.now() });
    out['৮. ডাটাবেসে লেখা'] = 'কাজ করছে ✔';
  } catch (e) { out['৮. ডাটাবেসে লেখা'] = 'কাজ করছে না ✘ — ' + String(e.message).slice(0, 100); }
  if ((process.env.GATEWAY || 'sslcommerz') === 'sslcommerz' && process.env.SANDBOX !== 'false') {
    try {
      await GW().create({ id: 'CHK' + Date.now(), amount: 10, title: 'Check', uid: 'check' }, { ret: PUBLIC() + '/return', ipn: PUBLIC() + '/ipn' }, {});
      out['৯. SSLCommerz স্টোর আইডি/পাসওয়ার্ড'] = 'ঠিক আছে ✔';
    } catch (e) { out['৯. SSLCommerz স্টোর আইডি/পাসওয়ার্ড'] = 'ভুল ✘ — ' + String(e.message).slice(0, 100); }
  }
  res.set('content-type', 'text/plain; charset=utf-8').send(Object.entries(out).map(([k, v]) => k + ': ' + v).join('\n'));
});

module.exports = app;
