/* প্ল্যান ও দাম — অ্যাপের পেওয়ালের সাথে মিল রাখুন (shell/js/11-premium.js, PremiumBridge.config) */
module.exports = {
  monthly:  { amount: 49,  days: 30,  title: 'পাথেয় প্রিমিয়াম — মাসিক' },
  yearly:   { amount: 399, days: 365, title: 'পাথেয় প্রিমিয়াম — বার্ষিক' },
  lifetime: { amount: 999, days: 0,   title: 'পাথেয় প্রিমিয়াম — আজীবন' }
};
