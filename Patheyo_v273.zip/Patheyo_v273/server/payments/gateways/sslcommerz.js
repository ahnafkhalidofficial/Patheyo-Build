/* SSLCommerz (v4) — bKash, Nagad, রকেট, কার্ড সব এক পেজে
   ডক: https://developer.sslcommerz.com/doc/v4/
   ১) create: সেশন খুলে GatewayPageURL ফেরত
   ২) ফেরত (success/fail/cancel) ও IPN-এ val_id আসে → validationserverAPI দিয়ে যাচাই */
const base = () => (process.env.SANDBOX === 'false' ? 'https://securepay.sslcommerz.com' : 'https://sandbox.sslcommerz.com');

async function create(order, urls, user) {
  const body = new URLSearchParams({
    store_id: process.env.SSLC_STORE_ID, store_passwd: process.env.SSLC_STORE_PASSWD,
    total_amount: String(order.amount), currency: 'BDT', tran_id: order.id,
    success_url: urls.ret + '?r=success', fail_url: urls.ret + '?r=fail', cancel_url: urls.ret + '?r=cancel', ipn_url: urls.ipn,
    cus_name: user.name || 'Patheyo User', cus_email: user.email || 'user@patheyo.app', cus_phone: '01700000000',
    cus_add1: 'Bangladesh', cus_city: 'Dhaka', cus_country: 'Bangladesh',
    shipping_method: 'NO', num_of_item: '1', product_name: order.title, product_category: 'Subscription', product_profile: 'non-physical-goods',
    value_a: order.uid
  });
  const r = await fetch(base() + '/gwprocess/v4/api.php', { method: 'POST', body });
  const j = await r.json();
  if (j.status !== 'SUCCESS' || !j.GatewayPageURL) throw new Error('sslcommerz: ' + (j.failedreason || 'session failed'));
  return { url: j.GatewayPageURL, ref: j.sessionkey };
}

/** val_id যাচাই: সত্যিই টাকা এসেছে, সঠিক অর্ডার, সঠিক পরিমাণ */
async function verify(params, order) {
  const valId = params.val_id;
  if (!valId) return { ok: false, status: params.r === 'cancel' ? 'cancelled' : 'failed' };
  const q = new URLSearchParams({ val_id: valId, store_id: process.env.SSLC_STORE_ID, store_passwd: process.env.SSLC_STORE_PASSWD, format: 'json' });
  const r = await fetch(base() + '/validator/api/validationserverAPI.php?' + q);
  const j = await r.json();
  const good = (j.status === 'VALID' || j.status === 'VALIDATED') && j.tran_id === order.id &&
    Number(j.amount) >= order.amount && (j.currency_type || j.currency) === 'BDT';
  return { ok: good, status: good ? 'success' : 'failed', txn: j.bank_tran_id || valId, method: j.card_type || '' };
}

/** কোন অর্ডারের ফেরত — SSLCommerz tran_id পাঠায় */
const orderIdFrom = (params) => params.tran_id || params.value_b || '';

module.exports = { create, verify, orderIdFrom };
