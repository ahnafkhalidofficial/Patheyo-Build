/* Google Play কেনা যাচাই — শুধু Play Store সংস্করণে (অ্যাপে DISTRIBUTION = "play")
   Play Console → API access → সার্ভিস অ্যাকাউন্ট (Financial data দেখার অনুমতি) → JSON চাবি → PLAY_SERVICE_ACCOUNT_JSON */
const { google } = require('googleapis');
const PKG = () => process.env.APP_PACKAGE || 'com.gunjoron.patheyo';

async function client() {
  const auth = new google.auth.GoogleAuth({ keyFile: process.env.PLAY_SERVICE_ACCOUNT_JSON, scopes: ['https://www.googleapis.com/auth/androidpublisher'] });
  return google.androidpublisher({ version: 'v3', auth });
}

/** ফেরত: {ok, plan, until(ms; আজীবনে 0), txn} */
async function verify(productId, purchaseToken) {
  const api = await client();
  if (productId === 'patheyo_lifetime') {
    const r = await api.purchases.products.get({ packageName: PKG(), productId, token: purchaseToken });
    return { ok: r.data.purchaseState === 0, plan: 'lifetime', until: 0, txn: r.data.orderId || '' };
  }
  const r = await api.purchases.subscriptionsv2.get({ packageName: PKG(), token: purchaseToken });
  const d = r.data, li = (d.lineItems || [])[0] || {};
  const active = d.subscriptionState === 'SUBSCRIPTION_STATE_ACTIVE' || d.subscriptionState === 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD';
  const basePlan = (li.offerDetails && li.offerDetails.basePlanId) || 'monthly';
  return { ok: active, plan: basePlan === 'yearly' ? 'yearly' : 'monthly', until: Date.parse(li.expiryTime || 0) || 0, txn: d.latestOrderId || '' };
}
module.exports = { verify };
