/* bKash Tokenized Checkout (v1.2.0-beta)
   ডক: https://developer.bka.sh/docs/tokenized-checkout-overview
   grant token → create (bkashURL) → গ্রাহক পেমেন্ট করে → callbackURL?paymentID=…&status=success → execute */
const base = () => (process.env.SANDBOX === 'false' ? 'https://tokenized.pay.bka.sh/v1.2.0-beta' : 'https://tokenized.sandbox.bka.sh/v1.2.0-beta');

async function token() {
  const r = await fetch(base() + '/tokenized/checkout/token/grant', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', username: process.env.BKASH_USERNAME, password: process.env.BKASH_PASSWORD },
    body: JSON.stringify({ app_key: process.env.BKASH_APP_KEY, app_secret: process.env.BKASH_APP_SECRET })
  });
  const j = await r.json();
  if (!j.id_token) throw new Error('bkash: token ' + (j.statusMessage || ''));
  return j.id_token;
}
function headers(t) { return { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: t, 'X-APP-Key': process.env.BKASH_APP_KEY }; }

async function create(order, urls) {
  const t = await token();
  const r = await fetch(base() + '/tokenized/checkout/create', {
    method: 'POST', headers: headers(t),
    body: JSON.stringify({ mode: '0011', payerReference: order.uid.slice(0, 20), callbackURL: urls.ret + '?order=' + order.id,
      amount: String(order.amount), currency: 'BDT', intent: 'sale', merchantInvoiceNumber: order.id })
  });
  const j = await r.json();
  if (!j.bkashURL) throw new Error('bkash: create ' + (j.statusMessage || ''));
  return { url: j.bkashURL, ref: j.paymentID };
}

async function verify(params, order) {
  if (params.status !== 'success' || !params.paymentID) return { ok: false, status: params.status === 'cancel' ? 'cancelled' : 'failed' };
  const t = await token();
  const r = await fetch(base() + '/tokenized/checkout/execute', { method: 'POST', headers: headers(t), body: JSON.stringify({ paymentID: params.paymentID }) });
  let j = await r.json();
  if (!j.transactionStatus) {        /* execute টাইমআউট হলে query দিয়ে নিশ্চিত হওয়া */
    const q = await fetch(base() + '/tokenized/checkout/payment/status', { method: 'POST', headers: headers(t), body: JSON.stringify({ paymentID: params.paymentID }) });
    j = await q.json();
  }
  const good = j.transactionStatus === 'Completed' && Number(j.amount) >= order.amount && j.merchantInvoiceNumber === order.id;
  return { ok: good, status: good ? 'success' : 'failed', txn: j.trxID || '', method: 'bkash' };
}

const orderIdFrom = (params) => params.order || '';
module.exports = { create, verify, orderIdFrom };
