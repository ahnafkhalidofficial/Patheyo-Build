/* ShurjoPay (v2) — bKash, Nagad, রকেট, কার্ড
   ডক: https://shurjopay.com.bd/developers
   get_token → secret-pay (checkout_url) → return_url?order_id=<sp_order_id> → verification */
const base = () => (process.env.SANDBOX === 'false' ? 'https://engine.shurjopayment.com' : 'https://sandbox.shurjopayment.com');

async function token() {
  const r = await fetch(base() + '/api/get_token', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: process.env.SHURJO_USERNAME, password: process.env.SHURJO_PASSWORD }) });
  const j = await r.json();
  if (!j.token) throw new Error('shurjopay: token');
  return j;
}

async function create(order, urls, user) {
  const t = await token();
  const r = await fetch(base() + '/api/secret-pay', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t.token },
    body: JSON.stringify({ prefix: process.env.SHURJO_PREFIX || 'PTY', token: t.token, store_id: t.store_id,
      return_url: urls.ret, cancel_url: urls.ret + '?cancel=1', amount: order.amount, order_id: order.id, currency: 'BDT',
      customer_name: user.name || 'Patheyo User', customer_email: user.email || '', customer_address: 'Bangladesh', customer_phone: '01700000000',
      customer_city: 'Dhaka', client_ip: user.ip || '127.0.0.1', value1: order.uid }) });
  const j = await r.json();
  if (!j.checkout_url) throw new Error('shurjopay: create');
  return { url: j.checkout_url, ref: j.sp_order_id };
}

async function verify(params, order) {
  if (params.cancel) return { ok: false, status: 'cancelled' };
  const sp = params.order_id || order.ref; if (!sp) return { ok: false, status: 'failed' };
  const t = await token();
  const r = await fetch(base() + '/api/verification', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t.token },
    body: JSON.stringify({ order_id: sp }) });
  const arr = await r.json(); const j = Array.isArray(arr) ? arr[0] : arr;
  const good = j && String(j.sp_code) === '1000' && Number(j.amount || j.payable_amount) >= order.amount && (j.customer_order_id === order.id || j.value1 === order.uid);
  return { ok: !!good, status: good ? 'success' : 'failed', txn: (j && (j.bank_trx_id || j.order_id)) || '', method: (j && j.method) || '' };
}

/* ShurjoPay ফেরতে শুধু নিজের sp_order_id দেয় — অর্ডার খুঁজতে ref ব্যবহার হয় (index.js) */
const orderIdFrom = () => '';
const refFrom = (params) => params.order_id || '';
module.exports = { create, verify, orderIdFrom, refFrom };
