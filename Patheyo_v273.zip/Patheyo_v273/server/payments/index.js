/* ⚠️ Firebase Functions-এ চালাতে package.json-এর "main" = "index.js" করতে হবে (Vercel-এর জন্য এখন "app.js") */
/* Firebase Cloud Functions হিসেবে চালাতে (Blaze প্ল্যান লাগে):  firebase deploy --only functions
   ঠিকানা হবে: https://asia-south1-<project>.cloudfunctions.net/pay  → এটাই অ্যাপের PAY_API_URL ও .env-এর PUBLIC_URL */
const { onRequest } = require('firebase-functions/v2/https');
const app = require('./app');
exports.pay = onRequest({ region: 'asia-south1', cors: false, maxInstances: 5 }, app);
