/* Vercel (ফ্রি, কার্ড লাগে না) — পুরো সার্ভার একটাই ফাংশন; vercel.json সব ঠিকানা এখানে পাঠায় */
module.exports = require('../app');
