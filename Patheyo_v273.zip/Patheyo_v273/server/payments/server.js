/* যেকোনো Node 20 হোস্টে (Render, Railway, নিজের VPS) চালাতে:  npm install && npm start
   Firebase Admin-এর জন্য GOOGLE_APPLICATION_CREDENTIALS = সার্ভিস অ্যাকাউন্টের JSON ফাইলের পথ।
   .env ফাইল থাকলে পড়ে নেয় (Node 20.6+:  node --env-file=.env server.js) */
const app = require('./app');
const port = process.env.PORT || 8080;
app.listen(port, () => console.log('Patheyo payments on :' + port));
