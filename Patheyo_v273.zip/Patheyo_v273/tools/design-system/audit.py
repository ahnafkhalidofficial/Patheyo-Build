#!/usr/bin/env python3
"""ডিজাইন-সিস্টেম অডিট: কোন পেজে এখনো সিস্টেমের বাইরের রং/সাইজ/গোলভাব/সময় আছে তা গোনে।

প্রতিটি ধাপ শেষে চালাতে হবে — সংখ্যা কমতে হবে; ধাপ ১৩-এ লক্ষ্য ০।
  python3 tools/design-system/audit.py            → সারাংশ টেবিল
  python3 tools/design-system/audit.py --detail namaz   → ওই অংশের প্রতিটি অমিলের লাইন
গণনা থেকে বাদ: shared/ds (সিস্টেম নিজে), vendor/, var(--pt-*) ব্যবহার, 0/inherit/transparent/currentColor ধরনের নিরপেক্ষ মান।
"""
import re, sys
from pathlib import Path
from collections import defaultdict

ROOT = Path(sys.argv[sys.argv.index("--root") + 1]) if "--root" in sys.argv else Path(__file__).resolve().parents[2] / "app/src/main/assets"
RULES = {
    "রং":       re.compile(r"#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)|hsla?\([^)]*\)"),
    "ফন্ট-সাইজ": re.compile(r"font-size\s*+:\s*+(?!var\(--pt-|calc\(var\(--pt-|inherit|100%|[\d.]+em\b)[^;}\"]+"),
    "গোলভাব":   re.compile(r"border-radius\s*+:\s*+(?!var\(--pt-|0\b|50%|inherit)[^;}\"]+"),
    "সময়":      re.compile(r"\b\d*\.?\d+m?s\s+(?:cubic-bezier\([^)]*\)|ease(?:-in-out|-in|-out)?|linear)"),
    "ফন্ট":     re.compile(r"font-family\s*+:\s*+(?!var\(--pt-|inherit)[^;}\"]+"),
    "keyframes": re.compile(r"@keyframes\s+(?!pt-)[\w-]+"),
}

def area(p: Path):
    r = p.relative_to(ROOT).parts
    if r[0] == "features": return r[1]
    if r[0] in ("shell", "ads", "shared"): return r[0]
    return "index.html" if p.name == "index.html" else r[0]

def files():
    for p in ROOT.rglob("*"):
        if p.suffix not in (".css", ".html", ".js") or not p.is_file(): continue
        s = str(p)
        if "/vendor/" in s or "/shared/ds/" in s: continue
        if p.suffix == ".js" and "style" not in p.read_text(encoding="utf-8", errors="ignore")[:200000]: continue
        yield p

def main():
    detail = sys.argv[2] if len(sys.argv) > 2 and sys.argv[1] == "--detail" else None
    tot = defaultdict(lambda: defaultdict(int))
    uniq = defaultdict(set)
    for p in files():
        a = area(p)
        for ln, line in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
            if p.suffix == ".js" and not re.search(r"style|css|color|font", line, re.I): continue
            masky = "mask" in line                       # মাস্কের #000/#fff রং নয়, আকৃতি
            for k, rx in RULES.items():
                if k == "রং" and masky: continue
                for m in rx.finditer(line):
                    tot[a][k] += 1; uniq[k].add(m.group(0).strip().lower())
                    if detail == a: print(f"{p.relative_to(ROOT)}:{ln}  [{k}] {m.group(0).strip()[:70]}")
    if detail: return
    keys = list(RULES)
    w = max(len(a) for a in tot) + 2
    print("অংশ".ljust(w) + "".join(k.rjust(11) for k in keys) + "      মোট")
    grand = defaultdict(int)
    for a in sorted(tot, key=lambda a: -sum(tot[a].values())):
        row = tot[a]; s = sum(row.values())
        for k in keys: grand[k] += row[k]
        print(a.ljust(w) + "".join(str(row[k]).rjust(11) for k in keys) + str(s).rjust(9))
    print("-" * (w + 11 * len(keys) + 9))
    print("মোট".ljust(w) + "".join(str(grand[k]).rjust(11) for k in keys) + str(sum(grand.values())).rjust(9))
    print("আলাদা মান".ljust(w) + "".join(str(len(uniq[k])).rjust(11) for k in keys))

if __name__ == "__main__":
    main()
