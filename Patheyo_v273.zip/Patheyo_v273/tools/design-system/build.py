#!/usr/bin/env python3
"""পাথেয় ডিজাইন সিস্টেম বিল্ডার।

একটাই সোর্স (assets/shared/ds/tokens.json) থেকে তৈরি করে:
  1. assets/shared/ds/tokens.css        — CSS ভ্যারিয়েবল (--pt-*), ডার্ক + লাইট
  2. assets/shared/ds/ds.css            — fonts + tokens + base + components এক ফাইলে (পেজগুলো শুধু এটাই লিংক করে)
     assets/shared/ds/ds.js             — icons + pt (আচরণ) এক ফাইলে
  3. res/values/pt_ds.xml               — Kotlin/XML স্ক্রিনের জন্য একই রং ও মাপ (pt_dark_* / pt_light_*)
আর রঙের কনট্রাস্ট (পড়ার মতো কি না) যাচাই করে; কম হলে বিল্ড থামে।

চালানো:  python3 tools/design-system/build.py
"""
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DS = ROOT / "app/src/main/assets/shared/ds"
RES = ROOT / "app/src/main/res/values"
T = json.loads((DS / "tokens.json").read_text(encoding="utf-8"))


def clean(d):
    return {k: v for k, v in d.items() if not k.startswith("$")}


# ---------- কনট্রাস্ট ----------
def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def lum(rgb):
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = map(f, rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(a, b):
    la, lb = sorted((lum(hex_rgb(a)), lum(hex_rgb(b))), reverse=True)
    return (la + 0.05) / (lb + 0.05)


errors, report = [], []
for theme, pal in T["color"].items():
    for fg, bg, need in T["contrast_checks"]:
        r = ratio(pal[fg], pal[bg])
        report.append(f"  {theme:5} {fg:>13} on {bg:<8} {r:5.2f}  (≥{need})")
        if r + 1e-9 < need:
            errors.append(f"{theme}: {fg} on {bg} = {r:.2f} < {need}")

# ---------- tokens.css ----------
def block(sel, pal):
    out = [f"{sel} {{"]
    out += [f"  --pt-{k}: {v};" for k, v in pal.items()]
    out.append("}")
    return "\n".join(out)


lines = ["/* স্বয়ংক্রিয়ভাবে তৈরি — হাতে বদলাবেন না। সোর্স: tokens.json, বিল্ড: tools/design-system/build.py */"]
common = {}
f = T["font"]
common.update({"font-bn": f["bn"], "font-display": f["display"], "font-num": f["num"], "font-ar": f["ar"], "w-regular": f["weight-regular"], "w-bold": f["weight-bold"]})
for name, t in clean(T["type"]).items():
    common[f"fs-{name}"] = t["size"]
    common[f"lh-{name}"] = t["line"]
    common[f"fw-{name}"] = t["weight"]
common.update(clean(T["arabic"]))
common["read-scale"] = "1"
common.update({f"space-{k}": v for k, v in T["space"].items()})
common.update({f"r-{k}": v for k, v in clean(T["radius"]).items()})
common["r-arch"] = "999px 999px var(--pt-r-lg) var(--pt-r-lg)"
common["r-arch-sm"] = "var(--pt-r-pill) var(--pt-r-pill) var(--pt-r-xs) var(--pt-r-xs)"
common.update({f"size-{k}": v for k, v in T["size"].items()})
common.update({f"sh-{k}": v for k, v in T["shadow"].items()})
common.update(clean(T["motion"]))
common.update({f"z-{k}": v for k, v in T["z"].items()})
common["safe-top"] = "env(safe-area-inset-top, 0px)"
common["safe-bottom"] = "env(safe-area-inset-bottom, 0px)"

lines.append(block(":root", common))
lines.append(block(':root, [data-theme="dark"]', T["color"]["dark"]) + '\n:root, [data-theme="dark"] { color-scheme: dark; }')
lines.append(block('[data-theme="light"]', T["color"]["light"]) + '\n[data-theme="light"] { color-scheme: light; }')
if "sepia" in T["color"]:                      # পড়ার পেজের "চোখের আরাম" থিম (কুরআন/হাদিস) — লাইটের মতো, উষ্ণ কাগজের রং
    lines.append(block('[data-theme="sepia"]', T["color"]["sepia"]) + '\n[data-theme="sepia"] { color-scheme: light; }')
lines.append("@media (prefers-reduced-motion: reduce) {\n  :root { --pt-dur-1: 0ms; --pt-dur-2: 0ms; --pt-dur-3: 0ms; --pt-dur-4: 0ms; }\n}")
tokens_css = "\n\n".join(lines) + "\n"
(DS / "tokens.css").write_text(tokens_css, encoding="utf-8")

# ---------- ds.css (বান্ডেল) ----------
def mini(css):
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
    css = re.sub(r"\s+", " ", css)
    css = re.sub(r"\s*([{};,>])\s*", r"\1", css)
    css = css.replace(";}", "}")
    return css.strip()


parts = ["fonts.css", "tokens.css", "base.css", "components.css"]
bundle = "/* পাথেয় ডিজাইন সিস্টেম — বান্ডেল (স্বয়ংক্রিয়)। সোর্স: shared/ds/{" + ",".join(parts) + "} */\n"
bundle += "\n".join(mini((DS / p).read_text(encoding="utf-8")) for p in parts) + "\n"
(DS / "ds.css").write_text(bundle, encoding="utf-8")

# ---------- ds.js (বান্ডেল: আইকন + আচরণ) ----------
js_parts = ["icons.js", "pt.js"]
js = "/* পাথেয় ডিজাইন সিস্টেম — JS বান্ডেল (স্বয়ংক্রিয়)। সোর্স: shared/ds/{" + ",".join(js_parts) + "} */\n"
js += "\n".join((DS / p).read_text(encoding="utf-8") for p in js_parts)
(DS / "ds.js").write_text(js, encoding="utf-8")

# ---------- Android ----------
def android_color(v):
    v = v.strip()
    if v.startswith("#"):
        return "#FF" + v[1:].upper()
    m = re.match(r"rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)", v)
    if m:
        r, g, b, a = int(m[1]), int(m[2]), int(m[3]), float(m[4])
        return "#%02X%02X%02X%02X" % (round(a * 255), r, g, b)
    raise ValueError(v)


x = ['<?xml version="1.0" encoding="utf-8"?>',
     "<!-- স্বয়ংক্রিয়ভাবে তৈরি (tools/design-system/build.py) — হাতে বদলাবেন না। ওয়েবের pt-* টোকেনের হুবহু কপি। -->",
     "<resources>"]
for theme, pal in T["color"].items():
    for k, v in pal.items():
        x.append(f'    <color name="pt_{theme}_{k.replace("-", "_")}">{android_color(v)}</color>')
for k, v in T["space"].items():
    x.append(f'    <dimen name="pt_space_{k}">{v[:-2]}dp</dimen>')
for k, v in clean(T["radius"]).items():
    x.append(f'    <dimen name="pt_r_{k}">{v[:-2]}dp</dimen>')
for k, t in clean(T["type"]).items():
    x.append(f'    <dimen name="pt_fs_{k.replace("-", "_")}">{t["size"][:-2]}sp</dimen>')
for k, v in T["size"].items():
    x.append(f'    <dimen name="pt_size_{k.replace("-", "_")}">{v[:-2]}dp</dimen>')
for k, v in clean(T["motion"]).items():
    if k.startswith("dur"):
        x.append(f'    <integer name="pt_{k.replace("-", "_")}">{v[:-2]}</integer>')
x.append("</resources>")
(RES / "pt_ds.xml").write_text("\n".join(x) + "\n", encoding="utf-8")

print("কনট্রাস্ট:")
print("\n".join(report))
print(f"tokens.css {len(tokens_css)}B · ds.css {len(bundle.encode())}B · ds.js {len(js.encode())}B · pt_ds.xml লেখা হলো")
if errors:
    print("❌ কনট্রাস্ট কম:\n  " + "\n  ".join(errors))
    sys.exit(1)
print("✅ সব ঠিক")
