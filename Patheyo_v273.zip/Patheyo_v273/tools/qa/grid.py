import sys, os, re
from PIL import Image, ImageDraw, ImageFont
D=sys.argv[1]; pref=sys.argv[2]; out=sys.argv[3]; per=int(sys.argv[4]) if len(sys.argv)>4 else 8; filt=sys.argv[5] if len(sys.argv)>5 else ''
fs=sorted([f for f in os.listdir(D) if f.startswith(pref) and (not filt or re.search(filt,f))], key=lambda f: os.path.getmtime(os.path.join(D,f)))
ims=[Image.open(os.path.join(D,f)).convert('RGB') for f in fs]
if not ims: sys.exit('none')
w=ims[0].width//3; h=ims[0].height//3
cols=per; rows=(len(ims)+cols-1)//cols
S=Image.new('RGB',(cols*(w+6),rows*(h+22)),'white'); d=ImageDraw.Draw(S)
for i,(f,im) in enumerate(zip(fs,ims)):
    x=(i%cols)*(w+6); y=(i//cols)*(h+22)
    S.paste(im.resize((w,int(im.height*w/im.width))),(x,y+20)); d.text((x+2,y+3),f.replace(pref,'')[:30],fill='black')
S.save(out,quality=78); print(len(ims),'->',out, S.size)
