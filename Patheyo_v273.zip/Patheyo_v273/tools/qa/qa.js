/* লেখা-লেআউট পরীক্ষক — একটা ডকুমেন্টে চালানো হয়, সমস্যার তালিকা ফেরত দেয়।
   ধরে: (১) লেখা নিজের বাক্সের বাইরে উপচে পড়া (কাটা পড়া — ইচ্ছাকৃত "…" বাদে)
        (২) দুটো আলাদা লেখা একটার ওপর আরেকটা
        (৩) লেখা তার শেপের (গোল/ব্যাকগ্রাউন্ড/বর্ডারওয়ালা কার্ড, চিপ, বোতাম) বাইরে বেরিয়ে যাওয়া
        (৪) চাপা যায় এমন জিনিস ৪০px-এর ছোট (৪৪ লক্ষ্য; ৪০ সহনীয়)
        (৫) লেখা ও পটভূমির কনট্রাস্ট কম (< ৩:১ বড় লেখা, < ৪.৫:১ ছোট লেখা — ধূসর ছোট লেখায় ৩:১ পর্যন্ত সহনীয়)
        (৬) ১১px-এর ছোট লেখা */
(function () {
  var W = window, D = document, out = [];
  var vw = W.innerWidth, vh = W.innerHeight;
  function visible(el) {
    if (!el.getClientRects().length) return false;
    var cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || +cs.opacity === 0 || cs.display === 'none') return false;
    var p = el; while (p && p !== D.documentElement) { var c = getComputedStyle(p); if (+c.opacity === 0 || c.visibility === 'hidden') return false; if (p.hidden || p.getAttribute('aria-hidden') === 'true' && p.closest('[inert]')) return false; p = p.parentElement; }
    var r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return false;
    if (r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw) return false;   /* শুধু পর্দায় দেখা অংশ */
    return true;
  }
  function path(el) {
    var s = [], e = el, n = 0;
    while (e && e.nodeType === 1 && n < 4) {
      var t = e.tagName.toLowerCase();
      if (e.id) { s.unshift(t + '#' + e.id); break; }
      var c = (e.className && typeof e.className === 'string') ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '';
      s.unshift(t + c); e = e.parentElement; n++;
    }
    return s.join(' > ');
  }
  function txt(el) { return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 40); }
  /* হিট-টেস্টের জন্য সাময়িকভাবে সবকিছু চাপযোগ্য (pointer-events:none থাকলেও আসল আঁকার ক্রম পাওয়া যায়) */
  var qs = D.createElement('style'); qs.textContent = '*{pointer-events:auto !important}'; D.head.appendChild(qs);
  function onTop(el, r) {
    var pts = [[0.5, 0.5], [0.15, 0.5], [0.85, 0.5]], hit = 0, tot = 0;
    for (var i = 0; i < pts.length; i++) {
      var x = r.left + r.width * pts[i][0], y = r.top + r.height * pts[i][1];
      if (x < 0 || y < 0 || x >= vw || y >= vh) continue; tot++;
      var h = D.elementFromPoint(x, y); if (h && (el === h || el.contains(h))) hit++;
    }
    return tot > 0 && hit > 0;
  }
  /* লেখা আছে এমন "পাতা" এলিমেন্ট: নিজের সরাসরি টেক্সট-নোড আছে */
  var leaves = [];
  D.querySelectorAll('body *').forEach(function (el) {
    if (/^(SCRIPT|STYLE|SVG|PATH|G|DEFS|TEMPLATE|NOSCRIPT|OPTION)$/i.test(el.tagName)) return;
    if (el.closest('svg')) return;
    var own = false;
    for (var i = 0; i < el.childNodes.length; i++) { var n = el.childNodes[i]; if (n.nodeType === 3 && n.nodeValue.trim()) { own = true; break; } }
    if (own && visible(el)) leaves.push(el);
  });
  function textRect(el) {   /* আসল লেখার জায়গা (প্যাডিং নয়) */
    var rg = D.createRange(), rs = [];
    for (var i = 0; i < el.childNodes.length; i++) { var n = el.childNodes[i]; if (n.nodeType === 3 && n.nodeValue.trim()) { rg.selectNodeContents(n); var r = rg.getBoundingClientRect(); if (r.width && r.height) rs.push(r); } }
    if (!rs.length) return null;
    var L = Math.min.apply(0, rs.map(function (r) { return r.left; })), T = Math.min.apply(0, rs.map(function (r) { return r.top; })),
        R = Math.max.apply(0, rs.map(function (r) { return r.right; })), B = Math.max.apply(0, rs.map(function (r) { return r.bottom; }));
    return { left: L, top: T, right: R, bottom: B, width: R - L, height: B - T };
  }
  /* (২) লেখার ওপর লেখা */
  var tr = leaves.map(function (el) { return { el: el, r: textRect(el) }; }).filter(function (x) { return x.r && onTop(x.el, x.r); });
  var topSet = new Set(tr.map(function (x) { return x.el; }));
  /* (১) উপচে পড়া / কাটা */
  var tr0 = null;
  leaves.forEach(function (el) {
    if (!topSet.has(el)) return;
    var cs = getComputedStyle(el);
    var clipped = el.scrollWidth > el.clientWidth + 2 && el.clientWidth > 0;
    /* ভেতরে সরে-যাওয়া ঝলক (absolute) থাকলে scrollWidth বেড়ে যায় — আসল লেখা কাটে না */
    if (clipped) { var abs = false; el.querySelectorAll('*').forEach(function (c) { var p = getComputedStyle(c).position; if (p === 'absolute' || p === 'fixed') abs = true; }); var ps = getComputedStyle(el, '::before').position, pa = getComputedStyle(el, '::after').position; if (abs || ps === 'absolute' || pa === 'absolute') clipped = false; }
    var vclip = el.scrollHeight > el.clientHeight + 3 && el.clientHeight > 0 && cs.overflowY !== 'visible' && !cs.webkitLineClamp;
    var ell = cs.textOverflow === 'ellipsis' || (cs.webkitLineClamp && cs.webkitLineClamp !== 'none');
    if ((clipped && cs.overflowX !== 'visible' && !ell) || vclip)
      out.push({ k: 'কাটা', s: path(el), t: txt(el), d: el.scrollWidth + '>' + el.clientWidth });
    if (clipped && ell) out.push({ k: 'ছেঁটে-…', s: path(el), t: txt(el), d: el.scrollWidth + '>' + el.clientWidth });
    if (clipped && cs.overflowX === 'visible' && cs.whiteSpace === 'nowrap') out.push({ k: 'উপচে', s: path(el), t: txt(el), d: el.scrollWidth + '>' + el.clientWidth });
    var fs = parseFloat(cs.fontSize);
    if (fs < 11) out.push({ k: 'ছোট-লেখা', s: path(el), t: txt(el), d: fs + 'px' });
  });
  for (var i = 0; i < tr.length; i++) for (var j = i + 1; j < tr.length; j++) {
    var a = tr[i], b = tr[j];
    if (a.el.contains(b.el) || b.el.contains(a.el)) continue;
    var ix = Math.min(a.r.right, b.r.right) - Math.max(a.r.left, b.r.left), iy = Math.min(a.r.bottom, b.r.bottom) - Math.max(a.r.top, b.r.top);
    if (ix > 3 && iy > 4) {
      var za = getComputedStyle(a.el).position, zb = getComputedStyle(b.el).position;
      out.push({ k: 'ওভারল্যাপ', s: path(a.el) + '  ⟷  ' + path(b.el), t: txt(a.el) + ' | ' + txt(b.el), d: Math.round(ix) + 'x' + Math.round(iy) });
    }
  }
  /* (৩) শেপের বাইরে: লেখার সবচেয়ে কাছের "শেপ" পূর্বপুরুষ (ব্যাকগ্রাউন্ড/বর্ডার/গোল কোণ) */
  function isShape(p) {
    var c = getComputedStyle(p);
    var bg = c.backgroundColor && !/rgba\(0, 0, 0, 0\)|transparent/.test(c.backgroundColor);
    var bimg = c.backgroundImage && c.backgroundImage !== 'none';
    var bd = parseFloat(c.borderTopWidth) > 0 && !/rgba\(0, 0, 0, 0\)/.test(c.borderTopColor);
    return (bg || bimg || bd) && p !== D.body && p !== D.documentElement;
  }
  tr.forEach(function (x) {
    var p = x.el; while (p && p !== D.body && !isShape(p)) p = p.parentElement;
    if (!p || p === D.body) return;
    var r = p.getBoundingClientRect();
    if (r.width > vw * 0.98 && r.height > vh * 0.9) return;                        /* পুরো পেজের পটভূমি */
    var o = Math.max(r.left - x.r.left, x.r.right - r.right, r.top - x.r.top, x.r.bottom - r.bottom);
    if (o > 2) out.push({ k: 'শেপের-বাইরে', s: path(x.el) + '  ⊄  ' + path(p), t: txt(x.el), d: Math.round(o) + 'px' });
  });
  /* (৪) ছোট বোতাম */
  D.querySelectorAll('button, a[href], [role="button"], [role="tab"], input[type="checkbox"], .pt-switch, select').forEach(function (el) {
    if (!visible(el)) return;
    if (el.matches('input[type="checkbox"]') && el.closest('.pt-switch')) return;
    var r = el.getBoundingClientRect();
    if (!onTop(el, r)) return;
    if (r.width < 40 && r.height < 40 || Math.min(r.width, r.height) < 28) {
      /* ছোট হলেও যদি বড় চাপার জায়গার (লেবেল/সারির) ভেতরে থাকে তবে ঠিক */
      var pr = el.parentElement && el.parentElement.closest('label, .pt-row, .rm-row, .onb-rmr');
      if (pr) { var q = pr.getBoundingClientRect(); if (q.height >= 40) return; }
      out.push({ k: 'ছোট-বোতাম', s: path(el), t: txt(el) || el.getAttribute('aria-label') || '', d: Math.round(r.width) + 'x' + Math.round(r.height) });
    }
  });
  /* (৫) কনট্রাস্ট */
  function rgb(s) { var m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null; var p = m[1].split(',').map(parseFloat); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; }
  function lum(c) { function f(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); } return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); }
  function bgOf(el) {
    var p = el, layers = [];
    while (p) {
      var c = getComputedStyle(p);
      if (c.backgroundImage && c.backgroundImage !== 'none') return null;           /* গ্রেডিয়েন্ট/ছবি — নিশ্চিত নয়, বাদ */
      var b = rgb(c.backgroundColor); if (b && b.a > 0) { layers.push(b); if (b.a >= 0.99) break; }
      p = p.parentElement;
    }
    var base = { r: 255, g: 255, b: 255 };
    if (layers.length && layers[layers.length - 1].a >= 0.99) base = layers.pop();
    for (var i = layers.length - 1; i >= 0; i--) { var l = layers[i]; base = { r: l.r * l.a + base.r * (1 - l.a), g: l.g * l.a + base.g * (1 - l.a), b: l.b * l.a + base.b * (1 - l.a) }; }
    return base;
  }
  tr.forEach(function (x) {
    if (x.el.closest('.pt-seg, .dseg, #mode-tabs, .onb-seg')) return;      /* সক্রিয় বোতামের নীল "থাম্ব" আলাদা উপাদান — পটভূমি এখানে মাপা যায় না */
    var cs = getComputedStyle(x.el), fg = rgb(cs.color), bg = bgOf(x.el);
    if (!fg || !bg) return;
    var op = 1, p = x.el; while (p) { op *= +getComputedStyle(p).opacity; p = p.parentElement; }
    fg = { r: fg.r * fg.a * op + bg.r * (1 - fg.a * op), g: fg.g * fg.a * op + bg.g * (1 - fg.a * op), b: fg.b * fg.a * op + bg.b * (1 - fg.a * op) };
    var L1 = lum(fg), L2 = lum(bg), cr = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
    var fs = parseFloat(cs.fontSize), bold = +cs.fontWeight >= 600, large = fs >= 18.5 || (fs >= 14 && bold);
    var need = large ? 3 : 4.5;
    if (cr < need) out.push({ k: cr < 3 ? 'কনট্রাস্ট-খুব-কম' : 'কনট্রাস্ট-কম', s: path(x.el), t: txt(x.el), d: cr.toFixed(2) + ' (' + fs + 'px)' });
  });
  qs.remove();
  return out;
})()
