# সব পেজ × প্রস্থ × থিম — লেআউট পরীক্ষা চালানো ও স্ক্রিনশট
# ব্যবহার: python3 run.py [widths comma] [themes comma] [scene-filter]
import asyncio, os, mimetypes, json, sys, re
from playwright.async_api import async_playwright
ROOT=os.environ.get('ROOT','/home/claude/src/Patheyo_v167/app/src/main/assets'); HOST='https://appassets.patheyo.invalid/'
QA=open('/home/claude/tools/s13/qa.js').read()
OUT=os.environ.get('OUT','/home/claude/shots/s13'); os.makedirs(OUT,exist_ok=True)
WIDTHS=[int(x) for x in (sys.argv[1] if len(sys.argv)>1 else '320,360,390,412').split(',')]
THEMES=(sys.argv[2] if len(sys.argv)>2 else 'dark,light').split(',')
FILT=sys.argv[3] if len(sys.argv)>3 else ''
SHOTS=os.environ.get('SHOTS','1')=='1'
async def route(r):
    u=r.request.url
    if u.startswith(HOST):
        p=os.path.join(ROOT,u[len(HOST):].split('?')[0])
        if os.path.isfile(p): return await r.fulfill(path=p,headers={'content-type':mimetypes.guess_type(p)[0] or 'x'})
        return await r.fulfill(status=404,body='')
    if u.split(':')[0] in('data','blob','about'): return await r.continue_()
    return await r.abort()
SEED="""try{localStorage.setItem('pathey-theme','%(t)s');localStorage.setItem('ns_theme',JSON.stringify('%(t)s'));
['quran-theme','hadith-theme','dua_theme','tasbih_theme','amol_theme','qibla_theme'].forEach(function(k){localStorage.setItem(k,k=='dua_theme'?JSON.stringify('%(t)s'):'%(t)s')});
localStorage.setItem('pt_onboarded','1');
localStorage.setItem('lastKnownPrayerData',JSON.stringify({timings:{Fajr:'04:50',Sunrise:'06:05',Dhuhr:'11:43',Asr:'15:41',Sunset:'17:17',Maghrib:'17:17',Isha:'18:34'},isRamadan:false,lat:23.81,lng:90.41,locationName:'ঢাকা',temp:'27°C'}));
localStorage.setItem('amol_report_state',JSON.stringify({days:{'2026-11-06':{fajr:'jamaat',midday:'alone'},'2026-11-05':{fajr:'jamaat',midday:'jamaat',asr:'alone',maghrib:'jamaat',isha:'alone'}},soundOn:true}));
localStorage.setItem('quran-last-read',JSON.stringify({type:'sura',idx:18,label:'সূরা ১৮ — Al-Kahf',ayahIndex:10}));
localStorage.setItem('pt_zakat',JSON.stringify({unit:'v',basis:'auto',goldPrice:'198000',silverPrice:'2900',gold:'2.5',karat:22,silver:'',cash:'1250000',business:'340000',receivable:'',invest:'500000',debt:'60000'}));
}catch(e){}"""
# দৃশ্য: (নাম, প্রস্তুতি-JS (মূল পেজে), কোথায় পরীক্ষা: 'main' | 'f0'.., স্ক্রল-ধাপ সংখ্যা, স্ক্রল-জায়গা)
H=" __ptPages.home(); "
SCENES=[
 ('home',      H,                                                  'main', 4, 'win'),
 ('wq-sheet',  H+"document.querySelector('.waqt-pill').click();",  'main', 1, ''),
 ('settings',  H+"__ptPages.open('settings');",                    'main', 5, '#settings-overlay .page-overlay-body'),
 ('notif',     H+"__ptPages.open('notif');",                       'main', 1, ''),
 ('search',    H+"ptOpenSearch('');",                              'main', 1, ''),
 ('search-q',  H+"ptOpenSearch('রহমান');",                         'main', 2, '#search-overlay .page-overlay-body'),
 ('zakat',     H+"__ptPages.open('zakat');",                       'main', 4, '#zakat-overlay .page-overlay-body'),
 ('reminders', H+"ptOpenReminders();",                             'main', 1, ''),
 ('account',   H+"window.__ptAccountOpen&&__ptAccountOpen();",     'main', 1, ''),
 ('premium',   H+"ptOpenPremium('qa');",                           'main', 2, '#pw-sheet .pt-sheet__body'),
 ('namaz',     H+"__ptPages.open('f0');",                          'f0', 5, 'win'),
 ('quran',     H+"__ptPages.open('f1');",                          'f1', 3, 'win'),
 ('quran-read',H+"__ptGo('quran:18');",                            'f1', 2, 'win'),
 ('hadith',    H+"__ptPages.open('f2');",                          'f2', 3, 'win'),
 ('amol',      H+"__ptPages.open('f3');",                          'f3', 5, 'win'),
 ('dua',       H+"__ptPages.open('f4');",                          'f4', 3, 'win'),
 ('asma',      H+"__ptGo('dua:asma');",                            'f4', 2, 'win'),
 ('qibla',     H+"__ptPages.open('f5');",                          'f5', 3, 'win'),
 ('tasbih',    H+"__ptPages.open('f6');",                          'f6', 3, 'win'),
 ('widget',    H+"__ptPages.open('f7');",                          'f7', 5, 'win'),
]
ONB=[('onb1',0),('onb2',1),('onb3',2)]
async def frame_ready(pg,key):
    for _ in range(80):
        ok=await pg.evaluate("(k)=>{var w=__ptPages.frameWin(k);return !!(w&&w.document&&w.document.readyState==='complete'&&w.document.body&&w.document.body.children.length)}",key)
        if ok: return True
        await pg.wait_for_timeout(250)
    return False
async def qa(pg,where):
    if where=='main': return await pg.evaluate(QA)
    return await pg.evaluate("([k,c])=>{var w=__ptPages.frameWin(k);return w?w.eval(c):[{k:'ফ্রেম-নেই'}]}",[where,QA])
async def scroll(pg,where,sc,i):
    if sc=='win':
        if where=='main': await pg.evaluate(f"window.scrollTo(0,{i}*innerHeight*0.8)")
        else: await pg.evaluate("([k,i])=>{var w=__ptPages.frameWin(k);w.scrollTo(0,i*w.innerHeight*0.8)}",[where,i])
    elif sc:
        await pg.evaluate("([s,i])=>{var e=document.querySelector(s);if(e)e.scrollTop=i*e.clientHeight*0.8}",[sc,i])
async def main():
    res={}
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        for th in THEMES:
            for w in WIDTHS:
                c=await b.new_context(viewport={'width':w,'height':780 if w<380 else 844},device_scale_factor=2 if SHOTS else 1,timezone_id='Asia/Dhaka'); await c.route('**/*',route)
                await c.add_init_script(SEED%{'t':th})
                pg=await c.new_page(); errs=[]
                pg.on('pageerror',lambda e: errs.append(str(e)[:120]))
                await pg.clock.install(time='2026-11-06T13:20:00')
                await pg.goto(HOST+'index.html'); await pg.wait_for_timeout(3800)
                await pg.evaluate("for(var i=0;i<30;i++)history.pushState({qa:i},'')")   # পরীক্ষার জন্য: ব্রাউজারে index.html-এর আগে খালি পাতা থাকে, অ্যাপে থাকে না
                for name,prep,where,steps,sc in SCENES:
                    if FILT and not re.search(FILT,name): continue
                    try:
                        if not await pg.evaluate("typeof __ptPages!=='undefined'"):
                            await pg.goto(HOST+'index.html'); await pg.wait_for_timeout(3800); await pg.evaluate("for(var i=0;i<30;i++)history.pushState({qa:i},'')")
                        await pg.evaluate("try{PT.sheet.isOpen()&&PT.sheet.close()}catch(e){}"); await pg.wait_for_timeout(250)
                        await pg.evaluate(prep); await pg.wait_for_timeout(900)
                        if where!='main': await frame_ready(pg,where); await pg.wait_for_timeout(1800)
                        for i in range(steps):
                            await scroll(pg,where,sc,i); await pg.wait_for_timeout(450)
                            r=await qa(pg,where)
                            key=f'{th}-{w}-{name}-{i}'; res[key]=r
                            if SHOTS: await pg.screenshot(path=f'{OUT}/{key}.png')
                    except Exception as e:
                        res[f'{th}-{w}-{name}-ERR']=[{'k':'ত্রুটি','t':str(e)[:150]}]
                # অনবোর্ডিং
                if not FILT or re.search(FILT,'onb'):
                    await c.close(); c=await b.new_context(viewport={'width':w,'height':780 if w<380 else 844},device_scale_factor=2 if SHOTS else 1); await c.route('**/*',route)
                    await c.add_init_script(SEED%{'t':th}+";localStorage.removeItem('pt_onboarded');window.__ptForceOnb=true;")
                    pg=await c.new_page(); await pg.goto(HOST+'index.html'); await pg.wait_for_timeout(4200)
                    for name,step in ONB:
                        if step: await pg.click('#onb-next'); await pg.wait_for_timeout(700)
                        r=await pg.evaluate(QA); key=f'{th}-{w}-{name}-0'; res[key]=r
                        if SHOTS: await pg.screenshot(path=f'{OUT}/{key}.png')
                res[f'{th}-{w}-jserr']=[{'k':'JS-ত্রুটি','t':e} for e in errs]
                await c.close()
        await b.close()
    json.dump(res,open(os.environ.get('RES','/home/claude/tools/s13/res.json'),'w'),ensure_ascii=False,indent=0)
    from collections import Counter
    cnt=Counter(i['k'] for v in res.values() for i in v); print(dict(cnt))
asyncio.run(main())
