package com.gunjoron.patheyo.update

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object UpdateChecker {

    // আগের লিংক (যেমন ছিল তেমনই) — যদি আপনার রিপোতে এই ফাইল থাকে, সেটাও কাজ করবে।
    private const val UPDATE_JSON_URL =
        "https://patheyobygunjoron.github.io/docs/update.json"

    // v49: নতুন লিংক — GitHub Action নতুন রিলিজ দিলে নিজে থেকে এই ফাইল বানায় (ওয়েবসাইটের ফোল্ডারে)।
    private const val SITE_UPDATE_JSON_URL =
        "https://patheyobygunjoron.github.io/patheyo/data/update.json"

    private val SOURCES = listOf(UPDATE_JSON_URL, SITE_UPDATE_JSON_URL)

    /** বর্তমানে ইনস্টল থাকা অ্যাপের versionCode */
    fun installedVersionCode(ctx: Context): Long {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        return PackageInfoCompat.getLongVersionCode(pi)
    }

    /** ইনস্টল থাকা অ্যাপের versionName (যেমন 1.6.0) */
    fun installedVersionName(ctx: Context): String =
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Throwable) { "" }

    /** নতুন ভার্সন থাকলে UpdateInfo, না থাকলে (বা ইন্টারনেট সমস্যা হলে) null */
    suspend fun checkForUpdate(ctx: Context): UpdateInfo? {
        val info = fetchLatest(ctx) ?: return null
        return if (isNewer(ctx, info)) info else null
    }

    /**
     * সব সূত্র (দুটি ফাইল + পুশে পাওয়া তথ্য) থেকে সবচেয়ে নতুন ভার্সনটি। কিছুই না পেলে null।
     * (নতুন কি না সেটি এখানে দেখা হয় না — দেখতে [isNewer] ব্যবহার করুন)
     *
     * v151: দুই সূত্র একসাথে (parallel) টানা হয় — অ্যাপ খুলতেই পপআপ দ্রুত আসে। সার্ভার থেকে কিছু পেলে সেটিই
     * সত্য ধরে সেভ রাখা হয়; কিছুই না পেলে (অফলাইন/সার্ভার সমস্যা) শেষবার সেভ করা তথ্য ব্যবহার হয়।
     */
    suspend fun fetchLatest(ctx: Context): UpdateInfo? = coroutineScope {
        val fetched = SOURCES.map { u -> async { fetch(u) } }.awaitAll().filterNotNull()
        var best: UpdateInfo? = UpdatePrefs.getPushed(ctx)
        if (fetched.isNotEmpty()) {
            var server: UpdateInfo = fetched[0]
            // v154: একই ভার্সন দুই ফাইলে থাকলে (হাতে লেখা docs/update.json + অটো patheyo/data/update.json)
            // যেটায় নোট বেশি বড় (সম্পূর্ণ), সেটিই নেওয়া হয়
            for (c in fetched) {
                val cmp = compare(c, server)
                if (cmp > 0 || (cmp == 0 && c.releaseNotes.length > server.releaseNotes.length)) server = c
            }
            UpdatePrefs.saveLatest(ctx, server)
            if (best == null || compare(server, best) > 0) best = server
            else if (best != null && compare(server, best) == 0 && server.releaseNotes.length > best.releaseNotes.length) {
                // v154: পুশে আসা নোট কাটা (সংক্ষিপ্ত) থাকে; সার্ভারের পুরো নোট পেলে সেটিই ব্যবহার + সেভ
                best = best.copy(releaseNotes = server.releaseNotes)
                UpdatePrefs.savePushed(ctx, best)
            }
        } else {
            val saved = UpdatePrefs.getLatest(ctx)
            if (saved != null && (best == null || compare(saved, best) > 0)) best = saved
        }
        best
    }

    /**
     * v151: নেটওয়ার্ক ছাড়াই জানা নতুন ভার্সন (পুশে পাওয়া বা শেষবার সার্ভার থেকে সেভ করা) —
     * ইনস্টল করা ভার্সনের চেয়ে নতুন হলে। অ্যাপ খোলামাত্র পপআপ দেখানোর জন্য।
     */
    fun knownUpdate(ctx: Context): UpdateInfo? {
        val a = UpdatePrefs.getPushed(ctx)
        val b = UpdatePrefs.getLatest(ctx)
        return when {
            a == null -> b
            b == null -> a
            compare(a, b) >= 0 -> a
            else -> b
        }
    }

    /** দুটো [UpdateInfo] একই ভার্সনের কি না */
    fun sameVersion(a: UpdateInfo, b: UpdateInfo): Boolean = compare(a, b) == 0

    /** [info] ইনস্টল করা অ্যাপের চেয়ে নতুন কি না */
    fun isNewer(ctx: Context, info: UpdateInfo): Boolean =
        if (info.codeKnown) info.versionCode > installedVersionCode(ctx)
        else semverCompare(info.versionName, installedVersionName(ctx)) > 0

    fun compare(a: UpdateInfo, b: UpdateInfo): Int =
        if (a.codeKnown && b.codeKnown && a.versionCode != b.versionCode)
            a.versionCode.compareTo(b.versionCode)
        else semverCompare(a.versionName, b.versionName)

    /** "v1.6.0" / "1.10.2" ধরনের নাম তুলনা: ধনাত্মক = a নতুন */
    fun semverCompare(a: String, b: String): Int {
        fun parts(s: String) = Regex("\\d+").findAll(s).map { it.value.toLongOrNull() ?: 0L }.toList()
        val x = parts(a)
        val y = parts(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = (x.getOrElse(i) { 0L }).compareTo(y.getOrElse(i) { 0L })
            if (d != 0) return d
        }
        return 0
    }


    /**
     * v154: নোট থেকে শুধু শিরোনামগুলো (ইমোজি দিয়ে শুরু বা # দিয়ে লেখা লাইন) বের করে।
     * সিস্টেম নোটিফিকেশন বড় করলে এটিই দেখায় — পুরো নোট নয়। পুরো নোট পপআপ ও ইনবক্সে।
     */
    fun highlights(notes: String, max: Int = 8): String {
        val out = ArrayList<String>()
        for (raw in notes.split('\n')) {
            val l = raw.trim()
            if (l.isEmpty() || l.all { it == '-' || it == '=' || it == '_' || it == '*' }) continue
            val first = l[0]
            val bullet = "•·●○◦▪-–—*".indexOf(first) >= 0
            val isHeading = !bullet && !first.isLetterOrDigit()   // ইমোজি/চিহ্ন দিয়ে শুরু = শিরোনাম
            if (isHeading) out.add(l.trimStart('#', ' '))
            if (out.size >= max) break
        }
        if (out.isEmpty()) {   // শিরোনাম না থাকলে প্রথম কয়েকটা পয়েন্ট
            for (raw in notes.split('\n')) {
                val l = raw.trim().trimStart('•', '·', '-', '*', ' ')
                if (l.isNotEmpty()) out.add("• " + l.take(60))
                if (out.size >= 4) break
            }
        }
        return out.joinToString("\n")
    }

    /**
     * v154: পুশের পর ব্যাকগ্রাউন্ডে সার্ভার থেকে পুরো নোট এনে পপআপ ও ইনবক্স হালনাগাদ করে।
     * (পুশে ৪KB সীমার কারণে নোট কাটা থাকে।) নেট না থাকলে চুপচাপ কিছু করে না — কাটা নোটই থাকে।
     */
    suspend fun refreshFullNotes(ctx: Context, info: UpdateInfo) {
        val server = SOURCES.map { fetch(it) }.filterNotNull()
            .filter { compare(it, info) == 0 && it.releaseNotes.length > info.releaseNotes.length }
            .maxByOrNull { it.releaseNotes.length } ?: return
        val updated = info.copy(releaseNotes = server.releaseNotes)
        UpdatePrefs.savePushed(ctx, updated)
        UpdatePrefs.saveLatest(ctx, updated)
        try { com.gunjoron.patheyo.notification.NotificationInbox.addUpdate(ctx, updated) } catch (_: Throwable) {}
    }

    /** versionName থেকে প্রম্পট-হিসাবের জন্য একটি সংখ্যা (যেমন 1.6.0 → 10600) */
    private fun nameKey(name: String): Long {
        val p = Regex("\\d+").findAll(name).map { it.value.toLongOrNull() ?: 0L }.toList()
        return p.getOrElse(0) { 0L } * 10000 + p.getOrElse(1) { 0L } * 100 + p.getOrElse(2) { 0L }
    }

    /** FCM পুশ বা অন্য সূত্র থেকে নামসহ UpdateInfo বানাতে (আসল versionCode না থাকলে) */
    fun infoFromName(name: String, apkUrl: String, notes: String, sizeMb: Int, mandatory: Boolean): UpdateInfo =
        UpdateInfo(nameKey(name), name, apkUrl, notes, sizeMb, mandatory, codeKnown = false)

    private suspend fun fetch(url: String): UpdateInfo? = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            // ?t=... দিয়ে ক্যাশ এড়ানো হচ্ছে
            conn = (URL("$url?t=${System.currentTimeMillis()}")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 8_000
                useCaches = false
                setRequestProperty("Cache-Control", "no-cache")
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) return@withContext null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun parse(json: String): UpdateInfo? = try {
        val o = JSONObject(json)
        // v154: নতুন ফিল্ড release_notes_text = পুরো নোট (শিরোনাম + পয়েন্ট, কোনো সীমা ছাড়া)।
        // না থাকলে (পুরনো update.json) আগের release_notes অ্যারে/স্ট্রিং-ই কাজ করবে।
        val full = o.optString("release_notes_text", "").trim()
        val notes = if (full.isNotEmpty()) full else when (val n = o.opt("release_notes")) {
            is JSONArray -> (0 until n.length()).joinToString("\n") { "•  " + n.getString(it) }
            is String -> n
            else -> ""
        }
        val name = o.getString("versionName")
        val apk = o.getString("apk_url")
        val code = o.optLong("versionCode", 0L)
        if (code > 0L) {
            UpdateInfo(code, name, apk, notes, o.optInt("size_mb", 0), o.optBoolean("mandatory", false))
        } else {
            infoFromName(name, apk, notes, o.optInt("size_mb", 0), o.optBoolean("mandatory", false))
        }
    } catch (e: Exception) {
        null
    }
}
