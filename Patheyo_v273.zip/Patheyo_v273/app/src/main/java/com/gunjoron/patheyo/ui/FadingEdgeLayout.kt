package com.gunjoron.patheyo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.FrameLayout
import android.widget.ScrollView

/**
 * v39: ভেতরের ScrollView-র লেখা নিচের দিকে ধীরে ধীরে মিলিয়ে যায় (হার্ড কাট নেই) —
 * মনে হয় লেখা গ্লাসের ভেতর থেকে উঠে আসছে।
 *  • নিচে আরও লেখা থাকলে → নিচের প্রান্তে নরম ফেড (বেশি লম্বা)
 *  • ওপরে স্ক্রল হয়ে গেলে → ওপরের প্রান্তেও হালকা ফেড (স্ক্রল করার সাথে সাথে ধীরে ফুটে ওঠে)
 *  • সব লেখা এঁটে গেলে বা শেষে পৌঁছালে → কোনো ফেড নেই, লেখা পুরো স্পষ্ট
 * ব্যবহার: ScrollView-কে এই লেআউটের ভেতরে রাখুন।
 */
class FadingEdgeLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val density = resources.displayMetrics.density
    private val bottomFade = 84f * density
    private val topFade = 36f * density

    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private var bottomShader: Shader? = null
    private var shaderForHeight = -1

    // smoothstep: 1 → 0, মাঝখানে নরম ঢাল (সরাসরি লিনিয়ার ফেডের চেয়ে অনেক মসৃণ)
    private val stops = floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
    private val alphas = floatArrayOf(1f, 0.84f, 0.5f, 0.16f, 0f)

    private fun scroller(): ScrollView? = (0 until childCount).map { getChildAt(it) }.filterIsInstance<ScrollView>().firstOrNull()

    override fun onFinishInflate() {
        super.onFinishInflate()
        scroller()?.setOnScrollChangeListener { _, _, _, _, _ -> invalidate() }
    }

    override fun dispatchDraw(canvas: Canvas) {
        val sv = scroller()
        val canDown = sv?.canScrollVertically(1) == true
        val canUp = sv?.canScrollVertically(-1) == true
        if (sv == null || (!canDown && !canUp)) { super.dispatchDraw(canvas); return }

        val w = width.toFloat(); val h = height.toFloat()
        val layer = canvas.saveLayer(0f, 0f, w, h, null)
        super.dispatchDraw(canvas)

        if (canDown) {
            val top = (h - bottomFade).coerceAtLeast(0f)
            if (bottomShader == null || shaderForHeight != height) {
                bottomShader = LinearGradient(
                    0f, top, 0f, h,
                    IntArray(stops.size) { Color.argb((alphas[it] * 255).toInt(), 255, 255, 255) },
                    stops, Shader.TileMode.CLAMP
                )
                shaderForHeight = height
            }
            maskPaint.shader = bottomShader
            canvas.drawRect(0f, top, w, h, maskPaint)
        }
        if (canUp) {
            // স্ক্রল যত বাড়ে, ওপরের ফেড তত পূর্ণ হয়
            val strength = (sv.scrollY / topFade).coerceIn(0f, 1f)
            val a0 = ((1f - strength) * 255).toInt()
            maskPaint.shader = LinearGradient(
                0f, 0f, 0f, topFade,
                intArrayOf(Color.argb(a0, 255, 255, 255), Color.argb(a0 + ((255 - a0) * 0.5f).toInt(), 255, 255, 255), Color.WHITE),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, w, topFade.coerceAtMost(h), maskPaint)
        }
        maskPaint.shader = null
        canvas.restoreToCount(layer)
    }
}
