package com.gunjoron.patheyo.update

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.withStarted
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.notification.NotificationInbox
import kotlinx.coroutines.launch

/** MainActivity থেকে শুধু এই অবজেক্টের ২টি ফাংশন কল করলেই চলবে */
object UpdateManager {

    /** এখন স্ক্রিনে থাকা আপডেট পপআপ ও তার মালিক অ্যাক্টিভিটি/তথ্য (এক সময়ে একটাই) */
    private var currentDialog: AlertDialog? = null
    private var dialogOwner: java.lang.ref.WeakReference<Activity>? = null
    private var dialogInfo: UpdateInfo? = null

    private fun isShowing(): Boolean = currentDialog?.isShowing == true

    /**
     * Activity-র onStart()-এ কল করুন।
     *
     * ✅ v151: কোনো সময়সূচি/সীমা নেই — নতুন ভার্সন থাকলে প্রতিবার দেখায়:
     *   • অ্যাপ কেটে (সোয়াইপ করে বন্ধ করে) আবার ঢুকলে
     *   • মিনিমাইজ করে বেরিয়ে আবার অ্যাপে ফিরলে (onStart ফের চলে)
     * "পরে করব" চাপলে বা বাইরে ট্যাপ করলে পরের বার ঢোকার সময় আবার আসবে। ইউজার আপডেট না করা পর্যন্ত।
     *
     * গতি: আগে থেকে জানা নতুন ভার্সন থাকলে (পুশ/শেষবারের সার্ভার তথ্য) নেটওয়ার্কের অপেক্ষা ছাড়াই সাথে সাথে
     * পপআপ আসে; একই সময়ে সার্ভার থেকে সর্বশেষ তথ্য এনে সেভ রাখা হয় (ইন্টারনেট না থাকলেও যেন ঠিক চলে)।
     */
    fun checkAndPrompt(activity: AppCompatActivity) {
        val app = activity.applicationContext
        // "অজানা সোর্স" সেটিংস থেকে ফিরছে → resumePending() ডাউনলোড চালাবে, মাঝখানে নতুন পপআপ নয়
        if (UpdatePrefs.hasPending(app)) return
        activity.lifecycleScope.launch {
            // আগে থেকে জানা তথ্য: সাথে সাথে দেখাও
            val known = try { UpdateChecker.knownUpdate(app) } catch (_: Throwable) { null }
            var shownNow: UpdateInfo? = null          // এই এক-বারের চেকে যেটি দেখানো হয়েছে
            if (known != null && presentIfPossible(activity, known)) shownNow = known

            // সার্ভার থেকে সর্বশেষ (এটিই সত্য)
            val latest = (try { UpdateChecker.checkForUpdate(app) } catch (_: Throwable) { null }) ?: return@launch
            try { NotificationInbox.addUpdate(app, latest) } catch (_: Throwable) {}

            val shown = shownNow
            if (shown == null) {
                presentIfPossible(activity, latest)                    // এখনো কিছু দেখানো হয়নি
            } else if ((!UpdateChecker.sameVersion(shown, latest) || latest.releaseNotes.length > shown.releaseNotes.length) &&
                isShowing() && dialogOwner?.get() === activity) {
                // v154: একই ভার্সনের পুরো নোট এলে (শুরুতে কাটা নোট দেখানো হয়ে থাকলে) পপআপ সম্পূর্ণ নোটে বদলে যায়
                // পপআপ চলাকালীন সার্ভারে আরও নতুন ভার্সন পাওয়া গেল → পপআপ তার তথ্যে বদলে দেওয়া
                // (ইউজার ইতিমধ্যে বন্ধ করে দিলে আর জোর করে খোলা হয় না — পরের বার ঢুকলে নতুনটা আসবে)
                try { currentDialog?.dismiss() } catch (_: Throwable) {}
                presentIfPossible(activity, latest)
            }
        }
    }

    /** অ্যাক্টিভিটি এখনো সামনে/জীবিত থাকলে এবং অন্য পপআপ না থাকলে দেখায়। দেখালে true */
    private fun presentIfPossible(activity: AppCompatActivity, info: UpdateInfo): Boolean {
        if (isShowing()) return false
        if (activity.isFinishing || activity.isDestroyed) return false
        if (!activity.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) return false
        UpdatePrefs.consumeNotificationPending(activity.applicationContext)   // নোটিফিকেশন-ট্যাপের ফ্ল্যাগ সাফ
        return showDialog(activity, info)
    }

    /** Activity-র onDestroy()-এ কল করুন — খোলা পপআপ থাকলে বন্ধ করে (লিক/আটকে-থাকা অবস্থা এড়াতে) */
    fun onActivityDestroyed(activity: Activity) {
        if (dialogOwner?.get() === activity) {
            try { currentDialog?.dismiss() } catch (_: Throwable) {}
            currentDialog = null
            dialogOwner = null
            dialogInfo = null
        }
    }

    /**
     * v49: ওয়েবসাইটের "অ্যাপ আপডেট করুন" বাটন (patheyo://update লিংক) থেকে অ্যাপ খুললে এটি চলে।
     * সাধারণ চেকের মতো দিনে-২বারের সীমা মানে না — সাথে সাথে চেক করে ফল দেখায়:
     * নতুন ভার্সন থাকলে আপডেট পপআপ, না থাকলে "সর্বশেষ ভার্সনে আছেন" বার্তা।
     */
    fun checkNow(activity: AppCompatActivity) {
        val app = activity.applicationContext
        activity.lifecycleScope.launch {
            val latest = UpdateChecker.fetchLatest(app)
            if (activity.isFinishing || activity.isDestroyed) return@launch
            if (latest == null) {
                Toast.makeText(app, R.string.update_check_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (!UpdateChecker.isNewer(app, latest)) {
                Toast.makeText(app, R.string.update_latest_already, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (isShowing()) return@launch
            try {
                activity.lifecycle.withStarted { }      // অ্যাপ পুরোপুরি সামনে আসা পর্যন্ত অপেক্ষা
                if (!isShowing() && !activity.isFinishing && !activity.isDestroyed) showDialog(activity, latest)
            } catch (t: Throwable) {
                android.util.Log.e("PatheyoSafe", "checkNow failed", t)
            }
        }
    }

    /** Activity-র onResume()-এ কল করুন ("অজানা সোর্স" সেটিংস থেকে ফিরে এলে ডাউনলোড চালু করতে) */
    fun resumePending(activity: Activity) {
        val ctx = activity.applicationContext
        val (url, name) = UpdatePrefs.takePending(ctx) ?: return
        if (UpdateDownloader.canInstall(ctx)) beginDownload(activity, url, name)
    }

    private fun showDialog(activity: Activity, info: UpdateInfo): Boolean {
        UpdatePrefs.markPrompted(activity.applicationContext, info)
        // v47: পপআপ বানাতে সমস্যা হলে (lifecycleScope-এর ভেতরে) ক্র্যাশ না করে শুধু বন্ধ রাখা
        return try {
            val d = UpdateDialog.show(
                activity, info,
                onUpdate = { startUpdate(activity, info.apkUrl, info.versionName) },
                onDismiss = {
                    // শুধু নিজের পপআপ হলেই সাফ করা (বদলানো-পপআপের পুরনোটার dismiss যেন নতুনটাকে না মোছে)
                    if (dialogInfo === info) { currentDialog = null; dialogOwner = null; dialogInfo = null }
                }
            )
            currentDialog = d
            dialogOwner = java.lang.ref.WeakReference(activity)
            dialogInfo = info
            true
        } catch (t: Throwable) {
            currentDialog = null; dialogOwner = null; dialogInfo = null
            android.util.Log.e("PatheyoSafe", "update popup failed", t)
            false
        }
    }

    private fun startUpdate(activity: Activity, url: String, name: String) {
        val ctx = activity.applicationContext
        if (UpdateDownloader.canInstall(ctx)) {
            beginDownload(activity, url, name)
            return
        }
        // "অজানা অ্যাপ ইনস্টল" পারমিশন নেই → বুঝিয়ে সেটিংসে পাঠানো
        AlertDialog.Builder(activity)
            .setTitle(R.string.update_perm_title)
            .setMessage(R.string.update_perm_msg)
            .setPositiveButton(R.string.update_perm_go) { _, _ ->
                UpdatePrefs.savePending(ctx, url, name)
                activity.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                )
            }
            .setNegativeButton(R.string.update_perm_cancel, null)
            .show()
    }

    private fun beginDownload(activity: Activity, url: String, name: String) {
        val ctx = activity.applicationContext
        if (UpdateDownloader.isDownloading(ctx)) {
            Toast.makeText(ctx, R.string.update_already_downloading, Toast.LENGTH_SHORT).show()
            return
        }
        UpdateDownloader.start(ctx, url, name)
        Toast.makeText(ctx, R.string.update_downloading, Toast.LENGTH_LONG).show()
    }
}
