package com.gunjoron.patheyo.notification

// app/src/main/java/com/gunjoron/Patheyo/notification/NotificationConfigLoader.kt
//
// assets/notifications_config.json ফাইল থেকে সব নোটিফিকেশন লোড করে।
// এই ফাইলটাই এখন নোটিফিকেশনের একমাত্র উৎস — নতুন করে অ্যাপ বিল্ড দিলে JSON-এ
// যা যা লেখা থাকবে ঠিক তা-ই কার্যকর হবে। বাংলা নির্দেশিকা দেখুন:
// NOTIFICATION_JSON_NIRDESHIKA.md (প্রজেক্টের রুট ফোল্ডারে)

import android.content.Context
import android.util.Log
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

// ✅ পুরনো IslamicNotification ডেটা ক্লাসের জায়গায় এখন link ও imageRef যোগ করা হলো
// ✅ v2: "annual_bengali" (বাংলা মাস/ঋতু) ও "annual_gregorian" (ইংরেজি ক্যালেন্ডার/জাতীয় দিবস)
//    টাইপ যোগ হলো — এই দুটোর জন্য আলাদা ফিল্ড (bengaliMonth/bengaliDays, gregorianMonth/gregorianDays)
//    ব্যবহার করা হয়, যাতে হিজরি month/days-এর সাথে গুলিয়ে না যায়।
data class IslamicNotification(
    val id: String,
    val enabled: Boolean = true,
    val type: String, // "weekly" | "daily" | "monthly_hijri" | "monthly_hijri_last3" | "annual_hijri" | "annual_bengali" | "annual_gregorian"
    val daysOfWeek: List<Int>? = null,
    val month: Int? = null,          // শুধু হিজরি টাইপের জন্য (hijri_month)
    val days: List<Int>? = null,     // শুধু হিজরি টাইপের জন্য (hijri_days)
    val bengaliMonth: Int? = null,   // শুধু annual_bengali টাইপের জন্য (১=বৈশাখ ... ১২=চৈত্র)
    val bengaliDays: List<Int>? = null,
    val season: String = "",         // শুধু annual_bengali টাইপের জন্য (তথ্যগত, শিডিউলিং-এ ব্যবহৃত হয় না)
    val gregorianMonth: Int? = null, // শুধু annual_gregorian টাইপের জন্য (১=জানুয়ারি ... ১২=ডিসেম্বর)
    val gregorianDays: List<Int>? = null,
    // "fixed" | "sunrise" | "sunset" | "morning" (সকাল ৮:০০) | পুরনো: "fajr" (সূর্যোদয়-৩০মি) | "maghrib" (সূর্যাস্ত+৩০মি)
    val timeRef: String = "maghrib",
    val fixedHour: Int? = null,
    val fixedMinute: Int? = null,
    // ✅ v43: "sunrise"/"sunset" টাইমরেফের সাথে যোগ/বিয়োগ করার মিনিট (যেমন সূর্যাস্ত + ২ মিনিট)
    val offsetMinutes: Int = 0,
    // ✅ v43: হিজরি টাইপের জন্য — আরবি দিন সূর্যাস্তে শুরু হয়, তাই তারিখ N-এর কোন অংশে নোটিফিকেশন আসবে:
    //   "night" = N তারিখের রাত (আগের দিনের সূর্যাস্তের পর শুরু হওয়া রাত)
    //   "day"   = N তারিখের দিনের বেলা (সূর্যোদয় থেকে সূর্যাস্ত)
    //   "dusk"  = N তারিখের দিনের শেষে সূর্যাস্তের সময় (অর্থাৎ N+১ তারিখের রাত শুরুর মুহূর্ত; মাস ২৯/৩০ দিন হলেও কাজ করে)
    //   খালি থাকলে (পুরনো কনফিগ): timeRef "maghrib" হলে "dusk", নাহলে "day"
    val phase: String = "",
    // ✅ v43: কোন কোন হিজরি মাস/তারিখে এই নোটিফিকেশন আসবে না (days না দিলে পুরো মাস বাদ)
    val skipHijri: List<HijriSkip>? = null,
    val title: String,
    val message: String,
    val source: String = "",
    val link: String = "",     // নোটিফিকেশনে ক্লিক করলে এই লিংক খুলবে (খালি হলে কিছু হবে না)
    val image: String = ""     // assets/notification_images/ ফোল্ডারের ফাইলের নাম, অথবা সম্পূর্ণ https লিংক
)

data class HijriSkip(val month: Int, val days: List<Int>? = null)

object NotificationConfigLoader {

    private const val ASSET_FILE = "notifications_config.json"
    private const val TAG = "NotificationConfig"

    private val BN_DAY_TO_CALENDAR = mapOf(
        "রবিবার" to Calendar.SUNDAY,
        "সোমবার" to Calendar.MONDAY,
        "মঙ্গলবার" to Calendar.TUESDAY,
        "বুধবার" to Calendar.WEDNESDAY,
        "বৃহস্পতিবার" to Calendar.THURSDAY,
        "শুক্রবার" to Calendar.FRIDAY,
        "শনিবার" to Calendar.SATURDAY
    )

    private var cache: List<IslamicNotification>? = null
    private var cachedFromFallback = false

    /**
     * assets/notifications_config.json পার্স করে সব নোটিফিকেশনের লিস্ট রিটার্ন করে।
     * একবার লোড হলে মেমরিতে ক্যাশ থাকে (পারফরম্যান্সের জন্য); ফাইল বদলে অ্যাপ রিস্টার্ট
     * করলে নতুন করে লোড হবে।
     */
    fun load(context: Context): List<IslamicNotification> {
        cache?.let { return it }

        // ১) Firebase Remote Config থেকে ক্যাশ করা JSON — থাকলে ও বৈধ হলে সর্বোচ্চ অগ্রাধিকার
        //    (এভাবেই রিবিল্ড ছাড়া নোটিফিকেশন কনফিগ বদলানো সম্ভব হয়)
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val remoteJson = prefs.getString(NotificationRemoteConfigSync.PREF_KEY_CACHED_REMOTE_JSON, null)
        if (!remoteJson.isNullOrBlank()) {
            try {
                val parsedRemote = parse(remoteJson)
                if (parsedRemote.isNotEmpty()) {
                    cachedFromFallback = false
                    cache = parsedRemote
                    return parsedRemote
                }
            } catch (e: Exception) {
                Log.e(TAG, "Remote Config ক্যাশ পার্স করা যায়নি, বান্ডেল করা JSON চেষ্টা করা হচ্ছে", e)
            }
        }

        // ২) assets/notifications_config.json (অ্যাপে বান্ডেল করা)
        val result = try {
            val jsonStr = context.assets.open(ASSET_FILE).bufferedReader(Charsets.UTF_8).use { it.readText() }
            parse(jsonStr)
        } catch (e: Exception) {
            Log.e(TAG, "notifications_config.json পড়তে সমস্যা হয়েছে, ফলব্যাক ডেটাসেট ব্যবহার হচ্ছে", e)
            cachedFromFallback = true
            NotificationDataset.items
        }

        cache = result
        return result
    }

    /** টেস্টিং বা রিফ্রেশের জন্য ক্যাশ খালি করা */
    fun clearCache() {
        cache = null
        cachedFromFallback = false
    }

    fun wasLoadedFromFallback(): Boolean = cachedFromFallback

    private fun parse(jsonStr: String): List<IslamicNotification> {
        val root = JSONObject(jsonStr)
        val arr: JSONArray = root.optJSONArray("notifications") ?: JSONArray()
        val list = mutableListOf<IslamicNotification>()

        for (i in 0 until arr.length()) {
            try {
                val o = arr.getJSONObject(i)

                val daysOfWeekArr = o.optJSONArray("days_of_week")
                val daysOfWeek: List<Int>? = if (daysOfWeekArr != null && daysOfWeekArr.length() > 0) {
                    (0 until daysOfWeekArr.length()).mapNotNull { idx ->
                        BN_DAY_TO_CALENDAR[daysOfWeekArr.optString(idx)]
                    }
                } else null

                val hijriDaysArr = o.optJSONArray("hijri_days")
                val hijriDays: List<Int>? = if (hijriDaysArr != null && hijriDaysArr.length() > 0) {
                    (0 until hijriDaysArr.length()).map { idx -> hijriDaysArr.optInt(idx) }
                } else null

                val triggerType = o.getString("trigger_type")

                // ✅ v2: annual_bengali → bengali_month / bengali_days
                val bengaliDaysArr = o.optJSONArray("bengali_days")
                val bengaliDays: List<Int>? = if (bengaliDaysArr != null && bengaliDaysArr.length() > 0) {
                    (0 until bengaliDaysArr.length()).map { idx -> bengaliDaysArr.optInt(idx) }
                } else null
                val bengaliMonth: Int? = if (!o.has("bengali_month") || o.isNull("bengali_month")) null
                    else o.optInt("bengali_month")

                // ✅ v2: annual_gregorian → month / days (হিজরির hijri_month/hijri_days থেকে ভিন্ন কী)
                //    শুধুমাত্র trigger_type == "annual_gregorian" হলেই এই ফিল্ড দুটো পড়া হয়, যাতে
                //    ভুলবশত অন্য টাইপের সাথে না গুলিয়ে যায়
                var gregorianMonth: Int? = null
                var gregorianDays: List<Int>? = null
                if (triggerType == "annual_gregorian") {
                    gregorianMonth = if (!o.has("month") || o.isNull("month")) null else o.optInt("month")
                    val gDaysArr = o.optJSONArray("days")
                    gregorianDays = if (gDaysArr != null && gDaysArr.length() > 0) {
                        (0 until gDaysArr.length()).map { idx -> gDaysArr.optInt(idx) }
                    } else null
                }

                val fixedTimeStr = o.optString("fixed_time", "")
                var fixedHour: Int? = null
                var fixedMinute: Int? = null
                if (fixedTimeStr.isNotBlank() && fixedTimeStr.contains(":")) {
                    val p = fixedTimeStr.split(":")
                    fixedHour = p.getOrNull(0)?.toIntOrNull()
                    fixedMinute = p.getOrNull(1)?.toIntOrNull()
                }

                // ✅ v43: skip_hijri → [{"month": 9}, {"month": 12, "days": [13]}]
                val skipArr = o.optJSONArray("skip_hijri")
                val skipHijri: List<HijriSkip>? = if (skipArr != null && skipArr.length() > 0) {
                    (0 until skipArr.length()).mapNotNull { idx ->
                        val so = skipArr.optJSONObject(idx) ?: return@mapNotNull null
                        val sm = so.optInt("month", 0)
                        if (sm !in 1..12) return@mapNotNull null
                        val sDaysArr = so.optJSONArray("days")
                        val sDays: List<Int>? = if (sDaysArr != null && sDaysArr.length() > 0) {
                            (0 until sDaysArr.length()).map { k -> sDaysArr.optInt(k) }
                        } else null
                        HijriSkip(sm, sDays)
                    }
                } else null

                list.add(
                    IslamicNotification(
                        id = o.getString("id"),
                        enabled = o.optBoolean("enabled", true),
                        type = triggerType,
                        daysOfWeek = daysOfWeek,
                        month = if (o.isNull("hijri_month")) null else o.optInt("hijri_month"),
                        days = hijriDays,
                        bengaliMonth = bengaliMonth,
                        bengaliDays = bengaliDays,
                        season = o.optString("season", ""),
                        gregorianMonth = gregorianMonth,
                        gregorianDays = gregorianDays,
                        timeRef = o.optString("time_ref", "maghrib"),
                        fixedHour = fixedHour,
                        fixedMinute = fixedMinute,
                        offsetMinutes = o.optInt("offset_minutes", 0),
                        phase = o.optString("phase", ""),
                        skipHijri = skipHijri,
                        title = o.getString("title"),
                        message = o.getString("message"),
                        source = o.optString("source", ""),
                        link = o.optString("link", ""),
                        image = o.optString("image", "")
                    )
                )
            } catch (e: Exception) {
                Log.e(TAG, "notifications_config.json-এর ${i} নম্বর এন্ট্রি পার্স করা যায়নি, বাদ দেওয়া হলো", e)
            }
        }
        return list
    }
}
