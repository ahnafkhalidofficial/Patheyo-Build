package com.gunjoron.patheyo.backup

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

/**
 * ✅ v165: পুরো-অ্যাপ ব্যাকআপ ও রিস্টোর (সেটিংস → ব্যাকআপ ও রিস্টোর)।
 *
 * কেন নেটিভ লাগে: অ্যাপের WebView-তে ফাইল-পিকার (<input type=file>) ও ব্রাউজারের ডাউনলোড (blob/a[download]) চালু নেই,
 * তাই JS একা ফাইল সেভ বা বাছাই করতে পারে না। এই ব্রিজ সেই তিনটা কাজ করে দেয়:
 *   saveFile  → ফোনের Downloads/Patheyo ফোল্ডারে JSON ফাইল সেভ (Android 10+; এর নিচে canSave() false)
 *   shareFile → শেয়ার-শিটে ফাইল পাঠানো (Telegram / Drive / Gmail / WhatsApp…) — সব Android ভার্সনে
 *   pickFile  → সিস্টেম ডকুমেন্ট-পিকার খোলে; বাছা ফাইলের লেখা window.__ptBackupPicked(text, name, err)-এ ফেরত
 * JS-এ নাম: PatheyoBackup (MainActivity দেখুন)। কোনো ইন্টারনেট/পারমিশন লাগে না।
 */
class BackupBridge(
    private val activity: Activity,
    private val webView: WebView,
    private val launchPicker: () -> Unit
) {
    private val tag = "PatheyoBackup"
    private val maxBytes = 12 * 1024 * 1024

    private fun safeName(name: String): String =
        name.replace(Regex("[^A-Za-z0-9_\\-.]"), "_").ifBlank { "patheyo_backup.json" }

    @JavascriptInterface
    fun canSave(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    /** সফল হলে মানুষের পড়ার মতো জায়গার নাম (যেমন "Downloads/Patheyo/xxx.json"), ব্যর্থ হলে "" */
    @JavascriptInterface
    fun saveFile(name: String, text: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return ""
        return try {
            val fileName = safeName(name)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Patheyo")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = activity.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return ""
            resolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: return ""
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "Downloads/Patheyo/$fileName"
        } catch (t: Throwable) {
            Log.w(tag, "saveFile failed", t)
            ""
        }
    }

    @JavascriptInterface
    fun shareFile(name: String, text: String): Boolean {
        return try {
            val dir = File(activity.cacheDir, "share").apply { mkdirs() }
            val file = File(dir, safeName(name))
            file.writeText(text, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "পাথেয় ব্যাকআপ")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(send, "ব্যাকআপ ফাইল পাঠান").apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.runOnUiThread {
                try { activity.startActivity(chooser) } catch (t: Throwable) { Log.w(tag, "chooser failed", t) }
            }
            true
        } catch (t: Throwable) {
            Log.w(tag, "shareFile failed", t)
            false
        }
    }

    @JavascriptInterface
    fun pickFile(): Boolean {
        return try {
            activity.runOnUiThread {
                try { launchPicker() } catch (t: Throwable) { deliver("", "", "picker") }
            }
            true
        } catch (t: Throwable) {
            Log.w(tag, "pickFile failed", t)
            false
        }
    }

    /** MainActivity-র ফাইল-পিকারের ফলাফল এখানে আসে (মূল থ্রেডে) */
    fun onPicked(uri: Uri?) {
        if (uri == null) { deliver("", "", "cancel"); return }
        Thread {
            try {
                var name = "backup.json"
                try {
                    activity.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
                    }
                } catch (_: Throwable) {}
                val bytes = activity.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) { deliver("", name, "read"); return@Thread }
                if (bytes.size > maxBytes) { deliver("", name, "big"); return@Thread }
                deliver(String(bytes, Charsets.UTF_8), name, "")
            } catch (t: Throwable) {
                Log.w(tag, "onPicked failed", t)
                deliver("", "", "read")
            }
        }.start()
    }

    private fun deliver(text: String, name: String, err: String) {
        val js = "window.__ptBackupPicked && window.__ptBackupPicked(" +
            JSONObject.quote(text) + "," + JSONObject.quote(name) + "," + JSONObject.quote(err) + ")"
        activity.runOnUiThread {
            try { webView.evaluateJavascript(js, null) } catch (t: Throwable) { Log.w(tag, "deliver failed", t) }
        }
    }
}
