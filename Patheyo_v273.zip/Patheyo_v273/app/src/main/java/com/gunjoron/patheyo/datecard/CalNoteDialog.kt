package com.gunjoron.patheyo.datecard

import android.app.Dialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.gunjoron.patheyo.calnote.CalNote
import com.gunjoron.patheyo.calnote.CalNotes
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import java.util.Calendar

/**
 * v244: নোট যোগ / সম্পাদনার ডায়ালগ — লেখা, মনে করানোর ধরন (শুধু নোট · নোটিফিকেশন · অ্যালার্ম · দুটোই) ও সময়।
 * তারিখ = ক্যালেন্ডারে এখন যে দিনটা বাছা। সময় লাগে শুধু তখন, যখন নোটিফিকেশন/অ্যালার্ম চালু।
 */
class CalNoteDialog(private val ctx: Context, private val p: HijriCalendarCard.Pal) {

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * ctx.resources.displayMetrics.density

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text; textSize = size; setTextColor(color); typeface = if (bold) p.bold else p.reg
    }

    private fun rounded(r: Float, fill: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        cornerRadius = dpf(r); setColor(fill); if (stroke != 0) setStroke(dp(sw), stroke)
    }

    private val WD_FULL = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

    /** [onDone] — সেভ/মোছার পর, নোটের (নতুন) তারিখসহ: ক্যালেন্ডার ওই দিনেই থাকে */
    fun show(y0: Int, m0: Int, d0: Int, existing: CalNote?, host: HijriCalendarCard.Host?, onDone: (Int, Int, Int) -> Unit) {
        var y = y0; var m = m0; var d = d0      // v246: সম্পাদনায় তারিখও বদলানো যায়
        var mode = existing?.mode ?: CalNotes.lastMode(ctx)
        var minutes = existing?.minutes?.takeIf { it >= 0 } ?: run {
            val now = Calendar.getInstance()
            val isToday = now.get(Calendar.YEAR) == y && now.get(Calendar.MONTH) == m && now.get(Calendar.DAY_OF_MONTH) == d
            if (isToday) minOf(23 * 60 + 59, (now.get(Calendar.HOUR_OF_DAY) + 1) * 60) else 8 * 60
        }

        val dialog = Dialog(ctx)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surfHi, p.surf)).apply {
                cornerRadius = dpf(24f); setStroke(dp(1), p.line)
            }
        }

        // ---- শিরোনাম + তারিখ
        root.addView(tv(if (existing == null) "নতুন নোট" else "নোট সম্পাদনা", 19f, p.text, true))
        val dateTv = tv("", 13f, p.okText, true).apply { setPadding(0, dp(4), 0, dp(14)) }
        fun refreshDate() {
            val dow = Calendar.getInstance().apply { clear(); set(y, m, d) }.get(Calendar.DAY_OF_WEEK) - 1
            dateTv.text = "${WD_FULL[dow]} · ${Bn.digits(d)} ${Bn.GREG_MONTHS[m]} ${Bn.digits(y)}   ✎ তারিখ বদলান"
        }
        refreshDate()
        dateTv.setOnClickListener {
            android.app.DatePickerDialog(ctx, { _, yy, mm, dd -> y = yy; m = mm; d = dd; refreshDate() }, y, m, d).show()
        }
        root.addView(dateTv)

        // ---- লেখা
        val et = EditText(ctx).apply {
            setText(existing?.text ?: "")
            hint = "কী মনে রাখতে চান? যেমন: বিকালে ডাক্তারের সিরিয়াল"
            setHintTextColor(p.text3); setTextColor(p.text); typeface = p.reg; textSize = 15f
            minLines = 3; maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(14f, p.surf2, p.line)
            filters = arrayOf(InputFilter.LengthFilter(CalNotes.MAX_TEXT))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSelection(text.length)
        }
        root.addView(et, LinearLayout.LayoutParams(-1, -2))

        // ---- মনে করানোর ধরন (২×২)
        root.addView(tv("মনে করানোর ধরন", 13f, p.text2, true).apply { setPadding(dp(2), dp(16), 0, dp(8)) })
        val chipLabels = arrayOf("শুধু নোট", "নোটিফিকেশন", "অ্যালার্ম", "দুটোই")
        val chipModes = intArrayOf(CalNotes.MODE_NONE, CalNotes.MODE_NOTIF, CalNotes.MODE_ALARM, CalNotes.MODE_BOTH)
        val chips = ArrayList<TextView>()
        val desc = tv("", 12f, p.text3).apply { setPadding(dp(2), dp(8), 0, 0); setLineSpacing(0f, 1.2f) }
        val timeRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, 0) }
        val timeBtn = tv("", 15f, p.text, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(16), dp(9), dp(16), dp(9))
            background = rounded(50f, Color.TRANSPARENT, p.goldLine)
        }

        fun refresh() {
            chips.forEachIndexed { i, c ->
                val sel = chipModes[i] == mode
                c.typeface = if (sel) p.bold else p.reg
                c.setTextColor(if (sel) p.onPrimary else p.text2)
                c.background = if (sel) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(12f) }
                               else rounded(12f, p.surf2, p.line)
            }
            desc.text = when (mode) {
                CalNotes.MODE_NONE -> "শুধু ক্যালেন্ডারে নোট থাকবে — কিছু বাজবে না, নোটিফিকেশনও আসবে না।"
                CalNotes.MODE_NOTIF -> "নির্ধারিত সময়ে নোটিফিকেশনে জানানো হবে।"
                CalNotes.MODE_ALARM -> "নির্ধারিত সময়ে অ্যালার্মের মতো ফোনের ডিফল্ট রিংটোন বাজবে (বন্ধ না করা পর্যন্ত, সর্বোচ্চ ১ মিনিট)।"
                else -> "নোটিফিকেশনও আসবে, আবার অ্যালার্মের মতো রিংটোনও বাজবে।"
            }
            timeRow.visibility = if (mode == CalNotes.MODE_NONE) View.GONE else View.VISIBLE
            timeBtn.text = CalNotes.fmtTime(minutes)
        }

        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        for (r in 0..1) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..1) {
                val i = r * 2 + c
                val chip = tv(chipLabels[i], 14f, p.text2).apply {
                    gravity = Gravity.CENTER; minHeight = dp(44); setPadding(dp(8), dp(8), dp(8), dp(8))
                    setOnClickListener { mode = chipModes[i]; refresh() }
                }
                chips.add(chip)
                row.addView(chip, LinearLayout.LayoutParams(0, -2, 1f).apply { if (c == 1) leftMargin = dp(8) })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, -2).apply { if (r == 1) topMargin = dp(8) })
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, -2))
        root.addView(desc, LinearLayout.LayoutParams(-1, -2))

        // ---- সময়
        timeRow.addView(tv("সময়", 14f, p.text2, true), LinearLayout.LayoutParams(0, -2, 1f))
        timeBtn.setOnClickListener {
            TimePickerDialog(ctx, { _, h, mi -> minutes = h * 60 + mi; refresh() }, minutes / 60, minutes % 60, false).show()
        }
        timeRow.addView(timeBtn, LinearLayout.LayoutParams(-2, -2))
        root.addView(timeRow, LinearLayout.LayoutParams(-1, -2))

        // ---- বাটন
        val actions = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (existing != null) {
            actions.addView(tv("মুছুন", 14.5f, Color.parseColor("#E5594F"), true).apply {
                gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(14), dp(12))
                setOnClickListener {
                    android.app.AlertDialog.Builder(ctx).setTitle("নোট মুছবেন?").setMessage(existing.text)
                        .setPositiveButton("মুছুন") { _, _ -> CalNotes.delete(ctx, existing.id); dialog.dismiss(); onDone(y, m, d) }
                        .setNegativeButton("না", null).show()
                }
            })
        }
        actions.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        actions.addView(tv("বাতিল", 15f, p.text, true).apply {
            gravity = Gravity.CENTER; minHeight = dp(46); setPadding(dp(18), dp(10), dp(18), dp(10))
            background = rounded(12f, Color.TRANSPARENT, p.goldLine)
            setOnClickListener { dialog.dismiss() }
        })
        actions.addView(tv("সেভ করুন", 15f, p.onPrimary, true).apply {
            gravity = Gravity.CENTER; minHeight = dp(46); setPadding(dp(20), dp(10), dp(20), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(12f) }
            setOnClickListener {
                val text = et.text.toString().trim()
                if (text.isEmpty()) { Toast.makeText(ctx, "নোটে কিছু লিখুন", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                val mins = if (mode == CalNotes.MODE_NONE) -1 else minutes
                // শুধু লেখা বদলালে (ধরন ও সময় একই) পুরনো সময় পার হলেও সেভ হবে
                val unchanged = existing != null && existing.mode == mode && existing.minutes == mins && existing.y == y && existing.m == m && existing.d == d
                if (mode != CalNotes.MODE_NONE && !unchanged) {
                    val at = Calendar.getInstance().apply { clear(); set(y, m, d, mins / 60, mins % 60, 0) }.timeInMillis
                    if (at <= System.currentTimeMillis()) {
                        Toast.makeText(ctx, "এই সময় পার হয়ে গেছে — ভবিষ্যতের সময় বাছুন", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                }
                val finish: () -> Unit = {
                    val note = CalNote(existing?.id ?: CalNotes.nextId(ctx), y, m, d, mins, text, mode, unchanged && existing!!.fired)
                    CalNotes.save(ctx, note)
                    CalNotes.rememberMode(ctx, mode)
                    dialog.dismiss(); onDone(y, m, d)
                    if (mode != CalNotes.MODE_NONE && !unchanged) Toast.makeText(ctx, "মনে করানো সেট হয়েছে — ${CalNotes.fmtTime(mins)}", Toast.LENGTH_SHORT).show()
                }
                if (host != null) host.ensureNotePermissions(mode) { finish() } else finish()
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })
        root.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        refresh()

        val scroll = ScrollView(ctx).apply { addView(root) }
        val frame = FrameLayout(ctx).apply { setPadding(dp(14), dp(14), dp(14), dp(14)); addView(scroll) }
        dialog.setContentView(frame)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            setDimAmount(0.6f)
        }
        dialog.show()
    }
}
