package com.gunjoron.patheyo.share

import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import java.io.File

/**
 * ✅ v161: শেয়ার কার্ড (আয়াত / হাদিস / দোয়া) — JS ছবি (PNG, base64) বানিয়ে এখানে পাঠায়;
 *   shareImage → ফোনের শেয়ার-শিট (WhatsApp, Facebook, Messenger…)
 *   saveImage  → গ্যালারির Pictures/Patheyo ফোল্ডারে সেভ (Android 10+; এর নিচে বাটনটি দেখানো হয় না)
 *   shareText  → শুধু লেখা শেয়ার
 * JS-এ নাম: PatheyoShare (WebView-তে addJavascriptInterface — MainActivity দেখুন)।
 * ছবির অস্থায়ী ফাইল cacheDir/share/-এ থাকে (file_paths.xml-এ cache-path দেওয়া আছে); পুরোনো ফাইল নিজে থেকে মুছে যায়।
 */
class ShareBridge(private val activity: Activity) {

    private val tag = "PatheyoShare"

    private fun shareDir(): File = File(activity.cacheDir, "share").apply { mkdirs() }

    private fun decode(b64: String): ByteArray {
        val raw = if (b64.contains(",")) b64.substringAfter(",") else b64
        return Base64.decode(raw, Base64.DEFAULT)
    }

    private fun cleanOld() {
        try {
            val limit = System.currentTimeMillis() - 60 * 60 * 1000L
            shareDir().listFiles()?.forEach { if (it.lastModified() < limit) it.delete() }
        } catch (_: Throwable) {}
    }

    @JavascriptInterface
    fun canSave(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    @JavascriptInterface
    fun shareImage(b64: String, text: String): Boolean {
        return try {
            cleanOld()
            val bytes = decode(b64)
            val file = File(shareDir(), "patheyo_card_${System.currentTimeMillis()}.png")
            file.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                if (text.isNotBlank()) putExtra(Intent.EXTRA_TEXT, text)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(send, "শেয়ার করুন").apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.runOnUiThread {
                try { activity.startActivity(chooser) } catch (t: Throwable) { Log.w(tag, "chooser failed", t) }
            }
            true
        } catch (t: Throwable) {
            Log.w(tag, "shareImage failed", t)
            false
        }
    }

    @JavascriptInterface
    fun saveImage(b64: String, name: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val bytes = decode(b64)
            val safe = name.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "patheyo_card" }
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$safe.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Patheyo")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = activity.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return false
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } catch (t: Throwable) {
            Log.w(tag, "saveImage failed", t)
            false
        }
    }

    @JavascriptInterface
    fun shareText(text: String): Boolean {
        return try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            val chooser = Intent.createChooser(send, "শেয়ার করুন")
            activity.runOnUiThread {
                try { activity.startActivity(chooser) } catch (t: Throwable) { Log.w(tag, "chooser failed", t) }
            }
            true
        } catch (t: Throwable) {
            Log.w(tag, "shareText failed", t)
            false
        }
    }
}
