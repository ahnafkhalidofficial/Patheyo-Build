package com.gunjoron.patheyo.calnote

import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.alarm.AlarmScheduler
import com.gunjoron.patheyo.datecard.DateCardActivity
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * v244: ক্যালেন্ডারের নোট ও রিমাইন্ডার।
 *
 * ইউজার ক্যালেন্ডারের যেকোনো তারিখে নোট লিখতে পারে, চাইলে সময় দিয়ে মনে করানোর ধরনও বাছতে পারে:
 *   [MODE_NONE]  — শুধু নোট, কিছু বাজবে না
 *   [MODE_NOTIF] — সময়মতো নোটিফিকেশন
 *   [MODE_ALARM] — সময়মতো অ্যালার্মের মতো ফোনের ডিফল্ট রিংটোন বাজবে ([CalNoteAlarmService] + [CalNoteAlarmActivity])
 *   [MODE_BOTH]  — নোটিফিকেশনও আসবে, রিংটোনও বাজবে
 *
 * নোট থাকে SharedPreferences-এ (JSON তালিকা)। প্রতিটা সময়-দেওয়া নোটের জন্য একটাই এক-বারের AlarmManager অ্যালার্ম;
 * রিবুট/অ্যাপ খোলায় [rescheduleAll] আবার বসায় (ReminderAlarms.scheduleAll ও MainActivity থেকে)।
 */
data class CalNote(
    val id: Int,
    val y: Int,
    val m: Int,            // ০–১১
    val d: Int,
    val minutes: Int,      // দিনের শুরু থেকে মিনিট; -১ = সময় দেওয়া হয়নি
    val text: String,
    val mode: Int,
    val fired: Boolean = false
) {
    val hasTime: Boolean get() = minutes >= 0
    val wantsNotif: Boolean get() = mode == CalNotes.MODE_NOTIF || mode == CalNotes.MODE_BOTH
    val wantsAlarm: Boolean get() = mode == CalNotes.MODE_ALARM || mode == CalNotes.MODE_BOTH
    /** তারিখের ক্রম-কী (yyyymmdd) */
    val dayKey: Int get() = y * 10000 + (m + 1) * 100 + d

    fun triggerAt(): Long = Calendar.getInstance().apply {
        clear(); set(y, m, d, if (minutes >= 0) minutes / 60 else 0, if (minutes >= 0) minutes % 60 else 0, 0)
    }.timeInMillis
}

object CalNotes {
    const val MODE_NONE = 0
    const val MODE_NOTIF = 1
    const val MODE_ALARM = 2
    const val MODE_BOTH = 3

    const val EXTRA_ID = "calnote_id"
    const val EXTRA_Y = "calnote_y"
    const val EXTRA_M = "calnote_m"
    const val EXTRA_D = "calnote_d"
    const val SNOOZE_MIN = 5
    const val MAX_TEXT = 300

    const val CH_NOTE = "patheyo_calnote_v1"
    const val CH_ALARM = "patheyo_calnote_alarm_v1"

    private const val PREFS = "patheyo_calnotes"
    private const val KEY_LIST = "notes_json"
    private const val KEY_SEQ = "seq"
    private const val KEY_LAST_MODE = "last_mode"
    private const val KEY_ARCH = "archive_json"
    private const val KEY_DEAD = "archive_dead"
    /**
     * সময় পার হওয়ার পরও এতক্ষণ নোট সক্রিয় থাকে (অ্যালার্ম বাজা/স্নুজের জন্য), তারপর আর্কাইভে যায়।
     * v248: ৩০ → ১০ মিনিট (অ্যালার্ম সর্বোচ্চ ১ মিনিট বাজে, স্নুজ ৫ মিনিট); স্নুজ করা থাকলে স্নুজের সময় থেকে গোনা হয় ([lastDue])।
     */
    private const val ARCHIVE_GRACE_MS = 10L * 60 * 1000
    private const val SNZ_PREFIX = "snz_"
    private const val REQ_FIRE = 500_000
    private const val REQ_OPEN = 560_000
    private const val NOTIF_BASE = 520_000
    private const val MISSED_WINDOW_MS = 12L * 60 * 60 * 1000

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ সংরক্ষণ

    @Synchronized
    fun all(ctx: Context): List<CalNote> {
        val out = ArrayList<CalNote>()
        try {
            val arr = JSONArray(prefs(ctx).getString(KEY_LIST, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(CalNote(
                    o.optInt("id"), o.optInt("y"), o.optInt("m"), o.optInt("d"),
                    o.optInt("t", -1), o.optString("x", ""), o.optInt("mode", MODE_NONE), o.optBoolean("f", false)
                ))
            }
        } catch (_: Throwable) {}
        return out
    }

    @Synchronized
    private fun saveAll(ctx: Context, list: List<CalNote>) {
        val arr = JSONArray()
        for (n in list) arr.put(JSONObject().apply {
            put("id", n.id); put("y", n.y); put("m", n.m); put("d", n.d)
            put("t", n.minutes); put("x", n.text); put("mode", n.mode); put("f", n.fired)
        })
        prefs(ctx).edit().putString(KEY_LIST, arr.toString()).apply()
    }

    @Synchronized
    fun nextId(ctx: Context): Int {
        val n = prefs(ctx).getInt(KEY_SEQ, 0) + 1
        prefs(ctx).edit().putInt(KEY_SEQ, n).apply()
        return n
    }

    fun get(ctx: Context, id: Int): CalNote? = all(ctx).firstOrNull { it.id == id }

    private fun order(a: CalNote, b: CalNote): Int {
        val ka = a.dayKey; val kb = b.dayKey
        if (ka != kb) return ka.compareTo(kb)
        if (a.minutes != b.minutes) return a.minutes.compareTo(b.minutes)
        return a.id.compareTo(b.id)
    }

    fun forDay(ctx: Context, y: Int, m: Int, d: Int): List<CalNote> =
        all(ctx).filter { it.y == y && it.m == m && it.d == d }.sortedWith { a, b -> order(a, b) }

    /** মাসের কোন দিনে কয়টা নোট (দিন → সংখ্যা) */
    fun countsForMonth(ctx: Context, y: Int, m: Int): Map<Int, Int> {
        val map = HashMap<Int, Int>()
        for (n in all(ctx)) if (n.y == y && n.m == m) map[n.d] = (map[n.d] ?: 0) + 1
        return map
    }

    /** আজ বা তার পরের নোট (আজকের সময়-পার-হওয়া রিমাইন্ডারও থাকে, যাতে বাজার পরও আজকের দিনে দেখা যায়) */
    fun upcoming(ctx: Context, limit: Int): List<CalNote> {
        val t = Calendar.getInstance()
        val today = t.get(Calendar.YEAR) * 10000 + (t.get(Calendar.MONTH) + 1) * 100 + t.get(Calendar.DAY_OF_MONTH)
        return all(ctx).filter { it.dayKey >= today }.sortedWith { a, b -> order(a, b) }.take(limit)
    }

    /** সামনের সময়ের অ্যালার্ম/নোটিফিকেশন-রিমাইন্ডারওয়ালা নোট (এখনো বাজেনি), সময়ের ক্রমে — "এক নজরে" অংশের জন্য */
    fun upcomingReminders(ctx: Context, limit: Int): List<CalNote> {
        val now = System.currentTimeMillis()
        return all(ctx).filter { it.mode != MODE_NONE && it.hasTime && !it.fired && it.triggerAt() > now }
            .sortedBy { it.triggerAt() }.take(limit)
    }

    /** মেয়াদ-শেষ নোট আর্কাইভে সরায়; কিছু সরলে অ্যাকাউন্টেও (সাইন-ইন থাকলে) পাঠায়। v248: কয়টা সরল তা ফেরত দেয় (স্ক্রিন নতুন করে আঁকার জন্য) */
    fun sweep(ctx: Context): Int = try {
        val n = archiveExpired(ctx)
        if (n > 0) CalNoteCloud.push(ctx)
        n
    } catch (_: Throwable) { 0 }

    /** শেষবার ইউজার যে ধরন বেছেছিল — নতুন নোটে সেটিই আগে থেকে বাছা থাকে */
    fun lastMode(ctx: Context): Int = prefs(ctx).getInt(KEY_LAST_MODE, MODE_NOTIF)
    fun rememberMode(ctx: Context, mode: Int) { prefs(ctx).edit().putInt(KEY_LAST_MODE, mode).apply() }

    @Synchronized
    fun save(ctx: Context, note: CalNote) {
        val list = all(ctx).filter { it.id != note.id }.toMutableList()
        list.add(note)
        saveAll(ctx, list)
        prefs(ctx).edit().remove(SNZ_PREFIX + note.id).apply()      // v248: সম্পাদনার পর পুরনো স্নুজের সময় বাতিল
        schedule(ctx, note)
        com.gunjoron.patheyo.sync.NativeSync.nudge()      // v247: অ্যাকাউন্টের ক্লাউডে পাঠানোর তাগাদা
    }

    @Synchronized
    fun delete(ctx: Context, id: Int) {
        val app = ctx.applicationContext
        try { (app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager)?.cancel(firePi(app, id)) } catch (_: Throwable) {}
        try { NotificationManagerCompat.from(app).cancel(NOTIF_BASE + id) } catch (_: Throwable) {}
        saveAll(app, all(app).filter { it.id != id })
        prefs(app).edit().remove(SNZ_PREFIX + id).apply()
        com.gunjoron.patheyo.sync.NativeSync.nudge()      // v247
    }

    @Synchronized
    private fun markFired(ctx: Context, id: Int) {
        saveAll(ctx, all(ctx).map { if (it.id == id) it.copy(fired = true) else it })
    }

    // ------------------------------------------------------------------ v245: আর্কাইভ

    /** আর্কাইভে জমা-হওয়া নোট ([at] = কখন জমা হলো)। [key] দুই ডিভাইস/ক্লাউডে একই নোট চেনার জন্য */
    data class Archived(val note: CalNote, val at: Long) {
        val key: String get() = "${note.dayKey}_${note.minutes}_${note.text.hashCode()}"
    }

    private fun archToJson(list: List<Archived>): JSONArray {
        val arr = JSONArray()
        for (a in list) arr.put(JSONObject().apply {
            put("y", a.note.y); put("m", a.note.m); put("d", a.note.d); put("t", a.note.minutes)
            put("x", a.note.text); put("mode", a.note.mode); put("at", a.at)
        })
        return arr
    }

    private fun archFromJson(arr: JSONArray): List<Archived> {
        val out = ArrayList<Archived>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Archived(CalNote(0, o.optInt("y"), o.optInt("m"), o.optInt("d"), o.optInt("t", -1), o.optString("x", ""),
                o.optInt("mode", MODE_NONE), true), o.optLong("at")))
        }
        return out
    }

    @Synchronized
    private fun rawArchive(ctx: Context): List<Archived> = try {
        archFromJson(JSONArray(prefs(ctx).getString(KEY_ARCH, "[]") ?: "[]"))
    } catch (_: Throwable) { emptyList() }

    @Synchronized
    private fun deadKeys(ctx: Context): Set<String> = try {
        val arr = JSONArray(prefs(ctx).getString(KEY_DEAD, "[]") ?: "[]")
        (0 until arr.length()).map { arr.optString(it) }.toSet()
    } catch (_: Throwable) { emptySet() }

    @Synchronized
    private fun saveArchive(ctx: Context, list: List<Archived>, dead: Set<String>) {
        prefs(ctx).edit().putString(KEY_ARCH, archToJson(list).toString())
            .putString(KEY_DEAD, JSONArray(dead.toList()).toString()).apply()
    }

    /** আর্কাইভের নোট — সবচেয়ে নতুন তারিখ আগে */
    fun archived(ctx: Context): List<Archived> =
        rawArchive(ctx).sortedWith { a, b ->
            if (a.note.dayKey != b.note.dayKey) b.note.dayKey.compareTo(a.note.dayKey)
            else b.note.minutes.compareTo(a.note.minutes)
        }

    fun archivedCount(ctx: Context): Int = rawArchive(ctx).size

    @Synchronized
    fun deleteArchived(ctx: Context, key: String) {
        saveArchive(ctx, rawArchive(ctx).filter { it.key != key }, deadKeys(ctx) + key)
        com.gunjoron.patheyo.sync.NativeSync.nudge()      // v247
    }

    /** নোটের শেষ নির্ধারিত সময় — স্নুজ করা থাকলে স্নুজের সময় (যেটি পরে সেটি) */
    private fun lastDue(ctx: Context, n: CalNote): Long {
        val t = n.triggerAt()
        val z = prefs(ctx).getLong(SNZ_PREFIX + n.id, 0L)
        return if (z > t) z else t
    }

    private fun isExpired(ctx: Context, n: CalNote, now: Long, today: Int): Boolean =
        if (n.hasTime) now > lastDue(ctx, n) + ARCHIVE_GRACE_MS else n.dayKey < today

    /**
     * তারিখ/সময় শেষ হওয়া নোট নিজে নিজে আর্কাইভে যায়: সময়-দেওয়া নোট = শেষ সময়ের [ARCHIVE_GRACE_MS] পর (স্নুজ ধরে);
     * সময়-ছাড়া নোট = তারিখ পার হলে। সবকিছু ফোনের স্টোরেজে থাকে; সাইন-ইন থাকলে অ্যাকাউন্টেও ([CalNoteCloud])।
     * v248: আগে আর্কাইভের আগের মোছা-নোটের চাবি ([KEY_DEAD]) বা একই চাবির নোট থাকলে নোটটা সক্রিয় তালিকা থেকে সরত
     * কিন্তু আর্কাইভে ঢুকত না — মানে নোট একদম হারিয়ে যেত। এখন সবসময় আর্কাইভে ঢোকে (নতুন মেয়াদ-শেষ নোট পুরনো মোছার চিহ্নকে হারায়)।
     * @return কয়টা নোট সরল
     */
    @Synchronized
    fun archiveExpired(ctx: Context): Int {
        val app = ctx.applicationContext
        val now = System.currentTimeMillis()
        val t = Calendar.getInstance()
        val today = t.get(Calendar.YEAR) * 10000 + (t.get(Calendar.MONTH) + 1) * 100 + t.get(Calendar.DAY_OF_MONTH)
        val live = all(app)
        val ringing = if (CalNoteAlarmService.isRunning) CalNoteAlarmService.currentId else -1
        val gone = live.filter { n -> n.id != ringing && isExpired(app, n, now, today) }
        if (gone.isEmpty()) return 0
        val dead = deadKeys(app).toMutableSet()
        val arch = rawArchive(app).toMutableList()
        val have = arch.map { it.key }.toHashSet()
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        for (n in gone) {
            try { am?.cancel(firePi(app, n.id)) } catch (_: Throwable) {}
            try { NotificationManagerCompat.from(app).cancel(NOTIF_BASE + n.id) } catch (_: Throwable) {}
            prefs(app).edit().remove(SNZ_PREFIX + n.id).apply()
            val a = Archived(n.copy(fired = true), now)
            dead.remove(a.key)                  // নতুন করে মেয়াদ-শেষ হওয়া নোট আগের মোছার চিহ্নে আটকায় না
            if (have.add(a.key)) arch.add(a)
        }
        saveArchive(app, arch, dead)
        saveAll(app, live.filter { n -> gone.none { it.id == n.id } })
        return gone.size
    }

    /** ক্লাউডে পাঠানোর জন্য আর্কাইভ + মুছে-ফেলা-কী-র তালিকা */
    @Synchronized
    fun exportArchive(ctx: Context): String = JSONObject()
        .put("items", archToJson(rawArchive(ctx))).put("dead", JSONArray(deadKeys(ctx).toList())).toString()

    /** ক্লাউডের আর্কাইভ ফোনের সাথে মেলানো (দুই দিকের ইউনিয়ন, মুছে-ফেলাগুলো বাদ)। কিছু বদলালে true */
    @Synchronized
    fun importArchive(ctx: Context, json: String): Boolean {
        return try {
            val o = JSONObject(json)
            val cloud = archFromJson(o.optJSONArray("items") ?: JSONArray())
            val deadArr = o.optJSONArray("dead") ?: JSONArray()
            val dead = deadKeys(ctx) + (0 until deadArr.length()).map { deadArr.optString(it) }
            val local = rawArchive(ctx)
            val map = LinkedHashMap<String, Archived>()
            for (a in local + cloud) if (a.key !in dead && !map.containsKey(a.key)) map[a.key] = a
            val changed = map.size != local.size || dead.size != deadKeys(ctx).size
            if (changed) saveArchive(ctx, map.values.toList(), dead)
            changed || cloud.size != map.size   // ক্লাউডে কম থাকলেও আবার পাঠাতে হবে
        } catch (_: Throwable) { false }
    }

    // ------------------------------------------------------------------ v247: অ্যাকাউন্টের সাথে সিঙ্ক
    // নোট (সক্রিয় + আর্কাইভ) অ্যাপের একই ক্লাউড-সিঙ্কে (Supabase) যায় — sync/NativeSync.kt দেখুন।
    // দুই ফোনে "একই নোট" চেনার চাবিতে id ও fired থাকে না (ও দুটো ফোনভেদে আলাদা), তাই সক্রিয়/আর্কাইভের ভাগ বদলালেও
    // সিঙ্কের লেখা বদলায় না।

    /** দুই ফোনে একই নোটের একই চাবি */
    fun syncKey(n: CalNote): String = "${n.dayKey}_${n.minutes}_${n.mode}_${n.text.hashCode()}"

    /** সক্রিয় + আর্কাইভ মিলিয়ে প্রতিটা নোট একবার, চাবির ক্রমে (স্থির ক্রম — ফিঙ্গারপ্রিন্ট না বদলাতে) */
    @Synchronized
    fun syncExport(ctx: Context): JSONArray {
        val map = java.util.TreeMap<String, CalNote>()
        for (n in all(ctx)) map[syncKey(n)] = n
        for (a in rawArchive(ctx)) { val k = syncKey(a.note); if (!map.containsKey(k)) map[k] = a.note }
        val arr = JSONArray()
        for (n in map.values) arr.put(JSONObject().apply {
            put("y", n.y); put("m", n.m); put("d", n.d); put("t", n.minutes); put("x", n.text); put("mode", n.mode)
        })
        return arr
    }

    /**
     * ক্লাউডের নোট ফোনে বসানো।
     *  replace = true  : ক্লাউডই সত্য — ক্লাউডে নেই এমন নোট ফোন থেকে বাদ (অ্যালার্মসহ), যেগুলো নেই সেগুলো যোগ।
     *  replace = false : মেলানো (প্রথমবার সাইন-ইন) — ফোনের কিছুই মোছে না; ক্লাউডের নতুনগুলো শুধু যোগ।
     * সময় পার হওয়া নোট আর্কাইভে, বাকি সক্রিয়তে (অ্যালার্ম বসে)।
     */
    @Synchronized
    fun syncApply(ctx: Context, items: JSONArray, replace: Boolean) {
        val app = ctx.applicationContext
        val want = LinkedHashMap<String, CalNote>()
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val n = CalNote(0, o.optInt("y"), o.optInt("m"), o.optInt("d"), o.optInt("t", -1),
                o.optString("x", ""), o.optInt("mode", MODE_NONE))
            if (n.text.isBlank()) continue
            want[syncKey(n)] = n
        }
        if (replace) {
            for (n in all(app)) if (syncKey(n) !in want) delete(app, n.id)
            val arch = rawArchive(app)
            val keep = arch.filter { syncKey(it.note) in want }
            if (keep.size != arch.size) saveArchive(app, keep, deadKeys(app))
        }
        val have = HashSet<String>()
        for (n in all(app)) have.add(syncKey(n))
        for (a in rawArchive(app)) have.add(syncKey(a.note))
        val dead = deadKeys(app)
        val now = System.currentTimeMillis()
        val t = Calendar.getInstance()
        val today = t.get(Calendar.YEAR) * 10000 + (t.get(Calendar.MONTH) + 1) * 100 + t.get(Calendar.DAY_OF_MONTH)
        val newArch = ArrayList<Archived>()
        for ((k, n) in want) {
            if (k in have) continue
            val expired = if (n.hasTime) now > n.triggerAt() + ARCHIVE_GRACE_MS else n.dayKey < today
            if (expired) {
                val a = Archived(n.copy(fired = true), now)
                if (replace || a.key !in dead) newArch.add(a)
            } else {
                save(app, n.copy(id = nextId(app), fired = n.hasTime && n.triggerAt() <= now))
            }
        }
        if (newArch.isNotEmpty()) saveArchive(app, rawArchive(app) + newArch, dead)
    }

    /** সাইন-আউটে এই ফোনের নোট (সক্রিয় + আর্কাইভ) সাফ — অ্যালার্মও বাতিল */
    @Synchronized
    fun syncReset(ctx: Context) {
        val app = ctx.applicationContext
        for (n in all(app)) delete(app, n.id)
        saveArchive(app, emptyList(), emptySet())
    }

    // ------------------------------------------------------------------ শিডিউল

    private fun firePi(ctx: Context, id: Int): PendingIntent =
        PendingIntent.getBroadcast(ctx, REQ_FIRE + id, Intent(ctx, CalNoteReceiver::class.java).putExtra(EXTRA_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun setAt(app: Context, am: AlarmManager, at: Long, pi: PendingIntent, realAlarm: Boolean) {
        // অ্যালার্ম = আজানের মতো সবচেয়ে নির্ভরযোগ্য পথ (setAlarmClock); শুধু নোটিফিকেশন = সাধারণ এক্সাক্ট/ইনএক্সাক্ট রিমাইন্ডার
        if (realAlarm) { AlarmScheduler.setBestAlarm(app, am, at, pi); return }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (AlarmScheduler.canScheduleExact(app)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else am.set(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Throwable) {
            try { am.set(AlarmManager.RTC_WAKEUP, at, pi) } catch (_: Throwable) {}
        }
    }

    fun schedule(ctx: Context, n: CalNote) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = firePi(app, n.id)
        val at = if (n.hasTime) n.triggerAt() else 0L
        if (n.mode == MODE_NONE || !n.hasTime || n.fired || at <= System.currentTimeMillis()) { am.cancel(pi); return }
        setAt(app, am, at, pi, n.wantsAlarm)
    }

    /** "৫ মিনিট পরে" — ঠিক এখন থেকে [SNOOZE_MIN] মিনিট পরে একই নোট আবার বাজবে */
    fun snooze(ctx: Context, id: Int) {
        val app = ctx.applicationContext
        val n = get(app, id) ?: return
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val until = System.currentTimeMillis() + SNOOZE_MIN * 60_000L
        prefs(app).edit().putLong(SNZ_PREFIX + id, until).apply()      // v248: আর্কাইভের সময় স্নুজের পর থেকে গোনা হয়
        setAt(app, am, until, firePi(app, id), n.wantsAlarm)
    }

    /** রিবুট / অ্যাপ খোলা / আপডেটের পর: ভবিষ্যতেরগুলো আবার বসানো; ১২ ঘণ্টার মধ্যে মিস হওয়াগুলো নোটিফিকেশনে জানানো */
    fun rescheduleAll(ctx: Context) {
        val app = ctx.applicationContext
        val now = System.currentTimeMillis()
        for (n in all(app)) {
            try {
                if (n.mode == MODE_NONE || !n.hasTime || n.fired) continue
                val at = n.triggerAt()
                if (at > now) schedule(app, n)
                else {
                    markFired(app, n.id)
                    if (now - at <= MISSED_WINDOW_MS) postNote(app, n, missed = true)
                }
            } catch (_: Throwable) {}
        }
        try { if (archiveExpired(app) > 0) CalNoteCloud.push(app) } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ বাজার সময়

    fun fire(ctx: Context, id: Int) {
        val app = ctx.applicationContext
        val n = get(app, id) ?: return
        if (n.mode == MODE_NONE) return
        markFired(app, id)
        if (!n.wantsAlarm) { postNote(app, n); return }

        // অ্যালার্ম: ফোরগ্রাউন্ড সার্ভিস রিংটোন বাজায়; ফোন লক/স্ক্রিন বন্ধ থাকলে সরাসরি অ্যালার্ম-স্ক্রিন, নইলে হেডস-আপ নোটিফিকেশন
        var started = false
        try {
            ContextCompat.startForegroundService(app, Intent(app, CalNoteAlarmService::class.java).putExtra(EXTRA_ID, id))
            started = true
        } catch (_: Throwable) {}
        if (!started) postNote(app, n)       // সার্ভিস চালু না হলে অন্তত সাউন্ডসহ নোটিফিকেশন
        else if (isLockedOrScreenOff(app)) {
            try {
                app.startActivity(Intent(app, CalNoteAlarmActivity::class.java).putExtra(EXTRA_ID, id).addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION))
            } catch (_: Throwable) {}
        }
        if (n.wantsNotif && started) postNote(app, n)     // "দুটোই" — নোটিফিকেশন ট্রেতেও থেকে যায়
    }

    fun isLockedOrScreenOff(ctx: Context): Boolean = try {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
        (km?.isKeyguardLocked ?: true) || !(pm?.isInteractive ?: false)
    } catch (_: Throwable) { true }

    // ------------------------------------------------------------------ নোটিফিকেশন

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH_NOTE) == null) {
                nm.createNotificationChannel(NotificationChannel(CH_NOTE, "ক্যালেন্ডার নোট", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "ক্যালেন্ডারে লেখা নোটের নির্ধারিত সময়ে মনে করিয়ে দেওয়া"
                    enableVibration(true)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                })
            }
            if (nm.getNotificationChannel(CH_ALARM) == null) {
                nm.createNotificationChannel(NotificationChannel(CH_ALARM, "ক্যালেন্ডার নোটের অ্যালার্ম", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "নোটের অ্যালার্ম বাজলে — রিংটোন সার্ভিস নিজে বাজায়, তাই এখানে আলাদা শব্দ নেই"
                    setSound(null, null)
                    setShowBadge(false)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                })
            }
        } catch (_: Throwable) {}
    }

    private val PERIODS = arrayOf("রাত", "সকাল", "দুপুর", "বিকাল", "সন্ধ্যা", "রাত")

    /** ৮:৩০ সকাল-ধরনের বাংলা সময়: "সকাল ৮:৩০" */
    fun fmtTime(minutes: Int): String {
        if (minutes < 0) return ""
        val h = minutes / 60; val mi = minutes % 60
        val period = when (h) { in 0..3 -> 0; in 4..11 -> 1; in 12..15 -> 2; in 16..17 -> 3; in 18..19 -> 4; else -> 5 }
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "${PERIODS[period]} ${Bn.digits(h12)}:${Bn.digits(Bn.pad2(mi))}"
    }

    fun modeLabel(mode: Int): String = when (mode) {
        MODE_NOTIF -> "নোটিফিকেশন"
        MODE_ALARM -> "অ্যালার্ম"
        MODE_BOTH -> "নোটিফিকেশন + অ্যালার্ম"
        else -> "শুধু নোট"
    }

    fun dateLine(n: CalNote): String = "${Bn.digits(n.d)} ${Bn.GREG_MONTHS[n.m]} ${Bn.digits(n.y)}" +
        (if (n.hasTime) " · ${fmtTime(n.minutes)}" else "")

    /** ট্যাপ করলে ক্যালেন্ডার খুলে ওই নোটের তারিখে যায় */
    fun openCalendarPi(ctx: Context, n: CalNote): PendingIntent =
        PendingIntent.getActivity(ctx, REQ_OPEN + n.id, Intent(ctx, DateCardActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(EXTRA_Y, n.y); putExtra(EXTRA_M, n.m); putExtra(EXTRA_D, n.d)
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** সাধারণ নোটিফিকেশন (শব্দ/কম্পনসহ, ট্রেতে থাকে) */
    fun postNote(ctx: Context, n: CalNote, missed: Boolean = false) {
        ensureChannels(ctx)
        val title = if (missed) "মিস হওয়া নোট" else "ক্যালেন্ডার নোট"
        val nb = NotificationCompat.Builder(ctx, CH_NOTE)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ContextCompat.getColor(ctx, R.color.brand_notif_color))
            .setContentTitle(title)
            .setContentText(n.text)
            .setSubText(dateLine(n))
            .setStyle(NotificationCompat.BigTextStyle().bigText(n.text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openCalendarPi(ctx, n))
            .build()
        try { NotificationManagerCompat.from(ctx).notify(NOTIF_BASE + n.id, nb) } catch (_: SecurityException) {}
    }
}
