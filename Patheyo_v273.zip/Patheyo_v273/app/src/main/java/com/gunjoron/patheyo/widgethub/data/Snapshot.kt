package com.gunjoron.patheyo.widgethub.data

import android.content.Context
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import org.json.JSONObject
import java.util.Calendar

/**
 * একটি নির্দিষ্ট মুহূর্তের সব প্রদর্শনযোগ্য তথ্য। রেন্ডারার শুধু এটিই পড়ে।
 *
 * তথ্যের উৎস (সবই মূল অ্যাপের নিজস্ব সিস্টেম — আলাদা কোনো হিসাব নেই):
 *  • নামাজের সময়, সূর্যোদয়/সূর্যাস্ত → নামাজ ফিচারের সেভ করা সময় (PrayerWidgetProvider.KEY_TIMINGS)
 *  • নিষিদ্ধ সময় → নামাজ ফিচারের নিয়মেই: সূর্যোদয়ের পর ১৫ মি., যোহরের আগে ১২ মি., সূর্যাস্তের আগে ১৫ মি.
 *  • ইংরেজি ও বাংলা তারিখ → অ্যাপের হোমের গণনা (রাত ১২টায় বদলায়)
 *  • আরবি (হিজরি) তারিখ → অ্যাপের হোমের তারিখ (Firebase অ্যাডজাস্টমেন্ট/ওভাররাইড সহ; মাগরিবে বদলায়)
 *
 * current: ০=ফজর ১=যোহর ২=আসর ৩=মাগরিব ৪=ইশা, -১ = সূর্যোদয় থেকে যোহর পর্যন্ত (কোনো ওয়াক্ত চলছে না)।
 */
class Snapshot(
    val nowMs: Long,
    val hijriMonthYear: String,      // "রবিউস সানি ১৪৪৭"
    val gregDay: String,             // "১৯"
    val gregMonth: String,           // "অক্টোবর"
    val gregYear: String,            // "২০২৬"
    val banglaDay: String,
    val banglaMonth: String,
    val banglaYear: String,
    val hijriDay: String,
    val hijriMonth: String,
    val hijriYear: String,
    val prayerNames: Array<String>,  // ফজর/যোহর(বা জুমা)/আসর/মাগরিব/ইশা
    val prayerTimes: Array<String>,  // ০৪:৫৫ ফরম্যাট, ফজর/যোহর/আসর/মাগরিব/ইশা
    val sunrise: String,             // ৬:৫৯
    val sehri: String,
    val iftar: String,
    val current: Int,
    val currentName: String,         // চলমান (বা পরবর্তী) ওয়াক্তের নাম
    val running: Boolean,            // true = ওয়াক্ত চলছে; false = সূর্যোদয়-যোহর বিরতি
    val periodStartMs: Long,         // চলমান ওয়াক্তের শুরু (বা বিরতির শুরু)
    val periodEndMs: Long,           // চলমান ওয়াক্তের শেষ (বা যোহরের শুরু)
    val isPm: Boolean,
    val nextChangeMs: Long,          // উইজেট কখন আবার রিফ্রেশ করতে হবে
    val sunriseMs: Long = 0L,        // আজকের সূর্যোদয়
    val sunsetMs: Long = 0L,         // আজকের সূর্যাস্ত (= মাগরিব)
    val nightStartMs: Long = 0L,     // চলমান/পরবর্তী রাতের শুরু (সূর্যাস্ত) — চাঁদের আর্কের জন্য
    val nightEndMs: Long = 0L,       // রাতের শেষ (পরবর্তী সূর্যোদয়)
    val forbid: Int = 0,             // ডিজাইন ৬: ০=স্বাভাবিক, ১=নিষিদ্ধ সময় চলছে, ২=সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত ("-")
    val forbidEndMs: Long = 0L,      // নিষিদ্ধ সময় (forbid=১) কখন শেষ
    val forbidStartMs: Long = 0L,    // নিষিদ্ধ সময় (forbid=১) কখন শুরু
    val gregFirst: Boolean = false,  // ইংরেজি তারিখ আগে (ট্রগল)
    val sunIsSet: Boolean = false,   // দিনে (সূর্যোদয়–সূর্যাস্ত) true → "সূর্যাস্ত" দেখাবে, নইলে "সূর্যোদয়"
    val sunLabel: String = "সূর্যোদয়",
    val sunTime: String = ""          // পরের সূর্য-ঘটনার সময় (দিনে সূর্যাস্ত, রাতে পরের সূর্যোদয়)
) {
    val gregorianLine: String get() = "$gregDay $gregMonth $gregYear"
    val banglaLine: String get() = "$banglaDay $banglaMonth $banglaYear"
    val hijriLine: String get() = "$hijriDay $hijriMonthYear"

    companion object {
        // নিষিদ্ধ সময়ের দৈর্ঘ্য — নামাজ ফিচারের (নফল ও নিষিদ্ধ সময়ের কার্ড) নিয়মের হুবহু একই
        const val FORBID_MORNING_MS = 15 * 60_000L   // সূর্যোদয়ের পর
        const val FORBID_NOON_MS = 12 * 60_000L      // যোহরের আগে (যাওয়াল)
        const val FORBID_EVENING_MS = 15 * 60_000L   // সূর্যাস্তের আগে

        private const val DAY_MS = 24 * 60 * 60 * 1000L

        // নামাজের সময় না পাওয়া গেলে (অ্যাপ একবারও সময় লোড করেনি) শুধু দেখানোর জন্য আনুমানিক সময় —
        // ব্যাকগ্রাউন্ডে আসল সময় আনার কাজ আলাদাভাবে চলে (WidgetRefreshScheduler.enqueueFetchNow)।
        private val FALLBACK = arrayOf("04:45", "06:05", "12:00", "15:25", "17:55", "19:15")

        private fun clock12(ms: Long, pad: Boolean): String {
            val c = Calendar.getInstance(); c.timeInMillis = ms
            var h = c.get(Calendar.HOUR); if (h == 0) h = 12
            val m = c.get(Calendar.MINUTE)
            return Bn.digits((if (pad && h < 10) "0$h" else "$h") + ":" + Bn.pad2(m))
        }

        /** "HH:mm" (বা "HH:mm (+06)") → আজকের দিনের ওই সময়ের মিলিসেকেন্ড; না পেলে null */
        private fun todayAt(hhmm: String?, dayStartMs: Long): Long? {
            if (hhmm.isNullOrBlank()) return null
            return try {
                val p = hhmm.trim().split(" ")[0].split(":")
                val h = p[0].toInt(); val m = p[1].toInt()
                if (h !in 0..23 || m !in 0..59) null else dayStartMs + h * 3_600_000L + m * 60_000L
            } catch (_: Exception) { null }
        }

        /** নামাজ ফিচারের সেভ করা সময় আছে কি না (নেই বা আজকের জন্য পুরনো হলে ব্যাকগ্রাউন্ড fetch-এর দরকার) */
        fun hasSavedTimings(ctx: Context): Boolean =
            ctx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
                .getString(PrayerWidgetProvider.KEY_TIMINGS, null) != null

        // ---- তারিখ (অ্যাপের হোমের সাথে এক) -----------------------------------------------------

        /** আরবি তারিখ: ইংরেজি সংখ্যার স্ট্রিং ("১২ ..." নয়, "12 রবিউস সানি 1447") — অ্যাপের হোমের লজিক */
        private fun hijriRaw(ctx: Context, data: JSONObject?, afterMaghrib: Boolean): String {
            val prefs = ctx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            val baseHijri = data?.optString("hijri", "-- --- ----") ?: "-- --- ----"
            val hijriFirebase = prefs.getString("hijri_date_firebase", null)
            val adjustment = prefs.getInt("last_rtdb_adjustment", 0)
            val today = FirebaseDataManager.todayDateOnlyStr()

            // ওভাররাইড চালু থাকলে অ্যাপে যে তারিখ দেখায় হুবহু সেটিই (দিন-এগোনো/মাগরিব-শিফট ছাড়া)
            val overrideDate = FirebaseDataManager.overrideHijriOrNull(prefs)
            var date = if (overrideDate != null) {
                overrideDate
            } else if (!hijriFirebase.isNullOrBlank()) {
                val setOn = prefs.getString("hijri_date_firebase_set_on", today) ?: today
                FirebaseDataManager.adjustHijriDate(hijriFirebase, FirebaseDataManager.daysBetweenDateStr(setOn, today))
            } else if (baseHijri != "-- --- ----") {
                val fetchedOn = prefs.getString("timings_fetched_on", today) ?: today
                FirebaseDataManager.adjustHijriDate(baseHijri, adjustment + FirebaseDataManager.daysBetweenDateStr(fetchedOn, today))
            } else baseHijri

            // আজকের মাগরিব পার হলে শুধু আজকের আংশিক দিনের জন্য ১ দিন এগিয়ে যায়
            if (date != "-- --- ----" && afterMaghrib && overrideDate == null) {
                date = FirebaseDataManager.adjustHijriDate(date, 1)
            }
            return date
        }

        // ইংরেজি ও বাংলা মাসের নাম — index.html-এর gregorianMonthsBN/banglaMonthsBN-এর সাথে হুবহু
        private val GREG_MONTHS = Bn.GREG_MONTHS
        private val BANGLA_MONTHS = Bn.BANGLA_MONTHS

        /** index.html-এর getBengaliCalendarCalculation()-এর হুবহু কোটলিন সংস্করণ (পহেলা বৈশাখ = ১৪ এপ্রিল) → (দিন, মাস-সূচক, সাল) */
        private fun banglaOf(nowMs: Long): Triple<Int, Int, Int> {
            val now = Calendar.getInstance().apply {
                timeInMillis = nowMs
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val gYear = now.get(Calendar.YEAR)
            val isLeap = (gYear % 4 == 0 && gYear % 100 != 0) || (gYear % 400 == 0)
            val daysInMonths = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (isLeap) 30 else 29, 30)
            var bYear = gYear - 593
            var poyla = Calendar.getInstance().apply { set(gYear, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            if (now.timeInMillis < poyla.timeInMillis) {
                bYear -= 1
                poyla = Calendar.getInstance().apply { set(gYear - 1, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            }
            val diffDays = ((now.timeInMillis - poyla.timeInMillis) / 86400000L).toInt()
            var monthIdx = 0
            var bDay = diffDays + 1
            while (monthIdx < daysInMonths.size && bDay > daysInMonths[monthIdx]) { bDay -= daysInMonths[monthIdx]; monthIdx++ }
            if (monthIdx >= BANGLA_MONTHS.size) monthIdx = BANGLA_MONTHS.size - 1
            return Triple(bDay, monthIdx, bYear)
        }

        fun build(ctx: Context, nowMs: Long = System.currentTimeMillis()): Snapshot {
            val app = ctx.applicationContext
            val prefs = Prefs.get(app)
            val sp = app.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            val data: JSONObject? = try { sp.getString(PrayerWidgetProvider.KEY_TIMINGS, null)?.let { JSONObject(it) } } catch (_: Exception) { null }

            val cal0 = Calendar.getInstance().apply {
                timeInMillis = nowMs
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val dayStart = cal0.timeInMillis
            val nextDayStart = (cal0.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis

            fun t(key: String, idx: Int): Long =
                todayAt(data?.optString(key, ""), dayStart) ?: todayAt(FALLBACK[idx], dayStart)!!
            val fajr = t("fajr", 0)
            val sunrise = t("sunrise", 1)
            val dhuhr = t("dhuhr", 2)
            val asr = t("asr", 3)
            val maghrib = t("maghrib", 4)
            val isha = t("isha", 5)
            // সূর্যাস্ত = নামাজ ফিচারের "sunset" (না থাকলে মাগরিব)
            val sunset = todayAt(data?.optString("sunset", ""), dayStart) ?: maghrib

            // গতকালের ইশা ও আগামীকালের ফজর/সূর্যোদয় (আজকের সময়ের ±২৪ ঘণ্টা — নামাজ ফিচারের নিয়ম)
            val prevIsha = isha - DAY_MS
            val nextFajr = fajr + DAY_MS
            val prevMaghrib = maghrib - DAY_MS
            val nextSunrise = sunrise + DAY_MS

            val cur: Int; val start: Long; val end: Long; val running: Boolean
            when {
                nowMs < fajr -> { cur = 4; start = prevIsha; end = fajr; running = true }
                nowMs < sunrise -> { cur = 0; start = fajr; end = sunrise; running = true }
                nowMs < dhuhr -> { cur = -1; start = sunrise; end = dhuhr; running = false }
                nowMs < asr -> { cur = 1; start = dhuhr; end = asr; running = true }
                nowMs < maghrib -> { cur = 2; start = asr; end = maghrib; running = true }
                nowMs < isha -> { cur = 3; start = maghrib; end = isha; running = true }
                else -> { cur = 4; start = isha; end = nextFajr; running = true }
            }
            // বৃহস্পতিবার সূর্যাস্তের পর থেকে শুক্রবার সূর্যাস্ত পর্যন্ত "যোহর"-এর জায়গায় "জুমা"
            val dow = cal0.get(Calendar.DAY_OF_WEEK)
            val jumuah = (dow == Calendar.FRIDAY && nowMs < maghrib) || (dow == Calendar.THURSDAY && nowMs >= maghrib)
            val names = Bn.PRAYER_NAMES.copyOf()
            if (jumuah) names[1] = "জুমা"
            val name = if (cur >= 0) names[cur] else names[1]

            // ---- তারিখ ----
            val bn = banglaOf(nowMs)
            val rawHijri = hijriRaw(app, data, nowMs >= maghrib)
            val hijriBn = FirebaseDataManager.convertEnglishToBengali(rawHijri).trim()
            val parts = hijriBn.split(" ").filter { it.isNotEmpty() }
            val hjDayTxt: String; val hjMonthTxt: String; val hjYearTxt: String
            if (parts.size >= 3) {
                hjDayTxt = parts.first(); hjYearTxt = parts.last(); hjMonthTxt = parts.subList(1, parts.size - 1).joinToString(" ")
            } else { hjDayTxt = "--"; hjMonthTxt = "---"; hjYearTxt = "----" }

            val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
            val isPm = cal.get(Calendar.HOUR_OF_DAY) >= 12

            // পরবর্তী রিফ্রেশ: ওয়াক্তের সীমা, ১ ঘণ্টা/১০ ঘণ্টা পার হলে Chronometer-এর ফরম্যাট বদল,
            // দুপুর ১২টা ও মধ্যরাত (AM/PM ও তারিখ)।
            val noon = dayStart + 12 * 3600_000L
            val midnight = nextDayStart
            val cands = ArrayList<Long>()
            cands += listOf(fajr, sunrise, dhuhr, asr, maghrib, isha, nextFajr, noon, midnight)
            cands += listOf(sunrise + FORBID_MORNING_MS, dhuhr - FORBID_NOON_MS, sunset - FORBID_EVENING_MS)
            for (h in longArrayOf(3600_000L, 36000_000L)) { cands += end - h; cands += start + h }
            var next = Long.MAX_VALUE
            for (c in cands) if (c > nowMs + 500 && c < next) next = c
            if (next == Long.MAX_VALUE) next = nowMs + 60_000L

            // নিষিদ্ধ সময় (নামাজ পড়া মাকরূহ): সূর্যোদয়ের পর, ঠিক দুপুর (যাওয়ালের আগে), সূর্যাস্তের আগে
            val srEnd = sunrise + FORBID_MORNING_MS
            val noonStart = dhuhr - FORBID_NOON_MS
            val evStart = sunset - FORBID_EVENING_MS
            var forbid = 0; var forbidEnd = 0L; var forbidStart = 0L
            when {
                nowMs >= sunrise && nowMs < srEnd -> { forbid = 1; forbidEnd = srEnd; forbidStart = sunrise }
                nowMs >= srEnd && nowMs < noonStart -> forbid = 2
                nowMs >= noonStart && nowMs < dhuhr -> { forbid = 1; forbidEnd = dhuhr; forbidStart = noonStart }
                nowMs >= evStart && nowMs < sunset -> { forbid = 1; forbidEnd = sunset; forbidStart = evStart }
            }

            // দিনে সূর্যাস্ত দেখানো হয় (সূর্যোদয় থেকে সূর্যাস্ত পর্যন্ত); সূর্যাস্তের পর থেকে পরের সূর্যোদয় পর্যন্ত সূর্যোদয়
            val isDay = nowMs >= sunrise && nowMs < sunset

            return Snapshot(
                nowMs = nowMs,
                hijriMonthYear = "$hjMonthTxt $hjYearTxt",
                gregDay = Bn.digits(cal0.get(Calendar.DAY_OF_MONTH)),
                gregMonth = GREG_MONTHS[cal0.get(Calendar.MONTH)],
                gregYear = Bn.digits(cal0.get(Calendar.YEAR)),
                banglaDay = Bn.digits(bn.first),
                banglaMonth = BANGLA_MONTHS[bn.second],
                banglaYear = Bn.digits(bn.third),
                hijriDay = hjDayTxt,
                hijriMonth = hjMonthTxt,
                hijriYear = hjYearTxt,
                prayerNames = names,
                prayerTimes = arrayOf(
                    clock12(fajr, true), clock12(dhuhr, true), clock12(asr, true),
                    clock12(maghrib, true), clock12(isha, true)
                ),
                sunrise = clock12(sunrise, false),
                sehri = clock12(fajr, false),
                iftar = clock12(maghrib, false),
                current = cur, currentName = name, running = running,
                periodStartMs = start, periodEndMs = end,
                isPm = isPm,
                nextChangeMs = next + 1000L,
                sunriseMs = sunrise, sunsetMs = sunset,
                nightStartMs = if (nowMs < sunrise) prevMaghrib else sunset,
                nightEndMs = if (nowMs < sunrise) sunrise else nextSunrise,
                forbid = forbid, forbidEndMs = forbidEnd, forbidStartMs = forbidStart,
                gregFirst = prefs.gregFirst,
                sunIsSet = isDay,
                sunLabel = if (isDay) "সূর্যাস্ত" else "সূর্যোদয়",
                sunTime = if (isDay) clock12(sunset, false) else clock12(if (nowMs < sunrise) sunrise else nextSunrise, false)
            )
        }
    }
}
