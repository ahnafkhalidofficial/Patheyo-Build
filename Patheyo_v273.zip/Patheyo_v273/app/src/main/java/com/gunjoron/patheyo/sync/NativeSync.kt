package com.gunjoron.patheyo.sync

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.gunjoron.patheyo.calnote.CalNotes
import com.gunjoron.patheyo.datecard.DateCardPrefs
import com.gunjoron.patheyo.datecard.DateCardScheduler
import com.gunjoron.patheyo.reminder.SmartReminders
import com.gunjoron.patheyo.widget.HubPreview
import com.gunjoron.patheyo.widgethub.data.Prefs
import com.gunjoron.patheyo.widgethub.widget.WidgetUpdater
import org.json.JSONObject
import java.lang.ref.WeakReference

/**
 * v247: নেটিভ (ফোনের SharedPreferences-এ থাকা) ডেটা অ্যাপের একই ক্লাউড-সিঙ্কে (Supabase user_backups) তোলার সেতু।
 *
 * কেন: অ্যাপের বেশিরভাগ ডেটা WebView-র localStorage-এ থাকে — সেগুলো shell/js/07-backup-settings.js-এর KEYS তালিকা ধরে
 * আগে থেকেই ব্যাকআপ-ফাইলে ও ক্লাউডে যায়। কিন্তু নোট/রিমাইন্ডার/তারিখ-কার্ড/উইজেট-হাবের সেটিংস নেটিভ স্টোরেজে থাকায়
 * কোনো ক্লাউডে যেত না (v245-এ শুধু আর্কাইভ গিয়েছিল Firebase-এ, আলাদা পথে)। এখন এই সব একটাই JSON হয়ে
 * ব্যাকআপের `pt_native_v1` চাবিতে ঢোকে — তাই ক্লাউডের নিয়ম, যাচাই, ফেরত আনা সব একই; Firebase-এ কোনো রুল লাগে না।
 *
 * মূল নিয়ম: [export] সবসময় স্থির লেখা দেয় (একই ডেটা = একই লেখা), নইলে দুই ফোন একে অপরকে অনন্ত পাঠাতে থাকত।
 * তাই নোটের id/fired ও আর্কাইভের সময় এতে নেই (CalNotes.syncKey দেখুন)।
 *
 * নতুন নেটিভ ডেটা ক্লাউডে যোগ করতে: [export]-এ একটি অংশ + [applyAll]-এ তার উল্টো কাজ + [wipe]-এ সাফ করা — এই তিন জায়গায়।
 */
object NativeSync {
    const val VERSION = 1

    @Volatile private var wv: WeakReference<WebView>? = null

    /** MainActivity WebView বানিয়ে এটি ডাকে — নেটিভে ডেটা বদলালে JS-কে জানানোর জন্য */
    fun attach(w: WebView) { wv = WeakReference(w) }

    /** ডেটা বদলেছে — JS (shell/js/10-account.js) দেড় সেকেন্ডে ক্লাউডে পাঠিয়ে দেবে। WebView না থাকলে পরে অ্যাপ খুললে/১৫ সেকেন্ডের চেকে ধরা পড়বে */
    fun nudge() {
        val w = wv?.get() ?: return
        try {
            w.post {
                try { w.evaluateJavascript("if(window.__ptNativeChanged)window.__ptNativeChanged();", null) } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ রপ্তানি

    fun export(ctx: Context): String {
        val app = ctx.applicationContext
        val o = JSONObject()
        o.put("v", VERSION)
        try { o.put("notes", CalNotes.syncExport(app)) } catch (_: Throwable) {}
        try { o.put("reminders", remindersOut(app)) } catch (_: Throwable) {}
        try { o.put("datecard", dateCardOut(app)) } catch (_: Throwable) {}
        try { o.put("hub", hubOut(app)) } catch (_: Throwable) {}
        return o.toString()
    }

    private val REM_BOOL = listOf("kahf", "monthu", "ayyam", "zikr", "islamic", "national", "sleep")

    private fun remindersOut(app: Context): JSONObject {
        val g = SmartReminders.get(app)
        val r = JSONObject()
        for (k in REM_BOOL) r.put(k, g.optBoolean(k, k != "sleep"))
        r.put("sleepTime", g.optString("sleepTime", "22:30"))
        return r
    }

    private fun dateCardOut(app: Context): JSONObject {
        val p = DateCardPrefs(app)
        return JSONObject()
            .put("auto", p.autoDaily).put("notify", p.notify).put("gallery", p.saveGallery)
            .put("theme", p.theme).put("format", p.format).put("scrim", p.scrim)
    }

    private fun hubOut(app: Context): JSONObject {
        val p = Prefs.get(app)
        return JSONObject()
            .put("theme", p.theme).put("nobgMode", p.nobgMode).put("design", p.design).put("wdesign", p.widgetDesign)
            .put("customBg", p.customBg).put("customOpacity", p.customOpacity).put("customTone", p.customTone)
            .put("gregFirst", p.gregFirst)
    }

    // ------------------------------------------------------------------ বসানো

    /**
     * ক্লাউডের নেটিভ ডেটা ফোনে বসানো। [merge] = true হলে (প্রথমবার সাইন-ইন; ফোনে আগে থেকে নিজের নোট থাকতে পারে)
     * নোট শুধু যোগ হয়, কিছু মোছে না। false হলে ক্লাউডই সত্য।
     * সেটিংসগুলো সবসময় ক্লাউডেরটাই (অ্যাপের বাকি সেটিংসের মতো)।
     */
    fun applyAll(ctx: Context, json: String, merge: Boolean): Boolean {
        val app = ctx.applicationContext
        val o = try { JSONObject(json) } catch (_: Throwable) { return false }
        if (o.optInt("v", 0) < 1) return false
        var ok = true
        o.optJSONArray("notes")?.let { arr -> try { CalNotes.syncApply(app, arr, !merge) } catch (_: Throwable) { ok = false } }
        o.optJSONObject("reminders")?.let { r -> try { remindersIn(app, r) } catch (_: Throwable) { ok = false } }
        o.optJSONObject("datecard")?.let { d -> try { dateCardIn(app, d) } catch (_: Throwable) { ok = false } }
        o.optJSONObject("hub")?.let { h -> try { hubIn(app, h) } catch (_: Throwable) { ok = false } }
        return ok
    }

    private fun remindersIn(app: Context, r: JSONObject) {
        if (remindersOut(app).toString() == r.toString()) return
        SmartReminders.set(app, r.toString())      // নিজেই যাচাই করে, শিডিউল বসায়
    }

    private fun dateCardIn(app: Context, d: JSONObject) {
        val p = DateCardPrefs(app)
        if (dateCardOut(app).toString() == d.toString()) return
        if (d.has("auto")) p.autoDaily = d.optBoolean("auto", true)
        if (d.has("notify")) p.notify = d.optBoolean("notify", true)
        if (d.has("gallery")) p.saveGallery = d.optBoolean("gallery", false)
        if (d.has("theme")) p.theme = d.optString("theme", "auto").ifBlank { "auto" }
        if (d.has("format")) p.format = if (d.optString("format") == "story") "story" else "post"
        if (d.has("scrim")) p.scrim = d.optInt("scrim", 45)
        try { DateCardScheduler.schedule(app) } catch (_: Throwable) {}
    }

    private fun hubIn(app: Context, h: JSONObject) {
        if (hubOut(app).toString() == h.toString()) return
        val p = Prefs.get(app)
        if (h.has("theme") && h.optString("theme") in listOf("glass", "nobg", "light", "custom")) p.theme = h.optString("theme")
        if (h.has("nobgMode")) p.nobgMode = if (h.optString("nobgMode") == "light") "light" else "dark"
        if (h.has("design")) p.design = h.optInt("design", 1)
        if (h.has("wdesign")) p.widgetDesign = h.optInt("wdesign", 1)
        if (h.has("customBg")) p.customBg = h.optInt("customBg", 0x1E293B)
        if (h.has("customOpacity")) p.customOpacity = h.optInt("customOpacity", 90)
        if (h.has("customTone")) p.customTone = h.optString("customTone", "auto").let { if (it == "dark" || it == "light") it else "auto" }
        if (h.has("gregFirst")) p.gregFirst = h.optBoolean("gregFirst", false)
        try { HubPreview.invalidate() } catch (_: Throwable) {}
        try { WidgetUpdater.updateAll(app) } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ সাইন-আউটে সাফ

    /** এই ফোনকে "প্রথম দিনের" অবস্থায় ফেরানো (সাইন-আউটের পর অন্য অ্যাকাউন্টে ডেটা না মিশতে) */
    fun wipe(ctx: Context) {
        val app = ctx.applicationContext
        try { CalNotes.syncReset(app) } catch (_: Throwable) {}
        try { remindersIn(app, JSONObject()
            .put("kahf", true).put("monthu", true).put("ayyam", true).put("zikr", true)
            .put("islamic", true).put("national", true).put("sleep", false).put("sleepTime", "22:30")) } catch (_: Throwable) {}
        try { dateCardIn(app, JSONObject()
            .put("auto", true).put("notify", true).put("gallery", false)
            .put("theme", "auto").put("format", "post").put("scrim", 45)) } catch (_: Throwable) {}
        try { hubIn(app, JSONObject()
            .put("theme", "glass").put("nobgMode", "dark").put("design", 1).put("wdesign", 1)
            .put("customBg", 0x1E293B).put("customOpacity", 90).put("customTone", "auto").put("gregFirst", false)) } catch (_: Throwable) {}
    }
}

/** JS ↔ নেটিভ সিঙ্ক (window.PatheyoNativeSync) — ব্যবহারকারী shell/js/07-backup-settings.js ও index.html-এর রিস্টোর-স্ক্রিপ্ট */
class NativeSyncBridge(private val ctx: Context) {
    @JavascriptInterface
    fun exportAll(): String = try { NativeSync.export(ctx) } catch (_: Throwable) { "" }

    @JavascriptInterface
    fun applyAll(json: String, merge: Boolean): Boolean = try { NativeSync.applyAll(ctx, json, merge) } catch (_: Throwable) { false }

    @JavascriptInterface
    fun wipe(): Boolean = try { NativeSync.wipe(ctx); true } catch (_: Throwable) { false }
}
