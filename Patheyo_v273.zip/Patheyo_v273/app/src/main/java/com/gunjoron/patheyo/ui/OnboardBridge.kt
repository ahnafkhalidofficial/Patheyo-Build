package com.gunjoron.patheyo.ui

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.gunjoron.patheyo.MainActivity

/**
 * ধাপ ১১: প্রথমবার খোলার গাইড (অনবোর্ডিং) ↔ নেটিভ অনুমতি।
 *
 * নতুন ইনস্টলে MainActivity শুরুর অনুমতি-ধারা (লোকেশন → নোটিফিকেশন → অ্যালার্ম/ব্যাটারি) নিজে চালায় না —
 * অপেক্ষা করে। ওয়েবের অনবোর্ডিং (shell/js/16-onboarding.js) তিনটি স্ক্রিনে কারণ বুঝিয়ে নিজেই চায়:
 *   PatheyoOnboard.pending()            → true হলে গাইড দেখাও
 *   PatheyoOnboard.requestLocation()    → ফোনের লোকেশন-পপআপ   → window.__ptOnbCb('loc', true|false)
 *   PatheyoOnboard.requestNotification()→ ফোনের নোটিফিকেশন-পপআপ → window.__ptOnbCb('notif', true|false)
 *   PatheyoOnboard.done()               → গাইড শেষ; বাকি আজান-নির্ভরযোগ্যতার ধাপ (এক্সাক্ট অ্যালার্ম, ব্যাটারি…) চলে
 * আপডেট করা পুরনো ব্যবহারকারী (firstInstallTime ≠ lastUpdateTime) গাইড দেখেন না — আগের মতোই চলে।
 */
class OnboardBridge(private val act: MainActivity, private val web: WebView) {

    companion object {
        private const val PREFS = "patheyo_onboarding"
        private const val KEY_DONE = "done"

        fun isFreshInstall(ctx: Context): Boolean = try {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            pi.firstInstallTime == pi.lastUpdateTime
        } catch (_: Throwable) { false }

        fun pending(ctx: Context): Boolean =
            !ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DONE, false) && isFreshInstall(ctx)

        fun markDone(ctx: Context) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_DONE, true).apply()
        }
    }

    private fun cb(kind: String, ok: Boolean) {
        web.post { try { web.evaluateJavascript("window.__ptOnbCb&&window.__ptOnbCb('$kind',$ok)", null) } catch (_: Throwable) {} }
    }

    @JavascriptInterface
    fun pending(): Boolean = pending(act)

    @JavascriptInterface
    fun hasLocation(): Boolean = act.onboardHasLocation()

    @JavascriptInterface
    fun hasNotification(): Boolean = act.onboardHasNotification()

    @JavascriptInterface
    fun requestLocation() { act.runOnUiThread { act.onboardRequestLocation { ok -> cb("loc", ok) } } }

    @JavascriptInterface
    fun requestNotification() { act.runOnUiThread { act.onboardRequestNotification { ok -> cb("notif", ok) } } }

    @JavascriptInterface
    fun done() {
        markDone(act)
        act.runOnUiThread { act.onboardFinished() }
    }
}
