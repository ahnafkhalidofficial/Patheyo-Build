package com.gunjoron.patheyo.auth

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.CancellationSignal
import android.os.SystemClock
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.OAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.gunjoron.patheyo.stats.BackendConfig
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * ধাপ ৯ — অ্যাকাউন্ট (JS-এ নাম: PatheyoAuth)
 *
 *  • Google: Android Credential Manager-এর "Sign in with Google" শিট → Google ID টোকেন → Firebase Auth।
 *  • ইমেইল: সাইন-আপ (নাম সহ, যাচাইয়ের ইমেইল যায়), সাইন-ইন, পাসওয়ার্ড রিসেট, যাচাই আবার পাঠানো।
 *  • ক্লাউড সিঙ্ক (v185 থেকে Supabase): অ্যাকাউন্ট Firebase-এ, কিন্তু ব্যাকআপ Supabase-এর user_backups টেবিলে।
 *    অ্যাপ Firebase ID টোকেন দিয়ে Edge Function "cloud-sync" ডাকে; সে টোকেন যাচাই করে শুধু ওই uid-এর সারি পড়ে/লেখে/মোছে।
 *    (data = সেটিংসের "ব্যাকআপ" ফাইলের হুবহু লেখা — তাই রিস্টোরও একই যাচাই দিয়ে হয়)। সেটআপ: docs/SUPABASE_CLOUD_SYNC.md
 *    পুরনো (v184-পর্যন্ত) ব্যাকআপ Firebase-এ থাকলে প্রথমবার সেখান থেকে পড়া হয়; পরের সেভ Supabase-এ গিয়ে পুরনোটা মুছে যায়।
 *  • অ্যাকাউন্ট মুছে ফেলা: Supabase-এর ব্যাকআপ + ছবি + Firebase-এর users/{uid} + অ্যাকাউন্ট (দরকার হলে আবার যাচাই করে)।
 *
 * সব কাজ async: JS একটি reqId দেয়, ফলাফল আসে  window.__ptAuthCb(reqId, json)
 *   json = {"ok":true, "state":{…}, …}  অথবা  {"ok":false, "code":"…", "msg":"বাংলায় কারণ"}
 * সাইন-ইন/আউট হলে আলাদা করে  window.__ptAuthChanged(state)।
 */
class AuthBridge(private val activity: Activity, private val webView: WebView) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val io = Executors.newSingleThreadExecutor()
    private val creds by lazy { CredentialManager.create(activity) }

    init {
        try {
            auth.addAuthStateListener { emit("window.__ptAuthChanged&&window.__ptAuthChanged(" + JSONObject.quote(stateJson().toString()) + ")") }
        } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ JS-এর দিকে

    private fun emit(js: String) {
        try { webView.post { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} } } catch (_: Throwable) {}
    }

    private fun reply(req: String, o: JSONObject) {
        emit("window.__ptAuthCb&&window.__ptAuthCb(" + JSONObject.quote(req) + "," + JSONObject.quote(o.toString()) + ")")
    }

    private fun ok(req: String, extra: JSONObject? = null) {
        val o = extra ?: JSONObject()
        o.put("ok", true); o.put("state", stateJson()); reply(req, o)
    }

    private fun fail(req: String, code: String, msg: String) {
        reply(req, JSONObject().put("ok", false).put("code", code).put("msg", msg))
    }

    private fun fail(req: String, t: Throwable?) {
        val (code, msg) = explain(t)
        fail(req, code, msg)
    }

    /** ত্রুটির ছোট কোড (পর্দায় দেখানোর জন্য) — কী ভুল হয়েছে ধরতে সুবিধা */
    private fun tag(t: Throwable?): String = when (t) {
        null -> "none"
        is GetCredentialException -> (t.type ?: "").substringAfterLast('.').substringAfterLast(':').ifEmpty { "cred" }
        is FirebaseAuthException -> (t.errorCode ?: "auth").removePrefix("ERROR_")
        is FirebaseNetworkException -> "NETWORK"
        else -> (t.message ?: "x").take(40)
    }

    /** Firebase/Credential-এর ত্রুটি → সহজ বাংলা (v193: অজানা হলেও কোড দেখায়, কিছু চুপ থাকে না) */
    private fun explain(t: Throwable?): Pair<String, String> = when (t) {
        is GetCredentialCancellationException -> "cancel" to ""
        is NoCredentialException -> "no-account" to "এই ফোনে কোনো Google অ্যাকাউন্ট পাওয়া যায়নি। ফোনের সেটিংসে Google অ্যাকাউন্ট যোগ করে আবার চেষ্টা করুন।"
        is GetCredentialException -> "google" to "Google সাইন-ইন খোলা যায়নি (কোড: ${tag(t)})। ইমেইল দিয়ে সাইন-ইন করুন।"
        is FirebaseNetworkException -> "network" to "ইন্টারনেট সংযোগ নেই। সংযোগ দিয়ে আবার চেষ্টা করুন।"
        is FirebaseTooManyRequestsException -> "many" to "অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।"
        is FirebaseAuthException -> when (t.errorCode) {
            "ERROR_INVALID_EMAIL" -> "email" to "ইমেইল ঠিকানাটি সঠিক নয়।"
            "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL", "ERROR_USER_NOT_FOUND", "ERROR_INVALID_LOGIN_CREDENTIALS" ->
                "wrong" to "ইমেইল বা পাসওয়ার্ড মেলেনি।"
            "ERROR_EMAIL_ALREADY_IN_USE" -> "exists" to "এই ইমেইলে আগে থেকেই অ্যাকাউন্ট আছে — সাইন-ইন করুন।"
            "ERROR_WEAK_PASSWORD" -> "weak" to "পাসওয়ার্ড অন্তত ৬ অক্ষরের দিন।"
            "ERROR_USER_DISABLED" -> "disabled" to "এই অ্যাকাউন্টটি বন্ধ করা আছে।"
            "ERROR_REQUIRES_RECENT_LOGIN" -> "recent" to "নিরাপত্তার জন্য আবার সাইন-ইন করে চেষ্টা করুন।"
            "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" -> "other-provider" to "এই ইমেইলে অন্য পদ্ধতিতে (Google বা ইমেইল) অ্যাকাউন্ট খোলা আছে — সেই পদ্ধতিতেই সাইন-ইন করুন।"
            "ERROR_WEB_CONTEXT_CANCELED" -> "cancel" to ""
            "ERROR_NETWORK_REQUEST_FAILED" -> "network" to "ইন্টারনেট সংযোগ নেই। সংযোগ দিয়ে আবার চেষ্টা করুন।"
            "ERROR_OPERATION_NOT_ALLOWED" -> "off-method" to "এই সাইন-ইন পদ্ধতি Firebase-এ চালু নেই (কোড: OPERATION_NOT_ALLOWED)।"
            "ERROR_INVALID_CERT_HASH", "ERROR_APP_NOT_AUTHORIZED" -> "cert" to "এই অ্যাপের সাইনিং-কী (SHA) Firebase-এ যোগ করা নেই (কোড: ${tag(t)})।"
            else -> (t.errorCode ?: "auth") to "কাজটি সম্পন্ন করা যায়নি (কোড: ${tag(t)})। একটু পরে আবার চেষ্টা করুন।"
        }
        else -> "error" to "কাজটি সম্পন্ন করা যায়নি (${tag(t)})। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।"
    }

    private fun stateJson(u: FirebaseUser? = try { auth.currentUser } catch (_: Throwable) { null }): JSONObject {
        val o = JSONObject()
        if (u == null) return o.put("signedIn", false)
        val provider = u.providerData.map { it.providerId }.firstOrNull { it == "google.com" || it == "password" } ?: "password"
        return o.put("signedIn", true).put("uid", u.uid)
            .put("name", u.displayName ?: "").put("email", u.email ?: "")
            .put("photo", u.photoUrl?.toString() ?: "")
            .put("provider", if (provider == "google.com") "google" else "email")
            .put("verified", u.isEmailVerified || provider == "google.com")
    }

    private fun db() = FirebaseDatabase.getInstance(RTDB_URL)

    /** অ্যাকাউন্টের ছোট পরিচিতি (নাম/ইমেইল/শেষ দেখা) — পরে প্রিমিয়াম ইত্যাদির জন্য */
    private fun touchProfile(u: FirebaseUser) {
        try {
            db().getReference("users").child(u.uid).child("profile").updateChildren(mapOf(
                "name" to (u.displayName ?: ""), "email" to (u.email ?: ""),
                "provider" to (stateJson(u).optString("provider")), "lastSeen" to ServerValue.TIMESTAMP,
                "device" to (Build.MANUFACTURER + " " + Build.MODEL)))
        } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ অবস্থা

    @JavascriptInterface
    fun state(): String = try { stateJson().toString() } catch (_: Throwable) { "{\"signedIn\":false}" }

    @JavascriptInterface
    fun available(): Boolean = true

    // ------------------------------------------------------------------ Google

    private fun googleToken(onToken: (String) -> Unit, onFail: (Throwable?) -> Unit) {
        val id = activity.resources.getIdentifier("default_web_client_id", "string", activity.packageName)
        if (id == 0) { onFail(IllegalStateException("no web client id")); return }
        val option = GetSignInWithGoogleOption.Builder(activity.getString(id)).build()
        val req = GetCredentialRequest.Builder().addCredentialOption(option).build()
        activity.runOnUiThread {
            try {
                creds.getCredentialAsync(activity, req, CancellationSignal(), io,
                    object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                        override fun onResult(result: GetCredentialResponse) {
                            val c = result.credential
                            if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                try { onToken(GoogleIdTokenCredential.createFrom(c.data).idToken) } catch (t: Throwable) { onFail(t) }
                            } else onFail(null)
                        }
                        override fun onError(e: GetCredentialException) { onFail(e) }
                    })
            } catch (t: Throwable) { onFail(t) }
        }
    }

    /** Google-এর টোকেন → Firebase সাইন-ইন (দুই পথেই একই) */
    private fun firebaseWithGoogleToken(req: String, token: String) {
        val cred = GoogleAuthProvider.getCredential(token, null)
        auth.signInWithCredential(cred).addOnCompleteListener { t ->
            val u = auth.currentUser
            if (t.isSuccessful && u != null) { touchProfile(u); ok(req, JSONObject().put("isNew", t.result?.additionalUserInfo?.isNewUser == true)) }
            else fail(req, t.exception)
        }
    }

    /**
     * v193 — Google সাইন-ইন আর কখনো চুপচাপ কাটে না।
     *  ১) প্রথমে ফোনের Google শিট (Credential Manager)।
     *  ২) শিট নিজে থেকে (১.৫ সেকেন্ডের আগেই) কেটে গেলে — সাইনিং-কী (SHA) না মিললে ঠিক এমনই হয়, আর সিস্টেম একে "বাতিল" বলে —
     *     অথবা অন্য কোনো ত্রুটি হলে → Firebase-এর নিজের ব্রাউজার-পথ (SHA-এর ওপর নির্ভর করে না)।
     *  ৩) ইউজার নিজে শিট বন্ধ করলে (১.৫ সেকেন্ডের পরে) কিছু দেখানো হয় না — সেটি ঠিকই।
     *  দুই পথই ব্যর্থ হলে কারণের কোডসহ বাংলা বার্তা যায়।
     */
    @JavascriptInterface
    fun google(req: String) {
        val t0 = SystemClock.elapsedRealtime()
        googleToken({ token -> firebaseWithGoogleToken(req, token) }, { e ->
            val userCancelled = e is GetCredentialCancellationException && SystemClock.elapsedRealtime() - t0 >= 1500
            when {
                // v194: শিটে অ্যাকাউন্ট বেছেও সাইন-ইন না হলে Android একেও "বাতিল" বলে — তাই চুপ না থেকে কারণের লেখা (detail) সহ JS-কে জানানো,
                // JS "ব্রাউজার দিয়ে সাইন-ইন" বাটন দেখায়।
                userCancelled -> reply(req, JSONObject().put("ok", false).put("code", "cancel").put("msg", "")
                    .put("detail", tag(e) + ": " + (e?.message ?: "").take(80)))
                e is FirebaseNetworkException -> fail(req, e)
                else -> googleViaBrowser(req, e)
            }
        })
    }

    /** v194: SHA/OAuth-কনফিগের ওপর নির্ভর না করা পথ — সরাসরি Firebase-এর ব্রাউজার সাইন-ইন (JS-এর "ব্রাউজার দিয়ে" বাটন) */
    @JavascriptInterface
    fun googleWeb(req: String) = googleViaBrowser(req, null)

    private fun googleViaBrowser(req: String, cause: Throwable?) {
        activity.runOnUiThread {
            try {
                val provider = OAuthProvider.newBuilder("google.com")
                    .setScopes(listOf("email", "profile"))
                    .addCustomParameter("prompt", "select_account")
                    .addCustomParameter("hl", "bn")
                    .build()
                val task = auth.pendingAuthResult ?: auth.startActivityForSignInWithProvider(activity, provider)
                task.addOnSuccessListener { r ->
                    val u = auth.currentUser
                    if (u != null) { touchProfile(u); ok(req, JSONObject().put("isNew", r.additionalUserInfo?.isNewUser == true)) }
                    else fail(req, "google", "Google সাইন-ইন সম্পন্ন হলো না। ইমেইল দিয়ে সাইন-ইন করুন।")
                }.addOnFailureListener { e2 ->
                    val (code, msg) = explain(e2)
                    if (code == "cancel") fail(req, "cancel", "")
                    else if (code == "network" || code == "many" || code == "disabled" || code == "other-provider") fail(req, code, msg)
                    else fail(req, "google", "Google সাইন-ইন হলো না (কোড: ${tag(cause)}/${tag(e2)})। ইমেইল দিয়ে সাইন-ইন করুন।")
                }
            } catch (t: Throwable) {
                fail(req, "google", "Google সাইন-ইন খোলা যায়নি (কোড: ${tag(cause)}/${tag(t)})। ইমেইল দিয়ে সাইন-ইন করুন।")
            }
        }
    }

    // ------------------------------------------------------------------ ইমেইল

    @JavascriptInterface
    fun emailIn(req: String, email: String, pass: String) {
        try {
            auth.signInWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                val u = auth.currentUser
                if (t.isSuccessful && u != null) { touchProfile(u); ok(req) } else fail(req, t.exception)
            }
        } catch (t: Throwable) { fail(req, t) }
    }

    @JavascriptInterface
    fun emailUp(req: String, name: String, email: String, pass: String) {
        try {
            auth.createUserWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                val u = auth.currentUser
                if (!t.isSuccessful || u == null) { fail(req, t.exception); return@addOnCompleteListener }
                u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim().take(40)).build()).addOnCompleteListener {
                    try { auth.setLanguageCode("bn") } catch (_: Throwable) {}
                    u.sendEmailVerification()
                    touchProfile(u)
                    ok(req, JSONObject().put("isNew", true))
                }
            }
        } catch (t: Throwable) { fail(req, t) }
    }

    @JavascriptInterface
    fun reset(req: String, email: String) {
        try {
            try { auth.setLanguageCode("bn") } catch (_: Throwable) {}
            auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { t ->
                if (t.isSuccessful) ok(req) else fail(req, t.exception)
            }
        } catch (t: Throwable) { fail(req, t) }
    }

    @JavascriptInterface
    fun sendVerify(req: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        try { auth.setLanguageCode("bn") } catch (_: Throwable) {}
        u.sendEmailVerification().addOnCompleteListener { t -> if (t.isSuccessful) ok(req) else fail(req, t.exception) }
    }

    /** ইমেইল যাচাই করার পর "যাচাই করেছি" চাপলে সার্ভার থেকে নতুন অবস্থা */
    @JavascriptInterface
    fun reload(req: String) {
        val u = auth.currentUser ?: return ok(req)
        u.reload().addOnCompleteListener { t -> if (t.isSuccessful) ok(req) else fail(req, t.exception) }
    }

    @JavascriptInterface
    fun setName(req: String, name: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim().take(40)).build())
            .addOnCompleteListener { t -> if (t.isSuccessful) { touchProfile(u); ok(req) } else fail(req, t.exception) }
    }

    /** অ্যাকাউন্টের ছবি (Google) ২৫৬px JPEG dataURL হিসেবে — হোমের প্রোফাইল-ছবিতে বসে, অফলাইনেও দেখা যায় */
    @JavascriptInterface
    fun photo(req: String) {
        val url = auth.currentUser?.photoUrl?.toString().orEmpty()
        if (url.isEmpty()) return ok(req, JSONObject().put("data", ""))
        io.execute {
            try {
                val big = if (url.contains("googleusercontent.com")) url.replace(Regex("=s\\d+(-c)?$"), "") + "=s256-c" else url
                val c = (URL(big).openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000 }
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) } ?: throw IllegalStateException("decode")
                val s = minOf(bmp.width, bmp.height)
                val sq = Bitmap.createBitmap(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s)
                val out = ByteArrayOutputStream()
                Bitmap.createScaledBitmap(sq, 256, 256, true).compress(Bitmap.CompressFormat.JPEG, 86, out)
                ok(req, JSONObject().put("data", "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)))
            } catch (t: Throwable) { ok(req, JSONObject().put("data", "")) }
        }
    }

    @JavascriptInterface
    fun signOut(req: String) {
        try { auth.signOut() } catch (_: Throwable) {}
        try {
            creds.clearCredentialStateAsync(ClearCredentialStateRequest(), CancellationSignal(), io,
                object : CredentialManagerCallback<Void?, ClearCredentialException> {
                    override fun onResult(result: Void?) {}
                    override fun onError(e: ClearCredentialException) {}
                })
        } catch (_: Throwable) {}
        ok(req)
    }

    /**
     * অ্যাকাউন্ট মুছে ফেলা (Play-এর নিয়ম): আগে আবার যাচাই (Google = শিট থেকে অ্যাকাউন্ট বাছাই, ইমেইল = পাসওয়ার্ড),
     * তারপর ক্লাউডের সব ডেটা (Supabase-এর ব্যাকআপ ও ছবি + Firebase-এর users/{uid}) মুছে অ্যাকাউন্ট মুছে ফেলা।
     */
    @JavascriptInterface
    fun deleteAccount(req: String, password: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        val google = stateJson(u).optString("provider") == "google"
        val proceed: (AuthCredential) -> Unit = { cred ->
            u.reauthenticate(cred).addOnCompleteListener { r ->
                if (!r.isSuccessful) { fail(req, r.exception); return@addOnCompleteListener }
                val uid = u.uid
                // v185: আগে Supabase-এর ব্যাকআপ মোছা (না মুছলে অ্যাকাউন্ট মোছা হবে না — ডেটা পড়ে থাকা চলবে না)
                u.getIdToken(true).addOnCompleteListener { tt ->
                    val tok = tt.result?.token
                    if (!tt.isSuccessful || tok.isNullOrEmpty()) { fail(req, tt.exception); return@addOnCompleteListener }
                    io.execute {
                        val cloudGone = try {
                            !BackendConfig.enabled() || syncCall(tok, JSONObject().put("action", "delete")).optBoolean("ok")
                        } catch (_: Throwable) { false }
                        if (!cloudGone) {
                            fail(req, "net", "ক্লাউডের ডেটা মোছা যায়নি — ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।")
                        } else {
                            try { avatarCall("DELETE", uid, null) } catch (_: Throwable) {}   // v184: Supabase-এর প্রোফাইল ছবিও মোছা
                            db().getReference("users").child(uid).removeValue().addOnCompleteListener {   // প্রোফাইল/প্রিমিয়াম/পুরনো ব্যাকআপ (Firebase)
                                u.delete().addOnCompleteListener { d ->
                                    if (d.isSuccessful) { try { auth.signOut() } catch (_: Throwable) {}; ok(req) } else fail(req, d.exception)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (google) googleToken({ tok -> proceed(GoogleAuthProvider.getCredential(tok, null)) }, { e -> fail(req, e) })
        else {
            if (password.isEmpty()) return fail(req, "need-password", "পাসওয়ার্ড দিন।")
            proceed(EmailAuthProvider.getCredential(u.email ?: "", password))
        }
    }

    // ------------------------------------------------------------------ প্রোফাইল ছবি (Supabase Storage) — v184
    // বাকেট: avatars (পাবলিক), ফাইল: {firebase uid}.jpg, সর্বোচ্চ ১০০KB। বাকেটের নিজস্ব সীমাও ১০০KB (docs/SUPABASE_AVATARS.sql)।
    private val avatarMax = 100 * 1024

    private fun avatarCall(method: String, uid: String, body: ByteArray?): Int {
        val key = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_ANON_KEY
        val url = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_URL.trimEnd('/') + "/storage/v1/object/avatars/" + uid + ".jpg"
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("apikey", key); setRequestProperty("Authorization", "Bearer $key")
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "image/jpeg"); setFixedLengthStreamingMode(body.size) }
        }
        try {
            if (body != null) c.outputStream.use { it.write(body) }
            return c.responseCode
        } finally { c.disconnect() }
    }

    /** ১০০KB-এর বেশি হলে (JS-এর ছোট করা সত্ত্বেও) এখানে আবার ছোট করা — Supabase-এ কখনো ১০০KB-এর বেশি যাবে না */
    private fun fitAvatar(raw: ByteArray): ByteArray {
        if (raw.size <= avatarMax) return raw
        val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: throw IllegalStateException("decode")
        val s0 = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - s0) / 2, (bmp.height - s0) / 2, s0, s0)
        var side = minOf(s0, 512)
        while (side >= 64) {
            val scaled = Bitmap.createScaledBitmap(sq, side, side, true)
            var q = 85
            while (q >= 40) {
                val out = ByteArrayOutputStream(); scaled.compress(Bitmap.CompressFormat.JPEG, q, out)
                if (out.size() <= avatarMax) return out.toByteArray()
                q -= 9
            }
            side = (side * 0.8).toInt()
        }
        throw IllegalStateException("big")
    }

    @JavascriptInterface
    fun uploadAvatar(req: String, dataUrl: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        if (!com.gunjoron.patheyo.stats.BackendConfig.enabled()) return fail(req, "off", "ছবি রাখার সুবিধা চালু নেই।")
        val uid = u.uid
        io.execute {
            try {
                val raw = Base64.decode(dataUrl.substringAfter(',', ""), Base64.DEFAULT)
                val bytes = fitAvatar(raw)
                var code = avatarCall("POST", uid, bytes)
                if (code == 400 || code == 409) code = avatarCall("PUT", uid, bytes)     // আগের ছবি আছে → বদলে দেওয়া
                if (code in 200..299) ok(req, JSONObject().put("size", bytes.size)) else fail(req, "http", "ছবি ক্লাউডে রাখা যায়নি (কোড $code)।")
            } catch (t: Throwable) { fail(req, "net", "ছবি ক্লাউডে রাখা যায়নি — ইন্টারনেট সংযোগ দেখুন।") }
        }
    }

    /** v202: ক্লাউডে (Supabase avatars/{uid}.jpg) রাখা নিজের প্রোফাইল ছবি ফোনে ফেরত আনা — সাইন-আউটের পর আবার সাইন-ইন করলে ছবি যেন গায়েব না হয়।
     *  ফেরত: data = dataURL, ছবি না থাকলে (404) data = "" ; নেট/সার্ভার সমস্যায় ok=false (JS তখন কিছু বদলায় না, পরে আবার চেষ্টা) */
    @JavascriptInterface
    fun downloadAvatar(req: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        if (!com.gunjoron.patheyo.stats.BackendConfig.enabled()) return fail(req, "off", "ছবি রাখার সুবিধা চালু নেই।")
        val uid = u.uid
        io.execute {
            try {
                val key = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_ANON_KEY
                val url = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_URL.trimEnd('/') + "/storage/v1/object/public/avatars/" + uid + ".jpg?t=" + System.currentTimeMillis()
                val c = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 10000; readTimeout = 20000
                    setRequestProperty("apikey", key); setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Cache-Control", "no-cache")
                }
                try {
                    val code = c.responseCode
                    if (code == 404 || code == 400) { ok(req, JSONObject().put("data", "")); return@execute }
                    if (code !in 200..299) { fail(req, "http", "ছবি আনা যায়নি (কোড $code)।"); return@execute }
                    val raw = c.inputStream.use { it.readBytes() }
                    if (raw.isEmpty() || raw.size > 400 * 1024) { ok(req, JSONObject().put("data", "")); return@execute }
                    if (BitmapFactory.decodeByteArray(raw, 0, raw.size) == null) { ok(req, JSONObject().put("data", "")); return@execute }
                    ok(req, JSONObject().put("data", "data:image/jpeg;base64," + Base64.encodeToString(raw, Base64.NO_WRAP)))
                } finally { c.disconnect() }
            } catch (t: Throwable) { fail(req, "net", "ছবি আনা যায়নি — ইন্টারনেট সংযোগ দেখুন।") }
        }
    }

    @JavascriptInterface
    fun deleteAvatar(req: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        if (!com.gunjoron.patheyo.stats.BackendConfig.enabled()) return ok(req)
        val uid = u.uid
        io.execute {
            try {
                val code = avatarCall("DELETE", uid, null)
                if (code in 200..299 || code == 404) ok(req) else fail(req, "http", "ছবি মোছা যায়নি (কোড $code)।")
            } catch (t: Throwable) { fail(req, "net", "ছবি মোছা যায়নি — ইন্টারনেট সংযোগ দেখুন।") }
        }
    }

    // ------------------------------------------------------------------ ক্লাউড সিঙ্ক (Supabase, v185)

    /** Edge Function "cloud-sync"-কে ডাকা। io থ্রেড থেকে ডাকতে হবে। ফেরত: সার্ভারের JSON + "http" (স্ট্যাটাস কোড) */
    private fun syncCall(idToken: String, body: JSONObject): JSONObject {
        val url = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/cloud-sync"
        val key = com.gunjoron.patheyo.stats.BackendConfig.SUPABASE_ANON_KEY
        val bytes = body.toString().toByteArray(Charsets.UTF_8)
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 40000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", key); setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("x-firebase-token", idToken)
            setFixedLengthStreamingMode(bytes.size)
        }
        try {
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val o = try { JSONObject(txt) } catch (_: Throwable) { JSONObject() }
            return o.put("http", code)
        } finally { c.disconnect() }
    }

    /** সাইন-ইন করা ইউজারের Firebase টোকেন নিয়ে (io থ্রেডে) কাজ চালানো */
    private fun withToken(req: String, block: (String) -> Unit) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        if (!com.gunjoron.patheyo.stats.BackendConfig.enabled()) return fail(req, "off", "ক্লাউড ব্যাকআপ চালু নেই।")
        u.getIdToken(false).addOnCompleteListener { t ->
            val tok = t.result?.token
            if (!t.isSuccessful || tok.isNullOrEmpty()) { fail(req, t.exception); return@addOnCompleteListener }
            io.execute {
                try { block(tok) } catch (_: Throwable) { fail(req, "net", "ইন্টারনেট সংযোগ নেই। সংযোগ দিয়ে আবার চেষ্টা করুন।") }
            }
        }
    }

    // ------------------------------------------------------------------ v272: ক্লাউডে কম জায়গা (gzip)
    // ব্যাকআপের লেখা gzip করে Base64 — সাধারণত ৭০–৮৫% ছোট হয়; প্রতিটি সিঙ্কে ইন্টারনেট-খরচও কমে।
    // সারির শুরুতে "gz1:" চিহ্ন থাকে। আনার সময় চিহ্ন থাকলে খুলে আগের মতো সাধারণ লেখা JS-কে দেওয়া হয় — তাই JS-এর
    // যাচাই (app/format/sum) ও রিস্টোরের পথ একই থাকে। আগের (চিহ্ন-ছাড়া) ব্যাকআপও ঠিকঠাক পড়া যায়।
    // Edge Function ও Supabase টেবিলে কিছু বদলাতে হয়নি — সেখানে লেখাটা যেমন আসে তেমনই জমা থাকে।
    private fun packCloud(text: String): String = try {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(text.toByteArray(Charsets.UTF_8)) }
        val packed = GZ_PREFIX + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        if (packed.length < text.length) packed else text
    } catch (_: Throwable) { text }

    /** ফেরত null = চিহ্ন আছে কিন্তু খোলা যায়নি (ভাঙা লেখা) */
    private fun unpackCloud(data: String): String? {
        if (!data.startsWith(GZ_PREFIX)) return data
        return try {
            val raw = Base64.decode(data.substring(GZ_PREFIX.length), Base64.NO_WRAP)
            GZIPInputStream(ByteArrayInputStream(raw)).use { it.readBytes() }.toString(Charsets.UTF_8)
        } catch (_: Throwable) { null }
    }

    @JavascriptInterface
    fun cloudSave(req: String, text: String) {
        if (text.isEmpty()) return fail(req, "empty", "পাঠানোর মতো কোনো ডেটা নেই।")
        withToken(req) { tok ->
            val data = packCloud(text)
            if (data.length > 4_000_000) { fail(req, "big", "ডেটার আকার অনেক বড় — ক্লাউডে সংরক্ষণ করা যায়নি।"); return@withToken }
            val r = syncCall(tok, JSONObject().put("action", "save").put("data", data)
                .put("device", Build.MANUFACTURER + " " + Build.MODEL))
            if (r.optBoolean("ok")) {
                ok(req, JSONObject().put("at", r.optLong("at", System.currentTimeMillis())))
                dropLegacyBackup()
            } else fail(req, "http", "ক্লাউডে রাখা যায়নি (কোড " + r.optInt("http") + ")।")
        }
    }

    /** v200: রিয়েল-টাইম পরীক্ষার হালকা কল — শুধু ক্লাউডের "শেষ বদলের সময়" (ডেটা নয়)। ফাংশনে meta না থাকলে code=nometa (JS তখন ধীরে cloudLoad দিয়ে চালায়) */
    @JavascriptInterface
    fun cloudMeta(req: String) {
        withToken(req) { tok ->
            val r = syncCall(tok, JSONObject().put("action", "meta"))
            when {
                r.optBoolean("ok") -> ok(req, JSONObject().put("empty", r.optBoolean("empty", false)).put("at", r.optLong("at")).put("device", r.optString("device")))
                r.optInt("http") == 400 -> fail(req, "nometa", "meta নেই")
                else -> fail(req, "http", "ক্লাউড দেখা যায়নি (কোড " + r.optInt("http") + ")।")
            }
        }
    }

    @JavascriptInterface
    fun cloudLoad(req: String) {
        withToken(req) { tok ->
            val r = syncCall(tok, JSONObject().put("action", "load"))
            if (!r.optBoolean("ok")) {
                fail(req, "http", "ক্লাউড থেকে আনা যায়নি (কোড " + r.optInt("http") + ")।")
            } else if (!r.optBoolean("empty", true) && r.optString("data").isNotEmpty()) {
                val plain = unpackCloud(r.optString("data"))
                if (plain == null) { fail(req, "broken", "ক্লাউডের ডেটা পড়া যায়নি।"); return@withToken }
                ok(req, JSONObject().put("empty", false).put("at", r.optLong("at"))
                    .put("device", r.optString("device")).put("data", plain))
            } else {
                loadLegacyBackup(req)   // Supabase-এ কিছু নেই → v184-পর্যন্ত Firebase-এ রাখা পুরনো ব্যাকআপ আছে কি দেখা
            }
        }
    }

    /** v184-পর্যন্ত ব্যাকআপ ছিল Firebase Realtime Database-এ users/{uid}/backup — নতুন ভার্সনে এলে যেন কিছু না হারায় */
    private fun loadLegacyBackup(req: String) {
        val u = auth.currentUser ?: return fail(req, "signed-out", "আগে সাইন-ইন করুন।")
        try {
            db().getReference("users").child(u.uid).child("backup").get().addOnCompleteListener { t ->
                if (!t.isSuccessful) { ok(req, JSONObject().put("empty", true)); return@addOnCompleteListener }
                val s = t.result
                if (s == null || !s.exists()) { ok(req, JSONObject().put("empty", true)); return@addOnCompleteListener }
                val at = (s.child("at").value as? Number)?.toLong() ?: 0L
                ok(req, JSONObject().put("empty", false).put("at", at)
                    .put("device", s.child("device").value?.toString() ?: "").put("data", s.child("data").value?.toString() ?: ""))
            }
        } catch (_: Throwable) { ok(req, JSONObject().put("empty", true)) }
    }

    /** Supabase-এ সেভ হয়ে গেলে Firebase-এর পুরনো ব্যাকআপ (যদি থাকে) মুছে ফেলা — ডেটা একটাই জায়গায় থাকবে */
    private fun dropLegacyBackup() {
        try { auth.currentUser?.let { db().getReference("users").child(it.uid).child("backup").removeValue() } } catch (_: Throwable) {}
    }

    companion object {
        private const val GZ_PREFIX = "gz1:"
        const val RTDB_URL = "https://hijri-tarikh-default-rtdb.firebaseio.com"
    }
}
