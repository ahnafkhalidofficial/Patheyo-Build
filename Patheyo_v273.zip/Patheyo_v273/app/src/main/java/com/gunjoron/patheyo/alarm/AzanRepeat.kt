package com.gunjoron.patheyo.alarm

// v45: আজানের স্নুজ / অটো-রিপিট ব্যবস্থা।
//
// নিয়ম:
//  • একটি ওয়াক্তে সর্বোচ্চ ৩ বার আজান বাজে (AzanContent.MAX_RINGS)।
//  • আজান শুরু হওয়ার মুহূর্তেই পরের ("আজান ২/৩", "৩/৩") বার ১০ মিনিট পরের জন্য AlarmManager-এ বসিয়ে রাখা হয় —
//    ইউজার কোনো বাটন না চাপলে (বা অ্যাপ/প্রসেস মরে গেলেও) সেটিই বাজবে।
//  • "আজান বন্ধ করুন" → বসানো রিপিট বাতিল, এই ওয়াক্তে আর আজান নয়।
//  • "স্নুজ" → বসানো রিপিট বাতিল করে বাটন চাপার সময় থেকে ঠিক ১০ মিনিট পরের জন্য নতুন করে বসানো।
//  • ৩য় আজানের পর আর কিছু বসে না — পরের ওয়াক্তে আবার নতুন করে শুরু।
// রিপিটের PendingIntent-এর request-code দৈনিক অ্যালার্মের (9001–9005) থেকে আলাদা (9011–9015), তাই একটি আরেকটাকে মোছে না।

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object AzanRepeat {

    const val EXTRA_RING = "ring"
    private const val INTERVAL_MS = AzanContent.SNOOZE_MINUTES * 60_000L

    private val CODES = mapOf(
        "Fajr" to 9011, "Dhuhr" to 9012, "Asr" to 9013, "Maghrib" to 9014, "Isha" to 9015
    )

    private fun intentFor(ctx: Context, waqtKey: String, ring: Int) =
        Intent(ctx, AzanAlarmReceiver::class.java).apply {
            putExtra("waqt", waqtKey)
            putExtra(EXTRA_RING, ring)
        }

    /**
     * [currentRing]-এর পরের আজান [delayMs] পরে বসায়। [currentRing] ৩ বা তার বেশি হলে কিছুই বসায় না (আর বাকি থাকা রিপিট মুছে দেয়)।
     * @return সত্যিই কিছু বসানো হলে true
     */
    fun scheduleNext(context: Context, rawWaqt: String?, currentRing: Int, delayMs: Long = INTERVAL_MS): Boolean {
        val ctx = context.applicationContext
        val key = AzanContent.key(rawWaqt) ?: return false
        if (currentRing >= AzanContent.MAX_RINGS) { cancel(ctx, key); return false }
        return try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
            val pi = PendingIntent.getBroadcast(
                ctx, CODES[key] ?: return false, intentFor(ctx, key, currentRing + 1),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            AlarmScheduler.setBestAlarm(ctx, am, System.currentTimeMillis() + delayMs, pi)
            true
        } catch (_: Throwable) { false }
    }

    /** একটি ওয়াক্তের বসানো রিপিট বাতিল */
    fun cancel(context: Context, rawWaqt: String?) {
        val key = AzanContent.key(rawWaqt) ?: return
        cancelKey(context.applicationContext, key)
    }

    /** সব ওয়াক্তের বসানো রিপিট বাতিল — "আজান বন্ধ করুন" চাপলে (কোন ওয়াক্ত তা না জানা গেলেও কাজ করে) */
    fun cancelAll(context: Context) {
        val ctx = context.applicationContext
        CODES.keys.forEach { cancelKey(ctx, it) }
    }

    private fun cancelKey(ctx: Context, key: String) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val pi = PendingIntent.getBroadcast(
                ctx, CODES[key] ?: return, intentFor(ctx, key, 0),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            ) ?: return
            am.cancel(pi)
            pi.cancel()
        } catch (_: Throwable) { }
    }
}
