package com.gunjoron.patheyo.reminder

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.gunjoron.patheyo.MainActivity
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.alarm.AlarmScheduler
import org.json.JSONObject
import java.util.Calendar

/**
 * ধাপ ৮: নফল নামাজের অ্যালার্ম ও খতমের দৈনিক রিমাইন্ডার — অ্যাপ বন্ধ থাকলেও।
 *
 *  • নফল: নামাজ পেজ (features/namaz/js/24-js-prayer-nafal-alarm.js) আজকের হিসাব করা সময় পাঠায়
 *    AndroidWidgetBridge.saveNafalAlarms({"ishrak":{"active":true,"time":"06:25","sound":"system"}, …})
 *    অ্যাপ না খুললে পরের দিনগুলোতে শেষ জানা সময়ই ব্যবহার হয় (দিনে সাধারণত ১–২ মিনিট বদলায়); অ্যাপ খুললেই আবার ঠিক হয়।
 *  • খতম: কুরআন পেজ (features/quran/js/51-khatm.js) পরিকল্পনা পাঠায়
 *    AndroidWidgetBridge.saveKhatmReminder({"on":true,"time":"21:00","days":30,"start":"2026-11-01","best":40,"total":610,"finished":false})
 *    বাজার সময় আজকের লক্ষ্য হিসাব হয় (ওয়েবের calc()-এর একই সূত্র); আজকের অংশ পড়া হয়ে গেলে নোটিফিকেশন আসে না।
 *
 * প্রতিটি অ্যালার্ম এক-বারের; বাজার পর রিসিভার পরের দিনেরটা বসায়। রিবুট/সময় বদলে BootCompletedReceiver আবার বসায়।
 */
object ReminderAlarms {
    private const val PREFS = "patheyo_reminders"
    private const val KEY_NAFAL = "nafal_json"
    private const val KEY_KHATM = "khatm_json"
    const val CHANNEL_ID = "patheyo_reminders_v1"
    const val EXTRA_KIND = "kind"
    private const val KHATM_REQ = 9210

    private val NAFAL = linkedMapOf(
        "ishrak" to Triple(9201, "ইশরাকের সময় হয়েছে", "সূর্য উঠে গেছে — এখন ইশরাকের নামাজ পড়ার উত্তম সময়।"),
        "chasht" to Triple(9202, "চাশতের সময় হয়েছে", "দুপুরের আগে চাশতের (দুহা) নামাজের সময় চলছে।"),
        "awabin" to Triple(9203, "আওয়াবিনের সময়", "মাগরিবের পর আওয়াবিনের নামাজ পড়ার সময়।"),
        "tahajjud" to Triple(9204, "তাহাজ্জুদের সময়", "রাতের শেষ ভাগ — তাহাজ্জুদের বরকতময় সময়।")
    )

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveNafal(ctx: Context, json: String) {
        prefs(ctx).edit().putString(KEY_NAFAL, json).apply()
        scheduleNafal(ctx)
    }

    fun saveKhatm(ctx: Context, json: String) {
        prefs(ctx).edit().putString(KEY_KHATM, json).apply()
        scheduleKhatm(ctx)
    }

    fun scheduleAll(ctx: Context) {
        try { scheduleNafal(ctx) } catch (_: Throwable) {}
        try { scheduleKhatm(ctx) } catch (_: Throwable) {}
        try { SmartReminders.schedule(ctx) } catch (_: Throwable) {}      // ধাপ ১১: ঘুমের আগের রিমাইন্ডার
        try { com.gunjoron.patheyo.calnote.CalNotes.rescheduleAll(ctx) } catch (_: Throwable) {}   // v244: ক্যালেন্ডার নোটের রিমাইন্ডার
    }

    private fun pi(ctx: Context, req: Int, kind: String): PendingIntent =
        PendingIntent.getBroadcast(ctx, req, Intent(ctx, ReminderReceiver::class.java).putExtra(EXTRA_KIND, kind),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun scheduleNafal(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val cfg = try { JSONObject(prefs(app).getString(KEY_NAFAL, null) ?: "{}") } catch (_: Throwable) { JSONObject() }
        for ((id, meta) in NAFAL) {
            try {
                val p = pi(app, meta.first, "nafal:$id")
                val c = cfg.optJSONObject(id)
                val time = c?.optString("time", "") ?: ""
                if (c?.optBoolean("active", false) != true || time.isEmpty()) { am.cancel(p); continue }
                val at = AlarmScheduler.nextOccurrence(time) ?: continue
                AlarmScheduler.setBestAlarm(app, am, at, p)          // নফল = সত্যিকারের অ্যালার্ম (আজানের মতো একই নির্ভরযোগ্য পথ)
            } catch (_: Throwable) {}
        }
    }

    fun scheduleKhatm(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val p = pi(app, KHATM_REQ, "khatm")
        val o = try { JSONObject(prefs(app).getString(KEY_KHATM, null) ?: "{}") } catch (_: Throwable) { JSONObject() }
        if (!o.optBoolean("on", false) || o.optBoolean("finished", false)) { am.cancel(p); return }
        val at = AlarmScheduler.nextOccurrence(o.optString("time", "21:00")) ?: return
        // রিমাইন্ডার — এক্সাক্ট না হলেও চলে, তাই অ্যালার্ম-ঘড়ির আইকন দেখায় না
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.set(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: Throwable) {}
    }

    // ---------------------------------------------------------------- নোটিফিকেশন

    private fun bn(n: Int) = n.toString().map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "নফল নামাজ ও খতমের রিমাইন্ডার", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "ইশরাক, চাশত, আওয়াবিন, তাহাজ্জুদের অ্যালার্ম, কুরআন খতম ও ঘুমের আগের আমলের দৈনিক মনে করিয়ে দেওয়া"
        })
    }

    /** go: ট্যাপে অ্যাপের নির্দিষ্ট জায়গা (যেমন "dua:sleep") — window.__ptGo; nav: ফুটারের ট্যাব (০–৪), না লাগলে -1 */
    fun post(ctx: Context, id: Int, title: String, body: String, nav: Int, go: String? = null) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(ctx, id, Intent(ctx, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            if (nav >= 0) putExtra("nav", nav)
            if (!go.isNullOrEmpty()) putExtra("go", go)
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ContextCompat.getColor(ctx, R.color.brand_notif_color))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (_: SecurityException) {}
    }

    fun fire(ctx: Context, kind: String) {
        val app = ctx.applicationContext
        if (kind.startsWith("smart:")) { SmartReminders.fire(app, kind); return }
        if (kind.startsWith("nafal:")) {
            val id = kind.removePrefix("nafal:")
            val meta = NAFAL[id] ?: return
            try { post(app, meta.first, meta.second, meta.third, 1) } finally { scheduleNafal(app) }
            return
        }
        if (kind == "khatm") {
            try {
                val o = JSONObject(prefs(app).getString(KEY_KHATM, null) ?: return)
                val total = o.optInt("total", 610).coerceAtLeast(1)
                val days = o.optInt("days", 30).coerceAtLeast(1)
                val best = o.optInt("best", 0)
                val sp = o.optString("start", "").split("-")
                if (sp.size == 3 && best < total) {
                    val start = Calendar.getInstance().apply { set(sp[0].toInt(), sp[1].toInt() - 1, sp[2].toInt(), 0, 0, 0); set(Calendar.MILLISECOND, 0) }
                    val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                    val day = (((today.timeInMillis - start.timeInMillis) / 86_400_000L).toInt()).coerceAtLeast(0)
                    val perDay = total.toDouble() / days
                    val target = minOf(total, Math.ceil(perDay * (day + 1)).toInt())
                    val left = target - best
                    if (left > 0) {
                        post(app, KHATM_REQ, "আজকের খতমের অংশ বাকি",
                            "আরও ${bn(left)} পৃষ্ঠা — পৃষ্ঠা ${bn(best + 1)} থেকে ${bn(target)} পর্যন্ত। অল্প অল্প করে, নিয়মিত।", 2)
                    }
                }
            } catch (_: Throwable) {
            } finally { scheduleKhatm(app) }
        }
    }
}

/** নফল/খতম/স্মার্ট রিমাইন্ডারের অ্যালার্ম বাজলে এখানে আসে */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra(ReminderAlarms.EXTRA_KIND) ?: return
        try { ReminderAlarms.fire(context, kind) } catch (_: Throwable) {}
    }
}
