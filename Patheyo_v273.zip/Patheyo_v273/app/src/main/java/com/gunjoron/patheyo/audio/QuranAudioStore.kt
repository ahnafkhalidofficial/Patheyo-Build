package com.gunjoron.patheyo.audio

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.Executors

/**
 * সূরার তিলাওয়াত অফলাইনে রাখা (শুধু সূরা অডিও — অন্য কিছু নয়)।
 *
 * ফাইল: noBackupFilesDir/quran_audio/<তিলাওয়াতকারী-ফোল্ডার>/<SSSAAA>.mp3 (everyayah.com-এর ফাইল-নামই)।
 *   noBackupFilesDir-এ রাখা হয় যাতে গুগল অটো-ব্যাকআপের ২৫ MB সীমায় অডিও ঢুকে ব্যাকআপ নষ্ট না করে।
 * একটি সূরা সম্পূর্ণ নামলে sura_<SSS>.done নামে ছোট মার্কার ফাইল লেখা হয় (ফাইলের তালিকা + মোট বাইট)।
 *   মার্কার + সবকটা ফাইল থাকলেই সূরাটা "অফলাইনে আছে"।
 * ডাউনলোড একটি একটি করে (সারিতে); নেট কেটে গেলে ফাইল-ভিত্তিক রিজিউম — আবার চাপলে যেগুলো নামা হয়ে গেছে সেগুলো বাদ দিয়ে চলে।
 * প্লেয়ার ([QuranAudioEngine]) প্রতিটা আয়াত চালানোর সময় আগে এখানকার লোকাল ফাইল খোঁজে, না থাকলে ইন্টারনেট থেকে।
 *
 * JS-এ প্রগ্রেস: window.__quranAudioEvent({k:'dl', ...}) ([QuranAudioBridge] দিয়ে)।
 */
object QuranAudioStore {

    private const val BASE = "https://everyayah.com/data/"
    private val NAME_RE = Regex("^[0-9]{6}$")
    private val FOLDER_RE = Regex("^[A-Za-z0-9_\\-]{3,64}$")

    private class Job(val folder: String, val sura: Int, val files: List<String>)

    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "patheyo-quran-dl").apply { isDaemon = true } }
    private val lock = Any()
    private val queue = ArrayList<Job>()

    @Volatile var sink: ((String) -> Unit)? = null
    @Volatile private var appCtx: Context? = null
    @Volatile private var curFolder = ""
    @Volatile private var curSura = 0
    @Volatile private var done = 0
    @Volatile private var total = 0
    @Volatile private var bytes = 0L
    @Volatile private var phase = "idle"       // idle | downloading | error
    @Volatile private var error: String? = null
    @Volatile private var cancelCur = false
    @Volatile private var conn: HttpURLConnection? = null
    @Volatile private var lastPushAt = 0L

    // ------------------------------------------------------------------ ফাইল-পথ

    private fun root(ctx: Context): File = File(ctx.applicationContext.noBackupFilesDir, "quran_audio").apply { mkdirs() }
    private fun dirOf(ctx: Context, folder: String): File = File(root(ctx), folder).apply { mkdirs() }
    private fun marker(ctx: Context, folder: String, sura: Int): File = File(dirOf(ctx, folder), "sura_" + sura.toString().padStart(3, '0') + ".done")

    /** একটি আয়াতের লোকাল ফাইল (থাকলে); না থাকলে null */
    fun localFile(ctx: Context, folder: String, file: String): File? {
        if (!FOLDER_RE.matches(folder) || !NAME_RE.matches(file)) return null
        val f = File(File(root(ctx), folder), "$file.mp3")
        return if (f.isFile && f.length() > 1024) f else null
    }

    private fun readMarker(f: File): JSONObject? = try { JSONObject(f.readText()) } catch (_: Throwable) { null }

    /** সূরাটা পুরোপুরি অফলাইনে আছে কি */
    fun isComplete(ctx: Context, folder: String, sura: Int): Boolean {
        if (!FOLDER_RE.matches(folder)) return false
        val m = readMarker(marker(ctx, folder, sura)) ?: return false
        val arr = m.optJSONArray("files") ?: return false
        val d = dirOf(ctx, folder)
        for (i in 0 until arr.length()) { val f = File(d, arr.optString(i) + ".mp3"); if (!f.isFile || f.length() <= 1024) return false }
        return arr.length() > 0
    }

    // ------------------------------------------------------------------ JS-এ দেখানোর তথ্য

    /** সম্পূর্ণ নামানো সূরার তালিকা: [{r:ফোল্ডার, s:সূরা, b:বাইট}] + মোট বাইট */
    fun listJson(ctx: Context): String {
        val out = JSONArray()
        var sum = 0L
        try {
            root(ctx).listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach { dir ->
                dir.listFiles()?.filter { it.name.startsWith("sura_") && it.name.endsWith(".done") }?.sortedBy { it.name }?.forEach { mk ->
                    val s = mk.name.removePrefix("sura_").removeSuffix(".done").toIntOrNull() ?: return@forEach
                    if (!isComplete(ctx, dir.name, s)) return@forEach
                    val b = readMarker(mk)?.optLong("bytes", 0L) ?: 0L
                    sum += b
                    out.put(JSONObject().put("r", dir.name).put("s", s).put("b", b))
                }
            }
        } catch (_: Throwable) {}
        return JSONObject().put("list", out).put("total", sum).toString()
    }

    fun statusJson(): String {
        val q = JSONArray()
        synchronized(lock) { queue.forEach { q.put(JSONArray().put(it.folder).put(it.sura)) } }
        val cur = if (phase == "idle" && curSura == 0) JSONObject.NULL else JSONObject()
            .put("r", curFolder).put("s", curSura).put("done", done).put("total", total).put("bytes", bytes)
            .put("phase", phase).put("error", error ?: JSONObject.NULL)
        return JSONObject().put("k", "dl").put("cur", cur).put("q", q).toString()
    }

    private fun push(force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPushAt < 250L) return
        lastPushAt = now
        val s = sink ?: return
        s("window.__quranAudioEvent&&window.__quranAudioEvent(" + statusJson() + ");")
    }

    // ------------------------------------------------------------------ ডাউনলোড

    fun start(ctx: Context, folder: String, sura: Int, filesJson: String) {
        appCtx = ctx.applicationContext
        if (!FOLDER_RE.matches(folder) || sura !in 1..114) return
        val files = ArrayList<String>()
        try {
            val a = JSONArray(filesJson)
            for (i in 0 until a.length()) { val n = a.optString(i); if (NAME_RE.matches(n) && n !in files) files.add(n) }
        } catch (_: Throwable) { return }
        if (files.isEmpty()) return
        synchronized(lock) {
            if ((curFolder == folder && curSura == sura && phase == "downloading") || queue.any { it.folder == folder && it.sura == sura }) return
            queue.add(Job(folder, sura, files))
        }
        push(true)
        pump()
    }

    private fun pump() {
        exec.execute {
            while (true) {
                val job: Job?
                synchronized(lock) {
                    if (queue.isEmpty()) {
                        phase = "idle"; curSura = 0; curFolder = ""
                        job = null
                    } else job = queue.removeAt(0)
                }
                if (job == null) { push(true); return@execute }
                runJob(job)
            }
        }
    }

    private fun runJob(job: Job) {
        val ctx = appCtx ?: return
        curFolder = job.folder; curSura = job.sura; total = job.files.size; done = 0; bytes = 0L
        cancelCur = false; error = null; phase = "downloading"
        push(true)
        val dir = dirOf(ctx, job.folder)
        try {
            for (name in job.files) {
                if (cancelCur) throw CancelledException()
                val dest = File(dir, "$name.mp3")
                if (dest.isFile && dest.length() > 1024) { bytes += dest.length(); done++; push(false); continue }
                var attempt = 0
                while (true) {
                    try {
                        bytes += fetch("$BASE${job.folder}/$name.mp3", dest)
                        break
                    } catch (e: CancelledException) { throw e
                    } catch (e: Throwable) {
                        if (cancelCur) throw CancelledException()
                        attempt++
                        val code = mapError(ctx, e)
                        if (attempt >= 3 || code == "no-space") throw StoreException(code)
                        try { Thread.sleep(700L * attempt) } catch (_: InterruptedException) {}
                    }
                }
                done++
                push(false)
            }
            // সবকটা নামা শেষ → মার্কার
            val arr = JSONArray(); job.files.forEach { arr.put(it) }
            marker(ctx, job.folder, job.sura).writeText(JSONObject().put("files", arr).put("bytes", bytes).toString())
            phase = "idle"; error = null
            push(true)
        } catch (_: CancelledException) {
            phase = "idle"; error = null
            push(true)
        } catch (e: StoreException) {
            phase = "error"; error = e.code
            push(true)
            // ত্রুটির পরেও সারিতে আর কিছু থাকলে চালিয়ে যাওয়া হবে (ইউজার আবার চাপলে এই সূরার বাকি অংশ নামবে)
            phase = "idle"
        } catch (e: Throwable) {
            phase = "error"; error = "network"
            push(true)
            phase = "idle"
        }
    }

    private class CancelledException : Exception()
    private class StoreException(val code: String) : Exception(code)

    /** একটি ফাইল নামায় (.part → rename); নামা বাইট ফেরত দেয় */
    private fun fetch(url: String, dest: File): Long {
        val part = File(dest.parentFile, dest.name + ".part")
        val c = URL(url).openConnection() as HttpURLConnection
        conn = c
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.instanceFollowRedirects = true
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", "Patheyo-Android")
            val code = c.responseCode
            if (code != 200) throw IOException("http $code")
            val expected = c.contentLengthLong
            var n = 0L
            c.inputStream.use { ins ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        if (cancelCur) throw CancelledException()
                        val r = ins.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        n += r
                    }
                }
            }
            if (n <= 1024 || (expected > 0 && n != expected)) throw IOException("bad size")
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw IOException("rename")
            return n
        } finally {
            try { c.disconnect() } catch (_: Throwable) {}
            conn = null
            if (part.exists()) try { part.delete() } catch (_: Throwable) {}
        }
    }

    private fun mapError(ctx: Context, e: Throwable): String = when (e) {
        is UnknownHostException -> if (isOnline(ctx)) "network" else "offline"
        is SocketTimeoutException -> "timeout"
        is IOException -> {
            val m = e.message ?: ""
            when {
                m.contains("ENOSPC", true) || m.contains("No space", true) -> "no-space"
                !isOnline(ctx) -> "offline"
                else -> "network"
            }
        }
        else -> "network"
    }

    private fun isOnline(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Throwable) { true }

    /** চলমান ডাউনলোড বাতিল + সারি খালি (নামা হয়ে যাওয়া ফাইল থাকে, আবার চাপলে সেখান থেকে চলবে) */
    fun cancel() {
        synchronized(lock) { queue.clear() }
        if (phase == "downloading") { cancelCur = true; try { conn?.disconnect() } catch (_: Throwable) {} }
        else push(true)
    }

    /** শুধু একটি সূরা সারি/চলমান থেকে বাদ */
    fun cancelSura(folder: String, sura: Int) {
        synchronized(lock) { queue.removeAll { it.folder == folder && it.sura == sura } }
        if (phase == "downloading" && curFolder == folder && curSura == sura) {
            cancelCur = true; try { conn?.disconnect() } catch (_: Throwable) {}
        } else push(true)
    }

    // ------------------------------------------------------------------ মোছা

    /** একটি সূরার অফলাইন ফাইল মোছে (অন্য সূরার কাজে লাগা ফাইল — যেমন বিসমিল্লাহ — রেখে দেয়) */
    fun delete(ctx: Context, folder: String, sura: Int) {
        if (!FOLDER_RE.matches(folder) || sura !in 1..114) return
        cancelSura(folder, sura)
        try {
            val dir = dirOf(ctx, folder)
            val mk = marker(ctx, folder, sura)
            val mine = HashSet<String>()
            readMarker(mk)?.optJSONArray("files")?.let { a -> for (i in 0 until a.length()) mine.add(a.optString(i)) }
            mk.delete()
            val others = HashSet<String>()
            dir.listFiles()?.filter { it.name.startsWith("sura_") && it.name.endsWith(".done") }?.forEach { o ->
                readMarker(o)?.optJSONArray("files")?.let { a -> for (i in 0 until a.length()) others.add(a.optString(i)) }
            }
            // এই সূরা নামার মাঝপথে থাকলে (মার্কার নেই) তার ফাইলও সাফ করতে হবে — নামের প্রথম ৩ অক্ষর = সূরা নম্বর
            val prefix = sura.toString().padStart(3, '0')
            dir.listFiles()?.forEach { f ->
                if (!f.name.endsWith(".mp3") && !f.name.endsWith(".part")) return@forEach
                val base = f.name.removeSuffix(".mp3").removeSuffix(".part")
                if ((base in mine || base.startsWith(prefix)) && base !in others) try { f.delete() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
        push(true)
    }

    fun deleteAll(ctx: Context) {
        cancel()
        try { root(ctx).deleteRecursively() } catch (_: Throwable) {}
        push(true)
    }
}
