package com.gunjoron.patheyo.widgethub.widget.designs

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.widget.WidgetRenderer.cardW
import com.gunjoron.patheyo.widgethub.widget.assets.Fonts
import com.gunjoron.patheyo.widgethub.widget.render.*
import com.gunjoron.patheyo.widgethub.widget.theme.Look
import com.gunjoron.patheyo.widgethub.widget.theme.Palettes
import java.util.Calendar

/** ডিজাইন ৩ (ত্রি-ক্যালেন্ডার): বড় ঘড়ি + ইংরেজি | হিজরি | বাংলা — তিন কলামের তারিখ। */
internal object TripleCalendarDesign {
    const val CH3_X = 548f

    private const val CLOCK_X = 85f; private const val CLOCK_W = 621f; private const val CLOCK_BASE = 200f

    private const val SIDE_CX = 838f; private const val AMPM_BASE = 80f; private const val SEC_BASE = 197f

    // ------------------------------------------------------------------------------------------
    fun draw(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean,
                       nowMs: Long, ov: Overlay) {
        val pal = Palettes.of3(look.variant)
        val cw = cardW(3)
        val rule = (pal.month and 0xFFFFFF) or 0xBF000000.toInt()   // লেখার রঙ, সামান্য ফিকে
        val ruleW = 1.8f

        // ১) বড় ঘড়ি (বাঁয়ে), AM/PM + সেকেন্ড (ডানে, একটার ওপর আরেকটা)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val clockSize = CLOCK_W / measure(p, "00:00", Fonts.clockBold, 100f) * 100f   // সবচেয়ে চওড়া "00:00" ধরে মাপ
        // ঘণ্টা | কোলন | মিনিট আলাদা আঁকা — কোলন ঠিক অঙ্কের উচ্চতার মাঝখানে (ফন্টে সেটি নিচু বসে)
        p.typeface = Fonts.clockBold; p.textSize = clockSize
        val rb = Rect(); p.getTextBounds("0", 0, 1, rb)
        val digitMid = (rb.top + rb.bottom) / 2f
        val cb = Rect(); p.getTextBounds(":", 0, 1, cb)
        val colonMid = (cb.top + cb.bottom) / 2f
        val colonDy = digitMid - colonMid
        val hhS = hm.substring(0, 2); val mmS = hm.substring(3)
        val hhW = measure(p, hhS, Fonts.clockBold, clockSize)
        val colonW = measure(p, ":", Fonts.clockBold, clockSize)
        text(c, p, hhS, CLOCK_X, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, ":", CLOCK_X + hhW, CLOCK_BASE + colonDy, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, mmS, CLOCK_X + hhW + colonW, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, if (snap.isPm) "PM" else "AM", SIDE_CX, AMPM_BASE, 80f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), SIDE_CX, SEC_BASE, 130f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        else ov.s3 = TextSpec(0f, 0f, 0f, pal.clock)

        // ২) তিন কলামের তারিখ: ইংরেজি | হিজরি | বাংলা — সমান তিন ভাগ
        class Col(val day: String, val month: String, val year: String)
        val cols = arrayOf(
            Col(snap.gregDay, snap.gregMonth, snap.gregYear),
            Col(snap.hijriDay, snap.hijriMonth, snap.hijriYear),
            Col(snap.banglaDay, snap.banglaMonth, snap.banglaYear)
        )
        val colW = cw / 3f
        p.style = Paint.Style.FILL; p.color = rule
        for (i in 1..2) c.drawRect(colW * i - ruleW / 2f, 248f, colW * i + ruleW / 2f, 399f, p)
        for ((i, col) in cols.withIndex()) {
            val cx = colW * (i + 0.5f)
            text(c, p, col.day, cx, 312f, 100f, pal.day, Fonts.bold, Paint.Align.CENTER)
            val maxW = colW - 36f
            var ms = 52f
            val mw = measure(p, col.month, Fonts.regular, ms)
            if (mw > maxW) ms *= maxW / mw
            text(c, p, col.month, cx, 360f, ms, pal.month, Fonts.regular, Paint.Align.CENTER)
            text(c, p, col.year, cx, 392f, 44f, pal.month, Fonts.regular, Paint.Align.CENTER)
        }

        // ৩) নিচের লাইন: ── ইশা [চলছে] সময় বাকি: 01:54:56 ──
        //    অঙ্ক স্থির জায়গায় (লাইভ Chronometer), বাকি সব তার বাঁয়ে ডান-সারিবদ্ধ; দুই পাশে রেখা।
        //    নিষিদ্ধ সময়ে নাম = "নিষিদ্ধ সময়" (লাল-কমলা, বোল্ড), চলছে-ব্যাজ নেই; সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত নাম ও টাইমার = "–"
        val warn = if (lum(pal.month) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val label = if (snap.running || snap.forbid != 0) "সময় বাকি:" else "শুরু হতে বাকি:"
        val nameTxt = when (snap.forbid) { 1 -> "নিষিদ্ধ সময়"; 2 -> "–"; else -> snap.currentName }
        val nameTf = if (snap.forbid == 1) Fonts.bold else Fonts.regular
        val nameCol = when (snap.forbid) { 1 -> warn; 2 -> pal.subLabel; else -> pal.prayer }
        val lw = measure(p, label, Fonts.regular, 27f)
        val nameW = measure(p, nameTxt, nameTf, 36f)
        val badgeW = 70.25f
        var x = CH3_X - 8f - lw
        text(c, p, label, x, 436f, 27f, pal.subLabel, Fonts.regular)
        if (snap.running && snap.forbid == 0) {
            x -= 8f + badgeW
            p.style = Paint.Style.FILL; p.color = 0xFFFCB010.toInt()
            c.drawRoundRect(x, 412f, x + badgeW, 440.05f, 14.02f, 14.02f, p)
            text(c, p, "চলছে", x + 10.34f, 435f, 26.95f, pal.badgeText, Fonts.regular)
            p.style = Paint.Style.FILL; p.color = 0xFFFF0000.toInt()
            c.drawCircle(x + 60.98f, 426.4f, 3.15f, p)
        }
        x -= 6f + nameW
        text(c, p, nameTxt, x, 437f, 36f, nameCol, nameTf)
        if (snap.forbid == 2) {
            text(c, p, "–", CH3_X, 436f, 34f, pal.subTime, Fonts.bold)   // টাইমারের জায়গায় "–"
        } else {
            val endMs = if (snap.forbid == 1) snap.forbidEndMs else snap.periodEndMs
            if (live) text(c, p, formatHms(endMs - nowMs), CH3_X, 436f, 34f, pal.subTime, Fonts.bebas)
            else ov.chrono = TextSpec(0f, 0f, 0f, pal.subTime)
        }
        // রেখা
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(24f, 426f - ruleW / 2f, x - 10f, 426f + ruleW / 2f, p)
        c.drawRect(CH3_X + 108f + 10f, 426f - ruleW / 2f, cw - 24f, 426f + ruleW / 2f, p)
    }
}
