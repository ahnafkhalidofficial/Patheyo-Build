package com.gunjoron.patheyo.calnote

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.widgethub.data.calendar.Bn

/**
 * v244: নোটের অ্যালার্ম — ফোনের ডিফল্ট রিংটোন অ্যালার্মের মতো বারবার বাজে (সর্বোচ্চ ১ মিনিট), সাথে কম্পন।
 * নোটিফিকেশনে "বন্ধ করুন" / "৫ মিনিট পরে"; ফোন লক থাকলে ফুল-স্ক্রিন অ্যালার্ম-স্ক্রিন ([CalNoteAlarmActivity])।
 * কেউ বন্ধ না করলে ১ মিনিট পরে নিজে থামে, আর নোটটা সাধারণ নোটিফিকেশন হয়ে ট্রেতে থেকে যায়।
 */
class CalNoteAlarmService : Service() {

    companion object {
        const val NOTIF_ID = 7790
        const val ACTION_STOP = "com.gunjoron.patheyo.CALNOTE_STOP"
        const val ACTION_SNOOZE = "com.gunjoron.patheyo.CALNOTE_SNOOZE"
        private const val MAX_RING_MS = 60_000L

        @Volatile var isRunning: Boolean = false
            private set
        @Volatile var currentId: Int = -1
            private set
        @Volatile private var instance: CalNoteAlarmService? = null

        /** বাটন/স্ক্রিন থেকে: সাউন্ড বন্ধ; [snooze] হলে ৫ মিনিট পরের জন্য আবার বসে */
        fun dismiss(ctx: Context, id: Int, snooze: Boolean) {
            val app = ctx.applicationContext
            val s = instance
            val realId = if (id >= 0) id else currentId
            if (s != null) {
                Handler(Looper.getMainLooper()).post { s.finishAlarm(snooze) }
            } else {
                if (snooze && realId >= 0) CalNotes.snooze(app, realId)
                try { NotificationManagerCompat.from(app).cancel(NOTIF_ID) } catch (_: Throwable) {}
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val timeout = Runnable { timeoutStop() }

    override fun onCreate() { super.onCreate(); instance = this }
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra(CalNotes.EXTRA_ID, -1) ?: -1
        val note = if (id >= 0) CalNotes.get(this, id) else null
        if (note == null) {
            // startForegroundService() দিয়ে চালু হয়েছে — তাই ফোরগ্রাউন্ডে উঠে তবেই থামতে হয়, নইলে সিস্টেম ক্র্যাশ ধরে
            CalNotes.ensureChannels(this)
            try { enterForeground(buildNotification(-1, null)) } catch (_: Throwable) {}
            cleanup(); stopSelf(); return START_NOT_STICKY
        }

        // আগের একটি অ্যালার্ম বাজার মধ্যেই নতুনটা এলে আগেরটা সাধারণ নোটিফিকেশনে রেখে দেওয়া হয়
        if (isRunning && currentId >= 0 && currentId != id) {
            CalNotes.get(this, currentId)?.let { CalNotes.postNote(this, it, missed = true) }
        }
        currentId = id
        isRunning = true
        CalNotes.ensureChannels(this)

        try {
            enterForeground(buildNotification(id, note))
        } catch (_: Throwable) {
            // ফোরগ্রাউন্ডে ওঠা যায়নি — অন্তত সাধারণ নোটিফিকেশন যাক
            CalNotes.postNote(this, note)
            isRunning = false; currentId = -1
            stopSelf(); return START_NOT_STICKY
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock?.let { if (it.isHeld) it.release() }
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Patheyo:CalNoteAlarm")?.apply { acquire(MAX_RING_MS + 10_000L) }
        } catch (_: Throwable) {}

        stopSound()
        startSound()
        startVibration()
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, MAX_RING_MS)
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ নোটিফিকেশন

    private fun enterForeground(n: android.app.Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTIF_ID, n)
    }

    private fun actionPi(action: String, id: Int): PendingIntent =
        PendingIntent.getBroadcast(this, if (action == ACTION_STOP) 7791 else 7792,
            Intent(this, CalNoteActionReceiver::class.java).setAction(action).putExtra(CalNotes.EXTRA_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun buildNotification(id: Int, n: CalNote?): android.app.Notification {
        val full = PendingIntent.getActivity(this, 7793,
            Intent(this, CalNoteAlarmActivity::class.java).putExtra(CalNotes.EXTRA_ID, id).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CalNotes.CH_ALARM)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ContextCompat.getColor(this, R.color.brand_notif_color))
            .setContentTitle("নোটের অ্যালার্ম")
            .setContentText(n?.text ?: "")
            .setSubText(if (n != null) CalNotes.dateLine(n) else null)
            .setStyle(NotificationCompat.BigTextStyle().bigText(n?.text ?: ""))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .addAction(0, "বন্ধ করুন", actionPi(ACTION_STOP, id))
            .addAction(0, "${Bn.digits(CalNotes.SNOOZE_MIN)} মিনিট পরে", actionPi(ACTION_SNOOZE, id))
            .build()
    }

    // ------------------------------------------------------------------ রিংটোন ও কম্পন

    /** ইউজারের ফোনের ডিফল্ট রিংটোন; না পেলে ডিফল্ট অ্যালার্ম, তাও না পেলে ডিফল্ট নোটিফিকেশন-সুর */
    private fun ringtoneUri(): Uri? {
        val order = intArrayOf(RingtoneManager.TYPE_RINGTONE, RingtoneManager.TYPE_ALARM, RingtoneManager.TYPE_NOTIFICATION)
        for (t in order) {
            try { RingtoneManager.getActualDefaultRingtoneUri(this, t)?.let { return it } } catch (_: Throwable) {}
            try { RingtoneManager.getDefaultUri(t)?.let { return it } } catch (_: Throwable) {}
        }
        return null
    }

    private fun startSound() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)          // অ্যালার্মের মতো — সাইলেন্ট/রিংটোন-ভলিউমে আটকায় না, অ্যালার্মের ভলিউমে বাজে
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val uri = ringtoneUri() ?: return
        var mp: MediaPlayer? = null
        try {
            mp = MediaPlayer()
            mp.setAudioAttributes(attrs)
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
            return
        } catch (_: Throwable) { try { mp?.release() } catch (_: Throwable) {} }
        // বিকল্প: সিস্টেমের Ringtone
        try {
            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                audioAttributes = attrs
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) isLooping = true
                play()
            }
        } catch (_: Throwable) {}
    }

    private fun stopSound() {
        try { player?.let { if (it.isPlaying) it.stop(); it.release() } } catch (_: Throwable) {}
        player = null
        try { ringtone?.stop() } catch (_: Throwable) {}
        ringtone = null
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            else getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            val pattern = longArrayOf(0, 700, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            else vibrator?.vibrate(pattern, 0)
        } catch (_: Throwable) {}
    }

    private fun stopVibration() { try { vibrator?.cancel() } catch (_: Throwable) {}; vibrator = null }

    // ------------------------------------------------------------------ শেষ করা

    private fun cleanup() {
        handler.removeCallbacks(timeout)
        stopSound(); stopVibration()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        wakeLock = null
        isRunning = false
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        try { NotificationManagerCompat.from(this).cancel(NOTIF_ID) } catch (_: Throwable) {}
    }

    fun finishAlarm(snooze: Boolean) {
        val id = currentId
        cleanup()
        currentId = -1
        if (snooze && id >= 0) CalNotes.snooze(this, id)
        stopSelf()
    }

    /** কেউ বন্ধ করেনি — থামে, আর নোটটা "মিস হওয়া নোট" হয়ে ট্রেতে থাকে */
    private fun timeoutStop() {
        val id = currentId
        cleanup()
        currentId = -1
        if (id >= 0) CalNotes.get(this, id)?.let { CalNotes.postNote(this, it, missed = true) }
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        instance = null
        currentId = -1
        super.onDestroy()
    }
}
