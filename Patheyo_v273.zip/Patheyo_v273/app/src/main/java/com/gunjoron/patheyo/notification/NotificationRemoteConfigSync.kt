package com.gunjoron.patheyo.notification

// app/src/main/java/com/gunjoron/Patheyo/notification/NotificationRemoteConfigSync.kt
//
// Firebase Remote Config-এ "notifications_config_json" নামের প্যারামিটারে
// notifications_config.json-এর মতোই একটি JSON বসিয়ে Publish করলে, অ্যাপ সেটি
// fetch করে নেয় — নতুন করে APK বিল্ড/ইন্সটল করা লাগে না।
//
// অগ্রাধিকার (কোনটা আগে ব্যবহার হবে):
//   ১) Remote Config থেকে সর্বশেষ সফলভাবে fetch হওয়া JSON (SharedPreferences-এ ক্যাশ করা)
//   ২) assets/notifications_config.json (অ্যাপে বান্ডেল করা, রিবিল্ডে বদলায়)
//   ৩) IslamicNotificationData.kt (হার্ডকোড করা শেষ ফলব্যাক)
//
// বিস্তারিত বাংলা নির্দেশিকা: FIREBASE_NOTIFICATION_NIRDESHIKA.md (প্রজেক্ট রুটে)

import android.content.Context
import android.util.Log
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import org.json.JSONObject

object NotificationRemoteConfigSync {

    private const val TAG = "NotifRemoteConfig"

    // Firebase Console → Remote Config-এ ঠিক এই নামেই প্যারামিটার বানাতে হবে
    const val REMOTE_CONFIG_KEY = "notifications_config_json"

    // SharedPreferences-এ (PrayerWidgetProvider.PREFS_NAME এর মধ্যেই) ক্যাশ রাখার key
    const val PREF_KEY_CACHED_REMOTE_JSON = "remote_notifications_config_json"

    /**
     * MainActivity-তে ইতিমধ্যে fetchAndActivate() করা RemoteConfig ইনস্ট্যান্স থাকলে
     * (এবং রিয়েল-টাইম listener-এ তাৎক্ষণিক আপডেট এলে), নতুন করে নেটওয়ার্ক কল না করে
     * সরাসরি সেখান থেকে notifications_config_json পড়ে প্রয়োগ করার জন্য।
     */
    fun applyFromActivatedConfig(
        context: Context,
        remoteConfig: FirebaseRemoteConfig,
        onComplete: (updated: Boolean) -> Unit = {}
    ) {
        val json = remoteConfig.getString(REMOTE_CONFIG_KEY)
        if (json.isBlank()) {
            onComplete(false)
            return
        }
        val isValid = try {
            val arr = JSONObject(json).optJSONArray("notifications")
            arr != null && arr.length() > 0
        } catch (e: Exception) {
            false
        }
        if (!isValid) {
            onComplete(false)
            return
        }
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val already = prefs.getString(PREF_KEY_CACHED_REMOTE_JSON, null)
        if (already == json) {
            onComplete(false) // আগের ক্যাশের সাথে হুবহু মিলে গেলে কিছু করার দরকার নেই
            return
        }
        prefs.edit().putString(PREF_KEY_CACHED_REMOTE_JSON, json).apply()
        NotificationConfigLoader.clearCache()
        onComplete(true)
    }

    /**
     * Remote Config থেকে সর্বশেষ ভ্যালু fetch+activate করে। সফল ও বৈধ JSON পেলে
     * SharedPreferences-এ ক্যাশ করে NotificationConfigLoader-এর ক্যাশ খালি করে দেয়,
     * যাতে পরের বার load() কল করলে নতুন ডেটা ব্যবহার হয়।
     *
     * নেটওয়ার্ক না থাকলে বা কিছু না পেলে চুপচাপ আগের (লোকাল/বান্ডেল) ডেটাই থেকে যায় —
     * এই ফাংশন কখনো নোটিফিকেশন সিস্টেম বন্ধ করে দেয় না।
     */
    fun fetchAndApply(context: Context, onComplete: (updated: Boolean) -> Unit = {}) {
        try {
            val remoteConfig = FirebaseRemoteConfig.getInstance()
            val settings = FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(3600) // স্বাভাবিক অবস্থায় ঘণ্টায় একবারের বেশি fetch না করা
                .build()
            remoteConfig.setConfigSettingsAsync(settings)

            remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w(TAG, "Remote Config fetch ব্যর্থ হয়েছে, বিদ্যমান ডেটাই থাকবে")
                    onComplete(false)
                    return@addOnCompleteListener
                }

                val json = remoteConfig.getString(REMOTE_CONFIG_KEY)
                if (json.isBlank()) {
                    // প্যারামিটারটাই এখনো তৈরি হয়নি বা খালি — স্বাভাবিক, কিছু করার নেই
                    onComplete(false)
                    return@addOnCompleteListener
                }

                val isValid = try {
                    val arr = JSONObject(json).optJSONArray("notifications")
                    arr != null && arr.length() > 0
                } catch (e: Exception) {
                    false
                }

                if (!isValid) {
                    Log.w(TAG, "Remote Config-এর JSON ফরম্যাট ভুল, উপেক্ষা করা হলো (বিদ্যমান ডেটাই থাকবে)")
                    onComplete(false)
                    return@addOnCompleteListener
                }

                val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
                prefs.edit().putString(PREF_KEY_CACHED_REMOTE_JSON, json).apply()
                NotificationConfigLoader.clearCache()
                Log.i(TAG, "Remote Config থেকে নতুন নোটিফিকেশন কনফিগ প্রয়োগ হলো")
                onComplete(true)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Remote Config fetch করতে সমস্যা হয়েছে", e)
            onComplete(false)
        }
    }
}
