package com.gunjoron.patheyo.datecard

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.gunjoron.patheyo.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** আজকের কার্ড বানানো + ফাইলে রাখা + (সেটিংস অনুযায়ী) নীরব নোটিফিকেশন ও গ্যালারিতে সেভ। রাত ১২টার রিসিভার ও স্ক্রিন — দুজনেই এটি ব্যবহার করে। */
object DateCardGenerator {

    const val CHANNEL_ID = "patheyo_date_card"
    private const val NOTIF_ID = 7301

    fun fileFor(prefs: DateCardPrefs, nowMs: Long): File =
        File(prefs.dir(), "card_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(nowMs)) + ".png")

    /** কার্ড বানিয়ে ফাইলে সেভ; নোটিফিকেশন/গ্যালারি সেটিংস মানা হয়। ব্যর্থ হলে null */
    fun generate(ctx: Context, nowMs: Long = System.currentTimeMillis(), notify: Boolean = true): File? {
        val app = ctx.applicationContext
        val prefs = DateCardPrefs(app)
        return try {
            val bmp = DateCardRenderer.renderFor(app, nowMs, prefs, 1080)
            val f = fileFor(prefs, nowMs)
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            cleanOld(prefs, f)
            if (prefs.saveGallery) saveToGallery(app, bmp, f.nameWithoutExtension)
            if (notify && prefs.notify) showNotification(app, bmp, nowMs)
            bmp.recycle()
            f
        } catch (_: Throwable) { null }
    }

    private fun cleanOld(prefs: DateCardPrefs, keep: File) {
        try {
            prefs.dir().listFiles()?.filter { it.name.startsWith("card_") && it != keep }?.sortedByDescending { it.name }?.drop(4)?.forEach { it.delete() }
        } catch (_: Throwable) {}
    }

    fun saveToGallery(ctx: Context, bmp: Bitmap, name: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$name.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Patheyo")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            r.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: return false
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
            r.update(uri, values, null, null)
            true
        } catch (_: Throwable) { false }
    }

    /** শেয়ারের জন্য cacheDir/share/-এ কপি (FileProvider-এ cache-path "share/" আগে থেকেই আছে) → content URI */
    fun shareUri(ctx: Context, bmp: Bitmap): android.net.Uri? = try {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, "patheyo_datecard_${System.currentTimeMillis()}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    } catch (_: Throwable) { null }

    private fun showNotification(ctx: Context, card: Bitmap, nowMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, ctx.getString(R.string.date_card_channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                        description = "প্রতিদিন রাত ১২টায় তৈরি আজকের তারিখ-কার্ড (শব্দ ছাড়া)"
                        setSound(null, null); enableVibration(false); setShowBadge(false)
                    })
                }
            }
            val info = DateCardRenderer.infoFor(ctx, nowMs)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val open = PendingIntent.getActivity(ctx, 7301, Intent(ctx, DateCardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags)
            val share = PendingIntent.getActivity(ctx, 7302, Intent(ctx, DateCardActivity::class.java).putExtra("share", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags)
            val big = Bitmap.createScaledBitmap(card, 900, (900 * card.height / card.width.toFloat()).toInt(), true)
            val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("আজ ${info.weekday}")
                .setContentText("${info.greg} · ${info.hijri} · ${info.bangla}")
                .setStyle(NotificationCompat.BigPictureStyle().bigPicture(big).setSummaryText("${info.greg} · ${info.hijri} · ${info.bangla}"))
                .setContentIntent(open)
                .addAction(0, "শেয়ার করুন", share)
                .setAutoCancel(true)
                .setSilent(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
            NotificationManagerCompat.from(ctx).notify(NOTIF_ID, n)
        } catch (_: Throwable) {}
    }
}
