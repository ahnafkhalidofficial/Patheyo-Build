package com.gunjoron.patheyo.alarm

// v48: আজান নোটিফিকেশনের চ্যানেল এক জায়গায়।
//  • নোটিফিকেশন-চ্যানেল একবার তৈরি হলে তার গুরুত্ব/লক-স্ক্রিন সেটিং কোড দিয়ে বদলানো যায় না — ইউজার (বা কিছু ফোন নিজে থেকে)
//    গুরুত্ব কমিয়ে দিলে আজানের পপআপ আর আসে না। তাই নতুন আইডির চ্যানেল (v2) বানানো হয়, পুরনোটা মুছে দেওয়া হয়।
//  • [problem] দেখে পারমিশন-পপআপ (AlarmPermissionDialog.Step.NOTIF_POPUP) ঠিক করে দেখানো দরকার কি না বোঝা যায়।

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object AzanChannel {

    const val ID = "azan_alarm_channel_v2"
    private const val OLD_ID = "azan_alarm_channel"

    fun ensure(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(OLD_ID) != null) {
                try { nm.deleteNotificationChannel(OLD_ID) } catch (_: Throwable) {}
            }
            if (nm.getNotificationChannel(ID) == null) {
                nm.createNotificationChannel(NotificationChannel(ID, "নামাজের আজান", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "নামাজের ওয়াক্ত হলে আজানের নোটিফিকেশন ও পপআপ"
                    setSound(null, null)
                    setShowBadge(false)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                })
            }
        } catch (_: Throwable) {}
    }

    /** আজানের পপআপ আসার পথে বাধা আছে কি না: নোটিফিকেশন বন্ধ / চ্যানেলের গুরুত্ব কম / লক-স্ক্রিনে লুকানো */
    fun problem(ctx: Context): Boolean = try {
        ensure(ctx)
        var bad = !NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        if (!bad && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = nm.getNotificationChannel(ID)
            if (ch != null) {
                bad = ch.importance < NotificationManager.IMPORTANCE_HIGH ||
                    ch.lockscreenVisibility == NotificationCompat.VISIBILITY_SECRET
            }
        }
        bad
    } catch (_: Throwable) { false }
}
