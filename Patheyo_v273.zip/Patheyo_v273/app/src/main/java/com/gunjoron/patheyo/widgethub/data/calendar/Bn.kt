package com.gunjoron.patheyo.widgethub.data.calendar

/** বাংলা সংখ্যা ও মাসের নাম। */
object Bn {
    private const val DIGITS = "০১২৩৪৫৬৭৮৯"

    fun digits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) sb.append(if (ch in '0'..'9') DIGITS[ch - '0'] else ch)
        return sb.toString()
    }

    fun digits(n: Int): String = digits(n.toString())

    fun pad2(n: Int): String = if (n < 10) "0$n" else n.toString()

    val GREG_MONTHS = arrayOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    // বাংলাদেশ সংশোধিত পঞ্জিকা (বৈশাখ = ১৪ এপ্রিল)
    val BANGLA_MONTHS = arrayOf(
        "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
        "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
    )

    val HIJRI_MONTHS = arrayOf(
        "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল আউয়াল", "জমাদিউস সানি",
        "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
    )

    val PRAYER_NAMES = arrayOf("ফজর", "যোহর", "আসর", "মাগরিব", "এশা")
}
