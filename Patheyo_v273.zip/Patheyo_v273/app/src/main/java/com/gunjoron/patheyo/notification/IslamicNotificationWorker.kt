package com.gunjoron.patheyo.notification

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

class IslamicNotificationWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        ScheduledNotificationScheduler.scheduleAllNotifications(applicationContext)

        // ✅ FIX #NEW: আগে এখানে fetchAndApply()-এর (Firebase network) কলব্যাক শেষ হওয়ার
        // অপেক্ষা না করেই doWork() Result.success() রিটার্ন করে ফেলত — ফলে WorkManager
        // worker-টাকে "শেষ" ধরে নিয়ে যেকোনো সময় প্রসেস/থ্রেড বন্ধ করে দিতে পারত, আর
        // ব্যাকগ্রাউন্ডে চলতে থাকা নেটওয়ার্ক কলব্যাকটা মাঝপথে বাতিল/অসম্পূর্ণ থেকে যেতে
        // পারত (বিশেষত কম-মেমরির ফোনে, যেখানে সিস্টেম আরও আক্রমণাত্মকভাবে প্রসেস রিক্লেইম
        // করে)। এখন suspendCancellableCoroutine দিয়ে আসল কলব্যাক শেষ না হওয়া পর্যন্ত
        // doWork() সাসপেন্ড থাকে, তাই fetchAndApply() সবসময় নির্ভরযোগ্যভাবে শেষ হয়ে যায়।
        // দ্রষ্টব্য: cont.resume(...) ব্যবহার করা হচ্ছে, cont.resumeWith(Result.success(...)) নয় —
        // কারণ এই ক্লাসে ইতিমধ্যেই androidx.work.ListenableWorker.Result (doWork()-এর রিটার্ন
        // টাইপ) "Result" নামে ব্যবহৃত হচ্ছে, kotlin.Result-এর সাথে নাম-সংঘর্ষ এড়াতে এটিই নিরাপদ।
        val updated = suspendCancellableCoroutine<Boolean> { cont ->
            NotificationRemoteConfigSync.fetchAndApply(applicationContext) { didUpdate ->
                if (cont.isActive) cont.resume(didUpdate)
            }
        }
        if (updated) {
            ScheduledNotificationScheduler.scheduleAllNotifications(applicationContext)
        }

        return Result.success()
    }
}
