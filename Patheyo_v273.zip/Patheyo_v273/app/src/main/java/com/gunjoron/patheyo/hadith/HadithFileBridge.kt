package com.gunjoron.patheyo.hadith

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.zip.GZIPInputStream
import javax.net.ssl.SSLException

/**
 * হাদিস পেজের (WebView) জন্য নেটিভ ডাউনলোডার — ৬টি কিতাব (.json.gz) GitHub Release থেকে নামিয়ে অ্যাপের নিজস্ব স্টোরেজে রাখে।
 * (আগে কিতাবগুলো অ্যাপের ভেতরেই বসানো ছিল, তাই অ্যাপ ~৩০ MB বড় ছিল।)
 *
 * JS-এর সাথে চুক্তি (assets/features/hadith/js/…book-download.js):
 *   window.HadithNative : isBookReady(id, ver), getBookSize(id, ver), getStatus(id, ver), startDownload(id, url, ver),
 *                         cancelDownload(id), readChunk(id, ver, offset, length), deleteBook(id)
 *   প্রগ্রেস: window.__hadithNativeEvent({id, phase, downloaded, total, error}) — phase = downloading | done | error | idle
 *   ফাইল পড়া: https://hadith-local.invalid/<id>-v<ver>.json (HadithLocalServer), না হলে readChunk (base64 টুকরো)।
 *
 * ফাইল থাকে filesDir/hadith/ ফোল্ডারে। ডাউনলোড `.part` ফাইলে হয়; নেটওয়ার্ক কেটে গেলে ফাইলটি রাখা হয়, আবার চাপলে
 * যেখানে থেমেছিল সেখান থেকে চলে (HTTP Range)। শেষে .gz খুলে `{` দিয়ে শুরু কি না যাচাই করে তবেই সেভ হয়।
 */
class HadithFileBridge(context: Context, private val webView: WebView) {

    private class Cancelled : Exception()

    private class BookState {
        @Volatile var phase = "idle"
        @Volatile var downloaded = 0L
        @Volatile var total = 0L
        @Volatile var error: String? = null
        @Volatile var cancelled = false
        @Volatile var conn: HttpURLConnection? = null
        @Volatile var lastPushAt = 0L
    }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newFixedThreadPool(2)
    private val states = ConcurrentHashMap<String, BookState>()

    private fun st(id: String): BookState = states.getOrPut(id) { BookState() }
    private fun validId(id: String) = Regex("^[a-z0-9_]+$").matches(id)

    private fun dir(): File = File(appContext.filesDir, HadithLocalServer.DIR_NAME).apply { mkdirs() }
    private fun finalFile(id: String, ver: Int): File = File(dir(), "$id-v$ver.json")
    private fun partFile(id: String): File = File(dir(), "$id.json.gz.part")

    // ------------------------------------------------------------------ JS-এ দেখানো মেথড

    @JavascriptInterface fun isBookReady(id: String, ver: Int): Boolean =
        validId(id) && finalFile(id, ver).let { it.exists() && it.length() > 0 }

    @JavascriptInterface fun getBookSize(id: String, ver: Int): Long =
        if (validId(id)) finalFile(id, ver).length() else 0L

    @JavascriptInterface fun getStatus(id: String, ver: Int): String = statusJson(id)

    @JavascriptInterface fun startDownload(id: String, url: String, ver: Int) {
        if (!validId(id)) return
        val s = st(id)
        if (s.phase == "downloading") return
        if (!url.startsWith("https://", ignoreCase = true)) { fail(id, "bad-url"); return }
        s.cancelled = false
        s.error = null
        s.downloaded = 0L
        s.total = 0L
        s.phase = "downloading"
        push(id, true)
        worker.execute {
            try {
                runDownload(id, url, ver)
            } catch (_: Cancelled) {
                onCancelled(id)
            } catch (e: Throwable) {
                if (s.cancelled) onCancelled(id) else fail(id, mapError(e))
            }
        }
    }

    @JavascriptInterface fun cancelDownload(id: String) {
        if (!validId(id)) return
        val s = st(id)
        if (s.phase != "downloading") return
        s.cancelled = true
        try { s.conn?.disconnect() } catch (_: Throwable) {}   // আটকে থাকা read সাথে সাথে ছাড়ানো
    }

    /** offset থেকে length বাইট পড়ে base64 (NO_WRAP) হিসেবে দেয়; ব্যর্থ হলে খালি স্ট্রিং */
    @JavascriptInterface fun readChunk(id: String, ver: Int, offset: Long, length: Int): String {
        if (!validId(id)) return ""
        return try {
            RandomAccessFile(finalFile(id, ver), "r").use { raf ->
                if (offset < 0 || offset >= raf.length() || length <= 0) return ""
                val n = minOf(length.toLong(), raf.length() - offset).toInt()
                val buf = ByteArray(n)
                raf.seek(offset)
                raf.readFully(buf)
                Base64.encodeToString(buf, Base64.NO_WRAP)
            }
        } catch (_: Throwable) { "" }
    }

    @JavascriptInterface fun deleteBook(id: String) {
        if (!validId(id)) return
        val s = st(id)
        if (s.phase == "downloading") { s.cancelled = true; try { s.conn?.disconnect() } catch (_: Throwable) {} }
        deleteFiles(id)
        s.error = null; s.phase = "idle"; s.downloaded = 0L; s.total = 0L
    }

    // ------------------------------------------------------------------ ডাউনলোড

    private fun openConnection(url: String, from: Long): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true      // GitHub Release → release-assets.githubusercontent.com (https→https)
        c.requestMethod = "GET"
        c.setRequestProperty("User-Agent", "Patheyo/1.6 (Android)")
        c.setRequestProperty("Accept-Encoding", "identity")
        if (from > 0) c.setRequestProperty("Range", "bytes=$from-")
        return c
    }

    private fun runDownload(id: String, url: String, ver: Int) {
        val s = st(id)
        val part = partFile(id)
        var resumeFrom = if (part.exists()) part.length() else 0L
        var c = openConnection(url, resumeFrom)
        s.conn = c
        var code = c.responseCode
        if (code == 416) {                    // রেঞ্জ মেলেনি (আগের .part পুরনো/নষ্ট) → গোড়া থেকে
            c.disconnect(); part.delete(); resumeFrom = 0L
            c = openConnection(url, 0L); s.conn = c; code = c.responseCode
        }
        if (code !in 200..299) { c.disconnect(); fail(id, "http-$code"); return }
        val append = code == 206 && resumeFrom > 0
        if (!append) resumeFrom = 0L          // সার্ভার Range না মানলে (200) গোড়া থেকে শুরু
        val len = c.contentLengthLong
        s.total = if (len > 0) len + resumeFrom else 0L
        s.downloaded = resumeFrom
        push(id, true)

        c.inputStream.use { input ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (s.cancelled) throw Cancelled()
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    s.downloaded += n
                    push(id, false)
                }
            }
        }
        if (s.cancelled) throw Cancelled()
        c.disconnect()
        if (s.total > 0 && part.length() < s.total) { fail(id, "network"); return }   // মাঝপথে কেটে গেছে — .part রাখা হলো
        finishAndStore(id, ver, part)
    }

    private fun readHead(f: File, n: Int): ByteArray {
        val buf = ByteArray(n)
        val r = f.inputStream().use { it.read(buf) }
        return if (r <= 0) ByteArray(0) else buf.copyOf(r)
    }

    /** .gz হলে খুলে, `{` দিয়ে শুরু কি না যাচাই করে চূড়ান্ত নামে সেভ; একই কিতাবের পুরনো ভার্সনের ফাইল মুছে ফেলে */
    private fun finishAndStore(id: String, ver: Int, part: File) {
        val s = st(id)
        val dst = finalFile(id, ver)
        val tmp = File(dir(), "$id-v$ver.json.tmp")
        val head = readHead(part, 2)
        val isGz = head.size >= 2 && head[0] == 0x1f.toByte() && head[1] == 0x8b.toByte()
        try {
            if (isGz) {
                GZIPInputStream(part.inputStream().buffered()).use { gz -> FileOutputStream(tmp).use { gz.copyTo(it) } }
                part.delete()
            } else if (!part.renameTo(tmp)) { fail(id, "corrupt"); return }
        } catch (e: IOException) {
            tmp.delete(); part.delete(); fail(id, "corrupt"); return
        }
        if (String(readHead(tmp, 1), Charsets.UTF_8) != "{") { tmp.delete(); fail(id, "not-book"); return }
        dst.delete()
        if (!tmp.renameTo(dst)) { fail(id, "corrupt"); return }
        dir().listFiles()?.forEach {   // আগের ডেটা-ভার্সনের ফাইল আর লাগবে না
            if (it.name.startsWith("$id-v") && it.name.endsWith(".json") && it.name != dst.name) it.delete()
        }
        val size = dst.length()
        s.downloaded = size; s.total = size; s.error = null; s.phase = "done"
        push(id, true)
        s.phase = "idle"; s.downloaded = 0L; s.total = 0L
    }

    private fun onCancelled(id: String) {
        val s = st(id)
        try { partFile(id).delete() } catch (_: Throwable) {}
        s.error = null; s.phase = "idle"; s.downloaded = 0L; s.total = 0L
        push(id, true)
    }

    private fun fail(id: String, code: String) {
        val s = st(id)
        s.error = code; s.phase = "error"
        push(id, true)
    }

    private fun deleteFiles(id: String) {
        try {
            dir().listFiles()?.forEach {
                if (it.name.startsWith("$id-v") || it.name == "$id.json.gz.part") it.delete()
            }
        } catch (_: Throwable) {}
    }

    private fun mapError(e: Throwable): String = when (e) {
        is UnknownHostException -> if (isOnline()) "network" else "offline"
        is SocketTimeoutException -> "timeout"
        is SSLException -> "ssl"
        is IOException -> {
            val m = e.message ?: ""
            when {
                m.contains("ENOSPC", true) || m.contains("No space", true) -> "no-space"
                !isOnline() -> "offline"
                else -> "network"
            }
        }
        else -> "network"
    }

    private fun isOnline(): Boolean = try {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Throwable) { true }

    // ------------------------------------------------------------------ JS-এ অবস্থা পাঠানো

    private fun statusJson(id: String): String {
        val s = st(id)
        return JSONObject()
            .put("id", id)
            .put("phase", s.phase)
            .put("downloaded", s.downloaded)
            .put("total", s.total)
            .put("error", s.error ?: JSONObject.NULL)
            .toString()
    }

    private fun push(id: String, force: Boolean) {
        val s = st(id)
        val now = SystemClock.elapsedRealtime()
        if (!force && now - s.lastPushAt < 250L) return
        s.lastPushAt = now
        val js = "window.__hadithNativeEvent&&window.__hadithNativeEvent(${statusJson(id)});"
        main.post { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} }
    }
}
