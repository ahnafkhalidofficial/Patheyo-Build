package com.gunjoron.patheyo.datecard

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.graphics.drawable.GradientDrawable.Orientation
import com.gunjoron.patheyo.MainActivity
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.graphics.PixelFormat
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.Executors
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import android.content.res.ColorStateList
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.SystemBarsBridge

/**
 * তারিখ-কার্ডের স্ক্রিন: আজকের কার্ডের প্রিভিউ, ১২টি ইসলামিক থিম (বা "অটো" = প্রতিদিন নতুন), পোস্ট/স্টোরি মাপ,
 * ফোনের গ্যালারি থেকে নিজের ব্যাকগ্রাউন্ড, শেয়ার / গ্যালারিতে সেভ, আর রাত ১২টার অটো-তৈরির সুইচ।
 */
class DateCardActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: DateCardPrefs
    private lateinit var preview: ImageView
    private lateinit var themeNote: TextView
    private lateinit var themeRow: LinearLayout
    private lateinit var formatRow: LinearLayout
    private lateinit var photoBox: LinearLayout
    private lateinit var removePhotoBtn: TextView
    private var token = 0
    private var current: Bitmap? = null
    private var wantShare = false
    private lateinit var calHolder: FrameLayout
    private lateinit var glanceHolder: FrameLayout      // v245: ওপরের "এক নজরে" কার্ড
    private lateinit var calLabel: View
    private lateinit var mainScroll: ScrollView
    private var calSig = ""
    private var calListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null
    private val calTick = object : Runnable {
        override fun run() {
            // v248: স্ক্রিন খোলা থাকা অবস্থায় নোটের মেয়াদ শেষ হলে নিজেই আর্কাইভে যায় ও কার্ড হালনাগাদ হয়
            val moved = com.gunjoron.patheyo.calnote.CalNotes.sweep(this@DateCardActivity)
            if (::calHolder.isInitialized && (moved > 0 || calSig != HijriCalendarCard.signature(this@DateCardActivity))) refreshCalendar()
            ui.postDelayed(this, 30_000L)
        }
    }

    // ধাপ ৭: রং এখন ডিজাইন সিস্টেমের টোকেন (res/values/pt_ds.xml) থেকে — অ্যাপ যে থিমে (ডার্ক/লাইট) আছে সেই অনুযায়ী
    private var light = false
    private var BG = 0; private var SURF = 0; private var SURF_HI = 0; private var SURF2 = 0
    private var LINE = 0; private var LINE_S = 0; private var TEXT = 0; private var TEXT2 = 0; private var TEXT3 = 0
    private var PRIMARY = 0; private var PRESS = 0; private var ON_PRIMARY = 0
    private var GOLD = 0; private var GOLD_LINE = 0; private var GOLD_SOFT = 0; private var PRIMARY_TEXT = 0
    private var OK = 0; private var OK_TEXT = 0; private var OK_SOFT = 0      // v244: নোট-চিহ্নের পান্না-সবুজ
    private var fontBold: Typeface = Typeface.DEFAULT_BOLD
    private var fontReg: Typeface = Typeface.DEFAULT
    private lateinit var themeGrid: LinearLayout

    private fun c(darkId: Int, lightId: Int) = ContextCompat.getColor(this, if (light) lightId else darkId)
    private fun loadPalette() {
        light = SystemBarsBridge.isLightSaved(this)
        BG = c(R.color.pt_dark_bg, R.color.pt_light_bg); SURF = c(R.color.pt_dark_surface, R.color.pt_light_surface)
        SURF_HI = c(R.color.pt_dark_surface_hi, R.color.pt_light_surface_hi); SURF2 = c(R.color.pt_dark_surface_2, R.color.pt_light_surface_2)
        LINE = c(R.color.pt_dark_line, R.color.pt_light_line); LINE_S = c(R.color.pt_dark_line_strong, R.color.pt_light_line_strong)
        TEXT = c(R.color.pt_dark_text, R.color.pt_light_text); TEXT2 = c(R.color.pt_dark_text_2, R.color.pt_light_text_2); TEXT3 = c(R.color.pt_dark_text_3, R.color.pt_light_text_3)
        PRIMARY = c(R.color.pt_dark_primary, R.color.pt_light_primary); PRESS = c(R.color.pt_dark_primary_press, R.color.pt_light_primary_press)
        ON_PRIMARY = c(R.color.pt_dark_on_primary, R.color.pt_light_on_primary)
        PRIMARY_TEXT = c(R.color.pt_dark_primary_text, R.color.pt_light_primary_text)
        GOLD = c(R.color.pt_dark_gold, R.color.pt_light_gold); GOLD_LINE = c(R.color.pt_dark_gold_line, R.color.pt_light_gold_line); GOLD_SOFT = c(R.color.pt_dark_gold_soft, R.color.pt_light_gold_soft)
        OK = c(R.color.pt_dark_success, R.color.pt_light_success); OK_TEXT = c(R.color.pt_dark_success_text, R.color.pt_light_success_text); OK_SOFT = c(R.color.pt_dark_success_soft, R.color.pt_light_success_soft)
        try { ResourcesCompat.getFont(this, R.font.gunjoron_bold)?.let { fontBold = it } } catch (_: Throwable) {}
        try { ResourcesCompat.getFont(this, R.font.gunjoron_regular)?.let { fontReg = it } } catch (_: Throwable) {}
    }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) importPhoto(uri) }

    // ------------------------------------------------------------------ v244: ক্যালেন্ডারের নোট
    /** বাছা মাস/দিন — ক্যালেন্ডার নতুন করে আঁকলেও (অ্যাপে ফেরা, নোট বদলানো) হারায় না */
    private val calState = HijriCalendarCard.ViewState()
    private var pendingPermDone: (() -> Unit)? = null

    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(this, "নোটিফিকেশনের অনুমতি বন্ধ — সময়মতো জানানো যাবে না। ফোনের সেটিংস থেকে চালু করুন", Toast.LENGTH_LONG).show()
        val cb = pendingPermDone; pendingPermDone = null
        cb?.invoke()
    }

    private val noteHost = object : HijriCalendarCard.Host {
        override fun ensureNotePermissions(mode: Int, done: () -> Unit) {
            if (mode == com.gunjoron.patheyo.calnote.CalNotes.MODE_NONE) { done(); return }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this@DateCardActivity, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                pendingPermDone = done
                notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                return
            }
            if (!androidx.core.app.NotificationManagerCompat.from(this@DateCardActivity).areNotificationsEnabled())
                Toast.makeText(this@DateCardActivity, "ফোনে এই অ্যাপের নোটিফিকেশন বন্ধ আছে — সেটিংস থেকে চালু করুন", Toast.LENGTH_LONG).show()
            done()
        }
        override fun onNotesChanged() { refreshCalendar() }
        override fun openLogin() { goNav(4) }        // "আরও" ট্যাবে অ্যাকাউন্ট/সাইন-ইন
        override fun scrollToCalendar() {
            if (!::mainScroll.isInitialized || !::calLabel.isInitialized) return
            mainScroll.post { mainScroll.smoothScrollTo(0, calLabel.top) }
        }
        /** v248: কার্ডের ভেতরের কোনো অংশে (যেমন ওপরের নোট-অংশ) মসৃণভাবে স্ক্রল */
        override fun scrollToView(v: View) {
            if (!::mainScroll.isInitialized) return
            mainScroll.post {
                val content = mainScroll.getChildAt(0)
                var y = 0
                var cur: View = v
                while (cur !== content) {
                    y += cur.top
                    cur = cur.parent as? View ?: return@post
                }
                mainScroll.smoothScrollTo(0, (y - dp(12)).coerceAtLeast(0))
            }
        }
    }

    /** নোটিফিকেশনে ট্যাপ করে এলে ক্যালেন্ডার ওই নোটের তারিখে খোলে */
    private fun applyNoteIntent(i: Intent?): Boolean {
        val y = i?.getIntExtra(com.gunjoron.patheyo.calnote.CalNotes.EXTRA_Y, -1) ?: -1
        if (y < 1950) return false
        calState.y = y
        calState.m = i!!.getIntExtra(com.gunjoron.patheyo.calnote.CalNotes.EXTRA_M, 0)
        calState.d = i.getIntExtra(com.gunjoron.patheyo.calnote.CalNotes.EXTRA_D, 1)
        return true
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        prefs = DateCardPrefs(this)
        loadPalette()
        // v240: ট্রানজিশনের সময় সাদা/কালো ঝলক নয় — জানালার ব্যাকগ্রাউন্ড অ্যাপের নিজের রং
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(BG))
        wantShare = intent?.getBooleanExtra("share", false) == true
        applyNoteIntent(intent)
        setContentView(buildUi())
        WindowCompat.getInsetsController(window, window.decorView).apply { isAppearanceLightStatusBars = light; isAppearanceLightNavigationBars = light }
        refreshAll()
    }

    /** v240: বন্ধ হওয়ার সময় অ্যাপের পেজের মতো নরমভাবে বেরোয় */
    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.pt_page_hold, R.anim.pt_page_exit)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("share", false)) { wantShare = true; renderPreview() }
        if (applyNoteIntent(intent) && ::calHolder.isInitialized) refreshCalendar()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { calListener?.let { getSharedPreferences(com.gunjoron.patheyo.widget.PrayerWidgetProvider.PREFS_NAME, MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(it) } } catch (_: Throwable) {}
        calListener = null
        worker.shutdownNow()
    }

    // ------------------------------------------------------------------ UI গঠন

    private fun tv(text: String, size: Float, color: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); typeface = if (bold) fontBold else fontReg
    }

    private fun round(r: Int, fill: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(fill); if (stroke != 0) setStroke(dp(sw), stroke)
    }

    /** ভরাট (রয়্যাল ব্লু) বা সোনালি রেখার বাটন */
    private fun pill(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 15f; gravity = Gravity.CENTER; typeface = fontBold
        setTextColor(if (filled) ON_PRIMARY else TEXT)
        background = if (filled) GradientDrawable(Orientation.TL_BR, intArrayOf(PRIMARY, PRESS)).apply { cornerRadius = dp(12).toFloat() }
                     else round(12, Color.TRANSPARENT, GOLD_LINE)
        minHeight = dp(48)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setOnClickListener { onClick() }
    }

    /** ৮-কোনা তারা (অ্যাপের সব জায়গার মতো) */
    private class StarDrawable(private val col: Int) : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        override fun draw(cv: Canvas) {
            p.color = col
            val s = bounds.width() / 100f
            val pts = floatArrayOf(50f,1f, 64f,15f, 85f,15f, 85f,36f, 99f,50f, 85f,64f, 85f,85f, 64f,85f, 50f,99f, 36f,85f, 15f,85f, 15f,64f, 1f,50f, 15f,36f, 15f,15f, 36f,15f)
            val path = Path()
            var i = 0
            while (i < pts.size) { val x = bounds.left + pts[i] * s; val y = bounds.top + pts[i + 1] * s; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y); i += 2 }
            path.close(); cv.drawPath(path, p)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    /** অংশের শিরোনাম: সোনালি তারা + শিরোনাম + মিলিয়ে যাওয়া সোনালি রেখা */
    private fun label(t: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(2), dp(26), 0, dp(12))
        addView(View(this@DateCardActivity).apply { background = StarDrawable(GOLD) }, LinearLayout.LayoutParams(dp(11), dp(11)).apply { rightMargin = dp(8) })
        addView(tv(t, 16f, TEXT, true))
        addView(View(this@DateCardActivity).apply { background = GradientDrawable(Orientation.LEFT_RIGHT, intArrayOf(GOLD_LINE, Color.TRANSPARENT)) },
            LinearLayout.LayoutParams(0, dp(1), 1f).apply { leftMargin = dp(10) })
    }

    private fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(12), dp(12), dp(12))
        addView(tv(text, 14.5f, TEXT).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        addView(SwitchCompat(this@DateCardActivity).apply {
            isChecked = checked
            thumbTintList = ColorStateList(states, intArrayOf(ON_PRIMARY, if (light) Color.WHITE else TEXT2))
            trackTintList = ColorStateList(states, intArrayOf(PRIMARY, LINE_S))
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
    }

    /** হোম/অন্য ফিচারের নিচের নেভিগেশনের আইকন (SVG পাথের মতোই), stroke-only */
    private class NavIcon(private val kind: Int, private val col: Int, private val d: Float) : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.8f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        override fun draw(c: Canvas) {
            p.color = col
            val sc = bounds.width() / 24f
            c.save(); c.translate(bounds.left.toFloat(), bounds.top.toFloat()); c.scale(sc, sc)
            val path = Path()
            when (kind) {
                0 -> { path.moveTo(4f, 11.5f); path.lineTo(12f, 4f); path.lineTo(20f, 11.5f)
                    path.moveTo(6f, 10f); path.lineTo(6f, 19f); path.lineTo(10.5f, 20f); path.lineTo(10.5f, 14.5f); path.lineTo(13.5f, 14.5f); path.lineTo(13.5f, 20f); path.lineTo(18f, 19f); path.lineTo(18f, 10f) }
                1 -> { path.moveTo(8f, 21f); path.lineTo(8f, 15f); path.cubicTo(8f, 9.5f, 16f, 9.5f, 16f, 15f); path.lineTo(16f, 21f)
                    path.moveTo(12f, 11f); path.lineTo(12f, 7.5f)
                    path.moveTo(3f, 21f); path.lineTo(3f, 12.8f); path.lineTo(4.25f, 10.5f); path.lineTo(5.5f, 12.8f); path.lineTo(5.5f, 21f)
                    path.moveTo(18.5f, 21f); path.lineTo(18.5f, 12.8f); path.lineTo(19.75f, 10.5f); path.lineTo(21f, 12.8f); path.lineTo(21f, 21f)
                    path.moveTo(2f, 21f); path.lineTo(22f, 21f) }
                2 -> { path.moveTo(12f, 5.5f); path.cubicTo(10.4f, 4.5f, 8.4f, 4.1f, 6f, 4.3f); path.lineTo(6f, 17.7f); path.cubicTo(8.4f, 17.5f, 10.4f, 17.9f, 12f, 18.9f)
                    path.cubicTo(13.6f, 17.9f, 15.6f, 17.5f, 18f, 17.7f); path.lineTo(18f, 4.3f); path.cubicTo(15.6f, 4.1f, 13.6f, 4.5f, 12f, 5.5f)
                    path.moveTo(12f, 5.5f); path.lineTo(12f, 18.9f) }
                3 -> { path.addRoundRect(RectF(5f, 3.5f, 19f, 20f), 1.6f, 1.6f, Path.Direction.CW)
                    path.moveTo(5f, 18.5f); path.lineTo(19f, 17f)
                    path.moveTo(9f, 8f); path.lineTo(15f, 8f); path.moveTo(9f, 11f); path.lineTo(13f, 11f) }
                else -> { p.style = Paint.Style.FILL; c.drawCircle(5f, 12f, 1.3f, p); c.drawCircle(12f, 12f, 1.3f, p); c.drawCircle(19f, 12f, 1.3f, p); c.restore(); return }
            }
            c.drawPath(path, p); c.restore()
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
        override fun getIntrinsicWidth() = d.toInt()
        override fun getIntrinsicHeight() = d.toInt()
    }

    /**
     * v262: ক্যালেন্ডারের হেডার-আইকন = হোমের "ক্যালেন্ডার" আইকন (assets/index.html-এর SVG-র হুবহু Canvas রূপ), ১০০×১০০ ক্যানভাসে আঁকা।
     * নীল ব্যান্ড + সোনালি রেখা ও রিং + ৮-কোনা তারা, বরফ-নীল বডিতে তারিখ-ঘর (আজ = সোনালি), নিচে ডানে সোনালি-রিমের পান্না চাঁদ-ব্যাজ।
     */
    private class CalendarMark : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val blue1 = Color.parseColor("#1F63D6"); private val blue2 = Color.parseColor("#3B8DEB")
        private val gold1 = Color.parseColor("#FBD35F"); private val gold2 = Color.parseColor("#DE9C22")
        private val em1 = Color.parseColor("#26CC82"); private val em2 = Color.parseColor("#0E9F5A")
        private val ice1 = Color.parseColor("#EEF6FE"); private val ice2 = Color.parseColor("#B3D3EE")
        private val shad = Color.parseColor("#0A2C78")
        private fun grad(c1: Int, c2: Int, r: RectF) = android.graphics.LinearGradient(r.left, r.top, r.right, r.bottom, c1, c2, android.graphics.Shader.TileMode.CLAMP)
        private fun block(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float, c1: Int, c2: Int) {
            val rect = RectF(x, y, x + w, y + h); p.shader = grad(c1, c2, rect); c.drawRoundRect(rect, r, r, p); p.shader = null
        }
        private fun solidRound(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float, col: Int, a: Int) {
            p.color = col; p.alpha = a; c.drawRoundRect(RectF(x, y, x + w, y + h), r, r, p); p.alpha = 255
        }
        private fun solidCircle(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, a: Int) {
            p.color = col; p.alpha = a; c.drawCircle(cx, cy, r, p); p.alpha = 255
        }
        private fun gradCircle(c: Canvas, cx: Float, cy: Float, r: Float, c1: Int, c2: Int) {
            p.shader = grad(c1, c2, RectF(cx - r, cy - r, cx + r, cy + r)); c.drawCircle(cx, cy, r, p); p.shader = null
        }
        private fun ringGold(c: Canvas, cx: Float, cy: Float, r: Float, w: Float, c1: Int, c2: Int) {
            p.style = Paint.Style.STROKE; p.strokeWidth = w
            p.shader = grad(c1, c2, RectF(cx - r, cy - r, cx + r, cy + r)); c.drawCircle(cx, cy, r, p); p.shader = null
            p.style = Paint.Style.FILL
        }
        override fun draw(cv: Canvas) {
            val sc = bounds.width() / 100f
            cv.save(); cv.translate(bounds.left.toFloat(), bounds.top.toFloat()); cv.scale(sc, sc)
            solidRound(cv, 9f, 21f, 82f, 75f, 18f, shad, 77)
            block(cv, 9f, 14f, 82f, 78f, 18f, ice1, ice2)
            run {  // ওপরের নীল ব্যান্ড (ওপরের দুই কোনা গোল, নিচে সোজা)
                val hr = RectF(9f, 14f, 91f, 44f); val hp = Path().apply { addRoundRect(hr, floatArrayOf(18f,18f,18f,18f,0f,0f,0f,0f), Path.Direction.CW) }
                p.shader = grad(blue1, blue2, hr); cv.drawPath(hp, p); p.shader = null }
            solidRound(cv, 20f, 16.8f, 60f, 7f, 3.5f, Color.WHITE, 38)
            block(cv, 9f, 43f, 82f, 2.2f, 0f, gold1, gold2)
            block(cv, 26f, 5f, 10f, 22f, 5f, gold1, gold2)
            solidRound(cv, 28.3f, 7.6f, 2.2f, 12f, 1.1f, Color.WHITE, 153)
            block(cv, 64f, 5f, 10f, 22f, 5f, gold1, gold2)
            solidRound(cv, 66.3f, 7.6f, 2.2f, 12f, 1.1f, Color.WHITE, 153)
            run {  // ৮-কোনা তারা (অ্যাপের ব্র্যান্ড-চিহ্ন)
                val sp = Path(); val sr = RectF(43.6f, 22.6f, 56.4f, 35.4f)
                sp.moveTo(50f, 22.38f)
                sp.lineTo(51.89f, 24.27f)
                sp.lineTo(54.73f, 24.27f)
                sp.lineTo(54.73f, 27.11f)
                sp.lineTo(56.62f, 29f)
                sp.lineTo(54.73f, 30.89f)
                sp.lineTo(54.73f, 33.73f)
                sp.lineTo(51.89f, 33.73f)
                sp.lineTo(50f, 35.62f)
                sp.lineTo(48.11f, 33.73f)
                sp.lineTo(45.27f, 33.73f)
                sp.lineTo(45.27f, 30.89f)
                sp.lineTo(43.38f, 29f)
                sp.lineTo(45.27f, 27.11f)
                sp.lineTo(45.27f, 24.27f)
                sp.lineTo(48.11f, 24.27f)
                sp.close(); p.shader = grad(gold1, gold2, sr); cv.drawPath(sp, p); p.shader = null }
            block(cv, 18f, 50.5f, 8f, 8f, 2.6f, blue1, blue2)
            block(cv, 31.5f, 50.5f, 8f, 8f, 2.6f, blue1, blue2)
            block(cv, 45f, 50.5f, 8f, 8f, 2.6f, blue1, blue2)
            block(cv, 58.5f, 50.5f, 8f, 8f, 2.6f, blue1, blue2)
            block(cv, 72f, 50.5f, 8f, 8f, 2.6f, blue1, blue2)
            block(cv, 18f, 64f, 8f, 8f, 2.6f, blue1, blue2)
            solidRound(cv, 30.3f, 62.8f, 10.4f, 10.4f, 3.8f, Color.parseColor("#F2BD42"), 89)
            block(cv, 31.5f, 64f, 8f, 8f, 2.6f, gold1, gold2)
            block(cv, 18f, 77.5f, 8f, 8f, 2.6f, blue1, blue2)
            block(cv, 31.5f, 77.5f, 8f, 8f, 2.6f, blue1, blue2)
            solidCircle(cv, 69f, 78.8f, 18.2f, shad, 71)
            solidCircle(cv, 69f, 77f, 19f, Color.parseColor("#F7FBFF"), 255)
            gradCircle(cv, 69f, 77f, 16.6f, em1, em2)
            ringGold(cv, 69f, 77f, 17.4f, 1.3f, gold1, gold2)
            cv.save(); cv.rotate(-32f, 62.5f, 68.6f); solidRound(cv, 54.5f, 65f, 16f, 7.2f, 3.6f, Color.WHITE, 51); cv.restore()
            run {  // সোনালি চাঁদ (বড় বৃত্ত থেকে ছোট বৃত্ত কাটা)
                val cp = Path()
                cp.arcTo(RectF(57.6f, 67f, 78.8f, 88.2f), -90.2f, -248.18f, true)
                cp.arcTo(RectF(63.8f, 65.8f, 81.4f, 83.4f), 51.7f, 188.03f, false)
                cp.close(); p.shader = grad(gold1, gold2, RectF(57.6f, 67f, 79f, 88f)); cv.drawPath(cp, p); p.shader = null }
            run {  // ছোট ঝিলিক
                val kp = Path(); kp.moveTo(77.6f, 66.6f); kp.rLineTo(1.2f, 2.7f); kp.rLineTo(2.7f, 1.2f); kp.rLineTo(-2.7f, 1.2f); kp.rLineTo(-1.2f, 2.7f); kp.rLineTo(-1.2f, -2.7f); kp.rLineTo(-2.7f, -1.2f); kp.rLineTo(2.7f, -1.2f); kp.close()
                p.shader = grad(gold1, gold2, RectF(74.9f, 66.6f, 81.5f, 73.2f)); cv.drawPath(kp, p); p.shader = null }
            cv.restore()
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    private fun goNav(index: Int) {
        run {
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("nav", index)
            })
        }
        finish()
    }

    private fun buildHeader(): View {
        // v242: সব ফিচারের স্ট্যান্ডার্ড হেডার — আইকন ৫৪, নাম ২০ (বোল্ড), সাবটাইটেল ১৩, বাটন ৪৪; ওপরে ১৪ + স্ট্যাটাস বার, নিচে ১২
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(12), dp(12))
        }
        val logo = ImageView(this).apply {
            setImageDrawable(CalendarMark())
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "ক্যালেন্ডার"
        }
        bar.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(12) })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(tv("ক্যালেন্ডার", 20f, TEXT, true).apply { setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END })
        // তিনটি পঞ্জিকা (ইংরেজি · বাংলা · হিজরি) — একই সাবটাইটেল-স্টাইল
        ht.addView(tv("ইংরেজি · বাংলা · হিজরি পঞ্জিকা", 13f, TEXT3).apply {
            setPadding(0, dp(3), 0, 0); setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
        })
        bar.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        // হেডারের আইকনের নিচে কোনো আকার নয়
        val back = TextView(this).apply {
            text = "✕"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(TEXT)
            contentDescription = "বন্ধ করুন"
            setOnClickListener { finish() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(bar)
        wrap.addView(View(this).apply {
            background = GradientDrawable(Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, GOLD_LINE, Color.TRANSPARENT))
        }, LinearLayout.LayoutParams(-1, dp(1)))
        return wrap
    }

    private fun buildFooter(): View {
        val names = arrayOf("হোম", "নামাজ", "কুরআন", "হাদিস", "আরও")
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(SURF) }
        wrap.addView(View(this).apply { setBackgroundColor(LINE_S) }, LinearLayout.LayoutParams(-1, dp(1)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        names.forEachIndexed { i, n ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(4))
                setOnClickListener { goNav(i) }
            }
            val ic = ImageView(this).apply { setImageDrawable(NavIcon(i, TEXT3, dp(24).toFloat())) }
            item.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(tv(n, 11.5f, TEXT3).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
            row.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        wrap.addView(row)
        return wrap
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        mainScroll = scroll
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(28)) }
        scroll.addView(col)
        val footer = buildFooter()
        root.addView(buildHeader(), LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }

        // ত্রি-পঞ্জিকা (ইংরেজি · বাংলা · হিজরি) ক্যালেন্ডার ও আসন্ন বিশেষ দিন — তারিখ-কার্ড ফিচারের একদম শুরুতে (v211: নামাজ ফিচার থেকে এখানে এসেছে)
        // v245: সবার ওপরে "এক নজরে" (আজকের তারিখ + অ্যালার্ম-তারিখ), তার নিচে মাসিক ক্যালেন্ডার
        col.addView(label("এক নজরে").apply { setPadding(dp(2), dp(10), 0, dp(12)) })
        glanceHolder = FrameLayout(this)
        col.addView(glanceHolder, LinearLayout.LayoutParams(-1, -2))
        calLabel = label("মাসের ক্যালেন্ডার")
        col.addView(calLabel)
        calHolder = FrameLayout(this)
        col.addView(calHolder, LinearLayout.LayoutParams(-1, -2))
        refreshCalendar()
        col.addView(label("আজকের তারিখ-কার্ড"))

        // প্রিভিউ — চারপাশে সরু সোনালি রেখা
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setBackgroundColor(SURF)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(22).toFloat()) }
            }
            foreground = round(22, Color.TRANSPARENT, GOLD_LINE)
            elevation = dp(10).toFloat()
        }
        col.addView(preview, LinearLayout.LayoutParams(-1, 10).apply { topMargin = 0 })
        themeNote = tv("", 13f, TEXT2).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        col.addView(themeNote, LinearLayout.LayoutParams(-1, -2))

        // শেয়ার / সেভ
        val acts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        acts.addView(pill("শেয়ার করুন", true) { shareNow() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(10) })
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            acts.addView(pill("গ্যালারিতে সেভ", false) { saveNow() }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(acts, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // মাপ — দুই ভাগের সেগমেন্ট
        col.addView(label("কার্ডের মাপ"))
        formatRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = round(14, SURF2, LINE); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        col.addView(formatRow, LinearLayout.LayoutParams(-1, -2))

        // থিম — ৩টি করে এক সারিতে
        col.addView(label("থিম বাছুন"))
        themeGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(themeGrid, LinearLayout.LayoutParams(-1, -2))
        themeRow = LinearLayout(this)   // পুরনো রেফারেন্সের জন্য (আর দেখা যায় না)

        // ব্যাকগ্রাউন্ড
        col.addView(label("নিজের ব্যাকগ্রাউন্ড"))
        col.addView(pill("ফোনের গ্যালারি থেকে ছবি বাছুন", false) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }, LinearLayout.LayoutParams(-1, -2))
        photoBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        photoBox.addView(tv("ছবির ওপর কালো পর্দা (লেখা পড়ার সুবিধায়)", 13f, TEXT2).apply { setPadding(dp(2), dp(14), 0, dp(4)) })
        photoBox.addView(SeekBar(this).apply {
            max = 80; progress = prefs.scrim
            progressTintList = ColorStateList.valueOf(PRIMARY); thumbTintList = ColorStateList.valueOf(PRIMARY)
            progressBackgroundTintList = ColorStateList.valueOf(LINE_S)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { prefs.scrim = s?.progress ?: 45; renderPreview() }
            })
        })
        removePhotoBtn = pill("ছবি সরিয়ে থিমের ব্যাকগ্রাউন্ডে ফিরুন", false) { prefs.usePhoto = false; refreshAll() }
        photoBox.addView(removePhotoBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(photoBox)

        // অটো — সব সুইচ একটাই কার্ডে, মাঝে সরু বিভাজক (বক্সের ভেতরে বক্স নয়)
        col.addView(label("স্বয়ংক্রিয়"))
        val sw = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(Orientation.TOP_BOTTOM, intArrayOf(SURF_HI, SURF)).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), LINE) }
        }
        fun divider() = View(this).apply { setBackgroundColor(LINE) }
        fun dlp() = LinearLayout.LayoutParams(-1, dp(1)).apply { leftMargin = dp(16); rightMargin = dp(16) }
        sw.addView(switchRow("প্রতিদিন রাত ১২টায় নিজে তৈরি করুন", prefs.autoDaily) { prefs.autoDaily = it; DateCardScheduler.schedule(this) })
        sw.addView(divider(), dlp())
        sw.addView(switchRow("তৈরি হলে নোটিফিকেশনে দেখান (শব্দ হয় না)", prefs.notify) { prefs.notify = it })
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            sw.addView(divider(), dlp())
            sw.addView(switchRow("প্রতিদিনের কার্ড নিজে গ্যালারিতে সেভ করুন", prefs.saveGallery) { prefs.saveGallery = it })
        }
        col.addView(sw, LinearLayout.LayoutParams(-1, -2))
        col.addView(tv("হিজরি তারিখ অ্যাপের হোম/উইজেটের হিসাব মেনেই আসে।", 12f, TEXT3).apply { setPadding(dp(2), dp(12), 0, 0) })
        return root
    }

    /**
     * ক্যালেন্ডার আঁকা/নতুন করে আঁকা। তারিখ আসে হোমের একই উৎস থেকে, তাই ফায়ারবেসের হিজরি অ্যাডজাস্টমেন্ট/ওভাররাইড মানে;
     * ওই সেটিং বদলালে, মাগরিব/মধ্যরাত পার হলে, বা অ্যাপে ফিরলে নিজে হালনাগাদ হয়।
     */
    private fun refreshCalendar() {
        calSig = HijriCalendarCard.signature(this)
        val pal = HijriCalendarCard.Pal(SURF, SURF_HI, SURF2, LINE, TEXT, TEXT2, TEXT3, PRIMARY, PRESS, ON_PRIMARY, PRIMARY_TEXT, GOLD, GOLD_LINE, GOLD_SOFT, fontBold, fontReg, OK, OK_TEXT, OK_SOFT)
        com.gunjoron.patheyo.calnote.CalNotes.sweep(this)      // v245: মেয়াদ-শেষ নোট আর্কাইভে
        val card = HijriCalendarCard(this, pal, noteHost, calState)
        glanceHolder.removeAllViews(); calHolder.removeAllViews()
        try { glanceHolder.addView(card.buildGlance()) } catch (_: Throwable) {}
        try { calHolder.addView(card.build()) } catch (_: Throwable) {}
    }

    private fun watchHijriPrefs() {
        if (calListener != null) return
        val sp = getSharedPreferences(com.gunjoron.patheyo.widget.PrayerWidgetProvider.PREFS_NAME, MODE_PRIVATE)
        val keys = setOf("last_rtdb_adjustment", "hijri_date_firebase", "hijri_date_firebase_set_on", "hijri_override_active",
            "timings_fetched_on", com.gunjoron.patheyo.widget.PrayerWidgetProvider.KEY_TIMINGS)
        calListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key in keys || (key != null && (key.startsWith("hijri") || key.contains("override")))) ui.post { if (::calHolder.isInitialized && calSig != HijriCalendarCard.signature(this)) refreshCalendar() }
        }
        sp.registerOnSharedPreferenceChangeListener(calListener)
    }

    override fun onResume() {
        super.onResume()
        watchHijriPrefs()
        if (::calHolder.isInitialized) refreshCalendar()
        try { com.gunjoron.patheyo.FirebaseDataManager.syncNow(this) } catch (_: Throwable) {}   // সর্বশেষ অ্যাডজাস্টমেন্ট এনে মিলিয়ে নেয়
        ui.removeCallbacks(calTick); ui.postDelayed(calTick, 30_000L)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(calTick)
    }

    // ------------------------------------------------------------------ অবস্থা অনুযায়ী পুনর্গঠন

    private fun refreshAll() {
        buildFormatChips()
        buildThemeChips()
        photoBox.visibility = if (prefs.usePhoto) View.VISIBLE else View.GONE
        renderPreview()
    }

    private fun segBtn(text: String, selected: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 14f; gravity = Gravity.CENTER; typeface = if (selected) fontBold else fontReg
        setTextColor(if (selected) ON_PRIMARY else TEXT2)
        background = if (selected) GradientDrawable(Orientation.TL_BR, intArrayOf(PRIMARY, PRESS)).apply { cornerRadius = dp(10).toFloat() } else null
        minHeight = dp(40)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { onClick() }
    }

    private fun buildFormatChips() {
        formatRow.removeAllViews()
        formatRow.addView(segBtn("পোস্ট (৪:৫)", prefs.format == "post") { prefs.format = "post"; refreshAll() }, LinearLayout.LayoutParams(0, -2, 1f))
        formatRow.addView(segBtn("স্টোরি (৯:১৬)", prefs.format == "story") { prefs.format = "story"; refreshAll() }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun buildThemeChips() {
        themeGrid.removeAllViews()
        val gap = dp(10)
        val tw = (resources.displayMetrics.widthPixels - dp(32) - gap * 2) / 3
        val th = (tw * (if (prefs.format == "story") 1.5f else 1.25f)).toInt()
        val sel = prefs.theme
        fun cell(title: String, selected: Boolean, onClick: () -> Unit): Pair<View, ImageView> {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setBackgroundColor(SURF2)
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat()) }
                }
                foreground = round(14, Color.TRANSPARENT, if (selected) GOLD else LINE, if (selected) 2 else 1)
            }
            box.addView(iv, LinearLayout.LayoutParams(tw, th))
            box.addView(tv(title, 12f, if (selected) GOLD else TEXT2, selected).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0); maxLines = 2; width = tw })
            box.setOnClickListener { onClick() }
            return Pair(box, iv)
        }
        val cells = ArrayList<View>()
        // "অটো": রয়্যাল ব্লুর ওপর সোনালি তারা
        val (autoBox, autoIv) = cell("অটো (প্রতিদিন নতুন)", sel == "auto") { prefs.theme = "auto"; refreshAll() }
        autoIv.setImageDrawable(android.graphics.drawable.LayerDrawable(arrayOf(
            GradientDrawable(Orientation.TL_BR, intArrayOf(PRIMARY, PRESS)), StarDrawable(GOLD))).apply {
            val inset = tw / 3; setLayerInset(1, inset, (th - (tw - inset * 2)) / 2, inset, (th - (tw - inset * 2)) / 2)
        })
        cells.add(autoBox)
        val info = DateCardRenderer.infoFor(this)
        val holders = HashMap<String, ImageView>()
        DateCardThemes.ALL.forEach { t ->
            val (v, iv) = cell(t.name, sel == t.id) { prefs.theme = t.id; refreshAll() }
            cells.add(v); holders[t.id] = iv
        }
        var row: LinearLayout? = null
        cells.forEachIndexed { i, v ->
            if (i % 3 == 0) { row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; themeGrid.addView(row, LinearLayout.LayoutParams(-1, -2).apply { if (i > 0) topMargin = dp(14) }) }
            row?.addView(v, LinearLayout.LayoutParams(tw, -2).apply { if (i % 3 != 0) leftMargin = gap })
        }
        // থাম্বনেইল পেছনে আঁকা
        val ctx = applicationContext
        val fmt = prefs.format
        worker.execute {
            try {
                DateCardThemes.ALL.forEach { t ->
                    val b = DateCardRenderer.render(ctx, info, t, fmt, null, 0, 300)
                    ui.post { holders[t.id]?.setImageBitmap(b) }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun renderPreview() {
        val my = ++token
        val w = resources.displayMetrics.widthPixels - dp(32)
        val ratio = DateCardRenderer.ratio(prefs.format)
        preview.layoutParams = (preview.layoutParams as LinearLayout.LayoutParams).apply { width = -1; height = (w * ratio).toInt() }
        val ctx = applicationContext
        worker.execute {
            try {
                val now = System.currentTimeMillis()
                val bmp = DateCardRenderer.renderFor(ctx, now, prefs, 1080)
                val info = DateCardRenderer.infoFor(ctx, now)
                val name = if (prefs.usePhoto) "আপনার ছবি" else DateCardThemes.forDay(prefs.theme, info.dayOfYear, info.year).name
                ui.post {
                    if (my != token || isFinishing) return@post
                    current = bmp
                    preview.setImageBitmap(bmp)
                    themeNote.text = (if (prefs.usePhoto) "ব্যাকগ্রাউন্ড: " else if (prefs.theme == "auto") "আজকের থিম (অটো): " else "থিম: ") + name
                    if (wantShare) { wantShare = false; shareNow() }
                }
            } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------ ছবি বাছাই

    private fun importPhoto(uri: Uri) {
        val ctx = applicationContext
        worker.execute {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: throw IllegalStateException()
                val deg = try {
                    contentResolver.openInputStream(uri)?.use {
                        when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                } catch (_: Throwable) { 0f }
                if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
                DateCardPrefs(ctx).photoFile().outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                bmp.recycle()
                ui.post { prefs.usePhoto = true; refreshAll() }
            } catch (_: Throwable) {
                ui.post { Toast.makeText(this, "ছবিটি খোলা যায়নি, অন্য ছবি বাছুন", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    // ------------------------------------------------------------------ শেয়ার / সেভ

    private fun shareNow() {
        val bmp = current ?: run { Toast.makeText(this, "কার্ড তৈরি হচ্ছে, একটু অপেক্ষা করুন", Toast.LENGTH_SHORT).show(); return }
        val uri = DateCardGenerator.shareUri(this, bmp) ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(send, "শেয়ার করুন").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) {}
    }

    private fun saveNow() {
        val bmp = current ?: return
        val ok = DateCardGenerator.saveToGallery(this, bmp, "patheyo_datecard_" + System.currentTimeMillis())
        Toast.makeText(this, if (ok) "গ্যালারির Pictures/Patheyo ফোল্ডারে সেভ হয়েছে" else "সেভ করা যায়নি", Toast.LENGTH_SHORT).show()
    }
}
