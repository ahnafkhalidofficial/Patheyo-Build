package com.gunjoron.patheyo.ui

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * ✅ v265: সেটিংসের ফুটারে অ্যাপের সংস্করণ — সরাসরি ইনস্টল হওয়া অ্যাপ থেকে পড়া হয়
 * (মান আসে app/build.gradle.kts-এর versionName থেকে), তাই ওখানে সংস্করণ বদলালেই এখানে নিজে থেকে বদলায়।
 * JS-এ নাম: PatheyoAppInfo (MainActivity-তে রেজিস্টার করা)।
 */
class AppInfoBridge(private val ctx: Context) {
    @JavascriptInterface
    fun getVersionName(): String =
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Throwable) { "" }
}
