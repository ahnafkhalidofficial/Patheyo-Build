package com.gunjoron.patheyo.notification

// v151: ওয়েবভিউ (ঘণ্টা পেজ) <-> NotificationInbox সংযোগ। JS-এ নাম: window.PatheyoInbox
// সব মেথড দ্রুত (SharedPreferences) — এবং কোনো কারণে ব্যর্থ হলে ক্র্যাশ নয়, ফাঁকা ফল।

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import androidx.appcompat.app.AppCompatActivity
import com.gunjoron.patheyo.update.UpdateManager

class NotificationInboxBridge(private val activity: AppCompatActivity) {

    private val ctx: Context get() = activity.applicationContext

    /** সব নোটিফিকেশন, JSON অ্যারে: [{id,title,text,link,kind,ver,ts,read}] — নতুনটা আগে */
    @JavascriptInterface
    fun getAll(): String = try { NotificationInbox.allJson(ctx) } catch (_: Throwable) { "[]" }

    /** অপঠিত সংখ্যা (লাল ব্যাজ) */
    @JavascriptInterface
    fun unreadCount(): Int = try { NotificationInbox.unreadCount(ctx) } catch (_: Throwable) { 0 }

    /** ইউজার এই একটাতে ট্যাপ করেছে → শুধু এটি পঠিত। ফেরত: নতুন অপঠিত সংখ্যা */
    @JavascriptInterface
    fun markRead(id: String?): Int {
        try { if (!id.isNullOrBlank()) NotificationInbox.markRead(ctx, id) } catch (_: Throwable) {}
        return unreadCount()
    }

    /** নোটিফিকেশনের লিংক (শুধু http/https) ব্রাউজারে খোলে */
    @JavascriptInterface
    fun openLink(url: String?) {
        val u = url?.trim().orEmpty()
        if (!(u.startsWith("https://") || u.startsWith("http://"))) return
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {}
        }
    }

    /** আপডেট-নোটিফিকেশনে ট্যাপ → আপডেট চেক করে পপআপ দেখায় */
    @JavascriptInterface
    fun openUpdate() {
        activity.runOnUiThread {
            try { if (!activity.isFinishing && !activity.isDestroyed) UpdateManager.checkNow(activity) } catch (_: Throwable) {}
        }
    }
}
