package com.gunjoron.patheyo.audio

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * কুরআন পেজের (WebView) জন্য নেটিভ অডিও ব্রিজ — JS-এ নাম: PatheyoQuranAudio।
 *
 * ▸ প্লেয়ার (ব্যাকগ্রাউন্ড সার্ভিস):
 *     isAvailable, load(itemsJson, startQi, repeat, speed, reciterName), toggle, play, pause, next, prev,
 *     seekTo(ms), setSpeed(x), setRepeat(mode), setSleep(min), stop, getState()
 *     ইভেন্ট: window.__quranAudioEvent({k:'st'|'pos'|'ended'|'error'|'sleep'|'dl', ...})
 * ▸ অফলাইন সূরা অডিও:
 *     dlStart(folder, sura, filesJson), dlCancel(), dlCancelSura(folder, sura), dlDelete(folder, sura), dlDeleteAll(),
 *     dlStatus(), dlList(), dlHas(folder, sura)
 *
 * JS-এর কল আসে ওয়েবভিউয়ের ব্যাকগ্রাউন্ড থ্রেডে, তাই প্লেয়ারের সব কাজ প্রধান থ্রেডে পোস্ট করা হয়।
 */
class QuranAudioBridge(context: Context, private val webView: WebView) {

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private val push: (String) -> Unit = { js -> main.post { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} } }

    init {
        QuranAudioEngine.sink = push
        QuranAudioStore.sink = push
    }

    /** অ্যাক্টিভিটি ধ্বংস হলে ধ্বংস-হওয়া ওয়েবভিউকে আর JS না পাঠানো (সার্ভিস কিন্তু চলতে থাকে) */
    fun detach() {
        if (QuranAudioEngine.sink === push) QuranAudioEngine.sink = null
        if (QuranAudioStore.sink === push) QuranAudioStore.sink = null
    }

    @JavascriptInterface fun isAvailable(): Boolean = true

    @JavascriptInterface fun load(itemsJson: String, startQi: Int, repeat: String, speed: Float, reciterName: String) {
        main.post { QuranAudioEngine.load(app, itemsJson, startQi, repeat, speed, reciterName) }
    }
    @JavascriptInterface fun toggle() { main.post { QuranAudioEngine.toggle(app) } }
    @JavascriptInterface fun play() { main.post { QuranAudioEngine.play(app) } }
    @JavascriptInterface fun pause() { main.post { QuranAudioEngine.pause(app) } }
    @JavascriptInterface fun next() { main.post { QuranAudioEngine.next(app) } }
    @JavascriptInterface fun prev() { main.post { QuranAudioEngine.prev(app) } }
    @JavascriptInterface fun seekTo(ms: Double) { main.post { QuranAudioEngine.seekTo(app, ms.toLong()) } }
    @JavascriptInterface fun setSpeed(x: Float) { main.post { QuranAudioEngine.setSpeed(app, x) } }
    @JavascriptInterface fun setRepeat(mode: String) { main.post { QuranAudioEngine.setRepeat(app, mode) } }
    @JavascriptInterface fun setSleep(min: Int) { main.post { QuranAudioEngine.setSleep(app, min) } }
    @JavascriptInterface fun stop() { main.post { QuranAudioEngine.stop(app) } }
    @JavascriptInterface fun getState(): String = QuranAudioEngine.lastState

    // ---- অফলাইন ----
    @JavascriptInterface fun dlStart(folder: String, sura: Int, filesJson: String) { QuranAudioStore.start(app, folder, sura, filesJson) }
    @JavascriptInterface fun dlCancel() { QuranAudioStore.cancel() }
    @JavascriptInterface fun dlCancelSura(folder: String, sura: Int) { QuranAudioStore.cancelSura(folder, sura) }
    @JavascriptInterface fun dlDelete(folder: String, sura: Int) { Thread { QuranAudioStore.delete(app, folder, sura) }.start() }
    @JavascriptInterface fun dlDeleteAll() { Thread { QuranAudioStore.deleteAll(app) }.start() }
    @JavascriptInterface fun dlStatus(): String = QuranAudioStore.statusJson()
    @JavascriptInterface fun dlList(): String = QuranAudioStore.listJson(app)
    @JavascriptInterface fun dlHas(folder: String, sura: Int): Boolean = QuranAudioStore.isComplete(app, folder, sura)
}
