package com.gunjoron.patheyo.premium

import android.app.Activity
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams

/**
 * ধাপ ১০ — Google Play Billing (শুধু BuildConfig.DISTRIBUTION == "play" হলে তৈরি হয়; GitHub সংস্করণে কখনো চলে না)
 *
 * Play Console-এ যে প্রোডাক্ট বানাতে হবে (docs/PREMIUM_SETUP.md):
 *   সাবস্ক্রিপশন  patheyo_premium  — বেস-প্ল্যান  monthly (৳৪৯)  ও  yearly (৳৩৯৯)
 *   এককালীন      patheyo_lifetime  (৳৯৯৯)
 * কেনা হলে টোকেন আমাদের সার্ভারে যাচাই হয় (verify), সার্ভার অ্যাকাউন্টে premium লেখে, তারপর এখানে acknowledge।
 */
class PlayBilling(
    private val activity: Activity,
    private val verify: (productId: String, token: String, done: (Boolean) -> Unit) -> Unit
) : PurchasesUpdatedListener {

    private var pending: ((String, String) -> Unit)? = null
    private val client: BillingClient = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    private fun ready(run: () -> Unit, onFail: () -> Unit) {
        if (client.isReady) { run(); return }
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(r: BillingResult) { if (r.responseCode == BillingClient.BillingResponseCode.OK) run() else onFail() }
            override fun onBillingServiceDisconnected() {}
        })
    }

    fun buy(plan: String, done: (String, String) -> Unit) {
        val lifetime = plan == "lifetime"
        val productId = if (lifetime) LIFETIME else SUBS
        val type = if (lifetime) BillingClient.ProductType.INAPP else BillingClient.ProductType.SUBS
        ready({
            val q = QueryProductDetailsParams.newBuilder().setProductList(listOf(
                QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(type).build())).build()
            client.queryProductDetailsAsync(q) { r, list ->
                val pd: ProductDetails? = list.firstOrNull()
                if (r.responseCode != BillingClient.BillingResponseCode.OK || pd == null) { done("store", "Play Store-এ প্রোডাক্ট পাওয়া যায়নি।"); return@queryProductDetailsAsync }
                val pp = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd)
                if (!lifetime) {
                    val offer = pd.subscriptionOfferDetails?.firstOrNull { it.basePlanId == plan } ?: pd.subscriptionOfferDetails?.firstOrNull()
                    if (offer == null) { done("store", "প্ল্যান পাওয়া যায়নি।"); return@queryProductDetailsAsync }
                    pp.setOfferToken(offer.offerToken)
                }
                pending = done
                activity.runOnUiThread {
                    client.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(pp.build())).build())
                }
            }
        }, { done("store", "Play Store-এর সাথে যুক্ত হওয়া যায়নি।") })
    }

    override fun onPurchasesUpdated(r: BillingResult, purchases: MutableList<Purchase>?) {
        val cb = pending; pending = null
        when (r.responseCode) {
            BillingClient.BillingResponseCode.OK -> purchases?.forEach { handle(it, cb) } ?: cb?.invoke("store", "কেনা সম্পন্ন হয়নি।")
            BillingClient.BillingResponseCode.USER_CANCELED -> cb?.invoke("cancel", "")
            else -> cb?.invoke("store", "কেনা সম্পন্ন হয়নি। আবার চেষ্টা করুন।")
        }
    }

    private fun handle(p: Purchase, cb: ((String, String) -> Unit)?) {
        if (p.purchaseState != Purchase.PurchaseState.PURCHASED) { cb?.invoke("pending", "পেমেন্ট প্রক্রিয়াধীন — সম্পন্ন হলে প্রিমিয়াম নিজে চালু হবে।"); return }
        val pid = p.products.firstOrNull() ?: return
        verify(pid, p.purchaseToken) { good ->
            if (good && !p.isAcknowledged) {
                client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) {}
            }
            cb?.invoke(if (good) "ok" else "verify", if (good) "" else "যাচাই করা যায়নি — একটু পরে \"রিস্টোর\" চাপুন।")
        }
    }

    /** আগের কেনাগুলো আবার যাচাই (নতুন ফোন / রিস্টোর) */
    fun restore() {
        ready({
            listOf(BillingClient.ProductType.SUBS, BillingClient.ProductType.INAPP).forEach { t ->
                client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(t).build()) { r, list ->
                    if (r.responseCode == BillingClient.BillingResponseCode.OK) list.forEach { handle(it, null) }
                }
            }
        }, {})
    }

    companion object {
        const val SUBS = "patheyo_premium"
        const val LIFETIME = "patheyo_lifetime"
    }
}
