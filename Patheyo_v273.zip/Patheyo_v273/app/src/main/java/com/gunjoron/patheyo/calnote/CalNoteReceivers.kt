package com.gunjoron.patheyo.calnote

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager

/** v244: নোটের নির্ধারিত সময় হলে AlarmManager এখানে ডাকে (অ্যাপ বন্ধ থাকলেও) */
class CalNoteReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(CalNotes.EXTRA_ID, -1)
        if (id < 0) return
        // সার্ভিস চালু হওয়া পর্যন্ত CPU জাগিয়ে রাখা (সর্বোচ্চ ২০ সেকেন্ড, নিজে ছেড়ে দেয়)
        try {
            val pm = context.applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Patheyo:CalNote")?.acquire(20_000L)
        } catch (_: Throwable) {}
        try { CalNotes.fire(context, id) } catch (_: Throwable) {}
    }
}

/** অ্যালার্মের নোটিফিকেশনের "বন্ধ করুন" / "৫ মিনিট পরে" বাটন */
class CalNoteActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(CalNotes.EXTRA_ID, -1)
        val snooze = intent.action == CalNoteAlarmService.ACTION_SNOOZE
        CalNoteAlarmService.dismiss(context, id, snooze)
    }
}
