package com.gunjoron.patheyo.datecard

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * প্রতিদিন রাত ১২টায় (০০:০০:০৫) কার্ড তৈরির অ্যালার্ম।
 * একবারের অ্যালার্ম — বাজলে [DateCardReceiver] কার্ড বানিয়ে নিজেই পরের রাতের জন্য আবার বসায়।
 * অ্যাপ চালু হলে / রিবুট / সময় বদলালে আবার বসানো হয় (PatheyoApp, BootCompletedReceiver, WidgetSystemEventReceiver)।
 */
object DateCardScheduler {
    private const val REQ = 9410
    const val ACTION = "com.gunjoron.patheyo.DATE_CARD"

    fun nextMidnight(now: Long = System.currentTimeMillis()): Long =
        Calendar.getInstance().apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 5); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    private fun pi(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, REQ, Intent(ctx, DateCardReceiver::class.java).setAction(ACTION),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(context: Context) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        if (!DateCardPrefs(ctx).autoDaily) { try { am.cancel(pi(ctx)) } catch (_: Throwable) {}; return }
        val at = nextMidnight()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx))
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx))
            }
        } catch (_: Throwable) {
            try { am.set(AlarmManager.RTC_WAKEUP, at, pi(ctx)) } catch (_: Throwable) {}
        }
    }

    fun cancel(context: Context) {
        val ctx = context.applicationContext
        try { (ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager)?.cancel(pi(ctx)) } catch (_: Throwable) {}
    }
}

class DateCardReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        val pending = try { goAsync() } catch (_: Throwable) { null }
        val job = Runnable {
            try {
                // আগে পরের রাতের অ্যালার্ম — কার্ড বানাতে সমস্যা হলেও চেইন যেন না ভাঙে
                DateCardScheduler.schedule(ctx)
                if (DateCardPrefs(ctx).autoDaily) DateCardGenerator.generate(ctx)
            } catch (_: Throwable) {
            } finally { try { pending?.finish() } catch (_: Throwable) {} }
        }
        if (pending != null) try { Thread(job, "patheyo-datecard").start() } catch (_: Throwable) { job.run() } else job.run()
    }
}
