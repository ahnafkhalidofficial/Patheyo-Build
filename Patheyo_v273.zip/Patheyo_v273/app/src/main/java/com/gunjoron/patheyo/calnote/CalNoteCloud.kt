package com.gunjoron.patheyo.calnote

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.gunjoron.patheyo.sync.NativeSync

/**
 * v247: নোট ও আর্কাইভ এখন অ্যাপের একই ক্লাউড-সিঙ্কে (Supabase user_backups) যায় — sync/NativeSync.kt।
 * (v245-এ আর্কাইভ আলাদাভাবে Firebase Realtime Database-এ যেত; সেই পথ বন্ধ — তাই Firebase-এ এর জন্য আর কোনো রুল লাগে না।)
 * এই অবজেক্ট এখন শুধু "সাইন-ইন আছে কি না" বলে ও পুরনো ডাকগুলো সিঙ্ক-তাগাদায় বদলে দেয়।
 */
object CalNoteCloud {
    fun isLoggedIn(): Boolean = try { FirebaseAuth.getInstance().currentUser != null } catch (_: Throwable) { false }

    /** নোট/আর্কাইভ বদলেছে — অ্যাপ খোলা থাকলে দেড় সেকেন্ডে ক্লাউডে যায়; নইলে পরের বার অ্যাপ খুললে */
    @Suppress("UNUSED_PARAMETER")
    fun push(ctx: Context) { NativeSync.nudge() }

    /** আগের পথের জায়গা — এখন ক্লাউড থেকে আনা অ্যাপের মূল সিঙ্কই করে, তাই এখানে বদলানোর কিছু নেই */
    @Suppress("UNUSED_PARAMETER")
    fun pull(ctx: Context, onDone: (Boolean) -> Unit) { onDone(false) }
}
