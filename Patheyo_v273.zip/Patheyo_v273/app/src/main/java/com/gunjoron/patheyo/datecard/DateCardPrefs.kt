package com.gunjoron.patheyo.datecard

import android.content.Context
import android.content.SharedPreferences
import java.io.File

/**
 * প্রতিদিনের তারিখ-কার্ডের সেটিংস (SharedPreferences "patheyo_datecard")।
 *  • autoDaily   — প্রতি রাত ১২টায় নিজে তৈরি (ডিফল্ট চালু)
 *  • notify      — তৈরি হলে নীরব নোটিফিকেশনে কার্ড দেখানো (ডিফল্ট চালু)
 *  • saveGallery — তৈরি হলে নিজে গ্যালারির Pictures/Patheyo-তে সেভ (ডিফল্ট বন্ধ; Android 10+)
 *  • theme       — "auto" (প্রতিদিন আলাদা থিম) বা কোনো থিমের id
 *  • format      — "post" (৪:৫) | "story" (৯:১৬)
 *  • usePhoto    — true হলে ফোন থেকে বাছা ছবি ব্যাকগ্রাউন্ড (ছবি filesDir/datecard/bg.jpg)
 *  • scrim       — ছবির ওপর কালো পর্দার ঘনত্ব, ০–৮০ (%)
 */
class DateCardPrefs(ctx: Context) {
    private val app = ctx.applicationContext
    private val sp: SharedPreferences = app.getSharedPreferences("patheyo_datecard", Context.MODE_PRIVATE)

    var autoDaily: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) { sp.edit().putBoolean("auto", v).apply() }
    var notify: Boolean
        get() = sp.getBoolean("notify", true)
        set(v) { sp.edit().putBoolean("notify", v).apply() }
    var saveGallery: Boolean
        get() = sp.getBoolean("gallery", false)
        set(v) { sp.edit().putBoolean("gallery", v).apply() }
    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) { sp.edit().putString("theme", v).apply() }
    var format: String
        get() = sp.getString("format", "post") ?: "post"
        set(v) { sp.edit().putString("format", v).apply() }
    var usePhoto: Boolean
        get() = sp.getBoolean("photo", false) && photoFile().isFile
        set(v) { sp.edit().putBoolean("photo", v).apply() }
    var scrim: Int
        get() = sp.getInt("scrim", 45).coerceIn(0, 80)
        set(v) { sp.edit().putInt("scrim", v.coerceIn(0, 80)).apply() }

    fun dir(): File = File(app.filesDir, "datecard").apply { mkdirs() }
    fun photoFile(): File = File(dir(), "bg.jpg")
}
