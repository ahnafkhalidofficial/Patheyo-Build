package com.gunjoron.patheyo.audio

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray
import org.json.JSONObject

/**
 * কুরআন তিলাওয়াতের নেটিভ ইঞ্জিন — প্লে-লিস্ট, রিপিট, গতি, ঘুমের টাইমার।
 * পুরোটাই প্রধান থ্রেডে (Handler) চলে; ওয়েবভিউ (JS) [QuranAudioBridge] দিয়ে এটাকে ডাকে।
 * ইঞ্জিনের আয়ু অ্যাক্টিভিটির চেয়ে বড় — অ্যাপ ব্যাকগ্রাউন্ডে গেলে বা স্ক্রিন বন্ধ হলেও [QuranPlaybackService] তিলাওয়াত চালিয়ে যায়,
 * আর অ্যাপ আবার খুললে JS [stateJson] দিয়ে অবস্থা ফিরে পায়।
 *
 * প্লে-লিস্টের আইটেম: mediaId = "<আয়াত-সূচক qi>:<বার>"। রিপিট "আয়াত ২/৩/৫ বার" হলে প্রতিটা আয়াত ঐ কয়বার প্লে-লিস্টে বসে
 * (বিসমিল্লাহ বাদে); "আয়াত ∞" = REPEAT_MODE_ONE, "পুরো সূরা ∞" = REPEAT_MODE_ALL।
 *
 * JS-এ ইভেন্ট: window.__quranAudioEvent({k:'st'|'pos'|'ended'|'error'|'sleep', ...}) (shell/js/06-native-bridge.js → কুরআন ফ্রেম)।
 */
object QuranAudioEngine {

    class Item(val url: String, val folder: String, val file: String, val title: String, val sub: String, val repeatable: Boolean)

    private val main = Handler(Looper.getMainLooper())

    @Volatile var sink: ((String) -> Unit)? = null
    @Volatile var lastState: String = "{\"has\":false}"; private set

    private var appCtx: Context? = null
    private var future: ListenableFuture<MediaController>? = null
    private var mc: MediaController? = null
    private val waiting = ArrayList<(MediaController) -> Unit>()

    private var items: List<Item> = emptyList()
    private var repeat = "off"
    private var speed = 1f
    private var reciter = ""
    private var retried = false

    private var sleepAt = 0L
    private var sleepMin = 0
    private val sleepRun = Runnable {
        sleepAt = 0L; sleepMin = 0
        mc?.pause()
        emit(JSONObject().put("k", "sleep").put("done", true))
        publish()
    }

    // ------------------------------------------------------------------ কন্ট্রোলার সংযোগ

    private fun withController(ctx: Context, block: (MediaController) -> Unit) {
        val app = ctx.applicationContext
        appCtx = app
        val c = mc
        if (c != null && c.isConnected) { block(c); return }
        waiting.add(block)
        if (future != null) return
        try {
            val token = SessionToken(app, ComponentName(app, QuranPlaybackService::class.java))
            val f = MediaController.Builder(app, token).buildAsync()
            future = f
            f.addListener({
                try {
                    val ctrl = f.get()
                    mc = ctrl
                    ctrl.addListener(listener)
                    val run = ArrayList(waiting); waiting.clear()
                    run.forEach { try { it(ctrl) } catch (_: Throwable) {} }
                    publish()
                } catch (_: Throwable) {
                    future = null; mc = null; waiting.clear()
                    emit(JSONObject().put("k", "error").put("code", "service"))
                }
            }, ContextCompat.getMainExecutor(app))
        } catch (_: Throwable) {
            future = null; waiting.clear()
            emit(JSONObject().put("k", "error").put("code", "service"))
        }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { publish(); if (isPlaying) { retried = false; ticker() } }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = publish()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { retried = false; publish() }
        override fun onPlaybackStateChanged(playbackState: Int) {
            publish()
            if (playbackState == Player.STATE_ENDED) emit(JSONObject().put("k", "ended"))
        }
        override fun onPlayerError(error: PlaybackException) {
            val c = mc ?: return
            if (!retried) { retried = true; main.postDelayed({ try { c.prepare(); c.play() } catch (_: Throwable) {} }, 600) }
            else emit(JSONObject().put("k", "error").put("code", "play"))
        }
    }

    // ------------------------------------------------------------------ প্লে-লিস্ট

    private fun repeatTimes(): Int = when (repeat) { "a2" -> 2; "a3" -> 3; "a5" -> 5; else -> 1 }
    private fun repeatMode(): Int = when (repeat) { "ainf" -> Player.REPEAT_MODE_ONE; "sinf" -> Player.REPEAT_MODE_ALL; else -> Player.REPEAT_MODE_OFF }

    private fun uriOf(ctx: Context, it: Item): Uri {
        val local = QuranAudioStore.localFile(ctx, it.folder, it.file)
        return if (local != null) Uri.fromFile(local) else Uri.parse(it.url)
    }

    /** (মিডিয়া-আইটেম তালিকা, প্রতিটা qi-র প্রথম কপির সূচক) */
    private fun build(ctx: Context): Pair<List<MediaItem>, IntArray> {
        val list = ArrayList<MediaItem>()
        val first = IntArray(items.size)
        val n = repeatTimes()
        for ((qi, it) in items.withIndex()) {
            first[qi] = list.size
            val times = if (it.repeatable) n else 1
            val uri = uriOf(ctx, it)
            for (r in 0 until times) {
                list.add(
                    MediaItem.Builder()
                        .setMediaId("$qi:$r")
                        .setUri(uri)
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(it.title)
                                .setArtist(if (it.sub.isNotEmpty()) it.sub + " · " + reciter else reciter)
                                .setAlbumTitle("কুরআন তিলাওয়াত")
                                .build()
                        )
                        .build()
                )
            }
        }
        return Pair(list, first)
    }

    private fun qiOf(c: MediaController): Int =
        c.currentMediaItem?.mediaId?.substringBefore(':')?.toIntOrNull() ?: -1

    private fun repOf(c: MediaController): Int =
        c.currentMediaItem?.mediaId?.substringAfter(':', "0")?.toIntOrNull() ?: 0

    // ------------------------------------------------------------------ JS থেকে আসা কাজ (প্রধান থ্রেডে)

    fun load(ctx: Context, itemsJson: String, startQi: Int, repeat: String, speed: Float, reciterName: String) {
        val parsed = ArrayList<Item>()
        try {
            val a = JSONArray(itemsJson)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                parsed.add(Item(o.optString("u"), o.optString("f"), o.optString("n"), o.optString("t"), o.optString("s"), o.optBoolean("r", true)))
            }
        } catch (_: Throwable) { return }
        if (parsed.isEmpty()) return
        items = parsed
        this.repeat = repeat
        this.speed = if (speed in 0.5f..2.5f) speed else 1f
        reciter = reciterName
        retried = false
        withController(ctx) { c ->
            val (list, first) = build(ctx)
            val qi = startQi.coerceIn(0, items.size - 1)
            c.setMediaItems(list, first[qi], 0L)
            c.repeatMode = repeatMode()
            c.playbackParameters = PlaybackParameters(this.speed, 1f)
            c.prepare()
            c.play()
        }
    }

    fun toggle(ctx: Context) = withController(ctx) { c ->
        if (c.mediaItemCount == 0) return@withController
        if (c.playbackState == Player.STATE_ENDED) { c.seekTo(0, 0L); c.play() }
        else if (c.isPlaying || c.playWhenReady) c.pause() else c.play()
    }

    fun play(ctx: Context) = withController(ctx) { if (it.mediaItemCount > 0) it.play() }
    fun pause(ctx: Context) = withController(ctx) { it.pause() }
    fun next(ctx: Context) = withController(ctx) { if (it.mediaItemCount > 0) it.seekToNext() }
    fun prev(ctx: Context) = withController(ctx) { if (it.mediaItemCount > 0) it.seekToPrevious() }
    fun seekTo(ctx: Context, ms: Long) = withController(ctx) { if (it.mediaItemCount > 0) it.seekTo(ms.coerceAtLeast(0L)) }

    fun setSpeed(ctx: Context, v: Float) {
        speed = if (v in 0.5f..2.5f) v else 1f
        withController(ctx) { it.playbackParameters = PlaybackParameters(speed, 1f) }
    }

    /** রিপিট বদলালে প্লে-লিস্ট নতুন করে সাজানো হয় (চলতি আয়াত ও জায়গা ঠিক রেখে) */
    fun setRepeat(ctx: Context, mode: String) {
        repeat = mode
        withController(ctx) { c ->
            if (c.mediaItemCount == 0 || items.isEmpty()) { c.repeatMode = repeatMode(); return@withController }
            val qi = qiOf(c).coerceIn(0, items.size - 1)
            val pos = c.currentPosition
            val wasPlaying = c.playWhenReady
            val (list, first) = build(ctx)
            c.setMediaItems(list, first[qi], pos)
            c.repeatMode = repeatMode()
            c.prepare()
            if (wasPlaying) c.play()
        }
    }

    fun setSleep(ctx: Context, minutes: Int) {
        main.removeCallbacks(sleepRun)
        sleepMin = minutes.coerceAtLeast(0)
        sleepAt = if (sleepMin > 0) System.currentTimeMillis() + sleepMin * 60_000L else 0L
        if (sleepMin > 0) main.postDelayed(sleepRun, sleepMin * 60_000L)
        publish()
    }

    fun stop(ctx: Context) {
        main.removeCallbacks(sleepRun); sleepAt = 0L; sleepMin = 0
        val c = mc
        if (c != null) {
            try { c.stop(); c.clearMediaItems() } catch (_: Throwable) {}
            try { future?.let { MediaController.releaseFuture(it) } } catch (_: Throwable) {}
        }
        mc = null; future = null; waiting.clear(); items = emptyList()
        lastState = "{\"has\":false}"
        emit(JSONObject().put("k", "st").put("has", false).put("playing", false))
    }

    // ------------------------------------------------------------------ JS-কে অবস্থা পাঠানো

    private fun stateObj(): JSONObject {
        val c = mc
        val o = JSONObject().put("k", "st")
        if (c == null || c.mediaItemCount == 0) return o.put("has", false).put("playing", false)
        val st = c.playbackState
        o.put("has", true)
            .put("playing", c.playWhenReady && st != Player.STATE_ENDED && st != Player.STATE_IDLE)
            .put("buffering", st == Player.STATE_BUFFERING)
            .put("ended", st == Player.STATE_ENDED)
            .put("qi", qiOf(c))
            .put("rep", repOf(c))
            .put("pos", c.currentPosition)
            .put("dur", if (c.duration > 0) c.duration else 0L)
            .put("sleepLeft", if (sleepAt > 0L) ((sleepAt - System.currentTimeMillis() + 59_999L) / 60_000L).coerceAtLeast(0L) else 0L)
        return o
    }

    private fun publish() {
        val o = stateObj()
        lastState = o.toString()
        emit(o)
    }

    private fun emit(o: JSONObject) {
        val s = sink ?: return
        s("window.__quranAudioEvent&&window.__quranAudioEvent(" + o.toString() + ");")
    }

    private var ticking = false
    private fun ticker() {
        if (ticking) return
        ticking = true
        main.post(object : Runnable {
            override fun run() {
                val c = mc
                if (c == null || !c.isPlaying) { ticking = false; return }
                if (sink != null) {
                    emit(JSONObject().put("k", "pos").put("pos", c.currentPosition).put("dur", if (c.duration > 0) c.duration else 0L))
                }
                lastState = stateObj().toString()
                main.postDelayed(this, 500L)
            }
        })
    }
}
