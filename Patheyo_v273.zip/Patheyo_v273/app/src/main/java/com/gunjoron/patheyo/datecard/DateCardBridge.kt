package com.gunjoron.patheyo.datecard

import android.app.Activity
import android.content.Intent
import android.webkit.JavascriptInterface

/** হোমের "তারিখ-কার্ড" টাইল থেকে নেটিভ স্ক্রিন খোলে — JS-এ নাম: PatheyoDateCard */
class DateCardBridge(private val activity: Activity) {
    @JavascriptInterface
    fun open() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(activity, DateCardActivity::class.java))
                // v240: সিস্টেমের ডিফল্ট ট্রানজিশন নয় — অ্যাপের ভেতরের পেজের মতো নরম প্রবেশ, নিচের স্ক্রিন স্থির
                @Suppress("DEPRECATION")
                activity.overridePendingTransition(com.gunjoron.patheyo.R.anim.pt_page_enter, com.gunjoron.patheyo.R.anim.pt_page_hold)
            } catch (_: Throwable) {}
        }
    }
}
