package com.gunjoron.patheyo

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * v27: ওয়েবসাইটের লোডিং-পেজের (#splash) হুবহু নেটিভ রূপ।
 *  - রেডিয়াল গ্লো ব্যাকগ্রাউন্ড (লাইট: সাদা, ডার্ক: #06101f) — সিস্টেম থিম অনুযায়ী
 *  - ৯৬dp গোল লোগো + ঘূর্ণায়মান লাল→নীল রিং (conic gradient)
 *  - বড় "পাথেয়" (Gunjoron-Font Bold, clamp(64px, 19vw, 99.2px))
 *  - ট্যাগলাইন শব্দ ধরে ধরে ব্লার-ইন (এক লাইনে — ফোনের প্রস্থ অনুযায়ী ফন্ট ছোট হয়ে ফিট করে)
 *  - নিচে "from Gunjoron" (Plus Jakarta Sans Light, লেটার-স্পেসড)
 *  - কমপক্ষে ২.৩ সেকেন্ড, পেজ লোড না হলেও সর্বোচ্চ ৩.৪ সেকেন্ডে ফেড-আউট + হালকা স্কেল-আপ
 */
class SplashView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs) {

    private val d = resources.displayMetrics.density
    /* ধাপ ৮: অ্যাপ শেষবার যে থিমে ছিল (ডার্ক/লাইট) সেটিই — সিস্টেম থিম শুধু প্রথমবার; তাই খোলার সময় রং লাফায় না */
    private val dark = SystemBarsBridge.savedLight(ctx)?.not()
        ?: ((resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
    /* v2 (ধাপ ২): ওয়েব স্প্ল্যাশ (shell/css/04-splash.css) ও ডিজাইন সিস্টেমের --pt-bg / --pt-text-এর সাথে হুবহু — খোলার সময় রং লাফায় না */
    private val ink = if (dark) 0xFFF1F4F9.toInt() else 0xFF111827.toInt()
    private val baseBg = if (dark) 0xFF111827.toInt() else 0xFFF4F6FA.toInt()
    private val glow = if (dark) 0x384169E1 else 0x214169E1

    private val handler = Handler(Looper.getMainLooper())
    private var t0 = 0L
    private var started = false
    private var pageLoaded = false
    private var ending = false
    private var spin: ValueAnimator? = null
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private lateinit var topBox: View
    private lateinit var title: View
    private lateinit var words: List<TextView>
    private lateinit var footer: View
    private lateinit var ring: RingView

    private val easeOutPop = PathInterpolator(0.2f, 0.9f, 0.3f, 1.2f)
    private val easeRise = PathInterpolator(0.2f, 0.8f, 0.3f, 1f)
    private val cssEase = PathInterpolator(0.25f, 0.1f, 0.25f, 1f)

    init {
        setWillNotDraw(false)
        isClickable = true
        isFocusable = true
        clipChildren = false
        clipToPadding = false
        setBackgroundColor(baseBg)
        buildContent()
        // নতুন HTML-এর নিজস্ব স্প্ল্যাশ আছে: নেটিভ স্প্ল্যাশ এখন শুধু লোড হওয়ার সময়ের ব্যাকগ্রাউন্ড-কভার (দুইবার স্প্ল্যাশ যেন না দেখা যায়)
        for (i in 0 until childCount) getChildAt(i).visibility = View.GONE
        ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom)
            insets
        }
    }

    private fun px(v: Float) = v * d

    private fun font(name: String): Typeface =
        try { Typeface.createFromAsset(context.assets, "fonts/$name") } catch (_: Exception) { Typeface.DEFAULT }

    private fun buildContent() {
        val wDp = resources.displayMetrics.widthPixels / d
        val sidePad = px(19.2f)

        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
            setPadding(sidePad.toInt(), 0, sidePad.toInt(), 0)
        }
        addView(column, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ── লোগো + রিং ──
        val box = FrameLayout(context).apply { clipChildren = false; clipToPadding = false }
        topBox = box
        val logo = ImageView(context).apply {
            setImageResource(R.drawable.splash_logo_vec)
            scaleType = ImageView.ScaleType.FIT_XY
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
            elevation = px(12f)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                outlineSpotShadowColor = 0x66002657
                outlineAmbientShadowColor = 0x1A002657
            }
            contentDescription = context.getString(R.string.app_name)
        }
        box.addView(logo, FrameLayout.LayoutParams(px(96f).toInt(), px(96f).toInt(), Gravity.CENTER))
        ring = RingView(context)
        val ringSize = px(114f).toInt()
        box.addView(ring, FrameLayout.LayoutParams(ringSize, ringSize, Gravity.CENTER))
        column.addView(box, LinearLayout.LayoutParams(px(96f).toInt(), px(96f).toInt()))
        box.alpha = 0f; box.scaleX = 0.7f; box.scaleY = 0.7f

        // ── নাম ──
        val titleSizeDp = min(max(64f, 0.19f * wDp), 99.2f)
        val t = TextView(context).apply {
            text = "পাথেয়"
            typeface = font("Gunjoron-Font-Bold.ttf")
            setTextSize(TypedValue.COMPLEX_UNIT_PX, px(titleSizeDp))
            setTextColor(ink)
            includeFontPadding = false
            gravity = Gravity.CENTER
        }
        title = t
        column.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = px(22.4f).toInt()
        })
        t.alpha = 0f; t.translationY = px(18f)

        // ── ট্যাগলাইন: এক লাইনে ফিট ──
        val tagWords = listOf("চিরস্থায়ী", "সফরের", "পরম", "সঙ্গী।")
        val tf = font("Gunjoron-Font-Normal.ttf")
        val wanted = min(max(16f, 0.042f * wDp), 19.2f)
        val ref = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = tf; textSize = 100f }
        val spaceW = ref.measureText(" ") / 100f           // em এককে
        val gapEm = 0.24f + spaceW
        val wordsEm = tagWords.sumOf { (ref.measureText(it) / 100f).toDouble() }.toFloat()
        val totalEm = wordsEm + gapEm * (tagWords.size - 1)
        val availPx = resources.displayMetrics.widthPixels - 2 * sidePad - px(4f)
        val sizePx = min(px(wanted), availPx / totalEm).let { kotlin.math.floor(it) }

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
        }
        words = tagWords.mapIndexed { i, w ->
            TextView(context).apply {
                text = w
                typeface = tf
                setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx)
                setTextColor(ink)
                includeFontPadding = false
                maxLines = 1
                alpha = 0f
                translationY = px(10f)
            }.also {
                row.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (sizePx * 1.7f).toInt()).apply {
                    if (i < tagWords.size - 1) marginEnd = (gapEm * sizePx).toInt()
                    gravity = Gravity.CENTER_VERTICAL
                })
                it.gravity = Gravity.CENTER_VERTICAL
            }
        }
        column.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = px(8f).toInt()
        })

        // ── from Gunjoron ──
        val fPx = px(19.2f)
        val fromFont = font("PlusJakartaSans-Light.ttf")
        val fp = Paint().apply { typeface = fromFont; textSize = fPx }
        val foot = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding((0.24f * fPx).toInt(), 0, 0, 0)   // text-indent .24em
            alpha = 0f
        }
        footer = foot
        foot.addView(TextView(context).apply {
            text = "from"; typeface = fromFont; letterSpacing = 0.24f
            setTextSize(TypedValue.COMPLEX_UNIT_PX, fPx); setTextColor(ink); alpha = 0.5f
            includeFontPadding = false
        })
        foot.addView(TextView(context).apply {
            text = "Gunjoron"; typeface = fromFont; letterSpacing = 0.2f
            setTextSize(TypedValue.COMPLEX_UNIT_PX, fPx); setTextColor(ink)
            includeFontPadding = false
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = (fp.measureText(" ") + 0.24f * fPx).toInt()
        })
        addView(foot, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = px(54.4f).toInt() })
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // radial-gradient(circle at 50% 40%, glow, transparent 62%) — farthest-corner
        val cx = width * 0.5f
        val cy = height * 0.4f
        val r = hypot(max(cx, width - cx), max(cy, height - cy)) * 0.62f
        if (r <= 0f) return
        bgPaint.shader = RadialGradient(cx, cy, r, glow, glow and 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
    }

    /** শুরু — একবারই চলে। */
    fun start() {
        if (started) return
        started = true
        t0 = System.currentTimeMillis()

        topBox.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(easeOutPop).start()
        spin = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1300; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { ring.angle = it.animatedValue as Float; ring.invalidate() }
            start()
        }
        title.animate().alpha(1f).translationY(0f).setStartDelay(250).setDuration(700).setInterpolator(easeRise).start()
        words.forEachIndexed { i, w ->
            w.animate().alpha(0.85f).translationY(0f).setStartDelay(600L + i * 70L).setDuration(550)
                .setInterpolator(DecelerateInterpolator(1.2f)).start()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val blur = px(4f)
                w.setRenderEffect(RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.DECAL))
                ValueAnimator.ofFloat(blur, 0.01f).apply {
                    startDelay = 600L + i * 70L; duration = 550; interpolator = DecelerateInterpolator(1.2f)
                    addUpdateListener { a ->
                        val v = a.animatedValue as Float
                        w.setRenderEffect(if (v <= 0.05f) null else RenderEffect.createBlurEffect(v, v, Shader.TileMode.DECAL))
                    }
                    addListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) { w.setRenderEffect(null) }
                    })
                    start()
                }
            }
        }
        footer.animate().alpha(1f).setStartDelay(1000).setDuration(900).setInterpolator(cssEase).start()

        handler.postDelayed({ end() }, MAX_MS)           // সর্বোচ্চ সীমা
        if (pageLoaded) scheduleEnd()
    }

    /** ওয়েব পেজ লোড হলে ডাকুন। */
    fun markPageLoaded() {
        pageLoaded = true
        if (started) scheduleEnd()
    }

    private fun scheduleEnd() {
        val wait = max(0L, MIN_MS - (System.currentTimeMillis() - t0))
        handler.postDelayed({ end() }, wait)
    }

    private fun end() {
        if (ending) return
        ending = true
        handler.removeCallbacksAndMessages(null)
        animate().alpha(0f).scaleX(1.04f).scaleY(1.04f).setStartDelay(0).setDuration(300)
            .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f))
            .withEndAction {
                spin?.cancel()
                visibility = View.GONE
                (parent as? ViewGroup)?.removeView(this)
            }.start()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null)
        spin?.cancel()
        super.onDetachedFromWindow()
    }

    /** conic-gradient(from 0deg, transparent 0 55%, red 80%, blue 100%) রিং, ২dp পুরু। */
    private inner class RingView(c: Context) : View(c) {
        var angle = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = px(2f)
        }
        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            val a = if (dark) 0xFFFF6B73.toInt() else 0xFFEC1C24.toInt()
            val b = if (dark) 0xFF7CC4EE.toInt() else 0xFF005D92.toInt()
            p.shader = SweepGradient(w / 2f, h / 2f,
                intArrayOf(a and 0x00FFFFFF, a and 0x00FFFFFF, a, b),
                floatArrayOf(0f, 0.55f, 0.8f, 1f))
        }
        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f; val cy = height / 2f
            canvas.save()
            canvas.rotate(angle - 90f, cx, cy)
            canvas.drawCircle(cx, cy, min(cx, cy) - p.strokeWidth / 2f, p)
            canvas.restore()
        }
    }

    companion object {
        private const val MIN_MS = 0L
        private const val MAX_MS = 3400L
    }
}
