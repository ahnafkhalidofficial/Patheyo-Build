package com.gunjoron.patheyo.ui

import android.content.Context
import android.graphics.Typeface

/**
 * v37: পপআপে ব্যবহৃত সব ফন্ট এক জায়গায়। ফাইলগুলো থাকে app/src/main/assets/fonts/ ফোল্ডারে।
 * ফন্ট বদলাতে চাইলে শুধু ঐ ফোল্ডারের ফাইল বদলান (বা নিচের নাম বদলান) — আর কোথাও হাত দিতে হবে না।
 *
 *  APP_NAME   → অ্যাপের নাম (Helvetica, রেগুলার)
 *  BN_*       → বাংলা লেখা (Gunjoron-Font)
 *  EN_*       → বাকি ইংরেজি/সংখ্যা (Poppins)
 *  CLOCK_*    → শুধু আজান পপআপের ঘড়ি (Outfit)
 */
object AppFonts {
    const val APP_NAME = "Helvetica.ttf"
    const val BN_REGULAR = "Gunjoron-Font-Normal.ttf"
    const val BN_BOLD = "Gunjoron-Font-Bold.ttf"
    const val EN_REGULAR = "Poppins-Regular.ttf"
    const val EN_BOLD = "Poppins-Bold.ttf"
    const val EN_LIGHT = "Poppins-Light.ttf"
    // v46: আজান পপআপের ঘড়ির প্রিমিয়াম ফন্ট (Outfit, OFL লাইসেন্স) — শুধু ঘড়ির জন্য
    const val CLOCK_LIGHT = "Outfit-Light.ttf"
    const val CLOCK_MEDIUM = "Outfit-Medium.ttf"

    private const val DIR = "fonts/"
    private val cache = HashMap<String, Typeface>()

    /** assets/fonts/[file] থেকে ফন্ট লোড (একবারই); ফাইল না পেলে [fallback] */
    fun load(ctx: Context, file: String, fallback: Typeface = Typeface.DEFAULT): Typeface =
        cache.getOrPut(file) {
            try { Typeface.createFromAsset(ctx.assets, DIR + file) } catch (_: Throwable) { fallback }
        }

    fun bengali(ctx: Context, bold: Boolean) =
        if (bold) load(ctx, BN_BOLD, Typeface.DEFAULT_BOLD) else load(ctx, BN_REGULAR)   // ব্র্যান্ড ফন্টের আসল Normal ও Bold ফাইল (নকল বোল্ড নয়)

    fun english(ctx: Context, bold: Boolean) =
        if (bold) load(ctx, EN_BOLD, Typeface.DEFAULT_BOLD) else load(ctx, EN_REGULAR)

    /**
     * পুরো অ্যাপে একটাই বাংলা ফন্ট — Gunjoron-Font। নেটিভ স্ক্রিনগুলোর (আজান ওভারলে, অ্যালার্ম) সব
     * TextView/Button-এ এই ফন্ট বসানো হয়। নোটিফিকেশন ইচ্ছা করেই বাদ — সেটি ফোনের নিজস্ব ডিফল্ট ফন্টেই যায়।
     */
    fun applyBanglaFontToTree(ctx: Context, root: android.view.View?) {
        try {
            val tf = bengali(ctx, false)
            val tfBold = bengali(ctx, true)
            fun walk(v: android.view.View?) {
                when (v) {
                    is android.widget.TextView -> {
                        val st = v.typeface?.style ?: Typeface.NORMAL
                        val base = if ((st and Typeface.BOLD) != 0) tfBold else tf
                        v.typeface = if ((st and Typeface.ITALIC) != 0) Typeface.create(base, Typeface.ITALIC) else base
                    }
                    is android.view.ViewGroup -> for (i in 0 until v.childCount) walk(v.getChildAt(i))
                    else -> {}
                }
            }
            walk(root)
        } catch (_: Throwable) { /* ফন্ট না পেলে সিস্টেম ফন্টেই থাকবে, ক্র্যাশ নয় */ }
    }
}
