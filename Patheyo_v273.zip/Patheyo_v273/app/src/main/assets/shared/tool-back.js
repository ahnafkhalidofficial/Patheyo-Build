/* ধাপ ৬ — দোয়া/তাসবিহ/কিবলা: Android ব্যাক বাটনে আগে খোলা পপআপ বন্ধ (হোম 06-native-bridge.js → __ptFrameBack জিজ্ঞেস করে)
   পপআপগুলো .sheet.on + .veil.on (পর্দায় চাপলেই নিজের কোড বন্ধ করে), উদযাপন .win.on ("চালিয়ে যান") */
(function () {
  'use strict';
  window.__ptFrameBack = function () {
    try { if (window.PT && PT.handleBack && PT.handleBack()) return true; } catch (e) {}
    var win = document.querySelector('.win.on'); if (win) { var ok = win.querySelector('#wok, button'); if (ok) { ok.click(); return true; } }
    var veils = document.querySelectorAll('.veil.on'); if (veils.length) { veils[veils.length - 1].click(); return true; }
    return false;
  };
})();
