/* পাথেয় — কম্পোনেন্টের আচরণ ও মোশন (কোনো লাইব্রেরি ছাড়া, ~৫KB)।
   সব সময়/ইজিং CSS টোকেন থেকে আসে; এখানে শুধু ক্লাস যোগ/বাদ।
   API (window.PT):
     PT.seg(el) / PT.tabs(el)         — সেগমেন্ট/ট্যাবের চলমান নির্দেশক; 'pt:change' ইভেন্ট দেয় (detail.index)
     PT.header(headerEl, scrollEl?)   — স্ক্রল করলে হেডার ছোট হয়
     PT.sheet.open(sheetEl) / close   — বটম-শিট (নিচে টানলে বন্ধ, ব্যাক বাটনে বন্ধ)
     PT.dialog({title, body, icon, ok, cancel, danger}) → Promise<boolean>
     PT.toast(text, {type, action, onAction, ms})
     PT.menu(anchorEl, items[])       — ⋯ মেনু; items: {icon, label, onClick} বা '-' (বিভাজক)
     PT.reveal(root?)                 — data-pt-reveal উপাদান ধাপে ধাপে ঢোকে
     PT.haptic(kind)                  — হালকা কম্পন ('light' | 'success' | 'warn')
     PT.slider(el)                    — স্লাইডারের ভরাট অংশ
     PT.init(root?)                   — পেজের সব কম্পোনেন্ট একবারে চালু
*/
(function (W, D) {
  var PT = W.PT = W.PT || {};
  var reduce = !!(W.matchMedia && W.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function cssMs(name, fb) {
    var v = getComputedStyle(D.documentElement).getPropertyValue(name).trim();
    var n = parseFloat(v); return isNaN(n) ? fb : n;
  }
  function closeAfter(el, cb) {               /* is-closing অ্যানিমেশন শেষ হলে সরাও */
    var ms = reduce ? 0 : cssMs('--pt-dur-2', 220);
    el.classList.add('is-closing');
    setTimeout(function () { el.classList.remove('is-closing'); cb && cb(); }, ms);
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- হ্যাপটিক ---------- */
  PT.haptic = function (kind) {
    var ms = kind === 'success' ? [12, 40, 12] : kind === 'warn' ? [30, 30, 30] : 10;
    try { if (W.PatheyoHaptics && W.PatheyoHaptics.vibrate) { W.PatheyoHaptics.vibrate(String(kind || 'light')); return; } } catch (e) {}
    try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {}
  };

  /* ---------- সেগমেন্ট ও ট্যাব: চলমান নির্দেশক ---------- */
  function slider(el, btnSel, inkSel, inkCls, useText) {
    if (!el || el.__pt) return; el.__pt = 1;
    var btns = [].slice.call(el.querySelectorAll(btnSel));
    var ink = el.querySelector(inkSel);
    if (!ink) { ink = D.createElement('span'); ink.className = inkCls; ink.setAttribute('aria-hidden', 'true'); el.insertBefore(ink, el.firstChild); }
    el.setAttribute('role', 'tablist');
    function place(i, instant) {
      var b = btns[i]; if (!b) return;
      if (instant) { ink.style.transition = 'none'; }
      var w = b.offsetWidth, x = b.offsetLeft;
      if (useText) { var t = b.scrollWidth; w = Math.min(w, t); }
      ink.style.width = w + 'px';
      ink.style.transform = 'translateX(' + (x - (useText ? 0 : 4)) + 'px)';
      if (instant) { void ink.offsetWidth; ink.style.transition = ''; }
    }
    function select(i, silent) {
      btns.forEach(function (b, k) { b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', k === i ? 'true' : 'false'); b.tabIndex = k === i ? 0 : -1; });
      place(i);
      if (useText && btns[i] && btns[i].scrollIntoView) { try { btns[i].scrollIntoView({ block: 'nearest', inline: 'center', behavior: reduce ? 'auto' : 'smooth' }); } catch (e) {} }
      if (!silent) { PT.haptic('light'); el.dispatchEvent(new CustomEvent('pt:change', { detail: { index: i, button: btns[i] } })); }
    }
    btns.forEach(function (b, i) { b.addEventListener('click', function () { if (b.getAttribute('aria-selected') !== 'true') select(i); }); });
    var start = Math.max(0, btns.findIndex(function (b) { return b.getAttribute('aria-selected') === 'true'; }));
    select(start, true); requestAnimationFrame(function () { place(start, true); });
    if (W.ResizeObserver) new ResizeObserver(function () { var c = btns.findIndex(function (b) { return b.getAttribute('aria-selected') === 'true'; }); place(Math.max(0, c), true); }).observe(el);
    el.ptSelect = select;
  }
  PT.seg = function (el) { slider(el, '.pt-seg__btn', '.pt-seg__thumb', 'pt-seg__thumb', false); };
  PT.tabs = function (el) { slider(el, '.pt-tabs__btn', '.pt-tabs__ink', 'pt-tabs__ink', true); };

  /* ---------- হেডার: স্ক্রলে ছোট ---------- */
  PT.header = function (h, scroller) {
    if (!h || h.__pt) return; h.__pt = 1;
    var s = scroller || W, ticking = false;
    function y() { return s === W ? (W.scrollY || D.documentElement.scrollTop) : s.scrollTop; }
    function upd() { ticking = false; h.classList.toggle('is-compact', y() > 12); }
    s.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(upd); } }, { passive: true });
    upd();
  };

  /* ---------- বটম-শিট ---------- */
  var openSheets = [];
  PT.sheet = {
    open: function (sheet) {
      if (!sheet || !sheet.hidden && sheet.__open) return;
      var scrim = D.createElement('div'); scrim.className = 'pt-scrim';
      sheet.parentNode.insertBefore(scrim, sheet);
      sheet.hidden = false; sheet.__open = true; sheet.__scrim = scrim;
      sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-modal', 'true');
      scrim.addEventListener('click', function () { PT.sheet.close(sheet); });
      openSheets.push(sheet);
      var f = sheet.querySelector('[autofocus]'); if (f) setTimeout(function () { try { f.focus({ preventScroll: true }); } catch (e) {} }, 50);   /* টাচে অকারণ ফোকাস-রিং নয় */
      sheet.dispatchEvent(new CustomEvent('pt:open'));
    },
    close: function (sheet) {
      sheet = sheet || openSheets[openSheets.length - 1];
      if (!sheet || !sheet.__open) return;
      sheet.__open = false; openSheets.splice(openSheets.indexOf(sheet), 1);
      var scrim = sheet.__scrim;
      sheet.style.transform = '';
      if (scrim) closeAfter(scrim, function () { scrim.remove(); });
      closeAfter(sheet, function () { sheet.hidden = true; sheet.dispatchEvent(new CustomEvent('pt:close')); });
    },
    isOpen: function () { return openSheets.length > 0; }
  };
  function dragToClose(sheet) {
    if (sheet.__drag) return; sheet.__drag = 1;
    var y0 = null, dy = 0, t0 = 0;
    sheet.addEventListener('touchstart', function (e) {
      var body = sheet.querySelector('.pt-sheet__body');
      if (body && body.contains(e.target) && body.scrollTop > 0) { y0 = null; return; }
      y0 = e.touches[0].clientY; dy = 0; t0 = Date.now(); sheet.style.transition = 'none';
    }, { passive: true });
    sheet.addEventListener('touchmove', function (e) {
      if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0);
      sheet.style.transform = dy ? 'translateY(' + dy + 'px)' : '';
    }, { passive: true });
    sheet.addEventListener('touchend', function () {
      if (y0 == null) return; y0 = null; sheet.style.transition = '';
      var fast = dy > 40 && (Date.now() - t0) < 250;
      if (dy > sheet.offsetHeight * 0.3 || fast) PT.sheet.close(sheet); else sheet.style.transform = '';
    });
  }

  /* ---------- ডায়লগ ---------- */
  PT.dialog = function (o) {
    o = o || {};
    return new Promise(function (resolve) {
      var scrim = D.createElement('div'); scrim.className = 'pt-scrim pt-dialog-scrim';
      var d = D.createElement('div'); d.className = 'pt-dialog'; d.setAttribute('role', 'alertdialog'); d.setAttribute('aria-modal', 'true');
      d.innerHTML = (o.icon ? '<div class="pt-dialog__icon pt-medal' + (o.danger ? ' pt-dialog__icon--danger' : '') + '">' + PT.icon(o.icon, 'pt-ic--lg') + '</div>' : '') +
        '<h2 class="pt-dialog__title">' + esc(o.title) + '</h2>' + (o.body ? '<p class="pt-dialog__body">' + esc(o.body) + '</p>' : '') +
        '<div class="pt-dialog__actions">' + (o.cancel === false ? '' : '<button class="pt-btn pt-btn--secondary" data-v="0">' + esc(o.cancel || 'বাতিল') + '</button>') +
        '<button class="pt-btn' + (o.danger ? ' pt-btn--danger' : '') + '" data-v="1">' + esc(o.ok || 'ঠিক আছে') + '</button></div>';
      D.body.appendChild(scrim); D.body.appendChild(d);
      var done = function (v) { closeAfter(scrim, function () { scrim.remove(); }); closeAfter(d, function () { d.remove(); }); PT.__back = null; resolve(v); };
      d.addEventListener('click', function (e) { var b = e.target.closest('[data-v]'); if (b) done(b.getAttribute('data-v') === '1'); });
      scrim.addEventListener('click', function () { done(false); });
      PT.__back = function () { done(false); return true; };
      setTimeout(function () { var b = d.querySelector('[data-v="1"]'); if (b) b.focus(); }, 30);
      PT.haptic(o.danger ? 'warn' : 'light');
    });
  };

  /* ---------- টোস্ট ---------- */
  PT.toast = function (text, o) {
    o = o || {};
    var host = D.querySelector('.pt-toasts');
    if (!host) { host = D.createElement('div'); host.className = 'pt-toasts'; host.setAttribute('role', 'status'); host.setAttribute('aria-live', 'polite'); D.body.appendChild(host); }
    var t = D.createElement('div'); t.className = 'pt-toast' + (o.type ? ' pt-toast--' + o.type : '');
    var ic = o.type === 'success' ? 'check-circle' : o.type === 'danger' ? 'alert' : o.icon;
    t.innerHTML = (ic ? PT.icon(ic) : '') + '<span>' + esc(text) + '</span>' + (o.action ? '<button class="pt-toast__action">' + esc(o.action) + '</button>' : '');
    host.appendChild(t);
    var gone = false, kill = function () { if (gone) return; gone = true; closeAfter(t, function () { t.remove(); }); };
    if (o.action) t.querySelector('.pt-toast__action').addEventListener('click', function () { kill(); o.onAction && o.onAction(); });
    setTimeout(kill, o.ms || (o.action ? 5000 : 2600));
    if (o.type === 'success') PT.haptic('success');
    return kill;
  };

  /* ---------- মেনু ---------- */
  var curMenu = null;
  function closeMenu() { if (!curMenu) return; var m = curMenu; curMenu = null; closeAfter(m, function () { m.remove(); }); }
  PT.menu = function (anchor, items) {
    if (curMenu) { closeMenu(); return; }
    var m = D.createElement('div'); m.className = 'pt-menu'; m.setAttribute('role', 'menu');
    items.forEach(function (it, i) {
      if (it === '-') { m.insertAdjacentHTML('beforeend', '<div class="pt-menu__sep"></div>'); return; }
      var b = D.createElement('button'); b.className = 'pt-menu__item'; b.setAttribute('role', 'menuitem');
      b.innerHTML = (it.icon ? PT.icon(it.icon) : '') + '<span>' + esc(it.label) + '</span>' + (it.toggle != null ? '<span class="pt-switch"><input type="checkbox" tabindex="-1"' + (it.toggle ? ' checked' : '') + '><span class="pt-switch__track"></span></span>' : '');
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        if (it.toggle != null) { var c = b.querySelector('input'); if (e.target !== c) c.checked = !c.checked; it.onClick && it.onClick(c.checked); return; }
        closeMenu(); it.onClick && it.onClick();
      });
      m.appendChild(b);
    });
    D.body.appendChild(m);
    var r = anchor.getBoundingClientRect(), vw = D.documentElement.clientWidth;
    m.style.top = (r.bottom + 6) + 'px';
    m.style.right = Math.max(8, vw - r.right) + 'px';
    curMenu = m;
    setTimeout(function () { D.addEventListener('click', function h(e) { if (curMenu && !curMenu.contains(e.target)) { D.removeEventListener('click', h, true); closeMenu(); } }, true); }, 0);
  };

  /* ---------- প্রবেশ অ্যানিমেশন (ধাপে ধাপে) ---------- */
  PT.reveal = function (root) {
    var els = [].slice.call((root || D).querySelectorAll('[data-pt-reveal]:not(.is-in)'));
    if (!els.length) return;
    if (reduce || !W.IntersectionObserver) { els.forEach(function (e) { e.classList.add('is-in'); }); return; }
    var step = 50, batch = 0, last = 0;
    var io = new IntersectionObserver(function (ents) {
      var now = Date.now(); if (now - last > 120) batch = 0; last = now;
      ents.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.style.setProperty('--pt-delay', Math.min(batch++, 8) * step + 'ms');
        en.target.classList.add('is-in'); io.unobserve(en.target);
      });
    }, { rootMargin: '0px 0px -8% 0px' });
    els.forEach(function (e) { io.observe(e); });
  };

  /* ---------- স্লাইডার ---------- */
  PT.slider = function (el) {
    if (!el || el.__pt) return; el.__pt = 1;
    function f() { var mn = +el.min || 0, mx = +el.max || 100; el.style.setProperty('--pt-fill', ((el.value - mn) / (mx - mn) * 100) + '%'); }
    el.addEventListener('input', f); f();
  };

  /* ---------- অ্যান্ড্রয়েড ব্যাক বাটন: আগে খোলা মেনু/ডায়লগ/শিট বন্ধ ---------- */
  PT.handleBack = function () {
    if (curMenu) { closeMenu(); return true; }
    if (PT.__back && PT.__back()) return true;
    if (openSheets.length) { PT.sheet.close(); return true; }
    return false;
  };

  /* ---------- সব একসাথে ---------- */
  PT.init = function (root) {
    root = root || D;
    [].forEach.call(root.querySelectorAll('.pt-seg'), PT.seg);
    [].forEach.call(root.querySelectorAll('.pt-tabs'), PT.tabs);
    [].forEach.call(root.querySelectorAll('.pt-slider'), PT.slider);
    var h = root.querySelector('.pt-header[data-pt-compact]'); if (h) PT.header(h);
    PT.reveal(root);
  };
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', function () { PT.init(); }); else PT.init();
})(window, document);
