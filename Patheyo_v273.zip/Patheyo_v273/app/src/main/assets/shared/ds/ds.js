/* পাথেয় ডিজাইন সিস্টেম — JS বান্ডেল (স্বয়ংক্রিয়)। সোর্স: shared/ds/{icons.js,pt.js} */
/* পাথেয় — আইকন সেট (২৪×২৪ গ্রিড, ১.৮ স্ট্রোক, গোল প্রান্ত)।
   ব্যবহার:  <i data-ic="book"></i>   → পেজ লোডে নিজে SVG হয়ে যায় (class="pt-ic")
             PT.icon('book', 'pt-ic--lg')  → SVG স্ট্রিং
   'd' ক্লাসের অংশ = ডুয়োটোন হালকা ভরাট (ফিচার আইকন), 'f' = পুরো ভরাট।
   নতুন আইকন যোগ করলে এই একই গ্রিড ও স্ট্রোক মানতে হবে। */
(function (W) {
  var I = {
    /* ---- নেভিগেশন ---- */
    home: '<path class="d" d="M5 10.5 12 5l7 5.5V20H5z"/><path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-5a2 2 0 0 1 4 0v5"/>',
    /* ---- v180: ফুটার ট্যাব-আইকন — সব ভরাট (solid) সিলুয়েট, একই ওজন; দেওয়া SVG (মসজিদ/কুরআন-রেহাল/কিতাব) ২৪ গ্রিডে মাপ-ঠিক করে বসানো ---- */
    'nv-home': '<path class="f" transform="translate(12 12.2) scale(.9) translate(-12 -12)" fill-rule="evenodd" d="M11.2 3.1 3.5 9.6C3.2 9.9 3 10.3 3 10.7V19a2 2 0 0 0 2 2h4.3v-5.2a1.4 1.4 0 0 1 1.4-1.4h2.6a1.4 1.4 0 0 1 1.4 1.4V21H19a2 2 0 0 0 2-2v-8.3c0-.4-.2-.8-.5-1.1L12.8 3.1a1.2 1.2 0 0 0-1.6 0z"/>',
    'nv-prayer': '<g class="f" transform="matrix(0.04740 0 0 0.04740 -32.198 -1.014)"><path d="M928.1,52.8c-5.9,3.8-10.8,8.3-14.8,13.8c-13.2,18.7-10.8,43.5,5.8,59.2c21.1,20,54.6,18.1,73.3-4.1c0.3-0.3,0.6-0.7,1-1.1c-3.2,19.6-23.8,43.3-54.9,45.5c0,3.1,0,6.3,0,9.4c0,0.3,0.5,0.7,0.8,1c7.8,5.3,9.4,9.4,6.9,18.6c2.4,0.9,4.9,1.8,7.3,2.8c23.2,9.3,44.5,21.8,63.2,38.4c21.6,19.1,37.3,42,44.9,70c2.8,10.5,4.1,21.3,3.5,32.4c-88.4,0-176.8,0-265.8,0c0.3-5.5,0.2-10.9,0.9-16.3c4.3-35.3,21.9-63.3,48.1-86.4c20.2-17.9,43.3-30.9,68.6-40.2c0.6-0.2,1.1-0.5,1.7-0.7c-0.4-1.9-1-3.7-1.1-5.5c-0.3-5.6,2.3-9.7,7.1-12.5c1.3-0.8,1.9-1.5,1.8-3.1c-0.1-2.8,0-5.6,0-8.3c-32.7-5.3-54-35.1-49.1-64.5C882.4,71.5,908.5,54.7,928.1,52.8z"/><path d="M1078.1,351.5c0,48.3,0,96.5,0,144.8c-30.1,0-60,0-90.2,0c0-0.9,0-1.8,0-2.8c0-18.9-0.3-37.8,0.1-56.6c0.3-16.5-6.2-29.6-18-40.5c-10.6-9.7-23.1-16.1-36.5-20.9c-0.6-0.2-1.4-0.2-2,0c-12.8,4.8-24.9,10.8-35.2,19.9c-12.5,10.9-19.4,24.4-19.1,41.4c0.3,18.5,0.1,37,0,55.4c0,1.3,0,2.6,0,4.1c-30.2,0-60.1,0-90.1,0c0-48.3,0-96.4,0-144.8C884.1,351.5,981,351.5,1078.1,351.5z"/><path d="M1097.5,271.5c14.2,0,28.2,0,42.5,0c0,74.9,0,149.7,0,224.7c-14.2,0-28.3,0-42.5,0C1097.5,421.3,1097.5,346.5,1097.5,271.5z"/><path d="M725.2,271.6c14.3,0,28.3,0,42.5,0c0,74.9,0,149.7,0,224.7c-14.2,0-28.3,0-42.5,0C725.2,421.4,725.2,346.7,725.2,271.6z"/><path d="M727.5,254.7c-0.4-1.3-0.5-2.5-1.1-3.1c-4.1-3.9-4.6-8.7-3.7-13.8c1.4-8.1,6.4-14,12.4-19.2c0.7-0.6,1.4-1.2,2.2-1.7c1.8-1.1,3.1-2.1,2.6-4.7c-0.2-1,0.6-2.7,1.5-3.5c1.4-1.2,1.5-2.5,1.4-4.1c-0.2-5.5,1.5-10.6,3.6-16c2.3,5.6,3.7,11.1,3.7,16.8c0,0.9,0.5,2,1.1,2.7c1.3,1.5,2.2,3.1,1.7,5.1c-0.4,1.5,0.2,2,1.3,2.8c7,4.8,12.5,10.8,15.2,18.9c1.4,4.2,1.5,8.4-0.2,12.6c-0.5,1.3-1.7,2.4-2.5,3.6c-0.6,0.9-1,1.9-1.8,3.5c3,0,5.2,0,7.5,0c3.8,0,5.2,1.4,5.2,5.2c0.2,7.2-0.5,7.9-7.8,7.9c-16.3,0-32.6,0-48.9,0c-4.5,0-5.9-1.4-5.9-5.8c0-0.9,0-1.9,0-2.8c0.2-2.9,1.6-4.4,4.6-4.5C722.2,254.6,724.5,254.7,727.5,254.7z"/><path d="M1118.6,188.6c2.3,5.8,3.7,11.1,3.8,16.7c0,1,0.5,2.2,1.2,2.9c1.9,2,2.1,4.2,1.6,6.1c3.8,3.7,7.7,6.8,10.9,10.6c4.9,5.8,7.9,12.5,6,20.3c-0.5,2.1-2,4-3,5.9c-0.5,1-1,2-1.8,3.5c3.1,0,5.4,0,7.7,0c3.2,0,4.7,1.5,4.8,4.7c0.4,7.5-0.6,8.4-8,8.4c-16.1,0-32.3,0-48.4,0c-4.9,0-6.1-1.2-6.1-6.1c0-0.3,0-0.6,0-0.9c0-4.9,1.2-6.1,6-6.1c1.9,0,3.7,0,6,0c-0.3-1.2-0.3-2.4-0.9-3c-4.6-4.5-4.8-10-3.3-15.6c2.3-8.6,8.1-14.8,15.2-19.8c1.3-0.9,1.7-1.7,1.7-3.4c0-1.6,1.1-3.1,1.7-4.6c0.4-0.9,1.1-1.9,1.1-2.8C1114.8,199.8,1116.5,194.5,1118.6,188.6z"/></g>',
    'nv-quran': '<g class="f" transform="matrix(0.05110 0 0 0.05110 -37.051 -19.446)"><path d="M959.9,664.5c-54.5-39.1-114.1-66.8-179.4-82.5c4.1-33.5,9.7-66.3,20.3-98c2.3-6.9,4.9-13.7,7.1-20.7c0.8-2.6,2.1-3.6,4.8-3.9c24.8-2.1,48.6,1.9,71.7,10.8c28.3,10.8,50.7,29.2,68.5,53.5c0.9,1.2,1.7,2.5,2.7,3.6c3.2,3.5,6.5,3.2,9.2-1.2c10.8-17,24.8-30.7,41.6-41.6c22-14.3,46.2-20.5,72.4-19.3c9,0.4,17.9,1.2,26.9,1.6c3.2,0.1,5,1,6.2,4.3c11.4,30.7,19.5,62.3,24.5,94.6c0.8,5.2,1.7,10.5,2.7,16.3C1074,597.9,1014.4,625.4,959.9,664.5z M1103.9,547.4c-0.4-4.5-3.6-4.9-7.2-4.9c-30.5,0.6-58.3,9.9-83.8,26.4c-12.3,8-23.5,17.4-33,28.6c-2.2,2.6-3.1,5.3-0.1,7.8c2.8,2.3,5.5,1.6,7.9-1c1.1-1.2,2.2-2.5,3.4-3.7c17-18.1,37.3-31.4,60.7-39.7c14.8-5.2,30.1-8,45.8-8.3C1101.2,552.7,1103.7,551.6,1103.9,547.4z M823.7,542.6c-2.9,0.1-7-0.6-7.6,4.6c-0.4,3.9,1.7,5.2,8,5.5c33.4,1.5,63.2,12.5,89.1,33.6c6.9,5.6,13,12.3,19.5,18.5c2.5,2.4,5,2.5,7.5,0.3c2.5-2.2,2.2-4.6,0.3-7c-0.6-0.8-1.3-1.5-1.9-2.3C907.6,562.8,869.8,544.6,823.7,542.6z M1078.8,503.2c-9.1,1.5-18.4,2.5-27.4,4.6c-24.3,5.7-45.2,17.7-63.1,35c-3.3,3.2-3.4,7.5-0.1,9.2c3.2,1.7,5.6,0,7.9-2.2c23.2-22.4,51-34,83.1-35.3c6.6-0.3,9.5-2,9.4-5.7C1088.5,505.1,1085.5,503.6,1078.8,503.2z M839.8,503.8c0.4,0-0.1,0-0.6,0c-3.8-0.3-7.5,0.4-7.8,4.8c-0.4,4.9,3.6,5.7,7.5,5.9c4,0.2,8,0.2,11.9,0.7c28.4,3.6,53.1,14.9,73.5,35.1c2.6,2.5,5.5,3.7,8.3,0.9c2.9-3,1.7-5.9-1.1-8.6C906.1,518.3,875.7,505.6,839.8,503.8z"/><path d="M1125.7,479c10.3-0.9,20.2-1.8,31-2.8c9.4,45.5,18.7,91.1,28.2,137.1c-40.8,8.1-79.4,22-116.9,39c-37.3,16.9-75.7,31.6-107,57.1c-70.3-44.7-145.3-76.7-226.1-96.9c9.2-45.1,18.6-90.6,28-136.6c9.7,1,18.9,1.9,28.1,2.8c-3.5,13.1-7.6,25.6-10.1,38.4c-4.4,22.4-7.8,45.1-11.4,67.7c-0.7,4.3,2.2,5.9,6,7c17.5,4.9,35.2,9.4,52.4,15.4c44.4,15.3,85.4,37.2,123.6,64.5c8.3,6,8.3,5.9,16.7,0c53.3-38.1,111.7-64.9,175.5-79.8c5.8-1.4,6.9-3,6.1-8.6c-5.1-34-11.2-67.7-23-100.1C1126.4,481.8,1126.2,480.7,1125.7,479z"/><path d="M1132.3,771.9c-54.4-18.9-107.7-37.4-161.1-56c-0.2-0.5-0.3-1-0.5-1.4c10-6.3,19.8-13.1,30.2-18.9c10.7-6,21.8-11.2,32.9-16.4c1.7-0.8,4.5-0.8,6.2,0.1c29.6,15.6,59.2,31.3,88.7,47.2c1.5,0.8,3.4,2.7,3.5,4.1C1132.4,743.9,1132.3,757.4,1132.3,771.9z"/><path d="M787.8,771.8c-0.1-2.4-0.3-4-0.3-5.6c0-11.1,0.2-22.3-0.1-33.4c-0.1-3.6,1.3-5.2,4.3-6.8c29.2-15.4,58.3-30.9,87.3-46.6c2.8-1.5,5-1.6,7.7-0.1c18.1,10.1,36.2,20,54.3,30.1c2.7,1.5,5,3.7,8.4,6.2C895.2,734.4,841.8,753,787.8,771.8z"/></g>',
    'nv-hadith': '<g class="f" transform="matrix(0.04300 0 0 0.04300 -7.945 -20.479)"><path d="M234.6,949.8c-4.9-2.9-5.2-7.4-5.2-12.2c0.1-9.1,0-18.1,0.1-27.2c0-0.9,0-1.9,0-3c29.1,0,57.9,0,87.1,0c0,0.9,0,1.8,0,2.7c0,9.7,0,19.4,0,29.1c0,5.3-1,7.2-5.8,10.4c8.7,0,17.1,0,26.1,0c-4.7-2.7-5.2-6.6-5-11c0.2-5,0.2-10.1,0-15.1c-0.1-2.3,0.6-2.9,2.9-2.9c25.2,0,50.5,0,75.7,0c2,0,4.1,0,6.4,0c0,3.6,0,6.9,0,10.1c0,2.8-0.1,5.7,0,8.5c0.2,4.3-0.7,8-5.5,10.5c9.4,0,18,0,26.9,0c-0.8-0.6-1.5-1-2.1-1.5c-2-1.7-3.2-3.8-3.2-6.3c0-11.4,0-22.7,0-34.1c0-0.2,0.1-0.4,0.2-0.8c28.6,0,57.3,0,86.4,0c0,0.9,0,1.8,0,2.7c0,9.6-0.1,19.2,0,28.9c0.1,4.8-0.8,8.8-5.6,11.3c1.1,0,2.1,0,3.2,0c65.2,0,130.4,0,195.7,0c3.4,0,6.4,0.8,9,3c2.9,2.3,4.3,5.3,4.4,9c0,1.7,0,3.3,0,5c0,7-5.2,12.3-12.2,12.3c-9,0.1-18,0-27,0c-157.6,0-315.3,0-472.9,0c-6.2,0-11.1-2.6-12.2-8c-0.9-4.3-0.8-9.1,0-13.5c0.9-4.8,6.1-7.8,11.5-7.8c6.3-0.1,12.6,0,18.9,0C233.1,949.8,233.9,949.8,234.6,949.8z"/><path d="M518.9,613.8c0,84.3,0,168.6,0,253.2c-28.6,0-57.1,0-85.8,0c0-84.2,0-168.6,0-253.2C461.7,613.8,490.2,613.8,518.9,613.8z"/><path d="M416.8,880.5c-28.5,0-56.6,0-85,0c0-1,0-1.8,0-2.7c0-83.7,0-167.3,0.1-251c0-6.3,3.7-10.1,9.9-10.1c21.8,0,43.7,0,65.5,0c5.9,0,9.5,3.7,9.5,9.7c0,83.8,0,167.7-0.1,251.5C416.8,878.6,416.8,879.4,416.8,880.5z M381.4,758.6C381.4,758.6,381.4,758.6,381.4,758.6c0,8.7,0,17.4,0,26c0,5.5,3.7,9.4,8.8,9.3c5.2,0,8.8-3.8,8.8-9.3c0-17.3,0-34.5,0-51.8c0-5.5-3.6-9.3-8.8-9.3c-5.2,0-8.8,3.7-8.8,9.3C381.3,741.4,381.4,750,381.4,758.6z M381.4,834.3C381.4,834.3,381.4,834.3,381.4,834.3c0,3-0.1,6,0,9c0.1,5,3.8,8.6,8.8,8.7c4.8,0,8.7-3.5,8.8-8.3c0.1-6.2,0.2-12.5,0-18.7c-0.1-4.9-4.1-8.3-9.2-8.2c-4.7,0.1-8.3,3.8-8.4,8.5C381.3,828.3,381.4,831.3,381.4,834.3z"/><path d="M539.3,676.4c33.2-8.5,65.9-17,99.1-25.5c20.4,67.2,40.9,134.5,61.4,202c-34,9-67.7,17.9-101.7,26.9C578.6,812.2,559,744.6,539.3,676.4z M646,774.7c-0.1-0.5-0.3-1.7-0.7-2.8c-3.9-12.5-7.9-24.9-11.6-37.4c-5.2-17.7-10.2-35.4-15.3-53.1c-0.9-3.1-2.5-5.4-5.6-6.5c-3.3-1.2-6.5-0.4-9,1.9c-2.5,2.3-3.4,5.3-2.4,8.6c3,9.9,6.1,19.7,9,29.6c6.3,20.9,12.6,41.8,18.9,62.7c1.3,4.3,5.1,7,9,6.5C642.8,783.5,646,779.9,646,774.7z M665.1,842.4c-0.4-1.4-0.9-3.6-1.6-5.7c-3-9.9-6-19.9-9.1-29.8c-1.4-4.6-5.8-7-10.2-5.8c-4.5,1.2-7.5,5.6-6.2,9.9c3.4,11.8,7,23.5,10.7,35.2c1.2,3.9,5.2,6.1,8.9,5.4C662.2,850.9,665.1,847.7,665.1,842.4z"/><path d="M229.7,613.6c29,0,57.8,0,86.7,0c0,84.5,0,168.9,0,253.6c-28.9,0-57.8,0-86.7,0C229.7,782.7,229.7,698.3,229.7,613.6z M297.9,775.1c0.1,0,0.1,0,0.2,0c0-22.4,0-44.8,0-67.2c0-5.5-3.7-9.4-8.8-9.5c-5.2-0.1-9,3.8-9.1,9.4c-0.1,3.4,0,6.8,0,10.2c0,41.2,0,82.5,0,123.7c0,5.4,3.8,9.4,8.8,9.4c5.2,0,8.9-3.9,8.9-9.3C297.9,819.6,297.9,797.4,297.9,775.1z M298,653.5C298.1,653.5,298.1,653.5,298,653.5c0.1-4.5,0.1-9,0.1-13.5c-0.1-5.3-4-9.2-9.1-9.1c-5,0.1-8.8,4-8.9,9.2c0,8.9,0,17.8,0,26.7c0,5.2,3.8,9.1,8.8,9.1c5.3,0,9-3.7,9.1-9.1C298.1,662.3,298,657.9,298,653.5z"/><path d="M626.3,614.2c-32.5,8.8-64.7,17.6-97.1,26.4c-0.8-2.6-1.6-5.3-2.4-8c-2.1-7.2-4.1-14.4-6.2-21.6c-1.9-6.5,0.1-10,6.7-11.8c15-4.1,30.1-8.2,45.1-12.4c10.9-3.1,21.7-6.4,32.6-9.6c6-1.8,9.8,0.4,11.7,6.5c2.9,9.4,5.9,18.8,8.9,28.2C625.8,612.5,626,613.1,626.3,614.2z"/><path d="M608.5,914.2c33.8-8.3,67.4-16.6,101.1-24.9c1.3,4.4,2.5,8.7,3.7,13c1.2,4.3,2.4,8.7,3.6,13c1.5,5.3-0.6,9.3-6,10.7c-9.6,2.6-19.2,5.1-28.8,7.6c-18.5,4.9-37,9.8-55.5,14.7c-4.4,1.2-8.2-0.5-9.5-4.7C614.1,934.1,611.4,924.4,608.5,914.2z"/><path d="M316.6,572.1c-29,0-57.9,0-87.1,0c-0.1-0.8-0.2-1.6-0.2-2.4c0-9.5,0-19.1,0-28.6c0-5.7,3.7-9.6,9.4-9.6c22.9-0.1,45.9-0.1,68.8,0c5.1,0,9.1,3.8,9.2,8.7c0.1,10.3,0,20.7,0,31C316.9,571.3,316.8,571.6,316.6,572.1z"/><path d="M432.6,572c0-7.8-0.1-15.5,0.1-23.1c0.1-4.4,3.3-7.6,7.9-8c4.3-0.3,8.7-0.1,13-0.2c18.6,0,37.2-0.1,55.8-0.1c7.6,0,10.7,3.2,10.7,10.8c0,5.8,0,11.7,0,17.5c0,0.9,0,1.9,0,3C490.7,572,461.8,572,432.6,572z"/><path d="M332,907.9c0-4.9,0-9.7,0-14.6c28.2,0,56.3,0,84.7,0c0,4.8,0,9.6,0,14.6C388.5,907.9,360.4,907.9,332,907.9z"/><path d="M316.7,585.1c0,4.9,0,9.6,0,14.5c-29,0-57.9,0-87.1,0c0-4.8,0-9.5,0-14.5C258.6,585.1,287.6,585.1,316.7,585.1z"/><path d="M519.5,585.1c0,4.8,0,9.5,0,14.4c-29,0-57.9,0-86.9,0c0-4.8,0-9.5,0-14.4C461.6,585.1,490.4,585.1,519.5,585.1z"/><path d="M316.5,879.9c0,4.8,0,9.5,0,14.3c-29,0-57.8,0-86.9,0c0-4.7,0-9.4,0-14.3C258.5,879.9,287.4,879.9,316.5,879.9z"/><path d="M519.5,879.4c0,4.9,0,9.6,0,14.4c-28.9,0-57.6,0-86.5,0c0-4.8,0-9.5,0-14.4C461.9,879.4,490.6,879.4,519.5,879.4z"/><path d="M536,664.4c-1.1-4-2.2-7.8-3.4-12c32.8-8.7,65.3-17.3,98.1-26c1.1,3.6,2.3,7.3,3.5,11.3C601.4,646.7,568.8,655.5,536,664.4z"/><path d="M605,902.8c-1.1-3.7-2.2-7.2-3.4-11.1c33.8-8.6,67.5-17.2,101.5-25.9c1,3.4,2,7,3.1,10.9C672.5,885.4,638.9,894,605,902.8z"/></g>',
    'nv-more': '<rect class="f" x="3.9" y="3.9" width="7" height="7" rx="2.1"/><rect class="f" x="13.1" y="3.9" width="7" height="7" rx="2.1"/><rect class="f" x="3.9" y="13.1" width="7" height="7" rx="2.1"/><rect class="f" x="13.1" y="13.1" width="7" height="7" rx="2.1"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    forward: '<path d="M9 5l7 7-7 7"/>',
    'chev-down': '<path d="M6 9l6 6 6-6"/>',
    'chev-up': '<path d="M6 15l6-6 6 6"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    more: '<circle class="f" cx="5" cy="12" r="1.6"/><circle class="f" cx="12" cy="12" r="1.6"/><circle class="f" cx="19" cy="12" r="1.6"/>',
    'more-v': '<circle class="f" cx="12" cy="5" r="1.6"/><circle class="f" cx="12" cy="12" r="1.6"/><circle class="f" cx="12" cy="19" r="1.6"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h10"/>',
    external: '<path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',

    /* ---- ফিচার (ডুয়োটোন) ---- */
    mosque: '<path class="d" d="M7 13a5 5 0 0 1 10 0v7H7z"/><path d="M12 4v2.2"/><path d="M12 6.2c-2.9 1.4-5 3.6-5 6.8h10c0-3.2-2.1-5.4-5-6.8Z"/><path d="M5 20V13h14v7"/><path d="M3 20h18"/><path d="M10.2 20v-2.6a1.8 1.8 0 0 1 3.6 0V20"/><path d="M3.5 20V10l1-1.6 1 1.6v10"/><path d="M18.5 20V10l1-1.6 1 1.6v10"/>',
    quran: '<path class="d" d="M12 7.2c-2.1-1.3-4.6-1.7-7-1.4v9.6c2.4-.3 4.9.1 7 1.4 2.1-1.3 4.6-1.7 7-1.4V5.8c-2.4-.3-4.9.1-7 1.4Z"/><path d="M12 7.2c-2.1-1.3-4.6-1.7-7-1.4v9.6c2.4-.3 4.9.1 7 1.4 2.1-1.3 4.6-1.7 7-1.4V5.8c-2.4-.3-4.9.1-7 1.4Z"/><path d="M12 7.2v9.6"/><path d="M6 20.5l12-3.6M18 20.5 6 16.9"/>',
    book: '<path d="M12 6.5c-2.1-1.4-5-1.9-8-1.5v13.5c3-.4 5.9.1 8 1.5 2.1-1.4 5-1.9 8-1.5V5c-3-.4-5.9.1-8 1.5Z"/><path d="M12 6.5V20"/>',
    hadith: '<path class="d" d="M4 5h4v15H4zM9.5 7h4v13h-4z"/><path d="M4 5h4v15H4zM9.5 7h4v13h-4z"/><path d="M15 7.6l3.8-1 3.2 12.6-3.8 1z"/><path d="M4 9h4M9.5 11h4M4 16h4M9.5 16h4"/>',
    scroll: '<path class="d" d="M7 4h11a2 2 0 0 1 0 4H7z"/><path d="M7 4h11a2 2 0 0 1 0 4H7"/><path d="M7 4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h11V8"/><path d="M10 12h5M10 15.5h5"/>',
    amol: '<path class="d" d="M6 5h12v15H6z"/><path d="M9 4h6v3H9z"/><path d="M15 5.5h3V20H6V5.5h3"/><path d="M9 11.5l1.5 1.5 3-3"/><path d="M9 16.5h6"/>',
    dua: '<path class="d" d="M8.5 20v-4.5L5 11V6.2a1.4 1.4 0 0 1 2.8 0V11M15.5 20v-4.5L19 11V6.2a1.4 1.4 0 0 0-2.8 0V11"/><path d="M8.5 20v-4.5L5 11V6.2a1.4 1.4 0 0 1 2.8 0V10.5"/><path d="M7.8 9.5l2.4 2.6a2 2 0 0 1 .5 1.3V20"/><path d="M15.5 20v-4.5L19 11V6.2a1.4 1.4 0 0 0-2.8 0V10.5"/><path d="M16.2 9.5l-2.4 2.6a2 2 0 0 0-.5 1.3V20"/>',
    qibla: '<circle class="d" cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="9"/><path d="M12 3v2M21 12h-2M12 21v-2M3 12h2"/><path d="M14.8 9.2 13 13l-3.8 1.8L11 11z"/><rect class="f" x="10.6" y="6.3" width="2.8" height="2.8" rx=".4" transform="rotate(45 12 7.7)" opacity=".9"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    tasbih: '<circle class="d" cx="12" cy="11" r="6.5"/><circle cx="12" cy="4.5" r="1.6"/><circle cx="6.4" cy="7.4" r="1.6"/><circle cx="17.6" cy="7.4" r="1.6"/><circle cx="5.5" cy="13.4" r="1.6"/><circle cx="18.5" cy="13.4" r="1.6"/><circle cx="9" cy="17.2" r="1.6"/><circle cx="15" cy="17.2" r="1.6"/><path d="M12 17.5v2.2"/><path d="M10.6 21.2 12 19.7l1.4 1.5"/>',
    beads: '<circle cx="12" cy="5" r="2"/><circle cx="6" cy="9" r="2"/><circle cx="18" cy="9" r="2"/><circle cx="7" cy="16" r="2"/><circle cx="17" cy="16" r="2"/><path d="M12 18v3"/>',
    widget: '<rect class="d" x="4" y="4" width="7" height="7" rx="2"/><rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><path d="M16.5 13.5v6M13.5 16.5h6"/>',
    datecard: '<rect class="d" x="4" y="5" width="16" height="15" rx="3"/><rect x="4" y="5" width="16" height="15" rx="3"/><path d="M8 3v4M16 3v4M4 10h16"/><path d="M14.2 13.2a2.8 2.8 0 1 0 0 4.6 3.3 3.3 0 0 1 0-4.6Z"/>',
    zakat: '<ellipse class="d" cx="10" cy="7" rx="6" ry="2.5"/><ellipse cx="10" cy="7" rx="6" ry="2.5"/><path d="M4 7v4c0 1.4 2.7 2.5 6 2.5s6-1.1 6-2.5V7"/><path d="M4 11v4c0 1.4 2.7 2.5 6 2.5"/><circle cx="17" cy="16.5" r="4"/><path d="M17 15v3"/>',
    names: '<path class="d" d="M12 3l2.6 2.6H18v3.4l2.6 2.6-2.6 2.6V18h-3.4L12 20.6 9.4 18H6v-3.4L3.4 12 6 9.4V6h3.4z"/><path d="M12 3l2.6 2.6H18v3.4l2.6 2.6-2.6 2.6V18h-3.4L12 20.6 9.4 18H6v-3.4L3.4 12 6 9.4V6h3.4z"/><circle cx="12" cy="12" r="2.5"/>',
    kaaba: '<path class="d" d="M5 8l7-3 7 3v9l-7 3-7-3z"/><path d="M5 8l7-3 7 3v9l-7 3-7-3z"/><path d="M5 8l7 3 7-3M12 11v9"/><path d="M5 11l7 3 7-3"/>',

    /* ---- কাজ ---- */
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
    bell: '<path d="M6 9.5a6 6 0 1 1 12 0c0 4 1.2 5.4 2 6.4.3.4 0 1-.5 1h-15c-.5 0-.8-.6-.5-1 .8-1 2-2.4 2-6.4Z"/><path d="M10 19.5a2 2 0 0 0 4 0"/>',
    'bell-off': '<path d="M8.7 4.6A6 6 0 0 1 18 9.5c0 2.6.5 4 1.1 5"/><path d="M6.1 8.3C6 8.7 6 9.1 6 9.5c0 4-1.2 5.4-2 6.4-.3.4 0 1 .5 1H16"/><path d="M10 19.5a2 2 0 0 0 4 0"/><path d="M3.5 3.5l17 17"/>',
    gear: '<path d="M10.42 4.87 L10.75 2.48 L13.25 2.48 L13.58 4.87 L15.92 5.84 L17.84 4.38 L19.62 6.16 L18.16 8.08 L19.13 10.42 L21.52 10.75 L21.52 13.25 L19.13 13.58 L18.16 15.92 L19.62 17.84 L17.84 19.62 L15.92 18.16 L13.58 19.13 L13.25 21.52 L10.75 21.52 L10.42 19.13 L8.08 18.16 L6.16 19.62 L4.38 17.84 L5.84 15.92 L4.87 13.58 L2.48 13.25 L2.48 10.75 L4.87 10.42 L5.84 8.08 L4.38 6.16 L6.16 4.38 L8.08 5.84Z"/><circle cx="12" cy="12" r="3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    'check-circle': '<circle cx="12" cy="12" r="9"/><path d="M8 12.3l2.8 2.8L16.2 9.6"/>',
    edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6"/><path d="M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12"/><path d="M9 7V4h6v3"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
    download: '<path d="M12 4v11M7 10.5l5 5 5-5"/><path d="M5 20h14"/>',
    upload: '<path d="M12 16V5M7 9.5l5-5 5 5"/><path d="M5 20h14"/>',
    cloud: '<path d="M7 18.5a4.5 4.5 0 0 1-.6-9 6 6 0 0 1 11.4 1.6A3.8 3.8 0 0 1 17.5 18.5z"/>',
    'cloud-check': '<path d="M7 18.5a4.5 4.5 0 0 1-.6-9 6 6 0 0 1 11.4 1.6A3.8 3.8 0 0 1 17.5 18.5z"/><path d="M9.5 13.7l1.8 1.8 3.4-3.4"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14.3-4.6L4 8.5"/><path d="M4 4v4.5h4.5"/><path d="M4 13a8 8 0 0 0 14.3 4.6l1.7-2.1"/><path d="M20 20v-4.5h-4.5"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
    filter: '<path d="M4 5h16l-6 7.5V19l-4 1.5v-8z"/>',
    sort: '<path d="M7 4v16M3.5 16.5 7 20l3.5-3.5M17 20V4M13.5 7.5 17 4l3.5 3.5"/>',
    bookmark: '<path d="M6 4h12v17l-6-4-6 4z"/>',
    'bookmark-on': '<path class="f" d="M6 4h12v17l-6-4-6 4z"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 7.5 3c0 5.4-7.5 10-7.5 10Z"/>',
    'heart-on': '<path class="f" d="M12 20s-7.5-4.6-7.5-10A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 7.5 3c0 5.4-7.5 10-7.5 10Z"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
    'star-on': '<path class="f" d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3"/>',
    'eye-off': '<path d="M4 4l16 16"/><path d="M9.9 6A9.8 9.8 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-3 3.8M6.3 7.6A17 17 0 0 0 2.5 12S6 18.5 12 18.5a9.6 9.6 0 0 0 4.4-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
    'zoom-in': '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2M11 8.5v5M8.5 11h5"/>',
    'text-size': '<path d="M4 18 8.5 6h1L14 18M5.6 14h6.8"/><path d="M15 18l2.8-7.5h.6L21 18M15.9 15.6h4.4"/>',
    list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle class="f" cx="4.5" cy="6" r="1.3"/><circle class="f" cx="4.5" cy="12" r="1.3"/><circle class="f" cx="4.5" cy="18" r="1.3"/>',
    grid: '<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',

    /* ---- মিডিয়া ---- */
    play: '<path class="f" d="M7 5.2v13.6a1 1 0 0 0 1.5.9l10.6-6.8a1 1 0 0 0 0-1.8L8.5 4.3A1 1 0 0 0 7 5.2Z"/>',
    pause: '<rect class="f" x="6" y="5" width="4" height="14" rx="1.2"/><rect class="f" x="14" y="5" width="4" height="14" rx="1.2"/>',
    next: '<path class="f" d="M5 6.2v11.6a1 1 0 0 0 1.5.8l8.7-5.8a1 1 0 0 0 0-1.6L6.5 5.4A1 1 0 0 0 5 6.2Z"/><path d="M19 5v14"/>',
    prev: '<path class="f" d="M19 6.2v11.6a1 1 0 0 1-1.5.8l-8.7-5.8a1 1 0 0 1 0-1.6l8.7-5.8a1 1 0 0 1 1.5.8Z"/><path d="M5 5v14"/>',
    repeat: '<path d="M17 3l3 3-3 3"/><path d="M20 6H8a4 4 0 0 0-4 4v1M7 21l-3-3 3-3"/><path d="M4 18h12a4 4 0 0 0 4-4v-1"/>',
    volume: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    'volume-off': '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    headphones: '<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3.5" y="14" width="4" height="6.5" rx="1.6"/><rect x="16.5" y="14" width="4" height="6.5" rx="1.6"/>',
    vibrate: '<rect x="8" y="4" width="8" height="16" rx="2"/><path d="M4.5 8.5v7M19.5 8.5v7M2 10.5v3M22 10.5v3"/>',

    /* ---- সময় ও প্রকৃতি ---- */
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    alarm: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9.5V13l2.3 1.6M4 5l3-2.5M20 5l-3-2.5"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M8 3v4M16 3v4M4 10h16"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5Z"/>',
    crescent: '<path class="f" d="M15.5 3.6A8.6 8.6 0 1 0 20.4 17 7 7 0 1 1 15.5 3.6Z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
    'sun-moon': '<path d="M12 3a9 9 0 1 0 0 18z" class="f"/><circle cx="12" cy="12" r="9"/>',
    sunrise: '<path d="M4 18h16M7 14.5a5 5 0 0 1 10 0"/><path d="M12 3v4M9.5 5.5 12 3l2.5 2.5M3.5 11l1.6 1M20.5 11l-1.6 1M6 21h12"/>',
    sunset: '<path d="M4 18h16M7 14.5a5 5 0 0 1 10 0"/><path d="M12 3v4M9.5 4.5 12 7l2.5-2.5M3.5 11l1.6 1M20.5 11l-1.6 1M6 21h12"/>',
    fajr: '<path d="M3 17h18M6.5 17a5.5 5.5 0 0 1 11 0"/><path d="M16 4.5a3.2 3.2 0 1 0 3.5 4.7 2.6 2.6 0 0 1-3.5-4.7Z"/><path d="M7 21h10"/>',
    location: '<path d="M12 21s-6.5-6.1-6.5-11a6.5 6.5 0 0 1 13 0c0 4.9-6.5 11-6.5 11Z"/><circle cx="12" cy="10" r="2.4"/>',
    gps: '<circle cx="12" cy="12" r="6"/><circle class="f" cx="12" cy="12" r="2.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3"/>',
    fire: '<path class="d" d="M12 21a6 6 0 0 0 6-6c0-4-3-6.5-4-10-1.5 2-2 3.5-2 5-1-1-1.6-2-1.7-3.4C8 8.5 6 11.3 6 15a6 6 0 0 0 6 6Z"/><path d="M12 21a6 6 0 0 0 6-6c0-4-3-6.5-4-10-1.5 2-2 3.5-2 5-1-1-1.6-2-1.7-3.4C8 8.5 6 11.3 6 15a6 6 0 0 0 6 6Z"/><path d="M12 21a2.5 2.5 0 0 1-2.5-2.5c0-1.6 1.4-2.4 2.5-4 1.1 1.6 2.5 2.4 2.5 4A2.5 2.5 0 0 1 12 21Z"/>',
    chart: '<path d="M4 20h16"/><rect x="5.5" y="11" width="3" height="6" rx="1"/><rect x="10.5" y="6" width="3" height="11" rx="1"/><rect x="15.5" y="13" width="3" height="4" rx="1"/>',
    trend: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle class="f" cx="12" cy="12" r="1.6"/>',
    sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4"/><path class="f" d="M12 8.5l1.2 2.3 2.3 1.2-2.3 1.2L12 15.5l-1.2-2.3L8.5 12l2.3-1.2z"/>',

    /* ---- অ্যাকাউন্ট ও প্রিমিয়াম ---- */
    user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
    'user-circle': '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.7 18.4a6 6 0 0 1 10.6 0"/>',
    mail: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/><circle class="f" cx="12" cy="15.5" r="1.4"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16.5 6.5l2.5 2.5M14 9l2 2"/>',
    logout: '<path d="M12 3v8.5"/><path d="M7.05 6.6a8 8 0 1 0 9.9 0"/>',
    crown: '<path class="d" d="M4 8l4 4 4-6.5L16 12l4-4-1.5 10h-13z"/><path d="M4 8l4 4 4-6.5L16 12l4-4-1.5 10h-13z"/><path d="M6 20.5h12"/>',
    shield: '<path d="M12 3 5 6v5.5c0 4.4 3 8 7 9.5 4-1.5 7-5.1 7-9.5V6z"/><path d="M9 12l2 2 4-4"/>',
    gift: '<rect x="4" y="9" width="16" height="11" rx="2"/><path d="M3 9h18v-.5a1.5 1.5 0 0 0-1.5-1.5h-15A1.5 1.5 0 0 0 3 8.5zM12 7v13"/><path d="M12 7c-1.5-3-5-3.5-5-1.5S10 7 12 7Zm0 0c1.5-3 5-3.5 5-1.5S14 7 12 7Z"/>',
    ad: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M7 15l2.2-6h.6L12 15M7.8 13h3.4M14.5 9v6h1.2a2.6 2.6 0 0 0 0-6z"/>',
    'no-ad': '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M4 4l16 16"/>',
    card: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3 10h18M7 15h3"/>',
    wallet: '<path d="M4 7.5V18a2 2 0 0 0 2 2h13a1 1 0 0 0 1-1v-3"/><path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H17v2.5"/><path d="M4 7.5h15a1 1 0 0 1 1 1V12h-4a2 2 0 0 0 0 4h4"/>',
    google: '<path class="f" fill="#4285F4" d="M21.6 12.2c0-.7-.1-1.4-.2-2H12v3.8h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3Z" style="opacity:1;fill:#4285F4"/><path class="f" d="M12 22c2.7 0 5-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22Z" style="opacity:1;fill:#34A853"/><path class="f" d="M6.4 14c-.2-.6-.3-1.3-.3-2s.1-1.4.3-2V7.4H3.1A10 10 0 0 0 2 12c0 1.6.4 3.1 1.1 4.6z" style="opacity:1;fill:#FBBC05"/><path class="f" d="M12 6c1.5 0 2.8.5 3.8 1.5l2.9-2.9A10 10 0 0 0 3.1 7.4L6.4 10C7.2 7.7 9.4 6 12 6Z" style="opacity:1;fill:#EA4335"/>',

    /* ---- অবস্থা ---- */
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5"/><circle class="f" cx="12" cy="7.8" r="1.2"/>',
    alert: '<path d="M10.3 4.3 2.8 17.5A2 2 0 0 0 4.5 20.5h15a2 2 0 0 0 1.7-3L13.7 4.3a2 2 0 0 0-3.4 0Z"/><path d="M12 9.5v4.5"/><circle class="f" cx="12" cy="17" r="1.1"/>',
    wifi_off: '<path d="M3 3l18 18M8.5 16.4a5 5 0 0 1 7 0M5 12.9a10 10 0 0 1 4.3-2.4M19 12.9a10 10 0 0 0-2.4-1.7M2 9.4a15 15 0 0 1 4.3-2.6M22 9.4A15 15 0 0 0 11 5.1"/><circle class="f" cx="12" cy="19.5" r="1.1"/>',
    battery: '<rect x="3" y="7" width="16" height="10" rx="2.5"/><path d="M21 10.5v3"/><rect class="f" x="5.5" y="9.5" width="7" height="5" rx="1"/>',
    phone: '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>',
    palette: '<path d="M12 3a9 9 0 0 0 0 18c1.2 0 1.8-.8 1.8-1.7 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-1 .8-1.7 1.7-1.7H16a5 5 0 0 0 5-5c0-4-4-7.2-9-7.2Z"/><circle class="f" cx="7.5" cy="11" r="1.3"/><circle class="f" cx="10" cy="7.3" r="1.3"/><circle class="f" cx="14.5" cy="7.3" r="1.3"/>'
  };

  function icon(name, extra, label) {
    var body = I[name];
    if (!body) { body = I.info; if (W.console) console.warn('[PT] অজানা আইকন:', name); }
    return '<svg class="pt-ic' + (extra ? ' ' + extra : '') + '" viewBox="0 0 24 24" ' +
      (label ? 'role="img" aria-label="' + label + '"' : 'aria-hidden="true"') + ' focusable="false">' + body + '</svg>';
  }
  function hydrate(root) {
    var els = (root || document).querySelectorAll('i[data-ic]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      el.outerHTML = icon(el.getAttribute('data-ic'), el.className, el.getAttribute('aria-label'));
    }
  }
  var PT = W.PT = W.PT || {};
  PT.icon = icon; PT.icons = I; PT.hydrateIcons = hydrate;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { hydrate(); });
  else hydrate();
})(window);

/* পাথেয় — কম্পোনেন্টের আচরণ ও মোশন (কোনো লাইব্রেরি ছাড়া, ~৫KB)।
   সব সময়/ইজিং CSS টোকেন থেকে আসে; এখানে শুধু ক্লাস যোগ/বাদ।
   API (window.PT):
     PT.seg(el) / PT.tabs(el)         — সেগমেন্ট/ট্যাবের চলমান নির্দেশক; 'pt:change' ইভেন্ট দেয় (detail.index)
     PT.header(headerEl, scrollEl?)   — স্ক্রল করলে হেডার ছোট হয়
     PT.sheet.open(sheetEl) / close   — বটম-শিট (নিচে টানলে বন্ধ, ব্যাক বাটনে বন্ধ)
     PT.dialog({title, body, icon, ok, cancel, danger}) → Promise<boolean>
     PT.toast(text, {type, action, onAction, ms})
     PT.menu(anchorEl, items[])       — ⋯ মেনু; items: {icon, label, onClick} বা '-' (বিভাজক)
     PT.reveal(root?)                 — data-pt-reveal উপাদান ধাপে ধাপে ঢোকে
     PT.haptic(kind)                  — হালকা কম্পন ('light' | 'success' | 'warn')
     PT.slider(el)                    — স্লাইডারের ভরাট অংশ
     PT.init(root?)                   — পেজের সব কম্পোনেন্ট একবারে চালু
*/
(function (W, D) {
  var PT = W.PT = W.PT || {};
  var reduce = !!(W.matchMedia && W.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function cssMs(name, fb) {
    var v = getComputedStyle(D.documentElement).getPropertyValue(name).trim();
    var n = parseFloat(v); return isNaN(n) ? fb : n;
  }
  function closeAfter(el, cb) {               /* is-closing অ্যানিমেশন শেষ হলে সরাও */
    var ms = reduce ? 0 : cssMs('--pt-dur-2', 220);
    el.classList.add('is-closing');
    setTimeout(function () { el.classList.remove('is-closing'); cb && cb(); }, ms);
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- হ্যাপটিক ---------- */
  PT.haptic = function (kind) {
    var ms = kind === 'success' ? [12, 40, 12] : kind === 'warn' ? [30, 30, 30] : 10;
    try { if (W.PatheyoHaptics && W.PatheyoHaptics.vibrate) { W.PatheyoHaptics.vibrate(String(kind || 'light')); return; } } catch (e) {}
    try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {}
  };

  /* ---------- সেগমেন্ট ও ট্যাব: চলমান নির্দেশক ---------- */
  function slider(el, btnSel, inkSel, inkCls, useText) {
    if (!el || el.__pt) return; el.__pt = 1;
    var btns = [].slice.call(el.querySelectorAll(btnSel));
    var ink = el.querySelector(inkSel);
    if (!ink) { ink = D.createElement('span'); ink.className = inkCls; ink.setAttribute('aria-hidden', 'true'); el.insertBefore(ink, el.firstChild); }
    el.setAttribute('role', 'tablist');
    function place(i, instant) {
      var b = btns[i]; if (!b) return;
      if (instant) { ink.style.transition = 'none'; }
      var w = b.offsetWidth, x = b.offsetLeft;
      if (useText) { var t = b.scrollWidth; w = Math.min(w, t); }
      ink.style.width = w + 'px';
      ink.style.transform = 'translateX(' + (x - (useText ? 0 : 4)) + 'px)';
      if (instant) { void ink.offsetWidth; ink.style.transition = ''; }
    }
    function select(i, silent) {
      btns.forEach(function (b, k) { b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', k === i ? 'true' : 'false'); b.tabIndex = k === i ? 0 : -1; });
      place(i);
      if (useText && btns[i] && btns[i].scrollIntoView) { try { btns[i].scrollIntoView({ block: 'nearest', inline: 'center', behavior: reduce ? 'auto' : 'smooth' }); } catch (e) {} }
      if (!silent) { PT.haptic('light'); el.dispatchEvent(new CustomEvent('pt:change', { detail: { index: i, button: btns[i] } })); }
    }
    btns.forEach(function (b, i) { b.addEventListener('click', function () { if (b.getAttribute('aria-selected') !== 'true') select(i); }); });
    var start = Math.max(0, btns.findIndex(function (b) { return b.getAttribute('aria-selected') === 'true'; }));
    select(start, true); requestAnimationFrame(function () { place(start, true); });
    if (W.ResizeObserver) new ResizeObserver(function () { var c = btns.findIndex(function (b) { return b.getAttribute('aria-selected') === 'true'; }); place(Math.max(0, c), true); }).observe(el);
    el.ptSelect = select;
  }
  PT.seg = function (el) { slider(el, '.pt-seg__btn', '.pt-seg__thumb', 'pt-seg__thumb', false); };
  PT.tabs = function (el) { slider(el, '.pt-tabs__btn', '.pt-tabs__ink', 'pt-tabs__ink', true); };

  /* ---------- হেডার: স্ক্রলে ছোট ---------- */
  PT.header = function (h, scroller) {
    if (!h || h.__pt) return; h.__pt = 1;
    var s = scroller || W, ticking = false;
    function y() { return s === W ? (W.scrollY || D.documentElement.scrollTop) : s.scrollTop; }
    function upd() { ticking = false; h.classList.toggle('is-compact', y() > 12); }
    s.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(upd); } }, { passive: true });
    upd();
  };

  /* ---------- বটম-শিট ---------- */
  var openSheets = [];
  PT.sheet = {
    open: function (sheet) {
      if (!sheet || !sheet.hidden && sheet.__open) return;
      var scrim = D.createElement('div'); scrim.className = 'pt-scrim';
      sheet.parentNode.insertBefore(scrim, sheet);
      sheet.hidden = false; sheet.__open = true; sheet.__scrim = scrim;
      sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-modal', 'true');
      scrim.addEventListener('click', function () { PT.sheet.close(sheet); });
      openSheets.push(sheet);
      var f = sheet.querySelector('[autofocus]'); if (f) setTimeout(function () { try { f.focus({ preventScroll: true }); } catch (e) {} }, 50);   /* টাচে অকারণ ফোকাস-রিং নয় */
      sheet.dispatchEvent(new CustomEvent('pt:open'));
    },
    close: function (sheet) {
      sheet = sheet || openSheets[openSheets.length - 1];
      if (!sheet || !sheet.__open) return;
      sheet.__open = false; openSheets.splice(openSheets.indexOf(sheet), 1);
      var scrim = sheet.__scrim;
      sheet.style.transform = '';
      if (scrim) closeAfter(scrim, function () { scrim.remove(); });
      closeAfter(sheet, function () { sheet.hidden = true; sheet.dispatchEvent(new CustomEvent('pt:close')); });
    },
    isOpen: function () { return openSheets.length > 0; }
  };
  function dragToClose(sheet) {
    if (sheet.__drag) return; sheet.__drag = 1;
    var y0 = null, dy = 0, t0 = 0;
    sheet.addEventListener('touchstart', function (e) {
      var body = sheet.querySelector('.pt-sheet__body');
      if (body && body.contains(e.target) && body.scrollTop > 0) { y0 = null; return; }
      y0 = e.touches[0].clientY; dy = 0; t0 = Date.now(); sheet.style.transition = 'none';
    }, { passive: true });
    sheet.addEventListener('touchmove', function (e) {
      if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0);
      sheet.style.transform = dy ? 'translateY(' + dy + 'px)' : '';
    }, { passive: true });
    sheet.addEventListener('touchend', function () {
      if (y0 == null) return; y0 = null; sheet.style.transition = '';
      var fast = dy > 40 && (Date.now() - t0) < 250;
      if (dy > sheet.offsetHeight * 0.3 || fast) PT.sheet.close(sheet); else sheet.style.transform = '';
    });
  }

  /* ---------- ডায়লগ ---------- */
  PT.dialog = function (o) {
    o = o || {};
    return new Promise(function (resolve) {
      var scrim = D.createElement('div'); scrim.className = 'pt-scrim pt-dialog-scrim';
      var d = D.createElement('div'); d.className = 'pt-dialog'; d.setAttribute('role', 'alertdialog'); d.setAttribute('aria-modal', 'true');
      d.innerHTML = (o.icon ? '<div class="pt-dialog__icon pt-medal' + (o.danger ? ' pt-dialog__icon--danger' : '') + '">' + PT.icon(o.icon, 'pt-ic--lg') + '</div>' : '') +
        '<h2 class="pt-dialog__title">' + esc(o.title) + '</h2>' + (o.body ? '<p class="pt-dialog__body">' + esc(o.body) + '</p>' : '') +
        '<div class="pt-dialog__actions">' + (o.cancel === false ? '' : '<button class="pt-btn pt-btn--secondary" data-v="0">' + esc(o.cancel || 'বাতিল') + '</button>') +
        '<button class="pt-btn' + (o.danger ? ' pt-btn--danger' : '') + '" data-v="1">' + esc(o.ok || 'ঠিক আছে') + '</button></div>';
      D.body.appendChild(scrim); D.body.appendChild(d);
      var done = function (v) { closeAfter(scrim, function () { scrim.remove(); }); closeAfter(d, function () { d.remove(); }); PT.__back = null; resolve(v); };
      d.addEventListener('click', function (e) { var b = e.target.closest('[data-v]'); if (b) done(b.getAttribute('data-v') === '1'); });
      scrim.addEventListener('click', function () { done(false); });
      PT.__back = function () { done(false); return true; };
      setTimeout(function () { var b = d.querySelector('[data-v="1"]'); if (b) b.focus(); }, 30);
      PT.haptic(o.danger ? 'warn' : 'light');
    });
  };

  /* ---------- টোস্ট ---------- */
  PT.toast = function (text, o) {
    o = o || {};
    var host = D.querySelector('.pt-toasts');
    if (!host) { host = D.createElement('div'); host.className = 'pt-toasts'; host.setAttribute('role', 'status'); host.setAttribute('aria-live', 'polite'); D.body.appendChild(host); }
    var t = D.createElement('div'); t.className = 'pt-toast' + (o.type ? ' pt-toast--' + o.type : '');
    var ic = o.type === 'success' ? 'check-circle' : o.type === 'danger' ? 'alert' : o.icon;
    t.innerHTML = (ic ? PT.icon(ic) : '') + '<span>' + esc(text) + '</span>' + (o.action ? '<button class="pt-toast__action">' + esc(o.action) + '</button>' : '');
    host.appendChild(t);
    var gone = false, kill = function () { if (gone) return; gone = true; closeAfter(t, function () { t.remove(); }); };
    if (o.action) t.querySelector('.pt-toast__action').addEventListener('click', function () { kill(); o.onAction && o.onAction(); });
    setTimeout(kill, o.ms || (o.action ? 5000 : 2600));
    if (o.type === 'success') PT.haptic('success');
    return kill;
  };

  /* ---------- মেনু ---------- */
  var curMenu = null;
  function closeMenu() { if (!curMenu) return; var m = curMenu; curMenu = null; closeAfter(m, function () { m.remove(); }); }
  PT.menu = function (anchor, items) {
    if (curMenu) { closeMenu(); return; }
    var m = D.createElement('div'); m.className = 'pt-menu'; m.setAttribute('role', 'menu');
    items.forEach(function (it, i) {
      if (it === '-') { m.insertAdjacentHTML('beforeend', '<div class="pt-menu__sep"></div>'); return; }
      var b = D.createElement('button'); b.className = 'pt-menu__item'; b.setAttribute('role', 'menuitem');
      b.innerHTML = (it.icon ? PT.icon(it.icon) : '') + '<span>' + esc(it.label) + '</span>' + (it.toggle != null ? '<span class="pt-switch"><input type="checkbox" tabindex="-1"' + (it.toggle ? ' checked' : '') + '><span class="pt-switch__track"></span></span>' : '');
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        if (it.toggle != null) { var c = b.querySelector('input'); if (e.target !== c) c.checked = !c.checked; it.onClick && it.onClick(c.checked); return; }
        closeMenu(); it.onClick && it.onClick();
      });
      m.appendChild(b);
    });
    D.body.appendChild(m);
    var r = anchor.getBoundingClientRect(), vw = D.documentElement.clientWidth;
    m.style.top = (r.bottom + 6) + 'px';
    m.style.right = Math.max(8, vw - r.right) + 'px';
    curMenu = m;
    setTimeout(function () { D.addEventListener('click', function h(e) { if (curMenu && !curMenu.contains(e.target)) { D.removeEventListener('click', h, true); closeMenu(); } }, true); }, 0);
  };

  /* ---------- প্রবেশ অ্যানিমেশন (ধাপে ধাপে) ---------- */
  PT.reveal = function (root) {
    var els = [].slice.call((root || D).querySelectorAll('[data-pt-reveal]:not(.is-in)'));
    if (!els.length) return;
    if (reduce || !W.IntersectionObserver) { els.forEach(function (e) { e.classList.add('is-in'); }); return; }
    var step = 50, batch = 0, last = 0;
    var io = new IntersectionObserver(function (ents) {
      var now = Date.now(); if (now - last > 120) batch = 0; last = now;
      ents.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.style.setProperty('--pt-delay', Math.min(batch++, 8) * step + 'ms');
        en.target.classList.add('is-in'); io.unobserve(en.target);
      });
    }, { rootMargin: '0px 0px -8% 0px' });
    els.forEach(function (e) { io.observe(e); });
  };

  /* ---------- স্লাইডার ---------- */
  PT.slider = function (el) {
    if (!el || el.__pt) return; el.__pt = 1;
    function f() { var mn = +el.min || 0, mx = +el.max || 100; el.style.setProperty('--pt-fill', ((el.value - mn) / (mx - mn) * 100) + '%'); }
    el.addEventListener('input', f); f();
  };

  /* ---------- অ্যান্ড্রয়েড ব্যাক বাটন: আগে খোলা মেনু/ডায়লগ/শিট বন্ধ ---------- */
  PT.handleBack = function () {
    if (curMenu) { closeMenu(); return true; }
    if (PT.__back && PT.__back()) return true;
    if (openSheets.length) { PT.sheet.close(); return true; }
    return false;
  };

  /* ---------- সব একসাথে ---------- */
  PT.init = function (root) {
    root = root || D;
    [].forEach.call(root.querySelectorAll('.pt-seg'), PT.seg);
    [].forEach.call(root.querySelectorAll('.pt-tabs'), PT.tabs);
    [].forEach.call(root.querySelectorAll('.pt-slider'), PT.slider);
    var h = root.querySelector('.pt-header[data-pt-compact]'); if (h) PT.header(h);
    PT.reveal(root);
  };
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', function () { PT.init(); }); else PT.init();
})(window, document);
