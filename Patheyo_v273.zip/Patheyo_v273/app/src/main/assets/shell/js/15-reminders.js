/* =============================================================================
   ধাপ ১১: স্মার্ট রিমাইন্ডার — প্রতিটি বিষয় আলাদা অন/অফ (মাঝখানের পপআপ #rm-sheet)
   নেটিভ: window.PatheyoReminders.get()/set(json) — reminder/SmartReminders.kt (দল ধরে আগের ইসলামিক নোটিফিকেশনও
   নিয়ন্ত্রণ করে; ঘুমের আগের রিমাইন্ডার নতুন)। ব্রাউজারে (ব্রিজ নেই) localStorage 'pt_reminders'-এ রাখে।
   খোলে: সেটিংসের "রিমাইন্ডার" সারি, হোমের "দরকারি" সারি, সার্চ, __ptGo('reminders'), অনবোর্ডিংয়ের শেষ ধাপ।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, $ = function (id) { return D.getElementById(id); };
  var sheet = $('rm-sheet'), list = $('rm-list'); if (!sheet || !list) return;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  function ic(n, c) { return window.PT ? PT.icon(n, c || '') : ''; }

  /* [কী, শিরোনাম, কখন আসে, আইকন] — ক্রম: মানুষ যেটি বেশি চায় আগে */
  var ITEMS = [
    ['kahf', 'জুমার দিন সূরা কাহফ', 'শুক্রবার সকালে · চাপলেই সূরা কাহফ খোলে', 'quran'],
    ['monthu', 'সোম ও বৃহস্পতিবারের রোজা', 'আগের রাত ৯টায় — সেহরির নিয়তের জন্য', 'moon'],
    ['ayyam', 'আইয়ামে বিযের রোজা', 'হিজরি ১৩, ১৪, ১৫ তারিখের আগের রাতে (রমজান বাদে)', 'crescent'],
    ['sleep', 'ঘুমের আগের দোয়া ও আমল', '', 'sun-moon'],
    ['zikr', 'সকাল-সন্ধ্যার জিকির', 'সূর্যোদয় ও সূর্যাস্তে', 'sunrise'],
    ['islamic', 'ইসলামিক দিন ও মাস', 'আশুরা, শবে কদর, রমজান, ঈদ, আরাফা…', 'calendar'],
    ['national', 'বাংলা মাস ও জাতীয় দিবস', 'পহেলা বৈশাখ, ২১ ফেব্রুয়ারি, বিজয় দিবস…', 'bell']
  ];
  var DEF = { kahf: true, monthu: true, ayyam: true, zikr: true, islamic: true, national: true, sleep: false, sleepTime: '22:30' };
  var LK = 'pt_reminders';

  function nat() { var b = window.PatheyoReminders; return b && typeof b.get === 'function' ? b : null; }
  function load() {
    var o = {};
    try { o = nat() ? JSON.parse(nat().get() || '{}') : JSON.parse(localStorage.getItem(LK) || '{}'); } catch (e) { o = {}; }
    var r = {}; for (var k in DEF) r[k] = o[k] == null ? DEF[k] : o[k]; return r;
  }
  function save(o) {
    var s = JSON.stringify(o);
    try { if (nat()) nat().set(s); else localStorage.setItem(LK, s); } catch (e) {}
  }
  function t12(hm) {
    var p = String(hm || '22:30').split(':'), h = +p[0], m = p[1] || '00';
    var part = h < 4 ? 'রাত' : h < 6 ? 'ভোর' : h < 12 ? 'সকাল' : h < 15 ? 'দুপুর' : h < 18 ? 'বিকাল' : h < 20 ? 'সন্ধ্যা' : 'রাত';
    return part + ' ' + bn((h % 12 || 12) + ':' + m);
  }

  function notifOk() {
    try { var b = window.AndroidWidgetBridge; if (b && b.checkAllPermissionsStatus) return !!JSON.parse(b.checkAllPermissionsStatus()).notification; } catch (e) {}
    return true;
  }

  function render() {
    var o = load();
    list.innerHTML = ITEMS.map(function (it) {
      var on = !!o[it[0]];
      var sub = it[0] === 'sleep'
        ? '<span class="rm-s">প্রতিদিন <button type="button" class="rm-time" id="rm-time-btn"' + (on ? '' : ' disabled') + '>' + t12(o.sleepTime) + '</button> · চাপলে ঘুমের দোয়া খোলে</span>'
        : '<span class="rm-s">' + it[2] + '</span>';
      return '<div class="rm-row' + (on ? ' on' : '') + '"><span class="pt-medal rm-medal">' + ic(it[3]) + '</span>' +
        '<span class="rm-tx"><span class="rm-t">' + it[1] + '</span>' + sub + '</span>' +
        '<label class="pt-switch" aria-label="' + it[1] + '"><input type="checkbox" data-rm="' + it[0] + '"' + (on ? ' checked' : '') + '><span class="pt-switch__track"></span></label></div>';
    }).join('') + '<input type="time" id="rm-time" class="rm-time-in" value="' + (o.sleepTime || '22:30') + '" tabindex="-1" aria-hidden="true">';
    $('rm-perm').hidden = notifOk();
  }

  list.addEventListener('change', function (e) {
    var k = e.target.getAttribute && e.target.getAttribute('data-rm');
    if (k) {
      var o = load(); o[k] = !!e.target.checked; save(o);
      if (window.PT && PT.haptic) PT.haptic('light');
      var row = e.target.closest('.rm-row'); if (row) row.classList.toggle('on', o[k]);
      var tb = $('rm-time-btn'); if (k === 'sleep' && tb) tb.disabled = !o[k];
      if (window.PT) PT.toast(o[k] ? 'চালু হলো — সময়মতো মনে করিয়ে দেওয়া হবে, ইনশাআল্লাহ' : 'বন্ধ হলো — এটি আর আসবে না', { type: o[k] ? 'success' : '' });
      return;
    }
    if (e.target.id === 'rm-time' && e.target.value) {
      var o2 = load(); o2.sleepTime = e.target.value; save(o2); render();
      if (window.PT) PT.toast('ঘুমের আগের রিমাইন্ডার ' + t12(o2.sleepTime) + '-এ', { type: 'success' });
    }
  });
  list.addEventListener('click', function (e) {
    if (!(e.target.closest && e.target.closest('#rm-time-btn'))) return;
    var ti = $('rm-time');
    try { if (ti.showPicker) ti.showPicker(); else ti.click(); } catch (er) { ti.click(); }
  });
  sheet.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('[data-rm-close]')) { if (window.PT) PT.sheet.close(sheet); }
    if (e.target.closest && e.target.closest('#rm-perm-btn')) {
      try { window.AndroidWidgetBridge.requestNotificationPermission(); } catch (er) {}
      setTimeout(render, 1500);
    }
  });

  window.ptOpenReminders = function () { render(); if (window.PT) PT.sheet.open(sheet); };
  window.__ptReminders = { load: load, save: save, ITEMS: ITEMS };   /* অনবোর্ডিং ব্যবহার করে */

  /* সেটিংসের সারির ছোট লেখা: কয়টি চালু */
  function paintRow() {
    var s = $('st-rm-s'); if (!s) return;
    var o = load(), n = ITEMS.filter(function (it) { return o[it[0]]; }).length;
    s.textContent = bn(n) + 'টি চালু · কাহফ, রোজা, ঘুমের দোয়া — শুধু আপনার বেছে নেওয়াগুলো';
  }
  var row = $('st-rm-row');
  if (row) row.addEventListener('click', window.ptOpenReminders);
  sheet.addEventListener('pt:close', paintRow);
  var so = $('settings-overlay');
  if (so && window.MutationObserver) new MutationObserver(paintRow).observe(so, { attributes: true, attributeFilter: ['class'] });
  paintRow();
})();
