/* =============================================================================
   ধাপ ১১: যাকাত ক্যালকুলেটর — সোনা/রুপা/নগদ/ব্যবসা/পাওনা/বিনিয়োগ − ঋণ → নিসাব যাচাই → ২.৫%
   পেজ: index.html-এর #zakat-overlay (কন্ট্রোলারে 'zakat')। খোলে হোমের "দরকারি" সারি, গ্লোবাল সার্চ বা __ptGo('zakat') থেকে।
   নিসাব (হানাফি মত, বাংলাদেশে প্রচলিত): সোনা ৭.৫ ভরি (৮৭.৪৮ গ্রাম) · রুপা ৫২.৫ ভরি (৬১২.৩৬ গ্রাম); ১ ভরি = ১১.৬৬৪ গ্রাম।
     "স্বয়ংক্রিয়": শুধু সোনা থাকলে (আর কোনো যাকাতযোগ্য সম্পদ নেই) সোনার নিসাব; মিশ্র সম্পদে রুপার নিসাব
                   (দুটির মধ্যে যেটি কম — গরিবের জন্য বেশি উপকারী, অধিকাংশ আলেমের পরামর্শ)।
   সোনা-রুপার দাম ইন্টারনেট থেকে আনা হয় না (অফলাইন ও নির্ভুল থাকার জন্য) — ব্যবহারকারী বাজুসের আজকের দাম দেখে বসান, মনে থাকে।
   সব তথ্য শুধু এই ফোনে: localStorage 'pt_zakat'।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, $ = function (id) { return D.getElementById(id); };
  var body = $('zk-body'); if (!body) return;
  var KEY = 'pt_zakat', VORI_G = 11.664, NISAB_GOLD_V = 7.5, NISAB_SILVER_V = 52.5;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  function ic(n, c) { return window.PT ? PT.icon(n, c || '') : ''; }
  function num(v) { v = String(v == null ? '' : v).replace(/[০-৯]/g, function (d) { return BN.indexOf(d); }).replace(/[,\s৳]/g, ''); var n = parseFloat(v); return isFinite(n) && n > 0 ? n : 0; }
  /* ১২,৩৪,৫৬৭ (দেশি কমা) */
  function taka(n) {
    n = Math.round(n || 0); var s = String(Math.abs(n)), last = s.slice(-3), rest = s.slice(0, -3);
    if (rest) last = ',' + last;
    rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    return (n < 0 ? '−' : '') + '৳' + bn(rest + last);
  }
  function wt(v, unit) { return bn((Math.round(v * 100) / 100).toString()) + ' ' + (unit === 'g' ? 'গ্রাম' : 'ভরি'); }

  var FIELDS = [
    ['cash', 'নগদ টাকা', 'হাতে, ব্যাংকে ও মোবাইল ব্যাংকিংয়ে (বিকাশ/নগদ)', 'wallet'],
    ['business', 'ব্যবসার পণ্য', 'বিক্রির জন্য রাখা মাল — আজকের বিক্রয়মূল্যে', 'card'],
    ['receivable', 'পাওনা টাকা', 'যা ফেরত পাওয়ার আশা আছে', 'undo'],
    ['invest', 'সঞ্চয় ও বিনিয়োগ', 'ডিপিএস, এফডিআর, সঞ্চয়পত্র, শেয়ার, বৈদেশিক মুদ্রা', 'trend']
  ];
  var DEF = { unit: 'v', basis: 'auto', goldPrice: '', silverPrice: '', gold: '', karat: 22, silver: '', cash: '', business: '', receivable: '', invest: '', debt: '' };
  var st = (function () { try { var o = JSON.parse(localStorage.getItem(KEY) || '{}'); var r = {}; for (var k in DEF) r[k] = o[k] == null ? DEF[k] : o[k]; return r; } catch (e) { return JSON.parse(JSON.stringify(DEF)); } })();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} }

  /* v268: ইনপুট এখন পুরো-প্রস্থের বক্স (ওপরে আইকন+নাম+সাহায্য, নিচে বড় লেখার ঘর) — ছোট ফোনেও চাপা লাগে না */
  function field(id, label, help, icon, val, o) {
    o = o || {};
    return '<div class="zk-f">' +
      '<label class="zk-fhd" for="zk-' + id + '"><span class="zk-fi">' + ic(icon) + '</span><span class="zk-ft"><span class="zk-fl">' + label + '</span>' + (help ? '<span class="zk-fh">' + help + '</span>' : '') + '</span>' +
        (o.valId ? '<b class="zk-val" id="' + o.valId + '"></b>' : '') + '</label>' +
      '<label class="zk-in" for="zk-' + id + '">' + (o.pre ? '<i class="zk-pre">' + o.pre + '</i>' : '') +
        '<input id="zk-' + id + '" data-k="' + id + '" inputmode="decimal" autocomplete="off" placeholder="০" value="' + String(val || '').replace(/"/g, '') + '">' +
        (o.suf ? '<em>' + o.suf + '</em>' : '') + '</label>' + (o.extra || '') + '</div>';
  }
  function seg(name, opts, cur) {
    return '<div class="pt-seg zk-seg" role="tablist" data-seg="' + name + '">' + opts.map(function (o) {
      return '<button class="pt-seg__btn" type="button" role="tab" data-v="' + o[0] + '" aria-selected="' + (String(o[0]) === String(cur)) + '">' + o[1] + '</button>';
    }).join('') + '</div>';
  }
  function sec(n, title, sub, inner) {
    return '<section class="zk-sec"><div class="zk-sh"><span class="zk-n">' + bn(n) + '</span><div class="zk-st"><b>' + title + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</div></div>' + inner + '</section>';
  }

  function build() {
    var u = st.unit === 'g' ? 'গ্রাম' : 'ভরি';
    body.innerHTML =
      /* ফলাফল — সবার ওপরে, লেখার সাথে সাথে বদলায় */
      '<section class="zk-hero" id="zk-hero" aria-live="polite">' +
        '<span class="zk-crest">' + ic('zakat') + '</span>' +
        '<div class="zk-cap" id="zk-cap">আপনার যাকাত · ২.৫% হারে</div>' +
        '<div class="zk-amt" id="zk-amt">৳০</div>' +
        '<div class="zk-pill" id="zk-pill"><i aria-hidden="true"></i><span id="zk-pt">হিসাব শুরু করুন</span></div>' +
        '<div class="zk-verdict" id="zk-verdict"></div>' +
        '<div class="zk-lines">' +
          '<span><em>মোট সম্পদ</em><b id="zk-tot">৳০</b></span>' +
          '<span><em>ঋণ বাদে</em><b id="zk-net">৳০</b></span>' +
          '<span><em id="zk-nl">নিসাব</em><b id="zk-nis">—</b></span>' +
        '</div>' +
        '<div class="zk-mh"><span>নিসাবের তুলনায় আপনার সম্পদ</span><b id="zk-pct">০%</b></div>' +
        '<div class="zk-meter"><i id="zk-bar"></i></div>' +
      '</section>' +

      sec(1, 'আজকের বাজারদর', 'সোনা-রুপার দাম বসান — একবার দিলে মনে থাকবে',
        '<div class="zk-panel">' +
          '<div class="zk-row zk-unit"><span>ওজনের একক</span>' + seg('unit', [['v', 'ভরি'], ['g', 'গ্রাম']], st.unit) + '</div>' +
          field('goldPrice', 'সোনা (২২ ক্যারেট)', 'প্রতি ' + u + ' দাম', 'sparkle', st.goldPrice, { pre: '৳', suf: '/ ' + u }) +
          field('silverPrice', 'রুপা', 'প্রতি ' + u + ' দাম', 'sparkle', st.silverPrice, { pre: '৳', suf: '/ ' + u }) +
        '</div><p class="zk-help">দাম দেখুন বাজুস (বাংলাদেশ জুয়েলার্স সমিতি)-এর আজকের তালিকায়।</p>') +

      sec(2, 'আপনার সম্পদ', 'যা যা আছে লিখুন; যা নেই, তা খালি রাখুন',
        '<div class="zk-panel">' +
          field('gold', 'সোনা', 'গয়না ও বার — ব্যবহারের গয়নাসহ', 'crown', st.gold, { suf: u, valId: 'zk-gv',
            extra: '<div class="zk-sub"><span>ক্যারেট</span>' + seg('karat', [[22, '২২'], [21, '২১'], [18, '১৮']], st.karat) + '</div>' }) +
          field('silver', 'রুপা', 'গয়না, বাসন ইত্যাদি', 'sparkle', st.silver, { suf: u, valId: 'zk-sv' }) +
          FIELDS.map(function (f) { return field(f[0], f[1], f[2], f[3], st[f[0]], { pre: '৳' }); }).join('') +
        '</div>') +

      sec(3, 'যা বাদ যাবে', 'ঋণ বাদ দিয়ে হিসাব হবে',
        '<div class="zk-panel">' + field('debt', 'ঋণ ও বকেয়া', 'এখনই পরিশোধ করতে হবে এমন ধার, বকেয়া বিল', 'minus', st.debt, { pre: '৳' }) + '</div>') +

      sec(4, 'নিসাবের হিসাব', 'কোন মানদণ্ডে নিসাব ধরা হবে',
        '<div class="zk-panel">' + seg('basis', [['auto', 'স্বয়ংক্রিয়'], ['silver', 'রুপা'], ['gold', 'সোনা']], st.basis) +
          '<div class="zk-nis2">' +
            '<span id="zk-ng"><em>সোনার নিসাব</em><b>৭.৫ ভরি</b><small>৮৭.৪৮ গ্রাম</small></span>' +
            '<span id="zk-ns"><em>রুপার নিসাব</em><b>৫২.৫ ভরি</b><small>৬১২.৩৬ গ্রাম</small></span>' +
          '</div>' +
          '<div class="zk-note">' + ic('info', 'pt-ic--sm') + '<p id="zk-basis"></p></div></div>') +

      '<div class="zk-acts"><button class="pt-btn" type="button" id="zk-share">' + ic('share', 'pt-ic--sm') + 'হিসাব শেয়ার</button>' +
        '<button class="pt-btn pt-btn--secondary" type="button" id="zk-reset">' + ic('undo', 'pt-ic--sm') + 'নতুন করে</button></div>' +
      '<p class="zk-priv">' + ic('lock', 'pt-ic--sm') + 'আপনার সব তথ্য শুধু এই ফোনেই থাকে।</p>' +

      '<section class="zk-rules"><div class="zk-rh">' + ic('info', 'pt-ic--sm') + 'মনে রাখুন</div><ul>' +
        '<li>নিসাব পরিমাণ সম্পদ পূর্ণ <b>এক চান্দ্র বছর</b> আপনার মালিকানায় থাকলে যাকাত ফরজ; হার <b>২.৫%</b>।</li>' +
        '<li>বসবাসের বাড়ি, ব্যবহারের গাড়ি, আসবাব, পরিধেয় কাপড়ে যাকাত নেই।</li>' +
        '<li>ব্যবহারের সোনার গয়নাতেও (হানাফি মতে) যাকাত দিতে হয়; হীরা-মুক্তায় নয় (ব্যবসার না হলে)।</li>' +
        '<li>এটি সাধারণ হিসাব — জটিল অবস্থায় (ব্যবসার অংশীদারি, দীর্ঘমেয়াদি ঋণ) একজন আলেমের পরামর্শ নিন।</li>' +
      '</ul></section>';
    if (window.PT && PT.hydrateIcons) PT.hydrateIcons(body);
    Array.prototype.forEach.call(body.querySelectorAll('.pt-seg'), function (s) { if (window.PT && PT.seg) PT.seg(s); });
    calc();
  }

  function calc() {
    var g = st.unit === 'g' ? VORI_G : 1;                          /* দাম "প্রতি একক" — ভরিতে রূপান্তর */
    var gp = num(st.goldPrice) * g, sp = num(st.silverPrice) * g;   /* প্রতি ভরি */
    var goldV = num(st.gold) / g, silverV = num(st.silver) / g;     /* ভরি */
    var goldVal = goldV * gp * (num(st.karat) || 22) / 22, silverVal = silverV * sp;
    var others = 0; FIELDS.forEach(function (f) { others += num(st[f[0]]); });
    var total = goldVal + silverVal + others, net = Math.max(0, total - num(st.debt));
    var basis = st.basis === 'auto' ? (goldVal > 0 && !silverVal && !others ? 'gold' : 'silver') : st.basis;
    var nis = basis === 'gold' ? NISAB_GOLD_V * gp : NISAB_SILVER_V * sp;
    var priceMissing = basis === 'gold' ? !gp : !sp;
    var due = !priceMissing && net > 0 && net >= nis, zakat = due ? net * 0.025 : 0;

    $('zk-gv').textContent = goldV ? taka(goldVal) : '';
    $('zk-sv').textContent = silverV ? taka(silverVal) : '';
    $('zk-tot').textContent = taka(total);
    $('zk-net').textContent = taka(net);
    $('zk-nl').textContent = 'নিসাব (' + (basis === 'gold' ? 'সোনা' : 'রুপা') + ')';
    $('zk-nis').textContent = priceMissing ? '—' : taka(nis);
    $('zk-amt').textContent = taka(zakat);
    var hero = $('zk-hero'), v = $('zk-verdict');
    hero.classList.toggle('is-due', due);
    hero.classList.toggle('is-empty', !total);
    if (!total) v.textContent = 'নিচে আপনার সম্পদ লিখুন — হিসাব সাথে সাথে এখানে দেখাবে।';
    else if (priceMissing) v.textContent = (basis === 'gold' ? 'সোনার' : 'রুপার') + ' আজকের দাম দিন — তা থেকেই নিসাব হিসাব হবে।';
    else if (due) v.textContent = 'নিসাব পূর্ণ — এক বছর পূর্ণ হলে যাকাত ফরজ। আল্লাহ কবুল করুন।';
    else v.textContent = 'এখন যাকাত ফরজ নয় — নিসাব থেকে ' + taka(nis - net) + ' কম।';
    $('zk-bar').style.width = (priceMissing || !nis ? 0 : Math.min(100, net / nis * 100)) + '%';
    var pct = priceMissing || !nis ? 0 : Math.min(100, net / nis * 100);
    $('zk-pct').textContent = bn(Math.round(pct)) + '%';
    var wait = !!total && priceMissing;
    hero.classList.toggle('is-wait', wait);
    $('zk-pt').textContent = !total ? 'হিসাব শুরু করুন' : wait ? 'আজকের দাম দিন' : due ? 'যাকাত ফরজ' : 'এখন যাকাত ফরজ নয়';
    $('zk-ng').classList.toggle('is-on', basis === 'gold');
    $('zk-ns').classList.toggle('is-on', basis === 'silver');
    var bl = basis === 'gold'
      ? 'সোনার নিসাব: ' + wt(NISAB_GOLD_V, 'v') + ' (৮৭.৪৮ গ্রাম)' + (st.basis === 'auto' ? ' — আপনার শুধু সোনা আছে, তাই এটিই প্রযোজ্য।' : '।')
      : 'রুপার নিসাব: ' + wt(NISAB_SILVER_V, 'v') + ' (৬১২.৩৬ গ্রাম)' + (st.basis === 'auto' ? ' — একাধিক ধরনের সম্পদ থাকলে দুটির মধ্যে কম পরিমাণটি (রুপা) ধরা হয়, যাতে গরিবের হক বাদ না পড়ে।' : '।');
    $('zk-basis').textContent = bl;
    return { total: total, net: net, nis: nis, zakat: zakat, due: due, basis: basis, priceMissing: priceMissing };
  }

  body.addEventListener('input', function (e) {
    var k = e.target.getAttribute && e.target.getAttribute('data-k'); if (!k) return;
    st[k] = e.target.value; save(); calc();
  });
  body.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
    var sg = b.closest('[data-seg]');
    if (sg && b.hasAttribute('data-v')) {
      var name = sg.getAttribute('data-seg'), v = b.getAttribute('data-v');
      Array.prototype.forEach.call(sg.querySelectorAll('.pt-seg__btn'), function (x) { x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
      if (window.PT && PT.seg) PT.seg(sg);
      if (name === 'unit' && st.unit !== v) {                     /* একক বদলালে লেখা ওজন/দামও রূপান্তর */
        var f = v === 'g' ? VORI_G : 1 / VORI_G;
        ['gold', 'silver'].forEach(function (k) { if (num(st[k])) st[k] = String(Math.round(num(st[k]) * f * 100) / 100); });
        ['goldPrice', 'silverPrice'].forEach(function (k) { if (num(st[k])) st[k] = String(Math.round(num(st[k]) / f)); });
        st.unit = v; save(); build(); return;
      }
      st[name] = name === 'karat' ? +v : v; save(); calc(); return;
    }
    if (b.id === 'zk-reset') {
      var go = function () { var keep = { unit: st.unit, goldPrice: st.goldPrice, silverPrice: st.silverPrice }; st = JSON.parse(JSON.stringify(DEF)); for (var k in keep) st[k] = keep[k]; save(); build(); };
      if (window.PT && PT.dialog) PT.dialog({ icon: 'undo', title: 'নতুন করে হিসাব?', body: 'সম্পদ ও ঋণের লেখা মুছে যাবে। সোনা-রুপার দাম থেকে যাবে।', ok: 'মুছে দিন', cancel: 'থাক' }).then(function (ok) { if (ok) go(); });
      else go();
      return;
    }
    if (b.id === 'zk-share') {
      var r = calc();
      var t = 'যাকাতের হিসাব (পাথেয়)\n\nমোট সম্পদ: ' + taka(r.total) + '\nঋণ বাদে: ' + taka(r.net) + '\nনিসাব (' + (r.basis === 'gold' ? 'সোনা' : 'রুপা') + '): ' + (r.priceMissing ? '—' : taka(r.nis)) +
        '\n' + (r.due ? 'যাকাত (২.৫%): ' + taka(r.zakat) : 'এখন যাকাত ফরজ নয়') + '\n\n— পাথেয় বাই গুঞ্জরণ';
      try { if (navigator.share) { navigator.share({ text: t }).catch(function () {}); return; } } catch (er) {}
      try { navigator.clipboard.writeText(t).then(function () { window.PT && PT.toast('হিসাব কপি হয়েছে', { type: 'success' }); }); } catch (er) {}
    }
  });
  build();
})();
