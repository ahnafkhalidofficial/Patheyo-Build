/* =============================================================================
   ধাপ ১১: অ্যাপের ভেতরের নির্দিষ্ট জায়গায় যাওয়া — window.__ptGo(target)
   ব্যবহার: নোটিফিকেশনে ট্যাপ (MainActivity "go" extra), গ্লোবাল সার্চের ফল, হোমের "দরকারি" সারি।
     quran:18        → কুরআন, সূরা ১৮ (তিলাওয়াত বা তরজমা — যেটি খোলা ছিল)
     quran:2:255     → সূরা ২, আয়াত ২৫৫
     dua:sleep       → দোয়া, "ঘুম" অধ্যায়        dua:id:m1 → নির্দিষ্ট দোয়া
     dua:asma        → আসমাউল হুসনা            dua:asma:17 → ১৭ নম্বর নাম
     hadith          → হাদিস পেজ
     zakat · reminders · search[:লেখা] · f0…f8 (যেকোনো ফিচার)
   খোলা/বন্ধ শুধু কন্ট্রোলারের window.__ptPages দিয়ে — নিজস্ব কোনো লজিক নয়।
   ============================================================================= */
(function () {
  'use strict';
  var P = function () { return window.__ptPages; };

  /* ফিচার-পেজ খুলে তার ফ্রেমের API তৈরি হওয়া পর্যন্ত অপেক্ষা (প্রথমবার ফ্রেম লোড হতে কয়েক সেকেন্ড লাগতে পারে) */
  function inFrame(key, ready, fn) {
    if (!P()) return;
    if (P().current() !== key) P().open(key);
    var t0 = Date.now();
    (function tick() {
      var w = P().frameWin(key), ok = false;
      try { ok = !!(w && ready(w)); } catch (e) {}
      if (ok) { setTimeout(function () { try { fn(w); } catch (e) {} }, 120); return; }
      if (Date.now() - t0 < 9000) setTimeout(tick, 200);
    })();
  }
  window.__ptIn = inFrame;

  function quran(s, a) {
    s = Math.max(1, Math.min(114, s | 0)); a = a | 0;
    inFrame('f1', function (w) { var A = w.QuranApp; return A && A.quranModel && A.quranModel.length === 114 && A.openReader && A.els; }, function (w) {
      var A = w.QuranApp;
      if (A.FsUi && A.FsUi.isOpen && A.FsUi.isOpen()) A.FsUi.close();
      if (A.state && A.state.mode === 'tarjama' && A.openTarjamaReader && A.tarjamaDownload && A.tarjamaDownload.isReady && A.tarjamaDownload.isReady()) {
        A.openTarjamaReader(s, a); return;
      }
      try { if (A.state.view !== 'sura-reader') { A.els.paraPanel.classList.add('hidden'); A.els.bookmarksPanel.classList.add('hidden'); } } catch (e) {}
      A.openReader(s);
      if (a && A.scrollToAyah) setTimeout(function () { try { A.scrollToAyah(s, a); } catch (e) {} }, 140);
    });
  }

  function dua(rest) {
    inFrame('f4', function (w) { return w.DuaApp && w.DuaApp.reveal; }, function (w) {
      var p = rest.split(':');
      if (p[0] === 'asma') w.DuaApp.reveal(p[1] || null, 'asma');
      else if (p[0] === 'id') w.DuaApp.reveal(p[1], null);
      else w.DuaApp.reveal(null, p[0] || null);
    });
  }

  window.__ptGo = function (target) {
    target = String(target || '');
    var p = target.split(':'), k = p[0];
    try {
      if (k === 'quran') return quran(+p[1] || 1, +p[2] || 0);
      if (k === 'dua') return dua(p.slice(1).join(':'));
      if (k === 'hadith') return P() && P().open('f2');
      if (k === 'zakat') return P() && P().open('zakat');
      if (k === 'reminders') return window.ptOpenReminders && window.ptOpenReminders();
      if (k === 'search') return window.ptOpenSearch && window.ptOpenSearch(p.slice(1).join(':'));
      if (/^f[0-8]$/.test(k)) return P() && P().open(k);
    } catch (e) {}
  };

  /* হোমের "দরকারি" সারি: data-go="..." */
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-go]') : null;
    if (!b) return;
    e.preventDefault();
    var g = b.getAttribute('data-go');
    if (g === 'zakat' && P()) { P().open('zakat', b.querySelector('.tl-ic') || b); return; }
    window.__ptGo(g);
  });
})();
