/* v256: ক্লিক সাউন্ড — একটাই সুইচ, সেটিংসে।
   আগে আমলের রিপোর্ট ও তাসবিহের হেডারে আলাদা সাউন্ড বাটন ছিল; এখন দুটোই এই সুইচ মানে।
   মান localStorage 'pt_click_sound' ('1' চালু / '0' বন্ধ; না থাকলে চালু)। পেজগুলো (ফ্রেম) একই অরিজিনে, তাই সরাসরি এটিই পড়ে।
   প্রথমবার: আগে কেউ আমল বা তাসবিহে সাউন্ড বন্ধ করে থাকলে সেটিই বজায় থাকে। */
(function () {
  'use strict';
  var KEY = 'pt_click_sound';
  var box = document.getElementById('st-snd'), sub = document.getElementById('st-snd-s');
  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  if (get(KEY) === null) {
    var off = false;
    try { if (JSON.parse(get('tz3_sound')) === false) off = true; } catch (e) {}
    try { var a = JSON.parse(get('amol_report_state') || 'null'); if (a && a.soundOn === false) off = true; } catch (e) {}
    set(KEY, off ? '0' : '1');
  }
  function on() { return get(KEY) !== '0'; }
  window.PtClickSound = { on: on, set: function (v) { set(KEY, v ? '1' : '0'); paint(); } };
  function paint() {
    if (box) box.checked = on();
    if (sub) sub.textContent = on() ? 'আমল ও তাসবিহে ট্যাপ করলে হালকা শব্দ' : 'বন্ধ আছে — ট্যাপে কোনো শব্দ হবে না';
  }
  if (box) box.addEventListener('change', function () { set(KEY, box.checked ? '1' : '0'); paint(); });
  paint();
})();
