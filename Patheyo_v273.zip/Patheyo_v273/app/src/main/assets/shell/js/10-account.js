/* =============================================================================
   ধাপ ৯ — অ্যাকাউন্ট ও ক্লাউড সিঙ্ক
   নেটিভ: PatheyoAuth (app/.../auth/AuthBridge.kt) — Google (Credential Manager) + ইমেইল, Firebase Auth,
          ক্লাউড (v185 থেকে) = Supabase user_backups, Edge Function cloud-sync দিয়ে (Firebase টোকেন যাচাই করে শুধু নিজের সারি)।
   ওয়েব:  প্রোফাইল বাটন / সেটিংস → অ্যাকাউন্ট কেন্দ্র (#pf-sheet, মাঝখানের পপআপ)।
   সিঙ্ক: সেটিংসের ব্যাকআপ-ফাইলের একই লেখা (window.__ptBackup)।
          • সাইন-ইন করলেই ক্লাউডে হিসাব থাকলে নিজে থেকে ফিরে আসে (প্রশ্ন করে না; আগের অবস্থা সেটিংসের \"রিস্টোর বাতিল\"-এ থাকে)।
          • ডেটা বদলালে/মুছলে ~৬ সেকেন্ড পরে নিজে থেকে ক্লাউডে (মুছলে ক্লাউড থেকেও মুছে যায়, কারণ পুরো হিসাব একসাথে বদলায়)।
          • অ্যাপ পেছনে গেলে ও প্রতি ২ মিনিটে (বদল থাকলে) নিশ্চিন্ত করার জন্য।
          • অন্য ফোনে ক্লাউড বদলে থাকলে, এই ফোনে নিজের বদল না থাকলে অ্যাপ খুললে সেটি নিজে থেকে চলে আসে।
          এই ফোনের অল্প ডেটা দিয়ে ক্লাউডের পুরনো হিসাব নিজে থেকে কখনো মোছে না।
   সাইন-ইন ঐচ্ছিক — অতিথি হিসেবে সব কাজ চলে।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window;
  var A = function () { return W.PatheyoAuth || null; };
  var GM = 'pt_google_mode';                 /* 'web' = Google সাইন-ইন সরাসরি ব্রাউজারে (শিট কাজ না করা ফোনে) */
  var CK = 'pt_cloud';                       /* {uid, on, at, fp, hold} — এই ফোনের সিঙ্কের অবস্থা (ব্যাকআপে যায় না) */
  var $ = function (id) { return D.getElementById(id); };
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(x) { return String(x).replace(/\d/g, function (d) { return BN[d]; }); }
  function jget(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function jset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function toast(t, type) { if (W.PT) PT.toast(t, { type: type || '' }); }

  var sheet = $('pf-sheet');
  if (!sheet) return;

  /* ---------------------------------------------------------------- নেটিভ কল (Promise) */
  var seq = 0, wait = {};
  W.__ptAuthCb = function (id, json) {
    var f = wait[id]; if (!f) return; delete wait[id];
    var r; try { r = JSON.parse(json); } catch (e) { r = { ok: false, msg: 'কাজটি সম্পন্ন করা যায়নি' }; }
    if (r && r.state) S = r.state;
    f(r);
  };
  function call(fn) {
    var args = [].slice.call(arguments, 1);
    return new Promise(function (res) {
      var a = A(); if (!a || typeof a[fn] !== 'function') { res({ ok: false, code: 'na', msg: 'এই সুবিধা শুধু অ্যাপের ভেতরে কাজ করে।' }); return; }
      var id = 'a' + (++seq); wait[id] = res;
      /* v193: সাইন-ইনের উত্তর ২ মিনিটে না এলে বাটন আটকে থাকে না — বার্তা দেখিয়ে ছাড়ে */
      if (fn === 'google' || fn === 'googleWeb' || fn === 'emailIn' || fn === 'emailUp') setTimeout(function () { var f = wait[id]; if (f) { delete wait[id]; f({ ok: false, code: 'timeout', msg: 'সাড়া পাওয়া যায়নি। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।' }); } }, 120000);
      try { a[fn].apply(a, [id].concat(args)); } catch (e) { delete wait[id]; res({ ok: false, msg: 'কাজটি সম্পন্ন করা যায়নি' }); }
    });
  }
  var lastOk = 0;   /* v200: ক্লাউডের সাথে শেষ সফল মিল/সেভ (মেমরিতে) */
  var S = { signedIn: false };
  function readState() { try { var a = A(); if (a && a.state) S = JSON.parse(a.state()) || S; } catch (e) {} return S; }
  W.__ptAuthChanged = function (json) { try { S = JSON.parse(json); } catch (e) {} paintAll(); };

  /* ---------------------------------------------------------------- দেখানো */
  var view = 'guest', mode = 'in', busy = false;
  function show(v) {
    view = v; sheet.setAttribute('data-view', v);
    [].forEach.call(sheet.querySelectorAll('.ac-pane'), function (p) { p.hidden = (' ' + p.getAttribute('data-v') + ' ').indexOf(' ' + v + ' ') < 0; });
    var t = { guest: 'আপনার অ্যাকাউন্ট', email: 'ইমেইল দিয়ে', user: 'আমার অ্যাকাউন্ট', local: 'নাম ও ছবি', del: 'অ্যাকাউন্ট মোছা' }[v];
    $('pf-title').textContent = t || 'আপনার অ্যাকাউন্ট';
    sheet.querySelector('.ac-back').hidden = !(v === 'email' || v === 'local' || v === 'del');
    sheet.querySelector('.ac-back').setAttribute('data-ac-go', v === 'del' ? 'user' : 'guest');
    if (v === 'email') { var sg = sheet.querySelector('.ac-seg'); if (sg && W.PT) PT.seg(sg); setMode(mode); }
    if (v === 'user' || v === 'local') { if (W.__ptProfileFill) W.__ptProfileFill(); }
    if (v === 'del') { $('ac-del-err').hidden = true; $('ac-del-pass').value = ''; }
    errOff();
  }
  function setMode(m) {
    mode = m; sheet.setAttribute('data-mode', m);
    $('ac-submit').textContent = m === 'up' ? 'অ্যাকাউন্ট খুলুন' : 'সাইন-ইন করুন';
    $('ac-pass').setAttribute('autocomplete', m === 'up' ? 'new-password' : 'current-password');
    errOff();
  }
  function err(t, id) { var e = $(id || 'ac-err'); if (!e) return; e.textContent = t; e.hidden = !t; if (t && W.PT) PT.haptic('warn'); }
  function errOff() { err('', 'ac-err'); gerr(''); }
  /* v193: Google-এর ব্যর্থতা বাটনের নিচেই লেখা দেখায় — আগে চুপচাপ কেটে যেত */
  function gerr(t, more) { var e = $('ac-gerr'); if (!e) return; e.textContent = t || ''; e.hidden = !t; var w = $('ac-gweb'); if (w) w.hidden = !(t && more); if (t && W.PT) PT.haptic('warn'); }
  function setBusy(b, btn) {
    busy = b; sheet.classList.toggle('is-busy', b);
    if (btn) { btn.disabled = b; btn.classList.toggle('is-loading', b); }
  }

  function provLabel(s) { return s.provider === 'google' ? 'Google' : 'ইমেইল'; }
  function fmtAgo(ms) {
    if (!ms) return '';
    var d = Math.round((Date.now() - ms) / 60000);
    if (d < 1) return 'এইমাত্র'; if (d < 60) return bn(d) + ' মিনিট আগে';
    var h = Math.round(d / 60); if (h < 24) return bn(h) + ' ঘণ্টা আগে';
    var dt = new Date(ms); return bn(dt.getDate()) + ' ' + ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'][dt.getMonth()];
  }
  function paintUser() {
    if (!S.signedIn) return;
    $('ac-mail').textContent = S.email || '';
    var pv = $('ac-prov'); pv.innerHTML = (W.PT ? PT.icon(S.provider === 'google' ? 'google' : 'mail', 'pt-ic--sm') : '') + provLabel(S);
    $('ac-verify').hidden = !!S.verified;
    var c = jget(CK) || {};
    $('ac-auto').checked = c.on !== false;
    var lt = Math.max(c.uid === S.uid && c.at || 0, lastOk);
    $('ac-last').textContent = c.hold ? 'বিরতি — সুইচ আবার চালু করলে শুরু হবে' : (c.on === false ? 'বন্ধ — চালু করলে সব ফোনে নিজে থেকে মিলবে' : (lt ? 'রিয়েল-টাইম চালু · শেষ মিল: ' + fmtAgo(lt) : 'সিঙ্ক শুরু হচ্ছে…'));
    $('ac-last').setAttribute('data-st', c.hold ? 'hold' : (c.on !== false && lt ? 'ok' : 'none'));
    sheet.classList.toggle('ac-email-user', S.provider !== 'google');
  }
  function paintSettings() {
    var t = $('st-acc-t'), s = $('st-acc-s'), img = $('st-acc-img'); if (!t) return;
    var p = jget('pt_profile') || {};
    if (S.signedIn) {
      t.textContent = p.name || S.name || 'আমার অ্যাকাউন্ট';
      var c = jget(CK) || {};
      s.textContent = (S.email || '') + (c.on !== false && !c.hold && (c.at || lastOk) ? ' · রিয়েল-টাইম সিঙ্ক' : '');
    } else { t.textContent = 'সাইন-ইন করুন'; s.textContent = 'স্বয়ংক্রিয় ক্লাউড ব্যাকআপ — নতুন ফোনেও সব ফিরে পাবেন'; }
    if (p.photo && String(p.photo).indexOf('data:') !== 0) p.photo = '';
    if (p.photo) { img.src = p.photo; img.hidden = false; } else { img.hidden = true; img.removeAttribute('src'); }
    var av = img.closest && img.closest('.st-acc__av'); if (av) av.classList.toggle('has-photo', !!p.photo);
    var hb = $('btn-profile'); if (hb) hb.classList.toggle('is-signed', !!S.signedIn);
  }
  function paintAll() {
    paintSettings();
    if (!sheet.hidden) { if (S.signedIn && (view === 'guest' || view === 'email')) show('user'); else if (!S.signedIn && (view === 'user' || view === 'del')) show('guest'); paintUser(); }
  }

  W.__ptAccountOpen = function () {
    if (!W.PT) return;
    readState();
    show(S.signedIn ? 'user' : 'guest'); paintUser();
    PT.sheet.open(sheet);
  };
  var _open = W.__ptAccountOpen; W.__ptAccountOpen = function () { _open(); baseH = hsh(photoNow()); };
  var row = $('st-acc-row'); if (row) row.addEventListener('click', W.__ptAccountOpen);

  /* ---------------------------------------------------------------- সাইন-ইনের পরে */
  /* v202: গুগলের ছবি → ফোনের প্রোফাইলে (ইউজারের নিজের ছবি না থাকলে) */
  function putPhoto(d) {
    var q = jget('pt_profile') || {}; q.photo = d; jset('pt_profile', q); baseH = hsh(d);
    if (W.__ptPaintProfile) W.__ptPaintProfile(); paintSettings();
    if (!sheet.hidden && W.__ptProfileFill) W.__ptProfileFill(); pfDirty();
  }
  function googlePhoto() {
    if (!S.signedIn || !S.photo || photoNow()) return;
    call('photo').then(function (r) { if (r && r.ok && r.data && !photoNow()) putPhoto(r.data); });
  }
  /* v202: লগআউটের পর আবার লগইনে ছবি গায়েব হওয়ার সমাধান — ক্লাউডের (Supabase avatars/{uid}.jpg) নিজের ছবি ফেরত আনা।
     ফোনে ছবি থাকলে বা নিজের মোছা/বদল ক্লাউডে যাওয়া বাকি থাকলে কিছু করে না। fallback = ক্লাউডে ছবি না থাকলে গুগলের ছবি। */
  var avLoading = false;
  function loadCloudAvatar(fallback) {
    if (!S.signedIn || avLoading || photoNow()) return;
    var d = jget(AVD); if (d && d.uid === S.uid) return;
    var uid = S.uid; avLoading = true;
    call('downloadAvatar').then(function (r) {
      avLoading = false;
      if (!S.signedIn || S.uid !== uid || photoNow()) return;
      /* v272: AVM আগে বসে, তারপর ছবি — যাতে ক্লাউডের রূপ (শুধু চিহ্ন) এক মুহূর্তের জন্যও বদলে না যায় */
      if (r && r.ok && r.data) { jset(AVM, { uid: uid, h: hsh(r.data) }); try { localStorage.removeItem(AVW); } catch (e) {} putPhoto(r.data); }
      else if (r && r.ok) { try { localStorage.removeItem(AVW); } catch (e) {} if (fallback) googlePhoto(); }   /* Storage-এ ছবি নেই — "নামানো বাকি" চিহ্ন আর রাখার মানে নেই */
    });
  }
  function adoptProfile(isNew) {
    var p = jget('pt_profile') || {};
    var changed = false;
    if (S.name && (!p.name || isNew)) { p.name = S.name; changed = true; }
    if (changed) { jset('pt_profile', p); if (W.__ptPaintProfile) W.__ptPaintProfile(); }
    if (!p.photo) loadCloudAvatar(true);
  }
  function afterSignIn(r, how) {
    S = r.state || readState();
    adoptProfile(r.isNew);
    show('user'); paintUser(); paintSettings();
    toast(how === 'up' ? 'অ্যাকাউন্ট খোলা হয়েছে — ইমেইল যাচাই করে নিন' : 'আসসালামু আলাইকুম' + (S.name ? ', ' + S.name.split(/\s+/)[0] : '') + '!', 'success');
    firstSync();
  }

  /* ---------------------------------------------------------------- প্রোফাইল ছবি → Supabase Storage (v184)
     বাকেট avatars, ফাইল {uid}.jpg, সর্বোচ্চ ১০০KB (09-home.js ছোট করে; নেটিভও আবার যাচাই করে)।
     শুধু ইউজার নিজে ছবি বদলে/সরিয়ে "সেভ" চাপলে আপলোড/মোছা — গুগলের ছবি নিজে থেকে যায় না।
     ইন্টারনেট না থাকলে "বাকি" থেকে যায়, পরে নিজে থেকে আবার চেষ্টা হয়। */
  var AVM = 'pt_avatar_up', AVD = 'pt_avatar_dirty', AVW = 'pt_avatar_want', baseH = '', avBusy = false;   /* AVW (v272): ক্লাউড-রিস্টোরের পর Storage থেকে ছবি নামানো বাকি */
  function hsh(s) { s = s || ''; var h = 5381; for (var i = 0; i < s.length; i += 7) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return s.length + ':' + h; }
  function photoNow() { var ph = (jget('pt_profile') || {}).photo || ''; return String(ph).indexOf('data:') === 0 ? ph : ''; }
  function syncAvatar(loud) {
    if (!S.signedIn || avBusy) return Promise.resolve();
    var d = jget(AVD); if (!d || d.uid !== S.uid) return Promise.resolve();
    var photo = photoNow(), want = photo ? hsh(photo) : '';
    avBusy = true;
    return (photo ? call('uploadAvatar', photo) : call('deleteAvatar')).then(function (r) {
      avBusy = false;
      if (r && r.ok) { try { localStorage.removeItem(AVD); } catch (e) {} jset(AVM, { uid: S.uid, h: want }); }
      else if (loud && r && r.code !== 'na') toast('ছবি ক্লাউডে রাখা যায়নি — ইন্টারনেট এলে নিজে থেকে আবার চেষ্টা হবে');
    });
  }

  /* ---------------------------------------------------------------- ক্লাউড সিঙ্ক */
  var B = function () { return W.__ptBackup || null; };
  function cloudState() { var c = jget(CK) || {}; if (c.uid !== S.uid) c = { uid: S.uid, on: true }; return c; }

  var inflight = false, chT = 0, fsBusy = false;   /* v202: fsBusy = সাইন-ইনের পর ক্লাউডের হিসাব দেখা চলছে — তখন এই ফোনের (খালি) অবস্থা ক্লাউডে লিখে ছবি/হিসাব মুছে ফেলা চলবে না */
  function push(force) {
    if (!S.signedIn || !B()) return Promise.resolve(false);
    if (!force && fsBusy) return Promise.resolve(false);
    var c = cloudState();
    if (!force && (c.on === false || c.hold)) return Promise.resolve(false);
    var fp = B().fingerprint();
    if (!force && fp === c.fp) return Promise.resolve(false);
    if (inflight && !force) { onChange(); return Promise.resolve(false); }   /* আগের সেভ চলছে — একটু পরে আবার */
    inflight = true;
    return call('cloudSave', B().make()).then(function (r) {
      inflight = false;
      if (r && r.ok) { c.fp = fp; c.at = Date.now(); c.cat = r.at || c.at; c.hold = false; lastOk = Date.now(); jset(CK, c); paintUser(); paintSettings(); return true; }
      return false;
    });
  }
  /** ডেটা বদলালে (এই পেজে বা অন্য পেজে) দেড় সেকেন্ড থেমে থাকলে ক্লাউডে পাঠাই (v200: আগে ৬ সেকেন্ড) */
  function onChange() {
    if (!S.signedIn) return;
    clearTimeout(chT); chT = setTimeout(function () { push(false); }, 1500);
  }
  try {
    var _si = Storage.prototype.setItem, _ri = Storage.prototype.removeItem;
    var mine = function (k) { return k === CK || k === AVM || k === AVD; };
    Storage.prototype.setItem = function (k) { var r = _si.apply(this, arguments); try { if (this === W.localStorage && !mine(k)) onChange(); } catch (e) {} return r; };
    Storage.prototype.removeItem = function (k) { var r = _ri.apply(this, arguments); try { if (this === W.localStorage && !mine(k)) onChange(); } catch (e) {} return r; };
  } catch (e) {}
  /* v247: নেটিভ (Kotlin) পাশে নোট ইত্যাদি বদলালে নেটিভ এটি ডাকে — localStorage বদলায় না বলে নিজে থেকে ধরা পড়ত না */
  W.__ptNativeChanged = function () { onChange(); };
  W.addEventListener('storage', function (e) { if (!e.key || (e.key !== CK && e.key !== AVM && e.key !== AVD)) onChange(); });   /* অন্য পেজ/ফ্রেম থেকে বদল */

  /** নতুন ফোন / নতুন সাইন-ইন: ক্লাউডে হিসাব থাকলে নিজে থেকেই ফিরিয়ে আনা (v185), না থাকলে এই ফোনেরটা পাঠানো */
  function firstSync() {
    if (!S.signedIn || !B()) return;
    var c = cloudState();
    if (c.at) { syncOnOpen(c); return; }        /* এই অ্যাকাউন্ট এই ফোনে আগেই সিঙ্ক হয়েছে */
    fsBusy = true;
    var guard = setTimeout(function () { fsBusy = false; }, 30000);   /* নেট না থাকলে চিরকাল আটকে থাকবে না */
    var done = function () { clearTimeout(guard); fsBusy = false; };
    call('cloudLoad').then(function (r) {
      if (!r || !r.ok) { done(); return; }
      if (r.empty || !r.data) { done(); push(true); return; }
      var pk = B().peek(r.data);
      if (pk && pk.fp === B().fingerprint()) { done(); c.fp = pk.fp; c.at = Date.now(); c.cat = r.at || 0; c.hold = false; lastOk = Date.now(); jset(CK, c); paintUser(); return; }
      toast('আপনার সব হিসাব ক্লাউড থেকে ফিরে আসছে…', 'success');
      restoreFrom(r.data, r.at, true);  /* অ্যাপ নতুন করে খুলবে — fsBusy রিলোডেই শেষ। true = এই ফোনে আগে থেকে থাকা নিজের নোট মুছবে না, ক্লাউডেরগুলো যোগ হবে (v247) */
      setTimeout(done, 4000);
    });
  }
  /** অ্যাপ খুললে: এই ফোনে নিজের বদল না থাকলে আর ক্লাউডে (অন্য ফোন থেকে) বদল এসে থাকলে সেটি নিজে থেকে আনা; নিজের বদল থাকলে ক্লাউডে পাঠানো */
  function syncOnOpen(c) {
    if (!S.signedIn || !B() || c.on === false || c.hold) return;
    if (B().fingerprint() !== c.fp) { push(false); return; }
    call('cloudLoad').then(function (r) {
      if (!r || !r.ok || r.empty || !r.data) return;
      var pk = B().peek(r.data);
      if (pk && pk.fp && pk.fp !== c.fp && pk.fp !== B().fingerprint() && B().fingerprint() === c.fp) {
        toast('অন্য ফোনের নতুন হিসাব ক্লাউড থেকে আসছে…', 'success');
        restoreFrom(r.data, r.at);
      }
    });
  }
  function restoreFrom(text, at, merge) {
    var res = B().restoreText(text, merge ? { merge: true } : null);
    if (res === 'ok') { var c = cloudState(); c.at = Date.now(); c.cat = at || c.cat || 0; c.hold = false; c.fp = (B().peek(text) || {}).fp; jset(CK, c); toast('ক্লাউড থেকে আনা হচ্ছে… অ্যাপ নতুন করে খুলছে', 'success'); }
    else toast(res === 'empty' ? 'ক্লাউডে ফেরত আনার মতো কিছু নেই' : 'ক্লাউডের ডেটা পড়া যায়নি', 'danger');
  }

  /* ---------------------------------------------------------------- রিয়েল-টাইম (v200)
     • এই ফোনে বদল → দেড় সেকেন্ডে ক্লাউডে (onChange ওপরে)।
     • অন্য ফোনে বদল → ৪ সেকেন্ডের পরপর ক্লাউডের "শেষ বদলের সময়" (হালকা cloudMeta) দেখা; নতুন হলে হিসাব এনে নিজে থেকে বসানো।
     • অ্যাপ পেছনে গেলে/ফোনে হাত না পড়লে (২ মিনিট) পরীক্ষা কমে যায়/থামে — ব্যাটারি ও সার্ভারের খরচ বাঁচাতে।
     • নিজের অসেভড বদল থাকলে আগে সেটিই পাঠানো হয় (নিজের হাতের বদল হারায় না); লিখতে থাকলে (কীবোর্ড খোলা) বসানো পরের বারে। */
  var pollBusy = false, metaOK = true, lastTouch = Date.now();
  ['touchstart', 'click', 'keydown'].forEach(function (ev) { D.addEventListener(ev, function () { lastTouch = Date.now(); }, { passive: true, capture: true }); });
  function applyRemote(r) {
    pollBusy = false;
    if (!r || !r.ok || r.empty || !r.data) return;
    var c = cloudState(); if (!r.at || r.at <= (c.cat || 0)) return;
    if (B().fingerprint() !== c.fp) { push(false); return; }               /* ইতিমধ্যে নিজের বদল হয়েছে — সেটিই আগে */
    var pk = B().peek(r.data);
    if (pk && pk.fp === B().fingerprint()) { c.cat = r.at; c.fp = pk.fp; c.at = Date.now(); lastOk = Date.now(); jset(CK, c); paintUser(); return; }
    var ae = D.activeElement; if (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) return;   /* লিখছেন — পরের বার */
    toast('অন্য ফোনের নতুন হিসাব আসছে…', 'success');
    restoreFrom(r.data, r.at);
  }
  function pollCloud() {
    if (!S.signedIn || !B() || pollBusy || inflight || D.visibilityState === 'hidden') return;
    var c = cloudState(); if (c.on === false || c.hold) return;
    if (B().fingerprint() !== c.fp) { push(false); return; }
    pollBusy = true;
    var viaMeta = metaOK;
    call(viaMeta ? 'cloudMeta' : 'cloudLoad').then(function (r) {
      if (!r || !r.ok) { pollBusy = false; if (viaMeta && r && r.code === 'nometa') metaOK = false; return; }
      lastOk = Date.now();
      if (r.empty || !r.at || r.at <= (c.cat || 0)) { pollBusy = false; return; }
      if (!viaMeta) { applyRemote(r); return; }
      call('cloudLoad').then(applyRemote);
    });
  }
  function pollLoop() {
    var idle = Date.now() - lastTouch > 120000;     /* ২ মিনিট হাত না পড়লে ধীর */
    pollCloud();                                    /* পেছনে থাকলে নিজেই থেমে যায় */
    setTimeout(pollLoop, (!metaOK || idle) ? 20000 : 4000);
  }
  setTimeout(pollLoop, 2500);
  function autoPush() { push(false); syncAvatar(false); }
  D.addEventListener('visibilitychange', function () { if (D.visibilityState === 'hidden') autoPush(); else { lastTouch = Date.now(); pollCloud(); } });
  W.addEventListener('online', function () { autoPush(); pollCloud(); loadCloudAvatar(false); });
  setInterval(autoPush, 15000);
  setInterval(function () { if (S.signedIn && !sheet.hidden) paintUser(); }, 10000);

  /* ---------------------------------------------------------------- বাটন */
  sheet.addEventListener('click', function (e) {
    var go = e.target.closest('[data-ac-go]'); if (go) { show(go.getAttribute('data-ac-go')); if (go.getAttribute('data-ac-go') === 'user') paintUser(); return; }
    var m = e.target.closest('[data-ac-mode]'); if (m) { setMode(m.getAttribute('data-ac-mode')); return; }
    var b = e.target.closest('[data-ac]'); if (!b || busy) return;
    var a = b.getAttribute('data-ac');
    if (a === 'google' || a === 'google-web') {
      /* v194: শিট (Credential Manager) বাতিল/ব্যর্থ হলে "ব্রাউজার দিয়ে" পথ; একবার ব্রাউজারে সফল হলে পরের বার সরাসরি সেটিই */
      var web = a === 'google-web' || jget(GM) === 'web';
      setBusy(true, b); gerr('');
      call(web ? 'googleWeb' : 'google').then(function (r) {
        setBusy(false, b);
        if (r.ok) { if (web) jset(GM, 'web'); afterSignIn(r, 'google'); }
        else if (r.code === 'cancel') {
          if (web) { if (a !== 'google-web') jset(GM, 'sheet'); return; }   /* ব্রাউজার বন্ধ করেছেন — চুপ */
          gerr('সাইন-ইন সম্পন্ন হলো না' + (r.detail ? ' (' + r.detail + ')' : '') + '। অ্যাকাউন্ট বেছেও এমন হলে নিচের "ব্রাউজার দিয়ে" চাপুন।', true);
        } else { var m = r.msg || 'Google সাইন-ইন হলো না। ইমেইল দিয়ে সাইন-ইন করুন।'; gerr(m, true); toast(m, 'danger'); }
      });
    } else if (a === 'eye') {
      var pi = $('ac-pass'), shown = pi.type === 'text'; pi.type = shown ? 'password' : 'text';
      b.innerHTML = W.PT ? PT.icon(shown ? 'eye' : 'eye-off') : ''; b.setAttribute('aria-label', shown ? 'পাসওয়ার্ড দেখান' : 'পাসওয়ার্ড লুকান');
    } else if (a === 'forgot') {
      var em = $('ac-email').value.trim();
      if (!/^\S+@\S+\.\S+$/.test(em)) { err('আগে ইমেইল ঠিকানাটি লিখুন, তারপর এখানে চাপুন।'); $('ac-email').focus(); return; }
      setBusy(true, b);
      call('reset', em).then(function (r) { setBusy(false, b); if (r.ok) { errOff(); toast('পাসওয়ার্ড বদলানোর লিংক ' + em + '-এ পাঠানো হয়েছে', 'success'); } else err(r.msg); });
    } else if (a === 'resend') {
      setBusy(true, b); call('sendVerify').then(function (r) { setBusy(false, b); toast(r.ok ? 'যাচাইয়ের ইমেইল আবার পাঠানো হয়েছে' : r.msg, r.ok ? 'success' : 'danger'); });
    } else if (a === 'verified') {
      setBusy(true, b); call('reload').then(function (r) { setBusy(false, b); paintUser(); toast(S.verified ? 'ইমেইল যাচাই হয়েছে — জাযাকাল্লাহ' : 'এখনো যাচাই হয়নি — ইমেইলের লিংকে চাপুন', S.verified ? 'success' : ''); });
    } else if (a === 'signout') {
      /* v194: সাইন-আউট = এই ফোন প্রথম দিনের মতো (নাম, ছবি, সেটিংস, হিসাব মুছে)। ক্লাউডে হিসাব নিরাপদ — আগে সেটি নিশ্চিত করা হয়। */
      var sc = cloudState(), dirty = !!B() && B().fingerprint() !== sc.fp;
      var finish = function () {
        setBusy(true, b);
        call('signOut').then(function () { S = { signedIn: false }; try { B().resetLocal(); } catch (e) { setBusy(false, b); show('guest'); paintSettings(); } });
      };
      var warn = function () {
        PT.dialog({ icon: 'logout', title: 'সিঙ্ক হয়নি — তবুও সাইন-আউট?', body: 'এই ফোনের কিছু বদল ক্লাউডে পাঠানো যায়নি (ইন্টারনেট বা সিঙ্ক বন্ধ)। এখন সাইন-আউট করলে সেগুলো মুছে যাবে।', ok: 'তবুও সাইন-আউট' }).then(function (y) { if (y) finish(); });
      };
      PT.dialog({ icon: 'logout', title: 'সাইন-আউট করবেন?', body: 'এই ফোনের নাম, ছবি, ক্যালেন্ডারের নোট ও সব সেটিংস মুছে অ্যাপ প্রথম দিনের মতো হয়ে যাবে। আপনার হিসাব ক্লাউডে নিরাপদ থাকবে — আবার সাইন-ইন করলেই ফিরে আসবে।', ok: 'সাইন-আউট' }).then(function (y) {
        if (!y) return;
        if (!dirty) { finish(); return; }
        if (sc.hold || sc.on === false) { warn(); return; }
        setBusy(true, b);
        push(true).then(function (ok) { setBusy(false, b); if (ok) finish(); else warn(); });
      });
    } else if (a === 'delete') {
      var pw = $('ac-del-pass').value;
      if (S.provider !== 'google' && !pw) { err('পাসওয়ার্ড দিন।', 'ac-del-err'); return; }
      setBusy(true, b);
      call('deleteAccount', S.provider === 'google' ? '' : pw).then(function (r) {
        setBusy(false, b);
        if (r.ok) { try { localStorage.removeItem(CK); localStorage.removeItem(AVM); localStorage.removeItem(AVD); localStorage.removeItem(AVW); } catch (e) {} S = { signedIn: false }; show('guest'); paintSettings(); toast('অ্যাকাউন্ট ও ক্লাউডের ডেটা মুছে ফেলা হয়েছে', 'success'); try { B().resetLocal(); } catch (e) {} }
        else if (r.code !== 'cancel') err(r.msg, 'ac-del-err');
      });
    }
  });

  $('ac-form').addEventListener('submit', function (e) {
    e.preventDefault(); if (busy) return;
    var name = $('ac-name').value.trim(), em = $('ac-email').value.trim(), pw = $('ac-pass').value;
    if (mode === 'up' && name.length < 2) { err('আপনার নাম লিখুন।'); $('ac-name').focus(); return; }
    if (!/^\S+@\S+\.\S+$/.test(em)) { err('ইমেইল ঠিকানাটি সঠিক নয়।'); $('ac-email').focus(); return; }
    if (pw.length < 6) { err('পাসওয়ার্ড অন্তত ৬ অক্ষরের দিন।'); $('ac-pass').focus(); return; }
    var btn = $('ac-submit'); setBusy(true, btn);
    (mode === 'up' ? call('emailUp', name, em, pw) : call('emailIn', em, pw)).then(function (r) {
      setBusy(false, btn);
      if (r.ok) { $('ac-pass').value = ''; afterSignIn(r, mode); }
      else { err(r.msg); if (r.code === 'exists') setTimeout(function () { var sg = sheet.querySelector('.ac-seg'); if (sg && sg.ptSelect) sg.ptSelect(0); setMode('in'); err(r.msg); }, 10); }
    });
  });
  var seg = sheet.querySelector('.ac-seg');
  if (seg) seg.addEventListener('pt:change', function (e) { setMode(e.detail.index ? 'up' : 'in'); });

  $('ac-auto').addEventListener('change', function () { var c = cloudState(); c.on = this.checked; if (c.on) c.hold = false; jset(CK, c); paintUser(); if (c.on) push(false); });

  /* v182: নাম/ছবিতে বদল না থাকলে "সেভ করুন" ধূসর — বদল করলেই চালু */
  function pfDirty() {
    var sv = $('pf-save'); if (!sv) return;
    if (view !== 'user') { sv.disabled = false; return; }
    var p = jget('pt_profile') || {}, nm = $('pf-name').value.trim();
    var ph = W.__ptProfilePending ? (W.__ptProfilePending() || '') : (p.photo || '');
    sv.disabled = (nm === (p.name || '').trim()) && (ph === (p.photo || ''));
  }
  $('pf-name').addEventListener('input', pfDirty);
  ['pf-file', 'pf-remove', 'pf-photo'].forEach(function (id) { var el = $(id); if (el) el.addEventListener(id === 'pf-file' ? 'change' : 'click', function () { setTimeout(pfDirty, 60); setTimeout(pfDirty, 600); }); });
  var _show = show; show = function (v) { _show(v); pfDirty(); };

  /* সাইন-ইন অবস্থায় নাম বদলালে অ্যাকাউন্টেও (সেভ বাটনের নিজের কাজ 09-home.js করে) */
  $('pf-save').addEventListener('click', function () {
    if (!S.signedIn) return;
    if (hsh(photoNow()) !== baseH) { try { localStorage.removeItem(AVW); } catch (e) {} jset(AVD, { uid: S.uid }); baseH = hsh(photoNow()); syncAvatar(true); }   /* নিজে ছবি বদলালে/সরালে সেটিই চূড়ান্ত */
    var n = $('pf-name').value.trim(); if (n && n !== S.name) call('setName', n);
  });

  /* ---------------------------------------------------------------- শুরু */
  readState(); paintSettings();
  if (S.signedIn) setTimeout(function () { var c = cloudState(); if (!c.at && !c.hold) firstSync(); else syncOnOpen(c); syncAvatar(false); loadCloudAvatar(false); }, 700);
})();
