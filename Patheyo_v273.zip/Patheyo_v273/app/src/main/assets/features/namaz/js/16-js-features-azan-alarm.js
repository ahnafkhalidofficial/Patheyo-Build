/* js/features/azan-alarm.js */
/* =============================================================================
   আজান ও অ্যালার্ম
   ওয়াক্তভিত্তিক অ্যালার্ম সেটিং, আজান টোস্ট/বন্ধ, অডিও টেস্ট, মাযহাব সেভ।
   ============================================================================= */

function checkAndTriggerConfiguredAlarms(now) {
    // Android native AlarmManager ইতিমধ্যে আজান হ্যান্ডেল করে — JS টাইমার দিয়ে ডুপ্লিকেট এড়ানো
    if (window.AndroidWidgetBridge) return;

    const minKey = `${now.getHours()}:${now.getMinutes()}`;
    if(firedAlarmsCacheKey === minKey) return;

    for(let w in waqtConfigs) {
        const c = waqtConfigs[w]; if(!c.active) continue;

        let tarH = 0; let tarM = 0;
        if(c.isCustom) {
            tarM = parseInt(c.minute); let h24 = parseInt(c.hour);
            if(c.ampm === "PM" && h24 < 12) h24 += 12;
            if(c.ampm === "AM" && h24 === 12) h24 = 0;
            tarH = h24;
        } else {
            const [apiH, apiM] = globalTimings[w].split(':').map(Number);
            tarH = apiH; tarM = apiM;
        }

        if(now.getHours() === tarH && now.getMinutes() === tarM) {
            firedAlarmsCacheKey = minKey; fireAzanNotificationToast(w); break;
        }
    }
}

function fireAzanNotificationToast(wKey) {
    const waqtName = waqtBnName(wKey, new Date());
    document.getElementById('toast-title').innerText = `${waqtName} ওয়াক্তের আজান শুরু হচ্ছে`;
    document.getElementById('azan-toast-overlay').classList.remove('hidden');
    const stopBanner = document.getElementById('stop-azan-btn');
    if (stopBanner) stopBanner.classList.remove('hidden');
    azanAudioEngine.currentTime = 0; azanAudioEngine.play().catch(e => console.log(e));
    if (window.AndroidWidgetBridge) {
        if (typeof window.AndroidWidgetBridge.showAzanNotification === 'function') {
            try { window.AndroidWidgetBridge.showAzanNotification(wKey, waqtName); } catch(e) {}
        }
        if (typeof window.AndroidWidgetBridge.showAzanOverlay === 'function') {
            try { window.AndroidWidgetBridge.showAzanOverlay(waqtName); } catch(e) {}
        }
    }
    if ('Notification' in window && Notification.permission === 'granted') {
        try { new Notification(`🕌 ${waqtName} ওয়াক্তের আজান`, { body: `${waqtName} নামাজের সময় হয়েছে।`, icon: window.__ASSET.logo, tag: 'azan-' + wKey }); } catch(e) {}
    }
}

function stopAzanRinging() {
    if (typeof nafalStopAlarm === 'function') nafalStopAlarm();
    azanAudioEngine.pause();
    document.getElementById('azan-toast-overlay').classList.add('hidden');
    const tp = document.querySelector('#azan-toast-overlay p'); if (tp && tp.dataset.orig) tp.innerText = tp.dataset.orig;
    const stopBanner = document.getElementById('stop-azan-btn');
    if (stopBanner) stopBanner.classList.add('hidden');
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.stopAzan === 'function') {
        try { window.AndroidWidgetBridge.stopAzan(); } catch(e) {}
    }
}

let isTestingAudio = false;
function toggleAudioTest() {
    const btn = document.getElementById('btn-audio-test');
    if(!isTestingAudio) {
        azanAudioEngine.currentTime = 0; azanAudioEngine.play();
        btn.innerHTML = nzIc('pause') + 'থামান'; isTestingAudio = true;
    } else {
        azanAudioEngine.pause(); btn.innerHTML = nzIc('play') + 'শুনুন'; isTestingAudio = false;
    }
}

function openWaqtConfigModal(wKey) {
    targetedActiveWaqtKey = wKey; const cnf = waqtConfigs[wKey];
    document.getElementById('modal-waqt-title-label').innerText = `${waqtBnName(wKey, new Date())}-এর অ্যালার্ম`;
    const tb = document.getElementById('btn-audio-test'); if (tb && !isTestingAudio) tb.innerHTML = nzIc('play') + 'শুনুন';
    setAlarmCustomTimeMode(cnf.isCustom);
    document.getElementById('custom-hour').value = cnf.hour;
    document.getElementById('custom-minute').value = cnf.minute;
    document.getElementById('custom-ampm').value = cnf.ampm; if (typeof wmSyncAmPm === 'function') wmSyncAmPm();
    const offsetInput = document.getElementById('custom-minute-offset');
    if (offsetInput) offsetInput.value = waqtMinuteOffsets[wKey] || 0;
    PT.sheet.open(document.getElementById('waqt-setup-modal'));
    if (typeof wmUpdateResetBtn === 'function') {
        clearTimeout(wmResetTimer); wmResetState = '';
        const rc = document.getElementById('wm-reset-card'); if (rc) rc.classList.remove('busy', 'done');
        const rb = document.getElementById('wm-reset-btn'); if (rb) rb.classList.remove('busy');
        const rl = document.getElementById('wm-reset-lbl'); if (rl) rl.textContent = 'রিসেট';
        wmUpdateResetBtn();
    }
}
function closeWaqtModal() { PT.sheet.close(document.getElementById('waqt-setup-modal')); }
(function () { const m = document.getElementById('waqt-setup-modal'); if (m) m.addEventListener('pt:close', function () { if (isTestingAudio) toggleAudioTest(); }); })();
function setAlarmCustomTimeMode(isCustom) {
    document.getElementById('custom-time-pickers-row').style.display = isCustom ? 'block' : 'none';
    const seg = document.getElementById('amode-seg'); if (seg) seg.dataset.mode = isCustom ? 'custom' : 'api';
    document.getElementById('amode-custom').classList.toggle('on', isCustom);
    document.getElementById('amode-api').classList.toggle('on', !isCustom);
    document.getElementById('amode-custom').setAttribute('data-state', isCustom);
}
function saveWaqtSpecificAlarmSettings() {
    const isCustom = document.getElementById('amode-custom').getAttribute('data-state') === 'true';
    waqtConfigs[targetedActiveWaqtKey].isCustom = isCustom;
    waqtConfigs[targetedActiveWaqtKey].hour = String(document.getElementById('custom-hour').value).padStart(2,'0');
    waqtConfigs[targetedActiveWaqtKey].minute = String(document.getElementById('custom-minute').value).padStart(2,'0');
    waqtConfigs[targetedActiveWaqtKey].ampm = document.getElementById('custom-ampm').value;
    localStorage.setItem('waqtConfigs', JSON.stringify(waqtConfigs));
    const offsetInput = document.getElementById('custom-minute-offset');
    if (offsetInput) saveWaqtMinuteOffset(targetedActiveWaqtKey, offsetInput.value);
    closeWaqtModal(); processDashboardTimelineUpdates(new Date());
    syncAlarmConfigsToNativeBridge();
    if (window.PT) PT.toast(`${waqtBnName(targetedActiveWaqtKey, new Date())}-এর সেটিংস সেভ হয়েছে`, { type: 'success' });
}

function syncMadhabUI(){var s=document.getElementById('setting-madhab'),g=document.getElementById('mz-seg');if(!s||!g)return;g.setAttribute('data-v',s.value);g.querySelectorAll('button').forEach(function(b){b.setAttribute('aria-checked',b.getAttribute('data-v')===s.value?'true':'false')});if(typeof nzSegSync==='function')nzSegSync(g)}
function setMadhabUI(v){var s=document.getElementById('setting-madhab');if(!s||s.value===v)return;s.value=v;syncMadhabUI();saveMadhabAndRecomputeAll();try{if(navigator.vibrate)navigator.vibrate(8)}catch(e){}}
function saveMadhabAndRecomputeAll() { 
    currentMadhab = document.getElementById('setting-madhab').value; 
    localStorage.setItem('currentMadhab', currentMadhab); nzRecompute(); 
}

function toggleAlarmActiveState(wKey) {
    waqtConfigs[wKey].active = !waqtConfigs[wKey].active;
    localStorage.setItem('waqtConfigs', JSON.stringify(waqtConfigs));
    if (window.PT) { PT.haptic('light'); PT.toast(`${waqtBnName(wKey, new Date())}-এর আজান ${waqtConfigs[wKey].active ? 'চালু' : 'বন্ধ'} হলো`, waqtConfigs[wKey].active ? { type: 'success' } : { icon: 'bell-off' }); }
    processDashboardTimelineUpdates(new Date());
    syncAlarmConfigsToNativeBridge();
}

