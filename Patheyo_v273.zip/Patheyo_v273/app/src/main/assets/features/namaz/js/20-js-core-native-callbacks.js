/* js/core/native-callbacks.js */
/* =============================================================================
   নেটিভ (Kotlin) → JS entry-point
   MainActivity যে ফাংশনগুলো কল করে: setNativeNetworkStatus, onAzanStopped, handleNativeBackPress।
   ⚠️ এই ফাইল বাকি সব ফাইলের পরে (শেষের দিকে) লোড হবে। কারণ: Kotlin এগুলো যেকোনো সময়
   কল করতে পারে (typeof চেক করে) — এমনকি পেজ লোড চলাকালেও। মূল একক স্ক্রিপ্টে সব ফাংশন
   একসাথে তৈরি হতো; এখানেও তাই এগুলো সবার শেষে রাখা হয়েছে, যাতে ফাংশনটা "আছে" বলে
   ধরা পড়ার সময় তার সব নির্ভরতাও তৈরি থাকে।
   ============================================================================= */

// Android native network status callback
window.setNativeNetworkStatus = function(isOnline) {
    const wasOffline = (nativeNetworkStatus === false) || isShowingOfflineData || !globalTimings;
    nativeNetworkStatus = isOnline;
    if (isOnline) {
        // শুধু তখনই আবার ফেচ করা হবে যদি আগে অফলাইন/ব্যর্থ অবস্থায় ছিলাম — নাহলে প্রতিটা মিনর
        // নেটওয়ার্ক কলব্যাকে (যেমন ওয়াইফাই↔মোবাইল ডেটা পরিবর্তন) অযথা বারবার ফেচ হবে না
        if (wasOffline) { fetchCorePrayerData(); } else { notifyOfflineBannerState(false); }
    } else {
        notifyOfflineBannerState(true);
    }
};

// আজান বন্ধ হলে UI-তে জানানোর receiver (MainActivity onNewIntent থেকে কল হয়)
window.onAzanStopped = function() {
    azanAudioEngine.pause();
    document.getElementById('azan-toast-overlay')?.classList.add('hidden');
    const btn = document.getElementById('stop-azan-btn');
    if (btn) btn.classList.add('hidden');
};

// Android ব্যাক বাটন — খোলা পপআপ থাকলে আগে সেটি বন্ধ (true), নইলে পেজ বন্ধ হোক (false)
// হোম (shell/js/06-native-bridge.js) খোলা পেজের __ptFrameBack() আগে জিজ্ঞেস করে।
window.handleNativeBackPress = window.__ptFrameBack = function() {
    try { if (window.PT && PT.handleBack && PT.handleBack()) return true; } catch (e) {}
    return false;
};
