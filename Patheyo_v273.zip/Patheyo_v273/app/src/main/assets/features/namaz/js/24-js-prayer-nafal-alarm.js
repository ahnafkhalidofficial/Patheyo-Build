/* js/prayer/nafal-alarm.js — নফল নামাজের অ্যালার্ম */
const NF_SOUND_LIST = [
    { id: 'system', title: 'ফোনের ডিফল্ট সাউন্ড', sub: 'ফোনে সেট করা ডিফল্ট নোটিফিকেশন/অ্যালার্ম সাউন্ড' },
    { id: 'azan', title: 'আজান', sub: 'অ্যাপের আজান' }
];
const NF_NAMES = { ishrak: 'ইশরাক', chasht: 'চাশত', awabin: 'আওয়াবিন', tahajjud: 'তাহাজ্জুদ' };
window.nafalConfigs = (function () {
    const d = { ishrak: { active: false, sound: 'system' }, chasht: { active: false, sound: 'system' }, awabin: { active: false, sound: 'system' }, tahajjud: { active: false, sound: 'system' } };
    try { const v = JSON.parse(localStorage.getItem('nafalConfigs') || 'null'); if (v) for (const k in d) if (v[k]) d[k] = Object.assign(d[k], v[k]); for (const k in d) if (/^s[123]$/.test(d[k].sound)) d[k].sound = 'azan'; } catch (e) {}
    return d;
})();
function nfSave() { try { localStorage.setItem('nafalConfigs', JSON.stringify(nafalConfigs)); } catch (e) {} }

/* ---- নিজের সাউন্ড: IndexedDB-তে রাখা হয় (বড় ফাইলের জন্য) ---- */
function nfDb() {
    return new Promise((res, rej) => {
        try {
            const r = indexedDB.open('nafalSounds', 1);
            r.onupgradeneeded = () => r.result.createObjectStore('s');
            r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
        } catch (e) { rej(e); }
    });
}
function nfPutSound(id, blob) { return nfDb().then(db => new Promise((res, rej) => { const t = db.transaction('s', 'readwrite'); t.objectStore('s').put(blob, id); t.oncomplete = () => res(); t.onerror = () => rej(t.error); })); }
function nfGetSound(id) { return nfDb().then(db => new Promise((res, rej) => { const q = db.transaction('s').objectStore('s').get(id); q.onsuccess = () => res(q.result || null); q.onerror = () => rej(q.error); })); }

/* ---- সাউন্ড বাজানো ---- */
const nafalAudio = new Audio(); nafalAudio.loop = false;
let nfPreview = null, nfStopTimer = null;
function nfStopPreview() { if (nfPreview) { nfPreview.pause(); nfPreview = null; } document.querySelectorAll('.nfo-p').forEach(b => { b.innerHTML = nzIc('play'); b.classList.remove('on'); }); }
async function nfResolveSrc(soundId, nafalId, pendingBlob) {
    if (soundId === 'custom') {
        const b = pendingBlob || await nfGetSound(nafalId).catch(() => null);
        if (b) return URL.createObjectURL(b);
        return window.__ASSET.azan;
    }
    return window.__ASSET.azan;
}
function nfPlaySystemSound(title) {
    const br = window.AndroidWidgetBridge;
    if (br && typeof br.playDefaultAlarmSound === 'function') { try { br.playDefaultAlarmSound(); return true; } catch (e) {} }
    if ('Notification' in window && Notification.permission === 'granted') {
        try { new Notification(title, { body: 'নফল নামাজের সময় হয়েছে।', silent: false, icon: window.__ASSET && window.__ASSET.logo }); return true; } catch (e) {}
    }
    return false;
}
async function nafalRing(id) {
    const cfg = nafalConfigs[id], name = NF_NAMES[id];
    const title = `${name} নামাজের সময় হয়েছে`;
    const toast = document.getElementById('azan-toast-overlay');
    if (toast) {
        document.getElementById('toast-title').innerText = title;
        const p = toast.querySelector('p'); if (p) { if (!p.dataset.orig) p.dataset.orig = p.innerText; p.innerText = 'নফল নামাজের জন্য আপনার সেট করা অ্যালার্ম।'; }
        toast.classList.remove('hidden');
    }
    let played = false;
    if (cfg.sound === 'system') played = nfPlaySystemSound(title);
    if (!played) {
        try { nafalAudio.loop = false; nafalAudio.src = await nfResolveSrc(cfg.sound === 'system' ? 'azan' : cfg.sound, id); nafalAudio.currentTime = 0; await nafalAudio.play(); } catch (e) { console.log(e); }
    }
    clearTimeout(nfStopTimer); nfStopTimer = setTimeout(() => { if (typeof stopAzanRinging === 'function') stopAzanRinging(); }, 240000);
}
function nafalStopAlarm() {
    nafalAudio.pause(); clearTimeout(nfStopTimer);
    const toast = document.getElementById('azan-toast-overlay'); const p = toast && toast.querySelector('p');
    if (p && p.dataset.orig) p.innerText = p.dataset.orig;
}

/* ---- সময় হলে বাজানো + নেটিভ অ্যাপকে জানানো ---- */
let nfLastSync = '';
function nfAfterCompute(items, now) {
    const resolved = {};
    items.forEach(it => {
        const c = nafalConfigs[it.id];
        resolved[it.id] = { active: !!c.active, time: p2h(it.alarm), sound: c.sound };
        if (!c.active) return;
        const diff = now - it.alarm;
        const key = it.id + '_' + it.alarm.getTime();
        if (diff >= 0 && diff < 60000 && localStorage.getItem('nfFired_' + it.id) !== key) {
            try { localStorage.setItem('nfFired_' + it.id, key); } catch (e) {}
            nafalRing(it.id);
        }
    });
    const js = JSON.stringify(resolved);
    if (js !== nfLastSync) {
        nfLastSync = js;
        const br = window.AndroidWidgetBridge;
        if (br && typeof br.saveNafalAlarms === 'function') { try { br.saveNafalAlarms(js); } catch (e) {} }
    }
}
function p2h(d) { return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function nfRerender() { if (window.__nfLast) renderNafalAndForbiddenCards(window.__nfLast[0], new Date()); }

function nfToggle(id) {
    const c = nafalConfigs[id]; c.active = !c.active; nfSave();
    if (c.active && 'Notification' in window && Notification.permission === 'default') { try { Notification.requestPermission(); } catch (e) {} }
    nfRerender();
    if (window.PT) { PT.haptic('light'); PT.toast(`${NF_NAMES[id]}-এর অ্যালার্ম ${c.active ? 'চালু' : 'বন্ধ'} হলো`, c.active ? { type: 'success' } : { icon: 'bell-off' }); }
}

/* ---- সেটিংস পপআপ ---- */
let nfEditId = null, nfDraft = 'system', nfPendingBlob = null, nfPendingName = '';
function nfRenderOptions() {
    const cfg = nafalConfigs[nfEditId];
    let h = '';
    NF_SOUND_LIST.forEach(o => {
        h += `<div class="pt-option nfo" role="radio" tabindex="0" aria-checked="${nfDraft === o.id}" onclick="nfSelect('${o.id}')"><span class="pt-option__radio"></span><div class="pt-grow"><div class="pt-row__title">${o.title}</div><div class="pt-row__sub">${o.sub}</div></div>${o.id !== 'system' ? `<button type="button" class="nfo-p" onclick="event.stopPropagation();nfTogglePreview('${o.id}',this)" aria-label="শুনুন">${nzIc('play')}</button>` : ''}</div>`;
    });
    const hasCustom = nfPendingBlob || cfg.customName;
    if (hasCustom) {
        const nm = nfPendingBlob ? nfPendingName : cfg.customName;
        h += `<div class="pt-option nfo" role="radio" tabindex="0" aria-checked="${nfDraft === 'custom'}" onclick="nfSelect('custom')"><span class="pt-option__radio"></span><div class="pt-grow"><div class="pt-row__title">আপনার সাউন্ড</div><div class="pt-row__sub">${nm.replace(/[<>&]/g, '')}</div></div><button type="button" class="nfo-p" onclick="event.stopPropagation();nfTogglePreview('custom',this)" aria-label="শুনুন">${nzIc('play')}</button></div>`;
    }
    document.getElementById('nf-sound-list').innerHTML = h;
}
function nfOpenSettings(id) {
    nfEditId = id; nfDraft = nafalConfigs[id].sound; nfPendingBlob = null; nfPendingName = '';
    document.getElementById('nf-modal-title').innerText = `${NF_NAMES[id]} নামাজের অ্যালার্ম`;
    nfRenderOptions();
    PT.sheet.open(document.getElementById('nafal-alarm-modal'));
}
function nfCloseSettings() { nfStopPreview(); PT.sheet.close(document.getElementById('nafal-alarm-modal')); }
(function () { const m = document.getElementById('nafal-alarm-modal'); if (m) m.addEventListener('pt:close', nfStopPreview); })();
function nfSelect(id) { nfDraft = id; nfRenderOptions(); }
async function nfTogglePreview(soundId, btn) {
    const was = nfPreview; nfStopPreview(); if (was) return;
    try {
        const src = await nfResolveSrc(soundId, nfEditId, nfPendingBlob);
        nfPreview = new Audio(src); nfPreview.onended = nfStopPreview; await nfPreview.play();
        btn.innerHTML = nzIc('pause'); btn.classList.add('on');
    } catch (e) { console.log(e); nfPreview = null; }
}
function nfPickFile(input) {
    const f = input.files && input.files[0]; input.value = '';
    if (!f) return;
    if (f.size > 8 * 1024 * 1024) { PT.toast('ফাইলটি ৮ MB-র বেশি — ছোট অডিও ফাইল বেছে নিন', { type: 'danger' }); return; }
    nfStopPreview(); nfPendingBlob = f; nfPendingName = f.name; nfDraft = 'custom'; nfRenderOptions();
}
async function nfSaveSettings() {
    const c = nafalConfigs[nfEditId];
    if (nfDraft === 'custom' && nfPendingBlob) {
        try { await nfPutSound(nfEditId, nfPendingBlob); c.customName = nfPendingName; } catch (e) { PT.toast('সাউন্ডটি সেভ করা যায়নি — অন্য ফাইল চেষ্টা করুন', { type: 'danger' }); return; }
    }
    if (nfDraft === 'custom' && !c.customName) nfDraft = 'system';
    c.sound = nfDraft; nfSave(); nfCloseSettings(); if (window.PT) PT.toast('সাউন্ড সেভ হয়েছে', { type: 'success' });
    if ('Notification' in window && Notification.permission === 'default' && nfDraft === 'system') { try { Notification.requestPermission(); } catch (e) {} }
    nfRerender();
}
