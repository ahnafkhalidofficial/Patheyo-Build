/* js/integrations/hijri-sync.js */
/* =============================================================================
   Firebase/নেটিভ হিজরি তারিখ সিঙ্ক
   নেটিভ বা Firebase থেকে হিজরি অ্যাডজাস্টমেন্ট/সরাসরি তারিখ গ্রহণ (রিয়েল-টাইম স্ট্রিমসহ)।
   ⚠️ এই ফাইল সবসময় সবার শেষে লোড হবে: এটি লোড হওয়ামাত্র Firebase ফেচ শুরু করে,
   আর সেই ফলাফল এসে fetchCorePrayerData() ইত্যাদি চালায় — তখন বাকি সব ফাংশন ডিফাইন থাকতে হবে।
   ============================================================================= */

// Firebase / Native থেকে আরবি তারিখের config পাওয়ার JS receiver
window.setNativeHijriConfig = function(config) {
    if (config) {
        const oldAdj = window._nativeHijriAdjustment;
        window._nativeHijriAdjustment = config.adjustment !== undefined ? parseInt(config.adjustment) : 0;
        window._nativeMethodId = config.methodId || 1;
        window._nativeDirectHijriDate = config.directDate || null;
        window._nativeHijriOverride = (config.override && config.override.on) ? config.override : null;   // ভাষা-ভিত্তিক ওভাররাইড (bn/en/…)

        localStorage.setItem('hijriAdjustment', window._nativeHijriAdjustment);
        localStorage.setItem('prayerMethodId', window._nativeMethodId);

        // যদি অ্যাডজাস্টমেন্ট পরিবর্তন হয়, তবে পুরনো ক্যাশ (Anchor) মুছে ফেলতে হবে
        if (oldAdj !== window._nativeHijriAdjustment) {
            hijriApiAnchor = null;
        }

        // সরাসরি তারিখ বা অ্যাডজাস্টমেন্ট যাই আসুক, স্ক্রিন আপডেট করা
        const hijriStr = pcBn(getFinalHijriDisplayString(new Date()));
        const hijriEl = document.getElementById('cal-hijri');
        if (hijriEl) hijriEl.innerText = hijriStr;

        // নতুন অ্যাডজাস্টমেন্ট দিয়ে ডেটা রি-ফেচ করা
        if (typeof fetchCorePrayerData === 'function') fetchCorePrayerData();
    }
};

// =====================================================================================
// 🔥 Firebase Realtime Database — আরবি/হিজরি তারিখ রিয়েল-টাইম কন্ট্রোল সিস্টেম
// Firebase কনসোলে গিয়ে prayer_config/hijri_adjustment বা prayer_config/hijri_date
// পরিবর্তন করলে এই ওয়েবসাইটে কোনো কোড পরিবর্তন না করেই সাথে সাথে (রিয়েল-টাইম) আপডেট হয়ে যাবে।
//
// hijri_adjustment: সংখ্যা (যেমন -1, 0, 1) → বর্তমান হিজরি তারিখে দিন যুক্ত/বিয়োগ হবে
// hijri_date: যদি কিছু লেখা থাকে (যেমন "15 মুহাররম 1448") সেটিই সরাসরি দেখানো হবে,
//             খালি রাখলে ("") স্বাভাবিক হিসাব করা হিজরি তারিখ দেখানো হবে
// =====================================================================================
(function initFirebaseHijriSync() {
    const REST_JSON_URL = "https://hijri-tarikh-default-rtdb.firebaseio.com/prayer_config.json";

    function applyFirebaseHijriConfig(cfg) {
        if (!cfg) return;
        const adjustment = (cfg.hijri_adjustment !== undefined && cfg.hijri_adjustment !== null) ? parseInt(cfg.hijri_adjustment) : 0;
        const fb = hijriOverrideFromFirebaseConfig(cfg);   // hijri_override সুইচ + bn/en তারিখ (না থাকলে পুরনো hijri_date)
        window.setNativeHijriConfig({ adjustment: adjustment, directDate: fb.directDate, override: fb.override });
    }

    // পেজ লোড হওয়ার সাথে সাথে একবার বর্তমান ডেটা নিয়ে আসা হলো
    fetch(REST_JSON_URL)
        .then(r => r.json())
        .then(applyFirebaseHijriConfig)
        .catch(e => console.log('Firebase প্রাথমিক ডেটা আনতে সমস্যা হয়েছে:', e));

    // রিয়েল-টাইম লিসেনার — Firebase REST স্ট্রিমিং (Server-Sent Events) ব্যবহার করে।
    // Firebase কনসোলে ভ্যালু পরিবর্তন হওয়া মাত্রই এই কোড সেটি ধরে ফেলবে, পেজ রিফ্রেশের প্রয়োজন নেই।
    function connectFirebaseRealtimeStream() {
        try {
            const stream = new EventSource(REST_JSON_URL);
            stream.addEventListener('put', function(e) {
                try {
                    const payload = JSON.parse(e.data);
                    if (payload && payload.path === "/") {
                        applyFirebaseHijriConfig(payload.data);
                    } else {
                        // hijri_adjustment বা hijri_date এর মধ্যে যেকোনো একটি আলাদাভাবে আপডেট হলে
                        // পুরো prayer_config আবার ফেচ করে নিশ্চিত হওয়া হলো
                        fetch(REST_JSON_URL).then(r => r.json()).then(applyFirebaseHijriConfig);
                    }
                } catch (err) { console.log('Firebase স্ট্রিম ডেটা পার্স করতে সমস্যা:', err); }
            });
            stream.addEventListener('patch', function() {
                fetch(REST_JSON_URL).then(r => r.json()).then(applyFirebaseHijriConfig);
            });
            stream.onerror = function() {
                // কানেকশন ছিঁড়ে গেলে কিছুক্ষণ পর আবার রিকানেক্ট করার চেষ্টা
                stream.close();
                setTimeout(connectFirebaseRealtimeStream, 5000);
            };
        } catch (e) {
            console.log('Firebase রিয়েল-টাইম স্ট্রিম চালু করতে সমস্যা হয়েছে:', e);
        }
    }
    connectFirebaseRealtimeStream();
})();

