/* js/ui/dashboard.js */
/* =============================================================================
   মূল ড্যাশবোর্ড (ধাপ ৩ রিডিজাইন)
   - ওপরে বর্তমান ওয়াক্তের রিং (হিরো): চলমান ওয়াক্ত / নিষিদ্ধ সময় / সূর্যোদয়-যোহরের ফাঁক
   - ফরজ টাইমলাইন: প্রতি ওয়াক্তে শুরু–শেষ, আদায়-চিহ্ন (আমলের রিপোর্ট), আজান অন/অফ; চাপলে অ্যালার্ম সেটিংস
   তালিকা শুধু অবস্থা বদলালে নতুন করে আঁকা হয় (বাটনের অ্যানিমেশন ভাঙে না); প্রতি সেকেন্ডে শুধু
   কাউন্টডাউন ও প্রোগ্রেস বদলায়।
   ⚠️ হোম (05-pages-controller.js → __homeSnap) processDashboardTimelineUpdates-এর কোড থেকে নিষিদ্ধ সময়ের
   মিনিট পড়ে: "tm['Sunrise'].getTime() + 15*60000", "tm['Dhuhr'].getTime() - 12*60000", "tm['Sunset'].getTime() - 15*60000"
   — এই লেখাগুলোর ধরন বদলাবেন না।
   ============================================================================= */

// একটি ওয়াক্তের সময়সীমার মাঝে আমরা কোথায় আছি — প্রথমার্ধে "অতিবাহিত", দ্বিতীয়ার্ধে "শেষ হতে বাকি"
function getWaqtPhaseInfo(start, end, now) {
    let elapsedMs = now - start;
    let remainingMs = end - now;
    if (elapsedMs < 0) elapsedMs = 0;
    if (remainingMs < 0) remainingMs = 0;
    const isFirstHalf = elapsedMs < remainingMs;
    const diffMs = isFirstHalf ? elapsedMs : remainingMs;
    const diffStr = nzHms(diffMs);
    return { isFirstHalf, diffStr, isOver: (now >= end) };
}
function nzHms(ms) {
    ms = Math.max(0, ms);
    const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), s = Math.floor((ms % 60000) / 1000);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

let nzLastState = null;   // হিরো/অন্যান্য অংশ এটি পড়ে (25-js-ui-extras.js)

function processDashboardTimelineUpdates(now) {
    if (!globalTimings) return;
    const tm = {
        'Fajr': parseWaqtStringToDate(globalTimings.Fajr),
        'Sunrise': parseWaqtStringToDate(globalTimings.Sunrise),
        'Dhuhr': parseWaqtStringToDate(globalTimings.Dhuhr),
        'Asr': parseWaqtStringToDate(globalTimings.Asr),
        'Maghrib': parseWaqtStringToDate(globalTimings.Maghrib),
        'Isha': parseWaqtStringToDate(globalTimings.Isha),
        'Sunset': parseWaqtStringToDate(globalTimings.Sunset || globalTimings.Maghrib)
    };

    // নামাজের ৩টা নিষিদ্ধ সময়
    const forbiddenWindows = [
        { key: 'sr', name: 'সূর্যোদয়', start: tm['Sunrise'], end: new Date(tm['Sunrise'].getTime() + 15*60000) },
        { key: 'noon', name: 'মধ্যাহ্ন', start: new Date(tm['Dhuhr'].getTime() - 12*60000), end: tm['Dhuhr'] },
        { key: 'ss', name: 'সূর্যাস্ত', start: new Date(tm['Sunset'].getTime() - 15*60000), end: tm['Sunset'] }
    ];
    let isForbidden = false; let activeForbiddenWindow = null;
    for (const w of forbiddenWindows) {
        if (now >= w.start && now < w.end) { isForbidden = true; activeForbiddenWindow = w; break; }
    }
    document.getElementById('forbidden-time-banner').style.display = isForbidden ? 'flex' : 'none';

    // ফজর সূর্যোদয়ে শেষ; সূর্যোদয় → যোহর পর্যন্ত কোনো ফরজ ওয়াক্ত চলমান নয় (isGap)
    let act = null; let start = null; let end = null; let isGap = false;
    if(now >= tm['Fajr'] && now < tm['Sunrise']) { act = 'Fajr'; start = tm['Fajr']; end = tm['Sunrise']; }
    else if(now >= tm['Sunrise'] && now < tm['Dhuhr']) { isGap = true; start = tm['Sunrise']; end = tm['Dhuhr']; }
    else if(now >= tm['Dhuhr'] && now < tm['Asr']) { act = 'Dhuhr'; start = tm['Dhuhr']; end = tm['Asr']; }
    else if(now >= tm['Asr'] && now < tm['Maghrib']) { act = 'Asr'; start = tm['Asr']; end = tm['Maghrib']; }
    else if(now >= tm['Maghrib'] && now < tm['Isha']) { act = 'Maghrib'; start = tm['Maghrib']; end = tm['Isha']; }
    else {
        act = 'Isha';
        if(now >= tm['Isha']) { start = tm['Isha']; end = new Date(tm['Fajr'].getTime() + 24*60*60000); }
        else { end = tm['Fajr']; start = new Date(tm['Isha'].getTime() - 24*60*60000); }
    }

    nzLastState = { tm, act, start, end, isGap, isForbidden, fw: activeForbiddenWindow, now };
    renderHero(nzLastState);
    renderMainDashboardCards(tm, act, start, end, now, isGap, isForbidden, activeForbiddenWindow);
    renderNafalAndForbiddenCards(tm, now);
    if (typeof nzAfterTick === 'function') nzAfterTick(nzLastState);
}

/* বাংলা ওয়াক্তের নাম — শুক্রবারে যোহরের নাম হবে "জুমা" */
function waqtBnName(id, d) {
    d = d || new Date();
    if (id === 'Dhuhr' && d.getDay() === 5) return 'জুমা';
    return ({ Fajr: 'ফজর', Dhuhr: 'যোহর', Asr: 'আসর', Maghrib: 'মাগরিব', Isha: 'এশা' })[id] || id;
}

/* আইকন — ডিজাইন সিস্টেমের (shared/ds/icons.js) */
function nzIc(name, cls) { return (window.PT && PT.icon) ? PT.icon(name, cls) : ''; }
const PC_ICON = {
    get bell() { return nzIc('bell'); },
    get bellOff() { return nzIc('bell-off'); },
    get gear() { return nzIc('gear'); }
};
const NZ_WAQT_IC = { Fajr: 'fajr', Dhuhr: 'sun', Asr: 'sun-moon', Maghrib: 'sunset', Isha: 'moon', Jumuah: 'mosque' };

const PC_BN = '০১২৩৪৫৬৭৮৯';
function pcBn(s) { return String(s).replace(/\d/g, d => PC_BN[d]); }
/* প্রতিটা ফরজ ওয়াক্ত যে সময়ে শেষ হয় */
const PC_END_KEY = { Fajr: 'Sunrise', Dhuhr: 'Asr', Asr: 'Maghrib', Maghrib: 'Isha', Isha: 'Fajr' };
/* প্রতিটা অঙ্ক নির্দিষ্ট প্রস্থের ঘরে — সেকেন্ড বদলালে লেখা নড়ে না */
function pcFixed(s) { return pcBn(String(s)).replace(/[০-৯]/g, d => `<span class="fd">${d}</span>`).replace(/:/g, '<span class="fc">:</span>'); }
function pcTime(s24) {
    const t = String(convert24To12(s24)).trim().split(' ');
    return { n: pcBn(t[0]), p: t[1] || '' };
}
function nzT(s24) { const t = pcTime(s24); return `${t.n} <small>${t.p}</small>`; }
function nzD(d) { return nzT(String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0')); }

/* ---------------- হিরো: বর্তমান ওয়াক্তের রিং ---------------- */
function nzSet(id, html) { const el = document.getElementById(id); if (el && el.__h !== html) { el.innerHTML = html; el.__h = html; } }
function renderHero(S) {
    const now = S.now;
    let state = 'waqt', kicker = 'এখন চলছে', name = '', cdMs = 0, cdLabel = '', pct = 0, st = S.start, en = S.end, stL = 'শুরু', enL = 'শেষ', warn = '';
    if (S.isForbidden && S.fw) {
        state = 'forbid'; kicker = 'নিষিদ্ধ সময়'; name = S.fw.name;
        st = S.fw.start; en = S.fw.end; cdMs = en - now; cdLabel = 'শেষ হতে বাকি';
        warn = 'এখন নামাজ ও সিজদা থেকে বিরত থাকুন';
    } else if (S.isGap) {
        state = 'gap'; kicker = 'পরের ওয়াক্ত'; name = waqtBnName('Dhuhr', now);
        cdMs = S.end - now; cdLabel = 'শুরু হতে বাকি'; stL = 'সূর্যোদয়'; enL = name + ' শুরু';
    } else {
        name = waqtBnName(S.act, now);
        const ph = getWaqtPhaseInfo(S.start, S.end, now);
        cdMs = ph.isFirstHalf ? (now - S.start) : (S.end - now);
        cdLabel = ph.isFirstHalf ? 'অতিবাহিত' : 'শেষ হতে বাকি';
        if (S.act === 'Isha') enL = 'শেষ';
    }
    const total = en - st;
    pct = total > 0 ? Math.max(0, Math.min(100, ((now - st) / total) * 100)) : 0;

    const ring = document.getElementById('nz-ring');
    if (ring && ring.dataset.state !== state) ring.dataset.state = state;
    const hero = document.getElementById('nz-hero'); if (hero && hero.dataset.state !== state) hero.dataset.state = state;
    nzSet('nz-hero-kicker', kicker);
    nzSet('nz-hero-name', name);
    nzSet('nz-hero-cd', pcFixed(nzHms(cdMs)));
    nzSet('nz-hero-cdl', cdLabel);
    nzSet('nz-hero-st', nzD(st));
    nzSet('nz-hero-en', nzD(en));
    const sp = document.getElementById('nz-hero-span');
    if (sp) { const l = sp.querySelectorAll('span'); if (l[0] && l[0].textContent !== stL) l[0].textContent = stL; if (l[1] && l[1].textContent !== enL) l[1].textContent = enL; }
    const w = document.getElementById('nz-hero-warn');
    if (w) { w.hidden = !warn; if (warn && w.textContent !== warn) w.textContent = warn; }
    const f = document.getElementById('nz-ring-fill');
    if (f) f.setAttribute('stroke-dasharray', pct.toFixed(2) + ' 100');
    if (ring) ring.style.setProperty('--a', (pct * 3.6).toFixed(2) + 'deg');
}

/* ---------------- ফরজ টাইমলাইন ---------------- */
function renderMainDashboardCards(tm, act, start, end, now, isGap, isForbidden, activeForbiddenWindow) {
    const container = document.getElementById('main-prayer-cards-container');
    if (!container) return;
    if (isForbidden) act = null;   /* নিষিদ্ধ সময়ে কোনো ওয়াক্ত "চলমান" দেখানো হয় না */
    const ids = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    const night = now < tm['Fajr'];                         /* রাত ১২টার পর, ফজরের আগে: আগের দিনের এশা চলছে */
    const prayed = (typeof nzPrayedMap === 'function') ? nzPrayedMap(now, tm) : {};

    const key = JSON.stringify([globalTimings, act, isForbidden && activeForbiddenWindow && activeForbiddenWindow.key, waqtConfigs, prayed, now.getDay(), night,
        ids.map(id => now >= tm[id])]);
    if (container.__key !== key) {
        container.__key = key;
        const firstRender = !container.firstElementChild;
        let html = '';
        ids.forEach((id, idx) => {
            const name = waqtBnName(id, now);
            const isCurrent = id === act;
            const started = night ? (id === 'Isha') : (now >= tm[id]);
            const isPast = !isCurrent && started;
            const cnf = waqtConfigs[id] || {};
            const isJumuah = (id === 'Dhuhr' && now.getDay() === 5);
            const ic = NZ_WAQT_IC[isJumuah ? 'Jumuah' : id];
            const st = pcTime(globalTimings[id]);
            const en = pcTime(globalTimings[PC_END_KEY[id]]);
            const pv = prayed[id] || '';
            const chips = (isCurrent ? '<span class="fz-chip live"><i></i>চলমান</span>' : '') +
                (cnf.isCustom ? `<span class="fz-chip">অ্যালার্ম ${pcBn(cnf.hour + ':' + cnf.minute)} ${cnf.ampm}</span>` : '') +
                (waqtMinuteOffsets[id] ? `<span class="fz-chip gold">${waqtMinuteOffsets[id] > 0 ? '+' : '−'}${pcBn(Math.abs(waqtMinuteOffsets[id]))} মি.</span>` : '');
            const doneLbl = pv === 'jamaat' ? 'জামাতে আদায় হয়েছে' : pv === 'alone' ? 'আদায় হয়েছে' : pv === 'qaza' ? 'কাজা' : 'আদায় চিহ্নিত করুন';
            const cls = 'fz' + (isCurrent ? ' cur' : '') + (isPast ? ' past' : '') + (!started ? ' future' : '') + (firstRender ? ' fz-in' : '');
            html += `
            <div class="${cls}" data-w="${id}" role="button" tabindex="0" onclick="openWaqtConfigModal('${id}')"${firstRender ? ` style="animation-delay:${idx * 50}ms"` : ''}>
                <span class="fz-ic pt-medal${isCurrent ? ' pt-medal--accent' : ''}">${nzIc(ic)}</span>
                <div class="fz-main">
                    <div class="fz-name"><b>${name}</b>${chips}</div>
                    <div class="fz-time"><b>${st.n}</b><small>${st.p}</small><i>–</i><b>${en.n}</b><small>${en.p}</small></div>
                    ${isCurrent ? '<div class="fz-bar"><span data-live="bar"></span></div><div class="fz-cd"><span data-live="lbl"></span><b data-live="cd"></b></div>' : ''}
                </div>
                <button type="button" class="fz-btn fz-done${pv ? ' is-' + pv : ''}"${started ? '' : ' disabled'} onclick="event.stopPropagation();nzPrayedOpen('${id}')" aria-label="${name}: ${doneLbl}" title="${doneLbl}">${nzIc('check')}</button>
                <button type="button" class="fz-btn fz-bell${cnf.active ? ' on' : ''}" onclick="event.stopPropagation();window.__pcPop='${id}';toggleAlarmActiveState('${id}')" aria-label="${name}-এর আজান ${cnf.active ? 'চালু' : 'বন্ধ'}" aria-pressed="${cnf.active ? 'true' : 'false'}">${cnf.active ? PC_ICON.bell : PC_ICON.bellOff}</button>
                <span class="fz-go" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></span>
            </div>`;
        });
        container.innerHTML = html;
        const pop = window.__pcPop; window.__pcPop = null;
        if (pop) { const b = container.querySelector(`[data-w="${pop}"] .fz-bell`); if (b) { b.classList.add('pop'); } }
    }
    /* প্রতি সেকেন্ডে: শুধু চলমান ওয়াক্তের প্রোগ্রেস ও কাউন্টডাউন */
    if (act && start && end) {
        const row = container.querySelector(`[data-w="${act}"]`);
        if (row) {
            const total = end - start, pct = total > 0 ? Math.max(0, Math.min(100, ((now - start) / total) * 100)) : 0;
            const ph = getWaqtPhaseInfo(start, end, now);
            const bar = row.querySelector('[data-live="bar"]'); if (bar) bar.style.width = pct.toFixed(1) + '%';
            const lbl = row.querySelector('[data-live="lbl"]'); const t = ph.isFirstHalf ? 'সময় অতিবাহিত' : 'শেষ হতে বাকি';
            if (lbl && lbl.textContent !== t) lbl.textContent = t;
            const cd = row.querySelector('[data-live="cd"]'); if (cd) { const h = pcFixed(ph.diffStr); if (cd.__h !== h) { cd.innerHTML = h; cd.__h = h; } }
        }
    }
}

/* ---------- সেটিংস পপআপের ছোট সহায়ক ফাংশন ---------- */
function wmNorm(el) {
    const min = parseInt(el.min, 10), max = parseInt(el.max, 10);
    let v = parseInt(el.value, 10); if (isNaN(v)) v = (el.id === 'custom-minute-offset') ? 0 : min;
    v = Math.max(min, Math.min(max, v));
    el.value = (el.id === 'custom-minute-offset') ? String(v) : String(v).padStart(2, '0');
}
function wmStep(id, d, min, max, wrap) {
    const el = document.getElementById(id); let v = parseInt(el.value, 10); if (isNaN(v)) v = 0;
    v += d;
    if (v > max) v = wrap ? min : max;
    if (v < min) v = wrap ? max : min;
    el.value = (id === 'custom-minute-offset') ? String(v) : String(v).padStart(2, '0');
    if (window.PT && PT.haptic) PT.haptic('light');
    setTimeout(wmUpdateResetBtn, 0);
}
function wmSyncAmPm() {
    const v = document.getElementById('custom-ampm').value;
    const am = document.getElementById('wm-am'), pm = document.getElementById('wm-pm');
    if (!am || !pm) return;
    am.classList.toggle('on', v === 'AM'); pm.classList.toggle('on', v === 'PM');
    am.parentNode.dataset.v = v;
}
function wmSetAmPm(v) { document.getElementById('custom-ampm').value = v; wmSyncAmPm(); }
/* রিসেট বাটন: নির্দিষ্ট সময় বা মিনিট সমন্বয় থাকলে চালু, না থাকলে নিষ্ক্রিয় */
var wmResetState = '', wmResetTimer = null;
function wmSetSub(t) {
    const sub = document.getElementById('wm-reset-sub'); if (!sub) return;
    sub.textContent = t; sub.classList.remove('swap'); void sub.offsetWidth; sub.classList.add('swap');
}
function wmUpdateResetBtn() {
    const btn = document.getElementById('wm-reset-btn'); if (!btn) return;
    if (wmResetState === 'busy') return;
    const modeBtn = document.getElementById('amode-custom');
    const isCustom = !!modeBtn && modeBtn.getAttribute('data-state') === 'true';
    const offEl = document.getElementById('custom-minute-offset');
    const off = offEl ? (parseInt(offEl.value, 10) || 0) : 0;
    const dirty = isCustom || off !== 0;
    const card = document.getElementById('wm-reset-card');
    if (dirty && wmResetState === 'done') { wmResetState = ''; if (card) card.classList.remove('done'); }
    btn.disabled = !dirty;
    const sec = document.getElementById('wm-reset-sec'); if (sec) sec.classList.toggle('is-idle', !dirty && wmResetState !== 'done');
    if (wmResetState === 'done') return;
    const sub = document.getElementById('wm-reset-sub');
    if (sub) sub.textContent = dirty ? (isCustom && off !== 0 ? 'নির্দিষ্ট সময় ও মিনিট সমন্বয় চালু' : isCustom ? 'নির্দিষ্ট সময় চালু আছে' : 'মিনিট সমন্বয় চালু আছে') : 'ওয়াক্তের নিজস্ব সময় ব্যবহার হচ্ছে';
}
function wmPulse(el) { if (!el) return; el.classList.remove('wm-pulse'); void el.offsetWidth; el.classList.add('wm-pulse'); }
function resetWaqtToRealTime() {
    if (wmResetState === 'busy') return;
    const btn = document.getElementById('wm-reset-btn'), card = document.getElementById('wm-reset-card');
    const lbl = document.getElementById('wm-reset-lbl');
    setAlarmCustomTimeMode(false);
    const offEl = document.getElementById('custom-minute-offset'); if (offEl) { offEl.value = 0; wmPulse(offEl); }
    wmResetState = 'busy';
    if (card) { card.classList.remove('done'); card.classList.add('busy'); }
    if (btn) { btn.disabled = true; btn.classList.add('busy'); }
    if (lbl) lbl.textContent = 'অপেক্ষা করুন';
    wmSetSub('আসল সময়ে ফিরিয়ে আনা হচ্ছে…');
    if (window.PT && PT.haptic) PT.haptic('light');
    clearTimeout(wmResetTimer);
    wmResetTimer = setTimeout(function () {
        wmResetState = 'done';
        if (card) { card.classList.remove('busy'); card.classList.add('done'); }
        if (btn) btn.classList.remove('busy');
        if (lbl) lbl.textContent = 'রিসেট';
        wmUpdateResetBtn();
        wmSetSub('আসল সময়ে ফিরেছে · সেভ করলে কার্যকর হবে');
    }, 900);
}
(function () {
    const m = document.getElementById('waqt-setup-modal'); if (!m) return;
    ['click', 'input', 'change'].forEach(function (ev) {
        m.addEventListener(ev, function (e) {
            if (e.target && e.target.closest && e.target.closest('#wm-reset-btn')) return;
            setTimeout(wmUpdateResetBtn, 0);
        });
    });
})();
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && window.PT && PT.handleBack) PT.handleBack();
});
