/* js/core/app-init.js */
/* =============================================================================
   অ্যাপ চালু হওয়া (init)
   ব্যাক-নেভিগেশন (popstate), window.onload-এর মূল স্টার্টআপ ধাপ এবং লাইভ সিস্টেম ঘড়ি।
   ============================================================================= */

        // ব্রাউজারের ব্যাক বাটনে (popstate) ট্যাব নেভিগেশন — ওয়েবসাইট ও PWA এর জন্য
window.addEventListener('popstate', function(e) {
    const tab = (e.state && e.state.tab) ? e.state.tab : 'dashboard';
    // switchTab কে পুনরায় কল করতে হবে কিন্তু history entry যোগ না করে
    if (typeof restoreQuranHeaderView === 'function' && tab !== 'quran') restoreQuranHeaderView();
    ['dashboard', 'quran', 'tasbih', 'qibla'].forEach(t => {
        document.getElementById(`view-${t}`)?.classList.add('hidden');
        document.getElementById(`tab-${t}`)?.setAttribute('class', "px-3 py-1 md:px-4 md:py-1.5 rounded-lg text-xs font-medium transition text-slate-400 hover:text-white whitespace-nowrap");
    });
    document.getElementById(`view-${tab}`)?.classList.remove('hidden');
    document.getElementById(`tab-${tab}`)?.setAttribute('class', "px-3 py-1 md:px-4 md:py-1.5 rounded-lg text-xs font-bold transition bg-blue-600 text-white whitespace-nowrap");
});

window.onload = function() {
    if(localStorage.getItem('waqtConfigs')) waqtConfigs = JSON.parse(localStorage.getItem('waqtConfigs'));
    if(localStorage.getItem('currentMadhab')) currentMadhab = localStorage.getItem('currentMadhab');
    /* "মসজিদের সাথে মেলান" সরানো হয়েছে — আগের সেভ করা ±মিনিট মুছে ফেলা হলো, যেন লুকানো সমন্বয়ে সময় না সরে */
    try { localStorage.removeItem('waqtMinuteOffsets'); } catch (e) {}
    waqtMinuteOffsets = { Fajr: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0 };
    document.getElementById('setting-madhab').value = currentMadhab; syncMadhabUI();

    // Firebase/Native hijri adjustment localStorage থেকে রিস্টোর
    window._nativeHijriAdjustment = parseInt(localStorage.getItem('hijriAdjustment') || '0');
    window._nativeMethodId = parseInt(localStorage.getItem('prayerMethodId') || '1');

    loadOfflineCacheIntoMemory();
    nzRenderOffline(new Date(), false);      /* ধাপ ৩: নেটের অপেক্ষা না করে ফোনের হিসাবে সাথে সাথে পুরো পেজ */
    initLiveSystemClock();
    requestGeoLocationAndFetch();
    setTimeout(syncAlarmConfigsToNativeBridge, 1200);

    // ওয়েব নোটিফিকেশন পারমিশন চাওয়া
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }

    // =====================================================================
    // মোবাইল সোয়াইপ নেভিগেশন + পুল-টু-রিফ্রেশ
    // =====================================================================
    const swipeTabs = ['dashboard'];
    let swTouchX = 0, swTouchY = 0, swTouchScrollY = 0;

    document.addEventListener('touchstart', function(e) {
        swTouchX = e.changedTouches[0].screenX;
        swTouchY = e.changedTouches[0].screenY;
        swTouchScrollY = window.scrollY;
    }, { passive: true });

    document.addEventListener('touchend', function(e) {
        const deltaX = e.changedTouches[0].screenX - swTouchX;
        const deltaY = e.changedTouches[0].screenY - swTouchY;
        // পুল-টু-রিফ্রেশ: একদম ওপর থেকে নিচে টান দিলে ডেটা রিফ্রেশ হবে
        if (swTouchScrollY === 0 && deltaY > 90 && Math.abs(deltaY) > Math.abs(deltaX) * 1.5 && !(window.PT && PT.sheet && PT.sheet.isOpen())) {
            if (globalTimings) { fetchCorePrayerData(); if (window.PT) PT.toast('সময় আবার মিলিয়ে নেওয়া হচ্ছে…', { icon: 'refresh' }); }
            return;
        }
        // বাম/ডান সোয়াইপে ট্যাব পরিবর্তন (শুধু horizontal swipe)
        // সুইপ একটু "শক্ত" (Threshold 150px) করা হয়েছে যেন ভুল করে প্যানেল না বদলায়
        if (Math.abs(deltaX) > 150 && Math.abs(deltaX) > Math.abs(deltaY) * 2) {
            const curTab = swipeTabs.find(t => {
                const el = document.getElementById('view-' + t);
                return el && !el.classList.contains('hidden');
            });
            const curIdx = swipeTabs.indexOf(curTab);
            if (deltaX < -150 && curIdx < swipeTabs.length - 1) {
                switchTab(swipeTabs[curIdx + 1]); // বামে সোয়াইপ → পরের ট্যাব
            } else if (deltaX > 150 && curIdx > 0) {
                switchTab(swipeTabs[curIdx - 1]); // ডানে সোয়াইপ → আগের ট্যাব
            }
        }
    }, { passive: true });

    // অনলাইন/অফলাইন অবস্থা বদলালেই যেন অ্যাপ নিজে থেকে টের পায় এবং সুন্দরভাবে আপডেট/দেখায়
    // Note: Android native network monitoring handles this now, but keep these as fallback
    window.addEventListener('online', () => { if (nativeNetworkStatus === null) { notifyOfflineBannerState(false); fetchCorePrayerData(); } });
    window.addEventListener('offline', () => { if (nativeNetworkStatus === null) { notifyOfflineBannerState(true); } });
    if (!isActuallyOnline()) { notifyOfflineBannerState(true); }

    // PWA শর্টকাট অথবা "এক ক্লিকে উইজেট" বাটন থেকে সরাসরি উইজেট মোডে আসার জন্য URL প্যারামিটার চেক করা হচ্ছে
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('mode') === 'widget') {
        
    }
};

function initLiveSystemClock() {
    setInterval(() => {
        const now = new Date();
        let hrs = now.getHours();
        const mins = String(now.getMinutes()).padStart(2, '0');
        const secs = String(now.getSeconds()).padStart(2, '0');
        const ampm = hrs >= 12 ? 'PM' : 'AM';
        const rawHrs = hrs;
        hrs = hrs % 12 || 12;

        const displayHrs = String(hrs).padStart(2, '0');
        document.getElementById('live-hour').innerText = displayHrs;
        document.getElementById('live-minute').innerText = mins;
        document.getElementById('live-second').innerText = secs;
        document.getElementById('live-ampm').innerText = ampm;

        if (globalTimings) {
            const hDate = getDisplayHijriDate(now);
            ISLAMIC_NOTIFIER.check(now, hDate);
            processDashboardTimelineUpdates(now);
            checkAndTriggerConfiguredAlarms(now);

            // মাগরিবের মুহূর্তে অ্যাপ খোলা থাকলেও আরবি তারিখ সাথে সাথে পরের দিনে চলে যাবে
            const liveHijriStr = pcBn(getFinalHijriDisplayString(now));
            const hijriEl = document.getElementById('cal-hijri');
            if (hijriEl && hijriEl.innerText !== liveHijriStr) {
                hijriEl.innerText = liveHijriStr;
            }
        }
    }, 1000);
}

