
/*!
 * js/features/events.js -- Wires up every DOM event listener
 *
 * Provides : App.bindEvents
 * Needs    : core/dom, core/state, features/mode-switch, features/tarjama-reader, features/tarjama-download-ui,
               features/footnote-popup, features/bookmark-fab, features/bookmark-modal, features/feedback,
               features/last-read, features/mushaf-fullscreen, features/mushaf-viewer, features/navigation,
               features/para-choice, features/pdf-download-ui, features/pinch-zoom, features/sura-reader,
               features/theme, features/web-reader, services/pdf-service
 */
(function (App) {
  "use strict";

  function bindEvents(){
    App.els.tabs.forEach(function(btn){
      btn.addEventListener('click', function(){ App.switchTab(btn.getAttribute('data-tab')); });
    });
    App.els.themeBtns.forEach(function(btn){
      btn.addEventListener('click', function(){
        var n = btn.getAttribute('data-theme-btn');
        if (n === 'toggle') n = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';   /* sepia -> light -> dark -> light ... */
        App.setTheme(n);
      });
    });
    App.els.backBtn.addEventListener('click', App.goBackOneLevel);
    App.els.paraPagesBackBtn.addEventListener('click', App.goBackOneLevel);
    App.els.webPageBackBtn.addEventListener('click', App.goBackOneLevel);
    App.els.pfCloseBtn.addEventListener('click', App.goBackOneLevel);
    App.els.pagePreviewCanvas.addEventListener('click', function(){ App.openFullscreenPage(App.pageState.current); });
    App.bindZoom();
    App.bindDragNav();
    App.bindPdfDownloadUi();
    App.bindModeSwitch();
    App.bindTarjamaReader();
    App.bindTarjamaDownloadUi();
    App.bindFootnotePopup();

    App.els.suraBmFab.addEventListener('click', function(){
      App.bmTapPulse(App.els.suraBmFab);
      var pos = App.getCurrentVisibleAyah();
      var ayahIdx = pos ? pos.ayah : 1;
      if (App.activeBookmarkId){ App.updateBookmarkPosition(App.activeBookmarkId, { suraIndex: App.currentOpenSuraIndex, ayahIndex: ayahIdx }); }
      else { App.openBookmarkModal({ type:'sura', suraIndex: App.currentOpenSuraIndex, ayahIndex: ayahIdx }); }
    });
    App.els.paraBmFab.addEventListener('click', function(){
      App.bmTapPulse(App.els.paraBmFab);
      if (App.activeBookmarkId){ App.updateBookmarkPosition(App.activeBookmarkId, { pageNum: App.pageState.current, mode:'mushaf' }); }
      else { App.openBookmarkModal({ type:'para-page', pageNum: App.pageState.current, mode:'mushaf' }); }
    });
    App.els.webBmFab.addEventListener('click', function(){
      App.bmTapPulse(App.els.webBmFab);
      var p = App.getCurrentVisibleWebPage();
      if (App.activeBookmarkId){ App.updateBookmarkPosition(App.activeBookmarkId, { pageNum: p, mode:'web' }); }
      else { App.openBookmarkModal({ type:'para-page', pageNum: p, mode:'web' }); }
    });
    App.els.pfBookmarkBtn.addEventListener('click', function(){
      App.bmTapPulse(App.els.pfBookmarkBtn);
      if (App.activeBookmarkId){ App.updateBookmarkPosition(App.activeBookmarkId, { pageNum: App.pf.current, mode:'mushaf' }); }
      else { App.openBookmarkModal({ type:'para-page', pageNum: App.pf.current, mode:'mushaf' }); }
    });
    App.els.bmCancelBtn.addEventListener('click', App.closeBookmarkModal);
    App.els.bmModalOverlay.addEventListener('click', function(e){
      if (e.target === App.els.bmModalOverlay) App.closeBookmarkModal();
    });
    App.els.bmSaveBtn.addEventListener('click', App.saveBookmarkFromModal);
    App.els.choiceMushafBtn.addEventListener('click', function(){
      var idx = App.pendingParaIdx; App.closeParaChoice();
      if (idx) App.openParaPages(idx);
    });
    App.els.choiceWebBtn.addEventListener('click', function(){
      var idx = App.pendingParaIdx; App.closeParaChoice();
      if (idx) App.openParaWebPage(idx);
    });
    App.els.choiceCancelBtn.addEventListener('click', App.closeParaChoice);
    App.els.paraChoiceOverlay.addEventListener('click', function(e){
      if (e.target === App.els.paraChoiceOverlay) App.closeParaChoice();
    });
    App.els.webVerses.addEventListener('click', function(e){
      var t = e.target;
      while (t && t !== App.els.webVerses && !t.classList.contains('aya-number')){ t = t.parentNode; }
      if (!t || t === App.els.webVerses) return;
      var suraIdx = parseInt(t.getAttribute('data-sura'), 10);
      var ayahIdx = parseInt(t.getAttribute('data-ayah'), 10);
      if (!suraIdx || !ayahIdx) return;
      App.openBookmarkModal({ type:'sura', suraIndex:suraIdx, ayahIndex:ayahIdx });
    });
    App.els.pdfPickBtn.addEventListener('click', function(){ App.els.pdfFileInput.click(); });
    App.els.pdfFileInput.addEventListener('change', function(){
      var file = App.els.pdfFileInput.files && App.els.pdfFileInput.files[0];
      if (!file) return;
      App.els.pdfPickBtn.textContent = 'লোড হচ্ছে…';
      App.loadPdfFromPickedFile(file).then(function(){
        App.showPreviewPage(App.pageState.current);
      }).catch(function(){
        App.els.pdfPickBtn.textContent = 'PDF ফাইল বেছে নিন';
        App.showSnackbar('ফাইলটি খোলা যায়নি, সঠিক PDF কি না যাচাই করুন');
      });
    });
    if (window.visualViewport){
      window.visualViewport.addEventListener('resize', function(){
        if (!App.els.bmModalOverlay.classList.contains('hidden')) App.syncModalToViewport();
      });
      window.visualViewport.addEventListener('scroll', function(){
        if (!App.els.bmModalOverlay.classList.contains('hidden')) App.syncModalToViewport();
      });
    }
    App.els.verses.addEventListener('click', function(e){
      var t = e.target;
      while (t && t !== App.els.verses && !t.classList.contains('aya-number')){ t = t.parentNode; }
      if (!t || t === App.els.verses) return;
      var suraIdx = parseInt(t.getAttribute('data-sura'), 10);
      var ayahIdx = parseInt(t.getAttribute('data-ayah'), 10);
      if (!suraIdx || !ayahIdx) return;
      App.openBookmarkModal({ type:'sura', suraIndex:suraIdx, ayahIndex:ayahIdx });
    });

    window.addEventListener('popstate', function(){
      if (App.state.view === 'para-fullscreen'){ App.state.view='para-pages'; App.closeFullscreenPage(); }
      else if (App.state.view === 'para-pages'){ App.state.view='list'; App.closeParaPages(); }
      else if (App.state.view === 'sura-reader'){ App.state.view='list'; App.closeReader(); }
      else if (App.state.view === 'para-web'){ App.state.view='list'; App.closeParaWebPage(); }
      else if (App.state.view === 'tr-fn'){ App.state.view='tr-reader'; App.closeFootnote(true); }
      else if (App.state.view === 'tr-reader'){ App.state.view='list'; App.closeTarjamaReader(); }
    });
    App.els.searchInput.addEventListener('input', function(){ App.filterActiveList(App.els.searchInput.value); });
    App.els.searchClear.addEventListener('click', function(){
      App.els.searchInput.value = '';
      App.filterActiveList('');
      App.els.searchInput.focus();
    });

    // Recompute the bookmark FAB's synced/drifted colour AND the "পড়া চালিয়ে যান" position
    // as the reader scrolls, so both always reflect exactly where the user is right now.
    var bmScrollTicking = false;
    window.addEventListener('scroll', function(){
      if (App.state.view !== 'sura-reader' && App.state.view !== 'para-web') return;
      if (bmScrollTicking) return;
      bmScrollTicking = true;
      requestAnimationFrame(function(){
        if (App.state.view === 'sura-reader') App.updateLastReadSura();
        else if (App.state.view === 'para-web') App.updateLastReadWeb();
        if (App.activeBookmarkId) App.updateBmFabIcon();
        bmScrollTicking = false;
      });
    }, { passive: true });
  }
  App.bindEvents = bindEvents;

})(window.QuranApp = window.QuranApp || {});

