
/*!
 * js/features/bookmark-modal.js -- Add / edit bookmark dialog and the active-bookmark state
 *
 * Provides : App.activeBookmarkId, App.bookmarkTitle, App.closeBookmarkModal, App.openBookmarkModal,
               App.saveBookmarkFromModal, App.syncModalToViewport
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/surah-meta, features/bookmark-fab,
               features/feedback, services/bookmark-store
 */
(function (App) {
  "use strict";

  App.activeBookmarkId = null;

  function bookmarkTitle(bm){
    if (bm.type === 'sura'){ return 'সূরা ' + App.bn(bm.suraIndex) + ', আয়াত ' + App.bn(bm.ayahIndex); }
    return 'পৃষ্ঠা ' + App.bn(bm.pageNum) + ' · পারা ' + App.bn(App.paraForPage(bm.pageNum)) + (bm.mode === 'web' ? ' (ওয়েব পেজ)' : ' (মুসহাফ)');
  }
  App.bookmarkTitle = bookmarkTitle;

  var bmDraft = null;

  function openBookmarkModal(prefill, existingId){
    bmDraft = { type: prefill.type, suraIndex: prefill.suraIndex, ayahIndex: prefill.ayahIndex, pageNum: prefill.pageNum, mode: prefill.mode, id: existingId || null };
    var isEdit = !!existingId;
    App.els.bmModalTitle.textContent = isEdit ? 'বুকমার্ক সম্পাদনা' : 'বুকমার্ক যোগ করুন';
    if (bmDraft.type === 'sura'){
      var sura = App.quranModel[bmDraft.suraIndex-1];
      App.els.bmModalContext.textContent = 'সূরা ' + App.bn(bmDraft.suraIndex) + ' — ' + (App.SURAH_EN[bmDraft.suraIndex-1]||'');
      App.els.bmAyahField.classList.remove('hidden');
      App.els.bmAyahInput.value = App.bn(bmDraft.ayahIndex || 1);
      document.getElementById('bm-ayah-range').textContent = '১ থেকে ' + App.bn(sura.ayahs.length) + ' এর মধ্যে';
    } else {
      App.els.bmModalContext.textContent = 'পৃষ্ঠা ' + App.bn(bmDraft.pageNum) + ' · পারা ' + App.bn(App.paraForPage(bmDraft.pageNum)) + (bmDraft.mode === 'web' ? ' (ওয়েব পেজ)' : ' (মুসহাফ)');
      App.els.bmAyahField.classList.add('hidden');
    }
    var existingLabel = '';
    if (isEdit){
      var arr = App.loadBookmarks();
      for (var i=0;i<arr.length;i++){ if (arr[i].id === existingId){ existingLabel = arr[i].label || ''; break; } }
    }
    App.els.bmNoteInput.value = existingLabel;
    var shareBtn = document.getElementById('bm-share-btn');          // শেয়ার কার্ড: শুধু আয়াতের বুকমার্ক-ডায়ালগে (পৃষ্ঠার নয়)
    if (shareBtn) shareBtn.classList.toggle('hidden', !(bmDraft.type === 'sura' && window.PtShareCard));
    var listenBtn = document.getElementById('bm-listen-btn');        // তিলাওয়াত: শুধু আয়াতের ডায়ালগে
    if (listenBtn) listenBtn.classList.toggle('hidden', !(bmDraft.type === 'sura' && window.QuranAudio));
    App.els.bmModalOverlay.classList.remove('hidden');
    syncModalToViewport();
    setTimeout(function(){ try{ App.els.bmNoteInput.focus(); }catch(e){} }, 50);
  }
  App.openBookmarkModal = openBookmarkModal;

  function syncModalToViewport(){
    if (!window.visualViewport) return;
    var vv = window.visualViewport;
    App.els.bmModalOverlay.style.top = vv.offsetTop + 'px';
    App.els.bmModalOverlay.style.height = vv.height + 'px';
  }
  App.syncModalToViewport = syncModalToViewport;

  function closeBookmarkModal(){
    App.els.bmModalOverlay.classList.add('hidden');
    App.els.bmModalOverlay.style.top = '';
    App.els.bmModalOverlay.style.height = '';
  }
  App.closeBookmarkModal = closeBookmarkModal;

  // ---- শেয়ার কার্ড (সূরা-পাঠ পেজ): আয়াত-নম্বরে চাপলে খোলা ডায়ালগ থেকে ----
  // আরবি সবসময় থাকে; তরজমা ডাউনলোড করা থাকলে উচ্চারণ ও অর্থও কার্ডে আসে।
  function shareAyahCard(sIdx, aIdx){
    if (!window.PtShareCard) return;
    var sura = App.quranModel[sIdx - 1], ay = null, pos = -1, i;
    for (i = 0; i < sura.ayahs.length; i++){ if (sura.ayahs[i].index === aIdx){ ay = sura.ayahs[i]; pos = i; break; } }
    if (!ay) return;
    var name = App.SURAH_BN[sIdx - 1] || '';
    function open(tx){
      window.PtShareCard.open({
        kind: 'ayah',
        title: 'সূরা ' + name,
        ar: ay.text,
        tr: tx && tx.u ? tx.u : '',
        bn: tx && tx.t ? String(tx.t).replace(/\[\[\d+\]\]/g, '').replace(/\s+/g, ' ').trim() : '',
        ref: 'সূরা ' + name + ' · আয়াত ' + App.bn(aIdx)
      });
    }
    function fromData(){
      try { var tr = App.tarjamaData.getSura(sIdx); return tr && tr.a ? tr.a[pos] : null; } catch(e){ return null; }
    }
    var td = App.tarjamaData;
    if (td && td.isLoaded()){ open(fromData()); return; }
    if (td && App.tarjamaDownload && App.tarjamaDownload.isReady && App.tarjamaDownload.isReady()){
      td.load().then(function(){ open(fromData()); }, function(){ open(null); });
      return;
    }
    open(null);
  }
  App.shareAyahCard = shareAyahCard;
  (function bindListen(){
    var b = document.getElementById('bm-listen-btn');
    if (!b) return;
    b.addEventListener('click', function(){
      if (!bmDraft || bmDraft.type !== 'sura' || !window.QuranAudio) return;
      var sura = App.quranModel[bmDraft.suraIndex - 1];
      var v = parseInt(App.toEnglishDigits(App.els.bmAyahInput.value).replace(/\D/g, ''), 10) || bmDraft.ayahIndex || 1;
      v = Math.min(Math.max(1, v), sura.ayahs.length);
      var s = bmDraft.suraIndex;
      closeBookmarkModal();
      window.QuranAudio.playFrom(s, v);
    });
  })();
  (function bindShare(){
    var b = document.getElementById('bm-share-btn');
    if (!b) return;
    b.addEventListener('click', function(){
      if (!bmDraft || bmDraft.type !== 'sura') return;
      var sura = App.quranModel[bmDraft.suraIndex - 1];
      var v = parseInt(App.toEnglishDigits(App.els.bmAyahInput.value).replace(/\D/g, ''), 10) || bmDraft.ayahIndex || 1;
      v = Math.min(Math.max(1, v), sura.ayahs.length);
      var s = bmDraft.suraIndex;
      closeBookmarkModal();
      shareAyahCard(s, v);
    });
  })();

  function saveBookmarkFromModal(){
    if (!bmDraft) return;
    var bm = {
      id: bmDraft.id || ('bm' + Date.now() + Math.random().toString(36).slice(2,7)),
      type: bmDraft.type,
      createdAt: bmDraft.id ? (bmDraft.createdAt || Date.now()) : Date.now(),
      label: App.els.bmNoteInput.value.trim()
    };
    if (bm.type === 'sura'){
      var sura = App.quranModel[bmDraft.suraIndex-1];
      var raw = App.toEnglishDigits(App.els.bmAyahInput.value).replace(/\D/g,'');
      var v = parseInt(raw, 10);
      if (!v || v < 1) v = 1;
      if (v > sura.ayahs.length) v = sura.ayahs.length;
      bm.suraIndex = bmDraft.suraIndex;
      bm.ayahIndex = v;
    } else {
      bm.pageNum = bmDraft.pageNum;
      bm.mode = bmDraft.mode || 'mushaf';
    }
    App.addOrUpdateBookmark(bm);
    closeBookmarkModal();
    App.showSnackbar('বুকমার্ক সংরক্ষণ করা হয়েছে');
    // The bookmark just saved (whether newly created or edited) becomes the active one
    // immediately, wherever it was saved from -- this is what turns the FAB into the
    // live green(synced)/grey(drifted) save-position indicator right away, everywhere,
    // not only on views that were originally opened FROM a saved bookmark.
    App.activeBookmarkId = bm.id;
    App.activeBookmarkPos = { type: bm.type, suraIndex: bm.suraIndex, ayahIndex: bm.ayahIndex, pageNum: bm.pageNum, mode: bm.mode };
    App.updateBmFabIcon();
  }
  App.saveBookmarkFromModal = saveBookmarkFromModal;

})(window.QuranApp = window.QuranApp || {});

