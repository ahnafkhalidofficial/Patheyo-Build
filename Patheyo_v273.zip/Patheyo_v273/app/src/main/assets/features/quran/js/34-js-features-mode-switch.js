
/*!
 * js/features/mode-switch.js -- ওপরের "তিলাওয়াত করুন | তরজমা পড়ুন" সুইচ
 *
 * Provides : App.setMode, App.bindModeSwitch
 * Needs    : core/dom, core/state, features/navigation, features/sura-reader, features/mushaf-viewer,
 *            features/web-reader, features/tarjama-reader, features/footnote-popup
 *
 *  তিলাওয়াত করুন -> আগের মতোই সূরা / পারা / বুকমার্ক (কিছুই বদলায়নি)
 *  তরজমা পড়ুন   -> সূরার তালিকা; সূরা খুললে আরবি + বাংলা তরজমা (+ উচ্চারণ), ব্যাখ্যা পপআপে
 */
(function (App) {
  "use strict";

  // একটি রিডার খোলা থাকলে সেটি ঠিকভাবে বন্ধ করে তালিকায় ফেরে (FAB ইত্যাদিসহ আগের close ফাংশনগুলোই ব্যবহার হয়)
  function leaveCurrentView(){
    var v = App.state.view;
    if (v === 'list') return;
    if (v === 'tr-fn'){ App.closeFootnote(true); v = 'tr-reader'; }
    if (v === 'sura-reader') App.closeReader();
    else if (v === 'para-pages') App.closeParaPages();
    else if (v === 'para-web') App.closeParaWebPage();
    else if (v === 'tr-reader') App.closeTarjamaReader();
    App.state.view = 'list';
    // রিডার খোলার সময় ব্রাউজার-হিস্ট্রিতে যে এন্ট্রি জমেছিল সেটি সরিয়ে দেওয়া, যাতে পরে ব্যাক বাটন একবারেই কাজ করে
    try { if (history.state && history.state.qview) history.back(); } catch(e){}
  }

  // ---- the actual switch (no animation) ----
  function applyMode(mode){
    leaveCurrentView();
    App.state.mode = mode;

    App.els.modeBtns.forEach(function(btn){
      var on = btn.getAttribute('data-mode') === mode;
      btn.classList.toggle('active', on);
      btn.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    App.els.tilawatTabs.classList.toggle('hidden', mode !== 'tilawat');
    App.els.tarjamaTabs.classList.toggle('hidden', mode !== 'tarjama');

    if (mode === 'tilawat'){
      App.els.trPanel.classList.add('hidden');
      App.els.trReaderPanel.classList.add('hidden');
      App.switchTab(App.state.tab);          // আগের অবস্থা (সূরা/পারা/বুকমার্ক) যেমন ছিল তেমনই ফিরে আসে
    } else {
      App.els.suraPanel.classList.add('hidden');
      App.els.paraPanel.classList.add('hidden');
      App.els.bookmarksPanel.classList.add('hidden');
      App.els.continueCard.classList.add('hidden');
      App.showTarjamaHome();
    }
    window.scrollTo(0, 0);
  }

  // ---- with a very short fade-out (90ms) -> switch -> fade-in (170ms), so the section never "jumps" ----
  var OUT_MS = 90, IN_MS = 170, fadeTimer = null, inTimer = null, pending = null;

  function setMode(mode){
    if (mode !== 'tilawat' && mode !== 'tarjama') return;
    var body = document.body;
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var sameMode = (mode === App.state.mode) && !pending;

    // same tab tapped again, or reduced-motion: just go there at once
    if (sameMode || reduce){
      clearTimeout(fadeTimer); clearTimeout(inTimer); pending = null;
      body.classList.remove('mode-out', 'mode-in');
      applyMode(mode);
      return;
    }
    // quick successive taps: only the latest target counts
    pending = mode;
    clearTimeout(fadeTimer); clearTimeout(inTimer);
    body.classList.remove('mode-in');
    body.classList.add('mode-out');
    fadeTimer = setTimeout(function(){
      var target = pending; pending = null;
      applyMode(target);
      body.classList.remove('mode-out');
      body.classList.add('mode-in');
      inTimer = setTimeout(function(){ body.classList.remove('mode-in'); }, IN_MS + 30);
    }, OUT_MS);
  }
  App.setMode = setMode;

  function bindModeSwitch(){
    App.els.modeBtns.forEach(function(btn){
      btn.addEventListener('click', function(){ setMode(btn.getAttribute('data-mode')); });
    });
  }
  App.bindModeSwitch = bindModeSwitch;

})(window.QuranApp = window.QuranApp || {});

