
/*!
 * js/features/navigation.js -- Tab switching, search filtering and history (back-button) handling
 *
 * Provides : App.filterActiveList, App.goBackOneLevel, App.pushHistory, App.switchTab
 * Needs    : core/dom, core/state, core/utils, features/bookmark-list, features/last-read,
               features/mushaf-fullscreen, features/mushaf-viewer, features/sura-reader, features/web-reader,
               features/tarjama-reader, features/footnote-popup
 */
(function (App) {
  "use strict";

  function switchTab(tab){
    App.state.tab = tab;
    App.els.tabs.forEach(function(btn){
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tab);
    });
    App.els.readerPanel.classList.add('hidden');
    App.els.paraPagesPanel.classList.add('hidden');
    App.els.suraPanel.classList.toggle('hidden', tab !== 'sura');
    App.els.paraPanel.classList.toggle('hidden', tab !== 'para');
    App.els.bookmarksPanel.classList.toggle('hidden', tab !== 'bookmarks');
    App.els.searchWrap.classList.toggle('hidden', tab === 'bookmarks');
    if (tab === 'bookmarks'){ App.renderBookmarksList(); }
    App.els.searchInput.value = '';
    App.els.searchInput.placeholder = (tab === 'para') ? 'পারা নম্বর লিখুন' : 'সূরা নম্বর বা নাম লিখুন';
    filterActiveList('');
    App.showContinueCard();
  }
  App.switchTab = switchTab;

  function filterActiveList(query){
    var inTr = (App.state.mode === 'tarjama');          // তরজমা পড়ুন-এ সার্চ তরজমার সূরা-তালিকায় কাজ করে
    if (!inTr && App.state.tab === 'bookmarks') return;
    var q = (query || '').trim();
    var qNorm = App.normalizeSearchText(q);
    var qDigits = q.replace(/[০-৯]/g, function(d){ return String(App.BN_DIGITS.indexOf(d)); }).replace(/\D/g,'');
    var listEl = inTr ? App.els.trList : ((App.state.tab === 'para') ? App.els.paraList : App.els.suraList);
    var emptyEl = inTr ? App.els.trEmpty : ((App.state.tab === 'para') ? App.els.paraEmpty : App.els.suraEmpty);
    var rows = listEl.querySelectorAll('.list-item');
    var visible = 0;
    rows.forEach(function(row){
      var name = App.normalizeSearchText(row.getAttribute('data-name'));
      var idx = row.getAttribute('data-index') || '';
      var match = !q || name.indexOf(qNorm) !== -1 || idx === qDigits;
      row.classList.toggle('hidden', !match);
      if (match) visible++;
    });
    emptyEl.classList.toggle('hidden', visible !== 0);
    App.els.searchClear.classList.toggle('show', !!q);
  }
  App.filterActiveList = filterActiveList;

  function pushHistory(view){
    App.state.view = view;
    try{ history.pushState({ qview:view }, ''); } catch(e){}
  }
  App.pushHistory = pushHistory;

  function goBackOneLevel(){
    if (history.state && history.state.qview){ history.back(); return; }
    if (App.state.view === 'para-fullscreen'){ App.state.view='para-pages'; App.closeFullscreenPage(); }
    else if (App.state.view === 'para-pages'){ App.state.view='list'; App.closeParaPages(); }
    else if (App.state.view === 'sura-reader'){ App.state.view='list'; App.closeReader(); }
    else if (App.state.view === 'para-web'){ App.state.view='list'; App.closeParaWebPage(); }
    else if (App.state.view === 'tr-fn'){ App.state.view='tr-reader'; App.closeFootnote(true); }
    else if (App.state.view === 'tr-reader'){ App.state.view='list'; App.closeTarjamaReader(); }
  }
  App.goBackOneLevel = goBackOneLevel;

})(window.QuranApp = window.QuranApp || {});

