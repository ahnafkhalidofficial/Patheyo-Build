
(function(){
  var done = false, files = ['pdfjs.js', 'pdfjs-worker-source.js', 'pdfjs-boot.js'];
  window.__loadPdfjs = function(){
    if (done) return; done = true;
    try { localStorage.setItem('pt_pdf_used', '1'); } catch (e) {}
    files.forEach(function(f){ var s = document.createElement('script'); s.async = false; s.src = 'https://appassets.patheyo.invalid/features/quran/vendor/' + f; document.head.appendChild(s); });   /* async=false: তিনটা ফাইল ঠিক এই ক্রমেই চলে */
  };
  /* ধাপ ১২: pdf.js (~১.৩ MB) সবার জন্য আগে থেকে নয় — মুসহাফ (PDF) খুললে তবেই (pdf-service-এর waitForPdfjs ডাকে)।
     আগে কখনো মুসহাফ খুলেছেন এমন ব্যবহারকারীর জন্য ফোন ফাঁকা হলে আগেভাগে লোড, যাতে তাঁর জন্য খুলতে দেরি না হয়। */
  window.addEventListener('load', function(){
    var used = false; try { used = !!localStorage.getItem('pt_pdf_used'); } catch (e) {}
    if (!used) return;
    var go = function(){ window.__loadPdfjs(); };
    setTimeout(function(){ if (window.requestIdleCallback) requestIdleCallback(go, { timeout: 6000 }); else go(); }, 2500);
  });
})();
