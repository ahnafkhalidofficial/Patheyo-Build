
/*!
 * js/features/tarjama-download-ui.js -- তরজমা ডাউনলোড কার্ড: লাইভ % রিং, MB, গতি, বাকি সময়, ত্রুটির বার্তা
 *
 * Provides : App.bindTarjamaDownloadUi, App.syncTarjamaPanel
 * Needs    : core/dom, services/tarjama-download, services/tarjama-data, features/feedback, features/tarjama-reader
 */
(function (App) {
  "use strict";

  var RING_C = 2 * Math.PI * 52;   // ring circumference (r = 52 in index.html)
  var showDone = false;            // "সম্পন্ন" অবস্থাটি শুধু ডাউনলোড শেষ হওয়ার ঠিক পরের মুহূর্তে দেখানো হয়
  var prevPhase = 'idle';

  // ---------------------------------------------------------------- formatting (মুসহাফ কার্ডের মতোই, সংখ্যা 0-9)
  function num(v){ return String(v); }
  function mb(bytes, d){ return num((bytes / 1048576).toFixed(d === undefined ? 1 : d)); }
  function fmtSize(bytes){ return bytes >= 1048576 ? mb(bytes) + ' MB' : num(Math.round(bytes / 1024)) + ' KB'; }
  function fmtSpeed(bps){
    if (!bps) return 'মাপা হচ্ছে…';
    return bps >= 1048576 ? mb(bps) + ' MB/s' : num(Math.max(1, Math.round(bps / 1024))) + ' KB/s';
  }
  function fmtEta(sec){
    if (sec === null || sec === undefined) return 'হিসাব হচ্ছে…';
    sec = Math.ceil(sec);
    if (sec <= 3) return 'কয়েক সেকেন্ড';
    if (sec < 60) return num(sec) + ' সেকেন্ড';
    var m = Math.floor(sec / 60), s = sec % 60;
    return num(m) + ' মিনিট' + (s ? ' ' + num(s) + ' সেকেন্ড' : '');
  }

  var ERRORS = {
    'blocked':     ['ডাউনলোড করা যায়নি', 'ইন্টারনেট ঠিক থাকলে আবার চেষ্টা করুন। না হলে নিচের লিংক থেকে ফাইলটি ব্রাউজারে নামিয়ে "নিজে বেছে নিন" দিয়ে দিন।'],
    'no-gzip':     ['এই ব্রাউজারে ফাইল খোলা যায়নি', 'ব্রাউজার আপডেট করুন, অথবা Chrome / Edge / Safari-র নতুন ভার্সনে খুলুন।'],
    'offline':     ['ইন্টারনেট সংযোগ নেই', 'ওয়াই-ফাই বা মোবাইল ডেটা চালু করে আবার চেষ্টা করুন।'],
    'timeout':     ['সংযোগ ধীর হয়ে গেছে', 'ইন্টারনেট ঠিক হলে আবার চেষ্টা করুন, যেখানে থেমেছিল সেখান থেকেই চলবে।'],
    'network':     ['ডাউনলোড বাধাপ্রাপ্ত হয়েছে', 'ইন্টারনেট বিচ্ছিন্ন হয়েছে। আবার চেষ্টা করলে যেখানে থেমেছিল সেখান থেকেই চলবে।'],
    'ssl':         ['নিরাপদ সংযোগ হয়নি', 'ফোনের তারিখ ও সময় ঠিক আছে কি না দেখে আবার চেষ্টা করুন।'],
    'no-space':    ['ফোনে জায়গা নেই', 'কিছু জায়গা খালি করে আবার চেষ্টা করুন।'],
    'corrupt':     ['ফাইলটি নষ্ট হয়ে গেছে', 'আবার ডাউনলোড করুন।'],
    'not-tarjama': ['ফাইলটি সঠিক তরজমা ফাইল নয়', 'লিংকটি সরাসরি Quran-Tarjama.json.gz ফাইলের কি না যাচাই করুন।'],
    'no-url':      ['ডাউনলোড লিংক সেট করা হয়নি', 'data/tarjama-config.js ফাইলে তরজমা ফাইলের লিংক বসান।'],
    'bad-url':     ['ডাউনলোড লিংক সঠিক নয়', 'লিংকটি https:// দিয়ে শুরু হতে হবে (data/tarjama-config.js)।']
  };

  function errorText(code){
    if (ERRORS[code]) return ERRORS[code];
    var m = /^http-(\d+)$/.exec(code || '');
    if (m){
      if (m[1] === '404') return ['ফাইলটি পাওয়া যায়নি', 'ডাউনলোড লিংকটি ঠিক নেই বা ফাইলটি সরানো হয়েছে। (কোড ' + num(404) + ')'];
      return ['সার্ভারে সমস্যা হয়েছে', 'কিছুক্ষণ পরে আবার চেষ্টা করুন। (কোড ' + num(m[1]) + ')'];
    }
    return ['ডাউনলোড সম্পন্ন হয়নি', 'আবার চেষ্টা করুন।'];
  }

  // ---------------------------------------------------------------- rendering
  function render(s){
    var el = App.els;
    if (!el.trdlCard) return;
    var dl = App.tarjamaDownload;
    var phase = s.phase;
    if (phase === 'done' && !showDone) phase = 'idle';

    var total = dl.getKnownTotal();
    var pct = (phase === 'done') ? 100 : (total > 0 ? Math.min(100, Math.floor(s.downloaded / total * 100)) : 0);
    el.trdlCard.setAttribute('data-state', phase);
    el.trdlCard.classList.toggle('trdl-indet', phase === 'downloading' && !(total > 0));
    el.trdlRing.setAttribute('aria-valuenow', String(pct));
    el.trdlRingBar.style.strokeDashoffset = String(RING_C * (1 - pct / 100));
    el.trdlPercent.textContent = num(pct) + '%';

    if (phase === 'idle'){
      el.trdlTitle.textContent = 'তরজমা ও ব্যাখ্যা ডাউনলোড করুন';
      el.trdlDesc.textContent = 'পুরো কুরআনের বাংলা তরজমা, উচ্চারণ ও ব্যাখ্যা একটি ফাইলে আছে' + (total > 0 ? ' (' + fmtSize(total) + ')' : '') + '।';
      el.trdlStartLabel.textContent = 'ডাউনলোড করুন';
    } else if (phase === 'downloading'){
      el.trdlTitle.textContent = 'ডাউনলোড হচ্ছে…';
      el.trdlDesc.textContent = 'অনুগ্রহ করে অপেক্ষা করুন। ডাউনলোড শেষ হলেই তরজমা নিজে থেকে খুলে যাবে।';
      el.trdlStatSize.textContent = total > 0 ? mb(s.downloaded) + ' / ' + mb(total) + ' MB' : fmtSize(s.downloaded);
      el.trdlStatSpeed.textContent = fmtSpeed(s.speed);
      el.trdlStatEta.textContent = (total > 0) ? fmtEta(s.eta) : '–';
    } else if (phase === 'done'){
      el.trdlTitle.textContent = 'ডাউনলোড সম্পন্ন!';
      el.trdlDesc.textContent = 'তরজমা খোলা হচ্ছে…';
    } else {
      var t = errorText(s.error);
      el.trdlTitle.textContent = t[0];
      el.trdlDesc.textContent = t[1];
      el.trdlStartLabel.textContent = 'আবার চেষ্টা করুন';
    }
  }

  function syncTarjamaPanel(){ render(App.tarjamaDownload.getState()); }
  App.syncTarjamaPanel = syncTarjamaPanel;

  // ---------------------------------------------------------------- ডাউনলোড শেষ হলে
  function onFinished(){
    showDone = true;
    syncTarjamaPanel();
    App.tarjamaData.load().then(function(){
      setTimeout(function(){
        showDone = false;
        var viewing = App.isTarjamaReaderOpen() && !App.els.trDlPanel.classList.contains('hidden');
        if (viewing) App.onTarjamaDownloaded();
        else if (App.showSnackbar) App.showSnackbar('তরজমা ডাউনলোড সম্পন্ন হয়েছে');
      }, 900);
    }).catch(function(){
      showDone = false;
      App.tarjamaDownload.discard();
      App.tarjamaDownload.setError('corrupt');
    });
  }

  // ---------------------------------------------------------------- wiring
  function bindTarjamaDownloadUi(){
    var dl = App.tarjamaDownload;
    if (!dl || !App.els.trdlCard) return;
    App.els.trdlStartBtn.addEventListener('click', function(){ dl.start(); });
    App.els.trdlCancelBtn.addEventListener('click', function(){ dl.cancel(); });
    dl.subscribe(function(s){
      if (prevPhase === 'downloading' && s.phase === 'done'){ prevPhase = s.phase; onFinished(); return; }
      prevPhase = s.phase;
      render(s);
    });
    prevPhase = dl.getState().phase;
    syncTarjamaPanel();
  }
  App.bindTarjamaDownloadUi = bindTarjamaDownloadUi;

})(window.QuranApp = window.QuranApp || {});

