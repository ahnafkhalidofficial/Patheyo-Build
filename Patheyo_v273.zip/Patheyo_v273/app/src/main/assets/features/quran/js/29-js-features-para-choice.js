
/*!
 * js/features/para-choice.js -- Para "read as" choice sheet (Mushaf pages or web page)
 *
 * Provides : App.closeParaChoice, App.openParaChoice, App.pendingParaIdx
 * Needs    : core/dom, core/utils
 */
(function (App) {
  "use strict";

  // ---- "আসল মুসহাফে পড়ুন" / "ওয়েব পেজে পড়ুন" choice sheet ----
  App.pendingParaIdx = null;

  function openParaChoice(idx){
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    App.pendingParaIdx = idx;
    App.els.choiceTitle.textContent = 'পারা ' + App.bn(idx) + ' — কীভাবে পড়তে চান?';
    App.els.paraChoiceOverlay.classList.remove('hidden');
  }
  App.openParaChoice = openParaChoice;

  function closeParaChoice(){
    App.els.paraChoiceOverlay.classList.add('hidden');
    App.pendingParaIdx = null;
  }
  App.closeParaChoice = closeParaChoice;

})(window.QuranApp = window.QuranApp || {});

