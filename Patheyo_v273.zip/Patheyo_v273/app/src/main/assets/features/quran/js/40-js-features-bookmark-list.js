
/*!
 * js/features/bookmark-list.js -- Bookmarks tab list, jump-to-bookmark navigation, delete confirmation
 *
 * Provides : App.renderBookmarksList, App.scrollToAyah, App.scrollToWebPage
 * Needs    : core/dom, core/quran-meta, core/utils, data/para-meta, data/surah-meta, features/bookmark-fab,
               features/bookmark-modal, features/feedback, features/mushaf-fullscreen, features/mushaf-viewer,
               features/sura-reader, features/web-reader, services/bookmark-store
 */
(function (App) {
  "use strict";

  function scrollToAyah(suraIdx, ayahIdx){
    if (App.completeRender) App.completeRender();          // long suras are rendered in slices: make sure the target ayah exists
    function go(){
      var el = document.getElementById('ayah-' + suraIdx + '-' + ayahIdx);
      if (!el) return;
      try{ el.scrollIntoView({behavior:'smooth', block:'center'}); }catch(e){ el.scrollIntoView(); }
      el.classList.add('ayah-highlight');
      setTimeout(function(){ el.classList.remove('ayah-highlight'); }, 1600);
    }
    // If the Quran font is still loading, the text re-flows when it arrives: wait for it, otherwise the jump lands in the wrong place.
    if (document.fonts && document.fonts.status === 'loading') document.fonts.ready.then(go, go); else go();
  }
  App.scrollToAyah = scrollToAyah;

  function goToBookmark(bm){
    App.els.bookmarksPanel.classList.add('hidden');
    if (bm.type === 'sura'){
      App.openReader(bm.suraIndex); // resets activeBookmarkId/Pos internally; re-set below since this IS a bookmark open
      App.activeBookmarkId = bm.id; App.activeBookmarkPos = { type: bm.type, suraIndex: bm.suraIndex, ayahIndex: bm.ayahIndex };
      setTimeout(function(){ scrollToAyah(bm.suraIndex, bm.ayahIndex); App.updateBmFabIcon(); }, 80);
    } else if (bm.mode === 'web'){
      var paraIdxW = App.paraForPage(bm.pageNum);
      App.openParaWebPage(paraIdxW);
      App.activeBookmarkId = bm.id; App.activeBookmarkPos = { type: bm.type, pageNum: bm.pageNum, mode: bm.mode };
      setTimeout(function(){ scrollToWebPage(bm.pageNum); App.updateBmFabIcon(); }, 80);
    } else {
      var paraIdx = App.paraForPage(bm.pageNum);
      App.openParaPages(paraIdx);
      App.showPreviewPage(bm.pageNum);
      App.openFullscreenPage(bm.pageNum);
      App.activeBookmarkId = bm.id; App.activeBookmarkPos = { type: bm.type, pageNum: bm.pageNum, mode: bm.mode };
    }
    App.updateBmFabIcon();
  }

  function scrollToWebPage(pageNum){
    var el = App.els.webVerses.querySelector('.qp-page[data-page="' + pageNum + '"]');
    if (!el) return;
    try{ el.scrollIntoView({behavior:'smooth', block:'start'}); }catch(e){ el.scrollIntoView(); }
    el.classList.add('qp-page-highlight');
    setTimeout(function(){ el.classList.remove('qp-page-highlight'); }, 1600);
  }
  App.scrollToWebPage = scrollToWebPage;

  function renderBookmarksList(){
    var arr = App.loadBookmarks().slice().sort(function(a,b){ return b.createdAt - a.createdAt; });
    App.els.bookmarksList.innerHTML = '';
    App.els.bookmarksEmpty.classList.toggle('hidden', arr.length !== 0);
    var frag = document.createDocumentFragment();
    arr.forEach(function(bm){
      var row = document.createElement('div');
      row.className = 'list-item bm-item';
      row.innerHTML =
        '<div class="li-badge"><svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21 12 16 5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg></div>' +
        '<div class="li-name-block">' +
          '<div class="li-name-en">' + App.bookmarkTitle(bm) + '</div>' +
          (bm.label ? '<div class="li-sub">' + App.escapeHtml(bm.label) + '</div>' : '') +
        '</div>' +
        '<button class="bm-edit-btn" aria-label="সম্পাদনা"><svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg></button>' +
        '<button class="bm-del-btn" aria-label="মুছুন"><svg class="icon icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path></svg></button>';
      row.querySelector('.bm-edit-btn').addEventListener('click', function(e){
        e.stopPropagation();
        App.openBookmarkModal(bm, bm.id);
      });
      row.querySelector('.bm-del-btn').addEventListener('click', function(e){
        e.stopPropagation();
        openDeleteConfirm(bm);
      });
      row.addEventListener('click', function(){ goToBookmark(bm); });
      frag.appendChild(row);
    });
    App.els.bookmarksList.appendChild(frag);
  }
  App.renderBookmarksList = renderBookmarksList;

  var pendingDeleteBm = null;

  function openDeleteConfirm(bm){
    pendingDeleteBm = bm;
    var what;
    if (bm.type === 'sura'){
      what = 'সূরা ' + (App.SURAH_BN[bm.suraIndex-1] || App.bn(bm.suraIndex)) + ', আয়াত-' + App.bn(bm.ayahIndex);
    } else {
      var pIdx = App.paraForPage(bm.pageNum);
      var pInPara = bm.pageNum - App.PARA_PAGE_RANGE[pIdx-1][0] + 1;
      what = 'পারা-' + App.bn(pIdx) + ', পৃষ্ঠা-' + App.bn(pInPara) + ' (' + (bm.mode === 'web' ? 'ওয়েব পেজ' : 'আসল মুসহাফ') + ')';
    }
    App.els.bmDeleteContext.innerHTML = '<strong style="color:var(--text)">' + what + '</strong><br>এই বুকমার্কটি কি আপনি মুছে ফেলতে চান?';
    App.els.bmDeleteOverlay.classList.remove('hidden');
  }

  function closeDeleteConfirm(){
    App.els.bmDeleteOverlay.classList.add('hidden');
    pendingDeleteBm = null;
  }

  App.els.bmDeleteCancelBtn.addEventListener('click', closeDeleteConfirm);

  App.els.bmDeleteOverlay.addEventListener('click', function(e){
    if (e.target === App.els.bmDeleteOverlay) closeDeleteConfirm();
  });

  App.els.bmDeleteConfirmBtn.addEventListener('click', function(){
    if (!pendingDeleteBm) return;
    var bm = pendingDeleteBm;
    var removed = App.deleteBookmark(bm.id);
    if (App.activeBookmarkId === bm.id){ App.activeBookmarkId = null; App.activeBookmarkPos = null; App.updateBmFabIcon(); }
    closeDeleteConfirm();
    App.showSnackbarUndo('বুকমার্ক মুছে ফেলা হয়েছে', function(){ if (removed) App.addOrUpdateBookmark(removed); });
  });

})(window.QuranApp = window.QuranApp || {});

