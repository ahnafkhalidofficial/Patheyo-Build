
/*!
 * js/features/header-autohide.js -- নিচে স্ক্রল করলে হেডার (লোগো, নাম, থিম বাটন) লুকায়;
 * ওপরের দিকে একটু জোরে স্ক্রল করলে (যেখানেই থাকুক) আবার নেমে আসে। কোনো নির্ধারিত জায়গা ধরা নেই -- শুধু স্ক্রলের দিক ও গতি দেখে।
 *
 * Needs : CSS  .app-header.hdr-hidden  (css/header.css)
 */
(function (App) {
  "use strict";

  var header = document.querySelector('.app-header');
  if (!header) return;

  var HIDE_AFTER  = 14;    // এই পরিমাণ (px) নিচে নামলে লুকাবে
  var SHOW_AFTER  = 28;    // এই পরিমাণ (px) ওপরে উঠলে ফিরে আসবে (আস্তে নাড়লে আসবে না)
  var FAST_PX     = 1.1;   // বা এত px/ms গতিতে উঠলে সঙ্গে সঙ্গে ফিরবে
  var USER_WINDOW = 1600;  // ms: আঙুল/হুইল/কিবোর্ডের স্ক্রলের পর এত সময় পর্যন্ত স্ক্রলকে "ব্যবহারকারীর স্ক্রল" ধরা হয় (ফ্লিংসহ)
  var SETTLE      = 450;   // ms: পর্দার মাপ বদলালে (ফুটার লুকানো/ফেরা) এই সময় স্ক্রল-ইভেন্ট উপেক্ষা -- নইলে নিজে নিজেই লুকাত/ফিরত
  var lastY = window.pageYOffset, lastT = Date.now(), acc = 0, hidden = false, ticking = false;
  var userT = 0, moved = false, settleUntil = 0;

  function setHidden(v) {
    if (v === hidden) return;
    hidden = v;
    header.classList.toggle('hdr-hidden', v);
  }

  function searchFocused() {
    var a = document.activeElement;
    return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA');
  }


  // সত্যিকারের পড়ার ভিউ কি না: সূরা (তিলাওয়াত), পারার ওয়েব পেজ, এবং তরজমার আয়াত (ডাউনলোড কার্ড নয়)।
  // পারার মুসহাফ প্রিভিউ ও ডাউনলোড কার্ড এর বাইরে -- ফুল স্ক্রিন হলে হেডার-ফুটার শেল নিজেই সরায়।
  function isReadingView() {
    function open(id) { var el = document.getElementById(id); return !!el && !el.classList.contains('hidden'); }
    if (open('reader-panel') || open('web-page-panel')) return true;
    var tr = document.getElementById('tr-reader-panel');
    return !!tr && !tr.classList.contains('hidden') && !tr.classList.contains('tr-dl-mode');
  }

  // এই ভিউগুলোতে হেডার কখনোই লুকাবে না: সূরার তালিকা, পারা/বুকমার্ক তালিকা, তরজমার ডাউনলোড কার্ড, মুসহাফের ডাউনলোড কার্ড ও প্রিভিউ
  // (দেখা গেলে/ভিউ বদলালে হেডার সঙ্গে সঙ্গে ফিরিয়ে আনা হয়)
  function syncView() { if (!isReadingView()) { acc = 0; setHidden(false); } }

  function onScroll() {
    var y = Math.max(0, window.pageYOffset), now = Date.now();
    var dy = y - lastY, dt = Math.max(1, now - lastT);
    lastY = y; lastT = now;

    header.classList.toggle('hdr-lifted', y > 4);
    if (y <= 4) { acc = 0; setHidden(false); return; }       // একেবারে ওপরে: সবসময় দেখা যাবে
    if (searchFocused()) { setHidden(false); return; }        // লেখার সময় হেডার থাকবে
    if (!isReadingView()) { acc = 0; setHidden(false); return; } // তালিকা / ডাউনলোড / অধ্যায়-তালিকা / মুসহাফ প্রিভিউ: যতই স্ক্রল করুক হেডার থাকবে
    if (now < settleUntil) { acc = 0; return; }               // মাপ বদলানোর ঝাঁকুনি: হিসাবে ধরা হবে না
    if (now - userT > USER_WINDOW) { acc = 0; return; }       // কোড থেকে স্ক্রল (সূরা/কিতাব খোলা, বুকমার্ক/শেষ পড়ায় ফেরা): শুরুতেই লুকাবে না

    if (dy > 0) {                                             // নিচে
      acc = acc > 0 ? acc + dy : dy;
      if (acc >= HIDE_AFTER && y > header.offsetHeight) setHidden(true);
    } else if (dy < 0) {                                      // ওপরে
      acc = acc < 0 ? acc + dy : dy;
      if (-acc >= SHOW_AFTER || (-dy / dt) >= FAST_PX) setHidden(false);
    }
  }

  window.addEventListener('scroll', function () {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () { ticking = false; onScroll(); });
  }, { passive: true });

  // ব্যবহারকারী নিজে স্ক্রল করছে কি না: শুধু ট্যাপে (touchmove ছাড়া) হবে না
  function markUser() { userT = Date.now(); }
  window.addEventListener('touchstart', function () { moved = false; }, { passive: true, capture: true });
  window.addEventListener('touchmove',  function () { moved = true; markUser(); }, { passive: true, capture: true });
  window.addEventListener('touchend',   function () { if (moved) markUser(); }, { passive: true, capture: true });
  window.addEventListener('wheel',      markUser, { passive: true, capture: true });
  window.addEventListener('keydown', function (e) {
    if (/^(PageUp|PageDown|ArrowUp|ArrowDown|Home|End| )$/.test(e.key)) markUser();
  }, true);

  // ফুটার লুকালে/ফিরলে ফ্রেমের উচ্চতা বদলায়: তখনকার স্ক্রল-সংশোধনকে ব্যবহারকারীর স্ক্রল ভেবে ভুল করা চলবে না
  window.addEventListener('resize', function () {
    settleUntil = Date.now() + SETTLE;
    lastY = window.pageYOffset; acc = 0;
  });

  // পাতা বদলালে (সূরা/পারা/তরজমা খোলা, ট্যাব) হেডার ফিরিয়ে আনা
  window.addEventListener('popstate', function () { setHidden(false); });
  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('.tab, .mode-tab, .tr-mode-btn, .list-item, .back-btn')) setHidden(false);
  }, true);

  // পড়ার ভিউ থেকে বেরোলে (বা ডাউনলোড কার্ড এলে) স্ক্রলের অপেক্ষা না করে হেডার ফেরত
  if (window.MutationObserver) {
    var mo = new MutationObserver(syncView);
    ['reader-panel', 'web-page-panel', 'tr-reader-panel', 'para-pages-panel'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) mo.observe(el, { attributes: true, attributeFilter: ['class'] });
    });
  }

  App.showHeader = function () { setHidden(false); };

})(window.QuranApp = window.QuranApp || {});
