/* ধাপ ৫ — Android ব্যাক: আগে এই পেজের পপআপ (বুকমার্ক, মুছে ফেলা, কিতাব মুছে ফেলা) বন্ধ; হোম (06-native-bridge.js) জিজ্ঞেস করে */
(function () {
  'use strict';
  function $(id) { return document.getElementById(id); }
  function vis(id) { var el = $(id); return el && !el.classList.contains('hidden'); }
  window.__ptFrameBack = function () {
    try { if (window.PT && PT.handleBack && PT.handleBack()) return true; } catch (e) {}
    if (vis('book-remove-overlay')) { $('book-remove-cancel-btn').click(); return true; }
    if (vis('bm-delete-overlay')) { $('bm-delete-cancel-btn').click(); return true; }
    if (vis('bm-modal-overlay')) { $('bm-cancel-btn').click(); return true; }
    return false;
  };
})();
