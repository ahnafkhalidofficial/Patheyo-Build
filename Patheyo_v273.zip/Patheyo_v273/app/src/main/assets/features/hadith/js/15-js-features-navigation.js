
/* ===== js/features/navigation.js ===== */
/*!
 * js/features/navigation.js -- Tab switching, search filtering and history (back-button) handling
 *
 * Provides : App.switchTab, App.filterBooks, App.pushHistory, App.goBackOneLevel, App.onPopState, App.resetToList,
 *            App.updateSearchUi
 * Needs    : core/dom, core/state, core/utils, features/bookmark-list, features/last-read, features/lists,
 *            features/book-view, features/chapter-reader, features/search
 */
(function (App) {
  "use strict";

  // The search box sits in the (always visible) header. What it searches depends on the screen:
  //  books tab -> filters the 6 books | opened book -> hadith number / words | otherwise hidden.
  function updateSearchUi(){
    var el = App.els, v = App.state.view, show = false, ph = '';
    if (v === 'list' && App.state.tab === 'books'){ show = true; ph = 'কিতাবের নাম লিখুন'; }
    else if (v === 'book' && App.bookBodyVisible()){ show = true; ph = 'হাদিস নম্বর বা শব্দ লিখুন'; }
    el.searchWrap.classList.toggle('hidden', !show);
    if (ph) el.searchInput.placeholder = ph;
  }
  App.updateSearchUi = updateSearchUi;

  function clearSearch(){
    App.els.searchInput.value = '';
    App.els.searchClear.classList.remove('show');
  }

  function switchTab(tab){
    App.state.tab = tab;
    App.state.view = 'list';
    App.els.tabs.forEach(function(btn){
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tab);
    });
    App.els.bookPanel.classList.add('hidden');
    App.els.chapterPanel.classList.add('hidden');
    App.els.booksPanel.classList.toggle('hidden', tab !== 'books');
    App.els.bookmarksPanel.classList.toggle('hidden', tab !== 'bookmarks');
    if (tab === 'bookmarks'){ App.renderBookmarksList(); }
    if (tab === 'books'){ App.renderBookList(); }
    clearSearch();
    filterBooks('');
    updateSearchUi();
    App.showContinueCard();
  }
  App.switchTab = switchTab;

  // list view: filter books by name
  function filterBooks(query){
    var q = (query || '').trim();
    var qNorm = App.normalizeSearchText(q);
    var rows = App.els.booksList.querySelectorAll('.list-item');
    var visible = 0;
    rows.forEach(function(row){
      var name = App.normalizeSearchText(row.getAttribute('data-name'));
      var match = !q || name.indexOf(qNorm) !== -1;
      row.classList.toggle('hidden', !match);
      if (match) visible++;
    });
    App.els.booksEmpty.classList.toggle('hidden', visible !== 0);
    App.els.searchClear.classList.toggle('show', !!q);
  }
  App.filterBooks = filterBooks;

  // ---- history: every deeper screen pushes one entry, so the phone's back button goes one level up ----
  function pushHistory(view){
    App.state.view = view;
    App.state.depth++;
    try{ history.pushState({ qview:view }, ''); } catch(e){}
    updateSearchUi();
  }
  App.pushHistory = pushHistory;

  var suppressPops = 0;

  function onPopState(){
    if (suppressPops > 0){ suppressPops--; return; }
    if (App.state.depth > 0) App.state.depth--;
    if (App.state.view === 'chapter'){ App.closeChapter(); }
    else if (App.state.view === 'book'){ App.closeBook(); }
  }
  App.onPopState = onPopState;

  function goBackOneLevel(){
    if (history.state && history.state.qview){ history.back(); return; }
    if (App.state.view === 'chapter'){ App.closeChapter(); }
    else if (App.state.view === 'book'){ App.closeBook(); }
  }
  App.goBackOneLevel = goBackOneLevel;

  // A tab was tapped while a book / chapter was open: jump straight to the list and drop the
  // extra history entries so the phone's back button doesn't have to walk through them.
  function resetToList(tab){
    var d = App.state.depth;
    App.state.depth = 0;
    if (d > 0){ suppressPops++; try{ history.go(-d); } catch(e){ suppressPops = 0; } }
    App.stopChapterReader();
    switchTab(tab);
  }
  App.resetToList = resetToList;

})(window.HadithApp = window.HadithApp || {});

