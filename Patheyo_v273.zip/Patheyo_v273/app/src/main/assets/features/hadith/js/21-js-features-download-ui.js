
/* ===== js/features/download-ui.js ===== */
/*!
 * js/features/download-ui.js -- কিতাব ডাউনলোড কার্ড: আইকন, লাইভ % রিং, MB, গতি, বাকি সময়, ত্রুটির বার্তা
 *                               (কুরআন অ্যাপের মুসহাফ ডাউনলোড কার্ডের হুবহু একই আচরণ)
 *
 * Provides : App.bindDownloadUi, App.syncDownloadCard
 * Needs    : core/dom, core/books, core/utils, features/feedback, features/book-view, services/book-download
 */
(function (App) {
  "use strict";

  var RING_C = 2 * Math.PI * 52;   // ring circumference (r = 52 in index.html)
  var showDone = false;            // "সম্পন্ন" অবস্থাটি শুধু ডাউনলোড শেষ হওয়ার ঠিক পরের কয়েক মুহূর্ত দেখানো হয়
  var prevPhase = {};              // id -> আগের phase

  // ---------------------------------------------------------------- formatting (সংখ্যা সবসময় ইংরেজি digit-এ: 0-9)
  function num(v){ return String(v); }

  function mb(bytes, digits){ return num((bytes / 1048576).toFixed(digits === undefined ? 1 : digits)); }

  function fmtSize(bytes){
    if (bytes >= 1048576) return mb(bytes) + ' MB';
    return num(Math.round(bytes / 1024)) + ' KB';
  }

  function fmtSpeed(bps){
    if (!bps) return 'মাপা হচ্ছে…';
    if (bps >= 1048576) return mb(bps) + ' MB/s';
    return num(Math.max(1, Math.round(bps / 1024))) + ' KB/s';
  }

  function fmtEta(sec){
    if (sec === null || sec === undefined) return 'হিসাব হচ্ছে…';
    sec = Math.ceil(sec);
    if (sec <= 3) return 'কয়েক সেকেন্ড';
    if (sec < 60) return num(sec) + ' সেকেন্ড';
    var m = Math.floor(sec / 60), s = sec % 60;
    if (m >= 60) return num(Math.floor(m / 60)) + ' ঘণ্টা ' + num(m % 60) + ' মিনিট';
    return num(m) + ' মিনিট' + (s ? ' ' + num(s) + ' সেকেন্ড' : '');
  }

  var ERRORS = {
    'offline':   ['ইন্টারনেট সংযোগ নেই', 'ওয়াই-ফাই বা মোবাইল ডেটা চালু করে আবার চেষ্টা করুন।'],
    'timeout':   ['সংযোগ ধীর হয়ে গেছে', 'ইন্টারনেট ঠিক হলে আবার চেষ্টা করুন, যেখানে থেমেছিল সেখান থেকেই চলবে।'],
    'network':   ['ডাউনলোড বাধাপ্রাপ্ত হয়েছে', 'ইন্টারনেট বিচ্ছিন্ন হয়েছে। আবার চেষ্টা করলে যেখানে থেমেছিল সেখান থেকেই চলবে।'],
    'ssl':       ['নিরাপদ সংযোগ হয়নি', 'ফোনের তারিখ ও সময় ঠিক আছে কি না দেখে আবার চেষ্টা করুন।'],
    'no-space':  ['ফোনে জায়গা নেই', 'কিছু জায়গা খালি করে আবার চেষ্টা করুন।'],
    'not-book':  ['ফাইলটি সঠিক কিতাব-ফাইল নয়', 'ডাউনলোড লিংকটি সরাসরি কিতাবের .json.gz ফাইলের কি না যাচাই করুন।'],
    'corrupt':   ['ফাইলটি নষ্ট হয়ে গেছে', 'ফাইলটি মুছে ফেলা হয়েছে। আবার ডাউনলোড করুন।'],
    'no-url':    ['ডাউনলোড লিংক সেট করা হয়নি', 'data/books-config.js ফাইলে ডাউনলোড-লিংক বসান।'],
    'bad-url':   ['ডাউনলোড লিংক সঠিক নয়', 'লিংকটি https:// দিয়ে শুরু হতে হবে (data/books-config.js)।']
  };

  function errorText(code){
    if (ERRORS[code]) return ERRORS[code];
    var m = /^http-(\d+)$/.exec(code || '');
    if (m){
      if (m[1] === '404') return ['ফাইলটি পাওয়া যায়নি', 'ডাউনলোড লিংকটি ঠিক নেই বা ফাইলটি সরানো হয়েছে। (কোড ' + num(404) + ')'];
      return ['সার্ভারে সমস্যা হয়েছে', 'কিছুক্ষণ পরে আবার চেষ্টা করুন। (কোড ' + num(m[1]) + ')'];
    }
    return ['ডাউনলোড সম্পন্ন হয়নি', 'আবার চেষ্টা করুন।'];
  }

  // ---------------------------------------------------------------- rendering
  function render(id, s){
    var el = App.els;
    if (!el.dlCard || id !== App.curBookId) return;
    var dl = App.bookDl, b = App.bookById(id);
    var phase = s.phase;
    if (phase === 'done' && !showDone) phase = 'idle'; // আগে থেকেই ডাউনলোড করা আছে, অথচ এখানে এসেছি -> সাধারণ অবস্থা

    var total = dl.getKnownTotal(id);
    var pct = (phase === 'done') ? 100 : (total > 0 ? Math.min(100, Math.floor(s.downloaded / total * 100)) : 0);
    el.dlCard.setAttribute('data-state', phase);
    el.dlCard.classList.toggle('dl-indet', phase === 'downloading' && !(total > 0));
    el.dlRing.setAttribute('aria-valuenow', String(pct));
    el.dlRingBar.style.strokeDashoffset = String(RING_C * (1 - pct / 100));
    el.dlPercent.textContent = num(pct) + '%';

    if (phase === 'idle'){
      el.dlTitle.textContent = b.nameBn + ' ডাউনলোড করুন';
      el.dlDesc.textContent = 'পুরো কিতাবের আরবি ও বাংলা অনুবাদ একটি ফাইলে আছে' + (total > 0 ? ' (' + fmtSize(total) + ')' : '') + '।';
      el.dlStartLabel.textContent = 'ডাউনলোড করুন';
    } else if (phase === 'downloading'){
      el.dlTitle.textContent = 'ডাউনলোড হচ্ছে…';
      el.dlDesc.textContent = 'অনুগ্রহ করে অপেক্ষা করুন। ডাউনলোড শেষ হলেই কিতাব নিজে থেকে খুলে যাবে।';
      el.dlStatSize.textContent = total > 0
        ? mb(s.downloaded) + ' / ' + mb(total) + ' MB'
        : fmtSize(s.downloaded);
      el.dlStatSpeed.textContent = fmtSpeed(s.speed);
      el.dlStatEta.textContent = (total > 0) ? fmtEta(s.eta) : '–';
    } else if (phase === 'done'){
      el.dlTitle.textContent = 'ডাউনলোড সম্পন্ন!';
      el.dlDesc.textContent = 'কিতাব খোলা হচ্ছে…';
    } else { // error
      var t = errorText(s.error);
      el.dlTitle.textContent = t[0];
      el.dlDesc.textContent = t[1];
      el.dlStartLabel.textContent = 'আবার চেষ্টা করুন';
    }
  }

  function syncDownloadCard(){
    if (App.curBookId) render(App.curBookId, App.bookDl.getState(App.curBookId));
  }
  App.syncDownloadCard = syncDownloadCard;

  // ---------------------------------------------------------------- when a download finishes
  function onFinished(id){
    var viewing = (App.curBookId === id) && App.state.view === 'book' && !App.els.bookGate.classList.contains('hidden');
    var b = App.bookById(id);
    if (!viewing){
      if (App.showSnackbar) App.showSnackbar(b.nameBn + ' ডাউনলোড সম্পন্ন হয়েছে');
      if (App.state.view === 'list' && App.state.tab === 'books') App.renderBookList();
      return;
    }
    showDone = true;
    syncDownloadCard();
    App.loadBook(id).then(function(){
      setTimeout(function(){
        showDone = false;
        if (App.curBookId === id && App.state.view === 'book'){ App.enterBook(id); }
        else if (App.showSnackbar){ App.showSnackbar(b.nameBn + ' ডাউনলোড সম্পন্ন হয়েছে'); }
      }, 900);
    }).catch(function(){
      showDone = false;
      App.bookDl.discard(id);
      App.bookDl.fail(id, 'corrupt');
      syncDownloadCard();
      if (App.showSnackbar) App.showSnackbar('ফাইলটি খোলা যায়নি, আবার ডাউনলোড করুন');
    });
  }

  // ---------------------------------------------------------------- wiring
  function bindDownloadUi(){
    var dl = App.bookDl;
    if (!dl || !App.els.dlCard) return;


    App.els.dlStartBtn.addEventListener('click', function(){ if (App.curBookId) dl.start(App.curBookId); });
    App.els.dlCancelBtn.addEventListener('click', function(){ if (App.curBookId) dl.cancel(App.curBookId); });

    dl.subscribe(function(id, s){
      var was = prevPhase[id] || 'idle';
      prevPhase[id] = s.phase;
      if (was === 'downloading' && s.phase === 'done'){ onFinished(id); return; }
      render(id, s);
    });
    App.BOOKS.forEach(function(b){ prevPhase[b.id] = dl.getState(b.id).phase; });
    syncDownloadCard();
  }
  App.bindDownloadUi = bindDownloadUi;

})(window.HadithApp = window.HadithApp || {});

