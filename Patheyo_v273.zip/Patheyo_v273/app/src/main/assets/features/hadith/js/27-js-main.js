
/* ===== js/main.js ===== */
/*!
 * js/main.js -- Application entry point: builds the book list and starts the app
 *
 * Provides : (nothing -- entry point)
 * Needs    : core/dom, core/state, features/events, features/last-read, features/lists, features/theme
 */
(function (App) {
  "use strict";

  var savedTheme = 'light';
  try{ savedTheme = localStorage.getItem('hadith-theme') || 'light'; } catch(e){}
  App.setTheme(savedTheme);

  try{
    if (!App.BOOKS.length) throw new Error('data/books-config.js-এ কিতাবের তালিকা নেই');
    App.renderBookList();
    App.showContinueCard();
    App.bindEvents();
    App.updateSearchUi();
  } catch(err){
    App.els.errorBox.classList.remove('hidden');
    App.els.errorBox.textContent = 'দুঃখিত, অ্যাপ চালু করা যায়নি। (' + err.message + ')';
  }

})(window.HadithApp = window.HadithApp || {});

