
/* ===== js/services/book-download.js ===== */
/*!
 * js/services/book-download.js -- কিতাব ডাউনলোড (লাইভ প্রগ্রেস, গতি, বাকি সময়) ও লোকাল স্টোরেজ
 *
 * Provides : App.bookDl  { hasNative, isReady, needsDownload, getState, getKnownTotal, subscribe, start, cancel,
 *                          readText, discard, remove, fail, syncFromNative, _onNative }
 * Needs    : core/books
 *
 * তিনটি ব্যাকএন্ড:
 *  1) Android অ্যাপ (window.HadithNative আছে): Kotlin ডাউনলোড করে অ্যাপের স্টোরেজে সেভ করে; এখানে শুধু প্রগ্রেস আসে।
 *  2) SINGLE-FILE HTML (এই ফাইল): ৬টি কিতাবের .json.gz ফাইল HTML-এর ভেতরেই বসানো (id="hb-data-<book>").
 *     "ডাউনলোড করুন" চাপলে সেটি লাইভ প্রগ্রেস সহ খুলে (decode + gunzip + যাচাই) ব্রাউজারে "ডাউনলোড করা" হিসেবে
 *     চিহ্নিত হয় (localStorage) -- ইন্টারনেট ছাড়াই ১০০% কাজ করে।
 *  3) ভেতরে ডেটা না থাকলে (বা কোনো কিতাবের জন্য): data/books-config.js এর লিংক থেকে XHR দিয়ে নামিয়ে
 *     IndexedDB-তে রাখে। (লিংকের সার্ভারে CORS চালু থাকতে হবে।)
 * প্রতিটি কিতাবের নিজস্ব অবস্থা (state) আছে -- একটার ডাউনলোড চলাকালে অন্যটা আলাদাভাবে চলতে পারে।
 */
(function (App) {
  "use strict";

  var native = (window.HadithNative && typeof window.HadithNative.isBookReady === 'function') ? window.HadithNative : null;
  var VER = App.DATA_VERSION;
  var LOCAL_HOST = 'https://hadith-local.invalid/';

  var states = {};       // id -> { phase, downloaded, total, speed, eta, error, sample }
  var listeners = [];
  var xhrs = {};         // চলমান XHR (নেটওয়ার্ক ব্যাকএন্ড)
  var cancelFlags = {};  // চলমান embedded-ডাউনলোড বাতিলের পতাকা
  var webText = {};      // নেটওয়ার্ক থেকে নামানো কিতাবের টেক্সট (মেমরি)
  var idbReady = {};     // IndexedDB-তে সংরক্ষিত কিতাব
  var stash = null;      // { id, text } -- এইমাত্র যাচাই-করা কিতাবের টেক্সট, পরের readText() একবার নেবে

  // ---------------------------------------------------------------- স্থায়ী "ডাউনলোড করা" পতাকা
  var FLAG_KEY = 'hadith-dl-flags-v' + VER;
  var flags = (function(){
    try { var o = JSON.parse(localStorage.getItem(FLAG_KEY) || '{}'); return (o && typeof o === 'object') ? o : {}; }
    catch(e){ return {}; }
  })();
  function saveFlags(){ try { localStorage.setItem(FLAG_KEY, JSON.stringify(flags)); } catch(e){} }

  function st(id){
    return states[id] || (states[id] = { phase:'idle', downloaded:0, total:0, speed:0, eta:null, error:null, sample:null });
  }

  function emit(id){ var s = st(id); listeners.slice().forEach(function(fn){ try{ fn(id, s); }catch(e){} }); }

  function subscribe(fn){
    listeners.push(fn);
    return function(){ listeners = listeners.filter(function(f){ return f !== fn; }); };
  }

  function knownTotal(id){
    var s = st(id);
    if (s.total > 0) return s.total;
    var b = App.bookById(id);
    return (b && b.sizeBytes) || 0;
  }

  // ---- গতি (EMA) ও বাকি সময় ----
  function track(id, bytes){
    var s = st(id), now = Date.now();
    if (!s.sample){ s.sample = { t:now, b:bytes }; return; }
    var dt = now - s.sample.t;
    if (dt < 250) return; // ছোট ছোট ওঠানামা এড়াতে একটু পরপর মাপা
    var inst = Math.max(0, (bytes - s.sample.b) / dt * 1000);
    s.speed = s.speed ? s.speed * 0.6 + inst * 0.4 : inst;
    s.sample = { t:now, b:bytes };
    var t = knownTotal(id);
    s.eta = (t > 0 && s.speed > 1024) ? Math.max(0, (t - bytes) / s.speed) : null;
  }

  function reset(id, phase){
    var s = st(id);
    s.phase = phase; s.speed = 0; s.eta = null; s.sample = null;
  }

  // ---------------------------------------------------------------- Android (native)
  function onNative(ev){
    if (!ev || !ev.id) return;
    var id = ev.id, s = st(id), prev = s.phase;
    s.downloaded = ev.downloaded || 0;
    s.total = ev.total > 0 ? ev.total : 0;
    s.error = ev.error || null;
    if (ev.phase === 'downloading'){
      if (prev !== 'downloading'){ reset(id, 'downloading'); }
      track(id, s.downloaded);
    } else if (ev.phase === 'done'){
      reset(id, 'done'); s.downloaded = s.total = (ev.total > 0 ? ev.total : s.downloaded);
    } else if (ev.phase === 'error'){
      reset(id, 'error');
    } else {
      reset(id, 'idle'); s.downloaded = 0;
    }
    emit(id);
  }

  function syncFromNative(id){
    if (!native) return;
    try { onNative(JSON.parse(native.getStatus(id, VER))); } catch(e){}
  }

  // ---------------------------------------------------------------- gzip -> text
  function utf8(u8){ return new TextDecoder('utf-8').decode(u8); }

  function gunzipToText(input){
    var u8 = (input instanceof Uint8Array) ? input : new Uint8Array(input);
    if (!(u8[0] === 0x1f && u8[1] === 0x8b)) return Promise.resolve(utf8(u8));   // gzip নয় -- সরাসরি টেক্সট

    function viaPako(){
      return new Promise(function(resolve, reject){
        setTimeout(function(){
          try { resolve(utf8(window.pako.ungzip(u8))); } catch(e){ reject(e); }
        }, 0);
      });
    }

    if (typeof DecompressionStream !== 'undefined' && typeof Blob !== 'undefined' && Blob.prototype.stream){
      try {
        var stream = new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'));
        return new Response(stream).text().catch(viaPako);
      } catch(e){ return viaPako(); }
    }
    return viaPako();
  }

  // ---------------------------------------------------------------- ভেতরে বসানো (embedded) কিতাব
  function embeddedEl(id){ return document.getElementById('hb-data-' + id); }
  function hasEmbedded(id){ return !!embeddedEl(id); }

  // base64 -> Uint8Array, ছোট ছোট ধাপে (প্রগ্রেস দেখানো যায়, ফোন আটকে যায় না)
  function decodeEmbedded(id, onProgress, isCancelled){
    return new Promise(function(resolve, reject){
      var el = embeddedEl(id);
      var b64 = el ? (el.textContent || '').trim() : '';
      if (!b64){ reject(new Error('no-embedded')); return; }
      var pad = b64.charAt(b64.length - 1) === '=' ? (b64.charAt(b64.length - 2) === '=' ? 2 : 1) : 0;
      var outLen = b64.length / 4 * 3 - pad;
      var out = new Uint8Array(outLen);
      var chunkChars = Math.max(4096, Math.ceil(b64.length / 40 / 4) * 4);   // ~৪০ ধাপ, ৪-এর গুণিতক
      var pos = 0, w = 0;

      function one(){
        var bin = atob(b64.substr(pos, chunkChars));
        for (var i = 0; i < bin.length; i++) out[w + i] = bin.charCodeAt(i);
        w += bin.length; pos += chunkChars;
      }

      function next(){
        try {
          if (isCancelled()){ reject(new Error('cancelled')); return; }
          if (document.hidden){ while (pos < b64.length) one(); }   // ব্যাকগ্রাউন্ড ট্যাবে টাইমার ধীর হয়, তাই একবারেই
          else if (pos < b64.length){ one(); }
          onProgress(Math.min(w, outLen));
          if (pos >= b64.length){ resolve(out); return; }
          setTimeout(next, 16);
        } catch(e){ reject(e); }
      }
      next();
    });
  }

  function startEmbedded(id){
    var s = st(id);
    reset(id, 'downloading'); s.downloaded = 0; s.total = 0; s.error = null; emit(id);
    cancelFlags[id] = false;
    var total = knownTotal(id);
    var cap = Math.max(0, Math.floor(total * 0.99));   // যাচাই শেষ হওয়া পর্যন্ত ৯৯%-এ থাকে

    decodeEmbedded(id, function(w){
      s.downloaded = total > 0 ? Math.min(w, cap) : w;
      track(id, s.downloaded); emit(id);
    }, function(){ return !!cancelFlags[id]; })
    .then(gunzipToText)
    .then(function(text){
      if (cancelFlags[id]) throw new Error('cancelled');
      if (text.charAt(0) !== '{') throw new Error('not-book');
      stash = { id: id, text: text };
      setTimeout(function(){ if (stash && stash.id === id) stash = null; }, 8000);
      flags[id] = 1; saveFlags();
      s.downloaded = s.total = total || s.downloaded;
      reset(id, 'done'); emit(id);
    })
    .catch(function(e){
      var msg = e && e.message;
      if (msg === 'cancelled'){ reset(id, 'idle'); s.downloaded = 0; emit(id); return; }
      reset(id, 'error'); s.error = (msg === 'not-book') ? 'not-book' : 'corrupt'; emit(id);
    });
  }

  // ---------------------------------------------------------------- IndexedDB (নেটওয়ার্ক থেকে নামানো কিতাবের জন্য)
  var IDB_NAME = 'hadith-books', IDB_STORE = 'books';

  function idbOpen(){
    return new Promise(function(resolve, reject){
      if (!window.indexedDB){ reject(new Error('no-idb')); return; }
      var r;
      try { r = indexedDB.open(IDB_NAME, 1); } catch(e){ reject(e); return; }
      r.onupgradeneeded = function(){ r.result.createObjectStore(IDB_STORE); };
      r.onsuccess = function(){ resolve(r.result); };
      r.onerror = function(){ reject(r.error || new Error('idb')); };
    });
  }
  function idbDo(mode, fn){
    return idbOpen().then(function(db){
      return new Promise(function(resolve, reject){
        var tx = db.transaction(IDB_STORE, mode), store = tx.objectStore(IDB_STORE), req = fn(store);
        tx.oncomplete = function(){ db.close(); resolve(req ? req.result : undefined); };
        tx.onerror = tx.onabort = function(){ db.close(); reject(tx.error || new Error('idb')); };
      });
    });
  }
  function idbPut(key, val){ return idbDo('readwrite', function(s){ return s.put(val, key); }); }
  function idbGet(key){ return idbDo('readonly', function(s){ return s.get(key); }); }
  function idbDel(key){ return idbDo('readwrite', function(s){ return s.delete(key); }); }
  function idbKeys(){ return idbDo('readonly', function(s){ return s.getAllKeys(); }); }

  // ---------------------------------------------------------------- নেটওয়ার্ক (লিংক থেকে XHR)
  function startWeb(id, url){
    var s = st(id);
    reset(id, 'downloading'); s.downloaded = 0; s.total = 0; s.error = null; emit(id);
    var xhr = xhrs[id] = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'arraybuffer';
    xhr.onprogress = function(e){
      s.downloaded = e.loaded;
      if (e.lengthComputable && e.total > 0) s.total = e.total;
      track(id, e.loaded); emit(id);
    };
    xhr.onerror = function(){ delete xhrs[id]; reset(id, 'error'); s.error = navigator.onLine === false ? 'offline' : 'network'; emit(id); };
    xhr.ontimeout = function(){ delete xhrs[id]; reset(id, 'error'); s.error = 'timeout'; emit(id); };
    xhr.onabort = function(){ delete xhrs[id]; reset(id, 'idle'); s.downloaded = 0; emit(id); };
    xhr.onload = function(){
      var ok = xhr.status >= 200 && xhr.status < 300;
      var buf = xhr.response; delete xhrs[id];
      if (!ok){ reset(id, 'error'); s.error = 'http-' + xhr.status; emit(id); return; }
      gunzipToText(buf).then(function(text){
        if (text.charAt(0) !== '{') throw new Error('not-book');
        webText[id] = text;
        idbPut(App.localFileName(id), text).then(function(){ idbReady[id] = true; }).catch(function(){});
        s.downloaded = s.total = buf.byteLength || s.total;
        reset(id, 'done'); emit(id);
      }).catch(function(){ reset(id, 'error'); s.error = 'not-book'; emit(id); });
    };
    xhr.send();
  }

  // ---------------------------------------------------------------- public API
  function start(id){
    var s = st(id);
    if (s.phase === 'downloading') return;
    s.error = null;
    if (native){
      var url = App.getBookUrl(id);
      if (!url){ reset(id, 'error'); s.error = 'no-url'; emit(id); return; }
      reset(id, 'downloading'); s.downloaded = s.downloaded || 0; emit(id);
      try { native.startDownload(id, url, VER); }
      catch(e){ reset(id, 'error'); s.error = 'network'; emit(id); }
    } else if (hasEmbedded(id)){
      startEmbedded(id);
    } else {
      var u = App.getBookUrl(id);
      if (!u){ reset(id, 'error'); s.error = 'no-url'; emit(id); return; }
      startWeb(id, u);
    }
  }

  function cancel(id){
    var s = st(id);
    if (s.phase !== 'downloading') return;
    if (native){ try{ native.cancelDownload(id); }catch(e){} }
    else if (xhrs[id]){ xhrs[id].abort(); }
    else { cancelFlags[id] = true; }
  }

  function isReady(id){
    if (native){ try{ return !!native.isBookReady(id, VER); }catch(e){ return false; } }
    return webText[id] !== undefined || !!idbReady[id] || (!!flags[id] && hasEmbedded(id));
  }

  // কিতাব না থাকলে আগেই ডাউনলোড-কার্ড দেখানো যায়
  function needsDownload(id){ return !isReady(id); }

  // ---- ডাউনলোড করা ফাইল পড়া (Android): আগে লোকাল URL (XHR), না হলে ব্রিজের টুকরো-পড়া ----
  function readViaUrl(id){
    return new Promise(function(resolve, reject){
      var x = new XMLHttpRequest();
      x.open('GET', LOCAL_HOST + App.localFileName(id), true);
      x.responseType = 'arraybuffer';
      x.onload = function(){
        if (x.status === 200 && x.response && x.response.byteLength > 0) resolve(new Uint8Array(x.response));
        else reject(new Error('local-url-status-' + x.status));
      };
      x.onerror = function(){ reject(new Error('local-url-error')); };
      x.send();
    });
  }

  function readViaBridge(id){
    var size = native.getBookSize(id, VER);
    if (!size) return Promise.reject(new Error('empty'));
    var out = new Uint8Array(size), CHUNK = 1024 * 1024, off = 0;
    return new Promise(function(resolve, reject){
      (function next(){
        if (off >= size){ resolve(out); return; }
        try {
          var b64 = native.readChunk(id, VER, off, Math.min(CHUNK, size - off));
          var bin = atob(b64);
          for (var i = 0; i < bin.length; i++) out[off + i] = bin.charCodeAt(i);
          off += bin.length;
          if (!bin.length){ reject(new Error('short-read')); return; }
        } catch(e){ reject(e); return; }
        setTimeout(next, 0);
      })();
    });
  }

  // কিতাবের পুরো JSON টেক্সট (string) ফেরত দেয়
  function readText(id){
    if (native){
      return readViaUrl(id).catch(function(){ return readViaBridge(id); }).then(function(bytes){
        return new TextDecoder('utf-8').decode(bytes);
      });
    }
    if (stash && stash.id === id){ var t = stash.text; stash = null; return Promise.resolve(t); }
    if (stash && stash.id !== id) stash = null;
    if (webText[id] !== undefined) return Promise.resolve(webText[id]);
    if (idbReady[id]){
      return idbGet(App.localFileName(id)).then(function(text){
        if (typeof text !== 'string' || !text) throw new Error('empty');
        return text;
      });
    }
    if (flags[id] && hasEmbedded(id)){
      return decodeEmbedded(id, function(){}, function(){ return false; }).then(gunzipToText);
    }
    return Promise.reject(new Error('not-downloaded'));
  }

  // ফাইল নষ্ট (corrupt) হলে, বা ইউজার মুছতে চাইলে -- যাতে আবার ডাউনলোড করা যায়
  function discard(id){
    if (native){ try { native.deleteBook(id); } catch(e){} }
    delete webText[id];
    delete flags[id]; saveFlags();
    if (stash && stash.id === id) stash = null;
    if (idbReady[id]){ delete idbReady[id]; idbDel(App.localFileName(id)).catch(function(){}); }
    var s = st(id); reset(id, 'idle'); s.downloaded = 0; s.error = null; emit(id);
  }

  // বাইরে থেকে ত্রুটি বসানো (যেমন ফাইল পড়া যায়নি / নষ্ট)
  function fail(id, code){
    var s = st(id); reset(id, 'error'); s.error = code; emit(id);
  }

  App.bookDl = {
    hasNative: function(){ return !!native; },
    isReady: isReady,
    needsDownload: needsDownload,
    getState: st,
    getKnownTotal: knownTotal,
    subscribe: subscribe,
    start: start,
    cancel: cancel,
    readText: readText,
    discard: discard,
    remove: discard,
    fail: fail,
    syncFromNative: syncFromNative,
    _onNative: onNative
  };

  App.BOOKS.forEach(function(b){ syncFromNative(b.id); });

  // নেটওয়ার্ক থেকে আগে নামানো কিতাব (IndexedDB) থাকলে সেগুলোকে "ডাউনলোড করা" হিসেবে ধরা
  if (!native){
    idbKeys().then(function(keys){
      var changed = false;
      App.BOOKS.forEach(function(b){
        if (keys.indexOf(App.localFileName(b.id)) !== -1 && !idbReady[b.id]){ idbReady[b.id] = true; changed = true; emit(b.id); }
      });
      if (changed && App.renderBookList && App.state && App.state.view === 'list' && App.state.tab === 'books'){
        App.renderBookList();
        if (App.filterBooks && App.els.searchInput) App.filterBooks(App.els.searchInput.value);
      }
      if (changed && App.enterBook && App.curBookId && App.state.view === 'book' && !App.els.bookGate.classList.contains('hidden')){
        App.enterBook(App.curBookId);
      }
    }).catch(function(){});
  }

})(window.HadithApp = window.HadithApp || {});

