
/* ===== js/services/bookmark-store.js ===== */
/*!
 * js/services/bookmark-store.js -- Bookmark persistence (localStorage)
 *
 * Provides : App.addOrUpdateBookmark, App.deleteBookmark, App.loadBookmarks, App.saveBookmarksArr,
 *            App.findBookmark, App.bookmarkedSeqs
 * Needs    : features/bookmark-list
 *
 * Bookmark: { id, createdAt, label, book, seq, num, ch, ct }
 *   book = কিতাবের id, seq = কিতাবের ভেতরে হাদিসের ক্রমিক ঠিকানা, num = হাদিস নম্বর, ch = অধ্যায় index, ct = অধ্যায়ের নাম
 */
(function (App) {
  "use strict";

  var BOOKMARKS_KEY = 'hadith-bookmarks';

  function loadBookmarks(){
    try{ return JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]'); } catch(e){ return []; }
  }
  App.loadBookmarks = loadBookmarks;

  function saveBookmarksArr(arr){
    try{ localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr)); } catch(e){}
  }
  App.saveBookmarksArr = saveBookmarksArr;

  function addOrUpdateBookmark(bm){
    var arr = loadBookmarks();
    var i = -1;
    for (var k=0;k<arr.length;k++){ if (arr[k].id === bm.id){ i = k; break; } }
    if (i >= 0){ arr[i] = bm; } else { arr.unshift(bm); }
    saveBookmarksArr(arr);
    App.renderBookmarksList();
  }
  App.addOrUpdateBookmark = addOrUpdateBookmark;

  function deleteBookmark(id){
    var arr = loadBookmarks();
    var removed = null;
    var out = [];
    for (var k=0;k<arr.length;k++){
      if (arr[k].id === id){ removed = arr[k]; } else { out.push(arr[k]); }
    }
    saveBookmarksArr(out);
    App.renderBookmarksList();
    return removed;
  }
  App.deleteBookmark = deleteBookmark;

  // একই কিতাবের একই হাদিসে আগে থেকে বুকমার্ক আছে কি না
  function findBookmark(book, seq){
    var arr = loadBookmarks();
    for (var k=0;k<arr.length;k++){ if (arr[k].book === book && arr[k].seq === seq) return arr[k]; }
    return null;
  }
  App.findBookmark = findBookmark;

  // এই কিতাবের বুকমার্ক-করা সব seq (হাদিস-কার্ডে সবুজ আইকন দেখানোর জন্য)
  function bookmarkedSeqs(book){
    var set = {}, arr = loadBookmarks();
    for (var k=0;k<arr.length;k++){ if (arr[k].book === book) set[arr[k].seq] = arr[k].id; }
    return set;
  }
  App.bookmarkedSeqs = bookmarkedSeqs;

})(window.HadithApp = window.HadithApp || {});

