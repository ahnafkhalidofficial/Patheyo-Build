
/* ===== js/features/last-read.js ===== */
/*!
 * js/features/last-read.js -- "Continue reading" card and last-read position tracking
 *
 * Provides : App.saveLastRead, App.updateLastReadChapter, App.showContinueCard
 * Needs    : core/dom, core/books, core/state, core/utils, features/chapter-reader, features/book-view
 */
(function (App) {
  "use strict";

  var KEY = 'hadith-last-read';

  function labelFor(bookId, num){
    var b = App.bookById(bookId);
    return (b ? b.nameBn : '') + ' — হাদিস ' + App.bn(num);
  }

  function saveLastRead(data){
    try{ localStorage.setItem(KEY, JSON.stringify(data)); } catch(e){}
  }
  App.saveLastRead = saveLastRead;

  // Called while the chapter is scrolled, so "পড়া চালিয়ে যান" always resumes at the exact hadith
  // the user last reached -- not just the start of the chapter that was opened.
  function updateLastReadChapter(){
    var pos = App.getCurrentVisibleHadith();
    if (!pos || !App.curBookId) return;
    saveLastRead({ book: App.curBookId, ch: App.curChapter, seq: pos.seq, num: pos.num, label: labelFor(App.curBookId, pos.num) });
  }
  App.updateLastReadChapter = updateLastReadChapter;

  function showContinueCard(){
    if (App.state.view !== 'list' || App.state.tab !== 'books'){ App.els.continueCard.classList.add('hidden'); return; }
    try{
      var raw = localStorage.getItem(KEY);
      if (!raw){ App.els.continueCard.classList.add('hidden'); return; }
      var data = JSON.parse(raw);
      if (!App.bookById(data.book)){ App.els.continueCard.classList.add('hidden'); return; }
      App.els.continueTitle.textContent = data.label || labelFor(data.book, data.num);
      App.els.continueCard.classList.remove('hidden');
      App.els.continueCard.onclick = function(){
        App.openHadith(data.book, { seq: data.seq, num: data.num, ch: data.ch });
      };
    } catch(e){ App.els.continueCard.classList.add('hidden'); }
  }
  App.showContinueCard = showContinueCard;

})(window.HadithApp = window.HadithApp || {});

