
/* হোম স্ক্রিনে উইজেট যুক্ত করা / PWA ইনস্টল */
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    document.getElementById('btn-install-pwa-widget')?.classList.remove('hidden');
});

function installAppToHomeScreen() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                document.getElementById('btn-install-pwa-widget')?.classList.add('hidden');
            }
            deferredPrompt = null;
        });
    } else {
        alert('আপনার ব্রাউজারে শর্টকাট তৈরির সুবিধা প্রস্তুত। ব্রাউজারের মেনু (⋮) থেকে "Add to Home Screen" বা "Install App" বেছে নিয়ে সরাসরি ইনস্টল করতে পারেন।');
    }
}

// অ্যান্ড্রয়েড অ্যাপের WebView-তে নেটিভ "হোম স্ক্রিনে উইজেট পিন করুন" সিস্টেম প্রম্পট চালু হয়।
function oneClickMakeWidget() {
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.pinWidgetToHomeScreen === 'function') {
        try { window.AndroidWidgetBridge.pinWidgetToHomeScreen(); } catch (e) { console.error('pin widget failed', e); }
        return;
    }
    if (deferredPrompt) { installAppToHomeScreen(); return; }
    alert('এই বাটনটি শুধু অ্যাপের ভেতরে কাজ করে — হোম স্ক্রিনে উইজেট যুক্ত করার অনুরোধ অ্যান্ড্রয়েড অ্যাপ থেকেই আসে। আপনি এখন ব্রাউজারের টেস্ট মোডে আছেন।');
}

