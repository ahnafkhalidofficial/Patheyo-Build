/* ডিজিটাল তাসবিহ — ধারা (streak) ও ইতিহাস। (ধারার প্রতীক: সোনালি ৮-কোণা নূরের তারা)
   ডেটা আসে 01-main.js-এর window.TzHist থেকে: প্রতিদিনের { t: মোট গণনা, d: সম্পন্ন জিকির, b: { জিকির: গণনা } }।
   নিয়ম: যেদিন মোট গণনা দৈনিক লক্ষ্যে (ডিফল্ট ১০০) পৌঁছায়, সেদিন "সক্রিয়" ধরা হয়; পরপর সক্রিয় দিনগুলোই ধারা।
   আজ লক্ষ্যে না পৌঁছালেও ধারা ভাঙে না — আজ দিন শেষ না হওয়া পর্যন্ত গতকাল পর্যন্ত গণনা চলে। */
(function () {
  'use strict';
  var $ = function (i) { return document.getElementById(i); };
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var WD = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি'];                 /* getDay() ক্রমে */
  var WD_FULL = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
  var MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  var TICK = '<svg class="tk" viewBox="0 0 24 24" aria-hidden="true"><path d="M4.8 12.6l4.6 4.6L19.2 7.2"/></svg>';   // নিজের আঁকা টিক (SVG) — লেখার ✓ চিহ্ন নয়, তাই সব ফোনে একই সুন্দর দেখায়
  var GOALS = [33, 100, 300, 500, 1000];
  var MILESTONES = [3, 7, 14, 21, 40, 100, 365];
  var FLAME = '<svg class="flm" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="stA2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFE08A"/><stop offset="1" stop-color="#E2A52B"/></linearGradient><linearGradient id="stB2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF6D2"/><stop offset="1" stop-color="#FFCB57"/></linearGradient></defs><g transform="translate(24 24)"><rect x="-15" y="-15" width="30" height="30" rx="4" fill="url(#stA2)"/><rect x="-15" y="-15" width="30" height="30" rx="4" fill="url(#stA2)" transform="rotate(45)"/><rect x="-8.5" y="-8.5" width="17" height="17" rx="2.5" fill="url(#stB2)"/><rect x="-8.5" y="-8.5" width="17" height="17" rx="2.5" fill="url(#stB2)" transform="rotate(45)"/><circle r="3.4" fill="#fff" fill-opacity=".9"/></g></svg>';

  /* ---------- তারিখের ছোট সহায়ক ---------- */
  function parse(k) { var p = k.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function addD(k, n) { var d = parse(k); d.setDate(d.getDate() + n); return TzHist.key(d); }
  function H() { return TzHist.all(); }
  function tot(k) { var h = H()[k]; return h ? h.t : 0; }
  function act(k) { return tot(k) >= TzHist.goal(); }

  /* ---------- ধারার হিসাব ---------- */
  function current() {
    var td = TzHist.key(), k = act(td) ? td : addD(td, -1), n = 0;
    while (act(k) && n < 4000) { n++; k = addD(k, -1); }
    return n;
  }
  function best() {
    var ks = Object.keys(H()).sort(), run = 0, b = 0, prev = null;
    ks.forEach(function (k) {
      if (!act(k)) { run = 0; prev = null; return; }
      run = (prev && addD(prev, 1) === k) ? run + 1 : 1;
      prev = k; if (run > b) b = run;
    });
    return b;
  }
  function activeDays() { var n = 0; Object.keys(H()).forEach(function (k) { if (act(k)) n++; }); return n; }
  function nextMile(n) { for (var i = 0; i < MILESTONES.length; i++) if (MILESTONES[i] > n) return MILESTONES[i]; return null; }
  function sumRange(fromKey, toKey) { var s = 0; Object.keys(H()).forEach(function (k) { if (k >= fromKey && k <= toKey) s += H()[k].t; }); return s; }

  /* ---------- মূল পেজের ছোট "ধারা" কার্ড ---------- */
  function refresh() {
    if (!window.TzHist || !$('skp')) return;
    var n = current(), g = TzHist.goal(), t = TzHist.today().total, p = Math.min(100, g ? t / g * 100 : 0);
    $('skpT').textContent = n > 0 ? 'টানা ' + bn(n) + ' দিন' : 'ধারা শুরু করুন';
    $('skpS').innerHTML = t >= g ? 'আজকের লক্ষ্য পূর্ণ' + TICK + ' (' + bn(t) + ')' : 'আজ ' + bn(t) + '/' + bn(g);
    $('skpBar').style.width = p + '%';
    $('skp').classList.toggle('off', n === 0);
    $('skp').classList.toggle('done', t >= g);
    if (opened) paintSheet();
  }

  /* ---------- ইতিহাস শিট ---------- */
  var veil, sheet, opened = false, clearArm = 0;
  function build() {
    veil = document.createElement('div'); veil.className = 'veil'; veil.id = 'hveil';
    sheet = document.createElement('div'); sheet.className = 'sheet hsheet'; sheet.id = 'hsheet';
    sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'জিকিরের ইতিহাস');
    document.body.appendChild(veil); document.body.appendChild(sheet);
    veil.addEventListener('click', requestClose);
    sheet.addEventListener('click', onClick);
  }
  function onClick(e) {
    var t = e.target.closest ? e.target.closest('[data-act]') : null; if (!t) return;
    var a = t.getAttribute('data-act');
    if (a === 'close') requestClose();
    else if (a === 'goal') { TzHist.setGoal(+t.getAttribute('data-v')); refresh(); paintSheet(); }
    else if (a === 'clear') {
      if (!clearArm) { clearArm = setTimeout(function () { clearArm = 0; var b = sheet.querySelector('[data-act=clear]'); if (b) b.textContent = 'সব ইতিহাস মুছুন'; }, 3500); t.textContent = 'নিশ্চিত করতে আবার চাপুন'; t.classList.add('arm'); }
      else { clearTimeout(clearArm); clearArm = 0; TzHist.clear(); refresh(); paintSheet(); }
    }
  }

  function bars() {
    var td = TzHist.key(), g = TzHist.goal(), keys = [], i, mx = g;
    for (i = 6; i >= 0; i--) keys.push(addD(td, -i));
    keys.forEach(function (k) { if (tot(k) > mx) mx = tot(k); });
    var h = '<div class="hb">';
    keys.forEach(function (k) {
      var v = tot(k), ph = Math.max(v ? 6 : 3, Math.round(v / mx * 92)), d = parse(k);
      h += '<div class="hb-c' + (k === td ? ' now' : '') + '"><span class="hb-v">' + (v ? bn(v) : '') + '</span>' +
        '<div class="hb-t"><i class="' + (v >= g ? 'ok' : (v ? 'part' : 'none')) + '" style="height:' + ph + 'px"></i></div>' +
        '<span class="hb-l">' + WD[d.getDay()] + '</span></div>';
    });
    return h + '<i class="hb-g" style="bottom:' + (Math.round(g / mx * 92) + 22) + 'px"><u>লক্ষ্য</u></i></div>';
  }

  function heat() {
    var td = TzHist.key(), now = new Date(), g = TzHist.goal();
    var sinceSat = (now.getDay() + 1) % 7;                         /* শনিবার থেকে সপ্তাহ শুরু */
    var start = addD(td, -(sinceSat + 28)), h = '<div class="hm-w">';
    ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র'].forEach(function (w) { h += '<span>' + w + '</span>'; });
    h += '</div><div class="hm">';
    for (var i = 0; i < 35; i++) {
      var k = addD(start, i), v = tot(k), future = k > td, lv = v >= g ? 3 : v >= g / 2 ? 2 : v > 0 ? 1 : 0, d = parse(k);
      h += '<div class="hm-c l' + lv + (future ? ' fut' : '') + (k === td ? ' now' : '') + '" title="' + bn(d.getDate()) + ' ' + MONTHS[d.getMonth()] + (v ? ' — ' + bn(v) + ' বার' : '') + '"><b>' + bn(d.getDate()) + '</b></div>';
    }
    return h + '</div><div class="hm-lg"><span>কম</span><i class="l0"></i><i class="l1"></i><i class="l2"></i><i class="l3"></i><span>লক্ষ্য পূর্ণ</span></div>';
  }

  function dayLabel(k) {
    var td = TzHist.key();
    if (k === td) return 'আজ'; if (k === addD(td, -1)) return 'গতকাল';
    var d = parse(k); return bn(d.getDate()) + ' ' + MONTHS[d.getMonth()] + ', ' + WD_FULL[d.getDay()];
  }
  function recent() {
    var ks = Object.keys(H()).filter(function (k) { return H()[k].t > 0; }).sort().reverse().slice(0, 14);
    if (!ks.length) return '<div class="hh-empty">এখনো কোনো ইতিহাস নেই। জিকির করলেই এখানে প্রতিদিনের হিসাব জমা হবে।</div>';
    var g = TzHist.goal();
    return ks.map(function (k) {
      var r = H()[k], parts = Object.keys(r.b || {}).sort(function (a, b) { return r.b[b] - r.b[a]; }).map(function (n) { return esc(n) + ' <b>' + bn(r.b[n]) + '</b>'; });
      return '<div class="hr"><div class="hr-t"><span>' + dayLabel(k) + '</span><em class="' + (r.t >= g ? 'ok' : '') + '">' + bn(r.t) + ' বার' + (r.t >= g ? TICK : '') + '</em></div>' +
        (parts.length ? '<div class="hr-b">' + parts.join(' · ') + '</div>' : '') +
        (r.d ? '<div class="hr-d">' + bn(r.d) + 'টি জিকির সম্পন্ন</div>' : '') + '</div>';
    }).join('');
  }

  function paintSheet() {
    var n = current(), b = Math.max(best(), n), g = TzHist.goal(), td = TzHist.today(), nm = nextMile(n);
    var now = new Date(), sinceSat = (now.getDay() + 1) % 7, wk = addD(TzHist.key(), -sinceSat), mo = TzHist.key(new Date(now.getFullYear(), now.getMonth(), 1));
    var all = 0; Object.keys(H()).forEach(function (k) { all += H()[k].t; });
    var pct = Math.min(100, g ? td.total / g * 100 : 0);
    var h = '<div class="grab"></div>' +
      '<div class="hh-hd"><div class="hh-t">জিকিরের ইতিহাস</div><button type="button" class="hh-x" data-act="close" aria-label="বন্ধ করুন"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>' +
      '<div class="hh-hero' + (n ? '' : ' off') + '">' + FLAME + '<div><div class="hh-n"><b>' + bn(n) + '</b> দিন</div><div class="hh-s">' + (n ? 'টানা সক্রিয় ধারা' : 'আজ লক্ষ্য পূর্ণ করলেই ধারা শুরু') + '</div></div>' +
      '<div class="hh-b2"><small>সর্বোচ্চ</small><b>' + bn(b) + '</b></div></div>' +
      (nm ? '<div class="hh-mile"><i><u style="width:' + Math.min(100, n / nm * 100) + '%"></u></i><span>পরের মাইলফলক: ' + bn(nm) + ' দিন (আর ' + bn(nm - n) + ' দিন)</span></div>' : '<div class="hh-mile"><span>মাশাআল্লাহ! সব মাইলফলক পার করেছেন।</span></div>') +
      '<div class="hh-sec">আজকের অগ্রগতি</div>' +
      '<div class="hh-today"><div class="hh-tr"><b>' + bn(td.total) + '</b><span> / ' + bn(g) + ' বার</span><em>' + (td.total >= g ? 'লক্ষ্য পূর্ণ' + TICK : 'আর ' + bn(g - td.total) + ' বার') + '</em></div><i class="hh-bar"><u style="width:' + pct + '%"></u></i></div>' +
      '<div class="hh-sec">দৈনিক লক্ষ্য <small>এই সংখ্যক জিকির করলে দিনটি ধারায় গণনা হয়</small></div>' +
      '<div class="hh-goal">' + GOALS.map(function (x) { return '<button type="button" data-act="goal" data-v="' + x + '" class="' + (x === g ? 'on' : '') + '">' + bn(x) + '</button>'; }).join('') + '</div>' +
      '<div class="hh-sec">গত ৭ দিন</div>' + bars() +
      '<div class="hh-sec">গত ৫ সপ্তাহ</div>' + heat() +
      '<div class="hh-sum"><div><small>এই সপ্তাহ</small><b>' + bn(sumRange(wk, TzHist.key())) + '</b></div><div><small>এই মাস</small><b>' + bn(sumRange(mo, TzHist.key())) + '</b></div><div><small>সর্বমোট</small><b>' + bn(all) + '</b></div></div>' +
      '<div class="hh-note">সক্রিয় দিন: <b>' + bn(activeDays()) + '</b> · প্রতিটি সংখ্যা জিকিরের মোট গণনা (বার)</div>' +
      '<div class="hh-sec">সাম্প্রতিক দিন</div>' + recent() +
      '<button type="button" class="hh-clear" data-act="clear">সব ইতিহাস মুছুন</button>';
    var top = sheet.scrollTop; sheet.innerHTML = h; sheet.scrollTop = top;
  }

  function open() {
    if (!window.TzHist) return;
    if (!veil) build();
    if (opened) return;
    var win = $('win'), ok = $('wok');                          /* "মাশাআল্লাহ" পর্দা খোলা থাকলে আগে সেটি বন্ধ করি */
    if (win && win.classList.contains('on') && ok) ok.click();
    opened = true;
    try { history.pushState({ thist: 1 }, ''); } catch (e) {}
    paintSheet(); sheet.scrollTop = 0;
    veil.classList.add('on'); sheet.classList.add('on');
  }
  function hide() { if (!opened) return; opened = false; veil.classList.remove('on'); sheet.classList.remove('on'); }
  function requestClose() { if (!opened) return; if (history.state && history.state.thist) history.back(); else hide(); }
  window.addEventListener('popstate', function () { if (opened) hide(); });

  window.TzHistUI = { open: open, close: requestClose, refresh: refresh, _calc: { current: current, best: best } };
})();
