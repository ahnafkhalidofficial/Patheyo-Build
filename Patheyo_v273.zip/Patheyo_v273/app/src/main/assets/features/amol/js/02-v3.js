/* ধাপ ৭ — আমলের রিপোর্ট
   ১) Android ব্যাক: আগে ওপরের পপআপ বন্ধ (হোম 06-native-bridge.js → __ptFrameBack জিজ্ঞেস করে)
      ছোট পপআপ (ঘর এডিট / নতুন আমল / মুছে ফেলা) সরাসরি বন্ধ; বড় পর্দাগুলো (রিপোর্ট-ফ্লো, মাসিক হিসাব, কাজা)
      নিজেরাই history.pushState করে, তাই history.back() দিলে তাদের নিজের popstate-কোড চলে।
   ২) হোম/নামাজ পেজে "আদায় করেছি" দিলে এই পেজ খোলা থাকলেও সাথে সাথে হিসাব বদলায় (একই amol_report_state)। */
(function () {
  'use strict';
  function open(id) { var el = document.getElementById(id); return !!(el && el.classList.contains('show')); }
  function shut(id) { var el = document.getElementById(id); if (el) el.classList.remove('show'); }

  window.__ptFrameBack = function () {
    if (open('popMask')) { shut('popMask'); return true; }
    if (open('confirmDeleteMask')) { var c = document.getElementById('confirmDeleteCancelBtn'); if (c) c.click(); else shut('confirmDeleteMask'); return true; }
    if (open('amalModalMask')) { shut('amalModalMask'); return true; }
    if (open('qazaOverlay')) { try { closeQaza(); } catch (e) { shut('qazaOverlay'); } return true; }
    if (open('sheetOverlay')) { try { closeSheet(); } catch (e) { shut('sheetOverlay'); } return true; }
    if (open('flowOverlay')) {
      var back = document.getElementById('flowBackBtn');
      if (back && back.style.display !== 'none') { back.click(); return true; }
      var x = document.getElementById('flowCloseBtn'); if (x) x.click(); return true;
    }
    return false;
  };

  window.addEventListener('storage', function (e) {
    if (e.key !== 'amol_report_state') return;
    try {
      if (open('flowOverlay')) return;                 /* রিপোর্ট লেখার মাঝে হিসাব বদলাবো না */
      loadLocalFallback(); renderHome();
      if (open('sheetOverlay')) renderSheet();
    } catch (err) {}
  });
})();
