
/* ============================================================
   AMOL REPORT — data model, content, and interaction logic
   ============================================================ */

/* ---------- defensive event binding ----------
   Prevents a single missing element or a thrown error inside one
   handler from ever blocking the rest of the script's button
   bindings (each call is isolated in its own try/catch). */
function on(id, evt, handler){
  try{
    const el = document.getElementById(id);
    if(!el){ return; }
    el.addEventListener(evt, function(e){
      try{ handler(e); }catch(err){ console.error('[amol] handler error on #'+id, err); }
    });
  }catch(err){ console.error('[amol] failed to bind #'+id, err); }
}

/* ---------- ripple micro-interaction (delegated, works on dynamic content) ---------- */
function attachRipple(root){
  try{
    root.addEventListener('pointerdown', function(e){
      const btn = e.target.closest('.rippleable');
      if(!btn) return;
      try{
        const rect = btn.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height) * 1.5;
        const span = document.createElement('span');
        span.className = 'ripple';
        span.style.width = span.style.height = size+'px';
        span.style.left = (e.clientX - rect.left - size/2)+'px';
        span.style.top = (e.clientY - rect.top - size/2)+'px';
        btn.appendChild(span);
        setTimeout(()=> { try{ span.remove(); }catch(err){} }, 620);
      }catch(err){}
    });
  }catch(err){}
}

/* ---------- refined icon set (original line-icon style, 24x24) ---------- */
const ICONS = {
  check:`<svg viewBox="0 0 24 24" fill="none"><path d="M6.5 12.5l3.5 3.5 7.5-8" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  cross:`<svg viewBox="0 0 24 24" fill="none"><path d="M7.5 7.5l9 9M16.5 7.5l-9 9" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  jamaat:`<svg viewBox="0 0 24 24" fill="none"><circle cx="8.3" cy="7.3" r="2.6" stroke="currentColor" stroke-width="1.8"/><path d="M3.2 18.5c0-2.9 2.3-5.1 5.1-5.1s5.1 2.2 5.1 5.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="16.2" cy="6.6" r="2.1" stroke="currentColor" stroke-width="1.8" opacity=".8"/><path d="M13.6 18.5c0-2.4 1.7-4.3 4.2-4.7 1.7-.3 3 .9 3 2.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" opacity=".8"/></svg>`,
  alone:`<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="7.6" r="3.6" stroke="currentColor" stroke-width="1.9"/><path d="M4.8 19.4c0-3.4 3.2-6.1 7.2-6.1s7.2 2.7 7.2 6.1" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>`,
  qaza:`<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="13" r="7.6" stroke="currentColor" stroke-width="1.9"/><path d="M12 9.2v4.1l2.8 1.9" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.4 3.4h5.2M12 3.4v2.2" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>`,
  moon:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.2 14.9A8.7 8.7 0 1 1 9.1 3.8a7.2 7.2 0 0 0 11.1 11.1Z"/></svg>`,
  clipboard:`<svg viewBox="0 0 24 24" fill="none"><rect x="5.5" y="4.5" width="13" height="16" rx="2.2" stroke="currentColor" stroke-width="1.8"/><path d="M9 4.2h6a1 1 0 0 1 1 1v.8H8v-.8a1 1 0 0 1 1-1Z" fill="currentColor" opacity=".18" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 12h7M8.5 15.5h5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>`,
  sparkleStar:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l1.9 6.3L20 10.5l-6.1 1.9L12 18.5l-1.9-6.1L4 10.5l6.1-1.7L12 2.5Z"/></svg>`,
  speakerOn:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.2 9.3h2.9l3.9-3.3c.7-.6 1.8-.1 1.8.8v10.4c0 .9-1.1 1.4-1.8.8l-3.9-3.3H4.2c-.7 0-1.2-.5-1.2-1.2v-3c0-.7.5-1.2 1.2-1.2z" fill="currentColor" stroke="none"/><path d="M16 9.1a4.2 4.2 0 0 1 0 5.8"/><path d="M18.7 6.5a8 8 0 0 1 0 11" opacity=".65"/></svg>`,
  speakerOff:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.2 9.3h2.9l3.9-3.3c.7-.6 1.8-.1 1.8.8v10.4c0 .9-1.1 1.4-1.8.8l-3.9-3.3H4.2c-.7 0-1.2-.5-1.2-1.2v-3c0-.7.5-1.2 1.2-1.2z" fill="currentColor" stroke="none"/><path d="M16.2 9.6l4.6 4.8M20.8 9.6l-4.6 4.8"/></svg>`,
  trash:`<svg viewBox="0 0 24 24" fill="none"><path d="M5 7h14M9.5 7V5.3a1.3 1.3 0 0 1 1.3-1.3h2.4a1.3 1.3 0 0 1 1.3 1.3V7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 7l.8 12.1A1.8 1.8 0 0 0 9.6 20.7h4.8a1.8 1.8 0 0 0 1.8-1.6L17 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.2 11v6M13.8 11v6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`,
  pdf:`<svg viewBox="0 0 24 24" fill="none"><path d="M7 3h7l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M14 3v4h4" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M8.3 17v-4.3h1.1c.9 0 1.5.6 1.5 1.5s-.6 1.5-1.5 1.5h-.4M12.6 17v-4.3h1c1.1 0 1.9.9 1.9 2.15S14.7 17 13.6 17h-1ZM17.2 17v-4.3h2.2M17.2 15h1.7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

/* ---------- gentle synthesized sound effects (Web Audio; no external files) ---------- */
const SoundFX = (function(){
  let ctx = null, boostNode = null;
  function ensureCtx(){
    if(ctx) return ctx;
    try{
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      // A gentle limiter lets us push tones louder without risking clipping,
      // and a boost stage in front of it raises perceived loudness on phone speakers.
      const compressor = ctx.createDynamicsCompressor();
      compressor.threshold.value = -14;
      compressor.knee.value = 20;
      compressor.ratio.value = 6;
      compressor.attack.value = 0.003;
      compressor.release.value = 0.16;
      compressor.connect(ctx.destination);
      boostNode = ctx.createGain();
      boostNode.gain.value = 1.9;
      boostNode.connect(compressor);
    }catch(e){ ctx = null; boostNode = null; }
    return ctx;
  }
  function tone(c, freq, start, dur, type, peakGain){
    try{
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.type = type || 'sine';
      osc.frequency.value = freq;
      const t0 = c.currentTime + start;
      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.exponentialRampToValueAtTime(peakGain || 0.24, t0 + 0.014);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      osc.connect(gain);
      gain.connect(boostNode || c.destination);
      osc.start(t0);
      osc.stop(t0 + dur + 0.03);
    }catch(e){}
  }
  function ptSnd(){ try{ return localStorage.getItem('pt_click_sound') !== '0'; }catch(e){ return true; } }   /* v256: সাউন্ড সুইচ এখন সেটিংসে */
  function play(seq){
    if(!ptSnd()) return;
    const c = ensureCtx();
    if(!c) return;
    if(c.state === 'suspended'){ c.resume().catch(()=>{}); }
    seq.forEach(n=> tone(c, n.f, n.t, n.d, n.type, n.g));
  }
  return {
    tick(){ play([{f:640, t:0, d:.09, g:.22}]); },
    soft(){ play([{f:494, t:0, d:.16, g:.22}]); },
    success(){ play([{f:659, t:0, d:.12, g:.26}, {f:880, t:.09, d:.17, g:.26}]); },
    jamaat(){ play([{f:523, t:0, d:.1, g:.24}, {f:659, t:.08, d:.1, g:.24}, {f:784, t:.16, d:.24, g:.27}]); },
    miss(){ play([{f:349, t:0, d:.15, g:.26}, {f:262, t:.12, d:.26, g:.26}]); },
    complete(){ play([{f:523, t:0, d:.09, g:.22}, {f:659, t:.08, d:.09, g:.22}, {f:784, t:.16, d:.09, g:.22}, {f:988, t:.24, d:.3, g:.25}]); }
  };
})();

/* ---------- Bengali helpers ---------- */
const BN_DIGITS = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
function toBn(n){ return String(n).replace(/[0-9]/g, d => BN_DIGITS[d]); }
const WEEKDAYS_BN = ['রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','শনিবার'];
const MONTHS_BN = ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
function pad2(n){ return n<10 ? '0'+n : ''+n; }
function dateKey(d){ return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()); }
function monthKey(d){ return d.getFullYear()+'-'+pad2(d.getMonth()+1); }
function bnFullDate(d){
  return toBn(d.getDate())+' '+MONTHS_BN[d.getMonth()]+', '+toBn(d.getFullYear())+' ('+WEEKDAYS_BN[d.getDay()]+')';
}
function bnMonthLabel(d){ return MONTHS_BN[d.getMonth()]+' '+toBn(d.getFullYear()); }
function daysInMonth(y,m){ return new Date(y, m+1, 0).getDate(); }

/* ---------- slot definitions ----------
   Storage keys are position-based so Friday/weekday share one column set.
*/
const SLOT_DEFS = [
  {id:'fajr_s1', type:'sunnah', label:()=> 'ফজরের আগে সুন্নত', short:'ফজর সু.'},
  {id:'fajr',    type:'fard',   label:()=> 'ফজর', short:'ফজর'},
  {id:'midday_s1', type:'sunnah', label:(fri)=> fri? 'জুমার আগে সুন্নত':'যোহরের আগে সুন্নত', short:(fri)=>fri?'জুমা সু.':'যোহর সু.'},
  {id:'midday',    type:'fard',   label:(fri)=> fri? 'জুমা':'যোহর', short:(fri)=>fri?'জুমা':'যোহর'},
  {id:'midday_s2', type:'sunnah', label:(fri)=> fri? 'জুমার পরে সুন্নত':'যোহরের পরে সুন্নত', short:(fri)=>fri?'জুমা সু.২':'যোহর সু.২'},
  {id:'asr_s1',  type:'sunnah', label:()=> 'আসরের আগে সুন্নত', short:'আসর সু.'},
  {id:'asr',     type:'fard',   label:()=> 'আসর', short:'আসর'},
  {id:'maghrib', type:'fard',   label:()=> 'মাগরিব', short:'মাগরিব'},
  {id:'maghrib_s1', type:'sunnah', label:()=> 'মাগরিবের পরে সুন্নত', short:'মাগরিব সু.'},
  {id:'isha_s1', type:'sunnah', label:()=> 'এশার আগে সুন্নত', short:'এশা সু.'},
  {id:'isha',    type:'fard',   label:()=> 'এশা', short:'এশা'},
  {id:'isha_s2', type:'sunnah', label:()=> 'এশার পরে সুন্নত', short:'এশা সু.২'},
  {id:'witr',    type:'fard',   label:()=> 'বিতর', short:'বিতর'},
];
function slotLabel(def, isFriday){ return typeof def.label==='function' ? def.label(isFriday) : def.label; }
function slotShort(def, isFriday){ return typeof def.short==='function' ? def.short(isFriday) : def.short; }

const FARD_GROUPS = [
  {key:'fajr', label:'ফজর', slots:['fajr']},
  {key:'midday', label:'যোহর/জুমা', slots:['midday']},
  {key:'asr', label:'আসর', slots:['asr']},
  {key:'maghrib', label:'মাগরিব', slots:['maghrib']},
  {key:'isha', label:'এশা', slots:['isha']},
  {key:'witr', label:'বিতর', slots:['witr']},
];
const SUNNAH_IDS = SLOT_DEFS.filter(s=>s.type==='sunnah').map(s=>s.id);
const FARD_IDS = SLOT_DEFS.filter(s=>s.type==='fard').map(s=>s.id);

/* ---------- content pools (ayat/hadith, ভাবার্থ — paraphrased meaning, not verbatim translation) ---------- */
const POOL_CONGRATS = [
  {kind:'আয়াত', ref:'সূরা আল-বাকারা, ২:২৭৭', text:'যারা ঈমান আনে, সৎকাজ করে, সালাত কায়েম করে ও যাকাত আদায় করে — তাদের জন্য তাদের রবের কাছে প্রতিদান রয়েছে; তাদের কোনো ভয় নেই এবং তারা দুঃখিতও হবে না।'},
  {kind:'আয়াত', ref:'সূরা আল-মাআরিজ, ৭০:৩৪-৩৫', text:'যারা নিজেদের সালাতের প্রতি যত্নবান ও নিয়মিত, তারাই জান্নাতে সম্মানিতভাবে থাকবে।'},
  {kind:'আয়াত', ref:'সূরা আল-মুমিনুন, ২৩:১-২, ৯-১১', text:'মুমিনগণ সফলকাম — যারা নিজেদের সালাতে বিনম্র এবং তার যত্ন নেয়; তারাই জান্নাতের ওয়ারিশ।'},
  {kind:'আয়াত', ref:'সূরা ত্বা-হা, ২০:১৩২', text:'নিজের পরিবারকে সালাতের নির্দেশ দাও এবং নিজেও তাতে ধৈর্যশীল থাকো; শুভ পরিণতি মুত্তাকীদের জন্যই।'},
  {kind:'আয়াত', ref:'সূরা আল-আনকাবুত, ২৯:৪৫', text:'সালাত কায়েম করো — নিশ্চয় সালাত অশ্লীলতা ও গর্হিত কাজ থেকে বিরত রাখে, আর আল্লাহর স্মরণই সর্বশ্রেষ্ঠ।'},
];
const POOL_JAMAAT = [
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'জামাতে আদায়কৃত সালাত একাকী আদায়কৃত সালাতের চেয়ে সাতাশ গুণ বেশি মর্যাদাপূর্ণ।'},
  {kind:'হাদিস', ref:'আবু দাউদ ও তিরমিযী', text:'যে ব্যক্তি এশার সালাত জামাতে আদায় করে, সে যেন অর্ধরাত ইবাদত করলো; আর যে ফজরও জামাতে আদায় করে, সে যেন সারা রাত ইবাদতে কাটালো।'},
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'মসজিদের দিকে ফেলা প্রতিটি কদমে একটি নেকী লেখা হয় ও একটি গুনাহ মোচন করা হয়।'},
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'এক সালাতের পর পরবর্তী সালাতের অপেক্ষায় বসে থাকা ব্যক্তির জন্য ফেরেশতারা ক্রমাগত ক্ষমা প্রার্থনা করতে থাকেন।'},
  {kind:'আয়াত', ref:'সূরা আল-জুমুআ, ৬২:৯', text:'যখন জুমার দিন সালাতের জন্য আহ্বান করা হয়, তখন আল্লাহর স্মরণের দিকে দ্রুত ধাবিত হও — এটিই তোমাদের জন্য উত্তম।'},
];
const POOL_ALONE = [
  {kind:'হাদিস', ref:'সহীহ বুখারী', text:'জামাতে অনুপস্থিত থাকা এতটাই গুরুত্বপূর্ণ বিষয় বলে গণ্য হতো যে, রাসূল (সা.) তাদের ঘরে গিয়ে সালাতের গুরুত্ব স্মরণ করিয়ে দেওয়ার কথা ভাবতেন।'},
  {kind:'হাদিস', ref:'আবু দাউদ, তিরমিযী, নাসায়ী', text:'তিন ব্যক্তি এক এলাকায় থেকেও যদি জামাতে সালাত আদায় না করে, শয়তান তাদের ওপর প্রভাব বিস্তার করে — তাই জামাতের সাথে থাকা জরুরি।'},
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'এক দৃষ্টিহীন সাহাবী অব্যাহতি চাইলে রাসূল (সা.) জিজ্ঞেস করলেন, তুমি কি আজান শুনতে পাও? তিনি বললেন হ্যাঁ। রাসূল (সা.) বললেন, তাহলে সাড়া দাও।'},
  {kind:'আয়াত', ref:'সূরা আন-নিসা, ৪:১০২', text:'যুদ্ধ-বিপদের সময়েও জামাতে সালাত আদায়ের নির্দেশ এসেছে — স্বাভাবিক অবস্থায় এর গুরুত্ব আরও বেশি।'},
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'জামাতে সালাত আদায়কারীর সালাত একাকী সালাতের চেয়ে বহুগুণ শ্রেষ্ঠ — সাধ্যমতো পরের বার জামাতে শামিল হওয়ার চেষ্টা রাখুন।'},
];
const POOL_QAZA = [
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'কেউ ঘুমিয়ে পড়ার কারণে বা ভুলে সালাত ছুটিয়ে ফেললে, স্মরণ হওয়ামাত্র তা আদায় করে নেবে — এটিই তার কাফফারা।'},
  {kind:'আয়াত', ref:'সূরা আন-নিসা, ৪:১০৩', text:'নিশ্চয় সালাত মুমিনদের ওপর নির্দিষ্ট সময়ে ফরজ করে দেওয়া হয়েছে।'},
  {kind:'হাদিস', ref:'সহীহ বুখারী ও সহীহ মুসলিম', text:'সর্বোত্তম আমলগুলোর একটি হলো — সালাত তার নির্ধারিত সময়ে আদায় করা।'},
  {kind:'হাদিস', ref:'জামে তিরমিযী', text:'কিয়ামতের দিন বান্দার আমলের মধ্যে সর্বপ্রথম সালাতের হিসাব নেওয়া হবে; তা ঠিক থাকলে বাকি আমলও ঠিক থাকবে।'},
  {kind:'আয়াত', ref:'সূরা আল-বাকারা, ২:২৩৮', text:'সালাতসমূহের এবং বিশেষভাবে মধ্যবর্তী সালাতের হেফাজত করো, আর আল্লাহর উদ্দেশ্যে বিনীতভাবে দাঁড়াও।'},
];
const POOL_MISSED = [
  {kind:'হাদিস', ref:'সহীহ মুসলিম', text:'বান্দা ও কুফরের মধ্যে পার্থক্যকারী বিষয় হলো সালাত ত্যাগ করা — তাই ফিরে আসার পথ সবসময় খোলা।'},
  {kind:'আয়াত', ref:'সূরা আল-মুদ্দাসসির, ৭৪:৪২-৪৩', text:'জাহান্নামীদের জিজ্ঞাসা করা হবে, কিসে তোমাদের এখানে নিয়ে এলো? তারা বলবে, আমরা সালাত আদায়কারীদের অন্তর্ভুক্ত ছিলাম না।'},
  {kind:'আয়াত', ref:'সূরা মারইয়াম, ১৯:৫৯', text:'তাদের পরে এমন এক প্রজন্ম এলো যারা সালাত নষ্ট করলো এবং প্রবৃত্তির অনুসরণ করলো — তারা শীঘ্রই বিপথগামিতার পরিণাম দেখবে।'},
  {kind:'হাদিস', ref:'জামে তিরমিযী', text:'বান্দা ও শিরকের মাঝে পার্থক্যকারী বিষয় হলো সালাত ত্যাগ করা — আজই আবার শুরু করার সুযোগ আছে।'},
  {kind:'আয়াত', ref:'সূরা আত-তাওবা, ৯:১১', text:'তারা যদি তওবা করে, সালাত কায়েম করে ও যাকাত দেয়, তবে তারা দ্বীনে তোমাদের ভাই।'},
];
function pickQuote(pool, seed){ return pool[seed % pool.length]; }

/* ---------- global state ---------- */
let STATE = { theme:'light', soundOn:true, customAmals:[], days:{}, qaza:{ base:{}, paid:{}, log:[] } };
let dbNs = null, stateRef = null, writeChain = Promise.resolve();
let today = new Date();
let sheetMonthCursor = new Date(today.getFullYear(), today.getMonth(), 1);
let flowQueue = [];
let flowIndex = 0;
let flowDateKey = dateKey(today);
let flowResults = {}; // buffered results for the active flow session

/* ---------- persistence ---------- */
function withTimeout(promise, ms){
  return Promise.race([
    promise,
    new Promise((resolve)=> setTimeout(()=> resolve(null), ms))
  ]);
}
function loadLocalFallback(){
  try{
    const raw = localStorage.getItem('amol_report_state');
    if(raw){
      const parsed = JSON.parse(raw);
      if(parsed){
        /* হোম/নামাজ পেজ আগে "আদায় করেছি" লিখলে শুধু days থাকে — বাকি ঘর ডিফল্ট দিয়ে পূরণ (নইলে customAmals.forEach-এ ক্র্যাশ) */
        STATE = Object.assign({ theme:STATE.theme, soundOn:true, customAmals:[], days:{}, qaza:{ base:{}, paid:{}, log:[] } }, parsed);
        if(!Array.isArray(STATE.customAmals)) STATE.customAmals = [];
        if(!STATE.days || typeof STATE.days!=='object') STATE.days = {};
        if(!STATE.qaza || typeof STATE.qaza!=='object') STATE.qaza = { base:{}, paid:{}, log:[] };
        if(typeof STATE.soundOn !== 'boolean') STATE.soundOn = true;
      }
    }
  }catch(e){}
}
async function initStorage(){
  // Load whatever we have locally first, synchronously-ish, so the UI
  // never waits on the network/db before becoming interactive.
  loadLocalFallback();
  try{
    if(window.claude && window.claude.use){
      dbNs = await withTimeout(window.claude.use('db'), 4000);
    }
  }catch(e){ dbNs = null; }

  // Prefer a private per-viewer path (data/users/<id>/...) so the same
  // published link never lets two different people share or overwrite
  // each other's report — falls back to a shared doc if no identity
  // is available (e.g. an anonymous preview).
  let docPath = 'state/app';
  try{
    if(window.claude && window.claude.use){
      const userNs = await withTimeout(window.claude.use('user'), 3000);
      if(userNs){
        const uid = await withTimeout(userNs.id(), 3000);
        if(uid){ docPath = 'data/users/'+uid+'/state/app'; }
      }
    }
  }catch(e){}

  if(dbNs){
    stateRef = dbNs.doc(docPath);
    try{
      const snap = await withTimeout(stateRef.get(), 4000);
      if(snap && snap.exists && snap.data()){
        const d = snap.data();
        STATE = { theme:d.theme||STATE.theme, soundOn: (typeof d.soundOn==='boolean'? d.soundOn : STATE.soundOn), customAmals:d.customAmals||STATE.customAmals, days:d.days||STATE.days, qaza:d.qaza||STATE.qaza };
      }
    }catch(e){}
    try{
      stateRef.onSnapshot((snap)=>{
        if(!snap || !snap.exists) return;
        const d = snap.data();
        if(!d) return;
        STATE = { theme:d.theme||STATE.theme, soundOn: (typeof d.soundOn==='boolean'? d.soundOn : STATE.soundOn), customAmals:d.customAmals||STATE.customAmals, days:d.days||STATE.days, qaza:d.qaza||STATE.qaza };
        applyTheme();
        applySound();
        renderHome();
      }, ()=>{});
    }catch(e){}
  }
}
function persist(){
  const snapshot = JSON.parse(JSON.stringify(STATE));
  writeChain = writeChain.then(()=>{
    if(dbNs && stateRef){
      try{ localStorage.setItem('amol_report_state', JSON.stringify(snapshot)); }catch(e){}
      return stateRef.set(snapshot).catch(()=>{});
    } else {
      try{ localStorage.setItem('amol_report_state', JSON.stringify(snapshot)); }catch(e){}
      return Promise.resolve();
    }
  });
}

/* ---------- theme ---------- */
function applyTheme(){
  document.documentElement.setAttribute('data-theme', STATE.theme==='dark' ? 'dark':'light');
}
on('themeBtn', 'click', ()=>{
  STATE.theme = STATE.theme==='dark' ? 'light':'dark';
  applyTheme();
  applySound();
  persist();
});

function applySound(){
  try{
    const hs = document.getElementById('headSnd');
    if(hs){ hs.classList.toggle('on', !!STATE.soundOn); hs.setAttribute('aria-pressed', STATE.soundOn ? 'true':'false'); }
    const onEl = document.getElementById('soundIcoOn');
    const offEl = document.getElementById('soundIcoOff');
    if(onEl) onEl.innerHTML = ICONS.speakerOn;
    if(offEl) offEl.innerHTML = ICONS.speakerOff;
    // NOTE: must match the CSS centering rule's display value (flex) —
    // setting 'block' here would win over the .flow-sound span{display:flex}
    // rule (inline styles beat class rules) and silently break centering.
    if(onEl) onEl.style.display = STATE.soundOn ? 'flex' : 'none';
    if(offEl) offEl.style.display = STATE.soundOn ? 'none' : 'flex';
  }catch(e){}
}
function toggleSound(){
  STATE.soundOn = !STATE.soundOn;
  applySound();
  persist();
  if(STATE.soundOn){ SoundFX.tick(); }
}
on('soundToggleBtn', 'click', toggleSound);
on('headSnd', 'click', toggleSound);

/* ---------- day helpers ---------- */
/* ---------- নিজস্ব আমলের সময় (v221) ----------
   when = 'after:fajr' ইত্যাদি (ওয়াক্তের সাথে)  অথবা  'at:HH:MM' (ইউজারের নিজের বেছে নেওয়া যেকোনো সময়)।
   'at:' আমল দিনের ক্রমে মোটামুটি ওই সময়ের জায়গায় বসে (ফজরের আগে → শুরুতে, রাত ৯টা → এশার পরে)। */
const WHEN_ANCHOR = {
  'before:fajr':'__start', 'after:fajr':'fajr',
  'before:zuhr':'midday_s1', 'after:zuhr':'midday_s2',
  'before:asr':'midday_s2', 'after:asr':'asr',
  'before:maghrib':'asr', 'after:maghrib':'maghrib',
  'before:isha':'maghrib_s1', 'after:isha':'isha',
  'evening':'__end'
};
const WHEN_LABEL = {
  'before:fajr':'ফজরের আগে', 'after:fajr':'ফজরের পরে',
  'before:zuhr':'যোহর/জুমার আগে', 'after:zuhr':'যোহরের পরে',
  'before:asr':'আসরের আগে', 'after:asr':'আসরের পরে',
  'before:maghrib':'মাগরিবের আগে', 'after:maghrib':'মাগরিবের পরে',
  'before:isha':'এশার আগে', 'after:isha':'এশার পরে',
  'evening':'দিনের শেষে'
};
const CLOCK_ANCHORS = [[300,'fajr'],[750,'midday_s2'],[960,'asr'],[1080,'maghrib_s1'],[1170,'isha_s2']];
function clockMinutes(when){
  const m = /^at:(\d{1,2}):(\d{2})$/.exec(when || '');
  return m ? (Number(m[1])*60 + Number(m[2])) : null;
}
function bnClock(hhmm){
  const p = String(hhmm).split(':'), h = Number(p[0]), mi = Number(p[1]) || 0;
  const part = h<4 ? 'রাত' : h<6 ? 'ভোর' : h<12 ? 'সকাল' : h<15 ? 'দুপুর' : h<17 ? 'বিকাল' : h<19 ? 'সন্ধ্যা' : 'রাত';
  return part+' '+toBn(h%12 || 12)+':'+toBn(pad2(mi));
}
function whenText(when){
  const t = clockMinutes(when);
  if(t !== null) return bnClock(pad2(Math.floor(t/60))+':'+pad2(t%60))+' টায়';
  return WHEN_LABEL[when] || when;
}
function customAnchor(when){
  const t = clockMinutes(when);
  if(t !== null){
    if(t < CLOCK_ANCHORS[0][0]) return '__start';
    let a = CLOCK_ANCHORS[0][1];
    CLOCK_ANCHORS.forEach(c=>{ if(t >= c[0]) a = c[1]; });
    return a;
  }
  return WHEN_ANCHOR[when] || '__end';
}
function getDaySlots(d){
  const isFriday = d.getDay()===5;
  const slots = SLOT_DEFS.map(def=>({
    id:def.id, type:def.type, label:slotLabel(def,isFriday), short:slotShort(def,isFriday)
  }));
  const start = [], end = [], by = {};
  STATE.customAmals.forEach(ca=>{
    const slot = {id:'custom_'+ca.id, type:'custom', label:ca.name, short:ca.name, when:ca.when};
    const a = customAnchor(ca.when);
    if(a==='__start') start.push(slot); else if(a==='__end') end.push(slot); else (by[a] = by[a] || []).push(slot);
  });
  const byTime = (x,y)=> (clockMinutes(x.when) ?? -1) - (clockMinutes(y.when) ?? -1);
  start.sort(byTime); end.sort(byTime);
  const out = start.slice();
  slots.forEach(s=>{
    out.push(s);
    if(by[s.id]) by[s.id].sort(byTime).forEach(c=> out.push(c));
  });
  return out.concat(end);
}
function getDayRecord(key){ return STATE.days[key] || {}; }
function setDayRecord(key, slotId, value){
  if(!STATE.days[key]) STATE.days[key] = {};
  STATE.days[key][slotId] = value;
  persist();
}
function isPositive(type, val){
  if(!val) return false;
  if(type==='fard') return val==='jamaat' || val==='alone';
  return val==='done';
}

/* ---------- render: header/date ---------- */
function renderHeaderDate(){
  var el = document.getElementById('todayLabel');   /* v221: হিরোর ওপরের তারিখ সরানো হয়েছে */
  if(el) el.textContent = bnFullDate(today);
}

/* ---------- render: hero ring ---------- */
function renderHero(){
  const key = dateKey(today);
  const slots = getDaySlots(today);
  const rec = getDayRecord(key);
  const total = slots.length;
  let done = 0;
  slots.forEach(s=>{ if(rec[s.id]) done++; });
  const circumference = 207;
  const ratio = total? done/total : 0;
  document.getElementById('ringProgress').setAttribute('stroke-dashoffset', circumference - circumference*ratio);
  document.getElementById('ringText').textContent = toBn(done)+'/'+toBn(total);
  const startBtn = document.getElementById('startFlowBtn');
  const editBtn = document.getElementById('editTodayBtn');
  const sub = document.getElementById('heroSub');
  if(done>=total && total>0){
    startBtn.style.display='none';
    editBtn.style.display='block';
    sub.textContent = 'আজকের রিপোর্ট সম্পন্ন হয়েছে — মাশাআল্লাহ';
  } else if(done>0){
    startBtn.textContent = 'চালিয়ে যান';
    startBtn.style.display='block';
    editBtn.style.display='block';
    sub.textContent = toBn(total-done)+' টি এন্ট্রি বাকি আছে';
  } else {
    startBtn.textContent = 'রিপোর্ট শুরু করুন';
    startBtn.style.display='block';
    editBtn.style.display='none';
    sub.textContent = 'আজকের নামাজ ও সুন্নত এন্ট্রি করুন';
  }
}

/* ---------- render: custom amal list on home ---------- */
function renderCustomAmalList(){
  const wrap = document.getElementById('customAmalList');
  wrap.innerHTML='';
  if(STATE.customAmals.length===0){
    wrap.innerHTML = '<p class="hint" style="margin-top:6px;">এখনো কোনো নিজস্ব আমল যুক্ত করা হয়নি।</p>';
    return;
  }
  const rec = getDayRecord(dateKey(today));
  STATE.customAmals.forEach(ca=>{
    const val = rec['custom_'+ca.id];
    const row = document.createElement('div');
    row.className='amal-item';
    let chipHtml;
    if(val==='done') chipHtml = '<span class="chip done">সম্পন্ন</span>';
    else if(val==='missed') chipHtml = '<span class="chip missed">হয়নি</span>';
    else chipHtml = '<span class="chip pending">বাকি</span>';
    row.innerHTML = '<div><div class="name">'+escapeHtml(ca.name)+'</div><span class="when">'+ whenText(ca.when) +'</span></div>'
      + '<div class="amal-item-right">' + chipHtml
      + '<button type="button" class="amal-del-btn rippleable" data-id="'+ca.id+'" data-name="'+escapeHtml(ca.name)+'" aria-label="মুছুন">'+ICONS.trash+'</button></div>';
    wrap.appendChild(row);
  });
  wrap.querySelectorAll('.amal-del-btn').forEach(btn=>{
    btn.addEventListener('click', ()=> openDeleteAmalConfirm(btn.dataset.id, btn.dataset.name));
  });
}
function escapeHtml(s){ return s.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

let pendingDeleteAmalId = null;
function openDeleteAmalConfirm(id, name){
  pendingDeleteAmalId = id;
  const textEl = document.getElementById('confirmDeleteText');
  if(textEl) textEl.textContent = '"'+name+'" আমলটি মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা যাবে না।';
  const mask = document.getElementById('confirmDeleteMask');
  if(mask) mask.classList.add('show');
}

/* ---------- render: monthly summary on home ---------- */
function computeMonthStats(y,m){
  const dim = daysInMonth(y,m);
  const now = new Date();
  const isCurrent = (y===now.getFullYear() && m===now.getMonth());
  const upto = isCurrent ? now.getDate() : dim;
  const groupStats = {};
  FARD_GROUPS.forEach(g=> groupStats[g.key] = {pos:0, total:0});
  let sunnahPos=0, sunnahTotal=0;
  for(let day=1; day<=upto; day++){
    const d = new Date(y,m,day);
    const key = dateKey(d);
    const rec = STATE.days[key] || {};
    const isFriday = d.getDay()===5;
    FARD_IDS.forEach(id=>{
      const group = FARD_GROUPS.find(g=>g.slots.includes(id));
      if(!group) return;
      groupStats[group.key].total++;
      if(isPositive('fard', rec[id])) groupStats[group.key].pos++;
    });
    SUNNAH_IDS.forEach(id=>{
      sunnahTotal++;
      if(isPositive('sunnah', rec[id])) sunnahPos++;
    });
  }
  let fardPos=0, fardTotal=0;
  Object.values(groupStats).forEach(g=>{ fardPos+=g.pos; fardTotal+=g.total; });
  const overallPos = fardPos+sunnahPos, overallTotal = fardTotal+sunnahTotal;
  const pct = overallTotal? Math.round((overallPos/overallTotal)*100) : 0;
  const groupPct = {};
  FARD_GROUPS.forEach(g=>{ groupPct[g.key] = groupStats[g.key].total? Math.round((groupStats[g.key].pos/groupStats[g.key].total)*100):0; });
  const sunnahPct = sunnahTotal? Math.round((sunnahPos/sunnahTotal)*100):0;
  return {pct, groupPct, sunnahPct, upto};
}
function renderMonthlySummary(){
  const cur = computeMonthStats(today.getFullYear(), today.getMonth());
  const prevD = new Date(today.getFullYear(), today.getMonth()-1, 1);
  const prev = computeMonthStats(prevD.getFullYear(), prevD.getMonth());
  document.getElementById('curMonthPct').textContent = toBn(cur.pct)+'%';
  document.getElementById('prevMonthPct').textContent = toBn(prev.pct)+'%';
  const delta = cur.pct - prev.pct;
  const deltaEl = document.getElementById('deltaMonthPct');
  deltaEl.textContent = (delta>=0?'▲ ':'▼ ')+toBn(Math.abs(delta))+'%';
  deltaEl.className = 'val ' + (delta>=0?'up':'down');
  renderDaysChart();
}

/* ধাপ ৭ — গত ১৪ দিনের ফরজ (পাঁচ ওয়াক্ত) হিসাব: হালকা SVG বার-চার্ট (পূর্ণ দিন সোনালি, আংশিক নীল, ফাঁকা ধূসর দাগ) */
function renderDaysChart(){
  const box = document.getElementById('amDaysChart'); if(!box) return;
  const tk = dateKey(today), N = 14, W = 320, H = 104, top = 8, base = 78, slot = W / N, bw = Math.min(14, slot * .52);
  let bars = '', labels = '';
  for(let i = N-1; i >= 0; i--){
    const k = keyAdd(tk, -i), idx = N-1-i, cx = slot*idx + slot/2;
    const cnt = dayDoneCount(k), full = cnt >= 5, h = Math.max(cnt ? (base-top) * cnt/5 : 3, 3);
    const cls = full ? 'b-full' : cnt ? 'b-part' : 'b-none';
    bars += '<rect class="'+cls+'" x="'+(cx-bw/2).toFixed(1)+'" y="'+(base-h).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+h.toFixed(1)+'" rx="'+(bw/2).toFixed(1)+'"><title>'+toBn(cnt)+'/৫</title></rect>';
    if(full) bars += '<path class="b-star" transform="translate('+cx.toFixed(1)+' '+(base-h-7).toFixed(1)+') scale(.07)" d="M0 -50L14 -36H35V-15L49 0L35 14V35H14L0 49L-14 35H-35V14L-49 0L-35 -14V-35H-14Z"/>';
    const d = Number(k.slice(8));
    labels += '<text x="'+cx.toFixed(1)+'" y="'+(base+17)+'" class="'+(k===tk?'t-now':'')+'">'+toBn(d)+'</text>';
  }
  const grid = '<line x1="0" x2="'+W+'" y1="'+base+'" y2="'+base+'" class="g-base"/><line x1="0" x2="'+W+'" y1="'+top+'" y2="'+top+'" class="g-top"/>';
  box.innerHTML = '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="গত ১৪ দিনের ফরজ নামাজ">'+grid+bars+labels+'</svg>';
}

/* ---------- ধারা (streak): টানা কত দিন পাঁচ ওয়াক্তই আদায় হয়েছে ---------- */
const TICK = '<svg class="tk" viewBox="0 0 24 24" aria-hidden="true"><path d="M4.8 12.6l4.6 4.6L19.2 7.2"/></svg>';   // নিজের আঁকা টিক (SVG) — লেখার ✓ চিহ্ন নয়, তাই সব ফোনে একই সুন্দর দেখায়
const FIVE_WAQT = ['fajr','midday','asr','maghrib','isha'];
const WD_SHORT = ['রবি','সোম','মঙ্গল','বুধ','বৃহ','শুক্র','শনি'];
const MILESTONES = [3,7,14,21,40,100,365];
function keyAdd(key, n){ const p = key.split('-').map(Number); return dateKey(new Date(p[0], p[1]-1, p[2]+n)); }
function waqtDone(rec, id, needJamaat){ return needJamaat ? rec[id]==='jamaat' : isPositive('fard', rec[id]); }
function dayFull(key, needJamaat){ const rec = STATE.days[key]; return !!rec && FIVE_WAQT.every(id=> waqtDone(rec, id, needJamaat)); }
function dayDoneCount(key){ const rec = STATE.days[key] || {}; return FIVE_WAQT.filter(id=> isPositive('fard', rec[id])).length; }
function dayHasLoss(key){ const rec = STATE.days[key] || {}; return FIVE_WAQT.some(id=> rec[id] && !isPositive('fard', rec[id])); }   // কাজা/বাদ লেখা আছে
function streakNow(needJamaat){
  const tk = dateKey(today);
  let k = tk;
  if(!dayFull(k, needJamaat)){
    if(dayHasLoss(tk)) return 0;                  // আজ ওয়াক্ত বাদ/কাজা — ধারা ভেঙেছে
    k = keyAdd(k, -1);                            // আজ এখনো চলছে — গতকাল পর্যন্ত ধারা ধরে রাখা হয়
  }
  let n = 0;
  while(dayFull(k, needJamaat) && n < 4000){ n++; k = keyAdd(k, -1); }
  return n;
}
function streakBest(needJamaat){
  const ks = Object.keys(STATE.days).sort();
  let run = 0, best = 0, prev = null;
  ks.forEach(k=>{
    if(!dayFull(k, needJamaat)){ run = 0; prev = null; return; }
    run = (prev && keyAdd(prev, 1)===k) ? run+1 : 1;
    prev = k; if(run>best) best = run;
  });
  return best;
}
function renderStreak(){
  const card = document.getElementById('streakCard'); if(!card) return;
  const tk = dateKey(today);
  const n = streakNow(false), nj = streakNow(true);
  const best = Math.max(streakBest(false), n);
  document.getElementById('skNow').textContent = toBn(n);
  document.getElementById('skBest').textContent = toBn(best);
  document.getElementById('skJam').textContent = toBn(nj)+' দিন';
  card.classList.toggle('off', n===0);
  // এ মাসের পূর্ণ দিন
  let monthFull = 0;
  for(let d=1; d<=today.getDate(); d++){ if(dayFull(dateKey(new Date(today.getFullYear(), today.getMonth(), d)), false)) monthFull++; }
  document.getElementById('skMon').textContent = toBn(monthFull)+'/'+toBn(today.getDate());
  // গত ৭ দিনের বৃত্ত
  let dots = '';
  for(let i=6; i>=0; i--){
    const k = keyAdd(tk, -i), p = k.split('-').map(Number), wd = new Date(p[0], p[1]-1, p[2]).getDay();
    const full = dayFull(k, false), cnt = dayDoneCount(k);
    const cls = full ? 'full' : (cnt>0 ? 'part' : 'none');
    dots += '<div class="sk-d '+cls+(k===tk?' now':'')+'"><span class="sk-c">'+(full ? TICK : (cnt>0 ? toBn(cnt) : ''))+'</span><span class="sk-w">'+WD_SHORT[wd]+'</span></div>';
  }
  document.getElementById('skWeek').innerHTML = dots;
  // আজকের বার্তা
  const msg = document.getElementById('skMsg');
  const doneToday = dayDoneCount(tk);
  if(dayFull(tk, false)){ msg.textContent = 'আজকের পাঁচ ওয়াক্তই পূর্ণ — মাশাআল্লাহ'; msg.className = 'sk-msg ok'; }
  else if(dayHasLoss(tk)){ msg.textContent = 'আজ একটি ওয়াক্ত বাদ/কাজা — আজকের ধারা ভেঙেছে। কাল নতুন করে শুরু করুন, ইনশাআল্লাহ।'; msg.className = 'sk-msg warn'; }
  else if(n>0){ msg.textContent = 'আজ আর '+toBn(5-doneToday)+' ওয়াক্ত বাকি — ধারা ধরে রাখুন'; msg.className = 'sk-msg'; }
  else { msg.textContent = 'আজ পাঁচ ওয়াক্ত পূর্ণ করে নতুন ধারা শুরু করুন'; msg.className = 'sk-msg'; }
  // পরের মাইলফলক
  const nm = MILESTONES.find(m=> m>n);
  document.getElementById('skBar').style.width = (nm ? Math.min(100, n/nm*100) : 100)+'%';
  document.getElementById('skNext').textContent = nm ? 'পরের মাইলফলক: '+toBn(nm)+' দিন (আর '+toBn(nm-n)+' দিন)' : 'মাশাআল্লাহ! সব মাইলফলক পার করেছেন';
}

/* ---------- কাজা নামাজ ট্র্যাকার ----------
   বাকি কাজা (প্রতি ওয়াক্তে) = প্রাথমিক জমা (base, ইউজারের দেওয়া) + আমলের রিপোর্টে "পড়িনি" (missed) দেওয়া দিনের সংখ্যা − আদায় (paid)।
   রিপোর্টে "পড়িনি" দিলে কাজা আপনা-আপনি বাড়ে, বদলালে আবার কমে — তাই আলাদা করে মেলানোর ঝামেলা নেই।
   STATE.qaza = { base:{ওয়াক্ত:সংখ্যা}, paid:{ওয়াক্ত:সংখ্যা}, log:[{t,d,id,n}] }  (ব্যাকআপ ও ইম্পোর্টেও যায়) */
const QZ_IDS = ['fajr','midday','asr','maghrib','isha','witr'];
const QZ_LABEL = {fajr:'ফজর', midday:'যোহর / জুমা', asr:'আসর', maghrib:'মাগরিব', isha:'এশা', witr:'বিতর'};
function qz(){
  if(!STATE.qaza || typeof STATE.qaza!=='object') STATE.qaza = {base:{}, paid:{}, log:[]};
  if(!STATE.qaza.base || typeof STATE.qaza.base!=='object') STATE.qaza.base = {};
  if(!STATE.qaza.paid || typeof STATE.qaza.paid!=='object') STATE.qaza.paid = {};
  if(!Array.isArray(STATE.qaza.log)) STATE.qaza.log = [];
  return STATE.qaza;
}
function fmtN(n){ return toBn(String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',')); }
function qzMissed(id){ let n = 0; const d = STATE.days || {}; for(const k in d){ if(d[k] && d[k][id]==='missed') n++; } return n; }
function qzBase(id){ return Math.max(0, parseInt(qz().base[id], 10) || 0); }
function qzOwed(id){ return qzBase(id) + qzMissed(id); }
function qzPaid(id){ return Math.max(0, parseInt(qz().paid[id], 10) || 0); }
function qzLeft(id){ return Math.max(0, qzOwed(id) - qzPaid(id)); }
function qzTotals(){
  let left = 0, owed = 0, paid = 0;
  QZ_IDS.forEach(id=>{ left += qzLeft(id); owed += qzOwed(id); paid += Math.min(qzPaid(id), qzOwed(id)); });
  return {left, owed, paid};
}
function qzPace(){                                    // গত ১৪ দিনে দিনে গড়ে কত ওয়াক্ত আদায়
  const lim = Date.now() - 14*86400000; let s = 0;
  qz().log.forEach(e=>{ if(e && e.t >= lim) s += (e.n || 0); });
  return Math.max(0, s) / 14;
}
function qzSpan(days){
  days = Math.max(1, Math.ceil(days));
  if(days < 30) return toBn(days)+' দিন';
  const y = Math.floor(days/365), m = Math.floor((days%365)/30);
  return ((y? toBn(y)+' বছর ' : '') + (m? toBn(m)+' মাস' : '')).trim() || (toBn(y||1)+' বছর');
}
function qzPay(id, n){
  const q = qz();
  if(n > 0){ if(qzLeft(id) <= 0) return false; q.paid[id] = qzPaid(id) + 1; }
  else { if(qzPaid(id) <= 0) return false; q.paid[id] = qzPaid(id) - 1; }
  q.log.push({t:Date.now(), d:dateKey(new Date()), id, n: n > 0 ? 1 : -1});
  if(q.log.length > 200) q.log = q.log.slice(-200);
  persist();
  return true;
}

/* ---- হোমের কার্ড ---- */
function renderQazaCard(){
  const body = document.getElementById('qzCardBody'); if(!body) return;
  const t = qzTotals(), hasAny = t.owed > 0 || QZ_IDS.some(id=> qzPaid(id) > 0);
  const sub = document.getElementById('qzSub');
  if(!hasAny){
    sub.textContent = 'কত ওয়াক্ত বাকি, কতটা আদায় হলো';
    body.innerHTML = '<p class="qz-empty">কাজা নামাজ থাকলে এখানে হিসাব রাখুন। আদায় করার সাথে সাথে সংখ্যা কমতে থাকবে, আর আমলের রিপোর্টে "পড়িনি" দিলে কাজা আপনা-আপনি যোগ হবে।</p>' +
      '<button type="button" class="qz-btn pri" data-qz="open">হিসাব শুরু করুন</button>';
    return;
  }
  if(t.left === 0){
    sub.textContent = 'আলহামদুলিল্লাহ';
    body.innerHTML = '<div class="qz-done"><b>মাশাআল্লাহ!</b><span>সব কাজা আদায় হয়েছে — আল্লাহ কবুল করুন।</span></div>' +
      '<button type="button" class="qz-btn" data-qz="open">বিস্তারিত দেখুন</button>';
    return;
  }
  const pct = t.owed ? Math.min(100, t.paid / t.owed * 100) : 0;
  sub.textContent = 'আদায় '+fmtN(t.paid)+' / '+fmtN(t.owed)+' ওয়াক্ত';
  let chips = '';
  QZ_IDS.forEach(id=>{ const l = qzLeft(id); if(l > 0) chips += '<span class="qz-chip"><i>'+QZ_LABEL[id].split(' ')[0]+'</i><b>'+fmtN(l)+'</b></span>'; });
  body.innerHTML =
    '<div class="qz-left"><b>'+fmtN(t.left)+'</b><span>ওয়াক্ত বাকি</span></div>' +
    '<div class="qz-bar"><u style="width:'+pct+'%"></u></div>' +
    '<div class="qz-chips">'+chips+'</div>' +
    '<div class="qz-acts"><button type="button" class="qz-btn pri" data-qz="open">আদায় করলাম</button></div>';
}

/* ---- কাজার পূর্ণ-পর্দা শিট ---- */
let qzIsOpen = false, qzDraft = {}, qzClearArm = 0, qzMsgT = 0;
function qzMsg(text){
  const m = document.getElementById('qzMsg'); if(!m) return;
  m.textContent = text; m.classList.add('show');
  clearTimeout(qzMsgT); qzMsgT = setTimeout(()=> m.classList.remove('show'), 2000);
}
function qzCaptureDraft(){
  document.querySelectorAll('#qazaBody [data-qz-base]').forEach(inp=>{ qzDraft[inp.getAttribute('data-qz-base')] = inp.value; });
  ['qzY','qzM','qzD'].forEach(i=>{ const e = document.getElementById(i); if(e) qzDraft[i] = e.value; });
}
function renderQazaSheet(){
  const body = document.getElementById('qazaBody'); if(!body) return;
  const top = body.scrollTop, t = qzTotals(), q = qz();
  const pct = t.owed ? Math.min(100, t.paid / t.owed * 100) : 0;
  let h = '<div class="qz-msg" id="qzMsg" role="status"></div>';
  // সারসংক্ষেপ
  h += '<div class="qz-sum"><div class="qz-sum-l"><b>'+fmtN(t.left)+'</b><span>ওয়াক্ত বাকি</span></div>' +
       '<div class="qz-sum-r"><small>আদায়</small><b>'+fmtN(t.paid)+'</b></div></div>' +
       '<div class="qz-bar big"><u style="width:'+pct+'%"></u></div>';
  const maxLeft = Math.max.apply(null, QZ_IDS.map(qzLeft));
  if(t.left > 0){
    h += '<p class="qz-eta">প্রতিদিন এক দিনের কাজা (সব ওয়াক্ত একটি করে) আদায় করলে আনুমানিক <b>'+qzSpan(maxLeft)+'</b>-এ শেষ হবে।';
    const pace = qzPace();
    if(pace > 0){
      const need = t.left / pace;
      h += need > 18250
        ? '<br>এই গতিতে শেষ হতে অনেক সময় লাগবে — প্রতিদিন একটু বাড়িয়ে নিন, ইনশাআল্লাহ সহজ হয়ে যাবে।'
        : '<br>আপনার গতিতে (দিনে গড়ে '+toBn((Math.round(pace*10)/10).toString())+' ওয়াক্ত) আনুমানিক <b>'+qzSpan(need)+'</b>।';
    }
    h += '</p>';
  } else if(t.owed > 0){
    h += '<p class="qz-eta ok">মাশাআল্লাহ! সব কাজা আদায় হয়েছে।</p>';
  }
  // আদায়
  h += '<div class="qz-h">আদায় করুন</div>';
  if(t.left > 0){
    h += '<button type="button" class="qz-btn pri wide" data-qz="payall">এক দিনের সব (একটি করে) আদায় করলাম</button>';
  }
  h += '<div class="qz-rows">';
  QZ_IDS.forEach(id=>{
    const l = qzLeft(id), o = qzOwed(id);
    h += '<div class="qz-row"><div class="qz-rl"><b>'+QZ_LABEL[id]+'</b><small>'+(o ? 'আদায় '+fmtN(Math.min(qzPaid(id),o))+' / '+fmtN(o) : 'কাজা নেই')+'</small></div>' +
         '<div class="qz-rn'+(l? '' : ' zero')+'">'+fmtN(l)+'</div>' +
         '<button type="button" class="qz-un" data-qz="unpay" data-id="'+id+'" aria-label="একটি আদায় ফিরিয়ে নিন"'+(qzPaid(id)>0? '' : ' disabled')+'>−</button>' +
         '<button type="button" class="qz-pay" data-qz="pay" data-id="'+id+'"'+(l? '' : ' disabled')+'>আদায় '+TICK+'</button></div>';
  });
  h += '</div>';
  // হিসাব সেট/বদল
  h += '<div class="qz-h">হিসাব ঠিক করুন</div><p class="qz-note">আগের জমে থাকা কাজা (আমলের রিপোর্টের বাইরের) প্রতি ওয়াক্তে কত, তা লিখুন। রিপোর্টে "পড়িনি" দেওয়া ওয়াক্ত এর সাথে আপনা-আপনি যোগ হয়।</p>';
  h += '<div class="qz-calc"><div class="qz-calc-t">বছর-মাস থেকে হিসাব</div><div class="qz-calc-r">' +
       '<label><input type="number" inputmode="numeric" min="0" max="99" id="qzY" placeholder="০" value="'+(qzDraft.qzY||'')+'"><span>বছর</span></label>' +
       '<label><input type="number" inputmode="numeric" min="0" max="11" id="qzM" placeholder="০" value="'+(qzDraft.qzM||'')+'"><span>মাস</span></label>' +
       '<label><input type="number" inputmode="numeric" min="0" max="29" id="qzD" placeholder="০" value="'+(qzDraft.qzD||'')+'"><span>দিন</span></label>' +
       '<button type="button" class="qz-btn" data-qz="calc">হিসাব করুন</button></div>' +
       '<small>প্রতি ওয়াক্তের (বিতরসহ) জন্য দিনের সংখ্যা বসে যাবে। বছর = ৩৬৫ দিন, মাস = ৩০ দিন ধরা হয়।</small></div>';
  h += '<div class="qz-base">';
  QZ_IDS.forEach(id=>{
    const v = (qzDraft[id] !== undefined) ? qzDraft[id] : (qzBase(id) || '');
    h += '<label class="qz-bf"><span>'+QZ_LABEL[id]+'</span><input type="number" inputmode="numeric" min="0" max="99999" data-qz-base="'+id+'" placeholder="০" value="'+v+'"></label>';
  });
  h += '</div><button type="button" class="qz-btn pri wide" data-qz="save">সংরক্ষণ করুন</button>';
  const auto = QZ_IDS.filter(id=> qzMissed(id) > 0).map(id=> QZ_LABEL[id].split(' ')[0]+' '+fmtN(qzMissed(id)));
  if(auto.length) h += '<p class="qz-note">রিপোর্ট থেকে আপনা-আপনি যোগ হয়েছে: '+auto.join(' · ')+'</p>';
  // ইতিহাস
  const log = q.log.slice(-12).reverse();
  h += '<div class="qz-h">সাম্প্রতিক আদায়</div>';
  if(!log.length) h += '<p class="qz-note">এখনো কোনো আদায় লেখা হয়নি।</p>';
  else {
    h += '<div class="qz-log">';
    log.forEach(e=>{
      const dp = (e.d || '').split('-'), ds = dp.length===3 ? toBn(parseInt(dp[2],10))+' '+['জানু','ফেব্রু','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টে','অক্টো','নভে','ডিসে'][parseInt(dp[1],10)-1] : '';
      h += '<div class="qz-lr"><span>'+ds+'</span><b>'+(QZ_LABEL[e.id]||e.id).split(' ')[0]+'</b><em class="'+(e.n>0?'plus':'minus')+'">'+(e.n>0? '+১ আদায়' : '−১ ফেরত')+'</em></div>';
    });
    h += '</div>';
  }
  h += '<button type="button" class="qz-clear" data-qz="clear">কাজার সব হিসাব মুছুন</button>';
  body.innerHTML = h;
  body.scrollTop = top;
}
function openQaza(){
  if(qzIsOpen) return;
  qzIsOpen = true; qzDraft = {};
  try{ history.pushState({qazaSheet:true}, '', location.href); }catch(e){}
  document.getElementById('qazaOverlay').classList.add('show');
  renderQazaSheet();
  const b = document.getElementById('qazaBody'); if(b) b.scrollTop = 0;
}
function hideQaza(){
  if(!qzIsOpen) return;
  qzIsOpen = false; qzDraft = {};
  document.getElementById('qazaOverlay').classList.remove('show');
  renderHome();
}
function closeQaza(){
  if(!qzIsOpen) return;
  if(history.state && history.state.qazaSheet) history.back(); else hideQaza();
}
window.addEventListener('popstate', ()=>{ if(qzIsOpen) hideQaza(); });
function qzAfterChange(){ qzCaptureDraft(); renderQazaSheet(); }
document.addEventListener('click', (e)=>{
  const el = e.target.closest ? e.target.closest('[data-qz]') : null; if(!el) return;
  const act = el.getAttribute('data-qz'), id = el.getAttribute('data-id');
  if(act === 'open'){ openQaza(); return; }
  if(act === 'pay'){ if(qzPay(id, 1)){ qzCaptureDraft(); renderQazaSheet(); renderQazaCard(); if(qzTotals().left === 0) qzMsg('মাশাআল্লাহ! সব কাজা আদায় হয়েছে'); else qzMsg(QZ_LABEL[id].split(' ')[0]+' আদায় লেখা হলো'); } return; }
  if(act === 'unpay'){ if(qzPay(id, -1)){ qzCaptureDraft(); renderQazaSheet(); renderQazaCard(); qzMsg(QZ_LABEL[id].split(' ')[0]+': একটি ফিরিয়ে নেওয়া হলো'); } return; }
  if(act === 'payall'){
    let n = 0; QZ_IDS.forEach(i=>{ if(qzPay(i, 1)) n++; });
    qzCaptureDraft(); renderQazaSheet(); renderQazaCard();
    qzMsg(n ? toBn(n)+' ওয়াক্ত আদায় লেখা হলো' : 'আদায়ের মতো কাজা নেই');
    return;
  }
  if(act === 'calc'){
    const num = (i)=> Math.max(0, parseInt(document.getElementById(i).value, 10) || 0);
    const days = num('qzY')*365 + num('qzM')*30 + num('qzD');
    if(!days){ qzMsg('বছর, মাস বা দিন লিখুন'); return; }
    QZ_IDS.forEach(i=>{ qzDraft[i] = String(days); });
    qzCaptureDraft(); QZ_IDS.forEach(i=>{ qzDraft[i] = String(days); });
    renderQazaSheet(); qzMsg('প্রতি ওয়াক্তে '+toBn(days)+' দিন বসেছে — "সংরক্ষণ করুন" চাপুন');
    return;
  }
  if(act === 'save'){
    const q = qz();
    document.querySelectorAll('#qazaBody [data-qz-base]').forEach(inp=>{
      const v = Math.min(99999, Math.max(0, parseInt(inp.value, 10) || 0));
      q.base[inp.getAttribute('data-qz-base')] = v;
    });
    qzDraft = {}; persist(); renderQazaSheet(); renderQazaCard(); qzMsg('হিসাব সংরক্ষিত হয়েছে');
    return;
  }
  if(act === 'clear'){
    if(!qzClearArm){
      el.textContent = 'নিশ্চিত করতে আবার চাপুন'; el.classList.add('arm');
      qzClearArm = setTimeout(()=>{ qzClearArm = 0; el.textContent = 'কাজার সব হিসাব মুছুন'; el.classList.remove('arm'); }, 3500);
    } else {
      clearTimeout(qzClearArm); qzClearArm = 0;
      STATE.qaza = {base:{}, paid:{}, log:[]}; qzDraft = {}; persist(); renderQazaSheet(); renderQazaCard(); qzMsg('কাজার হিসাব মুছে ফেলা হয়েছে');
    }
  }
});
on('qazaCloseBtn', 'click', closeQaza);

function renderHome(){
  renderHeaderDate();
  renderHero();
  renderStreak();
  renderQazaCard();
  renderCustomAmalList();
  renderMonthlySummary();
  renderSyncCard(true);
}

/* ================= FLOW ================= */
function buildFlowQueue(dKey){
  const d = new Date(dKey+'T00:00:00');
  const slots = getDaySlots(d);
  const rec = getDayRecord(dKey);
  return slots.filter(s=> !rec[s.id]);
}

/* ---------- back-navigation (in-app button + real browser/hardware back) ----------
   flowScreenStack remembers every screen the person has moved forward from inside
   the current flow session, so both the on-screen back arrow and the device's own
   back button can undo one step at a time. A single "trap" history entry is kept
   armed while any overlay is open; the trap is re-armed after every step-back so
   repeated back presses keep being caught until there's nothing left to undo. */
let flowScreenStack = [];
let navTrapArmed = false;
let intentionalNavClose = false;

function isFlowOpen(){ const el=document.getElementById('flowOverlay'); return !!(el && el.classList.contains('show')); }
function isSheetOpen(){ const el=document.getElementById('sheetOverlay'); return !!(el && el.classList.contains('show')); }

function armNavTrap(){
  try{ history.pushState({amolNav:true, t:Date.now()}, '', location.href); navTrapArmed = true; }
  catch(e){ navTrapArmed = false; }
}
function updateFlowBackBtn(){
  const btn = document.getElementById('flowBackBtn');
  if(!btn) return;
  btn.style.display = flowScreenStack.length>0 ? 'flex' : 'none';
}
/* Pushes an undo point for the screen being left, then renders the next one. */
function goForward(desc, renderFn){
  flowScreenStack.push(desc);
  renderFn();
  updateFlowBackBtn();
}
/* Re-renders a screen popped off the undo stack — never pushes anything itself. */
function renderDescriptor(desc){
  const item = flowQueue[desc.index];
  flowIndex = desc.index;
  if(!item){ renderFlowStep(); return; }
  if(desc.type==='ask'){
    setFlowTint('flow-tint-neutral');
    if(item.type==='fard') renderFardAsk(item); else renderSimpleAsk(item);
  } else if(desc.type==='congrats'){
    renderCongrats(item);
  } else if(desc.type==='subResult'){
    renderSubResult(item, desc.kind);
  } else if(desc.type==='missedResult'){
    renderMissedResult(item);
  } else {
    renderFlowStep();
  }
}
function hideFlowOverlayOnly(){ document.getElementById('flowOverlay').classList.remove('show'); }
function hideSheetOverlayOnly(){
  document.getElementById('sheetOverlay').classList.remove('show');
  const pop = document.getElementById('popMask'); if(pop) pop.classList.remove('show');
}
/* The in-app arrow acts immediately (no waiting on the browser's async
   popstate round-trip, which can feel unresponsive on some phones). It
   still nudges history back to keep the hardware/browser back button in
   sync — suppressNextPopstate stops that resulting popstate from acting
   a second time. */
let suppressNextPopstate = false;
on('flowBackBtn', 'click', ()=>{
  if(flowScreenStack.length===0) return;
  const desc = flowScreenStack.pop();
  renderDescriptor(desc);
  updateFlowBackBtn();
  if(navTrapArmed){
    suppressNextPopstate = true;
    try{ history.back(); }catch(e){ suppressNextPopstate = false; }
    setTimeout(()=>{ if(suppressNextPopstate){ suppressNextPopstate = false; armNavTrap(); } }, 700);
  }
});

window.addEventListener('popstate', function(){
  if(suppressNextPopstate){
    suppressNextPopstate = false;
    armNavTrap();
    return;
  }
  if(intentionalNavClose){
    intentionalNavClose = false;
    navTrapArmed = false;
    if(isFlowOpen()){ hideFlowOverlayOnly(); flowScreenStack = []; }
    if(isSheetOpen()){ hideSheetOverlayOnly(); }
    renderHome();
    return;
  }
  if(isFlowOpen()){
    if(flowScreenStack.length>0){
      const desc = flowScreenStack.pop();
      renderDescriptor(desc);
      updateFlowBackBtn();
      armNavTrap();
    } else {
      navTrapArmed = false;
      hideFlowOverlayOnly();
      renderHome();
    }
    return;
  }
  if(isSheetOpen()){
    navTrapArmed = false;
    hideSheetOverlayOnly();
    return;
  }
});

function openFlow(dKey, forceAll){
  flowDateKey = dKey;
  const d = new Date(dKey+'T00:00:00');
  flowQueue = forceAll ? getDaySlots(d) : buildFlowQueue(dKey);
  flowIndex = 0;
  flowResults = {};
  flowScreenStack = [];
  document.getElementById('flowOverlay').classList.add('show');
  renderFlowStep();
  updateFlowBackBtn();
  armNavTrap();
}
function closeFlow(opts){
  opts = opts || {};
  if(opts.silent){
    hideFlowOverlayOnly();
    flowScreenStack = [];
    renderHome();
    return;
  }
  if(navTrapArmed){
    intentionalNavClose = true;
    history.back();
  } else {
    hideFlowOverlayOnly();
    flowScreenStack = [];
    renderHome();
  }
}
on('flowCloseBtn', 'click', ()=> closeFlow());
on('startFlowBtn', 'click', ()=> openFlow(dateKey(today), false));
on('editTodayBtn', 'click', ()=> openFlow(dateKey(today), true));

function setFlowTint(cls){
  const inner = document.getElementById('flowInner');
  inner.className = 'flow-inner ' + cls;
}
function updateFlowChrome(){
  const total = flowQueue.length;
  const pct = total? Math.round((flowIndex/total)*100) : 100;
  document.getElementById('flowProgressBar').style.transform = 'scaleX('+(pct/100)+')';
  document.getElementById('flowCount').textContent = toBn(Math.min(flowIndex,total))+'/'+toBn(total);
}
function sparkleBurstHTML(colorVar){
  let html = '<div class="sparkle-burst">';
  const n = 8;
  for(let i=0;i<n;i++){
    const angle = (Math.PI*2/n)*i;
    const dist = 34 + (i%2)*8;
    const dx = Math.round(Math.cos(angle)*dist);
    const dy = Math.round(Math.sin(angle)*dist);
    html += `<span style="--dx:${dx}px;--dy:${dy}px; background:${colorVar}; animation-delay:${i*22}ms;"></span>`;
  }
  html += '</div>';
  return html;
}
/* Cross-fades the flow body between steps; onReady binds listeners on the freshly-inserted markup. */
function setFlowBodyContent(html, onReady){
  const body = document.getElementById('flowBody');
  body.classList.remove('fx-in');
  body.classList.add('fx-out');
  setTimeout(()=>{
    body.innerHTML = html;
    body.classList.remove('fx-out');
    void body.offsetWidth; // restart animation
    body.classList.add('fx-in');
    try{ if(onReady) onReady(); }catch(err){ console.error('[amol] render bind error', err); }
    setTimeout(()=> body.classList.remove('fx-in'), 460);
  }, 130);
}

function renderFlowStep(){
  updateFlowChrome();
  if(flowIndex >= flowQueue.length){
    setFlowTint('flow-tint-neutral');
    renderFlowDone();
    return;
  }
  const item = flowQueue[flowIndex];
  if(item.type==='fard'){
    setFlowTint('flow-tint-neutral');
    renderFardAsk(item);
  } else {
    setFlowTint('flow-tint-neutral');
    renderSimpleAsk(item);
  }
}

function renderFardAsk(item){
  const html = `
    <div class="flow-label">${ICONS.clipboard.replace('<svg ', '<svg class="lbl-ico" ')}নামাজের রিপোর্ট</div>
    <div class="flow-prayer-name">${item.label}</div>
    <div class="choice-grid">
      <button type="button" class="choice-btn pos rippleable" id="btnPrayed">
        <span class="ico">${ICONS.check}</span>
        নামাজ পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
      <button type="button" class="choice-btn neg rippleable" id="btnNotPrayed">
        <span class="ico">${ICONS.cross}</span>
        নামাজ পড়িনি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    on('btnPrayed', 'click', ()=>{
      SoundFX.tick();
      goForward({type:'ask', index:flowIndex}, ()=> renderCongrats(item));
    });
    on('btnNotPrayed', 'click', ()=>{
      setDayRecord(flowDateKey, item.id, 'missed');
      SoundFX.miss();
      goForward({type:'ask', index:flowIndex}, ()=> renderMissedResult(item));
    });
  });
}

function seedFor(item){
  // rotate through pools deterministically by date + slot, so it doesn't repeat every day
  const d = new Date(flowDateKey+'T00:00:00');
  return d.getDate() + item.id.length;
}

function renderCongrats(item){
  setFlowTint('flow-tint-green');
  const q = pickQuote(POOL_CONGRATS, seedFor(item));
  const html = `
    <div class="result-panel">
      <div class="result-badge-wrap">
        <div class="result-badge g">${ICONS.check}</div>
        ${sparkleBurstHTML('var(--green)')}
      </div>
      <div class="result-title">আলহামদুলিল্লাহ!</div>
      <div class="result-sub">${item.label} আদায় করেছেন — সুসংবাদ গ্রহণ করুন</div>
    </div>
    <div class="quote-card">
      <span class="quote-kind">${q.kind} • ${q.ref}</span>
      <div class="quote-text">${q.text}</div>
    </div>
    <div class="flow-label" style="margin-top:24px;">কীভাবে আদায় করেছেন?</div>
    <div class="choice-grid" style="margin-top:10px;">
      <button type="button" class="choice-btn pos rippleable" id="btnJamaat">
        <span class="ico">${ICONS.jamaat}</span>
        জামাতে পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
      <button type="button" class="choice-btn mid rippleable" id="btnAlone">
        <span class="ico">${ICONS.alone}</span>
        একাকী পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
      <button type="button" class="choice-btn warn rippleable" id="btnQaza">
        <span class="ico">${ICONS.qaza}</span>
        কাজা পড়েছি
        <span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></span>
      </button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    SoundFX.success();
    on('btnJamaat', 'click', ()=>{ setDayRecord(flowDateKey,item.id,'jamaat'); goForward({type:'congrats', index:flowIndex}, ()=> renderSubResult(item,'jamaat')); });
    on('btnAlone', 'click', ()=>{ setDayRecord(flowDateKey,item.id,'alone'); goForward({type:'congrats', index:flowIndex}, ()=> renderSubResult(item,'alone')); });
    on('btnQaza', 'click', ()=>{ setDayRecord(flowDateKey,item.id,'qaza'); goForward({type:'congrats', index:flowIndex}, ()=> renderSubResult(item,'qaza')); });
  });
}

function renderSubResult(item, kind){
  let pool, tint, badgeClass, title, icon, sound, sparkle;
  if(kind==='jamaat'){ pool=POOL_JAMAAT; tint='flow-tint-green'; badgeClass='g'; title='জাযাকাল্লাহু খাইরান!'; icon=ICONS.jamaat; sound='jamaat'; sparkle=true; }
  else if(kind==='alone'){ pool=POOL_ALONE; tint='flow-tint-neutral'; badgeClass='a'; title='জাযাকাল্লাহু খাইরান'; icon=ICONS.alone; sound='success'; sparkle=false; }
  else { pool=POOL_QAZA; tint='flow-tint-amber'; badgeClass='a'; title='জাযাকাল্লাহু খাইরান'; icon=ICONS.qaza; sound='soft'; sparkle=false; }
  setFlowTint(tint);
  const q = pickQuote(pool, seedFor(item)+1);
  const subMsg = kind==='jamaat' ? 'জামাতে আদায়ের ফজিলত অর্জন করেছেন'
    : kind==='alone' ? 'পরবর্তীতে জামাতে শামিল হওয়ার চেষ্টা রাখুন'
    : 'সময়মতো আদায়ের প্রতি যত্নশীল হওয়ার চেষ্টা করুন';
  const html = `
    <div class="result-panel">
      <div class="result-badge-wrap">
        <div class="result-badge ${badgeClass}">${icon}</div>
        ${sparkle ? sparkleBurstHTML('var(--green)') : ''}
      </div>
      <div class="result-title">${title}</div>
      <div class="result-sub">${subMsg}</div>
    </div>
    <div class="quote-card">
      <span class="quote-kind">${q.kind} • ${q.ref}</span>
      <div class="quote-text">${q.text}</div>
    </div>
    <div class="flow-cta">
      <button type="button" class="btn-block rippleable" id="btnContinue">চালিয়ে যান</button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    SoundFX[sound]();
    on('btnContinue', 'click', ()=> goForward({type:'subResult', index:flowIndex, kind}, nextFlowStep));
  });
}

function renderMissedResult(item){
  setFlowTint('flow-tint-red');
  const q = pickQuote(POOL_MISSED, seedFor(item));
  const html = `
    <div class="result-panel shake">
      <div class="result-badge-wrap">
        <div class="result-badge r">${ICONS.cross}</div>
      </div>
      <div class="result-title">জাযাকাল্লাহু খাইরান</div>
      <div class="result-sub">পরের ওয়াক্ত সময়মতো আদায়ের নিয়ত রাখুন, ইনশাআল্লাহ</div>
    </div>
    <div class="quote-card">
      <span class="quote-kind">${q.kind} • ${q.ref}</span>
      <div class="quote-text">${q.text}</div>
    </div>
    <div class="flow-cta">
      <button type="button" class="btn-block rippleable" id="btnContinue">চালিয়ে যান</button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    on('btnContinue', 'click', ()=> goForward({type:'missedResult', index:flowIndex}, nextFlowStep));
  });
}

function renderSimpleAsk(item){
  const isSunnah = item.type==='sunnah';
  const yesWord = isSunnah ? 'পড়েছি' : 'করেছি';
  const noWord = isSunnah ? 'পড়িনি' : 'করিনি';
  const labelIcon = isSunnah ? ICONS.moon.replace('<svg ', '<svg class="lbl-ico" ') : ICONS.sparkleStar.replace('<svg ', '<svg class="lbl-ico" ');
  const html = `
    <div class="flow-label">${labelIcon}${isSunnah ? 'সুন্নত' : 'নিজস্ব আমল'}</div>
    <div class="flow-prayer-name">${item.label}</div>
    <div class="simple-toggle">
      <button type="button" class="yes rippleable" id="btnYes"><span class="t-ico">${ICONS.check}</span>${yesWord}</button>
      <button type="button" class="no rippleable" id="btnNo"><span class="t-ico">${ICONS.cross}</span>${noWord}</button>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    on('btnYes','click', ()=>{
      setDayRecord(flowDateKey, item.id, 'done');
      SoundFX.success();
      setFlowTint('flow-tint-green');
      setTimeout(()=> goForward({type:'ask', index:flowIndex}, nextFlowStep), 420);
    });
    on('btnNo','click', (e)=>{
      setDayRecord(flowDateKey, item.id, 'missed');
      SoundFX.miss();
      setFlowTint('flow-tint-red');
      const btn = document.getElementById('btnNo');
      if(btn){ btn.style.animation='shakeSm .4s ease'; }
      setTimeout(()=> goForward({type:'ask', index:flowIndex}, nextFlowStep), 420);
    });
  });
}

function nextFlowStep(){
  flowIndex++;
  renderFlowStep();
}

function renderFlowDone(){
  const d = new Date(flowDateKey+'T00:00:00');
  const rec = getDayRecord(flowDateKey);
  const slots = getDaySlots(d);
  let jamaat=0, alone=0, qaza=0, missed=0, sunnahDone=0;
  slots.forEach(s=>{
    const v = rec[s.id];
    if(s.type==='fard'){
      if(v==='jamaat') jamaat++;
      else if(v==='alone') alone++;
      else if(v==='qaza') qaza++;
      else if(v==='missed') missed++;
    } else if(v==='done'){ sunnahDone++; }
  });
  const html = `
    <div class="done-screen">
      <div class="big-badge">${ICONS.check}</div>
      <h2>আজকের আমল সম্পন্ন</h2>
      <p>আজকের রিপোর্ট সংরক্ষণ করা হয়েছে। আল্লাহ আপনার আমল কবুল করুন।</p>
      <div class="done-stats">
        <span class="done-pill">জামাত ${toBn(jamaat)}</span>
        <span class="done-pill">একাকী ${toBn(alone)}</span>
        <span class="done-pill">কাজা ${toBn(qaza)}</span>
        <span class="done-pill">ছুটেছে ${toBn(missed)}</span>
        <span class="done-pill">সুন্নত ${toBn(sunnahDone)}</span>
      </div>
      <div class="flow-cta" style="width:100%;">
        <button type="button" class="btn-block rippleable" id="btnSeeReport">মাসিক রিপোর্ট দেখুন</button>
        <button type="button" class="btn-block outline rippleable" id="btnBackHome" style="margin-top:10px;">হোমে ফিরুন</button>
      </div>
    </div>
  `;
  setFlowBodyContent(html, ()=>{
    SoundFX.complete();
    on('btnSeeReport', 'click', ()=>{ closeFlow({silent:true}); openSheet(); });
    on('btnBackHome', 'click', ()=> closeFlow());
  });
}

/* ================= SHEET / MONTHLY REPORT ================= */
function openSheet(){
  sheetMonthCursor = new Date(today.getFullYear(), today.getMonth(), 1);
  sheetOpenDay = dateKey(today);
  document.getElementById('sheetOverlay').classList.add('show');
  renderSheet();
  armNavTrap();
}
function closeSheet(){
  if(navTrapArmed){
    intentionalNavClose = true;
    history.back();
  } else {
    hideSheetOverlayOnly();
  }
}
on('openSheetBtn', 'click', openSheet);
on('sheetCloseBtn', 'click', closeSheet);
on('prevMonthBtn', 'click', ()=>{
  sheetMonthCursor = new Date(sheetMonthCursor.getFullYear(), sheetMonthCursor.getMonth()-1, 1);
  sheetOpenDay = null;
  renderSheet();
});
on('nextMonthBtn', 'click', ()=>{
  const nextC = new Date(sheetMonthCursor.getFullYear(), sheetMonthCursor.getMonth()+1, 1);
  if(nextC > new Date(today.getFullYear(), today.getMonth(), 1)) return;
  sheetMonthCursor = nextC;
  sheetOpenDay = (monthKey(nextC) === monthKey(today)) ? dateKey(today) : null;
  renderSheet();
});

/* ---------- v221: মাসিক হিসাব — নতুন, আধুনিক ও সহজ ডিজাইন ----------
   ১) ওপরে বড় রিং + গত মাসের সাথে তুলনা + তিনটি সংখ্যা   ২) মাসের ক্যালেন্ডার (রঙে দিনের অবস্থা, চাপলে সেই দিন খোলে)
   ৩) ওয়াক্তভিত্তিক তুলনা চার্ট   ৪) দৈনিক বিস্তারিত হিসাব: আজ থেকে পেছনে দিনের কার্ড — পাঁচ ওয়াক্তের বিন্দু একনজরে;
      চাপলে খুলে প্রতিটি আমলের অবস্থা সরাসরি বদলানো যায় (আলাদা পপআপ ছাড়াই; আবার চাপলে এন্ট্রি মুছে যায়)। */
let sheetOpenDay = null;
const WAQT5 = [['fajr','ফজর'],['midday','যোহর'],['asr','আসর'],['maghrib','মাগরিব'],['isha','এশা']];
const OPT_FARD = [['jamaat','জামাতে','g'],['alone','একাকী','b'],['qaza','কাজা','a'],['missed','পড়িনি','r']];
const OPT_NAFL = [['done','করেছি','g'],['missed','করিনি','r']];
const STATUS_CLS = {jamaat:'g', alone:'b', qaza:'a', missed:'r', done:'g'};
function monthExtra(y,m){
  const now = new Date(), isCur = (y===now.getFullYear() && m===now.getMonth());
  const upto = isCur ? now.getDate() : daysInMonth(y,m);
  let full=0, fardDone=0, jamaat=0;
  for(let d=1; d<=upto; d++){
    const key = dateKey(new Date(y,m,d)), rec = STATE.days[key] || {};
    const c = dayDoneCount(key); fardDone += c; if(c>=5) full++;
    FIVE_WAQT.forEach(id=>{ if(rec[id]==='jamaat') jamaat++; });
  }
  return {full, upto, fardDone, fardTotal: upto*5, jamaat, jamaatPct: fardDone ? Math.round(jamaat/fardDone*100) : 0};
}
function dotHtml(val, type){
  const cls = val ? (STATUS_CLS[val] || '') : '';
  let inner = '';
  if(val==='missed') inner = ICONS.cross; else if(val==='qaza') inner = '<i>ক</i>'; else if(val) inner = ICONS.check;
  return '<span class="dt '+(cls||'n')+'">'+inner+'</span>';
}
function daySummaryLine(d, rec){
  const slots = getDaySlots(d);
  let sn=0, snT=0, cu=0, cuT=0, witr='';
  slots.forEach(sl=>{
    if(sl.type==='sunnah'){ snT++; if(rec[sl.id]==='done') sn++; }
    else if(sl.type==='custom'){ cuT++; if(rec[sl.id]==='done') cu++; }
    else if(sl.id==='witr'){ witr = isPositive('fard', rec.witr) ? 'বিতর ✓' : (rec.witr ? 'বিতর ✕' : ''); }
  });
  const parts = [];
  if(Object.keys(rec).some(k=> rec[k])){
    parts.push('সুন্নত '+toBn(sn)+'/'+toBn(snT));
    if(witr) parts.push(witr);
    if(cuT) parts.push('নিজস্ব '+toBn(cu)+'/'+toBn(cuT));
    return parts.join(' · ');
  }
  return 'এখনো কোনো এন্ট্রি নেই';
}
function dayBodyHtml(key, d){
  const rec = getDayRecord(key), slots = getDaySlots(d), isFri = d.getDay()===5;
  const groups = [['ফরজ ও বিতর', s=>s.type==='fard'], ['সুন্নত', s=>s.type==='sunnah'], ['নিজস্ব আমল', s=>s.type==='custom']];
  let h = '<div class="dq"><button type="button" class="qa" data-qa="alljamaat" data-k="'+key+'">'+ICONS.jamaat+'পাঁচ ওয়াক্ত জামাতে</button>' +
          '<button type="button" class="qa ghost" data-qa="clear" data-k="'+key+'">'+ICONS.trash+'দিনের এন্ট্রি মুছুন</button></div>';
  groups.forEach(g=>{
    const list = slots.filter(g[1]); if(!list.length) return;
    h += '<div class="dg">'+g[0]+'</div>';
    list.forEach(sl=>{
      const cur = rec[sl.id], opts = sl.type==='fard' ? OPT_FARD : OPT_NAFL;
      h += '<div class="dr"><div class="dr-n">'+escapeHtml(sl.label)+'</div><div class="dr-o '+(sl.type==='fard'?'four':'two')+'">' +
        opts.map(o=> '<button type="button" class="ob '+o[2]+(cur===o[0]?' on':'')+'" data-k="'+key+'" data-id="'+sl.id+'" data-v="'+o[0]+'" aria-pressed="'+(cur===o[0])+'">'+o[1]+'</button>').join('') + '</div></div>';
    });
  });
  return h;
}
function dayCardHtml(key, d, isToday, open){
  const rec = getDayRecord(key), isFri = d.getDay()===5, cnt = dayDoneCount(key);
  const dots = WAQT5.map(w=> '<div class="dtc">'+dotHtml(rec[w[0]], 'fard')+'<small>'+(w[0]==='midday' && isFri ? 'জুমা' : w[1])+'</small></div>').join('');
  return '<article class="dc'+(open?' open':'')+(cnt>=5?' full':'')+'" data-k="'+key+'">' +
    '<button type="button" class="dc-head" data-k="'+key+'" aria-expanded="'+open+'">' +
      '<div class="dc-date"><b>'+toBn(d.getDate())+'</b><span>'+WD_SHORT[d.getDay()]+'</span></div>' +
      '<div class="dc-mid"><div class="dc-tags">'+(isToday?'<em class="tg now">আজ</em>':'')+(isFri?'<em class="tg jum">জুমা</em>':'')+'</div><div class="dc-dots">'+dots+'</div><div class="dc-cap">'+daySummaryLine(d, rec)+'</div></div>' +
      '<div class="dc-score"><b>'+toBn(cnt)+'</b><span>/৫</span></div>' +
      '<svg class="dc-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>' +
    '</button>' + (open ? '<div class="dc-body">'+dayBodyHtml(key, d)+'</div>' : '') + '</article>';
}
function calendarHtml(y, m){
  const dim = daysInMonth(y,m), first = new Date(y,m,1).getDay(), now = new Date(), tk = dateKey(now);
  let h = '<div class="cal-w">'+WD_SHORT.map(w=>'<span>'+w+'</span>').join('')+'</div><div class="cal-g">';
  for(let i=0;i<first;i++) h += '<i></i>';
  for(let day=1; day<=dim; day++){
    const d = new Date(y,m,day), key = dateKey(d), future = key > tk, cnt = dayDoneCount(key), rec = STATE.days[key] || {};
    const has = Object.keys(rec).some(k=>rec[k]), miss = FIVE_WAQT.some(id=> rec[id] && !isPositive('fard', rec[id]));
    let cls = future ? 'fut' : cnt>=5 ? 'full' : cnt>0 ? 'p'+cnt : (has ? 'p0' : 'none');
    if(miss && cnt<5 && !future) cls += ' loss';
    h += '<button type="button" class="cd '+cls+(key===tk?' now':'')+(key===sheetOpenDay?' sel':'')+'" data-k="'+key+'"'+(future?' disabled':'')+' aria-label="'+toBn(day)+' তারিখ, '+toBn(cnt)+'/৫"><b>'+toBn(day)+'</b></button>';
  }
  return h+'</div><div class="cal-k"><span><i class="k-full"></i>পাঁচ ওয়াক্তই</span><span><i class="k-p"></i>আংশিক</span><span><i class="k-loss"></i>ছুটেছে/কাজা</span><span><i class="k-none"></i>এন্ট্রি নেই</span></div>';
}
function renderSheet(){
  const body = document.getElementById('sheetBody'); if(!body) return;
  const keepScroll = body.scrollTop;
  document.getElementById('sheetMonthLabel').textContent = bnMonthLabel(sheetMonthCursor);
  const y = sheetMonthCursor.getFullYear(), m = sheetMonthCursor.getMonth();
  const now = new Date(), tk = dateKey(now), isCurMonth = (y===now.getFullYear() && m===now.getMonth());
  const cur = computeMonthStats(y,m), prevD = new Date(y, m-1, 1), prev = computeMonthStats(prevD.getFullYear(), prevD.getMonth());
  const delta = cur.pct - prev.pct, ex = monthExtra(y,m);
  if(sheetOpenDay && !(sheetOpenDay.slice(0,7) === monthKey(sheetMonthCursor) && sheetOpenDay <= tk)) sheetOpenDay = null;

  const C = 2*Math.PI*34, off = (C - C*Math.min(100,cur.pct)/100).toFixed(1);
  const dTxt = delta>0 ? 'গত মাসের চেয়ে '+toBn(delta)+'% বেশি' : delta<0 ? 'গত মাসের চেয়ে '+toBn(-delta)+'% কম' : 'গত মাসের সমান';
  let h = '<section class="sh-hero"><div class="sh-ring"><svg viewBox="0 0 80 80" aria-hidden="true"><defs><linearGradient id="shG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" class="g1"/><stop offset="1" class="g2"/></linearGradient></defs>' +
    '<circle cx="40" cy="40" r="34" class="rg-bg"/><circle cx="40" cy="40" r="34" class="rg-fg" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+off+'"/></svg><div class="sh-ring-t"><b>'+toBn(cur.pct)+'%</b></div></div>' +
    '<div class="sh-hero-t"><div class="sh-h1">এই মাসের অগ্রগতি</div><div class="sh-dl '+(delta>=0?'up':'down')+'">'+(delta>=0?'▲':'▼')+' '+dTxt+'</div><div class="sh-pv">গত মাস: '+toBn(prev.pct)+'%</div></div></section>' +
    '<section class="sh-kpis"><div><b>'+toBn(ex.full)+'</b><span>পূর্ণ দিন</span></div><div><b>'+toBn(ex.fardDone)+'<small>/'+toBn(ex.fardTotal)+'</small></b><span>ফরজ আদায়</span></div><div><b>'+toBn(ex.jamaatPct)+'%</b><span>জামাতে</span></div></section>' +
    '<button type="button" class="btn-block pdf-report-btn rippleable" id="pdfReportBtn">'+ICONS.pdf+' <span>এই মাসের PDF রিপোর্ট ডাউনলোড করুন</span></button>';

  h += '<section class="sh-sec"><h3>মাসের ক্যালেন্ডার</h3><p class="hint">যেকোনো দিনে চাপ দিলে নিচে সেই দিনের বিস্তারিত খুলবে</p>'+calendarHtml(y,m)+'</section>';

  const labels = FARD_GROUPS.map(g=>({key:g.key,label:g.label})).concat([{key:'sunnah',label:'সুন্নত (সার্বিক)'}]);
  let deltaRows = '';
  labels.forEach(g=>{
    const cv = g.key==='sunnah' ? cur.sunnahPct : cur.groupPct[g.key], pv = g.key==='sunnah' ? prev.sunnahPct : prev.groupPct[g.key], dd = cv-pv;
    deltaRows += '<div class="delta-row"><span class="name">'+g.label+'</span><span class="amt '+(dd>=0?'up':'down')+'">'+(dd>=0?'▲':'▼')+' '+toBn(Math.abs(dd))+'%</span></div>';
  });
  h += '<section class="sh-sec trend-card"><h3>ওয়াক্তভিত্তিক তুলনা</h3><p class="hint">এই মাস বনাম গত মাস (%)</p><div id="trendChart" class="trend-chart"></div>' +
    '<div class="trend-legend"><span><i class="l-cur"></i>এই মাস</span><span><i class="l-prev"></i>গত মাস</span></div>' +
    '<h4 class="delta-h">কোন আমল বেড়েছে, কোনটি কমেছে</h4><div class="delta-list">'+deltaRows+'</div></section>';

  const lastDay = isCurMonth ? now.getDate() : daysInMonth(y,m);
  let cards = '';
  for(let day=lastDay; day>=1; day--){
    const d = new Date(y,m,day), key = dateKey(d);
    cards += dayCardHtml(key, d, key===tk, key===sheetOpenDay);
  }
  h += '<section class="sh-sec" id="dailySec"><h3>দৈনিক বিস্তারিত হিসাব</h3><p class="hint">দিনে চাপ দিন — তারপর প্রতিটি আমলের অবস্থা সরাসরি বদলান</p><div class="day-list">'+cards+'</div>' +
    '<div class="legend"><span><i style="background:var(--green)"></i> জামাত/সম্পন্ন</span><span><i style="background:var(--blue)"></i> একাকী</span><span><i style="background:var(--amber)"></i> কাজা</span><span><i style="background:var(--red)"></i> ছুটেছে</span><span><i style="background:var(--text-faint)"></i> এন্ট্রি নেই</span></div></section>';

  body.innerHTML = h;
  body.scrollTop = keepScroll;
  drawTrendChart(cur, prev);
}
function sheetSetValue(key, id, v){
  if(STATE.days[key] && STATE.days[key][id] === v){ delete STATE.days[key][id]; persist(); }
  else setDayRecord(key, id, v);
  try{ SoundFX.tick(); }catch(e){}
}
(function bindSheet(){
  const body = document.getElementById('sheetBody'); if(!body) return;
  body.addEventListener('click', (e)=>{
    try{
      const pdf = e.target.closest('#pdfReportBtn');
      if(pdf){ openPdfReport(sheetMonthCursor.getFullYear(), sheetMonthCursor.getMonth()); return; }
      const ob = e.target.closest('.ob');
      if(ob){ sheetSetValue(ob.dataset.k, ob.dataset.id, ob.dataset.v); renderSheet(); renderHome(); return; }
      const qa = e.target.closest('.qa');
      if(qa){
        const k = qa.dataset.k;
        if(qa.dataset.qa === 'alljamaat'){ FIVE_WAQT.forEach(id=>{ if(!STATE.days[k]) STATE.days[k] = {}; STATE.days[k][id] = 'jamaat'; }); persist(); try{ SoundFX.success(); }catch(err){} amToast('পাঁচ ওয়াক্ত জামাতে লেখা হলো'); }
        else { delete STATE.days[k]; persist(); amToast('দিনের সব এন্ট্রি মুছে গেছে'); }
        renderSheet(); renderHome(); return;
      }
      const cd = e.target.closest('.cd');
      if(cd && !cd.disabled){
        sheetOpenDay = cd.dataset.k; renderSheet();
        const card = body.querySelector('.dc[data-k="'+sheetOpenDay+'"]');
        if(card){ const top = card.getBoundingClientRect().top - body.getBoundingClientRect().top + body.scrollTop - 8; body.scrollTo({top: top, behavior:'smooth'}); }
        return;
      }
      const hd = e.target.closest('.dc-head');
      if(hd){ sheetOpenDay = (sheetOpenDay === hd.dataset.k) ? null : hd.dataset.k; renderSheet(); }
    }catch(err){ console.error('[amol] sheet click', err); }
  });
})();
function cellButton(id, type, val, key, label){
  let cls='st-none', text='–';
  if(type==='fard'){
    if(val==='jamaat'){cls='st-jamaat'; text='জ';}
    else if(val==='alone'){cls='st-alone'; text='এ';}
    else if(val==='qaza'){cls='st-qaza'; text='ক';}
    else if(val==='missed'){cls='st-missed'; text='✕';}
  } else {
    if(val==='done'){cls='st-done'; text='✓';}
    else if(val==='missed'){cls='st-missed'; text='✕';}
  }
  return `<button class="cell-btn ${cls}" data-key="${key}" data-id="${id}" data-type="${type}" data-label="${escapeHtml(label)}">${text}</button>`;
}

function drawTrendChart(cur, prev){
  const box = document.getElementById('trendChart'); if(!box) return;
  const labels = ['ফজর','যোহর','আসর','মাগরিব','এশা','বিতর','সুন্নত'];
  const curData = FARD_GROUPS.map(g=>cur.groupPct[g.key]).concat([cur.sunnahPct]);
  const prevData = FARD_GROUPS.map(g=>prev.groupPct[g.key]).concat([prev.sunnahPct]);
  const W = 340, H = 196, L = 30, R = 4, top = 10, base = 158, n = labels.length, slot = (W-L-R)/n, bw = Math.min(13, slot*.3);
  const y = v => base - (base-top) * Math.max(0, Math.min(100, v||0)) / 100;
  let g = '';
  [0,50,100].forEach(v=>{ g += '<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(v)+'" y2="'+y(v)+'" class="'+(v?'g-top':'g-base')+'"/><text x="'+(L-6)+'" y="'+(y(v)+4)+'" class="t-y">'+toBn(v)+'</text>'; });
  labels.forEach((lb,i)=>{
    const cx = L + slot*i + slot/2;
    const hc = base - y(curData[i]), hp = base - y(prevData[i]);
    g += '<rect class="b-prev" x="'+(cx+1.5).toFixed(1)+'" y="'+(base-Math.max(hp,2)).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+Math.max(hp,2).toFixed(1)+'" rx="'+(bw/2).toFixed(1)+'"/>';
    g += '<rect class="b-cur" x="'+(cx-1.5-bw).toFixed(1)+'" y="'+(base-Math.max(hc,2)).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+Math.max(hc,2).toFixed(1)+'" rx="'+(bw/2).toFixed(1)+'"/>';
    g += '<text x="'+cx.toFixed(1)+'" y="'+(base+20)+'" class="t-x">'+lb+'</text>';
  });
  box.innerHTML = '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="ওয়াক্তভিত্তিক তুলনা"><defs><linearGradient id="trG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="s1"/><stop offset="1" class="s2"/></linearGradient></defs>'+g+'</svg>';
}

/* ---------- PDF report (native browser print → Save as PDF, keeps Bengali fonts intact) ---------- */
function openPdfReport(y, m){
  const cur = computeMonthStats(y, m);
  const prevD = new Date(y, m-1, 1);
  const prev = computeMonthStats(prevD.getFullYear(), prevD.getMonth());
  const delta = cur.pct - prev.pct;
  const monthDate = new Date(y, m, 1);

  const groups = FARD_GROUPS.map(g=>({label:g.label, cur:cur.groupPct[g.key], prev:prev.groupPct[g.key]}))
    .concat([{label:'সুন্নত (সার্বিক)', cur:cur.sunnahPct, prev:prev.sunnahPct}]);

  const barsHtml = groups.map(g=>{
    const d = g.cur - g.prev;
    return `
      <div class="pr-cat">
        <div class="pr-cat-title"><span>${g.label}</span><span class="d ${d>=0?'up':'down'}">${d>=0?'▲':'▼'} ${toBn(Math.abs(d))}%</span></div>
        <div class="pr-bar"><div class="pr-bar-fill cur" style="width:${Math.max(g.cur,4)}%">${toBn(g.cur)}% (এই মাস)</div></div>
        <div class="pr-bar"><div class="pr-bar-fill prev" style="width:${Math.max(g.prev,4)}%">${toBn(g.prev)}% (গত মাস)</div></div>
      </div>`;
  }).join('');

  const dim = daysInMonth(y, m);
  const sampleFriday = new Date(y,m,1).getDay()===5;
  let headCols = SLOT_DEFS.map(def=> `<th>${slotShort(def, sampleFriday)}</th>`).join('');
  STATE.customAmals.forEach(ca=> headCols += `<th>${escapeHtml(ca.name)}</th>`);

  let rowsHtml = '';
  const statusText = {jamaat:'জ', alone:'এ', qaza:'ক', missed:'✕', done:'✓'};
  for(let day=1; day<=dim; day++){
    const d = new Date(y,m,day);
    const key = dateKey(d);
    const rec = getDayRecord(key);
    let cells = SLOT_DEFS.map(def=> `<td>${statusText[rec[def.id]] || '–'}</td>`).join('');
    STATE.customAmals.forEach(ca=>{ cells += `<td>${statusText[rec['custom_'+ca.id]] || '–'}</td>`; });
    rowsHtml += `<tr><td class="dcell">${toBn(day)} ${WEEKDAYS_BN[d.getDay()]}</td>${cells}</tr>`;
  }

  const html = `
    <div class="pr-header">
      <h1>আমলের মাসিক রিপোর্ট — ${bnMonthLabel(monthDate)}</h1>
      <div class="pr-sub">তৈরি হয়েছে ${bnFullDate(new Date())}</div>
    </div>
    <div class="pr-summary">
      <div class="box"><div class="v">${toBn(cur.pct)}%</div><div class="l">এই মাস</div></div>
      <div class="box"><div class="v">${toBn(prev.pct)}%</div><div class="l">গত মাস</div></div>
      <div class="box"><div class="v">${delta>=0?'▲':'▼'} ${toBn(Math.abs(delta))}%</div><div class="l">পরিবর্তন</div></div>
    </div>
    <div class="pr-section-title">ওয়াক্তভিত্তিক হিসাব (এই মাস বনাম গত মাস)</div>
    ${barsHtml}
    <div class="pr-section-title">দৈনিক বিস্তারিত হিসাব</div>
    <div class="pr-legend">জ = জামাতে, এ = একাকী, ক = কাজা, ✓ = সম্পন্ন, ✕ = হয়নি/ছুটেছে, – = এন্ট্রি নেই</div>
    <table class="pr-table">
      <thead><tr><th>তারিখ</th>${headCols}</tr></thead>
      <tbody>${rowsHtml}</tbody>
    </table>
    <div class="pr-footer">পাথেয় — আমলের রিপোর্ট থেকে তৈরি</div>
  `;
  const area = document.getElementById('printArea');
  area.innerHTML = html;
  setTimeout(()=>{ try{ window.print(); }catch(e){} }, 80);
}

/* ---------- cell edit popover ---------- */
function openCellPopover(key, id, type, label){
  const mask = document.getElementById('popMask');
  document.getElementById('popTitle').textContent = label;
  document.getElementById('popSub').textContent = (function(){ const q = key.split('-').map(Number); return bnFullDate(new Date(q[0], q[1]-1, q[2])); })();
  const grid = document.getElementById('popGrid');
  const rec = getDayRecord(key);
  const cur = rec[id];
  let options;
  if(type==='fard'){
    options = [
      {v:'jamaat', c:'var(--green)', t:'জামাতে পড়েছি'},
      {v:'alone', c:'var(--blue)', t:'একাকী পড়েছি'},
      {v:'qaza', c:'var(--amber)', t:'কাজা পড়েছি'},
      {v:'missed', c:'var(--red)', t:'পড়িনি'},
    ];
  } else {
    options = [
      {v:'done', c:'var(--green)', t:'করেছি'},
      {v:'missed', c:'var(--red)', t:'করিনি'},
    ];
  }
  grid.innerHTML = options.map(o=>`<button class="pop-opt ${cur===o.v?'active':''}" data-v="${o.v}"><span class="pop-dot" style="background:${o.c}"></span>${o.t}</button>`).join('')
    + `<button class="pop-opt" data-v="__clear"><span class="pop-dot" style="background:var(--text-faint)"></span>এন্ট্রি মুছুন</button>`;
  grid.querySelectorAll('.pop-opt').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const v = btn.dataset.v;
      if(v==='__clear'){
        if(STATE.days[key]) delete STATE.days[key][id];
        persist();
      } else {
        setDayRecord(key, id, v);
      }
      mask.classList.remove('show');
      renderSheet();
      renderHome();
    });
  });
  mask.classList.add('show');
}
on('popMask', 'click', (e)=>{
  if(e.target.id==='popMask') e.currentTarget.classList.remove('show');
});

/* ---------- add custom amal modal (v221: ওয়াক্তের সাথে অথবা নিজের পছন্দের যেকোনো সময়) ---------- */
const amalMask = document.getElementById('amalModalMask');
let amalMode = 'waqt';
function updateClockRead(){
  const v = (document.getElementById('amalTimeInput') || {}).value;
  const el = document.getElementById('amalClockRead');
  if(el) el.textContent = v ? bnClock(v) : 'সময় বাছুন';
  document.querySelectorAll('#amalQuickTimes .qt').forEach(b=> b.classList.toggle('on', b.dataset.t === v));
}
function setAmalMode(m){
  amalMode = m;
  document.querySelectorAll('#amalTimeMode button').forEach(b=> b.classList.toggle('on', b.dataset.m === m));
  document.getElementById('amalWaqtWrap').hidden = (m !== 'waqt');
  document.getElementById('amalClockWrap').hidden = (m !== 'clock');
  if(m === 'clock') updateClockRead();
}
(function buildQuickTimes(){
  const box = document.getElementById('amalQuickTimes'); if(!box) return;
  box.innerHTML = ['03:30','06:00','09:00','12:00','15:30','18:00','21:00','22:00']
    .map(t=> '<button type="button" class="qt" data-t="'+t+'">'+bnClock(t)+'</button>').join('');
  box.addEventListener('click', (e)=>{
    const b = e.target.closest('.qt'); if(!b) return;
    document.getElementById('amalTimeInput').value = b.dataset.t; updateClockRead();
  });
})();
on('amalTimeMode', 'click', (e)=>{ const b = e.target.closest('button[data-m]'); if(b) setAmalMode(b.dataset.m); });
on('amalTimeInput', 'input', updateClockRead);
on('amalTimeInput', 'change', updateClockRead);
on('addAmalBtn', 'click', ()=>{
  document.getElementById('amalNameInput').value = '';
  document.getElementById('amalTimeSelect').value = 'after:fajr';
  document.getElementById('amalTimeInput').value = '06:00';
  setAmalMode('waqt');
  amalMask.classList.add('show');
});
on('amalCancelBtn', 'click', ()=> amalMask.classList.remove('show'));
amalMask.addEventListener('click', (e)=>{ if(e.target===amalMask) amalMask.classList.remove('show'); });
on('amalSaveBtn', 'click', ()=>{
  const nameEl = document.getElementById('amalNameInput');
  const name = nameEl.value.trim();
  if(!name){ nameEl.focus(); amToast('আমলের নাম লিখুন'); return; }
  let when;
  if(amalMode === 'clock'){
    const t = document.getElementById('amalTimeInput').value;
    if(!/^\d{1,2}:\d{2}$/.test(t || '')){ amToast('একটি সময় বাছুন'); return; }
    when = 'at:'+t;
  } else {
    when = document.getElementById('amalTimeSelect').value;
  }
  STATE.customAmals.push({ id: 'c'+Date.now(), name, when });
  persist();
  amalMask.classList.remove('show');
  renderHome();
  amToast('"'+name+'" যুক্ত হয়েছে — '+whenText(when));
});

/* ---------- confirm delete custom amal ---------- */
const confirmDeleteMask = document.getElementById('confirmDeleteMask');
on('confirmDeleteCancelBtn', 'click', ()=>{
  pendingDeleteAmalId = null;
  confirmDeleteMask.classList.remove('show');
});
confirmDeleteMask.addEventListener('click', (e)=>{ if(e.target===confirmDeleteMask){ pendingDeleteAmalId = null; confirmDeleteMask.classList.remove('show'); } });
on('confirmDeleteOkBtn', 'click', ()=>{
  if(pendingDeleteAmalId){
    STATE.customAmals = STATE.customAmals.filter(a=> a.id !== pendingDeleteAmalId);
    pendingDeleteAmalId = null;
    persist();
    renderHome();
  }
  confirmDeleteMask.classList.remove('show');
});

/* ---------- ছোট বার্তা (v221) ---------- */
let amToastT = 0;
function amToast(text){
  let el = document.getElementById('amToast');
  if(!el){ el = document.createElement('div'); el.id = 'amToast'; el.setAttribute('role','status'); document.body.appendChild(el); }
  el.textContent = text; el.classList.add('show');
  clearTimeout(amToastT); amToastT = setTimeout(()=> el.classList.remove('show'), 2600);
}

/* ---------- অ্যাকাউন্ট সিঙ্ক / ব্যাকআপ (v221) ----------
   • সাইন-ইন থাকলে: আমলের পুরো হিসাব (amol_report_state) অ্যাপের ক্লাউড-সিঙ্ক (shell/js/10-account.js → Supabase user_backups,
     সারির চাবি = ইউজারের আইডি) নিজে থেকেই নিয়ে যায় — এখানে এক্সপোর্ট/পুনরুদ্ধার লাগে না, তাই বাটনও নেই।
   • সাইন-ইন না থাকলে: হিসাব শুধু এই ফোনের স্টোরেজে (localStorage) থাকে; তখন হাতে ব্যাকআপ ফাইল (এক্সপোর্ট/পুনরুদ্ধার) আছে,
     আর নিচে সাবধান-বার্তা: সাইন-ইন করলে অ্যাকাউন্টে নিরাপদে সেভ থাকবে। */
function getAuth(){
  try{
    let a = window.PatheyoAuth;
    if(!(a && typeof a.state === 'function') && window.parent && window.parent !== window) a = window.parent.PatheyoAuth;
    if(a && typeof a.state === 'function'){ const st = JSON.parse(a.state()); if(st && typeof st === 'object') return st; }
  }catch(e){}
  return { signedIn:false };
}
function getCloudInfo(uid){
  try{ const c = JSON.parse(localStorage.getItem('pt_cloud') || 'null'); if(c && c.uid === uid) return c; }catch(e){}
  return {};
}
function agoText(ts){
  if(!ts) return 'এখনই সংরক্ষণ হচ্ছে…';
  const sec = Math.max(0, Math.round((Date.now() - ts)/1000));
  if(sec < 45) return 'এইমাত্র';
  if(sec < 3600) return toBn(Math.round(sec/60))+' মিনিট আগে';
  if(sec < 86400) return toBn(Math.round(sec/3600))+' ঘণ্টা আগে';
  const d = new Date(ts);
  return toBn(d.getDate())+' '+MONTHS_BN[d.getMonth()]+', '+bnClock(pad2(d.getHours())+':'+pad2(d.getMinutes()));
}
const SY_ICON = {
  cloud:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 18.5h10.2a3.8 3.8 0 0 0 .6-7.55A5.6 5.6 0 0 0 7.1 9.6 4.5 4.5 0 0 0 7 18.5Z"/><path d="m9.4 13.6 1.9 1.9 3.5-3.8"/></svg>',
  phone:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2.8" width="10" height="18.4" rx="2.6"/><path d="M10.6 18h2.8"/></svg>',
  shield:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.2 5 6v5.6c0 4.4 2.9 7.6 7 9.2 4.1-1.6 7-4.8 7-9.2V6l-7-2.8Z"/><path d="m9.2 12.2 2.1 2.1 3.6-4"/></svg>'
};
let syncSig = '';
function renderSyncCard(force){
  const box = document.getElementById('syncBody'); if(!box) return;
  const a = getAuth(), ci = a.signedIn ? getCloudInfo(a.uid) : {};
  const sig = JSON.stringify([!!a.signedIn, a.uid || '', a.name || '', a.email || '', ci.on, ci.hold, ci.at ? Math.floor(ci.at/30000) : 0]);
  if(!force && sig === syncSig) return;
  syncSig = sig;
  let h;
  if(a.signedIn){
    const who = a.name || a.email || 'আপনার অ্যাকাউন্ট';
    const off = (ci.on === false);
    h = '<div class="sy-head"><div class="sy-ic ok">'+SY_ICON.cloud+'</div><div class="sy-t"><h3>'+(off ? 'অটো সিঙ্ক বন্ধ আছে' : 'অটো ব্যাকআপ চালু')+'</h3>' +
        '<p class="hint">'+(off ? 'অ্যাকাউন্ট সেটিংস থেকে অটো ক্লাউড-সিঙ্ক চালু করলে আপনার আমল ও আমলের হিসাব নিজে থেকেই সেভ হবে।' : 'আপনার আমল ও আমলের হিসাব অ্যাকাউন্টে নিজে থেকেই সেভ হচ্ছে — কিছু করতে হবে না।')+'</p></div></div>' +
        '<div class="sy-rows"><div class="sy-row"><span>অ্যাকাউন্ট</span><b>'+escapeHtml(who)+'</b></div>' +
        (off ? '' : '<div class="sy-row"><span>শেষ সেভ</span><b>'+agoText(ci.at)+'</b></div>')+'</div>' +
        '<p class="sy-note">'+SY_ICON.shield+'<span>নতুন ফোনে বা অ্যাপ নতুন করে নামালেও এই অ্যাকাউন্টে সাইন-ইন করলেই আপনার সব আমল ও আমলের হিসাব ফিরে আসবে।</span></p>';
  } else {
    h = '<div class="sy-head"><div class="sy-ic">'+SY_ICON.phone+'</div><div class="sy-t"><h3>ডেটা ব্যাকআপ</h3>' +
        '<p class="hint">সাইন-ইন ছাড়া আপনার আমল ও আমলের হিসাব শুধু এই ফোনের স্টোরেজে আছে। নিশ্চিন্ত থাকতে মাঝে মাঝে একটি ব্যাকআপ ফাইল ডাউনলোড করে রাখুন।</p></div></div>' +
        '<div class="backup-row">' +
          '<button type="button" class="backup-btn rippleable" id="exportBackupBtn"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M12 4v11m0 0l-4-4m4 4l4-4" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke-linecap="round"/></svg>এক্সপোর্ট করুন</button>' +
          '<button type="button" class="backup-btn rippleable" id="importBackupBtn"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M12 20V9m0 0l-4 4m4-4l4 4" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke-linecap="round"/></svg>পুনরুদ্ধার করুন</button>' +
        '</div>' +
        '<div class="sy-warn" role="note"><div class="sy-warn-ic">'+SY_ICON.shield+'</div><div class="sy-warn-t"><b>সাইন-ইন করলে আরও নিরাপদ</b>' +
          '<p>সাইন-ইন করলে আপনার আমল ও আমলের হিসাব অ্যাকাউন্টে নিজে থেকেই সেভ থাকবে এবং নিরাপদ থাকবে। ফোন বদলালে বা অ্যাপ মুছে ফেললেও কিছুই হারাবে না — ব্যাকআপ ফাইলের ঝামেলাও থাকবে না।</p>' +
          '<button type="button" class="sy-signin rippleable" id="syncSignInBtn">সাইন-ইন করুন</button></div></div>';
  }
  box.innerHTML = h;
}
function openSignIn(){
  try{
    const p = window.parent;
    const b = p && p !== window ? p.document.getElementById('btn-profile') : null;
    if(b){ b.click(); return; }
  }catch(e){}
  amToast('ওপরের প্রোফাইল বাটন থেকে সাইন-ইন করুন');
}
async function exportBackup(btn){
  const original = btn.innerHTML;
  try{
    const snapshot = JSON.stringify(STATE, null, 2);
    const fname = 'amoler-report-backup-'+dateKey(new Date())+'.json';
    let nb = null;
    try{ nb = window.PatheyoBackup || (window.parent && window.parent.PatheyoBackup) || null; }catch(e){}
    let done = false;
    if(nb && typeof nb.saveFile === 'function'){
      let path = ''; try{ path = nb.saveFile(fname, snapshot); }catch(e){}
      done = !!path;
    }
    if(!done && nb && typeof nb.shareFile === 'function'){
      try{ done = !!nb.shareFile(fname, snapshot); }catch(e){}
    }
    if(!done){
      const blob = new Blob([snapshot], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = fname;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(()=> URL.revokeObjectURL(url), 2000);
    }
    btn.textContent = '✓ সংরক্ষিত হয়েছে';
    setTimeout(()=> { btn.innerHTML = original; }, 1800);
  }catch(e){
    btn.textContent = 'ব্যর্থ হয়েছে';
    setTimeout(()=> { btn.innerHTML = original; }, 1800);
  }
}
document.addEventListener('click', (e)=>{
  const t = e.target.closest ? e.target.closest('#exportBackupBtn, #importBackupBtn, #syncSignInBtn') : null; if(!t) return;
  if(t.id === 'exportBackupBtn') exportBackup(t);
  else if(t.id === 'importBackupBtn') document.getElementById('importFileInput').click();
  else openSignIn();
});
on('importFileInput', 'change', (e)=>{
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = ()=>{
    try{
      const parsed = JSON.parse(reader.result);
      if(parsed && typeof parsed === 'object'){
        STATE = {
          theme: parsed.theme || STATE.theme,
          soundOn: typeof parsed.soundOn === 'boolean' ? parsed.soundOn : STATE.soundOn,
          customAmals: Array.isArray(parsed.customAmals) ? parsed.customAmals : STATE.customAmals,
          days: parsed.days && typeof parsed.days === 'object' ? parsed.days : STATE.days,
          qaza: parsed.qaza && typeof parsed.qaza === 'object' ? parsed.qaza : STATE.qaza
        };
        applyTheme();
        applySound();
        persist();
        renderHome();
        amToast('ব্যাকআপ থেকে আমল ফিরিয়ে আনা হয়েছে');
      }
    }catch(err){ console.error('[amol] backup import failed', err); amToast('ফাইলটি পড়া যায়নি'); }
    e.target.value = '';
  };
  reader.readAsText(file);
});
setInterval(()=>{ try{ renderSyncCard(false); }catch(e){} }, 3000);
window.addEventListener('storage', (e)=>{ if(e.key === 'pt_cloud'){ try{ renderSyncCard(false); }catch(err){} } });

/* ---------- init ---------- */
(function initSync(){
  // Render synchronously first with whatever local data exists so the
  // page is fully interactive before any async storage call resolves.
  try{ loadLocalFallback(); }catch(e){}
  try{ applyTheme(); }catch(e){}
  try{ applySound(); }catch(e){}
  try{ attachRipple(document); }catch(e){}
  try{ renderHome(); }catch(e){ console.error('[amol] initial render failed', e); }
})();

(async function initAsync(){
  try{
    await initStorage();
    applyTheme();
    applySound();
    renderHome();
  }catch(e){ console.error('[amol] storage init failed', e); }
})();
