/* দোয়া — ইউজারের নিজের যোগ করা দোয়া (শুধু প্রিমিয়াম সদস্য যোগ করতে পারেন; আগে থেকে যোগ হওয়া দোয়া সবসময় দেখা যায়)।
   প্রতিটা নিজের দোয়া = একটি নিজস্ব টাইল (নাম + আইকন) + একটি দোয়া-কার্ড। ফোনে থাকে (localStorage: pt_dua_custom) এবং অ্যাপের ব্যাকআপ/ক্লাউড-সিঙ্কে যায়।
   লোড হওয়ার সময় DUA_CATS / DUA_ITEMS / DUA_ICON-এ মিশে যায় (u:1 চিহ্ন দিয়ে), তাই সার্চ, প্রিয়, কপি, শেয়ার — সবকিছু বাকি দোয়ার মতোই কাজ করে।
   বদলালে 'duacustom' ইভেন্ট ছাড়ে — ইঞ্জিন, তালিকা আর সার্চ নিজে নিজে হালনাগাদ হয়। */
var DuaCustom = (function () {
  'use strict';
  var KEY = 'pt_dua_custom', REF = 'আমার যোগ করা দোয়া';
  function okRec(x) { return x && typeof x.id === 'string' && x.id && typeof x.n === 'string' && x.n; }
  function load() { try { var a = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(a) ? a.filter(okRec) : []; } catch (e) { return []; } }
  function save(a) { try { localStorage.setItem(KEY, JSON.stringify(a)); return true; } catch (e) { return false; } }
  var list = load();

  function merge() {
    var i;
    for (i = DUA_CATS.length - 1; i >= 0; i--) if (DUA_CATS[i].u) DUA_CATS.splice(i, 1);
    for (i = DUA_ITEMS.length - 1; i >= 0; i--) if (DUA_ITEMS[i].u) DUA_ITEMS.splice(i, 1);
    list.forEach(function (x) {
      var cid = 'u_' + x.id;
      DUA_CATS.push({ id: cid, n: x.n, u: 1 });
      DUA_ICON[cid] = DUA_ICON[x.ic] || DUA_ICON.heart;
      DUA_ITEMS.push({ id: 'ud_' + x.id, cat: cid, t: x.n, ar: x.ar || '', tr: x.tr || '', bn: x.bn || '', ref: REF, u: 1, uid: x.id });
    });
  }
  function changed() {
    merge();
    try { window.dispatchEvent(new Event('duacustom')); } catch (e) {}
  }
  function clean(o) {
    function s(v, n) { return String(v == null ? '' : v).replace(/\s+$/g, '').replace(/^\s+/g, '').slice(0, n); }
    return { n: s(o.n, 40), ic: s(o.ic, 20), ar: s(o.ar, 4000), tr: s(o.tr, 4000), bn: s(o.bn, 4000) };
  }
  function find(id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return i; return -1; }

  merge();
  return {
    all: function () { return list.slice(); },
    get: function (id) { var i = find(id); return i < 0 ? null : JSON.parse(JSON.stringify(list[i])); },
    add: function (o) {
      var r = clean(o); r.id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var next = list.concat([r]); if (!save(next)) return null;
      list = next; changed(); return r;
    },
    update: function (id, o) {
      var i = find(id); if (i < 0) return null;
      var r = clean(o); r.id = id; var next = list.slice(); next[i] = r; if (!save(next)) return null;
      list = next; changed(); return r;
    },
    remove: function (id) {
      var i = find(id); if (i < 0) return false;
      var next = list.slice(); next.splice(i, 1); if (!save(next)) return false;
      list = next; changed(); return true;
    }
  };
})();
