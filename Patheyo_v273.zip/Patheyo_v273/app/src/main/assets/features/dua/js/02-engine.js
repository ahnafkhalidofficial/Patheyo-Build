/* দোয়া — সার্চ ইঞ্জিন (সার্চ বার ও পূর্ণ-পর্দা সার্চ দুটোই এটি ব্যবহার করে)।
   বাংলা ও আরবি দুটোতেই খোঁজে; আরবির হরকত ধরা হয় না; কিছু না মিললে "কাছাকাছি মিল" (ী/ি, শ/ষ/স ইত্যাদি এক ধরে) চলে। */
var DuaEngine = (function () {
  var CAT = {}; DUA_CATS.forEach(function (c) { CAT[c.id] = c.n; });
  var BN_DIG = '০১২৩৪৫৬৭৮৯';
  var AR_RE = /[\u0600-\u06FF]/;
  var COMB = /[\u0981-\u0983\u09BC\u09BE-\u09CC\u09D7\u064B-\u065F\u0670\u06D6-\u06ED]/;
  var RELAX = { 'ী': 'ি', 'ূ': 'ু', 'ঈ': 'ই', 'ঊ': 'উ', 'ণ': 'ন', 'শ': 'স', 'ষ': 'স', 'ৎ': 'ত', 'ঙ': 'ং', 'ঁ': '', 'ে': 'ি', 'ো': 'ু' };

  /* fold(): লেখাকে তুলনার উপযোগী করে + প্রতিটি নতুন অক্ষর মূল লেখার কোন জায়গা থেকে এল তার map রাখে (হাইলাইটের জন্য) */
  function fold(s, relaxed) {
    var t = '', map = [], i, ch, c, o;
    s = String(s == null ? '' : s);
    for (i = 0; i < s.length; i++) {
      ch = s.charAt(i); c = s.charCodeAt(i);
      if (c === 0x200C || c === 0x200D || c === 0x0640) continue;                        /* ZWNJ/ZWJ/তাতউইল */
      if ((c >= 0x064B && c <= 0x065F) || c === 0x0670 || (c >= 0x06D6 && c <= 0x06ED)) continue;   /* আরবি হরকত */
      if (c === 0x09DF) { t += '\u09AF\u09BC'; map.push(i, i); continue; }                /* য় এর দুই রূপ এক করা */
      o = BN_DIG.indexOf(ch); if (o > -1) ch = String(o);
      if (c === 0x0623 || c === 0x0625 || c === 0x0622 || c === 0x0671) ch = '\u0627';    /* أ إ آ ٱ → ا */
      else if (c === 0x0649) ch = '\u064A';                                               /* ى → ي */
      else if (c === 0x06A9) ch = '\u0643';                                               /* ک → ك */
      else ch = ch.toLowerCase();
      if (relaxed && RELAX.hasOwnProperty(ch)) ch = RELAX[ch];
      if (ch === '') continue;
      t += ch; map.push(i);
    }
    return { t: t, map: map };
  }

  var cache = { s: null, r: null };
  window.addEventListener('duacustom', function () {      /* নিজের দোয়া যোগ/বদল/মোছায় সার্চের তালিকা নতুন করে বানানো */
    CAT = {}; DUA_CATS.forEach(function (c) { CAT[c.id] = c.n; }); cache = { s: null, r: null };
  });
  function prep(relaxed) {
    var k = relaxed ? 'r' : 's';
    if (cache[k]) return cache[k];
    cache[k] = DUA_ITEMS.map(function (d) {
      return { d: d, t: fold(d.t, relaxed), bn: fold(d.bn, relaxed), tr: fold(d.tr, relaxed), ar: fold(d.ar, relaxed), ref: fold(d.ref, relaxed), cat: fold(CAT[d.cat], relaxed) };
    });
    return cache[k];
  }

  function terms(q, relaxed) {
    return fold(q, relaxed).t.split(/\s+/).filter(function (x) { return x; });
  }

  function run(q, relaxed) {
    var tm = terms(q, relaxed), mode = AR_RE.test(q) ? 'ar' : 'bn';
    if (!tm.length) return { mode: 'empty', terms: [], items: [] };
    var fields = mode === 'ar' ? [['ar', 3]] : [['t', 3], ['bn', 2], ['tr', 1.5], ['cat', 1], ['ref', 1]];
    var out = [];
    prep(relaxed).forEach(function (p, idx) {
      var score = 0, ok = true;
      for (var i = 0; i < tm.length && ok; i++) {
        var best = 0;
        for (var f = 0; f < fields.length; f++) { if (p[fields[f][0]].t.indexOf(tm[i]) > -1 && fields[f][1] > best) best = fields[f][1]; }
        if (!best) ok = false; else score += best;
      }
      if (ok) out.push({ d: p.d, score: score, idx: idx });
    });
    out.sort(function (a, b) { return b.score - a.score || a.idx - b.idx; });
    return { mode: mode, terms: tm, items: out, relaxed: !!relaxed };
  }

  function search(q) {
    var t0 = (window.performance && performance.now) ? performance.now() : Date.now();
    var r = run(q, false);
    if (r.mode !== 'empty' && !r.items.length) { var r2 = run(q, true); if (r2.items.length) r = r2; }
    r.total = r.items.length;
    r.ms = ((window.performance && performance.now) ? performance.now() : Date.now()) - t0;
    return r;
  }

  /* text-এর যেসব জায়গা terms-এর সাথে মেলে: [[শুরু, শেষ), ...] — মূল লেখার ইনডেক্সে */
  function spans(text, tm, relaxed) {
    var f = fold(text, relaxed), out = [], i, from, at;
    for (i = 0; i < tm.length; i++) {
      from = 0;
      while ((at = f.t.indexOf(tm[i], from)) > -1) {
        var e = f.map[at + tm[i].length - 1] + 1;
        while (e < text.length && COMB.test(text.charAt(e))) e++;      /* মিলের পরের কার-চিহ্ন/হরকতও হাইলাইটে আসুক, যাতে অক্ষর ভেঙে না যায় */
        out.push([f.map[at], e]);
        from = at + tm[i].length;
      }
    }
    out.sort(function (a, b) { return a[0] - b[0] || b[1] - a[1]; });
    var merged = [];
    out.forEach(function (r) { var l = merged[merged.length - 1]; if (l && r[0] <= l[1]) { if (r[1] > l[1]) l[1] = r[1]; } else merged.push([r[0], r[1]]); });
    return merged;
  }

  function catMatches(tm, relaxed) {
    if (!tm.length) return [];
    return DUA_CATS.filter(function (c) { var t = fold(c.n, relaxed).t; return tm.every(function (x) { return t.indexOf(x) > -1; }); });
  }

  return { search: search, spans: spans, catMatches: catMatches, fold: fold };
})();
