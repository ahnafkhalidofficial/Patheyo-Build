/* v236: কম্পাস ঠিক করার ৮-আকৃতির অ্যানিমেশন — মসৃণ।
   আগে CSS offset-path দিয়ে চলত, যা ওয়েবভিউতে ধাপে ধাপে/আটকে আটকে দেখাত।
   এখন requestAnimationFrame + সময়-ভিত্তিক হিসাব: ফ্রেম কমবেশি হলেও গতি সমান থাকে,
   পথের দৈর্ঘ্য ধরে সমান গতিতে চলে, আর ফোনের মুখ পথের দিক ধরে নরমভাবে ঘোরে। */
(function () {
  'use strict';
  var box = document.querySelector('.cal8');
  if (!box) return;
  var svg = box.querySelector('svg'), track = box.querySelector('.p8'), ph = box.querySelector('.ph');
  if (!svg || !track || !ph) return;

  var CX = 46, CY = 26, A = 42, SY = 1.35, N = 360, PERIOD = 4200;
  function pt(t) {                                   /* বার্নুলির লেমনিস্কেট (∞) */
    var s = Math.sin(t), c = Math.cos(t), d = 1 + s * s;
    return [CX + A * c / d, CY + SY * A * s * c / d];
  }
  /* পথ আঁকা + দৈর্ঘ্যের টেবিল */
  var pts = [], len = [0], i, d = '';
  for (i = 0; i <= N; i++) {
    var t = (i / N) * Math.PI * 2; pts.push(pt(t));
    d += (i ? 'L' : 'M') + pts[i][0].toFixed(2) + ' ' + pts[i][1].toFixed(2);
    if (i) len.push(len[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  }
  track.setAttribute('d', d + 'Z');
  var total = len[N];

  function at(p) {                                   /* p: 0..1 → সমান দূরত্বে বিন্দু ও দিক */
    var target = p * total, lo = 0, hi = N;
    while (lo < hi) { var m = (lo + hi) >> 1; if (len[m] < target) lo = m + 1; else hi = m; }
    var k = Math.max(1, lo), f = (target - len[k - 1]) / ((len[k] - len[k - 1]) || 1);
    var a = pts[k - 1], b = pts[k];
    return { x: a[0] + (b[0] - a[0]) * f, y: a[1] + (b[1] - a[1]) * f, ang: Math.atan2(b[1] - a[1], b[0] - a[0]) };
  }

  var rot = null;                                    /* কোণ নরম করা: লাফ নয়, ধীরে অনুসরণ */
  function draw(p, dt) {
    var q = at(p), deg = q.ang * 180 / Math.PI + 90;
    if (rot === null) rot = deg;
    else {
      var diff = ((deg - rot + 540) % 360) - 180;
      rot += diff * Math.min(1, dt / 90);
    }
    ph.setAttribute('transform', 'translate(' + q.x.toFixed(2) + ' ' + q.y.toFixed(2) + ') rotate(' + rot.toFixed(2) + ')');
  }

  var raf = 0, start = 0, last = 0, visible = true;
  function frame(now) {
    if (!start) { start = now; last = now; }
    var dt = Math.min(64, now - last); last = now;
    draw(((now - start) % PERIOD) / PERIOD, dt);
    raf = visible && !document.hidden ? requestAnimationFrame(frame) : 0;
  }
  function run() { if (!raf) { start = 0; raf = requestAnimationFrame(frame); } }
  function stop() { if (raf) { cancelAnimationFrame(raf); raf = 0; } }

  draw(0, 16);
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return;
  if ('IntersectionObserver' in window) {            /* স্ক্রিনে না থাকলে চলে না — ব্যাটারি বাঁচে */
    new IntersectionObserver(function (es) { visible = es[0].isIntersecting; visible ? run() : stop(); }).observe(box);
  }
  document.addEventListener('visibilitychange', function () { document.hidden ? stop() : (visible && run()); });
  run();
})();
