

var WMM={g:[[-29351.8,-1410.8],[-2556.6,2951.1,1649.3],[1361.0,-2404.1,1243.8,453.6],[895.0,799.5,55.7,-281.1,12.1],[-233.2,368.9,187.2,-138.7,-142.0,20.9],[64.4,63.8,76.9,-115.7,-40.9,14.9,-60.7],[79.5,-77.0,-8.8,59.3,15.8,2.5,-11.1,14.2],[23.2,10.8,-17.5,2.0,-21.7,16.9,15.0,-16.8,0.9],[4.6,7.8,3.0,-0.2,-2.5,-13.1,2.4,8.6,-8.7,-12.9],[-1.3,-6.4,0.2,2.0,-1.0,-0.6,-0.9,1.5,0.9,-2.7,-3.9],[2.9,-1.5,-2.5,2.4,-0.6,-0.1,-0.6,-0.1,1.1,-1.0,-0.2,2.6],[-2.0,-0.2,0.3,1.2,-1.3,0.6,0.6,0.5,-0.1,-0.4,-0.2,-1.3,-0.7]],h:[[0,4545.4],[0,-3133.6,-815.1],[0,-56.6,237.5,-549.5],[0,278.6,-133.9,212.0,-375.6],[0,45.4,220.2,-122.9,43.0,106.1],[0,-18.4,16.8,48.8,-59.8,10.9,72.7],[0,-48.9,-14.4,-1.0,23.4,-7.4,-25.1,-2.3],[0,7.1,-12.6,11.4,-9.7,12.7,0.7,-5.2,3.9],[0,-24.8,12.2,8.3,-3.3,-5.2,7.2,-0.6,0.8,10.0],[0,3.3,0.0,2.4,5.3,-9.1,0.4,-4.2,-3.8,0.9,-9.1],[0,0.0,2.9,-0.6,0.2,0.5,-0.3,-1.2,-1.7,-2.9,-1.8,-2.3],[0,-1.3,0.7,1.0,-1.4,0.0,0.6,-0.1,0.8,0.1,-1.0,0.1,0.2]],gd:[[12.0,9.7],[-11.6,-5.2,-8.0],[-1.3,-4.2,0.4,-15.6],[-1.6,-2.4,-6.0,5.6,-7.0],[0.6,1.4,0.0,0.6,2.2,0.9],[-0.2,-0.4,0.9,1.2,-0.9,0.3,0.9],[0.0,-0.1,-0.1,0.5,-0.1,-0.8,-0.8,0.8],[-0.1,0.2,0.0,0.5,-0.1,0.3,0.2,0.0,0.2],[0.0,-0.1,0.1,0.3,-0.3,0.0,0.3,-0.1,0.1,-0.1],[0.1,0.0,0.1,0.1,0.0,-0.3,0.0,-0.1,-0.1,0.0,0.0],[0.0,0.0,0.0,0.0,0.0,-0.1,0.0,0.0,-0.1,-0.1,-0.1,-0.1],[0.0,0.0,0.0,0.0,0.0,0.0,0.1,0.0,0.0,0.0,-0.1,0.0,-0.1]],hd:[[0,-21.5],[0,-27.7,-12.1],[0,4.0,-0.3,-4.1],[0,-1.1,4.1,1.6,-4.4],[0,-0.5,2.2,0.4,1.7,1.9],[0,0.3,-1.6,-0.4,0.9,0.7,0.9],[0,0.6,0.5,-0.8,0.0,-1.0,0.6,-0.2],[0,-0.2,0.5,-0.4,0.4,-0.5,-0.6,0.3,0.2],[0,-0.3,0.3,-0.3,0.3,0.2,-0.1,-0.2,0.4,0.1],[0,0.0,0.0,-0.2,0.1,-0.1,0.1,0.0,-0.1,0.2,0.0],[0,0.0,0.1,0.0,0.1,0.0,0.0,0.1,0.0,0.0,0.0,0.0],[0,0.0,0.0,-0.1,0.1,0.0,0.0,0.0,0.0,0.0,0.0,0.0,-0.1]],epoch:2025.0};
var QB={
  KAABA:{lat:21.422487,lon:39.826206},
  rad:function(d){return d*Math.PI/180},
  deg:function(r){return r*180/Math.PI},
  norm:function(d){d=d%360;return d<0?d+360:d},
  diff:function(a,b){var d=QB.norm(a-b);return d>180?d-360:d},
  decYear:function(dt){dt=dt||new Date();var y=dt.getUTCFullYear(),s=Date.UTC(y,0,1),e=Date.UTC(y+1,0,1);return y+(dt.getTime()-s)/(e-s)},
  /* WMM2025 magnetic field (NOAA/BGS) – returns declination, inclination, total intensity */
  field:function(lat,lon,hKm,year){
    var a=6378.137,f=1/298.257223563,e2=f*(2-f),re=6371.2;
    lat=Math.max(-89.9999,Math.min(89.9999,lat));
    var phi=QB.rad(lat),lam=QB.rad(lon),sp=Math.sin(phi),cp=Math.cos(phi);
    var rc=a/Math.sqrt(1-e2*sp*sp),p=(rc+hKm)*cp,z=(rc*(1-e2)+hKm)*sp,r=Math.sqrt(p*p+z*z),phic=Math.asin(z/r);
    var th=Math.PI/2-phic,ct=Math.cos(th),st=Math.sin(th),N=12,dt=year-WMM.epoch;
    var P=[],dP=[],S=[],n,m;
    for(n=0;n<=N;n++){P[n]=[];dP[n]=[];S[n]=[];for(m=0;m<=N;m++){P[n][m]=0;dP[n][m]=0;S[n][m]=0}}
    P[0][0]=1;
    for(n=1;n<=N;n++)for(m=0;m<=n;m++){
      if(n===m){P[n][m]=st*P[n-1][m-1];dP[n][m]=st*dP[n-1][m-1]+ct*P[n-1][m-1]}
      else if(n===1){P[n][m]=ct*P[n-1][m];dP[n][m]=ct*dP[n-1][m]-st*P[n-1][m]}
      else{var K=((n-1)*(n-1)-m*m)/((2*n-1)*(2*n-3));P[n][m]=ct*P[n-1][m]-K*P[n-2][m];dP[n][m]=ct*dP[n-1][m]-st*P[n-1][m]-K*dP[n-2][m]}
    }
    S[0][0]=1;
    for(n=1;n<=N;n++){S[n][0]=S[n-1][0]*(2*n-1)/n;for(m=1;m<=n;m++)S[n][m]=S[n][m-1]*Math.sqrt((n-m+1)*(m===1?2:1)/(n+m))}
    var Br=0,Bt=0,Bl=0;
    for(n=1;n<=N;n++){
      var rr=Math.pow(re/r,n+2);
      for(m=0;m<=n;m++){
        var g=WMM.g[n-1][m]+dt*WMM.gd[n-1][m],h=WMM.h[n-1][m]+dt*WMM.hd[n-1][m];
        var cm=Math.cos(m*lam),sm=Math.sin(m*lam),pn=P[n][m]*S[n][m],dpn=dP[n][m]*S[n][m];
        Br+=rr*(n+1)*(g*cm+h*sm)*pn;
        Bt-=rr*(g*cm+h*sm)*dpn;
        Bl+=rr*m*(-g*sm+h*cm)*pn*-1/st;
      }
    }
    var Xp=-Bt,Y=Bl,Zp=-Br,psi=phic-phi;
    var X=Xp*Math.cos(psi)-Zp*Math.sin(psi),Z=Xp*Math.sin(psi)+Zp*Math.cos(psi),H=Math.sqrt(X*X+Y*Y);
    return {D:QB.deg(Math.atan2(Y,X)),I:QB.deg(Math.atan2(Z,H)),F:Math.sqrt(H*H+Z*Z)};
  },
  /* Vincenty inverse on WGS-84: initial bearing (true north) + distance */
  inverse:function(lat1,lon1,lat2,lon2){
    var a=6378137,f=1/298.257223563,b=(1-f)*a;
    var L=QB.rad(lon2-lon1),U1=Math.atan((1-f)*Math.tan(QB.rad(lat1))),U2=Math.atan((1-f)*Math.tan(QB.rad(lat2)));
    var sU1=Math.sin(U1),cU1=Math.cos(U1),sU2=Math.sin(U2),cU2=Math.cos(U2);
    var lam=L,lamP,it=0,sS,cS,sg,sa,c2a,c2sm,sig,C,ok=true;
    do{
      var sl=Math.sin(lam),cl=Math.cos(lam);
      sS=Math.sqrt((cU2*sl)*(cU2*sl)+(cU1*sU2-sU1*cU2*cl)*(cU1*sU2-sU1*cU2*cl));
      if(sS===0)return {az:0,km:0};
      cS=sU1*sU2+cU1*cU2*cl;sig=Math.atan2(sS,cS);sa=cU1*cU2*sl/sS;c2a=1-sa*sa;
      c2sm=c2a!==0?cS-2*sU1*sU2/c2a:0;
      C=f/16*c2a*(4+f*(4-3*c2a));lamP=lam;
      lam=L+(1-C)*f*sa*(sig+C*sS*(c2sm+C*cS*(-1+2*c2sm*c2sm)));
    }while(Math.abs(lam-lamP)>1e-12&&++it<200);
    if(it>=200)ok=false;
    var az=Math.atan2(cU2*Math.sin(lam),cU1*sU2-sU1*cU2*Math.cos(lam));
    var u2=c2a*(a*a-b*b)/(b*b),A=1+u2/16384*(4096+u2*(-768+u2*(320-175*u2))),B=u2/1024*(256+u2*(-128+u2*(74-47*u2)));
    var ds=B*sS*(c2sm+B/4*(cS*(-1+2*c2sm*c2sm)-B/6*c2sm*(-3+4*sS*sS)*(-3+4*c2sm*c2sm)));
    var s=b*A*(sig-ds);
    if(!ok||isNaN(az)){
      var p1=QB.rad(lat1),p2=QB.rad(lat2),dl=QB.rad(lon2-lon1);
      var y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);
      var h=Math.sin((p2-p1)/2),k=Math.sin(dl/2);
      var q=h*h+Math.cos(p1)*Math.cos(p2)*k*k;
      return {az:QB.norm(QB.deg(Math.atan2(y,x))),km:2*6371.0088*Math.asin(Math.sqrt(q))};
    }
    return {az:QB.norm(QB.deg(az)),km:s/1000};
  },
  qibla:function(lat,lon){return QB.inverse(lat,lon,QB.KAABA.lat,QB.KAABA.lon)}
};

var $=function(i){return document.getElementById(i)};
function ld(k,d){try{var v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}}
function sv(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
function bn(n){return String(n).replace(/\d/g,function(d){return "০১২৩৪৫৬৭৮৯"[d]})}
var theme=ld("tz3_theme",matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");
function applyTheme(){document.documentElement.setAttribute("data-theme",theme)}
$("theme").onclick=function(){theme=theme==="dark"?"light":"dark";sv("tz3_theme",theme);applyTheme()};applyTheme();

/* ---------- dial ---------- */
(function(){
  var ns="http://www.w3.org/2000/svg",tk=$("ticks"),lt=$("letters");
  for(var i=0;i<72;i++){
    var a=i*5,maj=a%30===0,card=a%90===0,r1=118,r2=card?102:(maj?108:112);
    var l=document.createElementNS(ns,"line"),rad=a*Math.PI/180,sn=Math.sin(rad),c=-Math.cos(rad);
    l.setAttribute("x1",150+r1*sn);l.setAttribute("y1",150+r1*c);l.setAttribute("x2",150+r2*sn);l.setAttribute("y2",150+r2*c);
    l.setAttribute("stroke-width",card?3:(maj?2.2:1.4));
    l.setAttribute("class","tk2"+(a===0?" nn":(a===270?" ww":(maj?" mj":""))));
    tk.appendChild(l);
  }
  [["উ",0],["পূ",90],["দ",180],["প",270]].forEach(function(x){
    var rad=x[1]*Math.PI/180,px=150+73*Math.sin(rad),py=150-73*Math.cos(rad),g=document.createElementNS(ns,"g"),isW=x[1]===270;
    if(isW){var c=document.createElementNS(ns,"circle");c.setAttribute("cx",px);c.setAttribute("cy",py);c.setAttribute("r",13);c.setAttribute("class","wbadge");g.appendChild(c)}
    var tx=document.createElementNS(ns,"text");tx.setAttribute("x",px);tx.setAttribute("y",py);
    tx.setAttribute("class","cl"+(x[1]===0?" n":(isW?" w":"")));tx.textContent=x[0];g.appendChild(tx);
    g._x=px;g._y=py;lt.appendChild(g);
  });
})();

/* ---------- state ---------- */
var PIN='<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.4"/></svg>',CHK='<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',loc=ld("qb_loc",null),res=null,dec=0,running=false,hasSensor=false,sx=0,sy=0,got=false,magH=0,accDeg=null,aligned=false,lastRender=0,watchdog=null,secure=window.isSecureContext;
var CITIES=[["ঢাকা",23.8103,90.4125],["চট্টগ্রাম",22.3569,91.7832],["সিলেট",24.8949,91.8687],["রাজশাহী",24.3745,88.6042],["খুলনা",22.8456,89.5403],["বরিশাল",22.701,90.3535],["রংপুর",25.7439,89.2752],["ময়মনসিংহ",24.7471,90.4203],["কক্সবাজার",21.4272,92.0058],["লন্ডন",51.5074,-0.1278],["নিউ ইয়র্ক",40.7128,-74.006],["দুবাই",25.2048,55.2708],["কুয়ালালামপুর",3.139,101.6869],["টরন্টো",43.6532,-79.3832]];

function fmtDeg(d,p){return bn(d.toFixed(p===undefined?1:p))+"°"}
function updateLoc(){
  if(!loc){$("locline").textContent="লোকেশন নেওয়া হয়নি";return}
  $("locline").innerHTML=PIN+" <b>"+bn(loc.lat.toFixed(4))+"°, "+bn(loc.lon.toFixed(4))+"°</b>"+(loc.acc?" <span>(±"+bn(Math.round(loc.acc))+" মি.)</span>":(loc.src==="manual"?" <span>(হাতে দেওয়া)</span>":""));
}
function compute(){
  $("qmark").style.display=loc?"":"none";
  if(!loc){res=null;$("sAz").textContent="—";$("sKm").textContent="—";$("sDec").textContent="—";return}
  res=QB.qibla(loc.lat,loc.lon);
  dec=QB.field(loc.lat,loc.lon,0,QB.decYear()).D;
  $("sAz").textContent=fmtDeg(res.az,1);
  $("sKm").textContent=res.km<1?"কাছেই":bn(Math.round(res.km).toLocaleString("en-US"))+" কিমি";
  $("sDec").textContent=(dec>=0?"পূর্ব ":"পশ্চিম ")+fmtDeg(Math.abs(dec),1);
  $("qmark").style.transform="rotate("+res.az+"deg)";
}
function setLoc(lat,lon,acc,src){
  loc={lat:lat,lon:lon,acc:acc||0,src:src||"gps"};sv("qb_loc",loc);
  updateLoc();compute();render(true);
}

/* ---------- render ---------- */
function upright(h){var ls=$("letters").children;for(var i=0;i<ls.length;i++){ls[i].setAttribute("transform","rotate("+h+" "+ls[i]._x+" "+ls[i]._y+")")}}
function trueHeading(){return QB.norm(magH+dec)}
function render(force){
  var cd=$("cdial"),fin=$("fin"),ring=$("ring");
  if(!loc){fin.className="fin";fin.textContent="প্রথমে লোকেশন দিন";$("hdg").textContent="—";ring.style.transform="rotate(0deg)";upright(0);cd.classList.remove("ok");return}
  if(res&&res.km<0.05){fin.className="fin ok";fin.textContent="আপনি কাবার অতি নিকটে আছেন";return}
  if(!running||!got){
    ring.style.transform="rotate(0deg)";upright(0);cd.classList.remove("ok");aligned=false;
    $("hdg").textContent=fmtDeg(res.az,0);$("hlbl").textContent="কিবলা";
    fin.className="fin";
    fin.textContent=running?(hasSensor?"সেন্সর থেকে তথ্য আসছে…":"কম্পাস সেন্সর খোঁজা হচ্ছে…"):"কিবলার দিক ওপরে সংখ্যায় দেখুন, কম্পাস চালু করতে বাটনে চাপ দিন";
    return;
  }
  var h=trueHeading(),rel=QB.diff(res.az,h),ar=Math.abs(rel);
  ring.style.transform="rotate("+(-h)+"deg)";upright(h);
  $("hdg").textContent=fmtDeg(h,0);$("hlbl").textContent="আপনার দিক";
  var was=aligned;
  aligned=aligned?ar<=5:ar<=3;
  cd.classList.toggle("ok",aligned);
  if(aligned){fin.className="fin ok";fin.innerHTML=CHK+"আপনি কিবলার দিকে মুখ করে আছেন";if(!was&&navigator.vibrate)navigator.vibrate(35)}
  else{fin.className="fin";fin.textContent=(rel>0?"ডানে ":"বামে ")+bn(Math.round(ar))+"° ঘুরুন"}
}

/* ---------- sensors ---------- */
function screenAngle(){var a=(screen.orientation&&typeof screen.orientation.angle==="number")?screen.orientation.angle:(window.orientation||0);return a}
function eulerHeading(al,be,ga){
  var r=Math.PI/180,A=al*r,B=be*r,G=ga*r,cA=Math.cos(A),sA=Math.sin(A),cB=Math.cos(B),sB=Math.sin(B),cG=Math.cos(G),sG=Math.sin(G);
  var R11=cA*cG-sA*sB*sG,R12=-sA*cB,R13=cA*sG+sA*sB*cG,R21=sA*cG+cA*sB*sG,R22=cA*cB,R23=sA*sG-cA*sB*cG,R31=-cB*sG,R32=sB;
  var th=screenAngle()*r,ux=Math.sin(th),uy=Math.cos(th);
  var E=ux*R11+uy*R12,N=ux*R21+uy*R22,hm=Math.sqrt(E*E+N*N);
  if(hm<0.35){E=-R13;N=-R23}
  return QB.norm(QB.deg(Math.atan2(E,N)));
}
var rafId=0;
function push(h){
  var r=h*Math.PI/180;
  if(!got){sx=Math.sin(r);sy=Math.cos(r);got=true}
  else{var k=0.2;sx+=(Math.sin(r)-sx)*k;sy+=(Math.cos(r)-sy)*k}
  magH=QB.norm(QB.deg(Math.atan2(sx,sy)));hasSensor=true;
  if(!rafId)rafId=requestAnimationFrame(function(){rafId=0;render()});
}
function onAbs(e){if(e.alpha==null||e.beta==null||e.gamma==null)return;push(eulerHeading(e.alpha,e.beta,e.gamma))}
function onIOS(e){
  if(typeof e.webkitCompassHeading==="number"&&!isNaN(e.webkitCompassHeading)){
    accDeg=typeof e.webkitCompassAccuracy==="number"?e.webkitCompassAccuracy:null;showAcc();
    push(QB.norm(e.webkitCompassHeading+screenAngle()));
  }else if(e.absolute===true&&e.alpha!=null){push(eulerHeading(e.alpha,e.beta,e.gamma))}
}
function showAcc(){
  var el=$("acc");
  if(accDeg===null){el.hidden=false;el.className="acc";el.textContent="সেন্সরের নির্ভুলতা ফোনের ওপর নির্ভরশীল";return}
  el.hidden=false;
  if(accDeg<0||accDeg>25){el.className="acc b";el.textContent="সেন্সর ক্যালিব্রেট করুন — ফোন ৮ আকৃতিতে ঘোরান";}
  else if(accDeg>12){el.className="acc";el.textContent="সেন্সর নির্ভুলতা ±"+bn(Math.round(accDeg))+"° (মোটামুটি)"}
  else{el.className="acc g";el.textContent="সেন্সর নির্ভুলতা ±"+bn(Math.round(accDeg))+"° (ভালো)"}
}
function attach(){
  if("ondeviceorientationabsolute" in window){window.addEventListener("deviceorientationabsolute",onAbs,true)}
  else{window.addEventListener("deviceorientation",onIOS,true)}
}
function detach(){window.removeEventListener("deviceorientationabsolute",onAbs,true);window.removeEventListener("deviceorientation",onIOS,true)}
function needLocThenStart(){
  if(!loc)getLocation(true);
}
function startCompass(){
  var go=function(){
    running=true;got=false;hasSensor=false;attach();
    $("start").textContent="কম্পাস বন্ধ করুন";$("start").classList.add("stop");
    clearTimeout(watchdog);
    watchdog=setTimeout(function(){
      if(running&&!got){
        var f=$("fin");f.className="fin warn";
        f.textContent=secure?"এই ডিভাইসে কম্পাস সেন্সর পাওয়া যায়নি। ওপরের কিবলার দিক ("+fmtDeg(res?res.az:0,1)+") ব্যবহার করুন।":"সেন্সরের জন্য HTTPS (নিরাপদ সংযোগ) দরকার।";
      }
    },3000);
    render();
  };
  var DOE=window.DeviceOrientationEvent;
  if(DOE&&typeof DOE.requestPermission==="function"){
    DOE.requestPermission().then(function(s){
      if(s==="granted")go();else{var f=$("fin");f.className="fin warn";f.textContent="কম্পাসের অনুমতি দেওয়া হয়নি। সেটিংস থেকে অনুমতি দিন।"}
    }).catch(function(){var f=$("fin");f.className="fin warn";f.textContent="কম্পাসের অনুমতি পাওয়া যায়নি"});
  }else go();
  if(!loc)getLocation(false);
}
function stopCompass(){
  running=false;got=false;detach();clearTimeout(watchdog);aligned=false;
  $("start").textContent="কম্পাস চালু করুন";$("start").classList.remove("stop");$("acc").hidden=true;render();
}
$("start").onclick=function(){running?stopCompass():startCompass()};

/* ---------- location ---------- */
function getLocation(){
  var fin=$("fin");
  if(!navigator.geolocation){fin.className="fin warn";fin.textContent="এই ব্রাউজারে লোকেশন সুবিধা নেই। হাতে লোকেশন দিন।";return}
  fin.className="fin";fin.textContent="লোকেশন খোঁজা হচ্ছে…";
  navigator.geolocation.getCurrentPosition(function(p){
    setLoc(p.coords.latitude,p.coords.longitude,p.coords.accuracy,"gps");
  },function(err){
    fin.className="fin warn";
    fin.textContent=err&&err.code===1?"লোকেশনের অনুমতি দেওয়া হয়নি। অনুমতি দিন বা হাতে লোকেশন দিন।":"লোকেশন পাওয়া যায়নি। আবার চেষ্টা করুন বা হাতে দিন।";
  },{enableHighAccuracy:true,timeout:20000,maximumAge:0});
}
$("locBtn").onclick=getLocation;

/* ---------- manual sheet ---------- */
function openSheet(){$("veil").classList.add("on");$("sheet").classList.add("on");if(loc){$("inLat").value=loc.lat.toFixed(5);$("inLon").value=loc.lon.toFixed(5)}$("err").textContent=""}
function closeSheet(){$("veil").classList.remove("on");$("sheet").classList.remove("on")}
$("manBtn").onclick=openSheet;$("veil").onclick=closeSheet;
function en(s){return String(s).replace(/[০-৯]/g,function(d){return "০১২৩৪৫৬৭৮৯".indexOf(d)}).replace(/[,،]/g,".").replace(/\s+/g,"")}
$("saveLoc").onclick=function(){
  var la=$("inLat").value,lo=$("inLon").value;
  if(la.indexOf(",")>-1&&!lo){var pp=la.split(",");la=pp[0];lo=pp[1]}
  var lat=parseFloat(en(la)),lon=parseFloat(en(lo));
  if(isNaN(lat)||isNaN(lon)||lat<-90||lat>90||lon<-180||lon>180){$("err").textContent="সঠিক অক্ষাংশ (−৯০ থেকে ৯০) ও দ্রাঘিমাংশ (−১৮০ থেকে ১৮০) দিন";return}
  setLoc(lat,lon,0,"manual");closeSheet();
};
CITIES.forEach(function(c){
  var b=document.createElement("button");b.className="chip";b.textContent=c[0];
  b.onclick=function(){setLoc(c[1],c[2],0,"manual");closeSheet()};$("cities").appendChild(b);
});

updateLoc();compute();render(true);

