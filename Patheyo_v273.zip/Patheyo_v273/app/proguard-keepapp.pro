# v199 — অ্যাপের নিজের সব কোড (com.gunjoron.patheyo) ছাঁটাই ও নাম-বদল থেকে রক্ষা।
# শুধু লাইব্রেরি (Firebase, Media3, Material ইত্যাদি) ছোট হয় — আকার অনেকটা কমে, কিন্তু অ্যাপের কোডের রিফ্লেকশন/JS-ব্রিজ নিরাপদ।
-keep class com.gunjoron.patheyo.** { *; }
-keepclassmembers class com.gunjoron.patheyo.** { *; }
