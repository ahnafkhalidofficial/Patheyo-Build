# =============================================================================
# পাথেয় — রিলিজ বিল্ডের R8 নিয়ম (ধাপ ১২)
# R8 অব্যবহৃত কোড বাদ দেয় ও নাম ছোট করে (APK ছোট ও দ্রুত)। যা নাম ধরে খোঁজা হয় শুধু সেগুলো এখানে রক্ষা করা হলো।
# নতুন নেটিভ ↔ JS ব্রিজ যোগ করলে কিছু করতে হবে না — @JavascriptInterface থাকলেই নিচের নিয়মে রক্ষা পায়।
# =============================================================================

# ১) WebView-এর JS ব্রিজ: JS এই মেথডগুলো নাম ধরে ডাকে (PatheyoAuth.state(), AndroidWidgetBridge.saveAlarmConfigs() …)
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ২) WorkManager নাম ধরে Worker বানায় (লাইব্রেরির নিজের নিয়মও আছে — নিশ্চিত থাকার জন্য)
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# ৩) Google সাইন-ইন (Credential Manager) — অফিশিয়াল নির্দেশনা অনুযায়ী
-if class androidx.credentials.CredentialManager
-keep class androidx.credentials.playservices.** { *; }

# ৪) ক্র্যাশ রিপোর্টে লাইন নম্বর থাকুক (ফাইলের নাম লুকানো)
-keepattributes SourceFile,LineNumberTable,Signature,*Annotation*,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile

# ৫) এনাম (AlarmPermissionDialog.Step ইত্যাদি) values()/valueOf()
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ৬) সতর্কবার্তা চুপ (ঐচ্ছিক নির্ভরতা — আমাদের কোডে ব্যবহার নেই)
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn com.google.j2objc.annotations.**
