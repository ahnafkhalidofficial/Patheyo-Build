"""Tanzil Uthmani -> text for the app's KFGQPC 'Uthmanic Hafs v0.09' font (08-main.js data format)."""
import re, sys
SRC='/mnt/user-data/attachments/eb841900-0623-5079-8774-85cf9cb85e01/731b9528-1794578847884_quran-uthmani.xml'
OLD='/home/claude/work/Patheyo_v338/app/src/main/assets/features/quran/js/08-main.js'

def conv(t):
    t=t.replace('ْ','ۡ')      # sukun -> the font's Hafs sukun (same look as the existing text)
    t=t.replace('۟','۠')      # small high rounded zero: font draws it at U+06E0
    t=t.replace('ۭ','')            # small low meem (idgham/ikhfa tanween sign): font has no glyph
    t=t.replace('ۣ','ۜ')      # small low seen -> small high seen (88:22)
    t=t.replace('۪','').replace('۫','')  # empty-centre stops (11:41, 12:11): no glyph
    t=t.replace('۞','')            # rub-el-hizb sign: not part of the verse text
    t=re.sub(r' {2,}',' ',t).strip()
    t=re.sub(r' +(?=[ۖ-ۜ]\s*$)',' ',t)
    return t

def parse(s):
    d={}
    for m in re.finditer(r'<sura index="(\d+)" name="([^"]*)">(.*?)</sura>',s,re.S):
        d[int(m.group(1))]=(m.group(2),[(int(a),t,b) for a,t,b in re.findall(r'<aya index="(\d+)" text="([^"]*)"(?: bismillah="([^"]*)")?',m.group(3))])
    return d

def build():
    new=parse(open(SRC,encoding='utf-8').read())
    old=parse(open(OLD,encoding='utf-8').read())
    out={}
    for k,(name,ays) in new.items():
        res=[]
        if k==1:
            a=[conv(t) for _,t,_ in ays]
            last=a[6]; i=last.index('غَيۡرِ')
            parts=a[1:6]+[last[:i].strip(),last[i:].strip()]
            for n,t in enumerate(parts,1): res.append((n,t,None))
        else:
            for n,t,b in ays: res.append((n,conv(t),conv(b) if b else None))
        out[k]=(old[k][0],res)       # keep the existing sura name text
    return out,old
if __name__=='__main__':
    out,old=build()
    print(sum(len(v[1]) for v in out.values()))
    print(out[1][1][5:]); print(out[2][1][0])
