/* ধাপ ৭ + v239 — উইজেট হাব
   ১) প্রিভিউ উপরে আটকে গেলে (.is-stuck) ছোট হয় ও পর্দার দুই পাশ পর্যন্ত পুরো প্রস্থ নেয় (পাশে ফাঁক নেই)।
   ২) নিচে স্ক্রল করলে হেডার (ও শেলের ফুটার) লুকায়, প্রিভিউ উপরে উঠে যায়; উপরে স্ক্রল করলে হেডার ফিরে আসে, প্রিভিউ তার নিচে নামে।
   ৩) প্রিভিউ আটকালে নেটিভ থেকে ছোট ছবি চাওয়া হয় (কম কাজ)। */
(function () {
  'use strict';
  var box = document.getElementById('wh-prev');
  var header = document.querySelector('.app-header');
  if (!box) return;
  var mark = document.createElement('div');
  mark.style.cssText = 'height:1px;margin-top:-1px;pointer-events:none';
  box.parentNode.insertBefore(mark, box);

  var stuck = false, hidden = false, hdTop = -1, safe = 0;

  /* হেডারের নিচের কিনারা (লুকানো থাকলে ০) এবং স্ট্যাটাস বারের জায়গা */
  function measure() {
    var top = 0;
    if (header && !hidden) top = Math.max(0, Math.round(header.getBoundingClientRect().height));
    if (header) {
      var pt = parseFloat(getComputedStyle(header).paddingTop) || 0;
      safe = Math.max(0, Math.round(pt - 14));         /* শেল হেডারে ১৪px + স্ট্যাটাস বার দেয় */
      box.style.setProperty('--wh-safe', safe + 'px');
    }
    var want = hidden ? safe : top;
    if (want !== hdTop) { hdTop = want; box.style.top = want + 'px'; }
  }
  function setStuck(v) {
    if (v === stuck) return; stuck = v; box.classList.toggle('is-stuck', v);
    if (typeof window.wdRequestPreview === 'function') window.wdRequestPreview();   /* আকার বদলালে সঠিক মাপের ছবি */
  }
  function checkStuck() { setStuck(mark.getBoundingClientRect().top < hdTop - 24); }

  /* ---- হেডার লুকানো/ফেরা ---- */
  var HIDE_AFTER = 14, SHOW_AFTER = 28, FAST_PX = 1.1, USER_WINDOW = 1600, SETTLE = 450;
  var lastY = window.pageYOffset, lastT = Date.now(), acc = 0, userT = 0, moved = false, settleUntil = 0, ticking = false;
  function setHidden(v) {
    if (!header || v === hidden) return;
    hidden = v; header.classList.toggle('hdr-hidden', v);
    box.classList.toggle('hdr-gone', v); measure(); checkStuck();
  }
  function onScroll() {
    var y = Math.max(0, window.pageYOffset), now = Date.now();
    var dy = y - lastY, dt = Math.max(1, now - lastT); lastY = y; lastT = now;
    if (y <= 4) { acc = 0; setHidden(false); checkStuck(); return; }
    var a = document.activeElement;
    if (a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA')) { setHidden(false); checkStuck(); return; }
    if (now >= settleUntil && now - userT <= USER_WINDOW && header) {
      if (dy > 0) { acc = acc > 0 ? acc + dy : dy; if (acc >= HIDE_AFTER && y > header.offsetHeight) setHidden(true); }
      else if (dy < 0) { acc = acc < 0 ? acc + dy : dy; if (-acc >= SHOW_AFTER || (-dy / dt) >= FAST_PX) setHidden(false); }
    } else acc = 0;
    checkStuck();
  }
  window.addEventListener('scroll', function () {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () { ticking = false; onScroll(); });
  }, { passive: true });
  function markUser() { userT = Date.now(); }
  window.addEventListener('touchstart', function () { moved = false; }, { passive: true, capture: true });
  window.addEventListener('touchmove', function () { moved = true; markUser(); }, { passive: true, capture: true });
  window.addEventListener('touchend', function () { if (moved) markUser(); }, { passive: true, capture: true });
  window.addEventListener('wheel', markUser, { passive: true, capture: true });
  window.addEventListener('resize', function () {
    settleUntil = Date.now() + SETTLE; lastY = window.pageYOffset; acc = 0; hdTop = -1; measure(); checkStuck();
  });
  /* শেল বাইরে থেকে hdr-hidden সরালে (পেজ খোলার সময়) আমাদের অবস্থাও মিলিয়ে নেই */
  if (header && window.MutationObserver) {
    new MutationObserver(function () {
      var h = header.classList.contains('hdr-hidden');
      if (h !== hidden) { hidden = h; box.classList.toggle('hdr-gone', h); measure(); checkStuck(); }
    }).observe(header, { attributes: true, attributeFilter: ['class'] });
  }
  /* শেল কোড থেকে হেডার ফেরাতে চাইলে (পেজ খোলার সময়) */
  window.WidgetHubApp = { showHeader: function () { setHidden(false); } };

  setTimeout(function () { measure(); checkStuck(); }, 400);
  measure(); checkStuck();
})();
