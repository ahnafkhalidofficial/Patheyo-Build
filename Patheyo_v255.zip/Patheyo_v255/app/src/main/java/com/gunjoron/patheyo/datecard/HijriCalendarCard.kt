package com.gunjoron.patheyo.datecard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.RectF
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.calnote.CalNote
import com.gunjoron.patheyo.calnote.CalNotes
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import java.util.Calendar

/**
 * v243: ত্রি-পঞ্জিকা ক্যালেন্ডার — ইংরেজি মাসের আসল ক্যালেন্ডার-গ্রিড, প্রতিটি ঘরে তিনটি তারিখ (ইংরেজি · বাংলা · হিজরি),
 * আগের/পরের মাসে যাওয়ার বোতাম, ঘরে চাপলে ওই দিনের তিন তারিখের বিস্তারিত, আর নিচে আসন্ন বিশেষ দিন।
 * আজকের হিজরি তারিখ আসে হোম/উইজেটের একই হিসাব ([Snapshot]) থেকে — তাই ফায়ারবেস-অ্যাডজাস্টমেন্ট মেনে চলে;
 * অন্য দিনের হিজরি তারিখ = ফোনের সূত্র + ওই অ্যাডজাস্টমেন্টের পার্থক্য। বাংলা তারিখ সংশোধিত পঞ্জিকা (পহেলা বৈশাখ = ১৪ এপ্রিল)।
 *
 * v244: যেকোনো তারিখে নোট (সময় + নোটিফিকেশন/এলার্ম/দুটোই/কিছু না)। নোট-থাকা তারিখের ঘর পান্না-সবুজ ঘেরা + নিচে সবুজ বিন্দু,
 * মাসের মাথায় "এই মাসে নোট N টি", দিনের প্যানেলে নোটের তালিকা ও "+ নোট যোগ", আর নিচে "আসন্ন নোট"।
 */
class HijriCalendarCard(private val ctx: Context, private val p: Pal, private val host: Host? = null, private val vs: ViewState? = null) {

    class Pal(
        val surf: Int, val surfHi: Int, val surf2: Int, val line: Int,
        val text: Int, val text2: Int, val text3: Int,
        val primary: Int, val press: Int, val onPrimary: Int, val primaryText: Int,
        val gold: Int, val goldLine: Int, val goldSoft: Int,
        val bold: Typeface, val reg: Typeface,
        /** v244: নোট-চিহ্নের পান্না-সবুজ রং (ডিজাইন-সিস্টেমের success টোকেন) */
        val ok: Int = Color.parseColor("#22A06B"), val okText: Int = Color.parseColor("#5FD49A"), val okSoft: Int = Color.parseColor("#2922A06B")
    )

    class Ev(val m: Int, val d: Int, val t: String, val s: String? = null)
    class Up(val k: Int, val g: Calendar, val title: String, val sub: String?, val day: Int, val month: Int)
    class H(val day: Int, val month: Int, val year: Int)

    /** v244: নোট সেভ করার আগে অনুমতি চাওয়া ও নোট বদলালে ক্যালেন্ডার নতুন করে আঁকার জন্য হোস্ট-অ্যাক্টিভিটির হুক */
    interface Host {
        fun ensureNotePermissions(mode: Int, done: () -> Unit)
        fun onNotesChanged()
        /** v245: আর্কাইভের লগইন-সতর্কতা থেকে লগইন (অ্যাপের "আরও" ট্যাব) খোলা */
        fun openLogin()
        /** v245: "এক নজরে"-র তারিখ-চিপে চাপলে নিচের মাসিক ক্যালেন্ডারে নিয়ে যাওয়া */
        fun scrollToCalendar()
        /** v248: ক্যালেন্ডারের নিচের "ওপরে নোট দেখুন" বোতাম — ওপরের নোট-অংশে নিয়ে যাওয়া */
        fun scrollToView(v: View)
    }

    /** v244: ক্যালেন্ডার নতুন করে আঁকলেও (অ্যাপে ফিরলে/নোট বদলালে) যেন বাছা মাস ও দিন হারিয়ে না যায় */
    class ViewState(var y: Int = -1, var m: Int = 0, var d: Int = 0) {
        /** v245: "আরও দেখুন" খোলা কি না — দিনের নোট / আসন্ন নোট; lastKey বদলালে (অন্য দিন বাছলে) দিনের নোট আবার গুটিয়ে যায় */
        var expDay = false; var expUp = false; var lastKey = 0
    }

    companion object {
        /** মাসের নাম — নামাজ ফিচারের hijriMonthsBN-এর সাথে হুবহু */
        val MONTHS = arrayOf(
            "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল উলা", "জমাদিউস সানি",
            "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
        )
        private val EVENTS = listOf(
            Ev(0, 1, "হিজরি নববর্ষ"),
            Ev(0, 10, "আশুরা", "৯ ও ১০ বা ১০ ও ১১ মুহাররম রোজা"),
            Ev(6, 26, "শবে মিরাজ", "২৬ রজব দিবাগত রাত"),
            Ev(7, 14, "শবে বরাত", "১৪ শাবান দিবাগত রাত"),
            Ev(8, 1, "রমজান শুরু", "প্রথম রোজা (চাঁদ দেখা সাপেক্ষে)"),
            Ev(8, 26, "শবে কদর", "২৬ রমজান দিবাগত রাত"),
            Ev(9, 1, "ঈদুল ফিতর", "আজ রোজা রাখা হারাম"),
            Ev(11, 9, "আরাফাহর দিন", "নফল রোজা — দুই বছরের গুনাহ মাফ"),
            Ev(11, 10, "ঈদুল আজহা", "কোরবানির দিন")
        )
        private val WD = arrayOf("শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র")
        private val WD_FULL = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

        // ---------------------------------------------------------------- হিসাব

        private fun midnight(base: Calendar, plusDays: Int): Calendar =
            (base.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.DAY_OF_YEAR, plusDays)
            }

        /** Tabular Islamic Calendar (অ্যাডজাস্টমেন্ট ছাড়া) — ওয়েবের localGregorianToHijri(date, true)-এর সমান */
        private fun tabular(c: Calendar): H {
            val y = c.get(Calendar.YEAR); val m = c.get(Calendar.MONTH) + 1; val d = c.get(Calendar.DAY_OF_MONTH)
            val a = (14 - m) / 12
            val y2 = y + 4800 - a
            val m2 = m + 12 * a - 3
            val jdn = d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 - 32045
            var l = jdn - 1948440 + 10632
            val n = (l - 1) / 10631
            l = l - 10631 * n + 354
            val j = (10985 - l) / 5316 * (50 * l / 17719) + (l / 5670) * (43 * l / 15238)
            l = l - (30 - j) / 15 * (17719 * j / 50) - (j / 16) * (15238 * j / 43) + 29
            val month = (24 * l) / 709
            val day = l - (709 * month) / 24
            return H(day, month - 1, 30 * n + j - 30)
        }

        class B(val day: Int, val month: Int, val year: Int)

        /** বাংলা তারিখ (বাংলাদেশ সংশোধিত পঞ্জিকা, পহেলা বৈশাখ = ১৪ এপ্রিল) — Snapshot.banglaOf-এর সমান হিসাব, যেকোনো দিনের জন্য */
        fun banglaOf(c: Calendar): B {
            val now = midnight(c, 0)
            val gYear = now.get(Calendar.YEAR)
            fun leap(y: Int) = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)
            var bYear = gYear - 593
            var poyla = (now.clone() as Calendar).apply { set(gYear, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            if (now.timeInMillis < poyla.timeInMillis) {
                bYear -= 1
                poyla = (now.clone() as Calendar).apply { set(gYear - 1, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            }
            val diff = Math.round((now.timeInMillis - poyla.timeInMillis) / 86400000.0).toInt()
            // বাংলা বছরের মাসের দিন-সংখ্যা: ফাল্গুন বাংলা বছরের শেষ দিকে পড়ে (পরের ইংরেজি বছরের ফেব্রুয়ারি) — তাই লিপ-ইয়ার পোয়লার ইংরেজি বছর ধরে
            val polYear = poyla.get(Calendar.YEAR)
            val dm = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (leap(polYear + 1)) 30 else 29, 30)
            var mi = 0; var bd = diff + 1
            while (mi < dm.size - 1 && bd > dm[mi]) { bd -= dm[mi]; mi++ }
            return B(bd, mi, bYear)
        }

        private fun monthIndexOf(name: String): Int {
            val n = name.trim()
            for (i in MONTHS.indices) if (n == MONTHS[i]) return i
            for (i in Bn.HIJRI_MONTHS.indices) if (n == Bn.HIJRI_MONTHS[i]) return i
            for (i in MONTHS.indices) if (n.contains(MONTHS[i]) || MONTHS[i].contains(n)) return i
            return -1
        }

        /**
         * হিজরি তারিখ ঠিক [atMs] সময়ে — হোম/উইজেটের একই উৎস ([Snapshot]) থেকে, তাই ফায়ারবেসের hijri_adjustment /
         * hijri_override / মাগরিব-শিফট সব মেনে চলে। না পেলে ফোনের সূত্র + সেভ করা অ্যাডজাস্টমেন্ট।
         */
        private fun hijriAt(ctx: Context, atMs: Long, civil: Calendar): H {
            try {
                val snap = Snapshot.build(ctx.applicationContext, atMs)
                val day = FirebaseDataManager.convertBengaliToEnglish(snap.hijriDay).trim().toIntOrNull()
                val year = FirebaseDataManager.convertBengaliToEnglish(snap.hijriYear).trim().toIntOrNull()
                val mi = monthIndexOf(snap.hijriMonth)
                if (day != null && year != null && mi >= 0 && day in 1..30) return H(day, mi, year)
            } catch (_: Throwable) {}
            val adj = try { ctx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE).getInt("last_rtdb_adjustment", 0) } catch (_: Throwable) { 0 }
            return tabular(midnight(civil, adj))
        }

        /** ক্যালেন্ডারের সঠিক "চিহ্ন" (এখন অ্যাপের হোমে যে হিজরি তারিখ দেখায়) — বদলালে ক্যালেন্ডার নতুন করে আঁকতে হয় */
        fun signature(ctx: Context): String {
            val civil = midnight(Calendar.getInstance(), 0)
            val h = hijriAt(ctx, System.currentTimeMillis(), civil)
            return "${h.day}-${h.month}-${h.year}|${civil.get(Calendar.DAY_OF_YEAR)}"
        }
    }

    // ---- v248: বাছা মাস/দিন ও নোট-অংশ এখন কার্ডের নিজস্ব অবস্থা — ওপরের "এক নজরে" কার্ডের নোট-অংশ
    //      আর নিচের মাসিক ক্যালেন্ডার একই বাছা দিন দেখায় (ক্যালেন্ডারে দিন বাছলে ওপরের নোট বদলায়)
    private val today0: Calendar = midnight(Calendar.getInstance(), 0)
    private val todayY0 = today0.get(Calendar.YEAR)
    private val todayM0 = today0.get(Calendar.MONTH)
    private val todayD0 = today0.get(Calendar.DAY_OF_MONTH)
    private var vy = todayY0
    private var vm = todayM0
    private var sel = todayD0
    private var expDay = vs?.expDay ?: false
    private var lastKey = vs?.lastKey ?: 0
    private var notesBox: LinearLayout? = null
    private var renderCal: (() -> Unit)? = null

    init {
        if (vs != null && vs.y in 1950..2100) { vy = vs.y; vm = vs.m.coerceIn(0, 11); sel = vs.d.coerceAtLeast(1) }
    }

    /** ক্যালেন্ডারের ঘরের জন্য: মাগরিব-শিফট ছাড়া (ইংরেজি দিনের নিজের) হিজরি তারিখের পার্থক্য */
    private val delta0: Int by lazy {
        val base = hijriAt(ctx, today0.timeInMillis + 60_000L, today0)
        var d0 = 0
        for (d in -3..3) { val x = tabular(midnight(today0, d)); if (x.day == base.day && x.month == base.month) { d0 = d; break } }
        d0
    }
    private fun hijriOf(g: Calendar): H = tabular(midnight(g, delta0))
    private fun isWhiteDay(h: H) = h.day in 13..15 && h.month != 8 && !(h.month == 11 && h.day >= 11)

    private val okLine: Int get() = (p.ok and 0x00FFFFFF) or 0xAA000000.toInt()
    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * ctx.resources.displayMetrics.density

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text; textSize = size; setTextColor(color); typeface = if (bold) p.bold else p.reg
    }

    private class StarDrawable(private val col: Int) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        override fun draw(cv: Canvas) {
            paint.color = col
            val s = bounds.width() / 100f
            val pts = floatArrayOf(50f, 1f, 64f, 15f, 85f, 15f, 85f, 36f, 99f, 50f, 85f, 64f, 85f, 85f, 64f, 85f, 50f, 99f, 36f, 85f, 15f, 85f, 15f, 64f, 1f, 50f, 15f, 36f, 15f, 15f, 36f, 15f)
            val path = Path()
            var i = 0
            while (i < pts.size) { val x = bounds.left + pts[i] * s; val y = bounds.top + pts[i + 1] * s; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y); i += 2 }
            path.close(); cv.drawPath(path, paint)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    private fun dot(size: Int, color: Int) = View(ctx).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        layoutParams = LinearLayout.LayoutParams(size, size)
    }

    private class Chev(private val dir: Int, private val col: Int) : Drawable() {
        private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        override fun draw(cv: Canvas) {
            pt.color = col; pt.strokeWidth = bounds.width() * 0.09f
            val w = bounds.width().toFloat(); val cx = bounds.exactCenterX(); val cy = bounds.exactCenterY()
            val path = Path()
            path.moveTo(cx - dir * w * 0.09f, cy - w * 0.17f); path.lineTo(cx + dir * w * 0.09f, cy); path.lineTo(cx - dir * w * 0.09f, cy + w * 0.17f)
            cv.drawPath(path, pt)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    private fun hijriSpan(a: H, b: H): String =
        if (a.month == b.month && a.year == b.year) "${MONTHS[a.month]} ${Bn.digits(a.year)}"
        else if (a.year == b.year) "${MONTHS[a.month]} – ${MONTHS[b.month]} ${Bn.digits(a.year)}"
        else "${MONTHS[a.month]} ${Bn.digits(a.year)} – ${MONTHS[b.month]} ${Bn.digits(b.year)}"

    private fun banglaSpan(a: B, b: B): String =
        if (a.month == b.month && a.year == b.year) "${Bn.BANGLA_MONTHS[a.month]} ${Bn.digits(a.year)}"
        else if (a.year == b.year) "${Bn.BANGLA_MONTHS[a.month]} – ${Bn.BANGLA_MONTHS[b.month]} ${Bn.digits(a.year)}"
        else "${Bn.BANGLA_MONTHS[a.month]} ${Bn.digits(a.year)} – ${Bn.BANGLA_MONTHS[b.month]} ${Bn.digits(b.year)}"

    private fun tagged(label: String, labelCol: Int, value: String, valueCol: Int): CharSequence {
        val sb = SpannableStringBuilder()
        sb.append(label); sb.setSpan(ForegroundColorSpan(labelCol), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val st = sb.length; sb.append("  ").append(value)
        sb.setSpan(ForegroundColorSpan(valueCol), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    // ---------------------------------------------------------------- গঠন

    fun build(): View {
        val civil = midnight(Calendar.getInstance(), 0)
        // অ্যাপের হোমে এখন যে হিজরি তারিখ দেখায় (মাগরিবের পর পরের দিন)
        val shown = hijriAt(ctx, System.currentTimeMillis(), civil)
        val base = hijriAt(ctx, civil.timeInMillis + 60_000L, civil)       // একই দিনের মাগরিব-শিফট ছাড়া তারিখ
        val shift = if (shown.day == base.day && shown.month == base.month && shown.year == base.year) 0 else 1
        val now = midnight(civil, shift)      // দেখানো হিজরি দিনটির সাথে মেলানো ইংরেজি তারিখ
        val h0 = shown

        // হিজরি ↔ ফোনের সূত্রের পার্থক্য (দিন) — ওয়েবের nzHijriDelta
        var delta = 0
        for (d in -3..3) { val x = tabular(midnight(now, d)); if (x.day == h0.day && x.month == h0.month) { delta = d; break } }

        val todayY = civil.get(Calendar.YEAR); val todayM = civil.get(Calendar.MONTH); val todayD = civil.get(Calendar.DAY_OF_MONTH)

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surfHi, p.surf)).apply {
                cornerRadius = dpf(24f); setStroke(dp(1), p.line)
            }
        }
        val dyn = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        card.addView(dyn, LinearLayout.LayoutParams(-1, -2))

        val cellW = (ctx.resources.displayMetrics.widthPixels - dp(32) - dp(28)) / 7
        val cellH = maxOf(dp(58), (cellW * 1.36f).toInt())
        val todayWhite = Color.WHITE; val todayGold = Color.parseColor("#FFE3A0")

        fun navBtn(dir: Int, onClick: () -> Unit) = View(ctx).apply {
            background = android.graphics.drawable.LayerDrawable(arrayOf(
                GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(p.surf2); setStroke(dp(1), p.line) },
                Chev(dir, p.text)
            ))
            contentDescription = if (dir < 0) "আগের মাস" else "পরের মাস"
            setOnClickListener { onClick() }
        }

        lateinit var render: () -> Unit
        fun go(dm: Int) {
            val c = Calendar.getInstance().apply { clear(); set(vy, vm, 1); add(Calendar.MONTH, dm) }
            val ny = c.get(Calendar.YEAR)
            if (ny < 1950 || ny > 2100) return
            vy = ny; vm = c.get(Calendar.MONTH)
            sel = if (vy == todayY && vm == todayM) todayD else 1
            dyn.animate().cancel(); dyn.alpha = 0.15f; render(); dyn.animate().alpha(1f).setDuration(160).start()
        }

        render = {
            dyn.removeAllViews()
            val first = Calendar.getInstance().apply { clear(); set(vy, vm, 1) }
            val len = first.getActualMaximum(Calendar.DAY_OF_MONTH)
            val last = midnight(first, len - 1)
            val lead = (((first.get(Calendar.DAY_OF_WEEK) - 1) + 1) % 7)      // শনিবার থেকে সপ্তাহ
            val isCur = vy == todayY && vm == todayM
            if (sel > len) sel = len
            vs?.let { it.y = vy; it.m = vm; it.d = sel }
            if (vy * 10000 + vm * 100 + sel != lastKey) { lastKey = vy * 10000 + vm * 100 + sel; expDay = false }   // অন্য দিন বাছলে নোট আবার গুটিয়ে যায়
            vs?.let { it.expDay = expDay; it.lastKey = lastKey }
            val noteCounts = CalNotes.countsForMonth(ctx, vy, vm)
            val monthNotes = noteCounts.values.sum()

            // ---------- মাথা: ‹  মাসের নাম + বাংলা/হিজরি মাস  ›
            val nav = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            nav.addView(navBtn(-1) { go(-1) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            mid.addView(tv("${Bn.GREG_MONTHS[vm]} ${Bn.digits(vy)}", 21f, p.text, true).apply { gravity = Gravity.CENTER })
            mid.addView(TextView(ctx).apply {
                text = tagged("বাংলা", p.primaryText, banglaSpan(banglaOf(first), banglaOf(last)), p.text2)
                textSize = 11.5f; typeface = p.reg; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0)
            })
            mid.addView(TextView(ctx).apply {
                text = tagged("হিজরি", p.gold, hijriSpan(hijriOf(first), hijriOf(last)), p.text2)
                textSize = 11.5f; typeface = p.reg; gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0)
            })
            if (monthNotes > 0) mid.addView(tv("এই মাসে নোট ${Bn.digits(monthNotes)}টি", 11f, p.okText, true).apply {
                gravity = Gravity.CENTER; setPadding(dp(10), dp(3), dp(10), dp(3))
                background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.okSoft); setStroke(dp(1), okLine) }
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(7) })
            nav.addView(mid, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6); rightMargin = dp(6) })
            nav.addView(navBtn(1) { go(1) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            dyn.addView(nav, LinearLayout.LayoutParams(-1, -2))

            // ---------- v250: ঘর-টানা (রুলড) ক্যালেন্ডার — গোল-কোনা বাইরের ফ্রেম, হেডার-সারি, প্রতিটি দিন সরু রেখায় ঘেরা ঘরে
            // কৌশল: ফ্রেমের পেছনে রেখার রং, ঘরগুলোর মাঝে ১dp ফাঁক — তাই সব রেখা সমান সরু ও পরিষ্কার
            val grid = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(1), dp(1), dp(1), dp(1))
                background = GradientDrawable().apply { cornerRadius = dpf(18f); setColor(p.line) }
                clipToOutline = true; outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            }
            val blankBg = mix(p.surf, p.surf2, 0.6f)
            fun put(r: LinearLayout, v: View, h: Int, c: Int) { r.addView(v, LinearLayout.LayoutParams(0, h, 1f).apply { if (c < 6) rightMargin = dp(1) }) }

            // সপ্তাহের দিনের হেডার-সারি
            val hdr = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            WD.forEachIndexed { i, w ->
                put(hdr, tv(w, 11.5f, if (i == 6) p.gold else p.text2, true).apply { gravity = Gravity.CENTER; setBackgroundColor(p.surf2) }, dp(34), i)
            }
            grid.addView(hdr, LinearLayout.LayoutParams(-1, -2))

            var row: LinearLayout? = null
            var col = 0
            fun newRow() { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; grid.addView(row, LinearLayout.LayoutParams(-1, cellH).apply { topMargin = dp(1) }); col = 0 }
            fun blank() { put(row!!, View(ctx).apply { setBackgroundColor(blankBg) }, cellH, col); col++ }
            newRow()
            for (i in 0 until lead) blank()
            for (d in 1..len) {
                if (col == 7) newRow()
                val g = midnight(first, d - 1)
                val hj = hijriOf(g); val bn = banglaOf(g)
                val ev = EVENTS.firstOrNull { it.m == hj.month && it.d == hj.day }
                val white = hj.day in 13..15 && hj.month != 8 && !(hj.month == 11 && hj.day >= 11)
                val isT = isCur && d == todayD
                val past = isCur && d < todayD || (vy < todayY) || (vy == todayY && vm < todayM)
                val jsDow = g.get(Calendar.DAY_OF_WEEK) - 1
                val nc = noteCounts[d] ?: 0
                val cellView = cell(d, bn, hj, isT, d == sel, past, white, ev, jsDow == 5, todayWhite, todayGold, nc)
                cellView.setOnClickListener { sel = d; render(); showDaySheet(vy, vm, d) }      // v251: চাপলে দিনের শিট — বিশেষ আমল + নোট যোগ
                cellView.contentDescription = "${Bn.digits(d)} ${Bn.GREG_MONTHS[vm]}, ${WD_FULL[jsDow]} · বাংলা ${Bn.digits(bn.day)} ${Bn.BANGLA_MONTHS[bn.month]} · হিজরি ${Bn.digits(hj.day)} ${MONTHS[hj.month]}" +
                    (if (ev != null) " · ${ev.t}" else "") + (if (nc > 0) " · নোট আছে (${Bn.digits(nc)}টি)" else "")
                put(row!!, cellView, cellH, col); col++
            }
            while (col in 1..6) blank()
            dyn.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

            // ---------- ইঙ্গিত + "আজ" বোতাম
            val key = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(12), dp(2), 0) }
            key.addView(View(ctx).apply { background = StarDrawable(p.gold) }, LinearLayout.LayoutParams(dp(9), dp(9)))
            key.addView(tv("বিশেষ দিন", 11f, p.text3).apply { setPadding(dp(4), 0, dp(12), 0) })
            key.addView(dot(dp(6), p.primaryText))
            key.addView(tv("আইয়ামে বিয (সুন্নাত রোজা)", 11f, p.text3).apply { setPadding(dp(4), 0, 0, 0) })
            key.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
            key.addView(tv("আজ", 12f, p.gold, true).apply {
                gravity = Gravity.CENTER; setPadding(dp(14), dp(5), dp(14), dp(5))
                background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.goldSoft); setStroke(dp(1), p.goldLine) }
                visibility = if (isCur) View.INVISIBLE else View.VISIBLE
                setOnClickListener { vy = todayY; vm = todayM; sel = todayD; dyn.alpha = 0.15f; render(); dyn.animate().alpha(1f).setDuration(160).start() }
            })
            dyn.addView(key, LinearLayout.LayoutParams(-1, -2))
            val key2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(9), dp(2), 0) }
            key2.addView(View(ctx).apply { background = GradientDrawable().apply { cornerRadius = dpf(4f); setColor(p.okSoft); setStroke(dp(1), okLine) } }, LinearLayout.LayoutParams(dp(12), dp(12)))
            key2.addView(tv("তারিখে চাপলে ওই দিনের বিশেষ আমল ও নোট যোগ করার শিট খোলে", 11f, p.text3).apply { setPadding(dp(6), 0, 0, 0) })
            dyn.addView(key2, LinearLayout.LayoutParams(-1, -2))

            // ওপরের নোট-অংশ বাছা দিনের সাথে মিলিয়ে নেওয়া
            renderNotes()
        }
        renderCal = { dyn.animate().cancel(); dyn.alpha = 0.15f; render(); dyn.animate().alpha(1f).setDuration(160).start() }
        render()

        // ---------- v244: আসন্ন নোট (আজ বা পরের তারিখের)
        val upAll = CalNotes.upcoming(ctx, 5)
        val expUp = vs?.expUp ?: false
        val upNotes = if (expUp) upAll else upAll.take(1)
        if (upNotes.isNotEmpty()) {
            card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(20) })
            card.addView(tv("আসন্ন নোট", 15f, p.text, true).apply { setPadding(0, dp(16), 0, dp(4)) })
            upNotes.forEachIndexed { i, n ->
                if (i > 0) card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)))
                card.addView(upNoteRow(n, civil).apply {
                    setOnClickListener { selectDay(n.y, n.m, n.d); notesBox?.let { host?.scrollToView(it) } }
                })
            }
            if (upAll.size > 1) card.addView(moreToggle(upAll.size - 1, expUp) { vs?.expUp = !expUp; if (host != null) host.onNotesChanged() },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8); gravity = Gravity.CENTER_HORIZONTAL })
        }

        // ---------- আসন্ন বিশেষ দিন
        val ups = ArrayList<Up>()
        val seen = HashSet<String>()
        var seenWhite = false
        var k = 0
        while (k < 400 && ups.size < 12) {
            val x = tabular(midnight(now, k + delta)); val g = midnight(now, k)
            for (e in EVENTS) if (e.m == x.month && e.d == x.day && seen.add(e.t)) ups.add(Up(k, g, e.t, e.s, x.day, x.month))
            if (!seenWhite && x.day == 13 && k > 0 && x.month != 11) { seenWhite = true; ups.add(Up(k, g, "আইয়ামে বিয রোজা", "১৩, ১৪ ও ১৫ তারিখ — সুন্নাত রোজা", x.day, x.month)) }
            k++
        }
        ups.sortBy { it.k }

        card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(20) })
        card.addView(tv("আসন্ন বিশেষ দিন", 15f, p.text, true).apply { setPadding(0, dp(16), 0, dp(4)) })
        ups.take(4).forEachIndexed { i, u ->
            if (i > 0) card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)))
            card.addView(eventRow(u))
        }
        card.addView(tv("চাঁদ দেখার ওপর ভিত্তি করে হিজরি তারিখ এক দিন আগে-পরে হতে পারে।", 11f, p.text3).apply { setPadding(0, dp(12), 0, 0) })
        return card
    }

    /** v245: "আরও N টি দেখুন ▾" / "কম দেখান ▴" বোতাম */
    private fun moreToggle(n: Int, expanded: Boolean, onClick: () -> Unit): TextView =
        tv(if (expanded) "কম দেখান  ▴" else "আরও ${Bn.digits(n)}টি দেখুন  ▾", 12.5f, p.okText, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.okSoft); setStroke(dp(1), okLine) }
            setOnClickListener { onClick() }
        }

    /**
     * v245: পেজের একদম ওপরের "এক নজরে" কার্ড — আজকের তিন তারিখ + কোন কোন তারিখে এলার্ম/রিমাইন্ডার সেট আছে
     * (চিপে চাপলে ওই তারিখ বাছা হয়) + আর্কাইভ বোতাম।
     * v248: এর নিচে বাছা দিনের "নোট" অংশ (+ নোট যোগ, সম্পাদনা, মুছুন) — ক্যালেন্ডারের ভেতরে আর নেই।
     */
    fun buildGlance(): View {
        val civil = midnight(Calendar.getInstance(), 0)
        val shown = hijriAt(ctx, System.currentTimeMillis(), civil)        // হোমের মতো (মাগরিবের পর পরের দিন)
        val bnToday = banglaOf(civil)
        val dow = civil.get(Calendar.DAY_OF_WEEK) - 1
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surfHi, p.surf)).apply {
                cornerRadius = dpf(24f); setStroke(dp(1), p.line)
            }
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv(WD_FULL[dow], 18f, if (dow == 5) p.gold else p.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(tv("আজ", 11.5f, p.onPrimary, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(12), dp(4), dp(12), dp(4))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(50f) }
        })
        card.addView(head)
        fun line(c: Int, label: String, v: String) {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
            r.addView(dot(dp(8), c), LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(10) })
            r.addView(tv(label, 12.5f, p.text3), LinearLayout.LayoutParams(dp(54), -2))
            r.addView(tv(v, 14.5f, p.text, true), LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        card.getChildAt(0).setPadding(0, 0, 0, dp(6))
        line(p.text2, "ইংরেজি", "${Bn.digits(civil.get(Calendar.DAY_OF_MONTH))} ${Bn.GREG_MONTHS[civil.get(Calendar.MONTH)]} ${Bn.digits(civil.get(Calendar.YEAR))}")
        line(p.primaryText, "বাংলা", "${Bn.digits(bnToday.day)} ${Bn.BANGLA_MONTHS[bnToday.month]} ${Bn.digits(bnToday.year)}")
        line(p.gold, "হিজরি", "${Bn.digits(shown.day)} ${MONTHS[shown.month]} ${Bn.digits(shown.year)}")
        // v248: মাগরিবের পর হোম পরের হিজরি দিন দেখালে সেই কথা (আগে নিচের দিন-প্যানেলে ছিল)
        val baseH = hijriAt(ctx, civil.timeInMillis + 60_000L, civil)
        if (shown.day != baseH.day || shown.month != baseH.month || shown.year != baseH.year)
            card.addView(tv("মাগরিবের পর হিজরি তারিখ পরের দিনে গেছে (হোমের মতো)", 11f, p.text3).apply { setPadding(dp(18), dp(2), 0, 0) })

        card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12) })
        val rh = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(8)) }
        rh.addView(tv("এলার্ম ও রিমাইন্ডার", 14.5f, p.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        val arch = CalNotes.archivedCount(ctx)
        rh.addView(tv(if (arch > 0) "আর্কাইভ · ${Bn.digits(arch)}  ›" else "আর্কাইভ  ›", 12f, p.text2, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.surf2); setStroke(dp(1), p.line) }
            setOnClickListener { CalNoteArchiveDialog(ctx, p).show(host) { host?.onNotesChanged() } }
        })
        card.addView(rh)

        val rem = CalNotes.upcomingReminders(ctx, 12)
        if (rem.isEmpty()) {
            card.addView(tv("কোনো এলার্ম বা রিমাইন্ডার সেট করা নেই। নিচের \"নোট\" অংশে নোট যোগ করে সময়মতো মনে করাতে পারেন।", 12f, p.text3).apply { setLineSpacing(0f, 1.25f) })
        } else {
            val strip = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (n in rem) {
                val alarm = n.wantsAlarm
                val accent = if (alarm) p.gold else p.okText
                val chip = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(9), dp(14), dp(9))
                    background = GradientDrawable().apply {
                        cornerRadius = dpf(14f); setColor(if (alarm) p.goldSoft else p.okSoft)
                        setStroke(dp(1), if (alarm) p.goldLine else okLine)
                    }
                    contentDescription = "${Bn.digits(n.d)} ${Bn.GREG_MONTHS[n.m]}, ${CalNotes.fmtTime(n.minutes)}, ${CalNotes.modeLabel(n.mode)}। ক্যালেন্ডারে দেখতে চাপুন"
                    setOnClickListener { selectDay(n.y, n.m, n.d) }        // v248: ওই তারিখ বাছা হয়, নিচের নোট-অংশে তার নোট আসে
                }
                chip.addView(tv("${Bn.digits(n.d)} ${Bn.GREG_MONTHS[n.m]}", 14f, p.text, true))
                chip.addView(tv(CalNotes.fmtTime(n.minutes), 12f, accent, true).apply { setPadding(0, dp(3), 0, 0) })
                chip.addView(tv(CalNotes.modeLabel(n.mode), 10.5f, p.text3).apply { setPadding(0, dp(2), 0, 0) })
                strip.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
            }
            card.addView(android.widget.HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(strip) },
                LinearLayout.LayoutParams(-1, -2))
        }

        // ---------- v248: বাছা দিনের নোট (+ নোট যোগ · সম্পাদনা · মুছুন) — আগে মাসিক ক্যালেন্ডারের নিচে ছিল
        card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(16) })
        val nb = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        notesBox = nb
        card.addView(nb, LinearLayout.LayoutParams(-1, -2))
        renderNotes()
        return card
    }

    /** v248: বাছা দিন বদলানো — নিচের ক্যালেন্ডার ও ওপরের নোট-অংশ দুটোই মেলে */
    private fun selectDay(y: Int, m: Int, d: Int) {
        vy = y; vm = m; sel = d
        vs?.let { it.y = y; it.m = m; it.d = d }
        val r = renderCal
        if (r != null) r() else renderNotes()
    }

    /** v248: নোট বদলালে (যোগ/সম্পাদনা/মোছা) হোস্ট সবটা নতুন করে আঁকে; হোস্ট না থাকলে শুধু এই কার্ড */
    private fun onChanged() {
        if (host != null) host.onNotesChanged() else { val r = renderCal; if (r != null) r() else renderNotes() }
    }

    private fun openNoteDialog(n: CalNote?) {
        CalNoteDialog(ctx, p).show(vy, vm, sel, n, host) { ny, nm, nd ->
            vy = ny; vm = nm; sel = nd                      // নোট অন্য দিনে সরালে ক্যালেন্ডারও সেই দিনে যায়
            vs?.let { it.y = ny; it.m = nm; it.d = nd }
            onChanged()
        }
    }

    // v246: সরাসরি "মুছুন" বোতাম — নিশ্চিত করে তবেই মোছে
    private fun confirmDelete(n: CalNote, after: () -> Unit = {}) {
        android.app.AlertDialog.Builder(ctx).setTitle("নোট মুছবেন?").setMessage(n.text)
            .setPositiveButton("মুছুন") { _, _ -> CalNotes.delete(ctx, n.id); onChanged(); after() }
            .setNegativeButton("না", null).show()
    }


    // ---------------------------------------------------------------- v251: তারিখে চাপলে দিনের শিট

    private class Amal(val title: String, val sub: String?, val color: Int)

    /** একটি দিনের বিশেষ দিন/আমলের তালিকা — বিশেষ দিন, আইয়ামে বিয, তাশরিক, জুমা, সোম-বৃহস্পতির সুন্নাত রোজা */
    private fun amalsOf(g: Calendar, hj: H): List<Amal> {
        val out = ArrayList<Amal>()
        val dow = g.get(Calendar.DAY_OF_WEEK) - 1
        val ev = EVENTS.firstOrNull { it.m == hj.month && it.d == hj.day }
        val tashriq = hj.month == 11 && hj.day in 11..13            // তাশরিকের দিন — রোজা নিষিদ্ধ
        val eid = (hj.month == 9 && hj.day == 1) || (hj.month == 11 && hj.day == 10)
        val ramadan = hj.month == 8
        val white = isWhiteDay(hj)
        if (ev != null) out.add(Amal(ev.t, ev.s, p.gold))
        if (white) out.add(Amal("আইয়ামে বিয — সুন্নাত রোজার দিন", "প্রতি চান্দ্র মাসের ১৩, ১৪ ও ১৫ তারিখ রোজা রাখা সুন্নাত", p.primaryText))
        if (tashriq) out.add(Amal("তাশরিকের দিন", "এই দিনে রোজা রাখা নিষিদ্ধ", Color.parseColor("#E5594F")))
        if (ramadan && ev == null) out.add(Amal("রমজান মাস", "ফরজ রোজার মাস", p.gold))
        if (dow == 5) out.add(Amal("জুমার দিন", "সূরা কাহফ তিলাওয়াত ও বেশি করে দরুদ পড়া সুন্নাত", p.okText))
        if ((dow == 1 || dow == 4) && !white && !tashriq && !eid && !ramadan)
            out.add(Amal("সুন্নাত রোজার দিন", "সোম ও বৃহস্পতিবার নফল রোজা রাখা সুন্নাত", p.primaryText))
        return out
    }

    /**
     * v251: ক্যালেন্ডারের ঘরে চাপলে মাঝখানে খোলা পপআপ — ওই দিনের তিন তারিখ, বিশেষ দিন ও আমল (আইয়ামে বিয ইত্যাদি),
     * আর নোট (দেখা · সম্পাদনা · মুছুন · + নোট যোগ) — নির্ধারিত জায়গায় না গিয়ে এখান থেকেই নোট করা যায়।
     */
    private fun showDaySheet(y: Int, m: Int, d: Int) {
        val dialog = android.app.Dialog(ctx)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val g = Calendar.getInstance().apply { clear(); set(y, m, d) }
        val dow = g.get(Calendar.DAY_OF_WEEK) - 1
        val hj = hijriOf(g); val bn = banglaOf(g)
        val isToday = y == todayY0 && m == todayM0 && d == todayD0

        // মাঝখানের পপআপ — অন্য পপআপ (নতুন নোট ইত্যাদি) এর একই ধাঁচ: গোল-কোনা কার্ড, চারদিকে ফাঁক
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surfHi, p.surf)).apply {
                cornerRadius = dpf(24f); setStroke(dp(1), p.line)
            }
        }

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val scroll = object : ScrollView(ctx) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec((ctx.resources.displayMetrics.heightPixels * 0.66f).toInt(), View.MeasureSpec.AT_MOST))
            }
        }.apply { isVerticalScrollBarEnabled = false; addView(col) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, -2))

        // মাথা: বার + আজ ট্যাগ + বন্ধ
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv(WD_FULL[dow], 20f, if (dow == 5) p.gold else p.text, true))
        if (isToday) head.addView(tv("আজ", 11f, p.onPrimary, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(10), dp(3), dp(10), dp(3))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(50f) }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })
        head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        head.addView(tv("বন্ধ", 12.5f, p.text2, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(14), dp(6), dp(14), dp(6))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.surf2); setStroke(dp(1), p.line) }
            setOnClickListener { dialog.dismiss() }
        })
        col.addView(head, LinearLayout.LayoutParams(-1, -2))

        fun line(c: Int, label: String, v: String) {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            r.addView(dot(dp(8), c), LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(10) })
            r.addView(tv(label, 12.5f, p.text3), LinearLayout.LayoutParams(dp(54), -2))
            r.addView(tv(v, 14.5f, p.text, true), LinearLayout.LayoutParams(0, -2, 1f))
            col.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        col.addView(View(ctx), LinearLayout.LayoutParams(-1, dp(6)))
        line(p.text2, "ইংরেজি", "${Bn.digits(d)} ${Bn.GREG_MONTHS[m]} ${Bn.digits(y)}")
        line(p.primaryText, "বাংলা", "${Bn.digits(bn.day)} ${Bn.BANGLA_MONTHS[bn.month]} ${Bn.digits(bn.year)}")
        line(p.gold, "হিজরি", "${Bn.digits(hj.day)} ${MONTHS[hj.month]} ${Bn.digits(hj.year)}")

        // বিশেষ দিন ও আমল
        col.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12) })
        col.addView(tv("বিশেষ দিন ও আমল", 15f, p.text, true).apply { setPadding(0, dp(14), 0, dp(4)) })
        val amals = amalsOf(g, hj)
        if (amals.isEmpty()) {
            col.addView(tv("এই দিনে আলাদা কোনো বিশেষ দিন বা আমল নেই।", 12.5f, p.text3).apply { setPadding(0, dp(4), 0, 0) })
        } else for (a in amals) {
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, dp(12), 0)
                background = GradientDrawable().apply { cornerRadius = dpf(14f); setColor(p.surf2); setStroke(dp(1), p.line) }
            }
            card.addView(View(ctx).apply { background = GradientDrawable().apply { cornerRadius = dpf(3f); setColor(a.color) } },
                LinearLayout.LayoutParams(dp(4), -1).apply { setMargins(dp(8), dp(10), dp(12), dp(10)) })
            val t = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(11), 0, dp(11)) }
            t.addView(tv(a.title, 14f, p.text, true).apply { setLineSpacing(0f, 1.2f) })
            if (a.sub != null) t.addView(tv(a.sub, 12f, p.text3).apply { setPadding(0, dp(3), 0, 0); setLineSpacing(0f, 1.2f) })
            card.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }

        // নোট (দেখা · সম্পাদনা · মুছুন · + নোট যোগ)
        col.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(16) })
        val nbox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(nbox, LinearLayout.LayoutParams(-1, -2))

        fun openNote(n: CalNote?, rerender: () -> Unit) {
            CalNoteDialog(ctx, p).show(y, m, d, n, host) { ny, nm, nd ->
                vy = ny; vm = nm; sel = nd
                vs?.let { it.y = ny; it.m = nm; it.d = nd }
                onChanged()
                if (ny == y && nm == m && nd == d) rerender() else dialog.dismiss()      // নোট অন্য দিনে সরলে শিট বন্ধ
            }
        }
        lateinit var renderSheetNotes: () -> Unit
        renderSheetNotes = {
            nbox.removeAllViews()
            val notes = CalNotes.forDay(ctx, y, m, d)
            val nh = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, dp(8)) }
            nh.addView(tv("নোট", 15f, p.text, true))
            if (notes.isNotEmpty()) nh.addView(tv(Bn.digits(notes.size), 11.5f, p.okText, true).apply {
                gravity = Gravity.CENTER; setPadding(dp(8), dp(1), dp(8), dp(1))
                background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.okSoft) }
            }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            nh.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
            nh.addView(tv("+ নোট যোগ", 12.5f, p.onPrimary, true).apply {
                gravity = Gravity.CENTER; setPadding(dp(14), dp(7), dp(14), dp(7))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(50f) }
                contentDescription = "এই দিনে নতুন নোট যোগ করুন"
                setOnClickListener { openNote(null, renderSheetNotes) }
            })
            nbox.addView(nh, LinearLayout.LayoutParams(-1, -2))
            if (notes.isEmpty()) {
                nbox.addView(tv("এই দিনে কোনো নোট নেই। \"+ নোট যোগ\" চেপে এখান থেকেই লিখুন — চাইলে সময়মতো নোটিফিকেশন বা এলার্মে মনে করিয়ে দেবে।", 12f, p.text3).apply { setLineSpacing(0f, 1.25f) })
            } else for (n in notes) {
                nbox.addView(noteRow(n, { openNote(n, renderSheetNotes) }, { confirmDelete(n) { renderSheetNotes() } }),
                    LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
        }
        renderSheetNotes()

        val frame = android.widget.FrameLayout(ctx).apply { setPadding(dp(14), dp(14), dp(14), dp(14)); addView(root) }
        dialog.setContentView(frame)
        dialog.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            setLayout(android.view.WindowManager.LayoutParams.MATCH_PARENT, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER); setDimAmount(0.6f)
        }
        dialog.show()
    }

    /**
     * v248: "এক নজরে" কার্ডের নোট-অংশ — বাছা দিনের তারিখ, নোট-সংখ্যা, "+ নোট যোগ", আর নোটের সারি (সম্পাদনা/মুছুন)।
     * নিচের ক্যালেন্ডারে দিন বাছলে এটা নিজে বদলায়।
     */
    private fun renderNotes() {
        val box = notesBox ?: return
        box.removeAllViews()
        val first = Calendar.getInstance().apply { clear(); set(vy, vm, 1) }
        val len = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        if (sel > len) sel = len
        val g = midnight(first, sel - 1)
        val dayNotes = CalNotes.forDay(ctx, vy, vm, sel)

        // মাথা: নোট [সংখ্যা]            + নোট যোগ
        val nh = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, dp(8)) }
        nh.addView(tv("নোট", 15f, p.text, true))
        if (dayNotes.isNotEmpty()) nh.addView(tv(Bn.digits(dayNotes.size), 11.5f, p.okText, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(8), dp(1), dp(8), dp(1))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.okSoft) }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        nh.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        nh.addView(tv("+ নোট যোগ", 12.5f, p.onPrimary, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(50f) }
            contentDescription = "এই দিনে নতুন নোট যোগ করুন"
            setOnClickListener { openNoteDialog(null) }
        })
        box.addView(nh, LinearLayout.LayoutParams(-1, -2))

        // বিশেষ দিন / আইয়ামে বিয থাকলে ছোট ট্যাগ (আগে নিচের দিন-প্যানেলে ছিল)
        val hj = hijriOf(g)
        val ev = EVENTS.firstOrNull { it.m == hj.month && it.d == hj.day }
        if (ev != null || isWhiteDay(hj)) {
            val t = ev?.t ?: "আইয়ামে বিয — সুন্নাত রোজার দিন"
            box.addView(tv("✦  $t" + (if (ev?.s != null) " · ${ev.s}" else ""), 12f, p.gold, true).apply {
                setPadding(dp(12), dp(7), dp(12), dp(7)); setLineSpacing(0f, 1.2f)
                background = GradientDrawable().apply { cornerRadius = dpf(12f); setColor(p.goldSoft) }
            }, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(8) })
        }

        if (dayNotes.isEmpty()) {
            box.addView(tv("এই দিনে কোনো নোট নেই। কাজ বা কথা মনে রাখতে নোট লিখুন — চাইলে সময়মতো নোটিফিকেশন বা এলার্মে মনে করিয়ে দেবে।", 12f, p.text3).apply { setLineSpacing(0f, 1.25f) })
        } else {
            // v245: প্রথমে একটা নোট; একের বেশি থাকলে "আরও N টি দেখুন" চাপলে বাকিগুলো
            dayNotes.take(if (expDay) dayNotes.size else 1).forEach { n ->
                box.addView(noteRow(n, { openNoteDialog(n) }, { confirmDelete(n) }), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
            if (dayNotes.size > 1) box.addView(moreToggle(dayNotes.size - 1, expDay) { expDay = !expDay; vs?.expDay = expDay; renderNotes() },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10); gravity = Gravity.CENTER_HORIZONTAL })
        }
    }

    /** দুটো সলিড রঙের মিশ্রণ ([t] = [b]-এর ভাগ) — ঘরের সমতল পটভূমির জন্য (ফাঁকের রেখা যেন ঢেকে না যায়) */
    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    /**
     * v250: একটি দিনের ঘর (ঘর-টানা ক্যালেন্ডারের) — ওপরে ইংরেজি তারিখ (বড়), নিচে বাংলা (নীল) ও হিজরি (সোনালি) তারিখ।
     * পটভূমি সমতল রঙের (শুক্রবার সোনালি আভা, নোট-থাকা দিন সবুজ আভা); আজ = নীল গ্রেডিয়েন্টের গোল-কোনা ভরাট,
     * বাছা দিন = নীল ঘেরের গোল-কোনা; বিশেষ দিনের তারা ডানে-ওপরে, আইয়ামে বিযের বিন্দু বাঁয়ে-ওপরে, নোটের সবুজ বিন্দু নিচে।
     */
    private fun cell(d: Int, bn: B, hj: H, isToday: Boolean, selected: Boolean, past: Boolean, white: Boolean, ev: Ev?, fri: Boolean,
                     todayWhite: Int, todayGold: Int, noteCount: Int = 0): android.widget.FrameLayout {
        val box = android.widget.FrameLayout(ctx)
        box.setBackgroundColor(when {
            noteCount > 0 -> mix(p.surf, p.ok, 0.16f)
            fri -> mix(p.surf, p.gold, 0.09f)
            else -> p.surf
        })
        val inner = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        inner.background = when {
            isToday -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(11f); setStroke(dp(1), p.goldLine) }
            selected -> GradientDrawable().apply { cornerRadius = dpf(11f); setColor((p.primary and 0x00FFFFFF) or 0x2A000000); setStroke(dp(2), p.primaryText) }
            else -> null
        }
        val enCol = if (isToday) todayWhite else if (fri) p.gold else p.text
        inner.addView(tv(Bn.digits(d), 16.5f, enCol, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; includeFontPadding = false })
        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) }
        sub.addView(tv(Bn.digits(bn.day), 10.5f, if (isToday) todayWhite else p.primaryText, true).apply { includeFontPadding = false })
        sub.addView(View(ctx), LinearLayout.LayoutParams(dp(5), 1))
        sub.addView(tv(Bn.digits(hj.day), 10.5f, if (isToday) todayGold else p.gold, true).apply { includeFontPadding = false })
        inner.addView(sub, LinearLayout.LayoutParams(-2, -2))
        if (past && !isToday) inner.alpha = .5f
        box.addView(inner, android.widget.FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        if (white) box.addView(dot(dp(4), if (isToday) todayWhite else p.primaryText), android.widget.FrameLayout.LayoutParams(dp(4), dp(4), Gravity.TOP or Gravity.START).apply { topMargin = dp(7); leftMargin = dp(7) })
        if (ev != null) box.addView(View(ctx).apply { background = StarDrawable(if (isToday) todayGold else p.gold) },
            android.widget.FrameLayout.LayoutParams(dp(8), dp(8), Gravity.TOP or Gravity.END).apply { topMargin = dp(6); rightMargin = dp(6) })
        // v244: নিচে মাঝখানে সবুজ বিন্দু — যতটা নোট ততটা (সর্বোচ্চ ৩টি)
        if (noteCount > 0) {
            val dots = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            for (i in 0 until minOf(noteCount, 3)) dots.addView(dot(dp(5), if (isToday) todayWhite else p.okText),
                LinearLayout.LayoutParams(dp(5), dp(5)).apply { if (i > 0) leftMargin = dp(2) })
            box.addView(dots, android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(5) })
        }
        return box
    }

    /** v244: দিনের প্যানেলের একটি নোট — বাঁয়ে সবুজ দাগ, লেখা, নিচে সময় ও মনে করানোর ধরন */
    private fun noteRow(n: CalNote, onEdit: () -> Unit, onDelete: () -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, dp(12), 0)
            background = GradientDrawable().apply { cornerRadius = dpf(14f); setColor(p.surf2); setStroke(dp(1), p.line) }
        }
        row.addView(View(ctx).apply { background = GradientDrawable().apply { cornerRadius = dpf(3f); setColor(p.ok) } },
            LinearLayout.LayoutParams(dp(4), -1).apply { setMargins(dp(8), dp(10), dp(12), dp(10)) })
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(11), 0, dp(11)) }
        col.addView(tv(n.text, 14f, p.text, true).apply { maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END; setLineSpacing(0f, 1.2f) })
        val remind = n.mode != CalNotes.MODE_NONE
        val meta = if (!remind) "শুধু নোট" else CalNotes.fmtTime(n.minutes) + " · " + CalNotes.modeLabel(n.mode) + (if (n.fired) " · জানানো হয়েছে" else "")
        col.addView(tv(meta, 11.5f, if (remind && !n.fired) p.okText else p.text3, remind && !n.fired).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        // v246: দুটো স্পষ্ট বোতাম — সম্পাদনা ও মুছুন (পুরো সারিতে চাপলেও সম্পাদনা খোলে)
        val acts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        acts.addView(tv("সম্পাদনা", 12f, p.primaryText, true).apply { gravity = Gravity.CENTER; setPadding(dp(10), dp(8), dp(10), dp(6)); setOnClickListener { onEdit() } })
        acts.addView(tv("মুছুন", 12f, Color.parseColor("#E5594F"), true).apply { gravity = Gravity.CENTER; setPadding(dp(10), dp(6), dp(10), dp(8)); setOnClickListener { onDelete() } })
        row.addView(acts)
        row.setOnClickListener { onEdit() }
        row.contentDescription = "নোট: ${n.text}। সম্পাদনা করতে চাপুন"
        return row
    }

    /** v244: আসন্ন নোটের সারি — আর্চ-আকৃতির তারিখ-বক্স (সবুজ রেখা), লেখা, আর "আজ / আর N দিন" */
    private fun upNoteRow(n: CalNote, today: Calendar): View {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        val g = Calendar.getInstance().apply { clear(); set(n.y, n.m, n.d) }
        val date = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6))
            val r = dpf(23f); val s = dpf(6f)
            background = GradientDrawable().apply { setCornerRadii(floatArrayOf(r, r, r, r, s, s, s, s)); setColor(p.okSoft); setStroke(dp(1), okLine) }
        }
        date.addView(tv(Bn.digits(n.d), 17f, p.okText, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER })
        date.addView(tv(Bn.GREG_MONTHS[n.m], 11f, p.text3).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; maxLines = 1; setPadding(0, dp(2), 0, 0) })
        row.addView(date, LinearLayout.LayoutParams(dp(54), -2).apply { rightMargin = dp(12) })

        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(tv(n.text, 15f, p.text, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        val remind = n.mode != CalNotes.MODE_NONE
        mid.addView(tv(WD_FULL[g.get(Calendar.DAY_OF_WEEK) - 1] + (if (remind) " · " + CalNotes.fmtTime(n.minutes) + " · " + CalNotes.modeLabel(n.mode) else " · শুধু নোট"), 12f, p.text3).apply {
            setLineSpacing(0f, 1.25f); setPadding(0, dp(4), 0, 0)
        })
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))

        val k = Math.round((g.timeInMillis - midnight(today, 0).timeInMillis) / 86400000.0).toInt()
        val soon = k <= 1
        val whenTxt = when { k <= 0 -> "আজ"; k == 1 -> "আগামীকাল"; else -> "আর ${Bn.digits(k)} দিন" }
        row.addView(tv(whenTxt, 11f, if (soon) p.okText else p.text2, soon).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(if (soon) p.okSoft else p.surf2) }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        row.contentDescription = "আসন্ন নোট: ${n.text}, ${Bn.digits(n.d)} ${Bn.GREG_MONTHS[n.m]}। ক্যালেন্ডারে দেখতে চাপুন"
        return row
    }

    private fun eventRow(u: Up): View {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        // আর্চ-আকৃতির তারিখ-বক্স
        val date = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6))
            val r = dpf(23f); val s = dpf(6f)
            background = GradientDrawable().apply { setCornerRadii(floatArrayOf(r, r, r, r, s, s, s, s)); setColor(Color.TRANSPARENT); setStroke(dp(1), p.goldLine) }
        }
        date.addView(tv(Bn.digits(u.g.get(Calendar.DAY_OF_MONTH)), 17f, p.gold, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER })
        date.addView(tv(Bn.GREG_MONTHS[u.g.get(Calendar.MONTH)], 11f, p.text3).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; maxLines = 1; setPadding(0, dp(2), 0, 0) })
        row.addView(date, LinearLayout.LayoutParams(dp(54), -2).apply { rightMargin = dp(12) })

        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(tv(u.title, 15f, p.text, true))
        val jsDow = u.g.get(Calendar.DAY_OF_WEEK) - 1
        mid.addView(tv("${Bn.digits(u.day)} ${MONTHS[u.month]} · ${WD_FULL[jsDow]}" + (if (u.sub != null) " · ${u.sub}" else ""), 12f, p.text3).apply {
            setLineSpacing(0f, 1.25f); setPadding(0, dp(4), 0, 0)
        })
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))

        val soon = u.k <= 7
        val whenTxt = when (u.k) { 0 -> "আজ"; 1 -> "আগামীকাল"; else -> "আর ${Bn.digits(u.k)} দিন" }
        row.addView(tv(whenTxt, 11f, if (soon) p.gold else p.text2, soon).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(if (soon) p.goldSoft else p.surf2) }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        return row
    }
}
