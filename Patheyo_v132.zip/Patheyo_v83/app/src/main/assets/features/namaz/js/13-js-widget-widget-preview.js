/* js/widget/widget-preview.js */
/* =============================================================================
   উইজেট প্রিভিউ ছবি
   থিম ও টগল অনুযায়ী সঠিক প্রিভিউ PNG বাছাই ও দেখানো (assets/widget_preview_images/)।
   ============================================================================= */

// ✅ লাইভ প্রিভিউ এখন real widget ছবির (PNG) মাধ্যমে দেখানো হয়, DOM widget স্কেল/রিসাইজ করে নয়।
// থিম + কোন কোন উপাদান (ঘড়ি/আবহাওয়া/সাহরী-ইফতার) চালু আছে তার উপর ভিত্তি করে সঠিক ছবির নাম
// বের করে assets/widget_preview_images/ ফোল্ডার থেকে দেখানো হয়। ছবির নামের তালিকার জন্য
// widget_preview_images/README.md দেখুন।
// থিমের নাম → প্রিভিউ ছবির শুরুর অফসেট: গ্লাস 01–06, ট্রান্সপারেন্ট-ডার্ক 07–12, লাইট 13–18,
// ট্রান্সপারেন্ট-লাইট 19–24 (প্রতিটা সেটে একই ক্রমে একই ভ্যারিয়েন্ট — 07 এর লাইট জোড়া 19, 12 এর 24)।
function wdThemeKey() {
    if (activeWidgetTheme === 'custom') return 'custom';
    return (activeWidgetTheme === 'nobg' && activeNobgMode === 'light') ? 'nobg_light' : activeWidgetTheme;
}

function getWidgetPreviewImageName() {
    const clockOn = document.getElementById('toggle-wd-clock')?.checked || false;
    const sehriOn = document.getElementById('toggle-wd-sehri-iftar')?.checked || false;
    const weatherChecked = document.getElementById('toggle-wd-weather')?.checked || false;
    const weatherOn = weatherChecked && !(clockOn && sehriOn); // ঘড়ি চালু থাকলে দুটো একসাথে হয় না

    const themeOffset = { glass: 0, nobg: 6, light: 12, nobg_light: 18 };
    // v20: কাস্টম থিমে স্বচ্ছ-ব্যাকগ্রাউন্ডের ছবি (টোন অনুযায়ী ডার্ক/লাইট লেখা) দেখানো হয়, পেছনে বাছা রঙ বসে
    const key0 = wdThemeKey();
    const key = key0 === 'custom' ? (wcIsLightTone() ? 'nobg_light' : 'nobg') : key0;
    const offset = themeOffset[key] ?? 0;
    const pad = n => String(n).padStart(2, '0') + '.png';

    // ঘড়ি বন্ধ + আবহাওয়া ও সাহরী/ইফতার দুটোই চালু: এই কম্বিনেশনের আলাদা ছবি (25–28.png, ঐচ্ছিক)।
    // ছবি না থাকলে "শুধু সাহরী/ইফতার"-এর ছবি দেখায় (fallback)।
    if (!clockOn && weatherOn && sehriOn) {
        const extra = { glass: 25, nobg: 26, light: 27, nobg_light: 28 };
        return { primary: pad(extra[key] ?? 25), fallback: pad(offset + 5) };
    }

    let accessory = 'none';
    if (weatherOn) accessory = 'weather';
    else if (sehriOn) accessory = 'sehri';

    // থিম প্রতি ৬টি কম্বিনেশন (ঘড়ি+সাহরী/ইফতার, ঘড়ি+আবহাওয়া, শুধু ঘড়ি, শুধু আবহাওয়া, শুধু সাহরী/ইফতার, সবগুলো বন্ধ)
    const comboIndex = {
        'true|sehri': 1,
        'true|weather': 2,
        'true|none': 3,
        'false|weather': 4,
        'false|sehri': 5,
        'false|none': 6
    };
    const idx = comboIndex[`${clockOn}|${accessory}`] || 6;
    // ট্রান্সপারেন্ট-লাইটের (19–24) ছবি এখনো যুক্ত না থাকলে ট্রান্সপারেন্ট-ডার্কের (07–12) ছবিই দেখায়
    const fb = key === 'nobg_light' ? pad(6 + idx) : null;
    return { primary: pad(offset + idx), fallback: fb };
}

let _wdPreviewFallback = null;
function widgetPreviewImageFailed() {
    const img = document.getElementById('widget-preview-image');
    const missing = document.getElementById('widget-preview-missing');
    if (_wdPreviewFallback) {
        const fb = _wdPreviewFallback; _wdPreviewFallback = null;
        if (img) img.dataset.file = fb; if (window.__ASSET.previews[fb]) img.src = window.__ASSET.previews[fb];
        return;
    }
    if (img) img.style.display = 'none';
    if (missing) missing.classList.remove('hidden');
}

function updateWidgetHubChips() {
    const names = { glass: 'গ্লাস (ডার্ক)', nobg: 'ট্রান্সপারেন্ট · ডার্ক', nobg_light: 'ট্রান্সপারেন্ট · লাইট', light: 'লাইট', custom: 'কাস্টম · ' + wcHex() };
    const c1 = document.getElementById('wh-chip-theme');
    if (c1) c1.textContent = names[wdThemeKey()] || '';
    const parts = [];
    if (document.getElementById('toggle-wd-clock')?.checked) parts.push('ঘড়ি');
    if (document.getElementById('toggle-wd-weather')?.checked) parts.push('আবহাওয়া');
    if (document.getElementById('toggle-wd-sehri-iftar')?.checked) parts.push('সাহরী/ইফতার');
    const c2 = document.getElementById('wh-chip-items');
    if (c2) c2.textContent = parts.length ? parts.join(' · ') : 'শুধু নামাজের সময়';
}

function updateWidgetPreviewImage() {
    const img = document.getElementById('widget-preview-image');
    const missing = document.getElementById('widget-preview-missing');
    if (!img) return;
    const names = getWidgetPreviewImageName();
    _wdPreviewFallback = names.fallback;
    const newSrc = window.__ASSET.previews[names.primary]; img.dataset.file = names.primary;
    img.style.display = '';
    if (missing) missing.classList.add('hidden');
    if (newSrc) img.src = newSrc;
    wcApplyPreviewBg(names.primary);
    updateWidgetHubChips();
    // 🔧 কিছু পুরনো/সস্তা ফোনের WebView-এ src পরিবর্তনের পরেও মাঝে মাঝে স্ক্রিনে পুরনো ছবিই
    // থেকে যায় (রিপেইন্ট হয় না) — এটা এড়াতে জোর করে রিফ্লো/রিপেইন্ট ঘটানো হচ্ছে।
    void img.offsetHeight;
    img.style.webkitTransform = 'translateZ(0)';
    requestAnimationFrame(() => {
        requestAnimationFrame(() => { img.style.webkitTransform = ''; });
    });
}

