/* js/core/offline-cache.js */
/* =============================================================================
   অফলাইন ক্যাশ ও রিট্রাই
   সর্বশেষ সফল তথ্য ক্যাশে রাখা, অফলাইন ব্যানার এবং স্বয়ংক্রিয় পুনঃচেষ্টা।
   ============================================================================= */

// ============================================================================
// অফলাইন ক্যাশিং ব্যবস্থা — ইন্টারনেট না থাকলেও অ্যাপ যেন ভাঙাচোরা না দেখায়, বরং সর্বশেষ
// সফলভাবে আনা তথ্য (সময়, তারিখ, লোকেশন, তাপমাত্রা) সুন্দরভাবে দেখাতে থাকে।
// ============================================================================
function cacheLastKnownData(payload) {
    try { localStorage.setItem('lastKnownPrayerData', JSON.stringify(payload)); } catch(e) {}
}
function loadOfflineCacheIntoMemory() {
    try {
        const raw = localStorage.getItem('lastKnownPrayerData');
        if (!raw) return;
        const cached = JSON.parse(raw);
        if (cached.lat) userLat = cached.lat;
        if (cached.lng) userLng = cached.lng;
        if (cached.locationName) {
            document.getElementById('top-location').innerHTML = `<i class="fa-solid fa-location-dot text-blue-500"></i> ${cached.locationName}`;
        }
        if (cached.temp) {
            cacheTemperatureStr = cached.temp;
            document.getElementById('wd-widget-temp-val').innerText = cacheTemperatureStr;
        }
    } catch(e) {}
}
// ইন্টারনেট/ফেচ ব্যর্থ হলে এটা কল হয় — ক্যাশ করা সর্বশেষ ডেটা দিয়েই পুরো UI সুন্দরভাবে রেন্ডার করা হয়
function loadFromOfflineCache(now) {
    const raw = localStorage.getItem('lastKnownPrayerData');
    if (!raw) {
        notifyOfflineBannerState(true, true); // কোনো ক্যাশই নেই (একদম প্রথমবার অফলাইনে খোলা হয়েছে)
        return;
    }
    try {
        const cached = JSON.parse(raw);
        globalTimings = applyWaqtMinuteOffsets(cached.timings);
        isRamadanNow = !!cached.isRamadan;
        if (cached.lat) userLat = cached.lat;
        if (cached.lng) userLng = cached.lng;

        document.getElementById('cal-gregorian').innerText = `${now.getDate()} ${gregorianMonthsBN[now.getMonth()]} ${now.getFullYear()}`;
        document.getElementById('cal-bangla').innerText = getBengaliCalendarCalculation(now, false);
        const hijriStr = getFinalHijriDisplayString(now);
        document.getElementById('cal-hijri').innerText = hijriStr;
        updateWidgetDateStrings(now, hijriStr);

        document.getElementById('time-sunrise').innerText = convert24To12(globalTimings.Sunrise);
        document.getElementById('time-sunset').innerText = convert24To12(globalTimings.Sunset);
        document.getElementById('time-sehri').innerText = convert24To12(globalTimings.Fajr);
        document.getElementById('time-iftar').innerText = convert24To12(globalTimings.Maghrib);

        // অফলাইনে নামাজের কার্ডগুলো সাথে সাথে দেখানো হবে, ১ সেকেন্ড অপেক্ষা করতে হবে না
        setTimeout(() => { processDashboardTimelineUpdates(new Date()); }, 100);
        notifyOfflineBannerState(true);
    } catch(e) { notifyOfflineBannerState(true, true); }
}

// "সত্যিকারের অফলাইন" (ডিভাইসেই নেট নেই) বনাম "নেট আছে কিন্তু সার্ভার/এপিআই সাড়া দিচ্ছে না" — এই দুই
// অবস্থার জন্য আলাদা, নির্ভুল বার্তা দেখানো হয়। আগে দুটোকেই এক ধরে "ইন্টারনেট নেই" দেখানো হতো, যার ফলে
// মোবাইলে আসলে নেট চালু থাকা সত্ত্বেও অ্যাপ ভুল করে "নেট নেই" বলত।
function notifyOfflineBannerState(isOffline, noCacheYet) {
    isShowingOfflineData = isOffline;
    const banner = document.getElementById('offline-status-banner');
    if (!banner) return;
    if (isOffline) {
        banner.classList.remove('hidden');
        const deviceHasNoNetwork = (nativeNetworkStatus === false) || (nativeNetworkStatus === null && !navigator.onLine);
        if (!deviceHasNoNetwork) {
            // ডিভাইসে নেট থাকা সত্ত্বেও প্রয়োজনীয় ডেটা আনা যাচ্ছে না (সার্ভার/এপিআই সাময়িক সমস্যা)
            banner.innerText = noCacheYet
                ? '⚠️ সার্ভারের সাথে সংযোগ করা যাচ্ছে না — সঠিক নামাজের সময়সূচি এই মুহূর্তে আনা যায়নি, আবার চেষ্টা করা হচ্ছে'
                : '⚠️ সার্ভারে সাময়িক সমস্যা — সর্বশেষ সংরক্ষিত তথ্য দেখানো হচ্ছে, সঠিক হিসাব নাও হতে পারে। স্বয়ংক্রিয়ভাবে আবার চেষ্টা করা হচ্ছে';
        } else {
            banner.innerText = noCacheYet
                ? '📡 ইন্টারনেট সংযোগ পাওয়া যাচ্ছে না — প্রথমবার অ্যাপ চালু করতে অন্তত একবার ইন্টারনেট চালু করুন'
                : '📡 ইন্টারনেট সংযোগ নেই — সর্বশেষ সংরক্ষিত তথ্য দেখানো হচ্ছে, সঠিক নামাজের হিসাব নাও দেখতে পারেন';
        }
        scheduleOfflineDataRetry();
    } else {
        banner.classList.add('hidden');
        cancelOfflineDataRetry();
    }
}

// ডেটা আনতে ব্যর্থ হলে (নেট থাকুক বা না থাকুক) পটভূমিতে বারবার আবার চেষ্টা করার ব্যবস্থা — ব্যবহারকারীকে
// অ্যাপ বন্ধ-খোলা বা রিফ্রেশ করতে হবে না, নেট ফিরে এলে বা সার্ভার ঠিক হলে এমনিতেই সঠিক ডেটা চলে আসবে।
let offlineRetryTimer = null;
let offlineRetryAttempt = 0;
function scheduleOfflineDataRetry() {
    if (offlineRetryTimer) return; // ইতিমধ্যে শিডিউল করা আছে
    offlineRetryAttempt++;
    // এক্সপোনেনশিয়াল ব্যাকঅফ: ১৫সে → ৩০সে → ৬০সে → সর্বোচ্চ ১২০সে পরপর — ব্যাটারি/ডেটা সাশ্রয়ী রেখে দ্রুত রিকভারি
    const delayMs = Math.min(15000 * Math.pow(2, offlineRetryAttempt - 1), 120000);
    offlineRetryTimer = setTimeout(() => {
        offlineRetryTimer = null;
        if (isShowingOfflineData) { fetchCorePrayerData(); }
    }, delayMs);
}
function cancelOfflineDataRetry() {
    if (offlineRetryTimer) { clearTimeout(offlineRetryTimer); offlineRetryTimer = null; }
    offlineRetryAttempt = 0;
}

