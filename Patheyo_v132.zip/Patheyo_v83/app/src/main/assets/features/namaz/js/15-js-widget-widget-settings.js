/* js/widget/widget-settings.js */
/* =============================================================================
   উইজেট সেটিংস
   থিম/মোড বদল, টগল (ঘড়ি, আবহাওয়া, সাহরী-ইফতার), নেটিভ ব্রিজে সেটিং সিঙ্ক ও রিফ্রেশ।
   ============================================================================= */

// ট্রান্সপারেন্ট থিমের ডার্ক/লাইট মোড বদল
function changeNobgMode(mode) {
    activeNobgMode = (mode === 'light') ? 'light' : 'dark';
    try { localStorage.setItem('activeNobgMode', activeNobgMode); } catch (e) {}
    refreshNobgModeButtons();
    updateWidgetPreviewImage();
    try { syncWidgetSettingsToNativeBridge(); } catch (e) { console.error('native bridge sync error:', e); }
}

function refreshNobgModeButtons() {
    const box = document.getElementById('wd-nobg-modes');
    if (box) box.classList.toggle('hidden', activeWidgetTheme !== 'nobg');
    ['dark', 'light'].forEach(m => {
        const b = document.getElementById(`wmode-${m}`);
        if (b) b.classList.toggle('active', activeNobgMode === m);
    });
    refreshCustomPanel();
}

function changeWidgetStyleTheme(themeKey) {
    activeWidgetTheme = themeKey;
    try { localStorage.setItem('activeWidgetTheme', themeKey); } catch (e) {} // থিম সেভ করা হলো, নাহলে অ্যাপ বন্ধ করে খুললে আবার ডিফল্টে ফিরে যাবে

    // ✅ থিম বাটনের স্টাইল ও লাইভ প্রিভিউ ছবি সবার আগে, সরাসরি আপডেট হচ্ছে — যাতে ইউজার
    // ক্লিক করার সাথে সাথেই পরিবর্তন দেখতে পায়, নিচের কোনো (hidden/legacy) কোডে সমস্যা
    // হলেও এখানে কোনো প্রভাব পড়বে না।
    ['glass', 'nobg', 'light', 'custom'].forEach(t => {
        const btn = document.getElementById(`wtheme-${t}`);
        if (btn) btn.classList.toggle('active', t === themeKey);
    });
    refreshNobgModeButtons();

    updateWidgetPreviewImage(); // 👈 সবচেয়ে গুরুত্বপূর্ণ কাজ — সবার আগেই করা হলো

    // নিচের অংশ — hidden legacy widget markup (নেটিভ অ্যান্ড্রয়েড উইজেট আপডেটের জন্য দরকার) —
    // try/catch দিয়ে আলাদা করা হলো, যাতে এখানে কোনো এরর হলেও উপরের প্রিভিউ ছবিতে কোনো
    // প্রভাব না পড়ে এবং থিম বাটনের ক্লিক সবসময় সাথে সাথে কাজ করে।
    try {
        const w = document.getElementById('live-widget-container');
        if (w) {
            w.className = "p-4 md:p-6 rounded-3xl shadow-2xl transition-all duration-150 origin-center flex flex-col gap-4 md:gap-5";
            if (themeKey === 'glass') w.classList.add('widget-glass-dark');
            else if (themeKey === 'nobg' || themeKey === 'custom') w.classList.add('widget-nobg');
            else if (themeKey === 'light') w.classList.add('widget-light');
        }
        processDashboardTimelineUpdates(new Date());
    } catch (e) { console.error('legacy widget sync error:', e); }

    try { syncWidgetSettingsToNativeBridge(); } catch (e) { console.error('native bridge sync error:', e); }
}

// অ্যাপের উইজেট সেটিংস (থিম, ঘড়ি/আবহাওয়া অন-অফ) নেটিভ অ্যান্ড্রয়েড হোমস্ক্রিন উইজেটে পাঠানো হচ্ছে।
// এর ফলে অ্যাপে যেকোনো সেটিংস বদলালেই হোমস্ক্রিনের উইজেটও সাথে সাথে আপডেট হয়ে যাবে।
function syncWidgetSettingsToNativeBridge() {
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.saveWidgetSettings === 'function') {
        try {
            const sehriOn = document.getElementById('toggle-wd-sehri-iftar')?.checked || false;
            const clockOnNow = document.getElementById('toggle-wd-clock')?.checked || false;
            window.AndroidWidgetBridge.saveWidgetSettings(JSON.stringify({
                theme: wdThemeKey(),
                showClock: document.getElementById('toggle-wd-clock')?.checked || false,
                showWeather: (document.getElementById('toggle-wd-weather')?.checked || false) && !(sehriOn && clockOnNow),
                showSehriIftar: sehriOn,
                // v20: কাস্টম থিমের তথ্য (অন্য থিমে নেটিভ এগুলো উপেক্ষা করে)
                customBg: wcHex(),
                customOpacity: wdCustomOpacity,
                customTone: wdCustomTone
            }));
        } catch (e) { console.error('widget settings sync failed', e); }
    }
}

// ✅ FIX #11: "উইজেট রিফ্রেশ করুন" বাটনের জন্য — বর্তমান সেটিংসগুলো আরেকবার নিশ্চিতভাবে
// নেটিভ ব্রিজে পাঠায়, তারপর AndroidWidgetBridge.refreshWidgetNow() কল করে হোমস্ক্রিনের
// উইজেটটাকে জোর করে সাথে সাথে রিফ্রেশ করে (নেটিভ কোড একটা কনফার্মেশন টোস্টও দেখায়)।
// WebView-এর বাইরে (যেমন সাধারণ ব্রাউজারে টেস্ট করার সময়) ব্রিজ না থাকলে ব্যবহারকারীকে
// জানিয়ে দেওয়া হয়, যাতে বাটনটা নীরবে কিছু না করে বিভ্রান্তিকর না লাগে।
function forceRefreshWidgetNow() {
    syncWidgetSettingsToNativeBridge();
    if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.refreshWidgetNow === 'function') {
        try {
            window.AndroidWidgetBridge.refreshWidgetNow();
        } catch (e) {
            console.error('force refresh failed', e);
        }
    } else {
        alert('এই বাটনটা শুধু অ্যাপের ভিতরে (হোমস্ক্রিন উইজেট যুক্ত করার পর) কাজ করবে — এখন ব্রাউজারে টেস্ট মোডে আছেন।');
    }
}

// ✅ v17: আবহাওয়া ও সাহরী/ইফতারের নিয়ম —
//   • লাইভ ঘড়ি চালু থাকলে: একটা চালু করলে আরেকটা অটো-বন্ধ (জায়গা কম বলে)।
//   • লাইভ ঘড়ি বন্ধ থাকলে: দুটোই একসাথে চালু থাকতে পারে (সাহরী/ইফতার বামে, আবহাওয়া ডানে)।
//   • ঘড়ি আবার চালু করার সময় দুটোই চালু থাকলে আবহাওয়া বন্ধ হয়, সাহরী/ইফতার থাকে।
// changed = কোনটা এইমাত্র বদলেছে ('weather' | 'sehri' | 'clock' | null)।
function wdNormalizeToggles(changed) {
    const c = document.getElementById('toggle-wd-clock');
    const w = document.getElementById('toggle-wd-weather');
    const s = document.getElementById('toggle-wd-sehri-iftar');
    if (!c || !w || !s) return null;
    if (!c.checked || !w.checked || !s.checked) return null;
    let msg;
    if (changed === 'weather') { s.checked = false; try { localStorage.setItem('wdShowSehriIftar', false); } catch (e) {} msg = 'লাইভ ঘড়ি চালু থাকায় সাহরী/ইফতার বন্ধ হয়েছে'; }
    else { w.checked = false; try { localStorage.setItem('wdShowWeather', false); } catch (e) {} msg = 'লাইভ ঘড়ি চালু থাকায় আবহাওয়া বন্ধ হয়েছে'; }
    return msg;
}

let _wdNoteTimer = null;
function wdShowNote(msg) {
    const box = document.getElementById('warning-text');
    const span = document.getElementById('warning-text-msg');
    if (!box || !span) return;
    if (!msg) { box.classList.remove('show'); return; }
    span.textContent = msg;
    box.classList.add('show');
    clearTimeout(_wdNoteTimer);
    _wdNoteTimer = setTimeout(() => box.classList.remove('show'), 3200);
}

function wdAfterToggle() {
    updateWidgetPreviewImage(); // 👈 সবার আগে — সাথে সাথে ছবি বদলাবে
    try { processDashboardTimelineUpdates(new Date()); } catch (e) { console.error('legacy widget sync error:', e); }
    try { syncWidgetSettingsToNativeBridge(); } catch (e) { console.error('native bridge sync error:', e); }
}

function onClockToggleChanged(checked) {
    try { localStorage.setItem('wdShowClock', checked); } catch (e) {}
    const msg = checked ? wdNormalizeToggles('clock') : null;
    wdShowNote(msg);
    wdAfterToggle();
}

function onWeatherToggleChanged(checked) {
    try { localStorage.setItem('wdShowWeather', checked); } catch (e) {}
    const msg = checked ? wdNormalizeToggles('weather') : null;
    wdShowNote(msg);
    wdAfterToggle();
}

function onSehriIftarToggleChanged(checked) {
    try { localStorage.setItem('wdShowSehriIftar', checked); } catch (e) {}
    const msg = checked ? wdNormalizeToggles('sehri') : null;
    wdShowNote(msg);
    wdAfterToggle();
}

