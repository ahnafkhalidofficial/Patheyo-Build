
/* গ্লোবাল স্টেট (state.js থেকে শুধু উইজেটের অংশ) */
let activeWidgetTheme = 'glass';
let activeNobgMode = 'dark'; // ট্রান্সপারেন্ট থিমের মোড — 'dark' (সাদা লেখা) | 'light' (গাঢ় লেখা)
let wdCustomOpacity = 90;    // কাস্টম থিম: স্বচ্ছতা (১০–১০০%)
let wdCustomTone = 'auto';   // কাস্টম থিম: লেখা/আইকন টোন (auto|dark|light)
let deferredPrompt = null;   // PWA ইনস্টল প্রম্পট

