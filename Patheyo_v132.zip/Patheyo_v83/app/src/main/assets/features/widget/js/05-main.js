
/* =============================================================================
   কাস্টম থিম — কালার পিকার
   কালার হুইল, হেক্স ইনপুট, স্বচ্ছতা ও টোন; নেটিভ উইজেটে সিঙ্ক।
   নোট: WC অবজেক্ট ও ডিফল্ট রঙ সেট করা কলটি আগে state.js-এ ছিল, এখন পিকারের নিজের
   ফাইলেই আছে — যাতে wcSetFromHex ডিফাইন হওয়ার পরেই কল হয়।
   ============================================================================= */

const WC = { h: 217, s: 0.5, v: 0.23, ready: false, syncTimer: null };
wcSetFromHex('#1E293B'); // ডিফল্ট রঙ (হোইস্টেড ফাংশন; HSV-তে হুবহু #1E293B)

// =====================================================================================
// ✅ v20: কাস্টম থিম — কালার হুইল + হেক্স কোড + স্বচ্ছতা + লেখা/আইকন টোন
//   • রঙ/স্বচ্ছতা/টোন localStorage-এ সেভ হয় (অ্যাপ বন্ধ করে খুললেও থাকে)।
//   • বদলালে লাইভ প্রিভিউ সাথে সাথে বদলায়; নেটিভ হোমস্ক্রিন উইজেটে ~০.৩ সেকেন্ড পর পাঠানো হয়
//     (হুইল টানার সময় প্রতি পিক্সেলে উইজেট রিফ্রেশ হয়ে ফোন ভারী না হওয়ার জন্য)।
// =====================================================================================
const WC_PRESETS = ['#0F172A', '#111A2E', '#1E3A8A', '#0F766E', '#14532D', '#7F1D1D', '#581C87', '#F8FAFC', '#FEF3C7', '#DBEAFE'];
// স্বচ্ছ প্রিভিউ PNG-র (07–12, 19–24) কার্ডের সীমানা: [প্রস্থ, উচ্চতা, x0, y0, x1, y1] (পিক্সেল)
const WD_PREVIEW_BOX = {
    '07.png':[1600,932,78,77,1522,836],'08.png':[1600,932,78,77,1522,836],'09.png':[1600,932,78,77,1522,836],
    '10.png':[1600,932,76,77,1524,836],'11.png':[1600,932,78,101,1522,812],'12.png':[1600,704,77,80,1523,606],
    '19.png':[1600,932,78,77,1522,836],'20.png':[1600,932,78,77,1522,836],'21.png':[1600,932,78,77,1522,836],
    '22.png':[1600,932,76,77,1524,836],'23.png':[1600,932,78,101,1522,812],'24.png':[1600,704,77,80,1523,606]
};

function wcBn(n) { return String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]); }
function wcHsv2Rgb(h, s, v) {
    const c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c;
    let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}
function wcRgb2Hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d !== 0) {
        if (mx === r) h = 60 * (((g - b) / d) % 6);
        else if (mx === g) h = 60 * ((b - r) / d + 2);
        else h = 60 * ((r - g) / d + 4);
    }
    if (h < 0) h += 360;
    return { h: h, s: mx === 0 ? 0 : d / mx, v: mx };
}
function wcRgb() { return wcHsv2Rgb(WC.h, WC.s, WC.v); }
function wcHex() {
    return '#' + wcRgb().map(n => n.toString(16).padStart(2, '0')).join('').toUpperCase();
}
function wcSetFromHex(hex) {
    let t = String(hex || '').trim().replace('#', '');
    if (/^[0-9a-fA-F]{3}$/.test(t)) t = t.split('').map(c => c + c).join('');
    if (!/^[0-9a-fA-F]{6}$/.test(t)) return false;
    const hsv = wcRgb2Hsv(parseInt(t.slice(0, 2), 16), parseInt(t.slice(2, 4), 16), parseInt(t.slice(4, 6), 16));
    WC.h = hsv.h; WC.s = hsv.s; WC.v = hsv.v;
    return true;
}
// টোন লাইট কি না (লাইট = গাঢ় লেখা-আইকন) — নেটিভের isLightColor()-এর সাথে একই সূত্র
function wcIsLightTone() {
    if (wdCustomTone === 'light') return true;
    if (wdCustomTone === 'dark') return false;
    const [r, g, b] = wcRgb();
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.6;
}
function wcLoadSaved() {
    try {
        const hx = localStorage.getItem('wdCustomBg');
        if (hx) wcSetFromHex(hx);
        const op = parseInt(localStorage.getItem('wdCustomOpacity'), 10);
        if (op >= 10 && op <= 100) wdCustomOpacity = op;
        const tn = localStorage.getItem('wdCustomTone');
        if (tn === 'auto' || tn === 'dark' || tn === 'light') wdCustomTone = tn;
    } catch (e) {}
}
function wcPersist() {
    try {
        localStorage.setItem('wdCustomBg', wcHex());
        localStorage.setItem('wdCustomOpacity', String(wdCustomOpacity));
        localStorage.setItem('wdCustomTone', wdCustomTone);
    } catch (e) {}
}
function wcDrawWheel() {
    const cv = document.getElementById('wc-wheel');
    if (!cv || !cv.getContext) return;
    const ctx = cv.getContext('2d');
    const W = cv.width, H = cv.height, R = W / 2, img = ctx.createImageData(W, H), d = img.data;
    for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
            const dx = x + 0.5 - R, dy = y + 0.5 - R, r = Math.sqrt(dx * dx + dy * dy), i = (y * W + x) * 4;
            if (r > R) { d[i + 3] = 0; continue; }
            let h = Math.atan2(dy, dx) * 180 / Math.PI; if (h < 0) h += 360;
            const rgb = wcHsv2Rgb(h, Math.min(r / R, 1), 1);
            d[i] = rgb[0]; d[i + 1] = rgb[1]; d[i + 2] = rgb[2];
            d[i + 3] = Math.max(0, Math.min(255, Math.round((R - r) * 255)));
        }
    }
    ctx.putImageData(img, 0, 0);
}
function wcRefreshUi(skipHexInput) {
    const hex = wcHex(), [r, g, b] = wcRgb();
    const knob = document.getElementById('wc-knob');
    if (knob) {
        const a = WC.h * Math.PI / 180, rad = WC.s * 0.5; // 0.5 = ব্যাসার্ধ (কনটেইনারের অর্ধেক)
        knob.style.left = (50 + Math.cos(a) * rad * 100) + '%';
        knob.style.top = (50 + Math.sin(a) * rad * 100) + '%';
        knob.style.background = hex;
    }
    const chip = document.getElementById('wc-chip'); if (chip) chip.style.background = hex;
    const hx = document.getElementById('wc-hex');
    if (hx && !skipHexInput) { hx.value = hex; hx.classList.remove('invalid'); }
    const val = document.getElementById('wc-val');
    if (val) {
        val.value = Math.round(WC.v * 100);
        const full = wcHsv2Rgb(WC.h, WC.s, 1);
        val.style.background = 'linear-gradient(90deg, #000000, rgb(' + full.join(',') + '))';
    }
    const vt = document.getElementById('wc-val-txt'); if (vt) vt.textContent = wcBn(Math.round(WC.v * 100)) + '%';
    const op = document.getElementById('wc-opacity'); if (op) op.value = wdCustomOpacity;
    const ot = document.getElementById('wc-opacity-txt'); if (ot) ot.textContent = wcBn(wdCustomOpacity) + '%';
    ['auto', 'dark', 'light'].forEach(m => {
        const bt = document.getElementById('wcmode-' + m);
        if (bt) bt.classList.toggle('active', wdCustomTone === m);
    });
}
function wcApplyPreviewBg(fileName) {
    const bg = document.getElementById('wd-preview-bg');
    if (!bg) return;
    if (activeWidgetTheme !== 'custom') { bg.classList.add('hidden'); return; }
    const e = WD_PREVIEW_BOX[fileName] || WD_PREVIEW_BOX['07.png'];
    const W = e[0], H = e[1], pad = 30, rr = 62;
    const x0 = e[2] - pad, y0 = e[3] - pad, x1 = e[4] + pad, y1 = e[5] + pad;
    bg.style.left = (x0 / W * 100) + '%';
    bg.style.top = (y0 / H * 100) + '%';
    bg.style.width = ((x1 - x0) / W * 100) + '%';
    bg.style.height = ((y1 - y0) / H * 100) + '%';
    bg.style.borderRadius = (rr / (x1 - x0) * 100) + '% / ' + (rr / (y1 - y0) * 100) + '%';
    const [r, g, b] = wcRgb();
    bg.style.background = 'rgba(' + r + ',' + g + ',' + b + ',' + (wdCustomOpacity / 100) + ')';
    bg.classList.remove('hidden');
}
function wcScheduleNativeSync() {
    if (WC.syncTimer) clearTimeout(WC.syncTimer);
    WC.syncTimer = setTimeout(() => {
        WC.syncTimer = null;
        try { syncWidgetSettingsToNativeBridge(); } catch (e) { console.error('native bridge sync error:', e); }
    }, 300);
}
// রঙ/স্বচ্ছতা বদলালে: সেভ → UI → প্রিভিউ → (বিলম্বে) নেটিভ। টোন "অটো" হলে প্রিভিউ ছবিও (সাদা/গাঢ় লেখা) বদলাতে পারে।
function wcChanged(skipHexInput, tonePossiblyChanged) {
    wcPersist();
    wcRefreshUi(skipHexInput);
    if (tonePossiblyChanged) updateWidgetPreviewImage();
    else {
        const img = document.getElementById('widget-preview-image');
        const m = (img && img.dataset.name) || '07.png';
        wcApplyPreviewBg(m);
        updateWidgetHubChips();
    }
    wcScheduleNativeSync();
}
let _wcLastLight = null;
function wcAfterColorEdit(skipHexInput) {
    const light = wcIsLightTone();
    const toneFlip = (wdCustomTone === 'auto') && (_wcLastLight !== null) && (_wcLastLight !== light);
    _wcLastLight = light;
    wcChanged(skipHexInput, toneFlip);
}
function wcPickFromEvent(ev) {
    const wrap = document.getElementById('wc-wheel-wrap');
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const R = rect.width / 2;
    const dx = ev.clientX - (rect.left + R), dy = ev.clientY - (rect.top + rect.height / 2);
    let h = Math.atan2(dy, dx) * 180 / Math.PI; if (h < 0) h += 360;
    WC.h = h;
    WC.s = Math.min(Math.sqrt(dx * dx + dy * dy) / R, 1);
    if (WC.v < 0.05) WC.v = 0.05; // পুরো কালো হলে হুইল টেনে রঙ বোঝা যায় না — সামান্য উজ্জ্বলতা রাখা
    wcAfterColorEdit(false);
}
function wcInit() {
    if (WC.ready) return;
    const cv = document.getElementById('wc-wheel');
    if (!cv) return;
    WC.ready = true;
    wcDrawWheel();
    let dragging = false;
    cv.addEventListener('pointerdown', ev => { dragging = true; try { cv.setPointerCapture(ev.pointerId); } catch (e) {} wcPickFromEvent(ev); ev.preventDefault(); });
    cv.addEventListener('pointermove', ev => { if (dragging) { wcPickFromEvent(ev); ev.preventDefault(); } });
    const stop = () => { dragging = false; };
    cv.addEventListener('pointerup', stop); cv.addEventListener('pointercancel', stop); cv.addEventListener('lostpointercapture', stop);
    const sw = document.getElementById('wc-swatches');
    if (sw) {
        sw.innerHTML = '';
        WC_PRESETS.forEach(hx => {
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'wc-sw'; b.style.background = hx; b.setAttribute('aria-label', hx);
            b.onclick = () => { wcSetFromHex(hx); wcAfterColorEdit(false); };
            sw.appendChild(b);
        });
    }
    _wcLastLight = wcIsLightTone();
}
function refreshCustomPanel() {
    const panel = document.getElementById('wd-custom-panel');
    if (!panel) return;
    const on = (activeWidgetTheme === 'custom');
    panel.classList.toggle('hidden', !on);
    if (on) { wcInit(); wcRefreshUi(false); }
}
function wcOnValueInput(v) { WC.v = Math.max(0, Math.min(100, parseInt(v, 10) || 0)) / 100; wcAfterColorEdit(false); }
function wcOnOpacityInput(v) { wdCustomOpacity = Math.max(10, Math.min(100, parseInt(v, 10) || 90)); wcChanged(true, false); }
function wcOnHexInput(v) {
    const hx = document.getElementById('wc-hex');
    const ok = /^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(String(v).trim());
    if (hx) hx.classList.toggle('invalid', !ok && String(v).trim().length > 0);
    if (ok && wcSetFromHex(v)) wcAfterColorEdit(true); // টাইপ করার সময় ইনপুট নিজে বদলানো হয় না
}
function wcOnHexBlur() { wcRefreshUi(false); }
function changeCustomTone(mode) {
    wdCustomTone = (mode === 'dark' || mode === 'light') ? mode : 'auto';
    _wcLastLight = wcIsLightTone();
    wcPersist();
    wcRefreshUi(false);
    updateWidgetPreviewImage();
    try { syncWidgetSettingsToNativeBridge(); } catch (e) { console.error('native bridge sync error:', e); }
}
function wcReset() {
    wcSetFromHex('#1E293B'); wdCustomOpacity = 90; wdCustomTone = 'auto';
    _wcLastLight = wcIsLightTone();
    wcPersist(); wcRefreshUi(false);
    updateWidgetPreviewImage();
    try { syncWidgetSettingsToNativeBridge(); } catch (e) { console.error('native bridge sync error:', e); }
}

