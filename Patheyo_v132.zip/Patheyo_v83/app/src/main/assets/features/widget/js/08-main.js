
/* স্টার্টআপ — আগে সেভ করা থিম/টগল রিস্টোর (app-init.js-এর উইজেট অংশ, হুবহু একই নিয়ম) */
function wdLs(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
window.addEventListener('load', function () {
    const savedShowSehriIftar = wdLs('wdShowSehriIftar');
    if (savedShowSehriIftar !== null) { const si = document.getElementById('toggle-wd-sehri-iftar'); if (si) si.checked = (savedShowSehriIftar === 'true'); }

    const savedTheme = wdLs('activeWidgetTheme') || 'glass';
    const savedShowClock = wdLs('wdShowClock');
    const savedShowWeather = wdLs('wdShowWeather');
    if (savedShowClock !== null) { const twc = document.getElementById('toggle-wd-clock'); if (twc) twc.checked = (savedShowClock === 'true'); }
    if (savedShowWeather !== null) { const tww = document.getElementById('toggle-wd-weather'); if (tww) tww.checked = (savedShowWeather === 'true'); }
    const savedNobgMode = wdLs('activeNobgMode');
    if (savedNobgMode === 'light' || savedNobgMode === 'dark') activeNobgMode = savedNobgMode;
    try { wcLoadSaved(); } catch (e) { console.error('custom theme restore error:', e); }
    wdNormalizeToggles(null);
    changeWidgetStyleTheme(['glass','nobg','light','custom'].indexOf(savedTheme) >= 0 ? savedTheme : 'glass');
    setTimeout(syncWidgetSettingsToNativeBridge, 1000);
});
// অ্যান্ড্রয়েড ব্যাক বাটন: এখানে একটাই পেজ, তাই অ্যাপকে নিজের মতো বেরোতে দেওয়া হয়
window.handleNativeBackPress = function () { return false; };

