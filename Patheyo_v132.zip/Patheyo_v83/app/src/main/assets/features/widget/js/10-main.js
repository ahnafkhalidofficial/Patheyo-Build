
/* আইকন অ্যানিমেশন — চোখের পলক ও সারির আইকন পালস */
(function () {
    'use strict';
    var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var rnd = function (a, b) { return a + Math.random() * (b - a); };

    /* ১) মানুষের মতো চোখের পলক: একবার, দুইবার, একবার, দুইবার... (র‍্যান্ডম বিরতিতে) */
    var eye = document.querySelector('.wa-eye .eye-all');
    if (eye && eye.animate) {
        var blink = function () {
            var a = eye.animate(
                [{ transform: 'scaleY(1)' }, { transform: 'scaleY(.07)', offset: .45 }, { transform: 'scaleY(1)' }],
                { duration: 340, easing: 'ease-in-out' }
            );
            return a.finished.catch(function () {});
        };
        (async function loop() {
            var dbl = false;
            while (true) {
                await wait(rnd(2200, 5200));
                await blink();
                if (dbl) { await wait(rnd(120, 190)); await blink(); }
                dbl = !dbl;
            }
        })();
    }

    /* ৩) "উপাদান দেখান/লুকান" আইকনের স্লাইডার: সেটিংসের মতো — তিনটা নবই একসাথে নড়ে নতুন অবস্থানে সেট হয়,
          ১.৫ সেকেন্ড থেমে পরের সেটিংসে যায়; এভাবে লুপে চলে */
    var slg = document.querySelectorAll('.wa-sl .sl');
    if (slg.length === 3 && slg[0].animate) {
        var base = [15, 8, 17];
        var presets = [[15, 8, 17], [7, 17, 10], [18, 12, 5], [10, 5.5, 19]];
        var cur = base.slice(), step = 0;
        var ease = 'cubic-bezier(.22,1,.36,1)';
        var move = async function (i, to) {
            var knob = slg[i].querySelector('.sl-knob'), act = slg[i].querySelector('.sl-act');
            var o = { duration: 1000, easing: ease, fill: 'forwards' };
            var a1 = knob.animate([{ transform: 'translateX(' + (cur[i] - base[i]) + 'px)' }, { transform: 'translateX(' + (to - base[i]) + 'px)' }], o);
            var a2 = act.animate([{ strokeDasharray: (cur[i] - 2) + ' 40' }, { strokeDasharray: (to - 2) + ' 40' }], o);
            var a3 = knob.animate([{ scale: '1' }, { scale: '1.22', offset: .35 }, { scale: '1' }], { duration: 1000, easing: 'ease-in-out' });
            await Promise.all([a1.finished, a2.finished, a3.finished]).catch(function () {});
            try { a1.commitStyles(); a2.commitStyles(); } catch (e) {}
            a1.cancel(); a2.cancel();
            cur[i] = to;
        };
        (async function loop() {
            await wait(1000);
            while (true) {
                step = (step + 1) % presets.length;
                var t = presets[step];
                await Promise.all([0, 1, 2].map(function (i) { return wait(i * 70).then(function () { return move(i, t[i]); }); }));
                await wait(1500);
            }
        })();
    }
})();
