package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/WidgetRefreshScheduler.kt
//
// ✅ v24 — উইজেটের তারিখ/সময় রিফ্রেশ সিস্টেম (Android 7 থেকে সর্বশেষ ভার্সন পর্যন্ত নিয়ম মেনে)
//
// কখন উইজেট "হার্ড রিসেট" (অ্যালার্ম পুনর্গঠন + সম্পূর্ণ পুনরায় রেন্ডার) হয়:
//   ১) প্রতি ৮০ মিনিট পরপর (INTERVAL_REFRESH_MS) — যেকোনো ইভেন্টে রিসেট হলে ঘড়ি আবার ৮০ মিনিট গোনে,
//      তাই দুই রিসেটের মাঝে সর্বোচ্চ ফাঁক ৮০ মিনিট ⇒ দিনে কমপক্ষে ১৮ বার (দাবি ছিল ন্যূনতম ১০)।
//   ২) প্রতিটি ওয়াক্তের শুরুতে (ফজর, সূর্যোদয়, যোহর, আসর, মাগরিব, ইশা, সূর্যাস্ত)।
//      মাগরিব/সূর্যাস্তে রিসেট হলেই আরবি (হিজরি) তারিখ পরের দিনে যায় (PrayerWidgetProvider-এর মাগরিব-শিফট)।
//   ৩) মধ্যরাত ০০:০০:০৩-এ (RC_MIDNIGHT) — ইংরেজি ও বাংলা তারিখ বদলায়, এবং নতুন দিনের নামাজের সময়
//      আনতে (ইন্টারনেট থাকলে) একটা one-time WorkManager কাজ চলে।
//   ৪) নিষিদ্ধ সময়ের শুরু/শেষে, প্রতিটি ফেজ শেষে।
//   ৫) সিস্টেম ইভেন্টে: ফোন রিবুট, অ্যাপ আপডেট, সময়/তারিখ/টাইমজোন বদল, Exact-Alarm অনুমতি বদল
//      (দেখুন WidgetSystemEventReceiver) — এই ইভেন্টগুলোতে Android সব অ্যালার্ম মুছে ফেলে/সময় অচল হয়ে যায়।
//   ৬) WorkManager ব্যাকআপ (৮০ মিনিট) — AlarmManager চেইন কোনোভাবে থেমে গেলে এটা আবার চালু করে।
//
// Android নিয়ম মানা হয়েছে:
//   • API 31+: AlarmManager.canScheduleExactAlarms() না দেখে setExact ডাকলে SecurityException হয় —
//     এখন আগে যাচাই, অনুমতি না থাকলে setAndAllowWhileIdle (ইনএক্সাক্ট, Doze-এও চলে) ব্যবহার হয়।
//   • API 23+: Doze-এর জন্য *AndAllowWhileIdle ব্যবহার।
//   • PendingIntent: FLAG_IMMUTABLE (API 31+ বাধ্যতামূলক) + explicit component।
//   • কোনো উইজেট স্ক্রিনে না থাকলে সব অ্যালার্ম বাতিল (অকারণ ব্যাটারি খরচ নেই) — উইজেট যোগ করলে (onEnabled) আবার চালু।
//   • নেটওয়ার্ক কল কখনো BroadcastReceiver/মেইন থ্রেডে নয় — শুধু WorkManager Worker-এ (CONNECTED শর্তে)।
//   • WorkManager ন্যূনতম পিরিয়ড ১৫ মিনিট; আমরা ৮০ মিনিট ব্যবহার করি (বৈধ)।
//
// পুরনো (v6) নোট: ঘনঘন ১৫-মিনিট হার্টবিট OEM ব্যাটারি-অপ্টিমাইজারকে বিরক্ত করত, তাই event-driven রাখা হয়েছে;
// ৮০ মিনিট (দিনে ~১৮) এখনও সেই সীমার অনেক নিচে।

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone
import java.util.concurrent.TimeUnit

object WidgetRefreshScheduler {

    const val REFRESH_ACTION = "com.gunjoron.patheyo.widget.ACTION_REFRESH_WIDGET"
    private const val RC_INTERVAL       = 8801   // ৮০ মিনিটের নিরাপত্তা-জাল (হার্ড রিসেট চেইন)
    private const val RC_WAQT_BASE      = 8810   // 8810–8816: প্রতিটি waqt শুরু
    private const val RC_PHASE_END      = 8820   // phase শেষের exact alarm
    private const val RC_SUNRISE_FBD    = 8821   // sunrise নিষিদ্ধ শেষ (sunrise+15min)
    private const val RC_DHUHR_FBD_STR  = 8822   // দুপুরের নিষিদ্ধ সময় শুরু (dhuhr-12min)
    private const val RC_SUNSET_FBD_STR = 8823   // সূর্যাস্তের নিষিদ্ধ সময় শুরু (sunset-15min)
    private const val RC_MIDNIGHT       = 8824   // ✅ v24: রাত ১২টা — ইংরেজি/বাংলা তারিখ বদল

    // ✅ v24: ১ ঘণ্টা ২০ মিনিট
    const val INTERVAL_REFRESH_MS = 80 * 60 * 1000L

    private const val DAY_MS = 24 * 60 * 60 * 1000L

    private const val WORK_BACKUP = "ibadat_widget_refresh_80"   // নতুন নাম (পুরনো ৬০-মিনিটেরটা বাতিল করা হয়)
    private const val WORK_BACKUP_OLD = "ibadat_widget_refresh"
    private const val WORK_FETCH_NOW = "ibadat_widget_fetch_now"

    // ------------------------------------------------------------------------------------------
    //  সর্বজনীন API
    // ------------------------------------------------------------------------------------------

    /** স্ক্রিনে অন্তত একটা উইজেট আছে কি না */
    fun hasWidgets(context: Context): Boolean {
        return try {
            val app = context.applicationContext
            AppWidgetManager.getInstance(app)
                .getAppWidgetIds(ComponentName(app, PrayerWidgetProvider::class.java)).isNotEmpty()
        } catch (_: Throwable) { true } // অনিশ্চিত হলে চালু রাখাই নিরাপদ
    }

    /**
     * সব অ্যালার্ম (৮০-মিনিট হার্টবিট + মধ্যরাত + ওয়াক্ত/নিষিদ্ধ-সময়) আবার সেট করে। যেকোনো জায়গা
     * থেকে ডাকা নিরাপদ — কখনো exception ছোঁড়ে না; একই requestCode হওয়ায় ডুপ্লিকেট জমে না।
     */
    fun scheduleAll(context: Context) {
        val app = context.applicationContext
        if (!hasWidgets(app)) {
            // উইজেট নেই ⇒ অকারণ ওয়েকআপ নয় (Android battery guideline)
            try { cancelAll(app) } catch (_: Throwable) {}
            return
        }
        try { scheduleIntervalRefresh(app) } catch (_: Throwable) {}
        try { scheduleMidnight(app) } catch (_: Throwable) {}
        try { scheduleWaqtTriggers(app) } catch (_: Throwable) {}
        try { ensureBackupWork(app) } catch (_: Throwable) {}
    }

    /** এই ক্লাসের সব অ্যালার্ম বাতিল */
    fun cancelAll(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val codes = listOf(RC_INTERVAL, RC_PHASE_END, RC_SUNRISE_FBD, RC_DHUHR_FBD_STR, RC_SUNSET_FBD_STR, RC_MIDNIGHT) +
            (0..6).map { RC_WAQT_BASE + it }
        for (c in codes) {
            try { am.cancel(getRefreshPI(context, c)) } catch (_: Throwable) {}
        }
    }

    /**
     * ✅ v24: "হার্ড রিসেট" — (১) টাইমজোন ক্যাশ রিসেট, (২) সব অ্যালার্ম নতুন করে, (৩) সব উইজেট সম্পূর্ণ
     * পুনরায় রেন্ডার (তারিখ/হিজরি-শিফট/ওয়াক্ত/হাইলাইট/কাউন্টডাউন), (৪) আজকের নামাজের সময় বাসি থাকলে
     * নেটওয়ার্ক-শর্তসহ ব্যাকগ্রাউন্ড fetch লাইনে দেওয়া। নেটওয়ার্ক কল এখানে নয় ⇒ যেকোনো থ্রেড/রিসিভার
     * থেকে নিরাপদ। প্রতিটি ধাপ স্বাধীন — একটা ব্যর্থ হলে বাকিগুলো চলে।
     */
    fun hardReset(context: Context, allowFetchEnqueue: Boolean = true) {
        val app = context.applicationContext
        try { TimeZone.setDefault(null) } catch (_: Throwable) {}   // সিস্টেমের বর্তমান টাইমজোনে ফেরা
        try { scheduleAll(app) } catch (_: Throwable) {}            // সবার আগে — চেইন যেন না ভাঙে
        try { PrayerWidgetProvider.updateWidgetDirectly(app) } catch (_: Throwable) {}
        if (allowFetchEnqueue) {
            try { if (NativePrayerTimesFetcher.isStale(app)) enqueueFetchNow(app) } catch (_: Throwable) {}
        }
        try { recordHardReset(app) } catch (_: Throwable) {}
    }

    /** আজকের নামাজের সময় বাসি হলে: নেটওয়ার্ক পেলেই একবার fetch + রিরেন্ডার (WorkManager) */
    fun enqueueFetchNow(context: Context) {
        val req = OneTimeWorkRequestBuilder<WidgetUpdateWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(WORK_FETCH_NOW, ExistingWorkPolicy.KEEP, req)
    }

    /** ৮০ মিনিটের WorkManager ব্যাকআপ (self-healing)। পুরনো ৬০-মিনিটের কাজটা বাতিল হয়। */
    fun ensureBackupWork(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        try { wm.cancelUniqueWork(WORK_BACKUP_OLD) } catch (_: Throwable) {}
        wm.enqueueUniquePeriodicWork(
            WORK_BACKUP,
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<WidgetUpdateWorker>(80, TimeUnit.MINUTES).build()
        )
        ensureRtdbWork(context)
    }

    /** v62: 15 minute Firebase  (WorkManager  ) */
    fun ensureRtdbWork(context: Context) {
        val req = PeriodicWorkRequestBuilder<RtdbSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            "patheyo_rtdb_sync", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    // phase শেষে exact alarm — negative countdown বন্ধ করতে। PrayerWidgetProvider.updateWidget() থেকে কল হয়।
    fun schedulePhaseEnd(context: Context, phaseEndMillis: Long) {
        try {
            val now = System.currentTimeMillis()
            if (phaseEndMillis <= now) return
            if (phaseEndMillis - now > 6 * 60 * 60 * 1000L) return
            val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            setExactAlarm(am, phaseEndMillis + 1500L, getRefreshPI(context, RC_PHASE_END))
        } catch (_: Throwable) { /* পরের নিয়মিত রিফ্রেশেই ঠিক হবে */ }
    }

    // ------------------------------------------------------------------------------------------
    //  ভেতরের অংশ
    // ------------------------------------------------------------------------------------------

    private fun scheduleIntervalRefresh(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        setExactAlarm(am, System.currentTimeMillis() + INTERVAL_REFRESH_MS, getRefreshPI(context, RC_INTERVAL))
    }

    // ✅ v24: পরবর্তী মধ্যরাত (০০:০০:০৩ স্থানীয় সময়)। DST/টাইমজোন বদলে Calendar সঠিক দিন বের করে।
    private fun scheduleMidnight(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 3); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        setExactAlarm(am, cal.timeInMillis, getRefreshPI(context, RC_MIDNIGHT))
    }

    private fun scheduleWaqtTriggers(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null) ?: return

        try {
            val data = JSONObject(json)

            // প্রতিটি waqt শুরুর সময় (মাগরিব/সূর্যাস্তে ফায়ার হলে আরবি তারিখ পরের দিনে যায়)
            val waqts = listOf("fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha", "sunset")
            waqts.forEachIndexed { index, waqt ->
                val timeStr = data.optString(waqt, "")
                if (timeStr.isNotEmpty()) {
                    setExactAlarm(am, getNextOccurrence(timeStr), getRefreshPI(context, RC_WAQT_BASE + index))
                }
            }

            // সূর্যোদয়ের নিষিদ্ধ সময় শেষ (+১৫ মিনিট)
            val sunriseStr = data.optString("sunrise", "")
            if (sunriseStr.isNotEmpty()) {
                setExactAlarm(am, nextAfterOffset(sunriseStr, 15 * 60 * 1000L), getRefreshPI(context, RC_SUNRISE_FBD))
            }
            // দুপুরের নিষিদ্ধ সময় শুরু (−১২ মিনিট)
            val dhuhrStr = data.optString("dhuhr", "")
            if (dhuhrStr.isNotEmpty()) {
                setExactAlarm(am, nextAfterOffset(dhuhrStr, -12 * 60 * 1000L), getRefreshPI(context, RC_DHUHR_FBD_STR))
            }
            // সূর্যাস্তের নিষিদ্ধ সময় শুরু (−১৫ মিনিট)
            val sunsetStr = data.optString("sunset", "").ifBlank { data.optString("maghrib", "") }
            if (sunsetStr.isNotEmpty()) {
                setExactAlarm(am, nextAfterOffset(sunsetStr, -15 * 60 * 1000L), getRefreshPI(context, RC_SUNSET_FBD_STR))
            }
        } catch (_: Exception) {}
    }

    /** (পরবর্তী occurrence + offset) যেটা এখনো ভবিষ্যতে — অতীতে পড়লে পরের দিনে ঠেলে দেয় (নিষিদ্ধ-সময় অ্যালার্ম যেন হারিয়ে না যায়) */
    private fun nextAfterOffset(hhmm: String, offsetMs: Long): Long {
        val now = System.currentTimeMillis()
        var t = getNextOccurrence(hhmm) + offsetMs
        var guard = 0
        while (t <= now + 1000L && guard < 3) { t += DAY_MS; guard++ }
        return t
    }

    // বিভিন্ন Android ভার্সনে সঠিক alarm মেথড (উপরের নিয়মগুলো দেখুন)
    private fun canUseExact(am: AlarmManager): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { am.canScheduleExactAlarms() } catch (_: Throwable) { false }
        } else true
    }

    private fun setExactAlarm(am: AlarmManager, triggerAt: Long, pi: PendingIntent) {
        try {
            if (canUseExact(am)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            } else {
                // অনুমতি নেই: ইনএক্সাক্ট কিন্তু Doze-এও চলে (কয়েক মিনিট দেরি হতে পারে)
                setInexact(am, triggerAt, pi)
            }
        } catch (_: SecurityException) {
            setInexact(am, triggerAt, pi)
        } catch (_: Throwable) {
            setInexact(am, triggerAt, pi)
        }
    }

    private fun setInexact(am: AlarmManager, triggerAt: Long, pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (_: Throwable) {}
    }

    private fun getRefreshPI(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, PrayerWidgetProvider::class.java).apply {
            action = REFRESH_ACTION
        }
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // পরবর্তী occurrence: ইতোমধ্যে সময় পেরিয়ে গেলে পরের দিন (waqt শুরুর ২ সেকেন্ড পরে)
    private fun getNextOccurrence(hhmm: String): Long {
        return try {
            val parts = hhmm.trim().split(" ")[0].split(":")
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, parts[0].toInt())
            cal.set(Calendar.MINUTE, parts[1].toInt())
            cal.set(Calendar.SECOND, 2)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
            cal.timeInMillis
        } catch (_: Exception) {
            System.currentTimeMillis() + 60 * 1000L
        }
    }

    // শেষ হার্ড রিসেটের সময় ও দৈনিক গণনা (ডায়াগনস্টিক; prefs-এ ছোট দুটো মান)
    private fun recordHardReset(context: Context) {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val today = com.gunjoron.patheyo.FirebaseDataManager.todayDateOnlyStr()
        val day = prefs.getString("hard_reset_day", "")
        val n = if (day == today) prefs.getInt("hard_reset_count", 0) + 1 else 1
        prefs.edit()
            .putString("hard_reset_day", today)
            .putInt("hard_reset_count", n)
            .putLong("hard_reset_last_ms", System.currentTimeMillis())
            .apply()
    }
}
