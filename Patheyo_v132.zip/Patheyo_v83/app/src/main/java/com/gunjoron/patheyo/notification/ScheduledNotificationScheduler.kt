package com.gunjoron.patheyo.notification

// app/src/main/java/com/gunjoron/Patheyo/notification/ScheduledNotificationScheduler.kt
//
// নির্দিষ্ট সময়ে নোটিফিকেশন পাঠানোর জন্য স্কেজুলার (যেমন: জুম'আর দিন ১১টা)
// অ্যাপ বন্ধ থাকলেও কাজ করবে AlarmManager দিয়ে
//
// ✅ সব ধরনের নোটিফিকেশন (সাপ্তাহিক/দৈনিক/মাসিক-হিজরি/বাৎসরিক-হিজরি) এখন একই
// NotificationDataset.items লুপ থেকে পরিচালিত হয়, যাতে নতুন আইটেম যোগ করতে কোড
// পরিবর্তনের দরকার না পড়ে — শুধু IslamicNotificationData.kt-তে এন্ট্রি যোগ করলেই চলবে।

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.MainActivity
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import org.json.JSONObject
import java.net.URL
import java.util.Calendar

object ScheduledNotificationScheduler {

    private const val CHANNEL_ID = "scheduled_notifications"
    private const val NOTIF_ID = 9001
    const val ACTION_SCHEDULED = "com.gunjoron.patheyo.SCHEDULED_NOTIFICATION"

    // ✅ FIX #NEW (নোটিফিকেশন সময়মতো না আসার আসল কারণ ঠিক করা হলো):
    // আগে scheduleAllNotifications() শুধুমাত্র ৩টা জায়গা থেকে ট্রিগার হতো:
    //   ১) অ্যাপ খোলা হলে (MainActivity.onCreate) — এখানেই একমাত্র WorkManager-এর
    //      ঘণ্টাব্যাপী পর্যায়ক্রমিক (periodic) কাজ "ibadat_notif_check" enqueue হতো।
    //   ২) ফোন রিস্টার্ট হলে (BootCompletedReceiver)
    //   ৩) অ্যাপ প্রসেস চালু হলে (PatheyoApp.onCreate)
    // সমস্যা: Android-এর Doze/App-Standby/OEM ব্যাটারি ম্যানেজমেন্ট (Xiaomi/Vivo/Oppo/
    // Samsung-এর মতো ফোনে খুবই কঠোর) — ইউজার কয়েকদিন অ্যাপ না খুললে সিস্টেম WorkManager-এর
    // periodic কাজটাকেই ঘণ্টার পর ঘণ্টা/দিনের পর দিন চালাতে দেয় না। ফলে সেদিনের নোটিফিকেশন
    // schedule-ই হতো না, আর "অ্যাপ আগে ঠিকমতো নোটিফিকেশন দিত, এখন দেয় না" - এমন মনে হতো।
    //
    // সমাধান: উইজেট রিফ্রেশের (WidgetRefreshScheduler) মতোই এখানে একটা স্বয়ংসম্পূর্ণ
    // (self-chaining) AlarmManager exact-alarm heartbeat বসানো হলো — এটা WorkManager-এর
    // উপর নির্ভর করে না, তাই Doze-এও (setExactAndAllowWhileIdle) নির্ভরযোগ্যভাবে চলে।
    // প্রতিবার heartbeat ফায়ার হলে scheduleAllNotifications() কল হয় এবং পরের heartbeat-ও
    // নিজে থেকে আবার শিডিউল হয় (চেইন কখনো ভাঙে না, কারণ প্রতিটা ট্রিগার পয়েন্ট থেকেই
    // পুনরায় চালু করা হয়)।
    const val ACTION_HEARTBEAT = "com.gunjoron.patheyo.NOTIF_HEARTBEAT"
    private const val RC_HEARTBEAT = 8830
    // ✅ FIX #NEW (v6 — battery/wakeup কমানো, দেখুন WidgetRefreshScheduler.kt-এর v6 নোট):
    // ৪৫ মিনিট থেকে বাড়িয়ে ৩ ঘণ্টা করা হলো। এই হার্টবিটের একমাত্র কাজ হলো
    // scheduleAllNotifications() পুনরায় কল করা যাতে নতুন কোনো দিনের/সাপ্তাহিক/মাসিক আইটেম
    // মিস না হয় — কিন্তু এটা এমনিতেই ঘণ্টায় একবার WorkManager periodic job
    // (IslamicNotificationWorker, "ibadat_notif_check") থেকে এবং widget-refresh চেইনের
    // প্রতিটা waqt-ইভেন্ট থেকেও (দিনে ~১০-১২ বার) কল হয়। তাই ৪৫ মিনিটের নিজস্ব exact-alarm
    // চক্র ছিল ব্যাপক রিডান্ডেন্ট — শুধু অতিরিক্ত ব্যাকগ্রাউন্ড ওয়েকআপ যোগ করছিল, যেটা OEM
    // ব্যাটারি-অপ্টিমাইজারকে অ্যাপ বন্ধ/রেসট্রিক্ট করতে প্ররোচিত করত (আর সেটা হলে widget
    // চেইনও একসাথে ভেঙে যেত)। ৩ ঘণ্টা এখনও যথেষ্ট কম — দৈনিক/সাপ্তাহিক নোটিফিকেশন কখনো
    // পুরো একটা দিন মিস হবে না, শুধু বিশুদ্ধ নিরাপত্তা-জাল হিসেবে কাজ করে।
    private const val HEARTBEAT_INTERVAL_MS = 3 * 60 * 60 * 1000L // ৩ ঘণ্টা পরপর

    /**
     * সকল ইসলামিক নোটিফিকেশন চেক ও স্কেজুল করা (WorkManager থেকে ঘণ্টায় একবার কল করা হয়)
     */
    // ✅ v43: আরবি দিন সূর্যাস্তে শুরু হয় — তাই আরবি তারিখ N-এর "রাত" আগে আসে, "দিন" তার পরে।
    // প্রতিটা হিজরি নোটিফিকেশনে এখন phase আছে (দেখুন IslamicNotification.phase):
    //   night = N তারিখের রাত | day = N তারিখের দিন | dusk = N তারিখের দিনের শেষ সূর্যাস্ত
    // আজকের গ্রেগরিয়ান দিনের "দিনের তারিখ" ও "আজ রাতের তারিখ" দুটোই সকালেই জানা যায়, তাই সব
    // নোটিফিকেশন সেদিনের শুরুতেই একসাথে হিসাব করে শিডিউল হয় (ঘণ্টায় ঘণ্টায় মাগরিবের অপেক্ষা করতে হয় না)।
    private const val STALE_MIN_DAYTIME = 360 // বিকাল ৩টার আগের টার্গেট: এর বেশি দেরি হলে আর পাঠানো হয় না
    private const val STALE_MIN_EVENING = 150  // বিকাল ৩টা বা পরের টার্গেট: এর বেশি দেরি হলে আর পাঠানো হয় না
    private const val COLLISION_SHIFT_MIN = 10 // একই মিনিটে দুটো পড়লে কম-গুরুত্বেরটা এতটুকু পিছিয়ে যায়

    private class Candidate(val item: IslamicNotification, val order: Int, val priority: Int, val baseMinute: Int) {
        var minute: Int = baseMinute
    }

    /** ছোট সংখ্যা = বেশি গুরুত্ব। একই মিনিটে মিলে গেলে বেশি গুরুত্বেরটা নিজের সময়ে থাকে */
    private fun priorityOf(type: String): Int = when (type) {
        "annual_hijri", "annual_bengali", "annual_gregorian" -> 1
        "monthly_hijri", "monthly_hijri_last3" -> 2
        "weekly" -> 3
        else -> 4
    }

    private fun isHijriType(type: String): Boolean =
        type == "annual_hijri" || type == "monthly_hijri" || type == "monthly_hijri_last3"

    /** phase খালি থাকলে (পুরনো কনফিগ) "maghrib" timeRef = dusk, বাকি সব = day */
    private fun hijriPhaseOf(item: IslamicNotification): String = when (item.phase) {
        "night", "day", "dusk" -> item.phase
        else -> if (item.timeRef == "maghrib") "dusk" else "day"
    }

    /**
     * v63:    (  day=1)  -    .
     *  (monthly_hijri / annual_hijri, days  1, phase=night)   .
     *  (phase=day)     .
     */
    private fun isMonthStartItem(item: IslamicNotification): Boolean =
        item.type == "annual_hijri" && item.days?.contains(1) == true

    fun scheduleAllNotifications(context: Context) {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null) ?: return

        try {
            val data = JSONObject(json)
            val maghrib = data.optString("maghrib", "")
            val fajr = data.optString("fajr", "")
            val sunrise = data.optString("sunrise", "")
            val sunset = data.optString("sunset", maghrib)
            val maghribMin = parseHm(maghrib)?.let { it.first * 60 + it.second }

            val now = Calendar.getInstance()
            val todayDow = now.get(Calendar.DAY_OF_WEEK)
            val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

            // উইজেটে যে সঠিক (Firebase-এডজাস্ট করা) আরবি তারিখ দেখানো হয়, সেই তারিখই এখানে ব্যবহৃত হয়।
            //   dayHijri   = আজ দিনের বেলার আরবি তারিখ
            //   nightHijri = আজ সূর্যাস্তের পর শুরু হওয়া রাতের আরবি তারিখ
            val hAdj = prefs.getInt("last_rtdb_adjustment", 0)
            val dayHijri: Pair<Int, Int> = FirebaseDataManager.getCorrectedHijriForToday(context, false)
                ?: HijriCalendarHelper.getTodayHijri(false, hAdj).let { Pair(it.day, it.month) }
            val nightHijri: Pair<Int, Int> = FirebaseDataManager.getCorrectedHijriForToday(context, true)
                ?: HijriCalendarHelper.getTodayHijri(true, hAdj).let { Pair(it.day, it.month) }

            var isLastThreeDays: Boolean? = null // lazily computed, শুধু দরকার হলে হিসাব হবে
            var bengaliMonthDay: Pair<Int, Int>? = null // lazily computed (annual_bengali-এর জন্য)
            var gregorianMonthDay: Pair<Int, Int>? = null // lazily computed (annual_gregorian-এর জন্য)

            val configItems = NotificationConfigLoader.load(context)
            val candidates = mutableListOf<Candidate>()
            val unmatchedHijri = mutableListOf<IslamicNotification>()

            configItems.forEachIndexed { index, item ->
                if (!item.enabled) return@forEachIndexed
                val phase = hijriPhaseOf(item)
                val (hDay, hMonth) = if (phase == "night") nightHijri else dayHijri

                var matches = when (item.type) {
                    "weekly" -> item.daysOfWeek?.contains(todayDow) == true
                    "daily" -> true
                    "monthly_hijri" -> item.days?.contains(hDay) == true
                    "monthly_hijri_last3" -> {
                        if (isLastThreeDays == null) {
                            isLastThreeDays = FirebaseDataManager.isWithinLastThreeDaysOfHijriMonth(context)
                        }
                        isLastThreeDays == true
                    }
                    "annual_hijri" -> item.month == hMonth && item.days?.contains(hDay) == true
                    // বাংলা ক্যালেন্ডার (সংস্কারকৃত/সরকারি নিয়ম, ওয়েবভিউর getBengaliCalendarCalculation()-এর সমতুল্য)
                    "annual_bengali" -> {
                        if (bengaliMonthDay == null) bengaliMonthDay = getTodayBengaliMonthDay()
                        val (bm, bd) = bengaliMonthDay!!
                        item.bengaliMonth == bm && item.bengaliDays?.contains(bd) == true
                    }
                    // সাধারণ ইংরেজি (Gregorian) ক্যালেন্ডার — সরাসরি মেলানো হয়
                    "annual_gregorian" -> {
                        if (gregorianMonthDay == null) {
                            gregorianMonthDay = Pair(now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
                        }
                        val (gm, gd) = gregorianMonthDay!!
                        item.gregorianMonth == gm && item.gregorianDays?.contains(gd) == true
                    }
                    else -> false
                }

                // ✅ v43: skip_hijri — যেমন আইয়ামে বীজ রমজানে বা তাশরিকের দিনে আসবে না
                if (matches && isHijriType(item.type) &&
                    item.skipHijri?.any { it.month == hMonth && (it.days == null || it.days.contains(hDay)) } == true) {
                    matches = false
                }

                if (!matches) {
                    if (isHijriType(item.type)) unmatchedHijri.add(item)
                    return@forEachIndexed
                }

                val (h, m) = resolveTime(item, fajr, maghrib, sunrise, sunset) ?: return@forEachIndexed
                var minute = h * 60 + m
                // v63:        (  ) -  ;
                //      maghrib + 40  ( )
                if (isHijriType(item.type) && phase == "night" && isMonthStartItem(item) && maghribMin != null) {
                    minute = maxOf(minute, maghribMin + 40)
                }
                // রাতের নোটিফিকেশন কখনো সূর্যাস্তের আগে যাবে না (দূরের দেশের ইউজারের জন্যও)
                if (isHijriType(item.type) && phase == "night" && maghribMin != null && minute < maghribMin) {
                    minute = maghribMin
                }
                candidates.add(Candidate(item, index, priorityOf(item.type), minute))
            }

            // ✅ v43: একই দিনে একই মিনিটে দুটো নোটিফিকেশন পড়লে — বেশি গুরুত্বেরটা নিজের সময়ে থাকে,
            // অন্যটা ১০ মিনিট করে পিছিয়ে খালি মিনিটে বসে। (বিশেষ/বাৎসরিক > মাসিক > সাপ্তাহিক > দৈনিক)
            val taken = HashSet<Int>()
            candidates.sortedWith(compareBy({ it.priority }, { it.order })).forEach { c ->
                var minute = c.baseMinute
                while (minute in taken && minute + COLLISION_SHIFT_MIN <= 23 * 60 + 59) minute += COLLISION_SHIFT_MIN
                c.minute = minute
                taken.add(minute)
            }

            val todayKey = todayDateKey()
            candidates.forEach { c ->
                val marker = getMarker(context, c.item.id)
                val markedToday = marker != null && (marker == todayKey || marker.startsWith("$todayKey@"))
                val markedMinute = if (markedToday && marker!!.contains("@")) marker.substringAfter("@").toIntOrNull() else null

                // একই সময়ে ইতিমধ্যে শিডিউল করা আছে → আবার করার দরকার নেই (ডুপ্লিকেট নোটিফিকেশন বন্ধ)
                if (markedMinute == c.minute) return@forEach
                // আজ আগে শিডিউল হয়েছিল ও সেই সময় পেরিয়ে গেছে → নতুন করে আবার ফায়ার করা হবে না
                if (markedToday && c.minute <= nowMin) return@forEach
                // সময় অনেক আগে পেরিয়ে গেছে (যেমন সারাদিন ফোন বন্ধ ছিল) → বাসি নোটিফিকেশন পাঠানো হয় না
                val staleLimit = if (c.minute >= 15 * 60) STALE_MIN_EVENING else STALE_MIN_DAYTIME
                if (nowMin - c.minute > staleLimit) {
                    setMarker(context, c.item.id, c.minute)
                    return@forEach
                }
                scheduleNotification(context, c.item.id, c.minute / 60, c.minute % 60, c.item.title, c.item.message, c.item.link, c.item.image)
                setMarker(context, c.item.id, c.minute)
            }

            // হিজরি তারিখ সংশোধন (Firebase) হওয়ার পর যে নোটিফিকেশন আজকের জন্য আর প্রযোজ্য নয়, তার অ্যালার্ম বাতিল
            unmatchedHijri.forEach { item ->
                val marker = getMarker(context, item.id)
                if (marker != null && (marker == todayKey || marker.startsWith("$todayKey@"))) {
                    cancelOne(context, item.id)
                    clearMarker(context, item.id)
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    /**
     * ✅ FIX #NEW: Doze-প্রতিরোধী (Doze-resistant) স্বয়ংক্রিয় হার্টবিট চালু/পুনরায়-চালু করা।
     * WidgetRefreshScheduler-এর ডিজাইন প্যাটার্নের অনুরূপ — একবার ডাকলেই যথেষ্ট, কারণ
     * প্রতিবার ফায়ার হওয়ার সময় নিজে থেকেই পরের বার আবার শিডিউল করে নেয় (self-chaining)।
     * যেকোনো জায়গা থেকে (অ্যাপ ওপেন, প্রসেস স্টার্ট, বুট, এমনকি উইজেট রিফ্রেশ থেকেও) বারবার
     * কল করা সম্পূর্ণ নিরাপদ — FLAG_UPDATE_CURRENT দিয়ে শুধু একই অ্যালার্মটাই রিসেট হয়।
     */
    fun scheduleHeartbeat(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ScheduledNotificationReceiver::class.java).apply {
            action = ACTION_HEARTBEAT
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, RC_HEARTBEAT, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val triggerAt = System.currentTimeMillis() + HEARTBEAT_INTERVAL_MS
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            }
        } catch (_: SecurityException) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    /** আজকের তারিখ "yyyyMMdd" আকারে (SharedPreferences-এ প্রতি-আইটেম শিডিউল-মার্কার রাখতে ব্যবহৃত) */
    private fun todayDateKey(): String {
        val c = Calendar.getInstance()
        return "%04d%02d%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** এই আইটেমের (id) শেষ শিডিউল-মার্কার: "yyyyMMdd@মিনিট" (পুরনো ভার্সনে শুধু "yyyyMMdd" ছিল) */
    private fun getMarker(context: Context, id: String): String? {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString("sched_marker_$id", null)
    }

    /** এই আইটেম (id) আজ দিনের কত মিনিটে (০-১৪৩৯) শিডিউল হলো, তা মনে রাখা */
    private fun setMarker(context: Context, id: String, minute: Int) {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("sched_marker_$id", "${todayDateKey()}@$minute").apply()
    }

    private fun clearMarker(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove("sched_marker_$id").apply()
    }

    /** একটা নির্দিষ্ট আইটেমের শিডিউল করা অ্যালার্ম বাতিল (scheduleNotification-এর একই requestCode) */
    private fun cancelOne(context: Context, id: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ScheduledNotificationReceiver::class.java).apply {
            action = ACTION_SCHEDULED
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, id.hashCode(), intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) alarmManager.cancel(pendingIntent)
    }

    /**
     * "HH:mm" স্ট্রিং-এ মিনিট যোগ/বিয়োগ করা (দিন-রোলওভার হ্যান্ডেল করা লাগে না, কারণ ফলাফল
     * শুধু scheduleNotification()-এর hour/minute হিসেবে ব্যবহৃত হয়, যেটা "আজকের" ক্যালেন্ডারে বসে)
     */
    private fun addMinutesToHm(pair: Pair<Int, Int>, deltaMinutes: Int): Pair<Int, Int> {
        var total = pair.first * 60 + pair.second + deltaMinutes
        total = ((total % 1440) + 1440) % 1440
        return Pair(total / 60, total % 60)
    }

    /**
     * আইটেমের timeRef অনুযায়ী (সূর্যোদয়/সূর্যাস্ত/নির্দিষ্ট সময়) প্রকৃত ঘণ্টা-মিনিট বের করা
     *
     * ✅ FIX #10 (সকাল/সন্ধ্যার নোটিফিকেশনের সময় ঠিক করা হলো): আগে "fajr" timeRef মানে ফজর ওয়াক্ত
     * শুরুর সময়েই নোটিফিকেশন যেত, আর "maghrib" মানে মাগরিব ওয়াক্ত শুরুর সময়ে। এখন থেকে:
     *   - "fajr" (সকালের রেফারেন্স) → সূর্যোদয়ের ৩০ মিনিট আগে
     *   - "maghrib" (সন্ধ্যার রেফারেন্স) → সূর্যাস্তের ৩০ মিনিট পরে
     * এই একই timeRef পুরো JSON কনফিগে (daily/weekly/monthly/annual — সব ধরনের) সকাল/সন্ধ্যার
     * জন্য ব্যবহৃত হয়, তাই এই পরিবর্তন স্বয়ংক্রিয়ভাবে সব ধরনের নোটিফিকেশনেই প্রযোজ্য হয়ে যায় —
     * শুধু "fixed" (নির্দিষ্ট ঘড়ির সময়) ও "morning" (বাংলা/জাতীয় দিবস, সকাল ৮টা ফিক্সড) অপরিবর্তিত থাকে।
     */
    private fun resolveTime(item: IslamicNotification, fajr: String, maghrib: String, sunrise: String, sunset: String): Pair<Int, Int>? {
        return when (item.timeRef) {
            "fixed" -> {
                val h = item.fixedHour ?: return null
                val m = item.fixedMinute ?: 0
                Pair(h, m)
            }
            // ✅ v43: সূর্যোদয় ± offset_minutes (যেমন -৩০ = সূর্যোদয়ের ৩০ মিনিট আগে)
            "sunrise" -> {
                val sr = parseHm(sunrise) ?: parseHm(fajr) ?: return null
                addMinutesToHm(sr, item.offsetMinutes)
            }
            // ✅ v43: সূর্যাস্ত ± offset_minutes (যেমন +২ = সূর্যাস্তের ২ মিনিট পরে)
            "sunset" -> {
                val ss = parseHm(sunset) ?: parseHm(maghrib) ?: return null
                addMinutesToHm(ss, item.offsetMinutes)
            }
            // পুরনো নাম (অপরিবর্তিত): "fajr" → সূর্যোদয়ের ৩০ মিনিট আগে
            "fajr" -> {
                val sr = parseHm(sunrise) ?: parseHm(fajr) ?: return null
                addMinutesToHm(sr, -30)
            }
            // বাংলা/ঐতিহাসিক দিবসের নোটিফিকেশনে ব্যবহৃত — সকাল ৮:০০-এ (ডিভাইসের স্থানীয় সময়)
            "morning" -> Pair(8, 0)
            else -> { // পুরনো ডিফল্ট/"maghrib": সূর্যাস্তের ৩০ মিনিট পরে
                val ss = parseHm(sunset) ?: parseHm(maghrib) ?: return null
                addMinutesToHm(ss, 30)
            }
        }
    }

    /**
     * "annual_bengali" ট্রিগারের জন্য আজকের বাংলা মাস (১=বৈশাখ...১২=চৈত্র) ও তারিখ বের করা।
     * এটা ওয়েবভিউ-এর index.html-এ থাকা getBengaliCalendarCalculation() জাভাস্ক্রিপ্ট ফাংশনের
     * হুবহু কোটলিন সংস্করণ, যাতে অ্যাপের সব জায়গায় (ড্যাশবোর্ড, উইজেট, নোটিফিকেশন) একই বাংলা তারিখ
     * দেখানো/ব্যবহার করা হয় — সংস্কারকৃত/সরকারি বাংলা ক্যালেন্ডার নিয়ম: পহেলা বৈশাখ সবসময় ১৪ এপ্রিল,
     * প্রথম ৬ মাস ৩১ দিন, পরের ৫ মাস ৩০ দিন, ফাল্গুন (১১তম) লিপ ইয়ারে ৩০ নাহলে ২৯ দিন, চৈত্র ৩০ দিন।
     */
    private fun getTodayBengaliMonthDay(): Pair<Int, Int> {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val yr = today.get(Calendar.YEAR)
        val isLeap = (yr % 4 == 0 && yr % 100 != 0) || (yr % 400 == 0)
        val daysInMonths = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (isLeap) 30 else 29, 30)

        fun boishakhStart(year: Int): Calendar = Calendar.getInstance().apply {
            set(year, Calendar.APRIL, 14, 0, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }

        var boishakhMap = boishakhStart(yr)
        if (today.timeInMillis < boishakhMap.timeInMillis) {
            boishakhMap = boishakhStart(yr - 1)
        }

        val diffDays = ((today.timeInMillis - boishakhMap.timeInMillis) / 86400000L).toInt()
        var idx = 0
        var bDay = diffDays + 1
        while (bDay > daysInMonths[idx]) {
            bDay -= daysInMonths[idx]
            idx++
        }
        return Pair(idx + 1, bDay) // ১-ভিত্তিক মাস (১=বৈশাখ ... ১২=চৈত্র)
    }

    /** dp-কে ডিভাইসের density অনুযায়ী px-এ কনভার্ট করা (নোটিফিকেশন বিটম্যাপের সর্বোচ্চ প্রস্থ হিসাবের জন্য) */
    private fun dpToPx(context: Context, dp: Int): Int {
        val density = context.resources.displayMetrics.density
        return (dp * density).toInt()
    }

    private fun parseHm(timeStr: String): Pair<Int, Int>? {
        if (timeStr.isBlank()) return null
        val parts = timeStr.trim().split(" ")[0].split(":")
        if (parts.size < 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        return Pair(h, m)
    }

    /**
     * নির্দিষ্ট সময়ে নোটিফিকেশন স্কেজুল করা
     */
    fun scheduleNotification(
        context: Context,
        type: String,
        hour: Int,
        minute: Int,
        title: String,
        message: String,
        link: String = "",
        image: String = ""
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        createNotificationChannel(context)

        // ✅ FIX #9: আজকের টার্গেট সময় বসানো হচ্ছে — এখানে ইচ্ছাকৃতভাবে আর "সময় পেরিয়ে গেলে
        // +১ দিন" করা হচ্ছে না (আগে এটাই ১ দিন দেরিতে নোটিফিকেশন আসার বাগের মূল কারণ ছিল,
        // কারণ scheduleAllNotifications() বারবার কল হওয়ার সময় "আজ" সবসময় বৈধ দিন হলেও
        // "আগামীকাল" নাও হতে পারত — যেমন সাপ্তাহিক/মাসিক/বাৎসরিক নোটিফিকেশনের ক্ষেত্রে)।
        // scheduleAllNotifications()-এর মার্কার (getMarker/setMarker) গার্ডের কারণে এই ফাংশন
        // প্রতিটা আইটেমের জন্য দিনে সর্বোচ্চ একবারই কল হয়। যদি অ্যাপ/ফোন বন্ধ থাকার কারণে সেই
        // একবার চেক করাটাই টার্গেট সময় পেরিয়ে যাওয়ার পরে হয় (যেমন সারাদিন ফোন বন্ধ ছিল), তাহলে
        // AlarmManager-এর past-due exact alarm সাথে সাথেই ফায়ার হয়ে যায় — তাই ইউজার দেরিতে হলেও
        // সঠিক বার্তাটাই পায়, ভুল দিনের বার্তা পায় না।
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val intent = Intent(context, ScheduledNotificationReceiver::class.java).apply {
            action = ACTION_SCHEDULED
            putExtra("type", type)
            putExtra("title", title)
            putExtra("message", message)
            putExtra("link", link)
            putExtra("image", image)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            type.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // Exact alarm permission নেই
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        }
    }

    /**
     * সব স্কেজুল্ড নোটিফিকেশন বাতিল করা।
     * ✅ FIX: আগে শুধু পুরনো হার্ডকোড করা NotificationDataset.items (ফলব্যাক লিস্ট) থেকে id নিয়ে
     * ক্যান্সেল করা হতো — কিন্তু scheduleAllNotifications() আসলে NotificationConfigLoader.load()
     * (JSON থেকে আসা লাইভ লিস্ট) ব্যবহার করে অ্যালার্ম বসায়। JSON-এ নতুন id যোগ হলে (যেমন
     * bengali_*, bd_*, intl_* ইত্যাদি) সেগুলো ফলব্যাক লিস্টে না থাকায় আগে ঠিকমতো ক্যান্সেল হতো না।
     * তাই এখন লাইভ config থেকেই id নিয়ে ক্যান্সেল করা হচ্ছে, যাতে ১০০% মিলে যায়।
     */
    fun cancelAll(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val allIds = (NotificationConfigLoader.load(context).map { it.id } + NotificationDataset.items.map { it.id }).distinct()
        allIds.forEach { id ->
            val intent = Intent(context, ScheduledNotificationReceiver::class.java).apply {
                action = ACTION_SCHEDULED
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                id.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }

    /**
     * Notification Channel তৈরি করা (Android O+)
     */
    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "ইসলামিক নোটিফিকেশন",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "জুম'আ, রমজান ও অন্যান্য ইসলামিক ইভেন্টের নোটিফিকেশন"
            }

            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    /**
     * সরাসরি নোটিফিকেশন দেখানো (Receiver থেকে কল করার জন্য)
     *
     * @param link  খালি না থাকলে নোটিফিকেশনে ট্যাপ করলে এই লিংক ব্রাউজারে খুলবে;
     *              খালি থাকলে ট্যাপ করলে সরাসরি অ্যাপ (MainActivity) খুলবে
     * @param image খালি না থাকলে নোটিফিকেশনে বড় ছবি (BigPictureStyle) দেখাবে —
     *              "https://..." দিয়ে শুরু হলে ইন্টারনেট থেকে ডাউনলোড হবে,
     *              নয়তো assets/notification_images/ ফোল্ডারের ফাইল হিসেবে ধরা হবে
     * @param onDone ছবি লোড/নোটিফিকেশন দেখানো শেষ হলে কল হয় (BroadcastReceiver-এর
     *               goAsync() PendingResult.finish() করার জন্য প্রয়োজন)
     */
    fun showNotification(
        context: Context,
        title: String,
        message: String,
        link: String = "",
        image: String = "",
        onDone: () -> Unit = {}
    ) {
        createNotificationChannel(context)
        val appContext = context.applicationContext

        // ছবি ছাড়া হলে সরাসরি বানিয়ে দেখিয়ে দাও, নেটওয়ার্ক/ফাইল আই/ও-এর দরকার নেই
        if (image.isBlank()) {
            notify(appContext, title, message, link, null)
            onDone()
            return
        }

        // ছবি লোড করতে হবে বলে ব্যাকগ্রাউন্ড থ্রেডে করা হচ্ছে (main thread ব্লক না হয়)
        Thread {
            val bitmap = try {
                if (image.startsWith("http://") || image.startsWith("https://")) {
                    URL(image).openStream().use { BitmapFactory.decodeStream(it) }
                } else {
                    appContext.assets.open("notification_images/$image").use { BitmapFactory.decodeStream(it) }
                }
            } catch (e: Exception) {
                null // ছবি লোড করা না গেলেও নোটিফিকেশন আসবে, শুধু ছবি ছাড়া
            }

            Handler(Looper.getMainLooper()).post {
                notify(appContext, title, message, link, bitmap)
                onDone()
            }
        }.start()
    }

    /**
     * চূড়ান্ত NotificationCompat বানিয়ে দেখানো — এখানেই link (ক্লিক-থ্রু) ও
     * image (BigPictureStyle) দুটোই যুক্ত হয়
     */
    private fun notify(context: Context, title: String, message: String, link: String, image: Bitmap?) {
        val contentIntent: PendingIntent = if (link.isNotBlank()) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
            PendingIntent.getActivity(
                context, link.hashCode(), browserIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else {
            val appIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            PendingIntent.getActivity(
                context, 0, appIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(context.getColor(R.color.brand_notif_color))
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)

        // ✅ FIX #23 (v9): নোটিফিকেশনের টাইটেল/মেসেজ এখন সাধারণ TextView দিয়ে (কোনো কাস্টম
        // fontFamily ছাড়া — যার যার ফোনের নিজস্ব ডিফল্ট ফন্টে) দেখানো হয়, WidgetFontRenderer-এর
        // Bitmap-render দিয়ে না। কারণ: Sutonny OMJ ফন্টের ঘোষিত লাইন-হাইট মেট্রিক্স ত্রুটিপূর্ণ
        // হওয়ায় একাধিক লাইনের নোটিফিকেশন টেক্সটে (StaticLayout) লাইন একটা আরেকটার উপর উঠে
        // অপঠনযোগ্য হয়ে যাচ্ছিল। Android-এর নিজস্ব TextView সবসময় সঠিক লাইন-স্পেসিং/র‍্যাপিং/
        // কোলাপ্সড-অবস্থায় "..." কাটা — সবকিছু নির্ভুলভাবে করে, তাই এখানে raw title/message
        // সরাসরি setTextViewText() দিয়ে বসানো হচ্ছে — কোনো ellipsize()/renderMultiline() লাগছে
        // না। DecoratedCustomViewStyle ব্যবহার করা হচ্ছে যাতে সিস্টেমের নিজস্ব হেডার (অ্যাপ আইকন,
        // অ্যাপের নাম, সময়) স্বাভাবিকভাবেই থেকে যায়, শুধু টাইটেল/মেসেজের অংশটাই কাস্টম
        // রঙে/সাইজে যায়। ছবিসহ (BigPictureStyle) নোটিফিকেশনে এটা প্রযোজ্য নয় — Android একসাথে
        // BigPictureStyle ও কাস্টম কন্টেন্ট-ভিউ সাপোর্ট করে না, তাই ছবিসহ নোটিফিকেশনের টাইটেল/
        // মেসেজ আগের মতোই সিস্টেম ফন্টে থাকবে (ছবি রেন্ডারিং যাতে কোনোভাবেই না ভাঙে তার জন্য
        // এই সিদ্ধান্ত)।
        if (image == null) {
            val isNight = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
            val titleColor = if (isNight) 0xFFFFFFFF.toInt() else 0xFF1A1A1A.toInt()
            val textColor = if (isNight) 0xFFC7CCD1.toInt() else 0xFF5F6368.toInt()

            val collapsedView = RemoteViews(context.packageName, R.layout.notification_custom_collapsed).apply {
                setTextViewText(R.id.notif_custom_title, title)
                setTextColor(R.id.notif_custom_title, titleColor)
                setTextViewText(R.id.notif_custom_text, message)
                setTextColor(R.id.notif_custom_text, textColor)
            }
            val expandedView = RemoteViews(context.packageName, R.layout.notification_custom_expanded).apply {
                setTextViewText(R.id.notif_custom_title, title)
                setTextColor(R.id.notif_custom_title, titleColor)
                setTextViewText(R.id.notif_custom_text, message)
                setTextColor(R.id.notif_custom_text, textColor)
            }
            builder
                .setCustomContentView(collapsedView)
                .setCustomBigContentView(expandedView)
                .setStyle(NotificationCompat.DecoratedCustomViewStyle())
        }

        // ✅ নোটিফিকেশন প্যানেলে অ্যাপের রঙিন লোগো (large icon হিসেবে) দেখানো হচ্ছে।
        // কারণ: setSmallIcon()-এর আইকন Android নিজেই জোর করে সাদা সিলুয়েট বানিয়ে ফেলে (স্ট্যাটাস
        // বারের নিয়ম অনুযায়ী), তাই সেখানে আসল লোগো কখনোই রঙিন দেখা যাবে না — এটা Android-এর
        // স্বাভাবিক আচরণ, কোনো বাগ না। কিন্তু নোটিফিকেশনের ভেতরে (বড় করে) large icon হিসেবে
        // অ্যাপের রঙিন লোগো/আইকন দেখানো যায়, যেটা অনেক ফোনে/OEM স্কিনে (Xiaomi, Vivo, Oppo, পুরনো
        // Samsung ইত্যাদি) না দিলে ফাঁকা/জেনেরিক আইকন দেখায়। bigPicture-এর ক্ষেত্রে আগে থেকেই বসানো
        // ছিল, এখন ছবি-বিহীন সাধারণ নোটিফিকেশনেও বসানো হলো।
        if (image != null) {
            builder.setLargeIcon(image)
            builder.setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(image)
                    .bigLargeIcon(null as Bitmap?)
            )
        }
        // ছবি ছাড়া কেসে স্টাইল ইতিমধ্যে উপরে DecoratedCustomViewStyle হিসেবে বসানো হয়ে গেছে
        // (Noto Serif Bengali ফন্টসহ কাস্টম ভিউ) — এখানে আর আলাদা করে BigTextStyle বসানোর
        // দরকার নেই, বরং সেটা বসালে কাস্টম ভিউকেই override করে ফেলত।

        val notificationManager = context.getSystemService(NotificationManager::class.java)
        notificationManager?.notify(title.hashCode(), builder.build())
    }
}
