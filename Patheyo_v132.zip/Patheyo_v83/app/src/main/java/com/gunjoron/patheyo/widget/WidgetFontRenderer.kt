package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/WidgetFontRenderer.kt
//
// ✅ FIX #10: হোমস্ক্রিন উইজেটে (RemoteViews) Kalpurush ফন্ট গ্যারান্টিসহ দেখানোর সমাধান।
//
// মূল কারণ: android:fontFamily="@font/kalpurush" — XML স্টাইলে ঠিক থাকলেও RemoteViews-এ এটা
// নির্ভরযোগ্যভাবে কাজ করে না:
//   ১) Android-এর "Fonts in XML" ফিচারটা মূল প্ল্যাটফর্ম TextView-তে API 26 (Android 8.0)-এ যোগ
//      হয়েছিল। এই অ্যাপের minSdk 24 — অর্থাৎ Android 7.x ডিভাইসে এই ফিচারটাই নেই, তাই কাস্টম
//      ফন্ট রেন্ডার না হয়ে স্বয়ংক্রিয়ভাবে ডিফল্ট সিস্টেম ফন্টে ফলব্যাক করে।
//   ২) AndroidX/AppCompat-এর ফন্ট-ব্যাকপোর্ট (যেটা সাধারণ Activity-তে পুরনো API-তেও কাস্টম ফন্ট
//      চালু রাখে) RemoteViews-এ কাজ করে না, কারণ widget layout inflate হয় widget host/launcher
//      অ্যাপের প্রসেসে (আমাদের অ্যাপের প্রসেসে নয়) — সেখানে আমাদের AppCompat factory ইন্সটলই
//      থাকে না।
//   ৩) কিছু কাস্টম OEM লঞ্চার (পুরনো MIUI/EMUI ইত্যাদি) API 26+ ডিভাইসেও widget-এর কাস্টম ফন্ট
//      উপেক্ষা করে নিজস্ব রেন্ডারিং পাথ ব্যবহার করে।
//
// সমাধান: টেক্সটটা আমাদের নিজের অ্যাপ প্রসেসেই (widget host-এ নয়) Canvas + Typeface.createFromAsset
// দিয়ে Bitmap হিসেবে এঁকে ফেলা, তারপর সেই Bitmap RemoteViews.setImageViewBitmap() দিয়ে একটা
// ImageView-তে বসানো। যেহেতু রেন্ডারিং সম্পূর্ণভাবে আমাদের কোডের নিয়ন্ত্রণে, এটা ডিভাইস/লঞ্চার/API
// লেভেল নির্বিশেষে ১০০% গ্যারান্টিসহ কাজ করে।

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.util.TypedValue
import kotlin.math.ceil

object WidgetFontRenderer {

    // ✅ v11: উইজেটের বাংলা ফন্ট "SutonnyOMJ" থেকে বদলে "Gunjoron-Font" করা হলো — বাংলা লেখা ও সব
    // সংখ্যা (বাংলা অঙ্ক) এই ফন্টেই আঁকা হয়। পুরনো SutonnyOMJ.ttf অ্যাসেট ফাইলটা সম্পূর্ণভাবে
    // ডিলিট করা হয়েছে। Bitmap-হিসেবে রেন্ডার হওয়ায় width/height সবসময় paint.measureText()/
    // getTextBounds() থেকেই বের করা হয় (হার্ডকোড করা মাপ নেই), তাই ফন্ট বদলালে সাইজ/লেআউট নিজে
    // থেকেই নতুন ফন্টের প্রকৃত মেট্রিক্স অনুযায়ী সঠিকভাবে মানিয়ে নেবে।
    //
    // ✅ v11: SutonnyOMJ-এ ':' এর কোনো গ্লিফ ছিল না বলে আগে আলাদাভাবে "Cambria Math" ফন্ট
    // ব্যবহার করা হতো শুধু কোলনের জন্য (দেখুন v7-v10-এর পুরনো কমেন্ট, এখন প্রযোজ্য নয়)।
    // "Gunjoron-Font" ফন্টে ':' এর নিজস্ব সঠিক গ্লিফ আছে (যাচাই করা হয়েছে) এবং এই ফন্টের ঘোষিত
    // ascent/descent মেট্রিক্সও স্বাভাবিক/নির্ভরযোগ্য (SutonnyOMJ-এর মতো ত্রুটিপূর্ণ না), তাই এই
    // Cambria Math workaround-টা আর দরকার নেই — CambriaMath.ttf ফাইলটাও সম্পূর্ণ ডিলিট করা
    // হয়েছে। কোড-কাঠামো (typeface/colonTypeface, run-splitting) অপরিবর্তিত রাখা হয়েছে ঝুঁকি
    // কমানোর জন্য — colonTypeface() এখন শুধু typeface()-এর মতোই একই Gunjoron-Font ফন্ট রিটার্ন করে,
    // ফলে ':' সহ পুরো টেক্সট বাস্তবে এক ও অভিন্ন ফন্টেই আঁকা হয় (দেখতে সম্পূর্ণ সামঞ্জস্যপূর্ণ)।
    private const val FONT_ASSET_PATH = "fonts/Gunjoron-Font-Normal.ttf"
    private const val FONT_BOLD_ASSET_PATH = "fonts/Gunjoron-Font-Bold.ttf"

    // কোন ক্যারেক্টারগুলো (ঐতিহাসিক কারণে) আলাদা রানে ভাগ করে আঁকা হয় — বর্তমানে ব্যবহারিক কোনো
    // পার্থক্য নেই যেহেতু colonTypeface() এখন typeface()-এর সমান, কিন্তু ভবিষ্যতে দরকার হলে সহজে
    // আবার আলাদা ফন্ট বসানো যাবে এই একই কাঠামোতে।
    private fun isColonChar(c: Char): Boolean = c == ':'

    @Volatile
    private var cachedTypeface: Typeface? = null

    // ✅ FIX #25 (v9), configurable in v10: সংখ্যা/অক্ষরগুলো একটার সাথে আরেকটা "লেগে" থাকার
    // মতো লাগছিল (SutonnyOMJ ফন্টে)। সমাধান: Paint.letterSpacing (em-এর ভগ্নাংশ হিসেবে) দিয়ে
    // প্রতিটা ক্যারেক্টারের পর সামান্য অতিরিক্ত ফাঁকা যোগ করা হলো — এটা measureText()/
    // getTextBounds()/drawText() সবক'টাতেই স্বয়ংক্রিয়ভাবে হিসাবে চলে আসে।
    //
    // ✅ v11: "Gunjoron-Font" ফন্টের নিজস্ব সংখ্যার পার্শ্ব-ফাঁকা (side-bearing) SutonnyOMJ-এর চেয়ে
    // অনেক বেশি স্বাভাবিক/উদার — তাই ডিফল্ট মান কমিয়ে 0.05 করা হলো (0.12 এই ফন্টে বেশি ফাঁকা
    // ফাঁকা দেখাতে পারত)। ইউজার widget_style_config.json-এ এই মান নিজের পছন্দমতো বদলে নিতে
    // পারবেন (দেখুন WIDGET_CUSTOMIZATION_GUIDE.md)।
    @Volatile
    var letterSpacingEm: Float = 0.05f

    /**
     * ✅ v17: পুরো অ্যাপে একটাই ফন্ট — Gunjoron-Font। নেটিভ স্ক্রিনগুলোর (আজান ওভারলে, অ্যালার্ম) সব
     * TextView/Button-এ এই ফন্ট বসানো হয়। নোটিফিকেশন ইচ্ছা করেই বাদ — সেটা ফোনের নিজস্ব ডিফল্ট ফন্টেই যায়।
     */
    fun applyBanglaFontToTree(context: Context, root: android.view.View?) {
        try {
            val tf = typeface(context)
            fun walk(v: android.view.View?) {
                when (v) {
                    is android.widget.TextView -> {
                        val st = v.typeface?.style ?: Typeface.NORMAL
                        val base = if ((st and Typeface.BOLD) != 0) boldTypeface(context) else tf
                        v.typeface = if ((st and Typeface.ITALIC) != 0) Typeface.create(base, Typeface.ITALIC) else base
                    }
                    is android.view.ViewGroup -> for (i in 0 until v.childCount) walk(v.getChildAt(i))
                    else -> {}
                }
            }
            walk(root)
        } catch (_: Throwable) { /* ফন্ট না পেলে সিস্টেম ফন্টেই থাকবে, ক্র্যাশ নয় */ }
    }

    private fun applyLetterSpacing(p: Paint) {
        p.letterSpacing = letterSpacingEm
    }

    // ✅ v17: ফোনের "ফন্ট সাইজ" সেটিং খুব বড় (যেমন ১.৩×–২×) রাখা থাকলে বিটম্যাপ-লেখাগুলো অনুপাতে বেড়ে
    // উইজেটের উচ্চতা বাড়িয়ে নিচের কাউন্টডাউন কেটে দিত (ছোট/বড় ফোনে আলাদা আচরণের একটা বড় কারণ)।
    // এখন সর্বোচ্চ ১.১৫× পর্যন্ত বাড়ে — সাধারণ সেটিংয়ে (≤১.১৫×) আগের সাইজই থাকে, হুবহু একই।
    private const val MAX_FONT_SCALE = 1.15f
    private fun spToPx(sp: Float, metrics: android.util.DisplayMetrics): Float {
        val scale = metrics.scaledDensity / metrics.density
        val cappedScale = if (scale > MAX_FONT_SCALE) MAX_FONT_SCALE else scale
        return sp * metrics.density * cappedScale
    }

    private fun typeface(context: Context): Typeface {
        cachedTypeface?.let { return it }
        synchronized(this) {
            cachedTypeface?.let { return it }
            val tf = try {
                // app/src/main/assets/fonts/Gunjoron-Font-Normal.ttf
                Typeface.createFromAsset(context.applicationContext.assets, FONT_ASSET_PATH)
            } catch (_: Exception) {
                Typeface.DEFAULT
            }
            cachedTypeface = tf
            return tf
        }
    }

    @Volatile
    private var cachedBoldTypeface: Typeface? = null

    /** ব্র্যান্ড ফন্টের আসল Bold ফাইল (নকল/সিনথেটিক বোল্ড নয়) */
    private fun boldTypeface(context: Context): Typeface {
        cachedBoldTypeface?.let { return it }
        synchronized(this) {
            cachedBoldTypeface?.let { return it }
            val tf = try {
                Typeface.createFromAsset(context.applicationContext.assets, FONT_BOLD_ASSET_PATH)
            } catch (_: Exception) {
                Typeface.DEFAULT_BOLD
            }
            cachedBoldTypeface = tf
            return tf
        }
    }

    private fun typefaceFor(context: Context, bold: Boolean): Typeface =
        if (bold) boldTypeface(context) else typeface(context)

    // ✅ v11: আগে এখানে আলাদা "Cambria Math" টাইপফেস লোড হতো শুধু ':' এর জন্য (SutonnyOMJ-এ
    // কোলনের গ্লিফ না থাকায়)। এখন Gunjoron-Font-তেই কোলনের সঠিক গ্লিফ আছে, তাই এই ফাংশনটা শুধু
    // মূল typeface()-ই রিটার্ন করে — নিচের run-splitting কোড (drawMixed/measureMixed/
    // mixedTopBottom) অপরিবর্তিত/অক্ষত রাখা হয়েছে (ঝুঁকিমুক্ত থাকার জন্য), শুধু এখন উভয় Paint-ই
    // কার্যত একই ফন্ট ব্যবহার করে।
    private fun colonTypeface(context: Context): Typeface = typeface(context)

    // ✅ v7: মিশ্র-ফন্ট রান হিসাব ও আঁকার জন্য শেয়ার্ড হেল্পার। টেক্সটকে কোলন/নন-কোলন "run"-এ
    // ভাগ করে প্রতিটা অংশ যথাযথ Paint দিয়ে মাপে/আঁকে (v11-এ উভয় Paint কার্যত একই ফন্ট)।

    private inline fun forEachRun(text: String, action: (run: String, isColon: Boolean) -> Unit) {
        if (text.isEmpty()) return
        var i = 0
        while (i < text.length) {
            val colon = isColonChar(text[i])
            val start = i
            while (i < text.length && isColonChar(text[i]) == colon) i++
            action(text.substring(start, i), colon)
        }
    }

    private fun measureMixed(text: String, mainPaint: Paint, colonPaint: Paint): Float {
        var width = 0f
        forEachRun(text) { run, colon -> width += (if (colon) colonPaint else mainPaint).measureText(run) }
        return width
    }

    /** টেক্সটের প্রকৃত (কোলন ও মূল অংশ উভয় ফন্টের মেট্রিক্স বিবেচনা করে) top/bottom — যাতে কোনো
     *  অংশ বিটম্যাপে কেটে না যায়, ঠিক renderHijriDateInternal-এর মূল/ছোট সাইজ কম্বিনেশনের মতোই।
     *
     *  ⚠️ FIX #20 (v7): কোলনের জন্য colonPaint.fontMetrics() (পুরো ফন্টের ঘোষিত ascent/descent)
     *  ব্যবহার করা হয় না — কারণ "Cambria Math" একটা ম্যাথ-ফন্ট, জটিল স্ট্যাক্ড ইকুয়েশন/ফ্র্যাকশনের
     *  জন্য ডিজাইন করা, তাই এর ঘোষিত OS/2 win-ascent+descent প্রকৃত ফন্ট সাইজের ৫ গুণেরও বেশি।
     *
     *  ✅ FIX #26 (v9): মূল (Sutonny) অংশের জন্যও এখন আর mainPaint.fontMetrics() ব্যবহার করা হয়
     *  না — একই নীতিতে। কারণ ধরা পড়েছে Sutonny OMJ-এর নিজস্ব ঘোষিত ascent/descent বেশিরভাগ
     *  সাধারণ বাংলা অক্ষর/সংখ্যার প্রকৃত দৃশ্যমান উচ্চতার চেয়ে অনেক বেশি ফাঁকা জায়গা রাখে। এর
     *  ফলে প্রতিটা বিটম্যাপের উপরে-নিচে অদৃশ্য প্যাডিং তৈরি হচ্ছিল, আর দুটো পরপর বিটম্যাপ স্ট্যাক
     *  করলে (যেমন নামাজের নাম ও তার নিচের সময়, বা হিজরি তারিখ ও তার নিচের ইংরেজি/বাংলা তারিখ)
     *  মাঝের ফাঁকা জায়গা অস্বাভাবিক বড় দেখাচ্ছিল। সমাধান: getTextBounds() দিয়ে প্রতিটা রানের
     *  (colon/non-colon আলাদাভাবে, যেহেতু Sutonny-তে ':' এর গ্লিফ নেই) প্রকৃত দৃশ্যমান কালি (ink)
     *  বের করে সেটার ভিত্তিতেই বিটম্যাপের উচ্চতা ঠিক করা হয় — কোনো লেখা কাটা পড়ে না, কারণ এই
     *  মাপ ঠিক ওই টেক্সটটার জন্যই নির্ভুলভাবে হিসাব করা (approximation না)। স্পেস/ফাঁকা টেক্সটের
     *  ক্ষেত্রে (কোনো দৃশ্যমান কালিই নেই) নিরাপদ ফলব্যাক হিসেবে fontMetrics ব্যবহার হয়, যাতে
     *  বিটম্যাপ কখনো শূন্য/অস্বাভাবিক উচ্চতার না হয়ে যায়। */
    private fun mixedTopBottom(text: String, mainPaint: Paint, colonPaint: Paint): Pair<Float, Float> {
        var top: Float? = null
        var bottom: Float? = null
        val rect = Rect()
        forEachRun(text) { run, colon ->
            val p = if (colon) colonPaint else mainPaint
            p.getTextBounds(run, 0, run.length, rect)
            if (rect.top != 0 || rect.bottom != 0) {
                val t = rect.top.toFloat()
                val b = rect.bottom.toFloat()
                top = if (top == null) t else minOf(top!!, t)
                bottom = if (bottom == null) b else maxOf(bottom!!, b)
            }
        }
        if (top == null || bottom == null) {
            // কোনো রানেই দৃশ্যমান কালি পাওয়া যায়নি (যেমন শুধুই স্পেস) — নিরাপদ ফলব্যাক
            val fm = mainPaint.fontMetrics
            top = fm.top
            bottom = fm.bottom
        }
        return top!! to bottom!!
    }

    private fun drawMixed(canvas: Canvas, text: String, startX: Float, baseline: Float, mainPaint: Paint, colonPaint: Paint) {
        var x = startX
        forEachRun(text) { run, colon ->
            val p = if (colon) colonPaint else mainPaint
            canvas.drawText(run, x, baseline, p)
            x += p.measureText(run)
        }
    }

    // ✅ FIX #19 (v7), সংশোধিত FIX #20-এ: renderMultiline()-এ StaticLayout-এর ভেতরে ':'
    // ক্যারেক্টারকে আলাদা টাইপফেসে (Cambria Math) দেখানোর জন্য span।
    //
    // ⚠️ প্রথমে MetricAffectingSpan দিয়ে বানানো হয়েছিল, কিন্তু সেটাতে একটা গুরুতর সমস্যা ছিল:
    // MetricAffectingSpan-এর updateMeasureState() StaticLayout-কে বলে দেয় "এই রানের জন্য
    // Cambria Math-এর নিজস্ব ফন্ট-মেট্রিক্স ব্যবহার করো" — আর Cambria Math যেহেতু জটিল স্ট্যাক্ড
    // ইকুয়েশনের জন্য বানানো ম্যাথ-ফন্ট, তার ঘোষিত ascent/descent প্রকৃত সাইজের ৫ গুণেরও বেশি।
    // ফলে ':' থাকা যেকোনো লাইনের উচ্চতা StaticLayout অস্বাভাবিক বড় করে ফেলত (পুরো নোটিফিকেশন/
    // উইজেট বড় দেখানোর মূল কারণ এটাই ছিল)।
    //
    // সমাধান: ReplacementSpan ব্যবহার করা হলো (এটাও MetricAffectingSpan-এর সাবক্লাস, কিন্তু এর
    // updateMeasureState() ইচ্ছাকৃতভাবে ফাঁকা/no-op — তাই এটা লাইনের ফন্ট-মেট্রিক্সে কোনো প্রভাব
    // ফেলে না)। getSize()-এ ইচ্ছাকৃতভাবে fm (FontMetricsInt) স্পর্শ করা হয়নি, তাই লাইনের উচ্চতা
    // সম্পূর্ণভাবে চারপাশের মূল (Sutonny) টেক্সটের মেট্রিক্স দিয়েই নির্ধারিত হয় — ঠিক যেন ':' জায়গায়
    // সাধারণ Sutonny টেক্সটই ছিল, শুধু draw()-এর সময় আমরা নিজেদের colonPaint (Cambria Math)
    // দিয়ে সঠিক গ্লিফটা এঁকে দিই। প্রস্থ (width) এখনও Cambria Math-এর নিজস্ব measureText থেকেই
    // নেওয়া হয়, তাই আঁকা ও মাপা একদম মিলে যায়।
    private class ColonReplacementSpan(private val colonPaint: Paint) : android.text.style.ReplacementSpan() {
        override fun getSize(
            paint: Paint,
            text: CharSequence,
            start: Int,
            end: Int,
            fm: Paint.FontMetricsInt?
        ): Int {
            // fm ইচ্ছাকৃতভাবে অপরিবর্তিত — লাইনের height-এ কোনো প্রভাব ফেলবে না
            return ceil(colonPaint.measureText(text, start, end)).toInt()
        }

        override fun draw(
            canvas: Canvas,
            text: CharSequence,
            start: Int,
            end: Int,
            x: Float,
            top: Int,
            y: Int,
            bottom: Int,
            paint: Paint
        ) {
            canvas.drawText(text, start, end, x, y.toFloat(), colonPaint)
        }
    }

    /**
     * বাংলা টেক্সটকে SutonnyOMJ ফন্টে transparent-background Bitmap হিসেবে রেন্ডার করে (টেক্সটের
     * ভেতরে থাকা ':' ক্যারেক্টার স্বয়ংক্রিয়ভাবে Cambria Math ফন্টে, একই সাইজে আঁকা হয়)।
     * widget-এর ImageView-তে views.setImageViewBitmap(id, bitmap) দিয়ে বসাতে হবে।
     *
     * @param textSizeSp   XML-এ যেমন sp ব্যবহার হতো, সেই একই মান দিন (density অনুযায়ী px-এ কনভার্ট হয়)
     * @param colorInt     0xAARRGGBB ফরম্যাটে রঙ (যেমন 0xFFFFFFFF.toInt())
     * @param bold         বোল্ড দেখাতে চাইলে true
     */
    fun render(
        context: Context,
        text: String,
        textSizeSp: Float,
        colorInt: Int,
        bold: Boolean = false
    ): Bitmap {
        // ✅ FIX #NEW (v4): OutOfMemoryError হলো Exception নয়, Error — তাই বাকি কোডবেসের কোনো
        // "catch (_: Exception)" এটা ধরতে পারত না। পুরনো/কম-RAM ফোনে (widget প্রতি ১৫ মিনিটে বহুবার
        // বিটম্যাপ আঁকে) এটা মাঝেমধ্যে ঘটার আশঙ্কা থাকে, আর একবার uncaught হলে পুরো widget-রিফ্রেশ
        // চেইনটাই ভেঙে যেত (দেখুন PrayerWidgetProvider-এর FIX #NEW)। এখন যেকোনো Throwable-এ নিরাপদে
        // একটা ন্যূনতম, খালি (transparent) ১x১ বিটম্যাপে ফলব্যাক করে — সেই একটা লেবেল ফাঁকা দেখাবে,
        // কিন্তু পুরো widget বা রিফ্রেশ-চেইন ক্র্যাশ করবে না।
        return try {
            renderInternal(context, text, textSizeSp, colorInt, bold)
        } catch (t: Throwable) {
            try { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }
            catch (_: Throwable) { Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8) }
        }
    }

    private fun renderInternal(
        context: Context,
        text: String,
        textSizeSp: Float,
        colorInt: Int,
        bold: Boolean
    ): Bitmap {
        val safeText = text.ifEmpty { " " }
        val metrics = context.resources.displayMetrics
        val textSizePx = spToPx(textSizeSp, metrics)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = this@WidgetFontRenderer.typefaceFor(context, bold)
            this.textSize = textSizePx
            color = colorInt
            isFakeBoldText = false
        }
        applyLetterSpacing(paint)
        // ✅ FIX #19 (v7): ':' ক্যারেক্টারের জন্য আলাদা Cambria Math Paint — বাকি সব বৈশিষ্ট্য
        // (textSize, color, bold) মূল Paint-এর সাথে হুবহু একই রাখা হয়েছে, যাতে সাইজ/রঙ অভিন্ন থাকে।
        val colonPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = this@WidgetFontRenderer.typefaceFor(context, bold)
            this.textSize = textSizePx
            color = colorInt
            isFakeBoldText = false
        }
        applyLetterSpacing(colonPaint)

        val textWidth = measureMixed(safeText, paint, colonPaint)
        val (top, bottom) = mixedTopBottom(safeText, paint, colonPaint)
        // সামান্য পার্শ্ব-মার্জিন (১-২px) — ইতালিক/কার্ভি বাংলা গ্লিফ কেটে না যাওয়ার জন্য
        val width = ceil(textWidth).toInt().coerceAtLeast(1) + 2
        val height = ceil(bottom - top).toInt().coerceAtLeast(1) + 2

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val baseline = -top + 1f
        drawMixed(canvas, safeText, 1f, baseline, paint, colonPaint)
        return bitmap
    }

    /**
     * ✅ v17: "ইংরেজি তারিখ | বাংলা তারিখ" লাইন। মাঝের দাগটা আর ফন্টের '|' অক্ষর না — Canvas-এ সরাসরি
     * আঁকা নরম-কোণা লাইন, তাই ফন্ট/নেট/ফোনের ভার্সন নির্বিশেষে সব ফোনে হুবহু একরকম দেখায়।
     * দাগের উচ্চতা = লেখার সাইজ × sepHeightEm, চওড়াই = sepWidthDp, রঙ আলাদা (সামান্য হালকা)।
     * দাগটা সংখ্যার (অঙ্কের) দৃশ্যমান উচ্চতার ঠিক মাঝ বরাবর বসে।
     */
    fun renderDateLine(
        context: Context,
        leftText: String,
        rightText: String,
        textSizeSp: Float,
        colorInt: Int,
        bold: Boolean,
        sepVisible: Boolean,
        sepHeightEm: Float,
        sepWidthDp: Float,
        sepGapEm: Float,
        sepColorInt: Int
    ): Bitmap {
        return try {
            renderDateLineInternal(context, leftText, rightText, textSizeSp, colorInt, bold, sepVisible, sepHeightEm, sepWidthDp, sepGapEm, sepColorInt)
        } catch (t: Throwable) {
            try { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }
            catch (_: Throwable) { Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8) }
        }
    }

    private fun renderDateLineInternal(
        context: Context,
        leftText: String,
        rightText: String,
        textSizeSp: Float,
        colorInt: Int,
        bold: Boolean,
        sepVisible: Boolean,
        sepHeightEm: Float,
        sepWidthDp: Float,
        sepGapEm: Float,
        sepColorInt: Int
    ): Bitmap {
        val metrics = context.resources.displayMetrics
        val sizePx = spToPx(textSizeSp, metrics)
        val tf = typeface(context)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = typefaceFor(context, bold); textSize = sizePx; color = colorInt; isFakeBoldText = false
        }
        applyLetterSpacing(paint)

        val l = leftText.trim().ifEmpty { " " }
        val r = rightText.trim()
        val leftW = paint.measureText(l)
        val rightW = if (r.isNotEmpty()) paint.measureText(r) else 0f
        val gapPx = sizePx * sepGapEm
        val sepW = sepWidthDp * metrics.density
        val hasSep = sepVisible && r.isNotEmpty()
        val middle = if (hasSep) gapPx + sepW + gapPx else if (r.isNotEmpty()) gapPx * 1.4f else 0f

        // লেখার দৃশ্যমান top/bottom (বেসলাইন থেকে) — দুই অংশের মিলিত
        val (lt, lb) = mixedTopBottom(l, paint, paint)
        var top = lt; var bottom = lb
        if (r.isNotEmpty()) {
            val (rt, rb) = mixedTopBottom(r, paint, paint)
            top = minOf(top, rt); bottom = maxOf(bottom, rb)
        }
        // দাগ: সংখ্যার মাঝ বরাবর (অঙ্কের উচ্চতা ≈ ০.৫৭ em, তাই কেন্দ্র বেসলাইনের ০.২৮ em উপরে)
        val sepH = sizePx * sepHeightEm
        val sepCenterY = -0.28f * sizePx
        if (hasSep) {
            top = minOf(top, sepCenterY - sepH / 2f)
            bottom = maxOf(bottom, sepCenterY + sepH / 2f)
        }

        val width = ceil(leftW + middle + rightW).toInt().coerceAtLeast(1) + 2
        val height = ceil(bottom - top).toInt().coerceAtLeast(1) + 2
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val baseline = -top + 1f

        canvas.drawText(l, 1f, baseline, paint)
        if (r.isNotEmpty()) {
            if (hasSep) {
                val sepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sepColorInt }
                val sx = 1f + leftW + gapPx
                val sy = baseline + sepCenterY
                val rad = sepW / 2f
                canvas.drawRoundRect(android.graphics.RectF(sx, sy - sepH / 2f, sx + sepW, sy + sepH / 2f), rad, rad, sepPaint)
            }
            canvas.drawText(r, 1f + leftW + middle, baseline, paint)
        }
        return bitmap
    }

    /**
     * ✅ FIX #NEW (v6, প্রয়োজনীয়তা #৩): হিজরি তারিখ লাইনের জন্য — দিনের সংখ্যাটা বড়-বোল্ড
     * সাইজে, আর মাসের নাম + সাল ছোট সাইজে (ইংরেজি/বাংলা তারিখের লাইনের মতোই), কিন্তু দুটোই
     * একই লাইনে, একই বেসলাইনে অ্যালাইন করে একটা বিটম্যাপে আঁকা হয় (যেমন "28°সে."-এ বড় সংখ্যা
     * আর ছোট ইউনিট একসাথে বসে) — এখানে দুই সাইজের ফন্ট মেট্রিক্স বিবেচনা করে overall
     * ascent/descent হিসাব করে বিটম্যাপ সাইজ ঠিক করা হয়, যাতে কোনো অংশ কাটা না পড়ে।
     *
     * @param dayText   দিনের সংখ্যা (বড় সাইজে, বোল্ড)
     * @param restText  মাসের নাম ও সাল (ছোট সাইজে, নরমাল ওয়েট) — খালি হলে শুধু dayText আঁকা হয়
     */
    fun renderHijriDate(
        context: Context,
        dayText: String,
        restText: String,
        bigSizeSp: Float,
        smallSizeSp: Float,
        colorInt: Int,
        // ✅ v14: মাস+সাল অংশের আলাদা রঙ/বোল্ড (দিনের সংখ্যা থেকে স্বতন্ত্র) — না দিলে আগের মতোই
        // একই রঙ ও (দিন=বোল্ড, মাস-সাল=নরমাল) ব্যবহার হয়, তাই পুরনো আচরণ অক্ষত থাকে।
        smallColorInt: Int = colorInt,
        bigBold: Boolean = true,
        smallBold: Boolean = false
    ): Bitmap {
        return try {
            renderHijriDateInternal(context, dayText, restText, bigSizeSp, smallSizeSp, colorInt, smallColorInt, bigBold, smallBold)
        } catch (t: Throwable) {
            try { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }
            catch (_: Throwable) { Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8) }
        }
    }

    private fun renderHijriDateInternal(
        context: Context,
        dayText: String,
        restText: String,
        bigSizeSp: Float,
        smallSizeSp: Float,
        colorInt: Int,
        smallColorInt: Int,
        bigBold: Boolean,
        smallBold: Boolean
    ): Bitmap {
        val safeDay = dayText.ifEmpty { " " }
        val safeRest = restText.trim()
        val metrics = context.resources.displayMetrics
        val bigSizePx = spToPx(bigSizeSp, metrics)
        val smallSizePx = spToPx(smallSizeSp, metrics)
        val gapPx = spToPx(smallSizeSp * 0.4f, metrics)

        val tf = typeface(context)
        val colonTf = colonTypeface(context)
        val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = typefaceFor(context, bigBold); textSize = bigSizePx; color = colorInt; isFakeBoldText = false
        }.also { applyLetterSpacing(it) }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = typefaceFor(context, smallBold); textSize = smallSizePx; color = smallColorInt; isFakeBoldText = false
        }.also { applyLetterSpacing(it) }
        // ✅ FIX #19 (v7): দিন/মাস অংশে যদি কখনো ':' চলে আসে (নিরাপদ ফলব্যাক), সেটাও একই সাইজে
        // Cambria Math দিয়ে আঁকা হবে — dayText/restText-এর নিজ নিজ সাইজের সাথে মিলিয়ে।
        val bigColonPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = typefaceFor(context, bigBold); textSize = bigSizePx; color = colorInt; isFakeBoldText = false
        }.also { applyLetterSpacing(it) }
        val smallColonPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = typefaceFor(context, smallBold); textSize = smallSizePx; color = smallColorInt; isFakeBoldText = false
        }.also { applyLetterSpacing(it) }

        val dayWidth = measureMixed(safeDay, bigPaint, bigColonPaint)
        val restWidth = if (safeRest.isNotEmpty()) measureMixed(safeRest, smallPaint, smallColonPaint) else 0f
        val extraGap = if (safeRest.isNotEmpty()) gapPx else 0f

        val (dayTop, dayBottom) = mixedTopBottom(safeDay, bigPaint, bigColonPaint)
        // ✅ FIX #26 (v9): restText খালি থাকলে smallPaint.fontMetrics() দিয়ে ফলব্যাক করা হতো,
        // যেটা অব্যবহৃত হলেও day-এর বিটম্যাপ height-কে অকারণে বড় করে ফেলতে পারত (ফন্টের
        // ঘোষিত মেট্রিক্স অনির্ভরযোগ্য, উপরের FIX #26 কমেন্ট দেখুন) — এখন restText খালি থাকলে
        // শুধু dayTop/dayBottom-ই ব্যবহার হয়, কোনো অপ্রাসঙ্গিক ফলব্যাক মেশানো হয় না।
        val (top, bottom) = if (safeRest.isNotEmpty()) {
            val (restTop, restBottom) = mixedTopBottom(safeRest, smallPaint, smallColonPaint)
            // দুই সাইজের মধ্যে যেটার top/bottom বেশি (আরও উপরে/নিচে যায়) সেটা অনুযায়ী সামগ্রিক
            // উচ্চতা নেওয়া হচ্ছে, যাতে কোনো অংশ কাটা না পড়ে — উভয়ে একই বেসলাইনে বসবে।
            minOf(dayTop, restTop) to maxOf(dayBottom, restBottom)
        } else {
            dayTop to dayBottom
        }

        val width = ceil(dayWidth + extraGap + restWidth).toInt().coerceAtLeast(1) + 2
        val height = ceil(bottom - top).toInt().coerceAtLeast(1) + 2

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val baseline = -top + 1f
        drawMixed(canvas, safeDay, 1f, baseline, bigPaint, bigColonPaint)
        if (safeRest.isNotEmpty()) {
            drawMixed(canvas, safeRest, 1f + dayWidth + extraGap, baseline, smallPaint, smallColonPaint)
        }
        return bitmap
    }

    /**
     * ✅ FIX #17: কোলাপ্সড নোটিফিকেশনে ১ লাইনে "..." দিয়ে কেটে দেখানোর জন্য — সঠিক টাইপফেস
     * (SutonnyOMJ) দিয়েই মাপ করা হয়, তাই কাটার জায়গাটা render()-এর প্রকৃত রেন্ডার-করা প্রস্থের
     * সাথে প্রায় নির্ভুলভাবে মিলে যায় (নোট: এখানে ':' এর জন্য Cambria Math-এর প্রস্থ আলাদা করে
     * ধরা হয়নি — কোলনের প্রস্থ-পার্থক্য নগণ্য বলে ট্রাংকেশন-পয়েন্টে কোনো লক্ষণীয় প্রভাব ফেলে না)।
     */
    fun ellipsize(context: Context, text: String, textSizeSp: Float, maxWidthPx: Int): String {
        val metrics = context.resources.displayMetrics
        val paint = android.text.TextPaint().apply {
            typeface = this@WidgetFontRenderer.typeface(context)
            textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, textSizeSp, metrics)
        }
        return android.text.TextUtils.ellipsize(
            text, paint, maxWidthPx.toFloat(), android.text.TextUtils.TruncateAt.END
        ).toString()
    }

    /**
     * ✅ FIX #17: নোটিফিকেশনের টাইটেল/মেসেজের জন্য — উইজেটের render()-এর মতোই কিন্তু একাধিক
     * লাইনে wrap করে আঁকে (নোটিফিকেশনের মেসেজ প্রায়ই এক লাইনের বেশি লম্বা হয়, যেমন জিকিরের
     * পূর্ণ বাক্য)। প্রথমে notification_custom_*.xml-এ সরাসরি android:fontFamily="@font/..."
     * ব্যবহার করা হয়েছিল, কিন্তু সেটা ভুল ছিল — এই একই কোডবেসে উইজেটের জন্য আগেই প্রমাণিত হয়েছে
     * (উপরের FIX #10 কমেন্ট দেখুন) যে RemoteViews-এ (নোটিফিকেশনও RemoteViews দিয়েই তৈরি, বিভিন্ন
     * OEM-এর SystemUI/নোটিফিকেশন-শেড প্রসেসে ইনফ্লেট হয়) XML ফন্ট নির্ভরযোগ্যভাবে কাজ করে না।
     * তাই এখানেও একই বিটম্যাপ-রেন্ডারিং পদ্ধতি ব্যবহার করা হলো — StaticLayout দিয়ে টেক্সট wrap
     * করে Canvas-এ আঁকা হয়, ফলাফল RemoteViews.setImageViewBitmap() দিয়ে বসাতে হবে।
     *
     * @param maxWidthPx   সর্বোচ্চ প্রস্থ (px) — এর বেশি হলে টেক্সট পরের লাইনে চলে যাবে
     */
    fun renderMultiline(
        context: Context,
        text: String,
        textSizeSp: Float,
        colorInt: Int,
        maxWidthPx: Int,
        bold: Boolean = false
    ): Bitmap {
        // ✅ FIX #NEW (v4): render()-এর মতো এখানেও OutOfMemoryError/অন্য কোনো Throwable থেকে
        // নিরাপদ ফলব্যাক — যাতে নোটিফিকেশন রেন্ডারিং ব্যর্থ হলে সেটা একই প্রসেসে চলা widget
        // রিফ্রেশ চেইনকে প্রভাবিত করতে না পারে।
        return try {
            renderMultilineInternal(context, text, textSizeSp, colorInt, maxWidthPx, bold)
        } catch (t: Throwable) {
            try { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }
            catch (_: Throwable) { Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8) }
        }
    }

    private fun renderMultilineInternal(
        context: Context,
        text: String,
        textSizeSp: Float,
        colorInt: Int,
        maxWidthPx: Int,
        bold: Boolean
    ): Bitmap {
        val safeText = text.ifEmpty { " " }
        val metrics = context.resources.displayMetrics
        val textSizePx = spToPx(textSizeSp, metrics)
        val safeMaxWidth = maxWidthPx.coerceAtLeast(50)

        val paint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = this@WidgetFontRenderer.typefaceFor(context, bold)
            this.textSize = textSizePx
            color = colorInt
            isFakeBoldText = false
        }
        applyLetterSpacing(paint)

        // ✅ FIX #19/#20 (v7): StaticLayout একটামাত্র Paint নিয়ে কাজ করে, তাই মাল্টিলাইন টেক্সটে
        // মিশ্র-ফন্ট পেতে ':' ক্যারেক্টারগুলোর ওপর একটা ReplacementSpan (Cambria Math টাইপফেস)
        // বসানো হয় — এটা লাইনের ascent/descent-এ কোনো প্রভাব ফেলে না (দেখুন ColonReplacementSpan-
        // এর কমেন্ট), তাই লাইনের উচ্চতা সবসময় Sutonny টেক্সটের সমানই থাকে, শুধু ':' নিজের সঠিক
        // ফন্টেই (Cambria Math) আঁকা হয়।
        val spannable = android.text.SpannableStringBuilder(safeText)
        val colonPaintForSpan = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = this@WidgetFontRenderer.typefaceFor(context, bold)
            this.textSize = textSizePx
            color = colorInt
            isFakeBoldText = false
        }
        for (i in safeText.indices) {
            if (isColonChar(safeText[i])) {
                spannable.setSpan(
                    ColonReplacementSpan(colonPaintForSpan),
                    i, i + 1,
                    android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }

        val layout = android.text.StaticLayout.Builder
            .obtain(spannable, 0, spannable.length, paint, safeMaxWidth)
            .setAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1f)
            .setIncludePad(false)
            .build()

        val width = layout.width.coerceAtLeast(1) + 2
        val height = layout.height.coerceAtLeast(1) + 2

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.translate(1f, 1f)
        layout.draw(canvas)
        return bitmap
    }
}
