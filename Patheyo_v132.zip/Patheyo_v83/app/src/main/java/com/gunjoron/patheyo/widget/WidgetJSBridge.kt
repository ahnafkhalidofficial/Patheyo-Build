package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/WidgetJSBridge.kt
//
// এই রাউন্ডে নতুন:
//  - saveWidgetSettings() এ showSehriIftar সাপোর্ট
//  - stopAzan() — JS থেকে আজান বন্ধ করার ব্রিজ
//  - setHijriConfig() — Firebase RC থেকে আসা hijri adjustment ও method ID ধরে রাখা

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.widget.Toast
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.alarm.AlarmScheduler
import com.gunjoron.patheyo.alarm.AzanForegroundService
import com.gunjoron.patheyo.alarm.AzanOverlayActivity

class WidgetJSBridge(private val activity: Activity) {

    @JavascriptInterface
    fun saveTimings(jsonString: String) {
        val prefs = activity.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(PrayerWidgetProvider.KEY_TIMINGS, jsonString)
            .putLong("last_sync_timestamp", System.currentTimeMillis())
            // ✅ FIX #1: এই সময়ের নামাজের সময়সূচি কোন গ্রেগরিয়ান তারিখে আনা হয়েছে সেটা মনে রাখা হচ্ছে
            // (হিজরি তারিখ মধ্যরাতে রিভার্ট হওয়া বাগ ফিক্স করতে দরকার — দেখুন PrayerWidgetProvider)
            .putString("timings_fetched_on", com.gunjoron.patheyo.FirebaseDataManager.todayDateOnlyStr())
            .commit() // দ্রুত রাইট করার জন্য commit
        
        // RTDB থেকে পাওয়া লেটেস্ট এডজাস্টমেন্ট সাথে সাথে অ্যাপ্লাই করা (Race condition সমাধান)
        FirebaseDataManager.refreshWithLastAdjustment(activity)

        val appContext = activity.applicationContext
        activity.runOnUiThread { 
            PrayerWidgetProvider.updateWidgetDirectly(appContext) // সরাসরি আপডেট
            // ✅ FIX #4: ব্রডকাস্টও পাঠানো হচ্ছে, যাতে অ্যাপ হাব থেকে করা যেকোনো পরিবর্তন সাথে সাথে
            // হোমস্ক্রিন উইজেটে দেখা যায় — অ্যাপ কেটে/উইজেটে ক্লিক করে আবার ঢোকার দরকার না হয়।
            PrayerWidgetProvider.updateAllWidgets(appContext)
            WidgetRefreshScheduler.scheduleAll(appContext) // নতুন সময় অনুযায়ী শিডিউল রিফ্রেশ
        }
        AlarmScheduler.scheduleAllAlarms(activity)
    }

    @JavascriptInterface
    fun saveWidgetSettings(jsonString: String) {
        val prefs = activity.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(PrayerWidgetProvider.KEY_SETTINGS, jsonString)
            .putLong("last_sync_timestamp", System.currentTimeMillis())
            .commit()
        val appContext = activity.applicationContext
        activity.runOnUiThread { 
            PrayerWidgetProvider.updateWidgetDirectly(appContext) // সরাসরি আপডেট
            PrayerWidgetProvider.updateAllWidgets(appContext) // ✅ FIX #4: ব্রডকাস্ট দিয়েও রিফ্রেশ
            WidgetRefreshScheduler.scheduleAll(appContext)
        }
    }

    // ✅ FIX #11: উইজেট হাব-এর "রিফ্রেশ" বাটনের জন্য — সেটিংস এমনিতেই saveWidgetSettings() কল হলে
    // সাথে সাথে সিঙ্ক হয়ে যায়, কিন্তু কোনো কারণে (লঞ্চারের ধীরগতির রিড্র, বা কোনো এজ-কেস) হোমস্ক্রিন
    // widget-টা এক পলক দেরি করলে ব্যবহারকারী যেন ম্যানুয়ালি জোর করে সাথে সাথে রিফ্রেশ করতে পারে —
    // সেই গ্যারান্টি হিসেবে এই মেথড, প্লাস একটা Toast দিয়ে নিশ্চিত করা হয় যে কাজটা হয়েছে।
    @JavascriptInterface
    fun refreshWidgetNow() {
        val appContext = activity.applicationContext
        activity.runOnUiThread {
            PrayerWidgetProvider.updateWidgetDirectly(appContext)
            PrayerWidgetProvider.updateAllWidgets(appContext)
            WidgetRefreshScheduler.scheduleAll(appContext)
            Toast.makeText(activity, "উইজেট রিফ্রেশ হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun updateWeatherTemp(tempString: String) {
        val prefs = activity.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(PrayerWidgetProvider.KEY_TEMP, tempString)
            .putLong("last_sync_timestamp", System.currentTimeMillis())
            .commit()
        val appContext = activity.applicationContext
        activity.runOnUiThread {
            PrayerWidgetProvider.updateWidgetDirectly(appContext) // সরাসরি আপডেট
            PrayerWidgetProvider.updateAllWidgets(appContext) // ✅ FIX #4: ব্রডকাস্ট দিয়েও রিফ্রেশ
        }
    }

    @JavascriptInterface
    fun pinWidgetToHomeScreen() {
        activity.runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val awm = activity.getSystemService(AppWidgetManager::class.java)
                val cn = ComponentName(activity, PrayerWidgetProvider::class.java)
                if (awm != null && awm.isRequestPinAppWidgetSupported) awm.requestPinAppWidget(cn, null, null)
                else Toast.makeText(activity, "হোমস্ক্রিনে লং-প্রেস → Widgets থেকে যুক্ত করুন", Toast.LENGTH_LONG).show()
            } else Toast.makeText(activity, "হোমস্ক্রিনে লং-প্রেস → Widgets থেকে যুক্ত করুন", Toast.LENGTH_LONG).show()
        }
    }

    @JavascriptInterface
    fun saveAlarmConfigs(jsonString: String) { AlarmScheduler.saveAlarmConfig(activity, jsonString) }

    @JavascriptInterface
    fun showAzanNotification(waqtKey: String, waqtName: String) {
        val serviceIntent = Intent(activity, AzanForegroundService::class.java).apply {
            putExtra("waqt", waqtKey)
            putExtra("waqtName", waqtName)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity.startForegroundService(serviceIntent)
        } else {
            activity.startService(serviceIntent)
        }
    }

    @JavascriptInterface
    fun showAzanOverlay(waqtName: String) {
        val overlayIntent = Intent(activity, AzanOverlayActivity::class.java).apply {
            putExtra("waqtName", waqtName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        activity.startActivity(overlayIntent)
    }

    @JavascriptInterface
    fun setActiveWaqt(waqtKey: String) {
        val prefs = activity.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("active_waqt_key", waqtKey)
            .putLong("last_sync_timestamp", System.currentTimeMillis())
            .commit()
        val appContext = activity.applicationContext
        activity.runOnUiThread { PrayerWidgetProvider.updateAllWidgets(appContext) }
    }

    @JavascriptInterface
    fun hasExactAlarmPermission(): Boolean = AlarmScheduler.canScheduleExact(activity)

    @JavascriptInterface
    fun requestExactAlarmPermission() {
        activity.runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                try { activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply { data = Uri.parse("package:${activity.packageName}") }) }
                catch (_: Exception) { Toast.makeText(activity, "সেটিংস → Alarms & reminders থেকে অনুমতি দিন", Toast.LENGTH_LONG).show() }
            } else {
                Toast.makeText(activity, "এই ফোনে আলাদা করে এই অনুমতি লাগে না", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ============================================================
    // ✅ নতুন: "পারমিশন সেন্টার" — সব দরকারি পারমিশন এক জায়গায়,
    // প্রতিটার জন্য এক-ক্লিকে সঠিক সেটিংস স্ক্রিনে নিয়ে যাওয়ার ব্রিজ
    // ============================================================

    // বর্তমানে কোন কোন পারমিশন/অনুমতি চালু আছে তা JSON আকারে JS-কে জানানো, যাতে
    // "পারমিশন" ট্যাবে প্রতিটার পাশে ✅/❌ লাইভ দেখানো যায়
    @JavascriptInterface
    fun checkAllPermissionsStatus(): String {
        val exactAlarm = try { AlarmScheduler.canScheduleExact(activity) } catch (_: Exception) { true }

        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            androidx.core.app.NotificationManagerCompat.from(activity).areNotificationsEnabled()
        }

        val location = androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

        val battery = try {
            val pm = activity.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            pm.isIgnoringBatteryOptimizations(activity.packageName)
        } catch (_: Exception) { true }

        val fullScreen = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                val nm = activity.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                nm.canUseFullScreenIntent()
            } catch (_: Exception) { true }
        } else true

        return org.json.JSONObject().apply {
            put("exactAlarm", exactAlarm)
            put("notification", notif)
            put("location", location)
            put("battery", battery)
            put("fullScreen", fullScreen)
        }.toString()
    }

    // লোকেশন পারমিশন — প্রথমবার হলে সরাসরি অ্যান্ড্রয়েডের নিজস্ব পপ-আপ দেখায়;
    // আগে একবার "Don't ask again" করে দিলে (permanently denied) সরাসরি অ্যাপ সেটিংস পেজে নিয়ে যায়,
    // কারণ Android-এ পার্মানেন্টলি ডিনাই করা পারমিশন কোড দিয়ে আর দ্বিতীয়বার পপ-আপ দেখানো যায় না।
    @JavascriptInterface
    fun requestLocationPermission() {
        activity.runOnUiThread {
            // v47: "সঠিক" বা "আনুমানিক" — যেকোনো একটা দেওয়া থাকলেই চালু ধরা হয় (Android 12+ এ ইউজার আনুমানিক দিতে পারেন)
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted) { Toast.makeText(activity, "লোকেশন পারমিশন আগে থেকেই চালু আছে", Toast.LENGTH_SHORT).show(); return@runOnUiThread }
            val mainAct = activity as? com.gunjoron.patheyo.MainActivity
            if (mainAct != null && androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                mainAct.requestLocationPermissionFromJs()
            } else if (mainAct != null && !hasAskedLocationBefore()) {
                markAskedLocationBefore()
                mainAct.requestLocationPermissionFromJs()
            } else {
                openAppDetailsSettings()
            }
        }
    }

    // নোটিফিকেশন পারমিশন — Android 13+ এ প্রথমবার সরাসরি পপ-আপ, নাহলে অ্যাপ নোটিফিকেশন সেটিংসে
    @JavascriptInterface
    fun requestNotificationPermission() {
        activity.runOnUiThread {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                openAppNotificationSettings(); return@runOnUiThread
            }
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted) { Toast.makeText(activity, "নোটিফিকেশন পারমিশন আগে থেকেই চালু আছে", Toast.LENGTH_SHORT).show(); return@runOnUiThread }
            val mainAct = activity as? com.gunjoron.patheyo.MainActivity
            if (mainAct != null && androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.POST_NOTIFICATIONS)) {
                mainAct.requestNotificationPermissionFromJs()
            } else if (mainAct != null && !hasAskedNotifBefore()) {
                markAskedNotifBefore()
                mainAct.requestNotificationPermissionFromJs()
            } else {
                openAppNotificationSettings()
            }
        }
    }

    private fun hasAskedLocationBefore(): Boolean =
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).getBoolean("asked_location", false)
    private fun markAskedLocationBefore() {
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).edit().putBoolean("asked_location", true).apply()
    }
    private fun hasAskedNotifBefore(): Boolean =
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).getBoolean("asked_notif", false)
    private fun markAskedNotifBefore() {
        activity.getSharedPreferences("ibadat_perm_prefs", Context.MODE_PRIVATE).edit().putBoolean("asked_notif", true).apply()
    }

    // ব্যাটারি অপ্টিমাইজেশন বাদ দেওয়ার সরাসরি এক-ক্লিক পপ-আপ (এইটাই সবচেয়ে গুরুত্বপূর্ণ —
    // এটা না দিলে অনেক ফোন ব্যাকগ্রাউন্ডে অ্যাপকে জোর করে ঘুম পাড়িয়ে দেয়, আজান/উইজেট বন্ধ হয়ে যায়)
    @JavascriptInterface
    fun openBatteryOptimizationSettings() {
        activity.runOnUiThread {
            try {
                val pm = activity.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                if (pm.isIgnoringBatteryOptimizations(activity.packageName)) {
                    Toast.makeText(activity, "ব্যাটারি অপ্টিমাইজেশন থেকে অ্যাপ আগে থেকেই বাদ দেওয়া আছে", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                activity.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${activity.packageName}")
                })
            } catch (_: Exception) {
                try {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(activity, "সেটিংস → ব্যাটারি → অ্যাপ থেকে ম্যানুয়ালি অনুমতি দিন", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // অ্যাপের নোটিফিকেশন সেটিংস পেজ (নোটিফিকেশন বন্ধ থাকলে চালু করার জন্য)
    @JavascriptInterface
    fun openAppNotificationSettings() {
        activity.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
                    })
                } else {
                    openAppDetailsSettings()
                }
            } catch (_: Exception) { openAppDetailsSettings() }
        }
    }

    // Android 14+ এ ফুল-স্ক্রিন অ্যালার্ম (লক স্ক্রিনেও আজানের স্ক্রিন দেখানো) অনুমতি
    @JavascriptInterface
    fun openFullScreenIntentSettings() {
        activity.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply {
                        data = Uri.parse("package:${activity.packageName}")
                    })
                } else {
                    Toast.makeText(activity, "এই ফোনে আলাদা করে এই অনুমতি লাগে না", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) { openAppDetailsSettings() }
        }
    }

    // অটো-স্টার্ট / ব্যাকগ্রাউন্ড লক (Xiaomi, Oppo, Vivo, Realme, Huawei, Samsung, Asus, Letv ইত্যাদি
    // কাস্টম Android স্কিনে থাকা নিজস্ব সেটিংস স্ক্রিন) — কোনো স্ট্যান্ডার্ড Android API নেই বলে
    // পরিচিত OEM-ভিত্তিক ইন্টেন্ট একটার পর একটা চেষ্টা করা হয়, না পেলে অ্যাপ ইনফো পেজে পাঠানো হয়।
    @JavascriptInterface
    fun openAutoStartSettings() {
        activity.runOnUiThread {
            // ✅ v44: লজিক এখন alarm/AlarmReliability-তে। আগের কোডে resolveActivity() দিয়ে চেক হতো, যেটা
            // অ্যান্ড্রয়েড ১১+ এ (package visibility) সবসময় null দিত — ফলে Honor/Huawei/Xiaomi সহ কোনো OEM-এর
            // অটো-স্টার্ট স্ক্রিনই খুলত না। এখন সরাসরি চেষ্টা করা হয়, ব্র্যান্ড অনুযায়ী সঠিক স্ক্রিন আগে।
            val opened = com.gunjoron.patheyo.alarm.AlarmReliability.openOemBackgroundSettings(activity)
            if (!opened) {
                Toast.makeText(activity, "এই ফোনের জন্য নির্দিষ্ট অটো-স্টার্ট মেনু পাওয়া যায়নি, অ্যাপ সেটিংসে নিয়ে যাওয়া হচ্ছে", Toast.LENGTH_LONG).show()
                openAppDetailsSettings()
            }
        }
    }

    // সবার জন্য fallback — অ্যাপের নিজস্ব সেটিংস (App Info) পেজ, যেখান থেকে ম্যানুয়ালি
    // যেকোনো পারমিশন চালু/বন্ধ করা যায় — কোনো নির্দিষ্ট শর্টকাট কাজ না করলে এখানে পাঠানো হয়
    @JavascriptInterface
    fun openAppDetailsSettings() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${activity.packageName}")
                })
            } catch (_: Exception) {
                Toast.makeText(activity, "সেটিংস অ্যাপ খোলা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // JS থেকে আজান বন্ধ করার ব্রিজ — অ্যাপের ভিতরে একটা বাটনে ক্লিক করলেই কাজ করবে
    @JavascriptInterface
    fun stopAzan() {
        activity.runOnUiThread {
            val stopIntent = Intent(activity, AzanForegroundService::class.java).apply { action = AzanForegroundService.ACTION_STOP }
            activity.startService(stopIntent)
        }
    }

    // Firebase Remote Config থেকে পাওয়া hijri adjustment ও method ID WebView-এ কাজে লাগানোর জন্য
    // এই ফাংশনটা MainActivity.kt থেকে সরাসরি call করা হয় (JavascriptInterface নয়)
    fun injectHijriConfig(hijriAdjustment: Int, methodId: Int) {
        // MainActivity onPageFinished থেকে evaluateJavascript দিয়ে inject করা হয়
        // এখানে শুধু মান store করা হয়, যাতে page reload হলে আবার inject করা যায়
        activity.getSharedPreferences("ibadat_hijri_prefs", Context.MODE_PRIVATE)
            .edit().putInt("adjustment", hijriAdjustment).putInt("methodId", methodId).apply()
    }

    fun getSavedHijriAdjustment(): Int =
        activity.getSharedPreferences("ibadat_hijri_prefs", Context.MODE_PRIVATE).getInt("adjustment", 0)

    fun getSavedMethodId(): Int =
        activity.getSharedPreferences("ibadat_hijri_prefs", Context.MODE_PRIVATE).getInt("methodId", 1)
}
