
# 🎛️ উইজেট কাস্টমাইজেশন গাইড (v16)

&nbsp;

> এই গাইডে **উইজেটের প্রায় সবকিছু** আলাদা আলাদাভাবে বদলানোর নিয়ম আছে — লেখা, আইকন, বক্স, পুরো লাইন/সারি, নামাজের রো, হাইলাইট বক্স।
> প্রতিটা ধাপ আলাদা সেকশনে, বড় শিরোনামসহ। যেটা দরকার সেই সেকশনে সরাসরি চলে যান।
>
> 🆕 **v16:** এই গাইডের সব সংখ্যা/সাইজ এখন আপনার **বর্তমান আসল মান** (যা আপনি সেট করেছিলেন) — ফাইলে কোথাও `null` নেই। সব ফোনে (Android ৭ থেকে ১৫) উইজেট লোড হয় — বিস্তারিত সেকশন ১৫-এ।

&nbsp;

---

&nbsp;

# 📑 সূচিপত্র

| # | সেকশন | কী বদলাতে পারবেন |
|---|---|---|
| 0 | [⚡ ৩ ধাপে দ্রুত শুরু](#s0) | ফাইল কোথায়, কীভাবে এডিট |
| 1 | [📌 মানগুলো কীভাবে লিখবেন](#s1) | true/false, রঙ, সংখ্যা (কোথাও null নেই) |
| 2 | [🔤 লেখা (texts)](#s2) | দেখানো/লুকানো, সাইজ, রঙ, বোল্ড, লম্বা/চেপ্টা, অক্ষর-ফাঁকা |
| 3 | [✏️ লেখার শব্দ পাল্টানো (labels)](#s3) | সরাসরি বাংলা শব্দ এডিট |
| 4 | [🖼️ আইকন (icons)](#s4) | আইকন লুকানো / ছোট-বড় |
| 5 | [🕌 নামাজের রো (prayer_rows)](#s5) | ফজর/যোহর/আসর/মাগরিব/ইশা লুকানো |
| 6 | [📦 বক্স (boxes)](#s6) | সরানো, ছোট-বড়, স্বচ্ছতা, ছায়া, বক্স লুকানো |
| 7 | [📏 পুরো লাইন/সারি (rows)](#s7) | ঘড়ি-লাইন, নামাজ-লাইন, কাউন্টডাউন-লাইন উপরে-নিচে |
| 8 | [🎯 চলমান-ওয়াক্ত হাইলাইট বক্স (highlight)](#s8) | ১:১ রাউন্ডেড-স্কয়ার, সাইজ, কোণা, রঙ |
| 9 | [⏰ ঘড়ির সময়/সেকেন্ড লম্বা-চেপ্টা করা](#s9) | শুধু "06:28" অংশটা স্ট্রেচ/স্পেস |
| 10 | [↔️ ফাঁকা (spacing)](#s10) | সংখ্যার ফাঁকা, দুই লাইনের ফাঁকা |
| 11 | [🪟 গ্লাস / ব্লার / কোণা রাউন্ড](#s11) | সত্যি কথা + রিবিল্ড-লাগা সেটিংস |
| 12 | [⚠️ সীমাবদ্ধতা (সৎভাবে)](#s12) | কী সম্ভব না, কেন |
| 13 | [🔄 ভুল হলে ডিফল্টে ফেরা](#s13) | পুরো ডিফল্ট ফাইল |
| 14 | [📐 নিচের ফাঁকা (layout)](#s14) | চার পাশে সমান ফাঁকা |
| 15 | [📱 সব ফোনে কাজ করার নিয়ম](#s15) | Android ভার্সন, "Problem loading widget" ফিক্স |
| 16 | [📝 v16-তে কী বদলেছে](#s16) | সংক্ষিপ্ত চেঞ্জলগ |

&nbsp;

---

&nbsp;

<a name="s0"></a>
# ⚡ ০) ৩ ধাপে দ্রুত শুরু

&nbsp;

### 📍 ধাপ ১ — ফাইলটা খুঁজে বের করুন

```
app/src/main/assets/widget_style_config.json
```

&nbsp;

### ✍️ ধাপ ২ — যেটা বদলাতে চান সেই মানটা এডিট করুন

শুধু মানটা (সংখ্যা / true / false / রঙ / লেখা) বদলান। কমা `,` বা ব্র্যাকেট `{ }` মুছবেন না।

&nbsp;

### ▶️ ধাপ ৩ — সেভ করে অ্যাপ আবার Build/Run করুন

Android Studio-তে **Build ▸ Rebuild Project**, তারপর **Run**।

&nbsp;

> 💡 **রিবিল্ড ছাড়াও বদলানো যায় (ঐচ্ছিক):** অ্যাপ একবার চালু হলে ফোনের
> `Android/data/com.gunjoron.patheyo/files/widget_style_config.json` ফাইলে এই ফাইলের একটা কপি বসে যায়।
> ওই কপি সরাসরি ফোনে এডিট করলে (ফাইল-ম্যানেজার বা PC-তে USB দিয়ে) রিবিল্ড ছাড়াই পরের রিফ্রেশে বদলে যায়।
> ⚠️ Android 11+ এ অনেক ফাইল-ম্যানেজার ওই ফোল্ডারে ঢুকতে দেয় না — সেক্ষেত্রে উপরের ৩ ধাপই ব্যবহার করুন, ওটা সবসময় কাজ করে।
>
> 🔁 **পুরনো ভার্সনের কপি থাকলে:** যদি ফোনে আগের (v14 বা তার আগের) কনফিগ ফাইল থেকে থাকে, অ্যাপ নিজে থেকেই সেটা
> `widget_style_config.json.old` নামে ব্যাকআপ রেখে নতুন (v15) ফাইল বসিয়ে দেবে। পুরনো সেটিংস দেখতে `.old` ফাইলটা খুলুন।

&nbsp;

---

&nbsp;

<a name="s1"></a>
# 📌 ১) মানগুলো কীভাবে লিখবেন

&nbsp;

### 🔹 এখন আর `null` নেই

v16 থেকে `widget_style_config.json`-এর **কোথাও `null` নেই**। প্রতিটা জায়গায় বর্তমানে ব্যবহৃত আসল সংখ্যা / রঙ / true-false লেখা আছে — ফাইল খুললেই দেখবেন কোনটার সাইজ কত, রঙ কী, বোল্ড কি না। বদলাতে চাইলে শুধু ওই মানটা বদলান:

```json
"size_sp": 16          ← এখন ১৬; বদলে 18 লিখলে ১৮ হবে
"color": "#FFFFFF"     ← এখন সাদা
```

&nbsp;

### 🔹 `true` / `false`

উদ্ধৃতি চিহ্ন (`"`) ছাড়া লিখবেন।

&nbsp;

### 🔹 রঙ লেখার নিয়ম

`"#RRGGBB"` ফরম্যাটে, উদ্ধৃতি চিহ্নসহ:

| রঙ | কোড | | রঙ | কোড |
|---|---|---|---|---|
| ⚪ সাদা | `"#FFFFFF"` | | 🟢 সবুজ | `"#00C853"` |
| ⚫ কালো | `"#000000"` | | 🔵 নীল | `"#2979FF"` |
| 🔴 লাল | `"#FF0000"` | | 🟡 হলুদ | `"#FFD600"` |

&nbsp;

### 🔹 এককগুলো

| একক | মানে |
|---|---|
| `sp` | লেখার সাইজ |
| `dp` | দূরত্ব/মাপ |
| `scale` / `stretch_x` / `stretch_y` | গুণক — `1.0` স্বাভাবিক, `1.2` = ২০% বড়/চওড়া/লম্বা, `0.8` = ২০% ছোট/সরু |
| `em` | অক্ষরের সাইজের ভগ্নাংশ (letter-spacing-এর জন্য) |

&nbsp;

---

&nbsp;

<a name="s2"></a>
# 🔤 ২) লেখা (`texts`)

&nbsp;

প্রতিটা লেখার জন্য সেটিং (কাউন্টডাউনের দুটোয় একটা বাড়তি):

```json
"prayer_times": {
  "visible": true, "size_sp": 16,
  "color": "#F1F5F9", "color_light_theme": "#070D19",
  "bold": true,
  "stretch_x": 1.0, "stretch_y": 1.0, "letter_spacing_em": 0.05
}
```

| সেটিং | কাজ | মান |
|---|---|---|
| `visible` | লেখাটা দেখাবে/লুকাবে | `true` / `false` |
| `size_sp` | লেখার সাইজ | সংখ্যা |
| `color` | লেখার রঙ (গ্লাস / ডার্ক / নো-ব্যাকগ্রাউন্ড থিমে) | `"#RRGGBB"` |
| `color_light_theme` | লেখার রঙ **লাইট থিমে** | `"#RRGGBB"` |
| `color_forbidden` | (শুধু `countdown_label` ও `countdown_chrono`) নিষিদ্ধ সময়ের রঙ | `"#RRGGBB"` (এখন লাল `#E11D48`) |
| `bold` | বোল্ড/আনবোল্ড | `true` / `false` |
| `stretch_x` | শুধু এই লেখাটাকে আড়াআড়ি (চওড়া/সরু) টানা | `1.0` স্বাভাবিক |
| `stretch_y` | শুধু এই লেখাটাকে লম্বালম্বি (লম্বা/খাটো) টানা | `1.0` স্বাভাবিক |
| `letter_spacing_em` | শুধু এই লেখার নিজস্ব অক্ষর-ফাঁকা | সংখ্যা (`0.05` = গ্লোবাল মান) |

> 💡 গ্লাস/ডার্ক থিমে লেখা সাদা, লাইট থিমে গাঢ় — এজন্যই রঙের দুটো আলাদা সেটিং। দুটোতে একই রঙ দিলে সব থিমে একই রঙ হবে।

&nbsp;

### 📋 সবগুলো লেখার তালিকা (বর্তমান আসল সাইজ)

| Key | কোন লেখা | সাইজ (sp) | স্ট্রেচ X × Y |
|---|---|---|---|
| `hijri_day_number` | হিজরি তারিখের বড় সংখ্যা | 28 | 1.0 × 1.0 |
| `hijri_month_year` | হিজরির মাস + সাল | 17 | 1.0 × 1.0 |
| `date_others` | ইংরেজি ও বাংলা তারিখের লাইন | 15 | 1.0 × 1.0 |
| `celestial_title` | "সূর্যোদয়" / "সূর্যাস্ত" | 13.5 | 1.0 × 1.0 |
| `celestial_time` | সূর্যোদয়/সূর্যাস্তের সময় | 16 | 1.0 × 1.0 |
| `clock_time` | ঘড়ির বড় সময় | 26 | 1.0 × 1.3 |
| `clock_seconds` | ঘড়ির সেকেন্ড | 16 | 1.0 × 1.1 |
| `clock_ampm` | ঘড়ির AM/PM লেখা | 10 | 1.0 × 1.0 |
| `weather_title` | "আবহাওয়া" | 13.5 | 1.0 × 1.0 |
| `weather_value` | তাপমাত্রা | 16 | 1.0 × 1.0 |
| `sehri_title` | "সাহরী" | 13.5 | 1.0 × 1.0 |
| `sehri_time` | সাহরীর সময় | 16 | 1.0 × 1.0 |
| `iftar_title` | "ইফতার" | 13.5 | 1.0 × 1.0 |
| `iftar_time` | ইফতারের সময় | 16 | 1.0 × 1.0 |
| `prayer_names` | ৫ ওয়াক্তের নাম (সবগুলো একসাথে) | 13.5 | 1.0 × 1.0 |
| `prayer_times` | ৫ ওয়াক্তের সময় (সবগুলো একসাথে) | 16 | 1.0 × 1.0 |
| `countdown_label` | নিচের লেখা ("নিষিদ্ধ সময় চলছে:") | 13.5 | 1.0 × 1.0 |
| `countdown_chrono` | চলমান কাউন্টডাউন সংখ্যা | 11.5 | 1.0 × 1.0 |

&nbsp;

### 🧪 উদাহরণ — নামাজের নাম ও সময় সবুজ করা

```json
"prayer_names": { "visible": true, "size_sp": 13.5, "color": "#00C853", "color_light_theme": "#00C853", "bold": true, "stretch_x": 1.0, "stretch_y": 1.0, "letter_spacing_em": 0.05 },
"prayer_times": { "visible": true, "size_sp": 16,   "color": "#00C853", "color_light_theme": "#00C853", "bold": true, "stretch_x": 1.0, "stretch_y": 1.0, "letter_spacing_em": 0.05 }
```

&nbsp;

> ⚠️ `clock_time`, `clock_seconds`, `clock_ampm`, `countdown_chrono` নেটিভ লেখা — এদের `bold` বদলায় না (বাকি সব বদলায়)।

&nbsp;

---

&nbsp;

<a name="s3"></a>
# ✏️ ৩) লেখার শব্দ পাল্টানো (`labels`)

&nbsp;

🆕 **v15:** এখন প্রতিটা key-এর মান সরাসরি **আসল বাংলা শব্দ** — `null` না। ফাইল খুললেই দেখবেন:

```json
"labels": {
  "sunrise": "সূর্যোদয়",
  "sunset": "সূর্যাস্ত",
  "sehri": "সাহরী",
  "iftar": "ইফতার",
  "weather": "আবহাওয়া",
  "fajr": "ফজর",
  "dhuhr": "যোহর",
  "jumma": "জুম'আ",
  "asr": "আসর",
  "maghrib": "মাগরিব",
  "isha": "ইশা"
}
```

সরাসরি এই বাংলা শব্দগুলোই এডিট করুন — বানান ঠিক করতে চাইলে বা সম্পূর্ণ নতুন শব্দ দিতে চাইলে (যেমন `"sunrise": "ভোর"`), শুধু উদ্ধৃতি চিহ্নের ভেতরের অংশটা বদলান। বাম পাশের key-টা (`"sunrise"`) ইংরেজিতেই থাকবে — ওটা শুধু কোড চেনার নাম, ওটা বদলাবেন না।

&nbsp;

> 💡 নিচের কাউন্টডাউন লাইনে ("আসর শেষ হতে বাকি:") ওয়াক্তের নামটাও এখান থেকেই আসে।

&nbsp;

---

&nbsp;

<a name="s4"></a>
# 🖼️ ৪) আইকন (`icons`)

&nbsp;

```json
"clock_icon": { "visible": true, "scale": 1.0 }
```

| Key | কোন আইকন |
|---|---|
| `logo` | অ্যাপের লোগো |
| `celestial_icon` | সূর্যোদয়/সূর্যাস্তের আইকন |
| `clock_icon` | ঘড়ির আইকন |
| `sehri_icon` | সাহরীর আইকন |
| `iftar_icon` | ইফতারের আইকন |
| `weather_icon` | আবহাওয়ার আইকন |
| `countdown_warning_icon` | নিষিদ্ধ সময়ের ⚠ আইকন |

> ℹ️ `clock_icon`-এর `scale` এখন `0.9` — এটাই ঘড়ির আইকনের আসল সাইজ (লেআউট XML-এও বসানো, তাই সব ফোনে একই)। বাকি আইকন `1.0`।

&nbsp;

---

&nbsp;

<a name="s5"></a>
# 🕌 ৫) নামাজের রো (`prayer_rows`)

&nbsp;

```json
"prayer_rows": { "fajr": true, "dhuhr": true, "asr": true, "maghrib": true, "isha": true }
```

প্রতিটা `false` করলে সেই ওয়াক্তের নাম+সময় দুটোই গায়েব হয়ে যাবে।

&nbsp;

---

&nbsp;

<a name="s6"></a>
# 📦 ৬) বক্স (`boxes`)

&nbsp;

বক্স = **পেছনের কালার্ড শেপ** (কার্ড / পিল)।

&nbsp;

### 📋 ৮টা বক্স

| Key | কোন বক্স |
|---|---|
| `main_card` | পুরো উইজেটের বড় কাঁচের কার্ড |
| `logo_frame` | লোগোর পেছনের বক্স |
| `clock_pill` | ঘড়ির বক্স |
| `celestial_pill` | সূর্যোদয়/সূর্যাস্তের বক্স |
| `sehri_pill` | সাহরীর বক্স |
| `iftar_pill` | ইফতারের বক্স |
| `weather_pill` | আবহাওয়ার বক্স |
| `clock_ampm_box` 🆕 | ঘড়ির AM/PM-এর নিচের গোল ব্যাকগ্রাউন্ড |

&nbsp;

### ⚙️ প্রতিটা বক্সের সেটিং

```json
"clock_pill": {
  "move_right_dp": 0, "move_down_dp": 0,
  "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
  "opacity": 1.0, "shadow_dp": 0,
  "visible": true, "background_visible": true
}
```

| সেটিং | কাজ |
|---|---|
| `move_right_dp` / `move_down_dp` | সরানো (+ডানে/নিচে, −বামে/উপরে) |
| `scale` / `scale_x` / `scale_y` | ছোট-বড় (scale_x/scale_y = শুধু এক দিক) |
| `opacity` | স্বচ্ছতা (`0.0`–`1.0`) |
| `shadow_dp` | ভাসমান ছায়া (`4`–`6` সুন্দর লাগে) |
| `visible` | বক্স + ভেতরের সবকিছু দেখানো/লুকানো |
| `background_visible` | **শুধু** বক্সের রঙ/শেপ দেখানো/লুকানো (ভেতরের লেখা-আইকন থাকবে) |

&nbsp;

### 📌 বর্তমান আসল মান (আপনার সেট করা)

| বক্স | আসল অবস্থা |
|---|---|
| `main_card` | ছায়া `shadow_dp: 30`, ব্যাকগ্রাউন্ড দৃশ্যমান |
| `logo_frame`, `clock_pill`, `celestial_pill`, `sehri_pill`, `iftar_pill`, `weather_pill` | `background_visible: false` (শুধু লেখা-আইকন দেখা যায়, পেছনের বক্স নেই) |
| `clock_ampm_box` | `move_right_dp: -8` (বামে ৮dp সরানো), `background_visible: false` |

&nbsp;

### 🔑 `visible` বনাম `background_visible`

| চান | দেবেন |
|---|---|
| পুরো বক্স (শেপ+লেখা+আইকন) গায়েব | `"visible": false` |
| শুধু বক্সের রঙ গায়েব, লেখা-আইকন থাকুক | `"background_visible": false` |
| গায়েব করা বক্সের রঙ আবার ফিরিয়ে আনা | `"background_visible": true` |

&nbsp;

### 🧪 উদাহরণ — AM/PM-এর পেছনের গোল বৃত্ত ফিরিয়ে আনা

```json
"clock_ampm_box": { "move_right_dp": -8, "move_down_dp": 0, "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
                    "opacity": 1.0, "shadow_dp": 0, "visible": true, "background_visible": true }
```

### 🧪 উদাহরণ — AM/PM বক্সটা আরও একটু ডানে-নিচে সরানো (−৮ থেকে −৫)

```json
"clock_ampm_box": { "move_right_dp": -5, "move_down_dp": 2, "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
                    "opacity": 1.0, "shadow_dp": 0, "visible": true, "background_visible": false }
```

&nbsp;

> ⚠️ বেশি সরালে (`move_*`) পাশের বক্সের সাথে ওভারল্যাপ হতে পারে — **৩–১৫ dp দিয়ে শুরু করুন**।

&nbsp;

---

&nbsp;

<a name="s7"></a>
# 📏 ৭) পুরো লাইন/সারি (`rows`) 🆕

&nbsp;

**বক্স** (সেকশন ৬) একটা নির্দিষ্ট বক্স নড়ায়। **রো** পুরো লাইনটাই — তার ভেতরের **সব বক্স-লেখাসহ** — একসাথে নড়ায়।

```json
"clock_weather_row": {
  "move_right_dp": 0, "move_down_dp": 0,
  "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
  "opacity": 1.0, "shadow_dp": 0, "visible": true
}
```

| Key | কোন লাইন |
|---|---|
| `top_row` | লোগো + তারিখ + সূর্যোদয়/সূর্যাস্ত (পুরো ১ম সারি) |
| `clock_weather_row` | ঘড়ি + সাহরী + ইফতার + আবহাওয়া (পুরো ২য় সারি) |
| `prayers_row` | ফজর থেকে ইশা — নাম ও সময়সহ পুরো লাইন |
| `countdown_row` | সবচেয়ে নিচের কাউন্টডাউন লাইন |

&nbsp;

### ✅ আপনার আগের সরানো মান এখন "আসল অবস্থান"

আপনি আগে ঘড়ি-লাইন **−৮**, নামাজ-লাইন **−১২**, কাউন্টডাউন-লাইন **−১৪** dp উপরে তুলেছিলেন। v16-এ এই তিনটা মান লেআউটে **পাকাপাকি বসানো** হয়েছে (তাই JSON-এ এখন `0`)। ফলে:

- লাইনগুলো ঠিক আগের জায়গাতেই দেখা যায় — একচুলও নড়েনি।
- আগে সরালেও কার্ডের মাপ একই থাকত (তাই নিচে বাড়তি ফাঁকা পড়ত); এখন কার্ড নিজে নিচ থেকে ছোট হয়ে লেখার চারপাশে সমান ফাঁকা রাখে (সেকশন ১৪)।
- আপনি Android ১২+ ফোনে JSON-এর `move_down_dp` দিয়ে আরও সরাতে পারবেন (নিচের উদাহরণ)।

**সব ফোনে** (পুরনো ফোনসহ) স্থায়ীভাবে বদলাতে চাইলে `app/src/main/res/layout/widget_prayer_times.xml`-এ এই margin-গুলো বদলান:

| লাইন | XML id | বর্তমান আসল margin |
|---|---|---|
| ১ম সারি → ২য় সারির ফাঁকা | `row_top` | `layout_marginBottom="0dp"` |
| ২য় সারির নিচের ফাঁকা | `row_clock_weather` | `layout_marginBottom="4dp"` |
| নামাজ-লাইনের উপরের ফাঁকা | `row_prayers` | `layout_marginTop="-2dp"` |
| কাউন্টডাউন-লাইনের উপরের ফাঁকা | `row_countdown` | `layout_marginTop="4dp"` |

&nbsp;

### 🧪 উদাহরণ — নামাজের পুরো লাইনটা আরও একটু নিচে নামানো (Android ১২+)

```json
"prayers_row": { "move_right_dp": 0, "move_down_dp": 4, "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
                 "opacity": 1.0, "shadow_dp": 0, "visible": true }
```

### 🧪 উদাহরণ — ঘড়ি+সাহরী+ইফতার+আবহাওয়ার লাইনটা আরও উপরে তোলা (Android ১২+)

```json
"clock_weather_row": { "move_right_dp": 0, "move_down_dp": -5, "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
                       "opacity": 1.0, "shadow_dp": 0, "visible": true }
```

### 🧪 উদাহরণ — নিচের কাউন্টডাউন লাইনটা আরও একটু নিচে (Android ১২+)

```json
"countdown_row": { "move_right_dp": 0, "move_down_dp": 3, "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
                   "opacity": 1.0, "shadow_dp": 0, "visible": true }
```

> ⚠️ `move_down_dp` শুধু ছবির মতো সরায় — কার্ডের মাপ বদলায় না। কার্ডের নিচের ফাঁকা ঠিক রাখতে চাইলে সেকশন ১৪-এর `bottom_padding_dp` মিলিয়ে নিন।

&nbsp;

---

&nbsp;

<a name="s8"></a>
# 🎯 ৮) চলমান-ওয়াক্ত হাইলাইট বক্স (`highlight`)

&nbsp;

এখন যে ওয়াক্ত চলছে (যেমন "আসর"), তার পেছনে যে সাদা (ক্রীম) হাইলাইট বসে সেটা এখন **১:১ রাউন্ডেড-স্কয়ার**।

**কীভাবে হয়েছে:** হাইলাইট আলাদা একটা ছবি (লেখার পেছনে বসে) — লেখা আর হাইলাইট আলাদা ভিউ। তাই হাইলাইট বদলালে **লেখা একচুলও নড়ে না, ছোট-বড়ও হয় না**। বর্গের বাহু = ঘরের (নাম+সময়সহ) উচ্চতা; আগের চওড়া বক্সটা **ডান ও বাম দুই পাশ থেকে সমানভাবে চেপে** বর্গ করা হয়েছে — উচ্চতা বাড়ানো হয়নি, তাই লেখা ঢাকা পড়ার ভয় নেই।

```json
"highlight": {
  "size_adjust_dp": 0,
  "corner_radius_dp": 10,
  "move_right_dp": 0, "move_down_dp": 0,
  "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0,
  "shadow_dp": 0
}
```

| সেটিং | কাজ | সব ফোনে? |
|---|---|---|
| `size_adjust_dp` | বর্গের বাহুর মাপে যোগ/বিয়োগ। `0` = ঠিক ১:১ স্বাভাবিক। `-4` = আরও ছোট বর্গ। ধনাত্মক দিলে ঘরের উচ্চতা বাড়তে পারে, তাই ঋণাত্মক বা ছোট মান ভালো | ✅ হ্যাঁ |
| `corner_radius_dp` | কোণা কতটা গোল (`10` = আসল; `0` = ধারালো; বড় মান = প্রায় গোল) | ✅ হ্যাঁ |
| `move_right_dp` / `move_down_dp` | শুধু হাইলাইট বর্গ সরানো (লেখা নয়) | Android ১২+ |
| `scale` / `scale_x` / `scale_y` | শুধু হাইলাইট বর্গ ছোট-বড় (`1.0` = ঠিক ১:১; লেখা অক্ষত) | Android ১২+ |
| `shadow_dp` | হাইলাইটের ছায়া | Android ১২+ |

> ✅ বর্গ সবসময় ঘরের ঠিক মাঝখানে বসে। ঘর যদি কখনো বর্গের চেয়ে সরু হয় (খুব ছোট উইজেট), বর্গ নিজে থেকে ছোট হয়ে ১:১ অনুপাত ধরে রাখে।

&nbsp;

### 🎨 রঙ — ডার্ক ও লাইট মোড আলাদা (রিবিল্ড লাগবে)

রঙ এখন এক জায়গায়: `app/src/main/res/values/colors.xml`

| নাম | কখন ব্যবহার হয় | বর্তমান রঙ |
|---|---|---|
| `widget_highlight_dark` | ডার্ক / গ্লাস / নো-ব্যাকগ্রাউন্ড থিম | `#FFFAF3E0` (ক্রীম-সাদা) |
| `widget_highlight_light` | লাইট থিম | `#FF070D19` (গাঢ়) |

রঙের কোড `#AARRGGBB` (প্রথম দুই অক্ষর স্বচ্ছতা, `FF` = পুরো দৃশ্যমান)। উদাহরণ: খাঁটি সাদা চাইলে `#FFFFFFFF`।

&nbsp;

### 🧪 উদাহরণ — আরও ছোট, বেশি গোল বর্গ

```json
"highlight": { "size_adjust_dp": -4, "corner_radius_dp": 14, "move_right_dp": 0, "move_down_dp": 0,
               "scale": 1.0, "scale_x": 1.0, "scale_y": 1.0, "shadow_dp": 0 }
```

&nbsp;

---

&nbsp;

<a name="s9"></a>
# ⏰ ৯) ঘড়ির সময়/সেকেন্ড লম্বা-চেপ্টা করা 🆕

&nbsp;

এটা আসলে সেকশন ২-এরই অংশ (`clock_time`, `clock_seconds`) — কিন্তু আলাদা করে উদাহরণ দিচ্ছি যেহেতু নির্দিষ্টভাবে চাওয়া হয়েছে।

&nbsp;

> ℹ️ বর্তমান আসল মান: ঘড়ির সময় `size_sp: 26`, `stretch_y: 1.3`; সেকেন্ড `size_sp: 16`, `stretch_y: 1.1`।

### 🧪 উদাহরণ ১ — শুধু "06:28" অংশটা আরও চওড়া করা

```json
"clock_time": { "visible": true, "size_sp": 26, "color": "#E2E8F0", "color_light_theme": "#E2E8F0", "bold": true,
                "stretch_x": 1.2, "stretch_y": 1.3, "letter_spacing_em": 0.02 }
```

### 🧪 উদাহরণ ২ — সময়টা কম লম্বা (স্বাভাবিক উচ্চতা) করা

```json
"clock_time": { "visible": true, "size_sp": 26, "color": "#E2E8F0", "color_light_theme": "#E2E8F0", "bold": true,
                "stretch_x": 1.0, "stretch_y": 1.0, "letter_spacing_em": 0.02 }
```

### 🧪 উদাহরণ ৩ — সংখ্যার মাঝে বেশি স্পেস দেওয়া (শুধু সময়ে)

```json
"clock_time": { "visible": true, "size_sp": 26, "color": "#E2E8F0", "color_light_theme": "#E2E8F0", "bold": true,
                "stretch_x": 1.0, "stretch_y": 1.3, "letter_spacing_em": 0.15 }
```

### 🧪 উদাহরণ ৪ — সেকেন্ড (":53") আরও লম্বা করা

```json
"clock_seconds": { "visible": true, "size_sp": 16, "color": "#8FA0B8", "color_light_theme": "#8FA0B8", "bold": true,
                   "stretch_x": 1.0, "stretch_y": 1.3, "letter_spacing_em": 0.0 }
```

> ⚠️ ঘড়ি ও সেকেন্ডের `stretch_x`/`stretch_y` বদলানো **Android ১২+ ফোনে** কাজ করে। পুরনো ফোনে আসল মান (১.৩ / ১.১) লেআউট XML থেকে আসে (`widget_live_clock_main`-এর `android:scaleY="1.3"`, `widget_live_clock_seconds`-এর `android:scaleY="1.1"`)। সাইজ, রঙ ও অক্ষর-ফাঁকা সব ফোনে কাজ করে।

&nbsp;

> 💡 `stretch_x`/`stretch_y`/`letter_spacing_em` আসলে **সবগুলো লেখার জন্যই কাজ করে** (সেকশন ২-এর তালিকার যেকোনোটাতে ব্যবহার করতে পারেন) — শুধু ঘড়ির জন্য এখানে আলাদা করে দেখানো হলো কারণ এটাই মূল অনুরোধ ছিল।

&nbsp;

---

&nbsp;

<a name="s10"></a>
# ↔️ ১০) ফাঁকা (spacing)

&nbsp;

### 🔹 গ্লোবাল সংখ্যা/অক্ষর-ফাঁকা

```json
"letter_spacing": { "value_em": 0.05 }
```
(একটা নির্দিষ্ট লেখার জন্য আলাদা করতে সেকশন ২-এর `letter_spacing_em` ব্যবহার করুন)

&nbsp;

### 🔹 দুই লাইনের মাঝের ফাঁকা

```json
"line_gap": { "extra_gap_dp": 5 }
```

| মান | ফল |
|---|---|
| `0` | কাছাকাছি |
| `5` | ডিফল্ট |
| `8`–`10` | বেশ ফাঁকা (এর বেশি সুপারিশ না) |

&nbsp;

---

&nbsp;

<a name="s11"></a>
# 🪟 ১১) গ্লাস / ব্লার / কোণা রাউন্ড

&nbsp;

## 🔴 ১১.০ — সত্যি কথা: আসল ব্যাকগ্রাউন্ড-ব্লার কেন সম্ভব না

Android হোমস্ক্রিন উইজেট **জানতে পারে না তার পেছনে কোন ওয়ালপেপার আছে** — তাই CSS-এর `backdrop-filter: blur()`-এর মতো লাইভ ব্লার **Android উইজেটে সম্ভব না** (Play Store-এর সেরা উইজেটগুলোও পারে না — প্ল্যাটফর্মের সীমাবদ্ধতা)।

&nbsp;

## 🟢 ১১.১ — যা পারা যায়: "ভাসমান কাঁচ" লুক

1. **স্বচ্ছতা** (১১.২)
2. **ছায়া** (`shadow_dp`, সেকশন ৬/৭) — `4`–`6` দিন, সবচেয়ে বড় প্রভাব
3. **কিনারা/বর্ডার** (১১.৪)

&nbsp;

## 🎨 ১১.২ — কাঁচের স্বচ্ছতা বদলানো (রিবিল্ড লাগবে)

| ফাইল | কী | বর্তমান |
|---|---|---|
| `widget_background_glass.xml` | বড় কার্ড — ডার্ক | `#9E121B2E` |
| `widget_background_light.xml` | বড় কার্ড — লাইট | `#C8F4F6F9` |
| `widget_logo_frame.xml` | লোগোর বক্স | `#D9070D19` |
| `widget_pill_background.xml` | সব পিল-বক্স | `#DE0F1729` |
| `widget_card_highlight.xml` | হাইলাইট বক্স — ডার্ক | (সেকশন ৮ দেখুন) |
| `widget_card_highlight_light.xml` | হাইলাইট বক্স — লাইট | (সেকশন ৮ দেখুন) |

```
#  9E        12       1B       2E
   ↑         ↑        ↑        ↑
 স্বচ্ছতা    লাল      সবুজ     নীল
```

**শুধু প্রথম ২ অক্ষর বদলান:**

| চান | লিখুন | | চান | লিখুন |
|---|---|---|---|---|
| ১০০% | `FF` | | 50% | `80` |
| ৮০% | `CC` | | 30% | `4D` |
| ৭০% | `B3` | | 20% | `33` |
| ৬০% | `99` | | 10% | `1A` |

⚠️ লাইট মোডে কার্ড ৪০%-এর নিচে স্বচ্ছ করবেন না।

&nbsp;

## ⭕ ১১.৩ — কোণা রাউন্ড করা (রিবিল্ড লাগবে)

`<corners android:radius="…dp" />` — বড় মান = বেশি গোল, `0dp` = চৌকোনা।

&nbsp;

## 🖊️ ১১.৪ — বর্ডার বদলানো (রিবিল্ড লাগবে)

`<stroke android:width="1dp" android:color="#…" />`

&nbsp;

---

&nbsp;

<a name="s12"></a>
# ⚠️ ১২) সীমাবদ্ধতা — সৎভাবে

&nbsp;

| যা চান | কেন হয় না / কীভাবে হয় |
|---|---|
| আসল ব্যাকগ্রাউন্ড-ব্লার | সম্ভব না (১১.০ দেখুন) |
| তারিখ/সময়ের সংখ্যা নিজে লেখা | স্বয়ংক্রিয় হিসাব, স্থির লেখা না |
| ঘড়ি/সেকেন্ড/AM-PM/কাউন্টডাউন-সংখ্যার bold | নেটিভ লেখায় সম্ভব না (visible/size/color/stretch/spacing সবই হয়) |
| হাইলাইট বক্সের **রঙ** JSON থেকে | `res/values/colors.xml`-এ (রিবিল্ড লাগে) — সাইজ/কোণা JSON থেকেই হয় (সেকশন ৮) |
| ৫ ওয়াক্তের নাম/সময় আলাদা আলাদা রঙ | একসাথে গ্রুপ হিসেবে বদলায়; আলাদা করতে শুধু লুকানো (`prayer_rows`) যায় |
| বক্স/লাইন সরানো-ছোট-বড়-স্বচ্ছতা-ছায়া **পুরনো ফোনে (Android ১১ ও নিচে)** JSON থেকে | Google-এর নিজস্ব সীমাবদ্ধতা (সেকশন ১৫)। আসল মানগুলো XML-এ বসানো, তাই লুক একই থাকে; নতুন মান পুরনো ফোনে চাইলে XML বদলান |
| বক্স ছোট-বড় করেও ভেতরের লেখা অপরিবর্তিত রাখা | `scale` কনটেন্টসহ বদলায় (Android-এর ভিউ-স্কেলের ধর্ম); ভেতরের লেখা একই রেখে শুধু বক্স ছোট-বড় করতে XML-এ padding বদলান (রিবিল্ড লাগে) |

&nbsp;

---

&nbsp;

<a name="s13"></a>
# 🔄 ১৩) ভুল হলে ডিফল্টে ফেরা

&nbsp;

কোনো মান ভুল লিখলে সেই একটা মানের জন্য নিজে থেকেই ডিফল্ট ব্যবহার হয় — **উইজেট কখনো ক্র্যাশ করবে না**।

পুরো ফাইল ফেরাতে নিচের পুরোটা কপি করে `widget_style_config.json` প্রতিস্থাপন করুন (এটাই v16-এর আসল ডিফল্ট — আপনার সব মান এতে বসানো):

&nbsp;

```json
{
  "config_version": 16,
  "_____README_____": "এই ফাইলটা এডিট করে আপনি উইজেটের প্রতিটা জিনিস আলাদা আলাদাভাবে বদলাতে পারবেন: লেখা (দেখানো/লুকানো, সাইজ, রঙ, বোল্ড, লম্বা/চেপ্টা, অক্ষর-ফাঁকা, শব্দ পাল্টানো), আইকন (দেখানো/লুকানো, ছোট-বড়), বক্স (সরানো, ছোট-বড়, স্বচ্ছতা, ছায়া, বক্স লুকানো কিন্তু ভেতরের লেখা রাখা), পুরো লাইন/সারি (সরানো, ছোট-বড়), নামাজের রো (দেখানো/লুকানো), চলমান-ওয়াক্ত হাইলাইট বক্স (১:১ রাউন্ডেড-স্কয়ার — সাইজ/কোণা/ছায়া), মূল কার্ডের নিচের ফাঁকা। '_comment' দিয়ে শুরু হওয়া লাইনগুলো শুধু নোট — ওগুলো বদলাবেন না। 'config_version' বদলাবেন না (এটা দেখে অ্যাপ বুঝে পুরনো কপি বদলাবে কি না)। v16 থেকে এই ফাইলে কোথাও null নেই — প্রতিটা জায়গায় বর্তমান আসল মানটাই লেখা আছে, তাই সরাসরি সংখ্যা/রঙ বদলালেই হবে। রঙ লিখবেন \"#RRGGBB\" ফরম্যাটে। বিস্তারিত ধাপে ধাপে গাইড: WIDGET_CUSTOMIZATION_GUIDE.md। কোনো মান ভুল/মিসিং থাকলেও widget ক্র্যাশ করবে না।",
  "texts": {
    "_comment": "প্রতিটা লেখার: visible (দেখানো/লুকানো), size_sp (সাইজ), color (গ্লাস/ডার্ক/নো-ব্যাকগ্রাউন্ড থিমের রঙ), color_light_theme (লাইট থিমের রঙ), bold, stretch_x/stretch_y (1.0=স্বাভাবিক, 1.3=৩০% চওড়া/লম্বা, 0.8=সরু/খাটো — শুধু এই লেখাটাকে টানে), letter_spacing_em (এই লেখার নিজস্ব অক্ষর-ফাঁকা)। কাউন্টডাউনের দুটো লেখায় আলাদা color_forbidden (নিষিদ্ধ সময়ের লাল রঙ) আছে। ঘড়ি/সেকেন্ড/AM-PM/কাউন্টডাউন-সংখ্যা নেটিভ লেখা — এদের bold বদলানো যায় না (মান শুধু দেখানোর জন্য, XML-এর সাথে মিলিয়ে true লেখা); ঘড়ি ও সেকেন্ডের stretch_y (1.3 / 1.1) লেআউট XML-এও বসানো আছে, তাই পুরনো ফোনেও একই লুক আসে (নতুন মান বদলালে শুধু Android ১২+ ফোনে কাজ করবে)।",
    "hijri_day_number": {
      "visible": true,
      "size_sp": 28,
      "color": "#F1F5F9",
      "color_light_theme": "#070D19",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "hijri_month_year": {
      "visible": true,
      "size_sp": 17,
      "color": "#F1F5F9",
      "color_light_theme": "#070D19",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "date_others": {
      "visible": true,
      "size_sp": 15,
      "color": "#FFFFFF",
      "color_light_theme": "#475569",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "celestial_title": {
      "visible": true,
      "size_sp": 13.5,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "celestial_time": {
      "visible": true,
      "size_sp": 16,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "clock_time": {
      "visible": true,
      "size_sp": 26,
      "color": "#E2E8F0",
      "color_light_theme": "#E2E8F0",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.3,
      "letter_spacing_em": 0.02
    },
    "clock_seconds": {
      "visible": true,
      "size_sp": 16,
      "color": "#8FA0B8",
      "color_light_theme": "#8FA0B8",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.1,
      "letter_spacing_em": 0.0
    },
    "clock_ampm": {
      "visible": true,
      "size_sp": 10,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.0
    },
    "weather_title": {
      "visible": true,
      "size_sp": 13.5,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "weather_value": {
      "visible": true,
      "size_sp": 16,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "sehri_title": {
      "visible": true,
      "size_sp": 13.5,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "sehri_time": {
      "visible": true,
      "size_sp": 16,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "iftar_title": {
      "visible": true,
      "size_sp": 13.5,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "iftar_time": {
      "visible": true,
      "size_sp": 16,
      "color": "#FFFFFF",
      "color_light_theme": "#FFFFFF",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "prayer_names": {
      "visible": true,
      "size_sp": 13.5,
      "color": "#FFFFFF",
      "color_light_theme": "#475569",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "prayer_times": {
      "visible": true,
      "size_sp": 16,
      "color": "#F1F5F9",
      "color_light_theme": "#070D19",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "countdown_label": {
      "visible": true,
      "size_sp": 13.5,
      "color": "#FBBF24",
      "color_light_theme": "#070D19",
      "color_forbidden": "#E11D48",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.05
    },
    "countdown_chrono": {
      "visible": true,
      "size_sp": 11.5,
      "color": "#FBBF24",
      "color_light_theme": "#070D19",
      "color_forbidden": "#E11D48",
      "bold": true,
      "stretch_x": 1.0,
      "stretch_y": 1.0,
      "letter_spacing_em": 0.0
    }
  },
  "icons": {
    "_comment": "আইকন = গোল ব্যাজ + ভেতরের ছবি, একসাথে। visible: true/false, scale: 1.0=স্বাভাবিক। clock_icon-এর 0.9 লেআউট XML-এও বসানো (পুরনো ফোনে একই লুক); অন্য আইকনের scale বদলানো শুধু Android ১২+ ফোনে কাজ করে।",
    "logo": {
      "visible": true,
      "scale": 1.0
    },
    "celestial_icon": {
      "visible": true,
      "scale": 1.0
    },
    "clock_icon": {
      "visible": true,
      "scale": 0.9
    },
    "sehri_icon": {
      "visible": true,
      "scale": 1.0
    },
    "iftar_icon": {
      "visible": true,
      "scale": 1.0
    },
    "weather_icon": {
      "visible": true,
      "scale": 1.0
    },
    "countdown_warning_icon": {
      "visible": true,
      "scale": 1.0
    }
  },
  "prayer_rows": {
    "_comment": "প্রতিটা নামাজের রো (নাম + সময়) আলাদাভাবে দেখানো/লুকানো।",
    "fajr": true,
    "dhuhr": true,
    "asr": true,
    "maghrib": true,
    "isha": true
  },
  "labels": {
    "_comment": "লেখার আসল শব্দ — সরাসরি এখানেই বাংলা বানান ঠিক করুন বা নতুন শব্দ বসান (ইংরেজি জানার দরকার নেই, শুধু বাম পাশের key-টা ইংরেজি, ডান পাশের মানটাই আসল বাংলা শব্দ)। jumma = শুক্রবারে যোহরের জায়গায় দেখাবে।",
    "sunrise": "সূর্যোদয়",
    "sunset": "সূর্যাস্ত",
    "sehri": "সাহরী",
    "iftar": "ইফতার",
    "weather": "আবহাওয়া",
    "fajr": "ফজর",
    "dhuhr": "যোহর",
    "jum'ah": "জুম'আ",
    "asr": "আসর",
    "maghrib": "মাগরিব",
    "isha": "ইশা"
  },
  "letter_spacing": {
    "_comment": "সংখ্যা/অক্ষরের মাঝের সাধারণ (গ্লোবাল) ফাঁকা (em এককে)। 0=লেগে থাকা, 0.05=ডিফল্ট, 0.10=বেশি।",
    "value_em": 0.05
  },
  "line_gap": {
    "_comment": "দুই স্ট্যাক-করা লাইনের (যেমন ফজর ↔ ০৪:৩৩) মাঝের অতিরিক্ত ফাঁকা (dp)। 0=কাছাকাছি, 5=ডিফল্ট।",
    "extra_gap_dp": 5
  },
  "boxes": {
    "_comment": "বক্স = পেছনের কালার্ড শেপ। move_right_dp/move_down_dp = সরানো, scale × scale_x / scale × scale_y = ছোট-বড় (1.0 = স্বাভাবিক), opacity = স্বচ্ছতা, shadow_dp = ছায়া, visible=false → বক্স+ভেতরের সবকিছু গায়েব, background_visible=false → শুধু বক্সের রঙ গায়েব (লেখা/আইকন থাকবে)। সরানো/ছোট-বড়/স্বচ্ছতা/ছায়া Android ১২+ ফোনে কাজ করে (Android ১১ ও নিচে এগুলো Google-এর সীমাবদ্ধতায় সম্ভব না)। তবে main_card-এর shadow_dp (30) এবং clock_ampm_box-এর move_right_dp (-8) লেআউট XML-এও বসানো, তাই পুরনো ফোনেও একই লুক আসে। background_visible/visible সব ফোনেই কাজ করে।",
    "main_card": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 30,
      "visible": true,
      "background_visible": true
    },
    "logo_frame": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true,
      "background_visible": false
    },
    "clock_pill": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true,
      "background_visible": false
    },
    "celestial_pill": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true,
      "background_visible": false
    },
    "sehri_pill": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true,
      "background_visible": false
    },
    "iftar_pill": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true,
      "background_visible": false
    },
    "weather_pill": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true,
      "background_visible": false
    },
    "clock_ampm_box": {
      "move_right_dp": -8,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true,
      "background_visible": false
    }
  },
  "rows": {
    "_comment": "পুরো লাইন/সারি একসাথে সরানো/ছোট-বড়/স্বচ্ছতা/ছায়া/লুকানো। top_row = লোগো+তারিখ+সূর্যোদয়-সূর্যাস্ত, clock_weather_row = ঘড়ি+সাহরী+ইফতার+আবহাওয়া, prayers_row = ৫ ওয়াক্তের নাম+সময়, countdown_row = নিচের কাউন্টডাউন লাইন। v16: আপনার আগের সরানো মানগুলো (ঘড়ি-লাইন -৮, নামাজ-লাইন -১২, কাউন্টডাউন-লাইন -১৪) এখন লেআউটে পাকাপাকি বসে গেছে — এটাই এখন 'আসল' অবস্থান (তাই এখানে 0)। এখান থেকে আরও সরাতে চাইলে move_down_dp বদলান (Android ১২+ এ কাজ করে); সব ফোনে একই ফল চাইলে res/layout/widget_prayer_times.xml-এর margin বদলান (গাইড দেখুন)।",
    "top_row": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true
    },
    "clock_weather_row": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true
    },
    "prayers_row": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true
    },
    "countdown_row": {
      "move_right_dp": 0,
      "move_down_dp": 0,
      "scale": 1.0,
      "scale_x": 1.0,
      "scale_y": 1.0,
      "opacity": 1.0,
      "shadow_dp": 0,
      "visible": true
    }
  },
  "highlight": {
    "_comment": "চলমান ওয়াক্তের হাইলাইট বক্স — এখন লেখার পেছনে আলাদা ১:১ রাউন্ডেড-স্কয়ার (ছবি হিসেবে আঁকা), লেখা একচুলও নড়ে না। স্কয়ারের বাহু = ঘরের উচ্চতা; ডান-বাম থেকে চেপে ১:১ করা হয়েছে। size_adjust_dp = বাহুর মাপে যোগ/বিয়োগ (0 = স্বাভাবিক ১:১; ঋণাত্মক দিলে ছোট হবে; ধনাত্মক দিলে ঘরের উচ্চতা বেড়ে যেতে পারে)। corner_radius_dp = কোণা কতটা গোল (10 = ডিফল্ট)। এই দুটো সব ফোনে কাজ করে। move/scale/scale_x/scale_y/shadow শুধু হাইলাইট স্কয়ারের ওপর প্রভাব ফেলে (লেখার ওপর না) কিন্তু Android ১২+ এ কাজ করে; scale_x=1.0, scale_y=1.0 মানে ঠিক ১:১। রঙ res/values/colors.xml-এর widget_highlight_dark (ডার্ক/গ্লাস) ও widget_highlight_light (লাইট) — রিবিল্ড লাগবে।",
    "size_adjust_dp": 0,
    "corner_radius_dp": 10,
    "move_right_dp": 0,
    "move_down_dp": 0,
    "scale": 1.0,
    "scale_x": 1.0,
    "scale_y": 1.0,
    "shadow_dp": 0
  },
  "layout": {
    "_comment": "bottom_padding_dp = সবচেয়ে নিচের লেখা থেকে মূল কার্ডের নিচের কিনারা পর্যন্ত ফাঁকা (dp) — উপরে/ডানে/বামে কার্ডের কিনারা থেকে দৃশ্যমান লেখা-আইকনের দূরত্ব প্রায় ১৬–২০dp, তাই ১৭ রাখলে চার পাশেই সমান দেখায়। বেশি চাইলে বাড়ান, কম চাইলে কমান (সব ফোনে কাজ করে)। উপর/ডান/বাম padding ১২dp (XML-এ)।",
    "bottom_padding_dp": 17
  }
}
```

&nbsp;

&nbsp;

---

&nbsp;

<a name="s14"></a>
# 📐 ১৪) নিচের ফাঁকা (`layout`)

&nbsp;

```json
"layout": { "bottom_padding_dp": 17 }
```

| সেটিং | কাজ |
|---|---|
| `bottom_padding_dp` | সবচেয়ে নিচের লেখা থেকে মূল কার্ডের নিচের কিনারা পর্যন্ত ফাঁকা (dp) |

**কেন ১৭?** কার্ডের উপর, ডান ও বাম কিনারা থেকে প্রথম দৃশ্যমান লেখা/আইকন পর্যন্ত দূরত্ব প্রায় ১৬–২০ dp (কার্ডের ভেতরের ১২dp ফাঁকা + প্রতিটা অংশের নিজস্ব ভেতরের ফাঁকা)। নিচেও প্রায় সেই মাপ রাখা হয়েছে, তাই লেখার চারপাশে সমান ফাঁকা দেখায়। পাশাপাশি আগে নিচের লাইনগুলো ছবির মতো উপরে তোলা হলেও কার্ড আগের মাপেই থাকত (নিচে বাড়তি ~১৪dp ফাঁকা পড়ত) — এখন সেটা নেই; কার্ড নিচ থেকে ছোট হয়েছে, উপর-ডান-বাম আগের মতোই।

- বেশি ফাঁকা চাইলে সংখ্যা বাড়ান (যেমন `20`), কম চাইলে কমান (যেমন `14`)। সব ফোনে কাজ করে।
- কাউন্টডাউন লাইন না থাকলে (নিষিদ্ধ সময়/ওয়াক্তের ফাঁকে) উইজেট নিজে থেকে শেষ লাইনের ৫dp ভেতরের ফাঁকা বাদ দিয়ে বাকিটা রাখে, যাতে ফাঁকা একই দেখায়।
- উপর/ডান/বাম ফাঁকা (১২dp) বদলাতে `widget_prayer_times.xml`-এর `widget_root`-এর `paddingLeft/Top/Right` বদলান এবং `PrayerWidgetProvider.kt`-এর `ROOT_PAD_DP` একই মানে রাখুন।

&nbsp;

---

&nbsp;

<a name="s15"></a>
# 📱 ১৫) সব ফোনে কাজ করার নিয়ম

&nbsp;

### ❌ আগে কী সমস্যা ছিল ("Problem loading widget")

উইজেটের সরানো / ছোট-বড় / স্বচ্ছতা / ছায়া Android-এর `RemoteViews.setFloat()` দিয়ে পাঠানো হচ্ছিল। এই কাজটা **Android ১২ (API 31)-এর আগে অনুমোদিত না**। পুরনো ফোনের লঞ্চার উইজেট আঁকতে গিয়ে এই নির্দেশে হোঁচট খেয়ে "Problem loading widget" দেখাত (অ্যাপের ভেতরে try/catch থাকলেও লাভ হয়নি, কারণ ব্যর্থতাটা লঞ্চারের প্রসেসে ঘটে)।

### ✅ এখন কী করা হয়েছে

| বিষয় | সব ফোনে? | কীভাবে |
|---|---|---|
| লেখা (সাইজ, রঙ, বোল্ড, শব্দ), দেখানো/লুকানো, `background_visible`, নামাজের রো, অক্ষর-ফাঁকা | ✅ | সরাসরি অনুমোদিত পদ্ধতি |
| হাইলাইট ১:১ স্কয়ার (`size_adjust_dp`, `corner_radius_dp`) | ✅ | ছবি হিসেবে আঁকা |
| নিচের ফাঁকা (`bottom_padding_dp`) | ✅ | padding |
| আপনার আসল সরানো/স্কেল (লাইনের অবস্থান, ঘড়ির লম্বা ভাব ১.৩/১.১, ঘড়ি-আইকন ০.৯, AM/PM −৮dp, কার্ডের ছায়া ৩০) | ✅ | লেআউট XML-এ পাকাপাকি বসানো |
| নতুন করে সরানো / স্কেল / স্বচ্ছতা / ছায়া (JSON থেকে) | Android ১২+ | Google-এর সীমা; পুরনো ফোনে নিরাপদে বাদ দেওয়া হয়, উইজেট ঠিকই লোড হয় |

তাছাড়া Android ৭.x ফোনে পিলের ভেতরের ফাঁকা হারিয়ে যাওয়ার একটা ছোট সমস্যাও ঠিক করা হয়েছে (`paddingHorizontal/Vertical` ছিল Android ৮+ এর, এখন সব ফোনের উপযোগী `paddingLeft/Right/Top/Bottom`)।

### 🔁 পুরনো কনফিগ কপি নিয়ে সতর্কতা

অ্যাপ ফোনের `Android/data/com.gunjoron.patheyo/files/widget_style_config.json`-এ একটা কপি রাখে এবং সেটাই অগ্রাধিকার পায়। v16-এ কনফিগের অর্থ বদলেছে (লাইনের সরানো মান লেআউটে গেছে), তাই ফাইলে `"config_version": 16` না থাকলে অ্যাপ পুরনো কপিটাকে `widget_style_config.json.old` নামে ব্যাকআপ রেখে নতুনটা বসিয়ে দেয়। আপনার হাতে-সম্পাদনা করা মান দরকার হলে `.old` ফাইল থেকে দেখে নিন।

&nbsp;

---

&nbsp;

<a name="s16"></a>
# 📝 ১৬) v16-তে কী বদলেছে

&nbsp;

1. **"Problem loading widget" ফিক্স** — পুরনো ফোনেও উইজেট লোড হয়।
2. **মূল কার্ড নিচ থেকে ছোট** — নিচের বাড়তি ফাঁকা গেছে, চার পাশে সমান ফাঁকা; উপর-ডান-বাম আগের মতো।
3. **হাইলাইট ১:১ রাউন্ডেড-স্কয়ার** — শুধু সাদা ব্যাকগ্রাউন্ড, লেখা অক্ষত।
4. **আপনার হাইড / সাইজ / সরানো সব ১০০% অক্ষত** — কোনো লেখা, আইকন, বক্স বা লাইন আগের জায়গা/মাপ থেকে নড়েনি।
5. **JSON-এ কোনো null নেই** — প্রতিটা জায়গায় আসল সংখ্যা/রঙ, সাথে `color_light_theme`, `color_forbidden`, `layout`, `highlight.size_adjust_dp`, `highlight.corner_radius_dp` নতুন।
6. **এই গাইড** — আপনার বর্তমান মানগুলোকেই "আসল" ধরে লেখা।

💡 প্রতিটা ফাইলের ভেতরের কমেন্টেও বাংলায় ব্যাখ্যা আছে। কোনো অংশে আটকে গেলে প্রশ্ন করুন।

---
## ✅ v17 — যা যা বদলেছে

1. **কম্প্যাক্ট ও কাটা-না-পড়া উইজেট** — সারির ফাঁকা কমানো (মোট উচ্চতা ≈ ১৫–২০dp কম), পাঁচ ওয়াক্তের ঘর সবসময় একই উচ্চতার, ফোনের ফন্ট-সাইজ সেটিং সর্বোচ্চ ১.১৫× পর্যন্ত ধরা, `minResizeWidth/Height` = ২৪০/১৪০dp। তবুও কোনো লঞ্চার ছোট করতে দিলে কোড (updateWidget-এর শেষের অংশ + `onAppWidgetOptionsChanged`) আগে চারদিকের ফাঁকা কমায়, তাতেও না ধরলে শুধু কাউন্টডাউন সারি লুকায় — লেখা কখনো ভাঙে/কাটে না। কাউন্টডাউনের লেখা জায়গা কম হলে সমানুপাতে ছোট হয়।
2. **চারদিকে সমান ফাঁকা** — `layout.edge_padding_dp` (ডিফল্ট ১২); নিচের ফাঁকা প্রতিটা ভ্যারিয়েন্টে কোড নিজে হিসাব করে উপরের সমান রাখে। হাতে সূক্ষ্ম বদলাতে `layout.bottom_extra_dp`।
3. **আইকন-বৃত্তের রঙ/অপাসিটি JSON-এ** — `icon_circles` (celestial, clock, sehri, iftar, weather, ampm): `color` / `color_light_theme`, `opacity` / `opacity_light_theme`, `border_opacity*`। বর্তমান মান (০.২৫ / ০.৪৫) বসানো আছে। ডার্ক/লাইট আইকন ফাইল: `ic_widget_{clock,sehri,iftar,thermometer,sunrise,sunset}.xml` ও `*_light.xml`। সূর্যোদয়/সূর্যাস্ত আলাদা আইকন — সূর্য ওঠার পর থেকে ডোবা পর্যন্ত "সূর্যাস্ত" (নিচে নামার আইকন), ডোবার পর "সূর্যোদয়" (উপরে ওঠার আইকন)।
4. **ট্রান্সপারেন্ট থিমে ডার্ক/লাইট মোড** — হাবে ট্রান্সপারেন্ট বাছলে মোড-সিলেক্টর আসে। নেটিভ থিম-নাম: `glass | nobg | nobg_light | light`। প্রিভিউ ছবি: ডার্ক 07–12, লাইট 19–24।
5. **প্রিমিয়াম উইজেট হাব UI** (রঙের কোড অপরিবর্তিত)।
6. **বাংলা লেখা সব Gunjoron-Font-Normal.ttf-এ** — শুধু বাংলা ফন্টগুলো (Noto Serif Bengali, Hind Siliguri, Galada) সরানো (ফাইলসহ)। আরবি ও ইংরেজি ফন্ট আগের মতোই (v18-এ ফেরানো): কুরআনের আরবি = Amiri, ইংরেজি/সংখ্যা = JetBrains Mono, ডিজিটাল ঘড়ি = JetBrains Mono → Roboto Condensed → Oswald; উইজেটের লাইভ ঘড়ি = sans-serif-condensed, কাউন্টডাউন সংখ্যা = sans-serif-black (অপরিবর্তিত)। নেটিভ আজান/অ্যালার্ম স্ক্রিনের বাংলা লেখায় Gunjoron-Font। নোটিফিকেশন ফোনের ডিফল্ট ফন্টেই।
7. **ডিফল্ট উইজেট** = লাইভ ঘড়ি ON + সাহরী/ইফতার ON, আবহাওয়া OFF (অ্যাপ না খুলে যোগ করলেও)।
8. **উইজেট-তালিকার প্রিভিউ** — `previewImage` এখন আসল ডিফল্ট ছবি (`drawable-nodpi` = লাইট, `drawable-night-nodpi` = ডার্ক); `previewLayout` সরানো (নতুন ফোনে ভাঙা দেখানোর কারণ)।
9. **একটাই আইটেম চালু থাকলে লাইনের মাঝখানে** — সারি ২-এর প্রতিটা পিলের কনটেন্ট `gravity=center`।
10. **ঘড়ি বন্ধ থাকলে আবহাওয়া + সাহরী/ইফতার একসাথে** (বামে সাহরী/ইফতার, ডানে আবহাওয়া); ঘড়ি চালু থাকলে একটা অন করলে আরেকটা অফ।
11. **তারিখের মাঝের দাগ** এখন নিজে-আঁকা (ফন্ট/নেট নির্ভর না) — `date_separator` (উচ্চতা ০.৭২em, আগে ≈০.৫১em; রঙ সামান্য হালকা)।
12. **ডার্ক মোডের হাইলাইট** = `#E6E6E6` (`highlight.color`); লাইট আগের মতো।

## ✅ v18
- v17-এ ভুলবশত সরে যাওয়া আরবি (Amiri) ও ইংরেজি (JetBrains Mono, Roboto Condensed, Oswald) ফন্ট আগের জায়গায় ফেরানো হয়েছে। উইজেটের ঘড়ি ও কাউন্টডাউনের ফন্ট v16-এর হুবহু একই (কাউন্টডাউন সংখ্যায় v17-এর যোগ করা includeFontPadding/singleLine সরানো হয়েছে)।


&nbsp;

---

# 📝 v20-তে কী বদলেছে (গাইডের জন্য)

- **হাইলাইট প্রস্থ:** `widget_style_config.json` → `highlight.width_scale` (ডিফল্ট `1.12`)। `1.0` = আগের মতো ১:১; বাড়ালে ডান-বাম চওড়া হয়, উচ্চতা বদলায় না। ঘরের প্রস্থের বেশি হয় না।
- **কাস্টম থিম:** রঙ/স্বচ্ছতা/টোন অ্যাপের উইজেট হাব থেকে সেট হয় (JSON-এ নয়)।
- **অটো স্কেল:** লেখার সাইজ উইজেটের মাপ অনুযায়ী ০.৮×–১.২× (উচ্চতায় না ধরলে ০.৭২× পর্যন্ত) বাড়ে-কমে। JSON-এর `size_sp` মানগুলো ১.০× ধরে দেওয়া — সেগুলোই বেসলাইন।
- **সাইজ:** ডিফল্ট ৪×২; ডান-বাম ৪ ঘর থেকে গ্রিডের শেষ পর্যন্ত বাড়ানো যায়।
