package com.gunjoron.patheyo.datecard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.RectF
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.gunjoron.patheyo.FirebaseDataManager
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import com.gunjoron.patheyo.widgethub.data.Snapshot
import com.gunjoron.patheyo.widgethub.data.calendar.Bn
import java.util.Calendar

/**
 * v243: ত্রি-পঞ্জিকা ক্যালেন্ডার — ইংরেজি মাসের আসল ক্যালেন্ডার-গ্রিড, প্রতিটি ঘরে তিনটি তারিখ (ইংরেজি · বাংলা · হিজরি),
 * আগের/পরের মাসে যাওয়ার বোতাম, ঘরে চাপলে ওই দিনের তিন তারিখের বিস্তারিত, আর নিচে আসন্ন বিশেষ দিন।
 * আজকের হিজরি তারিখ আসে হোম/উইজেটের একই হিসাব ([Snapshot]) থেকে — তাই ফায়ারবেস-অ্যাডজাস্টমেন্ট মেনে চলে;
 * অন্য দিনের হিজরি তারিখ = ফোনের সূত্র + ওই অ্যাডজাস্টমেন্টের পার্থক্য। বাংলা তারিখ সংশোধিত পঞ্জিকা (পহেলা বৈশাখ = ১৪ এপ্রিল)।
 */
class HijriCalendarCard(private val ctx: Context, private val p: Pal) {

    class Pal(
        val surf: Int, val surfHi: Int, val surf2: Int, val line: Int,
        val text: Int, val text2: Int, val text3: Int,
        val primary: Int, val press: Int, val onPrimary: Int, val primaryText: Int,
        val gold: Int, val goldLine: Int, val goldSoft: Int,
        val bold: Typeface, val reg: Typeface
    )

    class Ev(val m: Int, val d: Int, val t: String, val s: String? = null)
    class Up(val k: Int, val g: Calendar, val title: String, val sub: String?, val day: Int, val month: Int)
    class H(val day: Int, val month: Int, val year: Int)

    companion object {
        /** মাসের নাম — নামাজ ফিচারের hijriMonthsBN-এর সাথে হুবহু */
        val MONTHS = arrayOf(
            "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল উলা", "জমাদিউস সানি",
            "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
        )
        private val EVENTS = listOf(
            Ev(0, 1, "হিজরি নববর্ষ"),
            Ev(0, 10, "আশুরা", "৯ ও ১০ বা ১০ ও ১১ মুহাররম রোজা"),
            Ev(6, 26, "শবে মিরাজ", "২৬ রজব দিবাগত রাত"),
            Ev(7, 14, "শবে বরাত", "১৪ শাবান দিবাগত রাত"),
            Ev(8, 1, "রমজান শুরু", "প্রথম রোজা (চাঁদ দেখা সাপেক্ষে)"),
            Ev(8, 26, "শবে কদর", "২৬ রমজান দিবাগত রাত"),
            Ev(9, 1, "ঈদুল ফিতর", "আজ রোজা রাখা হারাম"),
            Ev(11, 9, "আরাফাহর দিন", "নফল রোজা — দুই বছরের গুনাহ মাফ"),
            Ev(11, 10, "ঈদুল আজহা", "কোরবানির দিন")
        )
        private val WD = arrayOf("শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র")
        private val WD_FULL = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

        // ---------------------------------------------------------------- হিসাব

        private fun midnight(base: Calendar, plusDays: Int): Calendar =
            (base.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.DAY_OF_YEAR, plusDays)
            }

        /** Tabular Islamic Calendar (অ্যাডজাস্টমেন্ট ছাড়া) — ওয়েবের localGregorianToHijri(date, true)-এর সমান */
        private fun tabular(c: Calendar): H {
            val y = c.get(Calendar.YEAR); val m = c.get(Calendar.MONTH) + 1; val d = c.get(Calendar.DAY_OF_MONTH)
            val a = (14 - m) / 12
            val y2 = y + 4800 - a
            val m2 = m + 12 * a - 3
            val jdn = d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 - 32045
            var l = jdn - 1948440 + 10632
            val n = (l - 1) / 10631
            l = l - 10631 * n + 354
            val j = (10985 - l) / 5316 * (50 * l / 17719) + (l / 5670) * (43 * l / 15238)
            l = l - (30 - j) / 15 * (17719 * j / 50) - (j / 16) * (15238 * j / 43) + 29
            val month = (24 * l) / 709
            val day = l - (709 * month) / 24
            return H(day, month - 1, 30 * n + j - 30)
        }

        class B(val day: Int, val month: Int, val year: Int)

        /** বাংলা তারিখ (বাংলাদেশ সংশোধিত পঞ্জিকা, পহেলা বৈশাখ = ১৪ এপ্রিল) — Snapshot.banglaOf-এর সমান হিসাব, যেকোনো দিনের জন্য */
        fun banglaOf(c: Calendar): B {
            val now = midnight(c, 0)
            val gYear = now.get(Calendar.YEAR)
            fun leap(y: Int) = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)
            var bYear = gYear - 593
            var poyla = (now.clone() as Calendar).apply { set(gYear, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            if (now.timeInMillis < poyla.timeInMillis) {
                bYear -= 1
                poyla = (now.clone() as Calendar).apply { set(gYear - 1, Calendar.APRIL, 14, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            }
            val diff = Math.round((now.timeInMillis - poyla.timeInMillis) / 86400000.0).toInt()
            // বাংলা বছরের মাসের দিন-সংখ্যা: ফাল্গুন বাংলা বছরের শেষ দিকে পড়ে (পরের ইংরেজি বছরের ফেব্রুয়ারি) — তাই লিপ-ইয়ার পোয়লার ইংরেজি বছর ধরে
            val polYear = poyla.get(Calendar.YEAR)
            val dm = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (leap(polYear + 1)) 30 else 29, 30)
            var mi = 0; var bd = diff + 1
            while (mi < dm.size - 1 && bd > dm[mi]) { bd -= dm[mi]; mi++ }
            return B(bd, mi, bYear)
        }

        private fun monthIndexOf(name: String): Int {
            val n = name.trim()
            for (i in MONTHS.indices) if (n == MONTHS[i]) return i
            for (i in Bn.HIJRI_MONTHS.indices) if (n == Bn.HIJRI_MONTHS[i]) return i
            for (i in MONTHS.indices) if (n.contains(MONTHS[i]) || MONTHS[i].contains(n)) return i
            return -1
        }

        /**
         * হিজরি তারিখ ঠিক [atMs] সময়ে — হোম/উইজেটের একই উৎস ([Snapshot]) থেকে, তাই ফায়ারবেসের hijri_adjustment /
         * hijri_override / মাগরিব-শিফট সব মেনে চলে। না পেলে ফোনের সূত্র + সেভ করা অ্যাডজাস্টমেন্ট।
         */
        private fun hijriAt(ctx: Context, atMs: Long, civil: Calendar): H {
            try {
                val snap = Snapshot.build(ctx.applicationContext, atMs)
                val day = FirebaseDataManager.convertBengaliToEnglish(snap.hijriDay).trim().toIntOrNull()
                val year = FirebaseDataManager.convertBengaliToEnglish(snap.hijriYear).trim().toIntOrNull()
                val mi = monthIndexOf(snap.hijriMonth)
                if (day != null && year != null && mi >= 0 && day in 1..30) return H(day, mi, year)
            } catch (_: Throwable) {}
            val adj = try { ctx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE).getInt("last_rtdb_adjustment", 0) } catch (_: Throwable) { 0 }
            return tabular(midnight(civil, adj))
        }

        /** ক্যালেন্ডারের সঠিক "চিহ্ন" (এখন অ্যাপের হোমে যে হিজরি তারিখ দেখায়) — বদলালে ক্যালেন্ডার নতুন করে আঁকতে হয় */
        fun signature(ctx: Context): String {
            val civil = midnight(Calendar.getInstance(), 0)
            val h = hijriAt(ctx, System.currentTimeMillis(), civil)
            return "${h.day}-${h.month}-${h.year}|${civil.get(Calendar.DAY_OF_YEAR)}"
        }
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * ctx.resources.displayMetrics.density

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text; textSize = size; setTextColor(color); typeface = if (bold) p.bold else p.reg
    }

    private class StarDrawable(private val col: Int) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        override fun draw(cv: Canvas) {
            paint.color = col
            val s = bounds.width() / 100f
            val pts = floatArrayOf(50f, 1f, 64f, 15f, 85f, 15f, 85f, 36f, 99f, 50f, 85f, 64f, 85f, 85f, 64f, 85f, 50f, 99f, 36f, 85f, 15f, 85f, 15f, 64f, 1f, 50f, 15f, 36f, 15f, 15f, 36f, 15f)
            val path = Path()
            var i = 0
            while (i < pts.size) { val x = bounds.left + pts[i] * s; val y = bounds.top + pts[i + 1] * s; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y); i += 2 }
            path.close(); cv.drawPath(path, paint)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    private fun dot(size: Int, color: Int) = View(ctx).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        layoutParams = LinearLayout.LayoutParams(size, size)
    }

    private class Chev(private val dir: Int, private val col: Int) : Drawable() {
        private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        override fun draw(cv: Canvas) {
            pt.color = col; pt.strokeWidth = bounds.width() * 0.09f
            val w = bounds.width().toFloat(); val cx = bounds.exactCenterX(); val cy = bounds.exactCenterY()
            val path = Path()
            path.moveTo(cx - dir * w * 0.09f, cy - w * 0.17f); path.lineTo(cx + dir * w * 0.09f, cy); path.lineTo(cx - dir * w * 0.09f, cy + w * 0.17f)
            cv.drawPath(path, pt)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    private fun hijriSpan(a: H, b: H): String =
        if (a.month == b.month && a.year == b.year) "${MONTHS[a.month]} ${Bn.digits(a.year)}"
        else if (a.year == b.year) "${MONTHS[a.month]} – ${MONTHS[b.month]} ${Bn.digits(a.year)}"
        else "${MONTHS[a.month]} ${Bn.digits(a.year)} – ${MONTHS[b.month]} ${Bn.digits(b.year)}"

    private fun banglaSpan(a: B, b: B): String =
        if (a.month == b.month && a.year == b.year) "${Bn.BANGLA_MONTHS[a.month]} ${Bn.digits(a.year)}"
        else if (a.year == b.year) "${Bn.BANGLA_MONTHS[a.month]} – ${Bn.BANGLA_MONTHS[b.month]} ${Bn.digits(a.year)}"
        else "${Bn.BANGLA_MONTHS[a.month]} ${Bn.digits(a.year)} – ${Bn.BANGLA_MONTHS[b.month]} ${Bn.digits(b.year)}"

    private fun tagged(label: String, labelCol: Int, value: String, valueCol: Int): CharSequence {
        val sb = SpannableStringBuilder()
        sb.append(label); sb.setSpan(ForegroundColorSpan(labelCol), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val st = sb.length; sb.append("  ").append(value)
        sb.setSpan(ForegroundColorSpan(valueCol), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    // ---------------------------------------------------------------- গঠন

    fun build(): View {
        val civil = midnight(Calendar.getInstance(), 0)
        // অ্যাপের হোমে এখন যে হিজরি তারিখ দেখায় (মাগরিবের পর পরের দিন)
        val shown = hijriAt(ctx, System.currentTimeMillis(), civil)
        val base = hijriAt(ctx, civil.timeInMillis + 60_000L, civil)       // একই দিনের মাগরিব-শিফট ছাড়া তারিখ
        val shift = if (shown.day == base.day && shown.month == base.month && shown.year == base.year) 0 else 1
        val now = midnight(civil, shift)      // দেখানো হিজরি দিনটির সাথে মেলানো ইংরেজি তারিখ
        val h0 = shown

        // হিজরি ↔ ফোনের সূত্রের পার্থক্য (দিন) — ওয়েবের nzHijriDelta
        var delta = 0
        for (d in -3..3) { val x = tabular(midnight(now, d)); if (x.day == h0.day && x.month == h0.month) { delta = d; break } }
        // ক্যালেন্ডারের ঘরের জন্য: মাগরিব-শিফট ছাড়া (ইংরেজি দিনের নিজের হিজরি তারিখ)
        var delta0 = 0
        for (d in -3..3) { val x = tabular(midnight(civil, d)); if (x.day == base.day && x.month == base.month) { delta0 = d; break } }
        fun hijriOf(g: Calendar): H = tabular(midnight(g, delta0))

        val todayY = civil.get(Calendar.YEAR); val todayM = civil.get(Calendar.MONTH); val todayD = civil.get(Calendar.DAY_OF_MONTH)
        var vy = todayY; var vm = todayM; var sel = todayD

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surfHi, p.surf)).apply {
                cornerRadius = dpf(24f); setStroke(dp(1), p.line)
            }
        }
        val dyn = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        card.addView(dyn, LinearLayout.LayoutParams(-1, -2))

        val cellW = (ctx.resources.displayMetrics.widthPixels - dp(32) - dp(28)) / 7
        val cellH = maxOf(dp(58), (cellW * 1.42f).toInt())
        val todayWhite = Color.WHITE; val todayGold = Color.parseColor("#FFE3A0")

        fun navBtn(dir: Int, onClick: () -> Unit) = View(ctx).apply {
            background = android.graphics.drawable.LayerDrawable(arrayOf(
                GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(p.surf2); setStroke(dp(1), p.line) },
                Chev(dir, p.text)
            ))
            contentDescription = if (dir < 0) "আগের মাস" else "পরের মাস"
            setOnClickListener { onClick() }
        }

        lateinit var render: () -> Unit
        fun go(dm: Int) {
            val c = Calendar.getInstance().apply { clear(); set(vy, vm, 1); add(Calendar.MONTH, dm) }
            val ny = c.get(Calendar.YEAR)
            if (ny < 1950 || ny > 2100) return
            vy = ny; vm = c.get(Calendar.MONTH)
            sel = if (vy == todayY && vm == todayM) todayD else 1
            dyn.animate().cancel(); dyn.alpha = 0.15f; render(); dyn.animate().alpha(1f).setDuration(160).start()
        }

        render = {
            dyn.removeAllViews()
            val first = Calendar.getInstance().apply { clear(); set(vy, vm, 1) }
            val len = first.getActualMaximum(Calendar.DAY_OF_MONTH)
            val last = midnight(first, len - 1)
            val lead = (((first.get(Calendar.DAY_OF_WEEK) - 1) + 1) % 7)      // শনিবার থেকে সপ্তাহ
            val isCur = vy == todayY && vm == todayM
            if (sel > len) sel = len

            // ---------- মাথা: ‹  মাসের নাম + বাংলা/হিজরি মাস  ›
            val nav = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            nav.addView(navBtn(-1) { go(-1) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            mid.addView(tv("${Bn.GREG_MONTHS[vm]} ${Bn.digits(vy)}", 21f, p.text, true).apply { gravity = Gravity.CENTER })
            mid.addView(TextView(ctx).apply {
                text = tagged("বাংলা", p.primaryText, banglaSpan(banglaOf(first), banglaOf(last)), p.text2)
                textSize = 11.5f; typeface = p.reg; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0)
            })
            mid.addView(TextView(ctx).apply {
                text = tagged("হিজরি", p.gold, hijriSpan(hijriOf(first), hijriOf(last)), p.text2)
                textSize = 11.5f; typeface = p.reg; gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0)
            })
            nav.addView(mid, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6); rightMargin = dp(6) })
            nav.addView(navBtn(1) { go(1) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            dyn.addView(nav, LinearLayout.LayoutParams(-1, -2))

            // ---------- সপ্তাহের দিন
            val wdRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(16), 0, dp(6)) }
            WD.forEachIndexed { i, w ->
                wdRow.addView(tv(w, 11f, if (i == 6) p.gold else p.text3, true).apply { gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(0, -2, 1f))
            }
            dyn.addView(wdRow, LinearLayout.LayoutParams(-1, -2))
            dyn.addView(View(ctx).apply { background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, p.goldLine, Color.TRANSPARENT)) },
                LinearLayout.LayoutParams(-1, dp(1)))

            // ---------- গ্রিড
            val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            var row: LinearLayout? = null
            var col = 0
            fun newRow() { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; grid.addView(row, LinearLayout.LayoutParams(-1, cellH).apply { topMargin = dp(2) }); col = 0 }
            newRow()
            for (i in 0 until lead) { row!!.addView(View(ctx), LinearLayout.LayoutParams(0, cellH, 1f)); col++ }
            for (d in 1..len) {
                if (col == 7) newRow()
                val g = midnight(first, d - 1)
                val hj = hijriOf(g); val bn = banglaOf(g)
                val ev = EVENTS.firstOrNull { it.m == hj.month && it.d == hj.day }
                val white = hj.day in 13..15 && hj.month != 8 && !(hj.month == 11 && hj.day >= 11)
                val isT = isCur && d == todayD
                val past = isCur && d < todayD || (vy < todayY) || (vy == todayY && vm < todayM)
                val jsDow = g.get(Calendar.DAY_OF_WEEK) - 1
                val cellView = cell(d, bn, hj, isT, d == sel, past, white, ev, jsDow == 5, todayWhite, todayGold)
                cellView.setOnClickListener { sel = d; render() }
                cellView.contentDescription = "${Bn.digits(d)} ${Bn.GREG_MONTHS[vm]}, ${WD_FULL[jsDow]} · বাংলা ${Bn.digits(bn.day)} ${Bn.BANGLA_MONTHS[bn.month]} · হিজরি ${Bn.digits(hj.day)} ${MONTHS[hj.month]}" +
                    (if (ev != null) " · ${ev.t}" else "")
                row!!.addView(cellView, LinearLayout.LayoutParams(0, cellH, 1f))
                col++
            }
            while (col in 1..6) { row!!.addView(View(ctx), LinearLayout.LayoutParams(0, cellH, 1f)); col++ }
            dyn.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

            // ---------- ইঙ্গিত + "আজ" বোতাম
            val key = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(12), dp(2), 0) }
            key.addView(View(ctx).apply { background = StarDrawable(p.gold) }, LinearLayout.LayoutParams(dp(9), dp(9)))
            key.addView(tv("বিশেষ দিন", 11f, p.text3).apply { setPadding(dp(4), 0, dp(12), 0) })
            key.addView(dot(dp(6), p.primaryText))
            key.addView(tv("আইয়ামে বিয (সুন্নাত রোজা)", 11f, p.text3).apply { setPadding(dp(4), 0, 0, 0) })
            key.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
            key.addView(tv("আজ", 12f, p.gold, true).apply {
                gravity = Gravity.CENTER; setPadding(dp(14), dp(5), dp(14), dp(5))
                background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(p.goldSoft); setStroke(dp(1), p.goldLine) }
                visibility = if (isCur) View.INVISIBLE else View.VISIBLE
                setOnClickListener { vy = todayY; vm = todayM; sel = todayD; dyn.alpha = 0.15f; render(); dyn.animate().alpha(1f).setDuration(160).start() }
            })
            dyn.addView(key, LinearLayout.LayoutParams(-1, -2))

            // ---------- নির্বাচিত দিনের তিন তারিখ
            val sg = midnight(first, sel - 1)
            val sh = hijriOf(sg); val sb = banglaOf(sg)
            val sDow = sg.get(Calendar.DAY_OF_WEEK) - 1
            val sEv = EVENTS.firstOrNull { it.m == sh.month && it.d == sh.day }
            val sToday = isCur && sel == todayD
            dyn.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(16) })
            val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, dp(6)) }
            head.addView(tv(WD_FULL[sDow], 15f, if (sDow == 5) p.gold else p.text, true), LinearLayout.LayoutParams(0, -2, 1f))
            if (sToday) head.addView(tv("আজ", 11f, p.onPrimary, true).apply {
                gravity = Gravity.CENTER; setPadding(dp(10), dp(3), dp(10), dp(3))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(50f) }
            })
            dyn.addView(head, LinearLayout.LayoutParams(-1, -2))
            fun line(c: Int, label: String, v: String) {
                val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
                r.addView(dot(dp(8), c), LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(10) })
                r.addView(tv(label, 12.5f, p.text3), LinearLayout.LayoutParams(dp(54), -2))
                r.addView(tv(v, 14.5f, p.text, true), LinearLayout.LayoutParams(0, -2, 1f))
                dyn.addView(r, LinearLayout.LayoutParams(-1, -2))
            }
            line(p.text2, "ইংরেজি", "${Bn.digits(sel)} ${Bn.GREG_MONTHS[vm]} ${Bn.digits(vy)}")
            line(p.primaryText, "বাংলা", "${Bn.digits(sb.day)} ${Bn.BANGLA_MONTHS[sb.month]} ${Bn.digits(sb.year)}")
            line(p.gold, "হিজরি", "${Bn.digits(sh.day)} ${MONTHS[sh.month]} ${Bn.digits(sh.year)}")
            if (sEv != null || (sh.day in 13..15 && sh.month != 8 && !(sh.month == 11 && sh.day >= 11))) {
                val t = sEv?.t ?: "আইয়ামে বিয — সুন্নাত রোজার দিন"
                dyn.addView(tv("✦  $t" + (if (sEv?.s != null) " · ${sEv.s}" else ""), 12.5f, p.gold, true).apply {
                    setPadding(dp(12), dp(8), dp(12), dp(8)); setLineSpacing(0f, 1.2f)
                    background = GradientDrawable().apply { cornerRadius = dpf(12f); setColor(p.goldSoft) }
                }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
            }
            if (sToday && shift == 1) dyn.addView(tv("মাগরিবের পর হিজরি তারিখ ${Bn.digits(shown.day)} ${MONTHS[shown.month]} ${Bn.digits(shown.year)} (হোমের মতো)", 11f, p.text3).apply {
                setPadding(0, dp(8), 0, 0)
            })
        }
        render()

        // ---------- আসন্ন বিশেষ দিন
        val ups = ArrayList<Up>()
        val seen = HashSet<String>()
        var seenWhite = false
        var k = 0
        while (k < 400 && ups.size < 12) {
            val x = tabular(midnight(now, k + delta)); val g = midnight(now, k)
            for (e in EVENTS) if (e.m == x.month && e.d == x.day && seen.add(e.t)) ups.add(Up(k, g, e.t, e.s, x.day, x.month))
            if (!seenWhite && x.day == 13 && k > 0 && x.month != 11) { seenWhite = true; ups.add(Up(k, g, "আইয়ামে বিয রোজা", "১৩, ১৪ ও ১৫ তারিখ — সুন্নাত রোজা", x.day, x.month)) }
            k++
        }
        ups.sortBy { it.k }

        card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(20) })
        card.addView(tv("আসন্ন বিশেষ দিন", 15f, p.text, true).apply { setPadding(0, dp(16), 0, dp(4)) })
        ups.take(4).forEachIndexed { i, u ->
            if (i > 0) card.addView(View(ctx).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(-1, dp(1)))
            card.addView(eventRow(u))
        }
        card.addView(tv("চাঁদ দেখার ওপর ভিত্তি করে হিজরি তারিখ এক দিন আগে-পরে হতে পারে।", 11f, p.text3).apply { setPadding(0, dp(12), 0, 0) })
        return card
    }

    /** একটি দিনের ঘর: ওপরে ইংরেজি তারিখ (বড়), নিচে বাংলা (নীল) ও হিজরি (সোনালি) তারিখ পাশাপাশি */
    private fun cell(d: Int, bn: B, hj: H, isToday: Boolean, selected: Boolean, past: Boolean, white: Boolean, ev: Ev?, fri: Boolean,
                     todayWhite: Int, todayGold: Int): android.widget.FrameLayout {
        val box = android.widget.FrameLayout(ctx)
        val inner = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        inner.background = when {
            isToday -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.press)).apply { cornerRadius = dpf(14f); setStroke(dp(1), p.goldLine) }
            selected -> GradientDrawable().apply { cornerRadius = dpf(14f); setColor((p.primary and 0x00FFFFFF) or 0x2A000000); setStroke(dp(1) + 1, p.primaryText) }
            fri -> GradientDrawable().apply { cornerRadius = dpf(14f); setColor((p.gold and 0x00FFFFFF) or 0x14000000) }
            else -> null
        }
        val enCol = if (isToday) todayWhite else if (fri) p.gold else p.text
        inner.addView(tv(Bn.digits(d), 16.5f, enCol, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; includeFontPadding = false })
        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) }
        sub.addView(tv(Bn.digits(bn.day), 10.5f, if (isToday) todayWhite else p.primaryText, true).apply { includeFontPadding = false })
        sub.addView(View(ctx), LinearLayout.LayoutParams(dp(5), 1))
        sub.addView(tv(Bn.digits(hj.day), 10.5f, if (isToday) todayGold else p.gold, true).apply { includeFontPadding = false })
        inner.addView(sub, LinearLayout.LayoutParams(-2, -2))
        if (past && !isToday) inner.alpha = .5f
        box.addView(inner, android.widget.FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
        if (white) box.addView(dot(dp(4), if (isToday) todayWhite else p.primaryText), android.widget.FrameLayout.LayoutParams(dp(4), dp(4), Gravity.TOP or Gravity.START).apply { topMargin = dp(6); leftMargin = dp(6) })
        if (ev != null) box.addView(View(ctx).apply { background = StarDrawable(if (isToday) todayGold else p.gold) },
            android.widget.FrameLayout.LayoutParams(dp(8), dp(8), Gravity.TOP or Gravity.END).apply { topMargin = dp(5); rightMargin = dp(5) })
        return box
    }

    private fun eventRow(u: Up): View {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        // আর্চ-আকৃতির তারিখ-বক্স
        val date = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6))
            val r = dpf(23f); val s = dpf(6f)
            background = GradientDrawable().apply { setCornerRadii(floatArrayOf(r, r, r, r, s, s, s, s)); setColor(Color.TRANSPARENT); setStroke(dp(1), p.goldLine) }
        }
        date.addView(tv(Bn.digits(u.g.get(Calendar.DAY_OF_MONTH)), 17f, p.gold, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER })
        date.addView(tv(Bn.GREG_MONTHS[u.g.get(Calendar.MONTH)], 11f, p.text3).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; maxLines = 1; setPadding(0, dp(2), 0, 0) })
        row.addView(date, LinearLayout.LayoutParams(dp(54), -2).apply { rightMargin = dp(12) })

        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(tv(u.title, 15f, p.text, true))
        val jsDow = u.g.get(Calendar.DAY_OF_WEEK) - 1
        mid.addView(tv("${Bn.digits(u.day)} ${MONTHS[u.month]} · ${WD_FULL[jsDow]}" + (if (u.sub != null) " · ${u.sub}" else ""), 12f, p.text3).apply {
            setLineSpacing(0f, 1.25f); setPadding(0, dp(4), 0, 0)
        })
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))

        val soon = u.k <= 7
        val whenTxt = when (u.k) { 0 -> "আজ"; 1 -> "আগামীকাল"; else -> "আর ${Bn.digits(u.k)} দিন" }
        row.addView(tv(whenTxt, 11f, if (soon) p.gold else p.text2, soon).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply { cornerRadius = dpf(50f); setColor(if (soon) p.goldSoft else p.surf2) }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        return row
    }
}
